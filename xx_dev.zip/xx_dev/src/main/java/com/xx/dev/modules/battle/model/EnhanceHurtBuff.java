/**
 * @file:EnhanceHurtBuff.java
 * @author:David
 **/
package com.xx.dev.modules.battle.model;
/**
 * @class:EnhanceHurtBuff
 * @description:伤害加强BUFF
 * @author:David
 * @version:v1.0
 * @date:2013-4-25
 **/
public class EnhanceHurtBuff extends AbstractBuff {
	
	public EnhanceHurtBuff(int effectBaseValueType,
			double effectBase, int effectValueType, double effect, int startRound,
			int persistRound) {
		super(effectBaseValueType, effectBase, effectValueType, effect, startRound, persistRound);
	}
}

