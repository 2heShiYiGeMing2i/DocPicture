package com.xx.dev.modules.champion.entity;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.apache.commons.lang.StringUtils;
import org.apache.mina.util.ConcurrentHashSet;
import org.codehaus.jackson.type.TypeReference;
import org.hibernate.annotations.Index;

import com.xx.common.db.cache.DbLoadInitializer;
import com.xx.common.db.model.BaseModel;
import com.xx.common.util.JsonUtils;


/**
 * 玩家争霸赛信息
 * 
 * @author bingshan
 */
@Entity
@Table(name = "playerChampion")
public class PlayerChampion extends BaseModel<Long> implements DbLoadInitializer {
	
	private static final long serialVersionUID = -7166454797128951066L;

	/**
	 * 角色ID
	 */
	@Id
	@Column(columnDefinition = "bigint(20) not null comment '角色id'")
	private Long playerId;
	
	/**
	 * 参加争霸赛日期
	 */
	@Index(name="playerChampion_idx_championDay")
	@Column(columnDefinition="varchar(20) default '' comment '参加争霸赛日期'")
	private String championDay = "";
	
	/**
	 * 名次
	 */
	@Column(columnDefinition = "int(11) default '0' comment '名次'")
	private Integer rank = 0;
	
	/**
	 * 奖励是否领取, 0-否  1-是
	 */
	@Column(columnDefinition = "tinyint(2) default '0' comment '奖励是否领取'")
	private Integer rewardStatus = 0;
	
	/**
	 * 奖励信息(奖励串格式)
	 */
	@Column(columnDefinition = "text comment '奖励信息'")
	private String rewards = "";
	
	/**
	 * 支持谁(json)
	 */
	@Column(columnDefinition = "text comment '支持谁(json)'")
	private String supports = "";
	
	/**
	 * supports转化过来
	 */
	@Transient
	private final Set<Long> supportIds = new ConcurrentHashSet<Long>();

	@Override
	public void doAfterLoad() {
		if (StringUtils.isBlank(this.supports)) {
			return;
		}
		
		TypeReference<Set<Long>> valueTypeRef = new TypeReference<Set<Long>>() {};
		Set<Long> ids = JsonUtils.jsonString2Object(this.supports, valueTypeRef);
		if (ids != null && !ids.isEmpty()) {
			this.supportIds.addAll(ids);
		}
	}
		
	public static PlayerChampion valueOf(long playerId) {
		PlayerChampion p = new PlayerChampion();
		p.playerId = playerId;
		return p;
	}

	@Override
	public Long getId() {
		return this.playerId;
	}

	@Override
	public void setId(Long id) {
		this.playerId = id;
	}

	public Long getPlayerId() {
		return playerId;
	}

	public void setPlayerId(Long playerId) {
		this.playerId = playerId;
	}

	public String getChampionDay() {
		return championDay;
	}

	public void setChampionDay(String championDay) {
		this.championDay = championDay;
	}

	public Integer getRank() {
		return rank;
	}

	public void setRank(Integer rank) {
		this.rank = rank;
	}

	public Integer getRewardStatus() {
		return rewardStatus;
	}

	public void setRewardStatus(Integer rewardStatus) {
		this.rewardStatus = rewardStatus;
	}

	public String getRewards() {
		return rewards;
	}

	public void setRewards(String rewards) {
		this.rewards = rewards;
	}

	public String getSupports() {
		return supports;
	}

	public void setSupports(String supports) {
		this.supports = supports;
	}

	public Set<Long> getSupportIds() {
		return supportIds;
	}
	
}
