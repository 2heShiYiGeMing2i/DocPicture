package com.xx.dev.modules.barracks.service.impl;

import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xx.common.basedb.BasedbService;
import com.xx.common.db.cache.DbCachedService;
import com.xx.common.event.EventBus;
import com.xx.common.util.BeanUtil;
import com.xx.common.utility.lock.ChainLock;
import com.xx.common.utility.lock.LockUtils;
import com.xx.dev.constant.GameRuleID;
import com.xx.dev.constant.Lineup;
import com.xx.dev.constant.LogSource;
import com.xx.dev.model.Result;
import com.xx.dev.modules.barracks.entity.PlayerSoldier;
import com.xx.dev.modules.barracks.handler.BarracksResult;
import com.xx.dev.modules.barracks.model.PlayerSoldierDto;
import com.xx.dev.modules.barracks.model.basedb.Barracks;
import com.xx.dev.modules.barracks.model.basedb.SoldierStar;
import com.xx.dev.modules.barracks.service.BarracksService;
import com.xx.dev.modules.building.model.BuildingId;
import com.xx.dev.modules.building.service.BuildingService;
import com.xx.dev.modules.chapter.service.ChapterService;
import com.xx.dev.modules.hero.entity.PlayerBattleLineup;
import com.xx.dev.modules.hero.entity.PlayerHero;
import com.xx.dev.modules.hero.model.HeroAttrSetType;
import com.xx.dev.modules.hero.service.HeroService;
import com.xx.dev.modules.player.entity.Player;
import com.xx.dev.modules.player.model.PlayerAttrType;
import com.xx.dev.modules.player.service.PlayerService;
import com.xx.dev.modules.push.PushHelper;
import com.xx.dev.modules.reward.action.RewardActionSet;
import com.xx.dev.modules.reward.model.Reward;
import com.xx.dev.modules.reward.result.ValueResultSet;
import com.xx.dev.modules.reward.service.RewardService;
import com.xx.dev.modules.server.SessionManager;
import com.xx.dev.modules.task.event.SoldierEvent;
import com.xx.dev.modules.task.event.SoldierRecruitEvent;
import com.xx.dev.modules.task.service.TaskBus;
import com.xx.dev.modules.tech.event.TechUpgradeEvent;
import com.xx.dev.modules.tech.model.TechType;
import com.xx.dev.utils.GameRuleService;

/**
 * 兵营服务接口实现类
 * 
 * @author Along
 *
 */
@Service
public class BarracksServiceImpl implements BarracksService {

	/**
	 * Session管理器
	 */
	@Autowired
	private SessionManager sessionManager;
	
	/**
	 * 缓存服务接口
	 */
	@Autowired
	private DbCachedService dbCachedService;
	
	/**
	 * 基础数据服务接口
	 */
	@Autowired
	private BasedbService basedbService;
	
	/**
	 * 建筑服务接口
	 */
	@Autowired
	private BuildingService buildingService;
	
	/**
	 * 奖励服务接口
	 */
	@Autowired
	private RewardService rewardService;
	
	/**
	 * 游戏规则服务接口
	 */
	@Autowired
	private GameRuleService gameRuleService;
	
	/**
	 * 武将服务接口
	 */
	@Autowired
	private HeroService heroService;
	
	/**
	 * 主公服务接口
	 */
	@Autowired
	private PlayerService playerService;
	
	/**
	 * 副本服务接口
	 */
	@Autowired
	private ChapterService chapterService;
	
	/**
	 * 推送接口
	 */
	@Autowired
	private PushHelper pushHelper;
	
	/**
	 * 事件总线
	 */
	@Autowired
	private EventBus eventBus;
	
	@Autowired
	private TaskBus taskBus;
	
	@Override
	public Result<PlayerSoldierDto> enterAction(long playerId) {
		int barracksLevel = this.buildingService.getBuildingLevel(playerId, BuildingId.BARRACKS);
		if (barracksLevel < 0) {// 兵营未开放
			return Result.Error(BarracksResult.BARRACKS_NO_OPEN);
		}
		PlayerSoldier playerSoldier = this.getPlayerSoldier(playerId);
		PlayerSoldierDto playerSoldierDto = new PlayerSoldierDto();
		BeanUtil.copyProperties(playerSoldier, playerSoldierDto);
		return Result.Success(playerSoldierDto);
	}

	@Override
	public Result<PlayerSoldierDto> recruitSoldiersAction(long playerId, int amount) {
		Player player = this.dbCachedService.get(playerId, Player.class);
		if (player == null) {
			return Result.Error(BarracksResult.FAILURE);
		}
		if (amount <= 0 || amount > 99999999) {// 招募士兵上限
			return Result.Error(BarracksResult.PARAM_ERROR);
		}
		int barracksLevel = this.buildingService.getBuildingLevel(playerId, BuildingId.BARRACKS);
		if (barracksLevel < 0) {
			return Result.Error(BarracksResult.BARRACKS_NO_OPEN);
		}
		PlayerSoldier playerSoldier = this.getPlayerSoldier(playerId);
		if (playerSoldier == null) {
			return Result.Error(BarracksResult.BARRACKS_NO_OPEN);
		}
		ValueResultSet valueResultSet = null;
		ChainLock chainLock = LockUtils.getLock(player);
		chainLock.lock();
		try {
			// 判断是否达到士兵上限
			Barracks barracks = this.basedbService.get(Barracks.class, barracksLevel);
			if (barracks == null) {
				return Result.Error(BarracksResult.BASE_DATA_NOT_EXIST);
			}
			int soldierAmount = playerSoldier.getAmount() + amount;
			if (barracks.getSoldierAmount() < soldierAmount) {// 超过带兵上限
				return Result.Error(BarracksResult.SOLDIER_AMOUNT_LIMIT);
			}
			// 扣减招募消耗
			SoldierStar soldierStar = this.basedbService.get(SoldierStar.class, playerSoldier.getStar());
			if (soldierStar == null) {
				return Result.Error(BarracksResult.BASE_DATA_NOT_EXIST);
			}
			List<Reward> costReward = this.rewardService.parseRewards(playerId, soldierStar.getCostGoods(), true);
			if (CollectionUtils.isEmpty(costReward)) {
				return Result.Error(BarracksResult.FAILURE);
			}
			if (amount > 1) {
				for (Reward reward: costReward) {
					reward.increase(reward.getCount() * (amount - 1));
				}
			}
			RewardActionSet rewardActonSet = this.rewardService.tryRewards(playerId, costReward);
			if (rewardActonSet.isNotOK()) {
				return Result.Error(rewardActonSet.getResultCode());
			}
			valueResultSet = this.rewardService.executeRewards(playerId, rewardActonSet, 
					LogSource.BARRACKS_RECRUIT_SOLDIERS);
			playerSoldier.setAmount(playerSoldier.getAmount() + amount);
			this.dbCachedService.submitUpdated2Queue(playerId, PlayerSoldier.class);
		} finally {
			chainLock.unlock();
		}
		PlayerSoldierDto playerSoldierDto = new PlayerSoldierDto();
		BeanUtil.copyProperties(playerSoldier, playerSoldierDto);
		Result<PlayerSoldierDto> result = Result.Success(playerSoldierDto);
		result.addContent("valueResultSet", valueResultSet);
		
		this.taskBus.post(SoldierEvent.valueOf(playerId));
		this.taskBus.post(SoldierRecruitEvent.valueOf(playerId, playerSoldier.getStar(), amount));
		return result;
	}

	@Override
	public Result<PlayerSoldierDto> disbandSoldiersAction(long playerId, int amount) {
		if (amount <= 0) {
			return Result.Error(BarracksResult.PARAM_ERROR);
		}
		Player player = this.dbCachedService.get(playerId, Player.class);
		if (player == null) {
			return Result.Error(BarracksResult.FAILURE);
		}
		PlayerSoldier playerSoldier = this.getPlayerSoldier(playerId);
		if (playerSoldier == null) {
			return Result.Error(BarracksResult.BARRACKS_NO_OPEN);
		}
		ValueResultSet valueResultSet = null;
		ChainLock chainLock = LockUtils.getLock(player);
		chainLock.lock();
		try {
			if (playerSoldier.getAmount() < amount) {
				return Result.Error(BarracksResult.NO_ENOUGH_SOLDIER_AMOUNT);
			}
			// 返回50%招募消耗
			SoldierStar soldierStar = this.basedbService.get(SoldierStar.class, playerSoldier.getStar());
			if (soldierStar == null) {
				return Result.Error(BarracksResult.BASE_DATA_NOT_EXIST);
			}
			List<Reward> costReward = this.rewardService.parseRewards(playerId, 
					soldierStar.getReturnCostGoods(), true);
			if (CollectionUtils.isEmpty(costReward)) {
				return Result.Error(BarracksResult.FAILURE);
			}
			if (amount > 1) {
				for (Reward reward: costReward) {
					reward.increase(reward.getCount() * (amount - 1));
				}
			}
			RewardActionSet rewardActonSet = this.rewardService.tryRewards(playerId, costReward);
			if (rewardActonSet.isNotOK()) {
				return Result.Error(rewardActonSet.getResultCode());
			}
			valueResultSet = this.rewardService.executeRewards(playerId, rewardActonSet, 
					LogSource.BARRACKS_DISBAND_SOLDIERS);
			playerSoldier.setAmount(playerSoldier.getAmount() - amount);
			this.dbCachedService.submitUpdated2Queue(playerId, PlayerSoldier.class);
		} finally {
			chainLock.unlock();
		}
		PlayerSoldierDto playerSoldierDto = new PlayerSoldierDto();
		BeanUtil.copyProperties(playerSoldier, playerSoldierDto);
		Result<PlayerSoldierDto> result = Result.Success(playerSoldierDto);
		result.addContent("valueResultSet", valueResultSet);
		return result;
	}

	@Override
	public Result<ValueResultSet> upgradeSoldierStarAction(long playerId) {
		Player player = this.dbCachedService.get(playerId, Player.class);
		if (player == null) {
			return Result.Error(BarracksResult.FAILURE);
		}
		PlayerSoldier playerSoldier = this.getPlayerSoldier(playerId);
		if (playerSoldier == null) {
			return Result.Error(BarracksResult.BARRACKS_NO_OPEN);
		}
		ValueResultSet valueResultSet = null;
		ChainLock chainLock = LockUtils.getLock(player);
		chainLock.lock();
		try {
			int barracksLevel = this.buildingService.getBuildingLevel(playerId, BuildingId.BARRACKS);
			SoldierStar oldSoldierStar = this.basedbService.get(SoldierStar.class, playerSoldier.getStar());
			SoldierStar soldierStar = this.basedbService.get(SoldierStar.class, playerSoldier.getStar() + 1);
			if (oldSoldierStar == null || soldierStar == null) {
				return Result.Error(BarracksResult.BASE_DATA_NOT_EXIST);
			}
			if (soldierStar.getBarracksLevel() <= barracksLevel) {// 可以升阶
				List<Reward> costReward = this.rewardService.parseRewards(playerId, 
						soldierStar.getUpgradeCostGoods(), true);
				if (CollectionUtils.isEmpty(costReward)) {
					return Result.Error(BarracksResult.FAILURE);
				}
				RewardActionSet rewardActonSet = this.rewardService.tryRewards(playerId, costReward);
				if (rewardActonSet.isNotOK()) {
					return Result.Error(rewardActonSet.getResultCode());
				}
				valueResultSet = this.rewardService.executeRewards(playerId, rewardActonSet, 
						LogSource.BARRACKS_UPGRADE_SOLDIER_STAR);
				
				// 升级兵
				List<Reward> newCostReward = this.rewardService.parseRewards(playerId, soldierStar.getCostGoods(), true);
				List<Reward> oldCostReward = this.rewardService.parseRewards(playerId, oldSoldierStar.getCostGoods(), true);
				if (CollectionUtils.isEmpty(oldCostReward)) {
					return Result.Error(BarracksResult.FAILURE);
				}
				double rate = 1.0;
				for (Reward reward1 : newCostReward) {
					for (Reward reward2 : oldCostReward) {
						if (reward1.getType() == reward2.getType()) {
							double tmp = (double) reward2.getCount() / reward1.getCount();
							if (tmp < rate) {
								rate = tmp;
							}
						}
					}
				}
				// 升级武将带的兵
				PlayerBattleLineup playerBattleLineup = this.heroService.getPlayerBattleLineup(playerId);
				for (Lineup lineup: Lineup.values()) {
					long heroId = playerBattleLineup.getLineupHero(lineup);
					if (heroId != -1l) {
						PlayerHero playerHero = this.heroService.getPlayerHero(playerId, heroId);
						playerHero.setSoldierAmount((int) Math.ceil(playerHero.getSoldierAmount() * rate));
						this.dbCachedService.submitUpdated2Queue(heroId, PlayerHero.class);
					}
				}
				// 升级兵营的空闲兵
				playerSoldier.setAmount((int) Math.ceil(playerSoldier.getAmount() * rate)); 
				playerSoldier.setStar(playerSoldier.getStar() + 1);
				this.dbCachedService.submitUpdated2Queue(playerId, PlayerSoldier.class);
				
				// 刷新战斗力
				this.heroService.refreshLineupHerosAttr(playerId, HeroAttrSetType.SOLDIER);
				// 刷新玩家属性
				this.playerService.refreshAttr(playerId, PlayerAttrType.HEROS);
				// 推送玩家属性刷新
				this.pushHelper.pushPlayerAttrRefresh(playerId, this.playerService.getPlayerDto(player));
				// 抛科技升级事件(刷新非上阵武将的士兵属性)
				this.eventBus.post(TechUpgradeEvent.valueOf(playerId, TechType.SOLDIER_TECH));
				
				// 推送玩家获得新的兵阶
				this.pushHelper.pushNewSoldierStar(playerId, playerSoldier.getStar());
			} else {
				return Result.Error(BarracksResult.NO_ENOUGH_BARRACKS_LEVEL);
			}
		} finally {
			chainLock.unlock();
		}
		Result<ValueResultSet> result = Result.Success(valueResultSet);
		PlayerSoldierDto playerSoldierDto = new PlayerSoldierDto();
		BeanUtil.copyProperties(playerSoldier, playerSoldierDto);
		result.addContent("playerSoldierDto", playerSoldierDto);
		return result;
	}
	
	@Override
	public int soldiersDisengage(long playerId, int amount) {
		if (amount <= 0) {
			return BarracksResult.PARAM_ERROR;
		}
		Player player = this.dbCachedService.get(playerId, Player.class);
		if (player == null) {
			return BarracksResult.FAILURE;
		}
		int minReduceSoldierLevel = 
				this.gameRuleService.getAmountByID(GameRuleID.HERO_MIN_REDUCE_SOLDIER_LEVEL).intValue();
		int minMissionId = this.gameRuleService.getAmountByID(
				GameRuleID.HERO_MIN_REDUCE_SOLDIER_MISSION_ID).intValue();
		int star = this.chapterService.getMissionStar(playerId, minMissionId);
		if (player.getLevel() < minReduceSoldierLevel && star <= 0) {// 还没达到最小减兵等级，还没打过据点
			return BarracksResult.SUCCESS;
		}
		PlayerSoldier playerSoldier = this.getPlayerSoldier(playerId);
		if (playerSoldier == null) {
			return BarracksResult.BARRACKS_NO_OPEN;
		}
		playerSoldier.setAmount(playerSoldier.getAmount() + amount);
		this.dbCachedService.submitUpdated2Queue(playerId, PlayerSoldier.class);
		return BarracksResult.SUCCESS;
	}

	@Override
	public int soldiersJoinBattle(long playerId, int amount, boolean isFull) {
		if (amount <= 0) {
			return BarracksResult.PARAM_ERROR;
		}
		PlayerSoldier playerSoldier = this.getPlayerSoldier(playerId);
		if (playerSoldier == null) {
			return BarracksResult.BARRACKS_NO_OPEN;
		}
		if (isFull && playerSoldier.getAmount() < amount) {// 士兵数量不足
			return BarracksResult.NO_ENOUGH_SOLDIER_AMOUNT;
		}
		int addAmount = 0;
		if (playerSoldier.getAmount() >= amount) {
			playerSoldier.setAmount(playerSoldier.getAmount() - amount);
			addAmount = amount;
		} else {
			addAmount = playerSoldier.getAmount();
			playerSoldier.setAmount(0);
		}
		this.dbCachedService.submitUpdated2Queue(playerId, PlayerSoldier.class);
		return addAmount;
	}

	/**
	 * 返回玩家的兵
	 * @param playerId 玩家id
	 * @return
	 */
	@Override
	public PlayerSoldier getPlayerSoldier(long playerId) {
		PlayerSoldier result = this.dbCachedService.get(playerId, PlayerSoldier.class);
		if (result == null) {
			result = this.dbCachedService.submitNew2Queue(PlayerSoldier.valueOf(playerId));
		}
		return result;
	}
	
	@Override
	public int getPlayerSoldierAmountLimit(long playerId) {
		int result = 0;
		int barracksLevel = this.buildingService.getBuildingLevel(playerId, BuildingId.BARRACKS);
		if (barracksLevel > 0) {
			Barracks barracks = this.basedbService.get(Barracks.class, barracksLevel);
			if (barracks != null) {
				result = barracks.getSoldierAmount();
			}
		}
		return result;
	}
	
	@Override
	public void initPlayerSoldierAmount(long playerId) {
		PlayerSoldier playerSoldier = this.getPlayerSoldier(playerId);
		if (playerSoldier != null) {
			playerSoldier.setAmount(0);
			this.dbCachedService.submitUpdated2Queue(playerSoldier.getId(), PlayerSoldier.class);
		}
	}

}
