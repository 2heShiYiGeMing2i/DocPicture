package com.xx.dev.modules.armygroup.event;

import com.xx.common.event.Event;

/**
 * 军团科技更新事件
 * 
 * @author Along
 *
 */
public class ArmyGroupTechUpdateEvent {

	/**
	 * 事件名称
	 */
	public static String NAME = "ArmyGroupTech:upgrade";
	
	/**
	 * 玩家id
	 */
	private long id;

	public static Event<ArmyGroupTechUpdateEvent> valueOf(long id) {
		ArmyGroupTechUpdateEvent armyGroupTechUpdateEvent = new ArmyGroupTechUpdateEvent();
		armyGroupTechUpdateEvent.setId(id);
		return new Event<ArmyGroupTechUpdateEvent>(NAME, armyGroupTechUpdateEvent);
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}
	
}
