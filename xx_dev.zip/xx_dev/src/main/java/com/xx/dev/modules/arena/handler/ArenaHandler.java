package com.xx.dev.modules.arena.handler;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.mina.core.session.IoSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.xx.common.db.cache.DbCachedService;
import com.xx.common.socket.handler.RequestProcessor;
import com.xx.common.socket.handler.RequestProcessorAdapter;
import com.xx.common.socket.model.Request;
import com.xx.common.socket.model.Response;
import com.xx.dev.config.Module;
import com.xx.dev.model.Result;
import com.xx.dev.modules.arena.entity.ArenaDayRankReward;
import com.xx.dev.modules.arena.entity.ArenaInfo;
import com.xx.dev.modules.arena.entity.PlayerArena;
import com.xx.dev.modules.arena.model.ArenaTopPlayerDto;
import com.xx.dev.modules.arena.model.DayRankRewardDto;
import com.xx.dev.modules.arena.model.DayRankRewardVO;
import com.xx.dev.modules.arena.model.PlayerArenaDto;
import com.xx.dev.modules.arena.model.PlayerRankDto;
import com.xx.dev.modules.arena.service.ArenaService;
import com.xx.dev.modules.player.entity.Player;
import com.xx.dev.modules.player.model.PlayerDto;
import com.xx.dev.modules.server.SessionManager;
import com.xx.dev.modules.server.handler.HandlerSupport;

/**
 * 竞技场接口实现类
 * 
 * @author bingshan
 */
@Component
public class ArenaHandler extends HandlerSupport {
	
	@Autowired
	private SessionManager sessionManager;
	@Autowired
	private ArenaService arenaService;
	@Autowired
	private DbCachedService dbCachedService;
	
	/**
	 * 模块id
	 */
	private final int module = Module.ARENA;

	@Override
	protected void init() {
		this.registerProcessor(getMyArenaInfo);
		this.registerProcessor(getChallengeList);
		this.registerProcessor(challenge);
		this.registerProcessor(turnCard);
		this.registerProcessor(eliminateCd);
		this.registerProcessor(buyCount);
		this.registerProcessor(fetchBox);
		this.registerProcessor(getRankList);
		this.registerProcessor(getChallengeHisList);
		this.registerProcessor(spy);
		this.registerProcessor(challengeNpc);
		this.registerProcessor(getDayRanks);
		this.registerProcessor(getDayRankReward);
		this.registerProcessor(getBalanceTopPlayer);
	}
	
	/**
	 * 取得本人的竞技场信息
	 */
	private RequestProcessor getMyArenaInfo = new RequestProcessorAdapter(module, ArenaCmd.GET_MY_ARENA_INFO) {
		@Override
		public void process(IoSession session, Request request, Response response) {
			Long playerId = sessionManager.getPlayerId(session);
			PlayerArena playerArena = arenaService.getPlayerArena(playerId);
			PlayerArenaDto dto = PlayerArenaDto.valueOf(playerArena);
			response.setValue(dto);
			session.write(response);
		}
	};
	
	/**
	 * 取得玩家可挑战的玩家信息列表
	 */
	private RequestProcessor getChallengeList = new RequestProcessorAdapter(module, ArenaCmd.GET_CHALLENGE_LIST) {
		@Override
		public void process(IoSession session, Request request, Response response) {
			Long playerId = sessionManager.getPlayerId(session);
			Result<String> result = Result.Success("");
			
			List<PlayerRankDto> playerRankList = arenaService.getChallengeList(playerId);
			result.addContent("playerRankList", playerRankList);
			
			PlayerArena playerArena = arenaService.getPlayerArena(playerId);
			PlayerArenaDto dto = PlayerArenaDto.valueOf(playerArena);
			result.addContent("playerArenaDto", dto);
		
			response.setValue(result);
			session.write(response);
		}		
	};
	
	/**
	 * 发起挑战
	 */
	private RequestProcessor challenge = new RequestProcessorAdapter(module, ArenaCmd.CHALLENGE, Map.class) {
		@SuppressWarnings("unchecked")
		@Override
		public void process(IoSession session, Request request, Response response) {
			Long playerId = sessionManager.getPlayerId(session);
			Map<String, Object> params = (Map<String, Object>) request.getValue();
			Integer rank = (Integer) params.get("rank");
			Result<String> result = arenaService.challenge(playerId, rank);
			response.setValue(result);
			session.write(response);
		}		
	};
	
	/**
	 * 翻牌
	 */
	private RequestProcessor turnCard = new RequestProcessorAdapter(module, ArenaCmd.TURN_CARD, Map.class) {
		@SuppressWarnings("unchecked")
		@Override
		public void process(IoSession session, Request request, Response response) {
			Long playerId = sessionManager.getPlayerId(session);
			Map<String, Object> params = (Map<String, Object>) request.getValue();
			Integer useGold = (Integer) params.get("useGold");
			Result<String> result = arenaService.turnCard(playerId, useGold == 1);
			response.setValue(result);
			session.write(response);
		}		
	};
	
	/**
	 * 消除冷却CD
	 */
	private RequestProcessor eliminateCd = new RequestProcessorAdapter(module, ArenaCmd.ELIMINATE_CD) {
		@Override
		public void process(IoSession session, Request request, Response response) {
			Long playerId = sessionManager.getPlayerId(session);
			Result<String> result = arenaService.eliminateCd(playerId);
			response.setValue(result);
			session.write(response);
		}		
	}; 
	
	/**
	 * 购买次数
	 */
	private RequestProcessor buyCount = new RequestProcessorAdapter(module, ArenaCmd.BUY_COUNT, Map.class) {
		@SuppressWarnings("unchecked")
		@Override
		public void process(IoSession session, Request request, Response response) {
			Long playerId = sessionManager.getPlayerId(session);
			Map<String, Object> params = (Map<String, Object>) request.getValue();
			Integer count = (Integer) params.get("count");
			Result<String> result = arenaService.buyCount(playerId, count);
			response.setValue(result);
			session.write(response);
		}		
	};
	
	/**
	 * 领取宝箱奖励
	 */
	private RequestProcessor fetchBox = new RequestProcessorAdapter(module, ArenaCmd.FETCH_BOX) {
		@Override
		public void process(IoSession session, Request request, Response response) {
			Long playerId = sessionManager.getPlayerId(session);
			Result<String> result = arenaService.fetchBoxReward(playerId);
			response.setValue(result);
			session.write(response);
		}		
	};
	
	/**
	 * 取得排行榜
	 */
	private RequestProcessor getRankList = new RequestProcessorAdapter(module, ArenaCmd.GET_RANK_LIST) {
		@Override
		public void process(IoSession session, Request request, Response response) {
			List<PlayerRankDto> result = arenaService.getRankList();
			response.setValue(result);
			session.write(response);
		}		
	};
	
	/**
	 *取得战斗记录
	 */
	private RequestProcessor getChallengeHisList = new RequestProcessorAdapter(module, ArenaCmd.GET_CHALLENGE_HIS_LIST) {
		@Override
		public void process(IoSession session, Request request, Response response) {
			Long playerId = sessionManager.getPlayerId(session);
			PlayerArena playerArena = arenaService.getPlayerArena(playerId);
			ArenaInfo ai = arenaService.getArenaFirstRankInfo();
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("challenges", playerArena.getChallengeHis());
			map.put("firstRanks", ai.getInfo());
			response.setValue(map);
			session.write(response);
		}		
	};
	
	/**
	 * 侦查玩家阵型
	 */
	private RequestProcessor spy = new RequestProcessorAdapter(module, ArenaCmd.SPY, Map.class) {
		@SuppressWarnings("unchecked")
		@Override
		public void process(IoSession session, Request request, Response response) {
			Long playerId = sessionManager.getPlayerId(session);
			Map<String, Object> params = (Map<String, Object>) request.getValue();
			long spyPlayerId = Long.parseLong(String.valueOf(params.get("playerId")));
			Result<PlayerDto> result = arenaService.spy(playerId, spyPlayerId);
			response.setValue(result);
			session.write(response);
		}		
	};
	
	/**
	 * 挑战NPC
	 */
	private RequestProcessor challengeNpc = new RequestProcessorAdapter(module, ArenaCmd.CHALLENGE_NPC, Map.class) {
		@SuppressWarnings("unchecked")
		@Override
		public void process(IoSession session, Request request, Response response) {
			Long playerId = sessionManager.getPlayerId(session);
			Map<String, Object> params = (Map<String, Object>) request.getValue();
			Integer npcId = (Integer)params.get("npcId");
			Result<String> result = arenaService.challengeNpc(playerId, npcId);
			response.setValue(result);
			session.write(response);
		}		
	};
	
	/**
	 * 取得日排行榜信息
	 */
	private RequestProcessor getDayRanks = new RequestProcessorAdapter(module, ArenaCmd.GET_DAY_RANKS, Map.class) {
		@SuppressWarnings("unchecked")
		@Override
		public void process(IoSession session, Request request, Response response) {
//			Long playerId = sessionManager.getPlayerId(session);
			Map<String, Object> params = (Map<String, Object>) request.getValue();
			List<Integer> days = (List<Integer>)params.get("days");
			
			List<DayRankRewardDto> result = null;
			if (days != null && !days.isEmpty()) {
				result = new ArrayList<DayRankRewardDto> (days.size() * 20);
				for (int day: days) {
					ArenaDayRankReward r = dbCachedService.get(day, ArenaDayRankReward.class);
					if (r == null) {
						continue;
					}
					
					for (DayRankRewardVO dr: r.getRankMap().values()) {
						String playerName = "";
						Player player = dbCachedService.get(dr.getPlayerId(), Player.class);
						if (player != null) {
							playerName = player.getPlayerName();
						}
						DayRankRewardDto d = DayRankRewardDto.valueOf(dr, day, playerName);
						result.add(d);
					}
				}
			}

			response.setValue(result);
			session.write(response);
		}		
	};

	/**
	 * 取得日排行榜奖励
	 */
	private RequestProcessor getDayRankReward = new RequestProcessorAdapter(module, ArenaCmd.GET_DAY_RANK_REWARD, Map.class) {
		@SuppressWarnings("unchecked")
		@Override
		public void process(IoSession session, Request request, Response response) {
			Long playerId = sessionManager.getPlayerId(session);
			Map<String, Object> params = (Map<String, Object>) request.getValue();
			Integer day = (Integer) params.get("day");
			Integer rank = (Integer) params.get("rank");
			Result<String> result = arenaService.getDayRankReward(playerId, day, rank);
			response.setValue(result);
			session.write(response);
		}		
	};
	
	/**
	 * 取得结算第一名玩家信息
	 */
	private RequestProcessor getBalanceTopPlayer = new RequestProcessorAdapter(module, ArenaCmd.GET_BALANCE_TOP_PLAYER) {
		@Override
		public void process(IoSession session, Request request, Response response) {
//			Long playerId = sessionManager.getPlayerId(session);
			long topPlayerId = arenaService.getBalanceTopPlayerId();
			String playerName = "";
			int sex = 0;
			if (topPlayerId > 0L) {
				Player player = dbCachedService.get(topPlayerId, Player.class);
				if (player != null) {
					playerName = player.getPlayerName();
					sex = player.getSex().ordinal();
				}
			}
			
			ArenaTopPlayerDto d = ArenaTopPlayerDto.valueOf(topPlayerId, playerName, sex);
			
			response.setValue(d);
			session.write(response);
		}		
	};
	
}
