/**
 * @file:Battle.java
 * @author:David
 **/
package com.xx.dev.modules.battle.core;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.concurrent.Callable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.xx.dev.constant.BattleType;
import com.xx.dev.constant.CharacterType;
import com.xx.dev.constant.FormulaID;
import com.xx.dev.modules.battle.model.AlliedAttackBuff;
import com.xx.dev.modules.battle.model.BattleAttackType;
import com.xx.dev.modules.battle.model.BattleAttrChanges;
import com.xx.dev.modules.battle.model.BattleAttrType;
import com.xx.dev.modules.battle.model.BattleCharacter;
import com.xx.dev.modules.battle.model.BattleDetail;
import com.xx.dev.modules.battle.model.BattleGroup;
import com.xx.dev.modules.battle.model.BattleReport;
import com.xx.dev.modules.battle.model.BattleResult;
import com.xx.dev.modules.battle.model.BattleRound;
import com.xx.dev.modules.battle.model.BattleSkillEffectInfo;
import com.xx.dev.modules.battle.model.BattleSkillInfo;
import com.xx.dev.modules.battle.model.BattleTargetRange;
import com.xx.dev.modules.battle.model.BattleTeam;
import com.xx.dev.modules.battle.model.BeatBackBuff;
import com.xx.dev.modules.battle.model.BlockBuff;
import com.xx.dev.modules.battle.model.Buff;
import com.xx.dev.modules.battle.model.ComboBuff;
import com.xx.dev.modules.battle.model.ComboTimeBuff;
import com.xx.dev.modules.battle.model.FootContext;
import com.xx.dev.modules.battle.model.SkillEffectDetail;
import com.xx.dev.modules.skill.model.SkillBaseType;
import com.xx.dev.modules.skill.model.SkillEffectTiming;
import com.xx.dev.modules.skill.model.basedb.Skill;
import com.xx.dev.modules.skill.model.basedb.SkillEffect;
import com.xx.dev.modules.skill.skilleffects.AlliedHurtEffect;
import com.xx.dev.modules.skill.skilleffects.BeatBackHurtEffect;
import com.xx.dev.modules.skill.skilleffects.ComboHurtEffect;
import com.xx.dev.modules.skill.skilleffects.Effect;
import com.xx.dev.modules.skill.skilleffects.SkillEffectService;
import com.xx.dev.modules.skill.skilleffects.UnityHurtEffect;
import com.xx.dev.utils.FormulaHelper;
import com.xx.dev.utils.ServiceFactory;

/**
 * @class:Battle
 * @description:战斗实现
 * @author:David
 * @version:v1.0
 * @date:2013-4-19
 **/
public class Battle extends CoreBattle implements Callable<BattleResult>{
	private static final Logger logger = LoggerFactory.getLogger(Battle.class);
	public Battle(BattleType battleType, BattleGroup attackGroup, BattleGroup defendGroup, boolean isReport) {
		super(battleType, attackGroup, defendGroup, isReport);
	}
	/**
	 * @description:处理战斗过程	
	 *
	 */
	private void battleProcess() {
		if(super.getAttackGroup().getAlivePos().isEmpty() || super.getDefendGroup().getAlivePos().isEmpty()){
			//攻方部队还活着且防守方部队已死亡
			if (super.getDefendGroup().getAlivePos().size() == 0) {
				super.innerGetBattleResult().setWinner(BattleWinner.OFFENSE_TEAM);
			} else {
				super.innerGetBattleResult().setWinner(BattleWinner.DEFENSE_TEAM);
			}
			return;
		}
		//战斗初始化
		initBattle();
		//战斗
		doProcess();
		//战斗完成
		endBattle();
	}
	public BattleResult getBattleResult() {
		return call();
	}
	/**
	 * @description:战斗完成
	 *
	 */
	private void endBattle() {
		//失败的一方
		BattleGroup battleGroup = null;
		//攻方部队还活着且防守方部队已死亡
		if (super.getAttackGroup().getAlivePos().size() > 0 && super.getDefendGroup().getAlivePos().size() == 0) {
			super.innerGetBattleResult().setWinner(BattleWinner.OFFENSE_TEAM);
			battleGroup = getDefendGroup();
		} else {
			super.innerGetBattleResult().setWinner(BattleWinner.DEFENSE_TEAM);
			battleGroup = getAttackGroup();
		}
		super.innerGetBattleResult().setCurrRound(getCurrRound());
		if(!battleGroup.getDropResult().isEmpty()){
			super.innerGetBattleResult().setDropResult(battleGroup.getDropResult());
		}
	}
	/**
	 * @description:战斗执行	
	 *
	 */
	private void doProcess() {
		super.increaseCurrround();
		for (super.getCurrRound(); super.getCurrRound() <= getMaxRound(); super.increaseCurrround()) {
			trace("【战斗系统】第 {} 回合", super.getCurrRound());
			
			BattleRound battleRound = addRoundInfo(super.getCurrRound());
			beforBattleRound(battleRound);
			
			BattleReport battleReport = addReportInfo(super.getCurrRound());
			super.setCurBattleReport(battleReport);
			
			//每回合开始技能和状态效果
			fireSkillAndStateEffects(SkillEffectTiming.EVERY_ROUND);
			
			//战斗
			battle();

			
			afterBattleRound(battleRound);
			
			if (isBattleOver()) {
				break;
			}
			
			//每回合结束技能和状态效果
			fireSkillAndStateEffects(SkillEffectTiming.EVERY_ROUND_END);
		}
	}
	/**
	 * @description:战前大回合战报信息补全
	 * @param battleRound
	 */
	private void beforBattleRound(BattleRound battleRound) {
		if(battleRound == null){
			return;
		}
		/** 攻击战斗群体 **/
		BattleGroup attackGroup = getAttackGroup();
		List<BattleCharacter> attackers = attackGroup.getAliveCharacters();
		for (BattleCharacter battleCharacter : attackers) {
			BattleAttrChanges battleAttrChanges = new BattleAttrChanges(battleCharacter);
			battleRound.addAttackChanges(battleAttrChanges);
		}
		/** 防守方战斗群体 **/
		BattleGroup defendGroup = getDefendGroup();
		List<BattleCharacter> defenders = defendGroup.getAliveCharacters();
		for (BattleCharacter battleCharacter : defenders) {
			BattleAttrChanges battleAttrChanges = new BattleAttrChanges(battleCharacter);
			battleRound.addDefendChanges(battleAttrChanges);
		}
	}
	/**
	 * @description:战后大回合战报信息补全
	 * @param battleRound
	 */
	private void afterBattleRound(BattleRound battleRound) {
		if(battleRound == null){
			return;
		}
		/** 攻击战斗群体 **/
		BattleGroup attackGroup = getAttackGroup();
		List<BattleAttrChanges> attackChanges = battleRound.getAttackChanges();
		for (BattleAttrChanges battleAttrChanges : attackChanges) {
			double hpBefore = battleAttrChanges.getCurrHp();
			BattleCharacter battleCharacter = attackGroup.getCharacter(battleAttrChanges.getPos());
			double hpAfter = battleCharacter.getBattleAttr().hp;
			battleAttrChanges.reflush((hpAfter-hpBefore), hpAfter);
		}
		/** 防守方战斗群体 **/
		BattleGroup defendGroup = getDefendGroup();
		List<BattleAttrChanges> defendChanges = battleRound.getDefendChanges();
		for (BattleAttrChanges battleAttrChanges : defendChanges) {
			double hpBefore = battleAttrChanges.getCurrHp();
			BattleCharacter battleCharacter = defendGroup.getCharacter(battleAttrChanges.getPos());
			double hpAfter = battleCharacter.getBattleAttr().hp;
			battleAttrChanges.reflush((hpAfter-hpBefore), hpAfter);
		}
	}
	
	/**
	 * @description:一次回合战斗触发	
	 *
	 */
	private void battle() {
		int maxPos = BattleGroup.MAX_BATTLE_POS;
		//攻方双方当前出战位置
		int attackerPos = BattleGroup.MIN_BATTLE_POS;		
		while (attackerPos <= maxPos){
			attackerPos = doAttack(attackerPos);
			
			if (isBattleOver()) {
				break;
			}
		}
	}
	/**
	 * @description:一次攻击执行	
	 * @param attackerPos 下一个执行攻击的位置
	 * @return
	 */
	private int doAttack(int attackerPos) {
		int nextPos = attackerPos;
		
		BattleCharacter character = super.getAttacker(nextPos);
		if(character != null){
			nextPos = character.getTeamPosition() + 1;
			
			super.increaseAttackRound();
			
			characterAttack(character);
		}else {
			nextPos += 1;
		}
		return nextPos;
	}
	/**
	 * @description:战斗角色执行攻击	
	 * @param character
	 */
	private void characterAttack(BattleCharacter character) {
		//添加战斗细节
		addBattleDetail(character);
		
		//出手前技能和状态效果
		fireSkillAndStateEffects(SkillEffectTiming.BEFORE_ATTACK, character);
		
		if(character.isDie()){
			getBattleGroup(character.getBattleTeam()).removeDeadPos(character.getTeamPosition());
		}else {
			if(!character.isBlock(getCurrRound())){
				getBattleGroup(character.getBattleTeam()).fireAssistSkillEffect(SkillEffectTiming.PARTNER_ATTACK, getCurrRound(), getCurBattleReport(), getSkillEffectConfig(), character);
				attack(character);
			}
			//减少主动技能冷却回合
			character.decrActiveSkillCoolRound();
			//出手后效果
			fireSkillAndStateEffects(SkillEffectTiming.ATTACK_END, character);
		}
	}
	/**
	 * @description:一次攻击释放	
	 * @param character
	 */
	private void attack(BattleCharacter character) {
		SkillEffectTiming timing = SkillEffectTiming.ATTACK;
		BattleAttackType attackType = BattleAttackType.NORMAL_ATTACK;
		//攻击范围
		BattleTargetRange attackRange = BattleTargetRange.DEFAULT;
		//攻击具体位置
		List<Integer> attackPosList = new ArrayList<Integer>();
		//主动技能id
		int activeSkillId = 0;
		//主动技能冷却回合
		int coolRoundOfActiveSkill = 0;
		//主动技能冷却回合 负数
		int leftCoolRoundBefore = 0;
		//释放技能消耗属性 {BattleAttrType:消耗值}
		Map<Integer, Double> costAttr = null;
		//攻击者所在群体
		BattleGroup battleGroup = getBattleGroup(character.getBattleTeam());
		Map<BattleSkillEffectInfo, Effect> effectMap = null;
		BattleSkillInfo battleSkillInfo = character.fireActiveSkill(battleGroup, costAttr);
		if(battleSkillInfo != null){
			Skill skill = battleSkillInfo.getSkill();
			attackRange = skill.getAttackTargetRange();
			boolean flag = buildAttackPosList(character, battleGroup, attackPosList, skill);
			if(flag){// 根据具体技能触发规则,主动技能可能 变成 普通技能
				battleSkillInfo = character.getDefaultSkillInfo();
				skill = battleSkillInfo.getSkill();
				attackRange = skill.getAttackTargetRange();
				buildAttackPosList(character, battleGroup, attackPosList, skill);
			}
			if(skill.getBaseType() == SkillBaseType.ACTIVE_SKILL.ordinal()){
				attackType = BattleAttackType.SKILL_ATTACK;
			}
			effectMap = battleSkillInfo.getEffectList(timing);
			activeSkillId = battleSkillInfo.getSkill().getId();
			coolRoundOfActiveSkill = battleSkillInfo.getLeftCoolRound();
			leftCoolRoundBefore = battleSkillInfo.getLeftCoolRoundBefore();
		}
		//当前攻击结算上下文
		FootContext fcx = new FootContext(getCurrRound(), timing, attackType, character, battleGroup ,attackRange, attackPosList, getCurRoundReport(), getSkillEffectConfig());
		doAttackSec(fcx, effectMap);
		//连击释放
		combo(fcx);
		//反击释放
		beatBack(fcx);
		if(fcx.isKilled()){
			FootContext fContext = new FootContext(getCurrRound(), SkillEffectTiming.KLLLED, BattleAttackType.NONE, character, getBattleGroup(character.getBattleTeam()), BattleTargetRange.DEFAULT, null, getCurBattleReport(), getSkillEffectConfig());
			character.fireAssistSkillEffect(fContext);
			character.fireBuffEffects(getCurrRound(), SkillEffectTiming.KLLLED, getCurBattleReport(), getSkillEffectConfig(), battleGroup);
		}
		//合击释放
		alliedAttack(fcx);
		buildBattleDetails(character, attackType, activeSkillId, coolRoundOfActiveSkill, leftCoolRoundBefore, costAttr);
	}
	/**
	 * @description:一次连击的释放	
	 * @param character
	 */
	private void combo(FootContext fcx) {
		BattleCharacter character = fcx.getAttacker();
		ComboBuff comboBuff = character.getBuff().getComboBuff();
		if(character.isDie()){
			return;
		}else if(comboBuff == null || comboBuff.getPersistRound(fcx.getCurrRound()) <= 0){
			return;
		}
		List<BattleCharacter> list = fcx.getHurtList();
		if(list == null || list.isEmpty()){
			return;
		}
		Collection<ComboTimeBuff> collection = character.getBuff().getComboTimeBuff().values();
		int comboTImes = 0;
		for (ComboTimeBuff comboTimeBuff : collection) {
			if(comboTimeBuff.getPersistRound(fcx.getCurrRound()) > 0){
				comboTImes += (comboTimeBuff.getEffect()+comboTimeBuff.getEffectBase());
			}
		}
		SkillEffectService skillEffectService = ServiceFactory.getSkillEffectService();
		ComboHurtEffect comboHurtEffect = skillEffectService.getComboHurtEffect();
		//战斗角色变化属性集合
		List<BattleAttrChanges> attrChangesList = new ArrayList<BattleAttrChanges>();
		while(comboTImes > 0){
			for (BattleCharacter defender : list) {
				if(defender.isDie()){
					continue;
				}
				double shieldsHpBefore = defender.getShieldsHp();
				double hpBefore = defender.getBattleAttr().hp;
				comboHurtEffect.fireEffect(comboBuff, fcx, defender);
				double hpAfter = defender.getBattleAttr().hp;
				double shieldsHpAfter = defender.getShieldsHp();
				if(fcx.getBattleReport() != null && fcx.getUnityHarm() <= 0){
					BattleAttrChanges attrChanges = new BattleAttrChanges(defender, (hpAfter-hpBefore), hpAfter, fcx.getEffectValue(), (shieldsHpAfter-shieldsHpBefore), shieldsHpAfter);
					attrChangesList.add(attrChanges);
				}
			}
			comboTImes --;
		}
		buildBattleReport(comboBuff.getSkillEffect(), fcx, list, attrChangesList, comboBuff.getPersistRound(fcx.getCurrRound()));
		//团结释放
		unityHarm(fcx);
	}
	/**
	 * @description:反击释放	
	 * @param fcx
	 */
	private void beatBack(FootContext fcx) {
		List<BattleCharacter> list = fcx.getHurtList();
		if(list == null || list.isEmpty()){
			return;
		}
		SkillEffectService skillEffectService = ServiceFactory.getSkillEffectService();
		BeatBackHurtEffect beatBackHurtEffect = skillEffectService.getBeatBackHurtEffect();
		//反击对象
		BattleCharacter attacker = fcx.getAttacker();
		List<SkillEffectDetail> effectList = this.getEffectList(fcx);
		for (BattleCharacter battleCharacter : list) {
			BeatBackBuff beatBackBuff = battleCharacter.getBuff().getBeatBackBuff();
			if(beatBackBuff != null && beatBackBuff.getPersistRound(fcx.getCurrRound()) > 0){
				SkillEffect skillEffect = beatBackBuff.getSkillEffect();
				double shieldsHpBefore = attacker.getShieldsHp();
				double hpBefore = attacker.getBattleAttr().hp;
				beatBackHurtEffect.fireEffect(beatBackBuff, fcx, battleCharacter);
				double hpAfter = attacker.getBattleAttr().hp;
				double shieldsHpAfter = attacker.getShieldsHp();
				if(fcx.getBattleReport() != null){
					BattleAttrChanges attrChanges = new BattleAttrChanges(attacker, (hpAfter-hpBefore), hpAfter, fcx.getEffectValue(), (shieldsHpAfter-shieldsHpBefore), shieldsHpAfter);
					SkillEffectDetail skillEffectDetail = new SkillEffectDetail(skillEffect.getEffectType(), skillEffect.getId(), skillEffect.getAttrType(), battleCharacter.getId(), battleCharacter.getTeamPosition(), beatBackBuff.getPersistRound(fcx.getCurrRound()), attrChanges);
					if (effectList != null) {
						effectList.add(skillEffectDetail);
					}
				}
			}
		}
	}
	/**
	 * @description:合击释放	
	 * @param fcx
	 */
	private void alliedAttack(FootContext fcx) {
		List<BattleCharacter> list = fcx.getHurtList();
		if(list == null || list.isEmpty()){
			return;
		}else if(fcx.getAttacker().isDie()){
			return;
		}
		BattleGroup attackBattleGroup = fcx.getAttackerGroup();
		List<BattleCharacter> attackerList = attackBattleGroup.getAlliedAttacker(getCurrRound(), fcx.getAttacker());
		if(attackerList == null || attackerList.isEmpty()){
			return;
		}
		SkillEffectService skillEffectService = ServiceFactory.getSkillEffectService();
		AlliedHurtEffect alliedHurtEffect = skillEffectService.getAlliedHurtEffect();
		//战斗角色变化属性集合
		List<BattleAttrChanges> attrChangesList = null;
		List<SkillEffectDetail> effectList = this.getEffectList(fcx);
		for (BattleCharacter attacker : attackerList) {
			AlliedAttackBuff alliedAttackBuff = attacker.getBuff().getAlliedAttackBuff();
			SkillEffect skillEffect = alliedAttackBuff.getSkillEffect();
			if(fcx.getBattleReport() != null){
				attrChangesList = new ArrayList<BattleAttrChanges>();
			}
			for (BattleCharacter defender : list) {
				double shieldsHpBefore = defender.getShieldsHp();
				double hpBefore = defender.getBattleAttr().hp;
				alliedHurtEffect.fireEffect(alliedAttackBuff, fcx, attacker, defender);
				double hpAfter = defender.getBattleAttr().hp;
				double shieldsHpAfter = defender.getShieldsHp();
				if(fcx.getBattleReport() != null && fcx.getUnityHarm() <= 0){
					BattleAttrChanges attrChanges = new BattleAttrChanges(defender, (hpAfter-hpBefore), hpAfter, fcx.getEffectValue(), (shieldsHpAfter-shieldsHpBefore), shieldsHpAfter);
					attrChangesList.add(attrChanges);
				}
			}
			if(effectList != null){
				SkillEffectDetail skillEffectDetail = new SkillEffectDetail(skillEffect.getEffectType(), skillEffect.getId(), skillEffect.getAttrType(), attacker.getId(), attacker.getTeamPosition(), alliedAttackBuff.getPersistRound(fcx.getCurrRound()), attrChangesList);
				effectList.add(skillEffectDetail);
				if(fcx.getUnityHarm() > 0){
					fcx.setSkillEffectDetail(skillEffectDetail);
				}
			}
		}
		//团结释放
		unityHarm(fcx);
	}
	/**
	 * @description:团结技能释放	
	 * @param fcx
	 */
	private void unityHarm(FootContext fcx) {
		if(fcx.getUnityHarm() <= 0){
			return;
		}
		List<BattleCharacter> list = fcx.getHurtList();
		if(list == null || list.isEmpty()){
			return;
		}
		//分摊伤害
		double shareHarm = fcx.getUnityHarm() / fcx.getAttackerGroup().getOpposeBattleGroup().getUnityPos().size();
		shareHarm = Math.ceil(shareHarm);
		SkillEffectService skillEffectService = ServiceFactory.getSkillEffectService();
		UnityHurtEffect unityHurtEffect = skillEffectService.getUnityHurtEffect();
		List<BattleCharacter> aliveBattleCharacters = fcx.getAttackerGroup().getOpposeBattleGroup().getAliveCharacters();
		//战斗角色变化属性集合
		List<BattleAttrChanges> attrChangesList = null;
		if(fcx.getBattleReport() != null){
			attrChangesList = new ArrayList<BattleAttrChanges>();
		}
		for (BattleCharacter battleCharacter : aliveBattleCharacters) {
			double shieldsHpBefore = battleCharacter.getShieldsHp();
			double hpBefore = battleCharacter.getBattleAttr().hp;
			unityHurtEffect.fireEffect(shareHarm, fcx, fcx.getAttacker(), battleCharacter);
			double hpAfter = battleCharacter.getBattleAttr().hp;
			double shieldsHpAfter = battleCharacter.getShieldsHp();
			if(fcx.getBattleReport() != null){
				BattleAttrChanges attrChanges = new BattleAttrChanges(battleCharacter, (hpAfter-hpBefore), hpAfter, fcx.getEffectValue(), (shieldsHpAfter-shieldsHpBefore), shieldsHpAfter);
				attrChangesList.add(attrChanges);
			}
		}
		if(fcx.getSkillEffectDetail() != null){
			fcx.getSkillEffectDetail().setUnity(1);
			fcx.getSkillEffectDetail().setAttrChanges(attrChangesList);
			fcx.setSkillEffectDetail(null);
		}
		fcx.setUnityHarm(0);
	}
	/**
	 * @description:连击释放完善回合细节	
	 * @param skillEffect
	 * @param fcx
	 * @param list
	 * @param attrChangesList
	 * @param leftRound
	 */
	private void buildBattleReport(SkillEffect skillEffect, FootContext fcx,
			List<BattleCharacter> list, List<BattleAttrChanges> attrChangesList, int leftRound) {
		if(fcx.getBattleReport() == null){
			return;
		}else if(list == null || list.isEmpty()){
			return;
		}
		BattleCharacter attacker = fcx.getAttacker();
		SkillEffectDetail skillEffectDetail = new SkillEffectDetail(skillEffect.getEffectType(), skillEffect.getId(), skillEffect.getAttrType(), attacker.getId(), attacker.getTeamPosition(), leftRound, attrChangesList);
		if(fcx.getUnityHarm() > 0){
			fcx.setSkillEffectDetail(skillEffectDetail);
		}
		List<SkillEffectDetail> effectList = this.getEffectList(fcx);		
		if (effectList != null) {
			effectList.add(skillEffectDetail);
		}
	}

	private List<SkillEffectDetail> getEffectList(FootContext fcx) {
		if(fcx.getBattleReport() == null){
			return null;
		}
		if(SkillEffectTiming.BEFORE_ATTACK.equals(fcx.getTiming()) || SkillEffectTiming.EVERY_ROUND.equals(fcx.getTiming())){
			return fcx.getBattleReport().getInitEffects();
		}
		BattleDetail battleDetail = fcx.getBattleReport().loadBattleDetail(fcx.getAttacker().getTeamPosition());
		if(battleDetail == null){
			return null;
		}
		return battleDetail.getEffectDetails();
	}
	/**
	 * @description:攻击释放	
	 * @param fcx 一次结算上下文对象 
	 * @param effectMap 主动技能效果
	 */
	private void doAttackSec(FootContext fcx, Map<BattleSkillEffectInfo, Effect> effectMap) {
		if(effectMap == null || effectMap.isEmpty()){
			return;
		}
		Set<Entry<BattleSkillEffectInfo, Effect>> entries = effectMap.entrySet();
		List<Entry<BattleSkillEffectInfo, Effect>> effectEntries = new ArrayList<Map.Entry<BattleSkillEffectInfo,Effect>>();
		effectEntries.addAll(entries);
		sortEffect(effectEntries);
		for (Entry<BattleSkillEffectInfo, Effect> entry : effectEntries) {
			BattleSkillEffectInfo battleSkillEffectInfo = entry.getKey();
			Effect effect = entry.getValue();
			effect.doEffect(battleSkillEffectInfo, fcx);
		}
		//团结释放
		unityHarm(fcx);
	}
	
	/**
	 * @description:释放效果排序，技能ID或者效果ID小的优先释放	
	 * @param effectEntries
	 */
	private void sortEffect(List<Entry<BattleSkillEffectInfo, Effect>> effectEntries) {
		Collections.sort(effectEntries, new Comparator<Entry<BattleSkillEffectInfo, Effect>>() {
			@Override
			public int compare(Entry<BattleSkillEffectInfo, Effect> o1, Entry<BattleSkillEffectInfo, Effect> o2) {
				if (o1.getKey().getSkill().getId() < o2.getKey().getSkill().getId()) {
					return -1;
				}
				if (o1.getKey().getSkill().getId() > o2.getKey().getSkill().getId()) {
					return 1;
				}
				if (o1.getKey().getSkillEffect().getId() < o2.getKey().getSkillEffect().getId()) {
					return -1;
				}
				if (o1.getKey().getSkillEffect().getId() > o2.getKey().getSkillEffect().getId()) {
					return 1;
				}
				return 1;
			}
		
		});
	}
	
	/**
	 * @description:增加回合细节到一次结算上下文中
	 * @param fcx
	 * @param attackerId
	 * @param attackType
	 * @param activeSkillId
	 * @param coolRoundOfActiveSkill
	 * @param costAttr
	 */
	private void buildBattleDetails(BattleCharacter battleCharacter, BattleAttackType attackType, int activeSkillId, int coolRoundOfActiveSkill, int leftCoolRoundBefore, Map<Integer, Double> costAttr){
		BattleReport battleReport = getCurBattleReport();
		if(battleReport != null){
			BattleDetail battleDetail = battleReport.loadBattleDetail(battleCharacter.getTeamPosition());
			if(battleDetail != null){
				battleDetail.setAttackType(attackType.ordinal());
				battleDetail.setActiveSkillId(activeSkillId);
				battleDetail.setCoolRoundOfActiveSkill(coolRoundOfActiveSkill);
				battleDetail.setLeftCoolRoundBefore(leftCoolRoundBefore);
				if(costAttr != null){
					double costDander = costAttr.get(BattleAttrType.DANDER)!=null?costAttr.get(BattleAttrType.DANDER):0;
					battleDetail.setCostDander(costDander);
				}
				battleDetail.setHp(battleCharacter.getBattleAttr().hp);
				battleDetail.setDander(getBattleGroup(battleCharacter.getBattleTeam()).getDander());
			}
		}
	}
	/**
	 * @description:根据攻击范围生成具体的攻击位置
	 * @param character
	 * @param battleGroup
	 * @param battleSkillInfo
	 * @param attackRange
	 * @param attackPosList
	 * @param skill
	 * @return
	 */
	public static boolean buildAttackPosList(BattleCharacter character, BattleGroup battleGroup, List<Integer> attackPosList, Skill skill) {
		//当前技能是否能成功释放，具体规则
		boolean flag = false;
		switch (skill.getAttackTargetRange()) {
		case ALL:
			BattleGroup defendGroup = battleGroup.getOpposeBattleGroup();
			attackPosList.addAll(defendGroup.getAlivePos());
			return flag;
		case FRONT_BACK:
			defendGroup = battleGroup.getOpposeBattleGroup();
			int[] defendPos = getDefensePos(battleGroup.getBattleTeam());
			int middlePos = defendPos.length >> 1;
			for (int i = 0; i < middlePos; i++) {
				if(defendGroup.isAlive(defendPos[i])){
					attackPosList.add(defendPos[i]);
				}
			}
			if(attackPosList == null || attackPosList.isEmpty()){
				for (int i = middlePos; i < defendPos.length; i++) {
					if(defendGroup.isAlive(defendPos[i])){
						attackPosList.add(defendPos[i]);
					}
				}
			}
			if(attackPosList == null || attackPosList.isEmpty()){
				flag = true;
			}
			return flag;
		case FRONT:
			defendGroup = battleGroup.getOpposeBattleGroup();
			defendPos = getDefensePos(battleGroup.getBattleTeam());
			middlePos = defendPos.length >> 1;
			for (int i = 0; i < middlePos; i++) {
				if(defendGroup.isAlive(defendPos[i])){
					attackPosList.add(defendPos[i]);
				}
			}
			if(attackPosList == null || attackPosList.isEmpty()){
				flag = true;
			}
			return flag;
		case BACK:
			defendGroup = battleGroup.getOpposeBattleGroup();
			defendPos = getDefensePos(battleGroup.getBattleTeam());
			middlePos = defendPos.length >> 1;
			for (int i = middlePos; i < defendPos.length; i++) {
				if(defendGroup.isAlive(defendPos[i])){
					attackPosList.add(defendPos[i]);
				}
			}
			if(attackPosList == null || attackPosList.isEmpty()){
				flag = true;
			}
			return flag;
		case CROSS:
			defendGroup = battleGroup.getOpposeBattleGroup();
			defendPos = getCrossPos(character.getTeamPosition());
			for (int i = 0; i < defendPos.length; i++) {
				if(defendGroup.isAlive(defendPos[i])){
					attackPosList.add(defendPos[i]);
				}
			}
			if(attackPosList == null || attackPosList.isEmpty()){
				flag = true;
			}
			return flag;
		case RANDOM2:
			defendGroup = battleGroup.getOpposeBattleGroup();
			if(defendGroup.getAlivePos().size() <= 2){
				List<Integer> alivePos = defendGroup.getAlivePos();
				for (int i = 0; i < alivePos.size(); i++) {
					attackPosList.add(alivePos.get(i));
				}
			}else {
				List<Integer> newAlivePos = new ArrayList<Integer>(defendGroup.getAlivePos());
				Collections.shuffle(newAlivePos);
				for (int i = 0; i < newAlivePos.size(); i++) {
					if(attackPosList.size() >= 2){
						 break;
					}
					attackPosList.add(newAlivePos.get(i));
				}
			}
			break;
		case RANDOM3:
			defendGroup = battleGroup.getOpposeBattleGroup();
			if(defendGroup.getAlivePos().size() <= 3){
				List<Integer> alivePos = defendGroup.getAlivePos();
				for (int i = 0; i < alivePos.size(); i++) {
					attackPosList.add(alivePos.get(i));
				}
			}else {
				List<Integer> newAlivePos = new ArrayList<Integer>(defendGroup.getAlivePos());
				Collections.shuffle(newAlivePos);
				for (int i = 0; i < newAlivePos.size(); i++) {
					if(attackPosList.size() >= 3){
						 break;
					}
					attackPosList.add(newAlivePos.get(i));
				}
			}
			break;
		case TARGET_LINE:
			defendGroup = battleGroup.getOpposeBattleGroup();
			defendPos = getLinePos(character.getTeamPosition());
			for (int i = 0; i < defendPos.length; i++) {
				if(defendGroup.isAlive(defendPos[i])){
					attackPosList.add(defendPos[i]);
				}
			}
			if(attackPosList == null || attackPosList.isEmpty()){
				int[] effect_pos;
				if(character.getBattleTeam().equals(BattleTeam.OFFENSE_TEAM)){
					effect_pos = BattleRule.OFFENSE_POS;
				}else {
					effect_pos = BattleRule.DEFENSE_POS;
				}
				for (int pos : effect_pos) {
					defendPos = getLinePos(pos);
					for (int i = 0; i < defendPos.length; i++) {
						if(defendGroup.isAlive(defendPos[i])){
							attackPosList.add(defendPos[i]);
						}
					}
					if(!attackPosList.isEmpty()){
						break;
					}
				}
				if(attackPosList == null || attackPosList.isEmpty()){
					flag = true;
				}
			}
			return flag;
		case LINE:
			defendGroup = battleGroup.getOpposeBattleGroup();
			defendPos = getLinePos(character.getTeamPosition());
			for (int i = 0; i < defendPos.length; i++) {
				if(defendGroup.isAlive(defendPos[i])){
					attackPosList.add(defendPos[i]);
				}
			}
			if(attackPosList == null || attackPosList.isEmpty()){
				flag = true;
			}
			return flag;
		case SELF_ALL:
			attackPosList.addAll(battleGroup.getAlivePos());
			return flag;
		case SELF_SOME:
			int[] attackInfo = skill.getAttackTargetPos();
			if(attackInfo==null || attackInfo.length != 1){
				trace("【战斗系统】技能{} 攻击范围出错", skill.getId());
			}
			attackPosList.addAll(battleGroup.getAliveHpLimit(attackInfo[0]));
			if(attackPosList == null || attackPosList.isEmpty()){
				flag = true;
			}
			return flag;
		case SELF_ONE:
			attackInfo = skill.getAttackTargetPos();
			attackPosList.addAll(battleGroup.getAliveHpLimit(1));
			if(attackPosList == null || attackPosList.isEmpty()){
				flag = true;
			}
			return flag;
		case TARGET_VOCATION:
			defendGroup = battleGroup.getOpposeBattleGroup();
			attackInfo = skill.getAttackTargetPos();
			if(attackInfo==null || attackInfo.length == 0){
				trace("【战斗系统】技能{} 职业范围出错", skill.getId());
			}
			attackPosList.addAll(defendGroup.getAliveVocation(attackInfo));
			if(attackPosList == null || attackPosList.isEmpty()){
				flag = true;
			}
			return flag;
		case SELF_VOCATION:
			attackInfo = skill.getAttackTargetPos();
			if(attackInfo==null || attackInfo.length == 0){
				trace("【战斗系统】技能{} 职业范围出错", skill.getId());
			}
			attackPosList.addAll(battleGroup.getAliveVocation(attackInfo));
			if(attackPosList == null || attackPosList.isEmpty()){
				flag = true;
			}
			return flag;
		case TARGET_ARMY:
			defendGroup = battleGroup.getOpposeBattleGroup();
			attackInfo = skill.getAttackTargetPos();
			if(attackInfo==null || attackInfo.length == 0){
				trace("【战斗系统】技能{} 特定兵种范围出错", skill.getId());
			}
			attackPosList.addAll(defendGroup.getAliveArmyType(attackInfo));
			if(attackPosList == null || attackPosList.isEmpty()){
				flag = true;
			}
			return flag;
		case SELF_ARMY:
			attackInfo = skill.getAttackTargetPos();
			if(attackInfo==null || attackInfo.length == 0){
				trace("【战斗系统】技能{} 特定兵种范围出错", skill.getId());
			}
			attackPosList.addAll(battleGroup.getAliveArmyType(attackInfo));
			if(attackPosList == null || attackPosList.isEmpty()){
				flag = true;
			}
			return flag;
		case TARGET_SOME_ARMY:
			defendGroup = battleGroup.getOpposeBattleGroup();

			attackInfo = skill.getAttackTargetPos();
			if(attackInfo==null || attackInfo.length != 1){
				trace("【战斗系统】技能{} 攻击范围出错", skill.getId());
			}
			attackPosList.addAll(defendGroup.getAliveHpLimit(attackInfo[0]));
			if(attackPosList == null || attackPosList.isEmpty()){
				flag = true;
			}
			return flag;
		case TARGET_TOP_ARMY:
			defendGroup = battleGroup.getOpposeBattleGroup();

			attackInfo = skill.getAttackTargetPos();
			if(attackInfo==null || attackInfo.length != 1){
				trace("【战斗系统】技能{} 攻击范围出错", skill.getId());
			}
			attackPosList.addAll(defendGroup.getAliveHpTopLimit(attackInfo[0]));
			if(attackPosList == null || attackPosList.isEmpty()){
				flag = true;
			}
			return flag;
		case BACK_SINGLE:
			//优先攻击对位目标
			defendGroup = battleGroup.getOpposeBattleGroup();
			defendPos = getBackSinglePos(character.getTeamPosition());
			for (int i = 0; i < defendPos.length; i++) {
				if(defendGroup.isAlive(defendPos[i])){
					attackPosList.add(defendPos[i]);
					break;
				}
			}
			if(attackPosList == null || attackPosList.isEmpty()){
				flag = true;
			}
			return flag;
		case SELF_RANDOM:
			attackInfo = skill.getAttackTargetPos();
			if(attackInfo==null || attackInfo.length != 1){
				trace("【战斗系统】技能{} 攻击范围出错", skill.getId());
			}
			List<Integer> newAlivePos = new ArrayList<Integer>(battleGroup.getAlivePos());
			Collections.shuffle(newAlivePos);
			
			for (int i = 0; i < newAlivePos.size(); i++) {
				if(attackPosList.size() >= attackInfo[0]){
					 break;
				}
				attackPosList.add(newAlivePos.get(i));
			}
			break;
		default:
			break;
		}
		return flag;
	}
	public static void main(String[] args) {
		int[] defense_pos = BattleRule.DEFENSE_POS;
		int middlePos = defense_pos.length >> 1;
		for (int i = middlePos; i < defense_pos.length; i++) {
			System.out.println(defense_pos[i]);
		}
		
	}
	/**
	 * @description:施放某个时间点某战斗单位的技能和状态效果效果
	 * @param effectTiming SkillEffectTiming
	 * @param character BattleCharacter
	 */
	private void fireSkillAndStateEffects(SkillEffectTiming effectTiming,BattleCharacter character) {
		FootContext fcx = new FootContext(getCurrRound(), effectTiming, BattleAttackType.NONE, character, super.getBattleGroup(character.getBattleTeam()), BattleTargetRange.DEFAULT ,null, getCurBattleReport(), getSkillEffectConfig());
		character.fireAssistSkillEffect(fcx);
		character.fireBuffEffects(getCurrRound(), effectTiming, getCurBattleReport(), getSkillEffectConfig(), character.getBattleGroup());
	}

	/**
	 * @description:添加战斗细节	
	 * @param character 所属玩家
	 */
	private BattleDetail addBattleDetail(BattleCharacter character) {
		BattleDetail battleDetail = null;
		BattleReport battleReport = getCurBattleReport();
		if(battleReport != null){
			battleDetail = new BattleDetail(character);
			battleReport.addBattleDetail(battleDetail);
		}
		return battleDetail;
	}

	/**
	 * 战斗是否结束
	 * @return true/false
	 */
	private boolean isBattleOver() {
		return super.getAttackGroup().isDead() || super.getDefendGroup().isDead();
	}
	/**
	 * @description:战斗开始	
	 */
	private void initBattle() {
		//添加回合战报
		BattleReport battleReport = addReportInfo(super.getCurrRound());
		super.setCurBattleReport(battleReport);
		//整场战斗初始技能和状态效果
		fireSkillAndStateEffects(SkillEffectTiming.BATTLE_INIT);
		//释放军威技能
		fireJunWeiSkillEffects();
	}
	/**
	 * @description:释放军威技能	
	 *
	 */
	private void fireJunWeiSkillEffects() {
		CharacterType pvp = CharacterType.PLAYER;
		if(super.getAttackGroup().getCharacterType().equals(pvp) && super.getDefendGroup().getCharacterType().equals(pvp)){
			List<BattleCharacter> list = null;
			int armyCount = 0;
			int cdRound = 0;
			int attackJunWeiLevel = super.getAttackGroup().getJunWeiLevel();
			int defendJunWeiLevel = super.getDefendGroup().getJunWeiLevel();
			FormulaHelper formulaHelper = ServiceFactory.getFormulaHelper();
			BattleTeam junWeiTeam = null;
			if(attackJunWeiLevel > defendJunWeiLevel){//防守方被眩晕
				junWeiTeam = BattleTeam.OFFENSE_TEAM;
				armyCount = formulaHelper.invoke(FormulaID.JUNWEI_COUNT, (attackJunWeiLevel-defendJunWeiLevel)).intValue();
				cdRound = formulaHelper.invoke(FormulaID.JUNWEI_CD).intValue();
				list = super.getDefendGroup().getAliveCharacters(armyCount);
			}else if(defendJunWeiLevel > attackJunWeiLevel){//攻击方被眩晕
				junWeiTeam = BattleTeam.DEFENSE_TEAM;
				armyCount = formulaHelper.invoke(FormulaID.JUNWEI_COUNT, (defendJunWeiLevel-attackJunWeiLevel)).intValue();;
				cdRound = formulaHelper.invoke(FormulaID.JUNWEI_CD).intValue();
				list = super.getAttackGroup().getAliveCharacters(armyCount);
			}
			if(list != null && !list.isEmpty()){
				Map<Long, Integer> junWeiMap = new HashMap<Long, Integer>();
				for (BattleCharacter battleCharacter : list) {
					Buff buff = battleCharacter.getBuff();
					BlockBuff blockBuff = new BlockBuff(getCurrRound(), cdRound);
					buff.setBlockBuff(blockBuff);
					
					junWeiMap.put(battleCharacter.getId(), cdRound);
				}
				if(getCurBattleReport() != null){
					getCurBattleReport().setJunWeiMap(junWeiMap);
					getCurBattleReport().setJunWeiTeam(junWeiTeam);
				}
			}
		}
	}
	/**
	 * @description:添加回合战报实体	
	 *
	 */
	private BattleReport addReportInfo(int currRound) {
		if(innerGetBattleResult().getBattleReports() != null){
			BattleReport battleReport = new BattleReport(currRound);
			super.innerGetBattleResult().addBattleReport(battleReport);
			return battleReport;
		}
		return null;
	}
	/**
	 * @description:添加大回合战报实体
	 */
	private BattleRound addRoundInfo(int currRound) {
		if(innerGetBattleResult().getBattleRounds() != null){
			BattleRound battleRound = new BattleRound(currRound);
			super.innerGetBattleResult().addBattleRound(battleRound);
			return battleRound;
		}
		return null;
	}
	/**
	 * 施放某个时间点双方部队的技能和状态效果效果
	 * @param effectTiming SkillEffectTiming
	 */
	private void fireSkillAndStateEffects(SkillEffectTiming effectTiming) {
		
		super.getAttackGroup().fireAssistSkillEffect(effectTiming, super.getCurrRound(), getCurRoundReport(), getSkillEffectConfig());
		super.getDefendGroup().fireAssistSkillEffect(effectTiming, super.getCurrRound(), getCurRoundReport(), getSkillEffectConfig());
		
		super.getAttackGroup().fireBuffEffect(effectTiming, super.getCurrRound(), getCurRoundReport(), getSkillEffectConfig());
		super.getDefendGroup().fireBuffEffect(effectTiming, super.getCurrRound(), getCurRoundReport(), getSkillEffectConfig());
	}
	
	/**
	 * 得到当前回合战报对象
	 */
	private BattleReport getCurRoundReport(){
		return super.getCurBattleReport();
	}
	
	/**
	 * debug日志信息
	 * @param format 格式
	 * @param param 参数
	 */
	private static void trace(String format, Object... param) {
		if (logger.isDebugEnabled()) {
			logger.debug(format, param);
		}
	}
	
	@Override
	public BattleResult call(){
		battleProcess();
		return innerGetBattleResult();
	}
}

