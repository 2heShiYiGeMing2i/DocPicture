package com.xx.dev.modules.bejeweled.model;

import org.codehaus.jackson.annotate.JsonIgnore;

/**
 * Created by LiangZengle on 2014/6/18.
 */
public class Goal {
    /**
     * 目标方块: 1-6
     */
    private int value;

    /**
     * 目标个数
     */
    private int count;

    /**
     * 已消除的个数
     */
    private int eliminated;

    public static Goal valueOf(int value, int count) {
        Goal goal = new Goal();
        goal.setValue(value);
        goal.setCount(count);
        return goal;
    }

    @JsonIgnore
    public boolean isCompleted() {
        return eliminated >= count;
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public int getEliminated() {
        return eliminated;
    }

    public void setEliminated(int eliminated) {
        this.eliminated = eliminated;
    }
}
