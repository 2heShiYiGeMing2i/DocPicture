package com.xx.dev.model;

import java.io.Serializable;
import java.util.List;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.codehaus.jackson.annotate.JsonIgnore;

import com.xx.dev.constant.AttrTypeId;
import com.xx.dev.modules.armygroup.model.basedb.ArmyGroupTechUpgrade;
import com.xx.dev.modules.barracks.model.basedb.Soldier;
import com.xx.dev.modules.battle.model.BattleAttr;
import com.xx.dev.modules.battle.model.BattleAttrType;
import com.xx.dev.modules.divination.model.DivinationType;
import com.xx.dev.modules.divination.model.basedb.Divination;
import com.xx.dev.modules.divination.model.basedb.DivinationAttr;
import com.xx.dev.modules.divination.model.basedb.DivinationLevelAttr;
import com.xx.dev.modules.drill.model.DrillTechId;
import com.xx.dev.modules.drill.model.basedb.DrillUpgrade;
import com.xx.dev.modules.equip.model.basedb.Equip;
import com.xx.dev.modules.hero.model.basedb.HeroConfig;
import com.xx.dev.modules.hero.model.basedb.HeroTalentSkill;
import com.xx.dev.modules.hero.model.basedb.PlayerTalentAddAttr;
import com.xx.dev.modules.herocollect.model.basedb.HeroCollect;
import com.xx.dev.modules.heroequip.model.HeroEquipAddAttrType;
import com.xx.dev.modules.heroequip.model.HeroEquipSuitAttrType;
import com.xx.dev.modules.heroequip.model.basedb.HeroEquip;
import com.xx.dev.modules.heroequip.model.basedb.HeroEquipSuitAttr;
import com.xx.dev.modules.heroequip.model.basedb.JewelLevelAttr;
import com.xx.dev.modules.horse.model.basedb.HorseConfig;
import com.xx.dev.modules.item.model.SubItemType;
import com.xx.dev.modules.item.model.basedb.Item;
import com.xx.dev.modules.player.model.basedb.PlayerJob;
import com.xx.dev.modules.tech.model.basedb.TechUpgrade;
import com.xx.dev.modules.totem.model.basedb.TotemConfig;
import com.xx.dev.modules.totem.model.basedb.TotemSoul;
import com.xx.dev.modules.totem.model.basedb.TotemSpirit;
import com.xx.dev.modules.training.model.TrainingAttrType;
import com.xx.dev.modules.training.model.basedb.TrainingAttr;

/**
 * 角色一级属性
 * 
 * @author Along
 *
 */
public class RoleAttr implements Serializable {

	private static final long serialVersionUID = 7330602713226539186L;

	/**
	 * 武力
	 */
	private double power;
	
	/**
	 * 智力
	 */
	private double brains;
	
	/**
	 * 魅力
	 */
	private double charm;
	
	/**
	 * 技能威力
	 */
	private double skillPower;
	
	/**
	 * 统率
	 */
	private double command;
	
	/**
	 * 步兵相性
	 */
	private double walker;
	
	/**
	 * 骑兵相性
	 */
	private double rider;
	
	/**
	 * 弓兵相性
	 */
	private double archer;
	
	/**
	 * 策士相性
	 */
	private double magician;
	
	/**
	 * 辎重相性
	 */
	private double supply;
	
	/**
	 * 战斗属性（二级属性）
	 */
	private BattleAttr battleAttr;
	
	public RoleAttr() {
		battleAttr = new BattleAttr();
	}

	@JsonIgnore
	public RoleAttr(double power, double brains, double charm, double skillPower,
			double command, double walker, double rider, double archer,
			double magician, double supply, BattleAttr battleAttr) {
		battleAttr = new BattleAttr();
		this.power = power;
		this.brains = brains;
		this.charm = charm;
		this.skillPower = skillPower;
		this.command = command;
		this.walker = walker;
		this.rider = rider;
		this.archer = archer;
		this.magician = magician;
		this.supply = supply;
		this.battleAttr = battleAttr;
	}
	
	/**
	 * 武将属性
	 * @param heroConfig 武将
	 * @param level 武将等级
	 */
	@JsonIgnore
	public RoleAttr(HeroConfig heroConfig, int level) {
		battleAttr = new BattleAttr();
		this.power = heroConfig.getPower(level);
		this.brains = heroConfig.getBrains(level);
		this.charm = heroConfig.getCharm(level);
		this.skillPower = heroConfig.getSkillPower(level);
		this.command = heroConfig.getCommand(level);
	}
	
	/**
	 * 武将天赋技能属性
	 * @param heroTalentSkill 武将天赋技能
	 * @param talentSkillLevel 天赋技能等
	 */
	@JsonIgnore
	public RoleAttr(HeroTalentSkill heroTalentSkill, int talentSkillLevel) {
		battleAttr = new BattleAttr();
		this.power = heroTalentSkill.getPower(talentSkillLevel);
		this.brains = heroTalentSkill.getBrains(talentSkillLevel);
		this.charm = heroTalentSkill.getCharm(talentSkillLevel);
		this.skillPower = heroTalentSkill.getSkillPower(talentSkillLevel);
		this.command = heroTalentSkill.getCommand(talentSkillLevel);
		this.battleAttr.add(BattleAttrType.ATTACK, heroTalentSkill.getAttack(talentSkillLevel));
		this.battleAttr.add(BattleAttrType.DEFEND, heroTalentSkill.getDefend(talentSkillLevel));
		this.battleAttr.add(BattleAttrType.STRATEGYATTACK, heroTalentSkill.getStrategyAttack(talentSkillLevel));
		this.battleAttr.add(BattleAttrType.STRATEGYDEFEND, heroTalentSkill.getStrategyDefend(talentSkillLevel));
	}
	
	/**
	 * 武将装备属性
	 * @param heroEquip 武将装备
	 * @param level 武将装备等级
	 */
	@JsonIgnore
	public RoleAttr(HeroEquip heroEquip, int level) {
		battleAttr = new BattleAttr();
		this.power = heroEquip.getPower(level);
		this.brains = heroEquip.getBrains(level);
		this.charm = heroEquip.getCharm(level);
		this.skillPower = heroEquip.getSkillPower(level);
		this.command = heroEquip.getCommand(level);
		
		this.battleAttr.add(BattleAttrType.ATTACK, heroEquip.getAttack(level));
		this.battleAttr.add(BattleAttrType.DEFEND, heroEquip.getDefend(level));
		this.battleAttr.add(BattleAttrType.STRATEGYATTACK, heroEquip.getStrategyAttack(level));
		this.battleAttr.add(BattleAttrType.STRATEGYDEFEND, heroEquip.getStrategyDefend(level));
		this.battleAttr.add(BattleAttrType.CRIT, heroEquip.getCrit(level));
		this.battleAttr.add(BattleAttrType.RESIST, heroEquip.getResist(level));
		this.battleAttr.add(BattleAttrType.NONE, heroEquip.getCommandAmount(level));
		this.battleAttr.add(BattleAttrType.SKILLDEFEND, heroEquip.getSkillDefend(level));
	}
	
	/**
	 * 主公属性
	 * @param playerJob 主公官职
	 */
	@JsonIgnore
	public RoleAttr(PlayerJob playerJob) {
		battleAttr = new BattleAttr();
		this.power = playerJob.getAddedPower();
		this.brains = playerJob.getAddedBrains();
		this.charm = playerJob.getAddedCharm();
		this.skillPower = playerJob.getAddedSkillPower();
		this.command = playerJob.getAddedCommander();
	}
	
	/**
	 * 士兵属性
	 * @param soldier 士兵
	 * @param soldierAmount 士兵数量
	 */
	@JsonIgnore
	public RoleAttr(Soldier soldier, int soldierAmount) {
		battleAttr = new BattleAttr();
		this.battleAttr = new BattleAttr(soldier.getAttack(), soldier.getDefend(), 
				soldier.getStrategyAttack(), soldier.getStrategyDefend(), 
				soldier.getCrit(), soldier.getResist(), 0.0, 
				soldier.getHp()*soldierAmount, 0.0);
	}
	
	/**
	 * 武将科技属性
	 * @param powerTech 物理科技
	 * @param brainsTech 智力科技
	 * @param charmTech 魅力科技
	 * @param skillPowerTech 技能威力科技
	 * @param commandTech 统帅科技
	 */
	@JsonIgnore
	public RoleAttr(TechUpgrade powerTech, TechUpgrade brainsTech, 
			TechUpgrade charmTech, TechUpgrade skillPowerTech,	
			TechUpgrade commandTech) {
		battleAttr = new BattleAttr();
		if (powerTech != null) {
			this.power = powerTech.getValue();
		}
		if (brainsTech != null) {
			this.brains = brainsTech.getValue();
		}
		if (charmTech != null) {
			this.charm = charmTech.getValue();
		}
		if (skillPowerTech != null) {
			this.skillPower = skillPowerTech.getValue();
		}
		if (commandTech != null) {
			this.command = commandTech.getValue();
		}
	}
	
	/**
	 * 士兵科技属性
	 * @param attackTech 物攻科技
	 * @param defendTech 物防科技
	 * @param strategyAttackTech 策攻科技
	 * @param strategyDefendTech 策放科技
	 * @param critTech 暴击科技
	 * @param resistTech 格挡科技
	 */
	@JsonIgnore
	public RoleAttr(TechUpgrade attackTech, TechUpgrade defendTech, TechUpgrade strategyAttackTech,
			TechUpgrade strategyDefendTech, TechUpgrade critTech, TechUpgrade resistTech) {
		battleAttr = new BattleAttr();
		double attack = 0.0;
		if (attackTech != null) {
			attack = attackTech.getValue();
		}
		double defend = 0.0;
		if (defendTech != null) {
			defend = defendTech.getValue();
		}
		double strategyAttack = 0.0;
		if (strategyAttackTech != null) {
			strategyAttack = strategyAttackTech.getValue();
		}
		double strategyDefend = 0.0;
		if (strategyDefendTech != null) {
			strategyDefend = strategyDefendTech.getValue();
		}
		double crit = 0.0;
		if (critTech != null) {
			crit = critTech.getValue();
		}
		double resist = 0.0;
		if (resistTech != null) {
			resist = resistTech.getValue();
		}
		this.battleAttr = new BattleAttr(attack, defend, strategyAttack, 
				strategyDefend, crit, resist, 0.0, 0.0, 0.0);
	}
	
	/**
	 * 军阵科技属性
	 * @param drillUpgrade 军阵升级对象
	 */
	@JsonIgnore
	public RoleAttr(DrillUpgrade drillUpgrade) {
		battleAttr = new BattleAttr();
		double attack = 0.0;
		double defend = 0.0;
		double strategyAttack = 0.0;
		double strategyDefend = 0.0;
		double crit = 0.0;
		double resist = 0.0;
		double skillPower = 0.0;
		
		switch (drillUpgrade.getTechId()) {
		case DrillTechId.TIAN_FU:
			attack += drillUpgrade.getValue();
			break;
			
		case DrillTechId.DI_ZAI:
			defend += drillUpgrade.getValue();
			break;
			
		case DrillTechId.FENG_YANG:
			strategyAttack += drillUpgrade.getValue();
			break;
			
		case DrillTechId.LONG_FEI:
			attack += drillUpgrade.getValue();
			strategyAttack += drillUpgrade.getValue();
			break;
			
		case DrillTechId.YUN_CHUI:
			strategyDefend += drillUpgrade.getValue();
			break;
			
		case DrillTechId.HU_YI:
			defend += drillUpgrade.getValue();
			strategyDefend += drillUpgrade.getValue();
			break;
			
		case DrillTechId.NIAO_XIANG:
			skillPower += drillUpgrade.getValue();
			break;
			
		case DrillTechId.SHE_PAN:
			crit += drillUpgrade.getValue();
			resist += drillUpgrade.getValue();
			break;

		default:
			break;
		}
		
		this.battleAttr = new BattleAttr(attack, defend, strategyAttack, 
				strategyDefend, crit, resist, skillPower, 0.0, 0.0);
	}
	
	/**
	 * 宝石附加的战斗属性（1+宝石共鸣属性加成）
	 * @param item 宝石道具
	 * @param attrAddRate 属性加成比例
	 * @return
	 */
	@JsonIgnore
	public RoleAttr add(Item item, double attrAddRate) {
		if (item != null) {
			double addAttr = item.getActionValue() * (1 + attrAddRate);
			switch (item.getSubItemType()) {
			case SubItemType.ATTACK_STONE:
				this.battleAttr.add(BattleAttrType.ATTACK, addAttr);
				break;

			case SubItemType.DEFEND_STONE:
				this.battleAttr.add(BattleAttrType.DEFEND, addAttr);
				break;
				
			case SubItemType.STRATEGY_ATTACK_STONE:
				this.battleAttr.add(BattleAttrType.STRATEGYATTACK, addAttr);
				break;
				
			case SubItemType.STRATEGY_DEFEND_STONE:
				this.battleAttr.add(BattleAttrType.STRATEGYDEFEND, addAttr);
				break;
				
			case SubItemType.CRIT_STONE:
				this.battleAttr.add(BattleAttrType.CRIT, addAttr);
				break;
				
			case SubItemType.RESIST_STONE:
				this.battleAttr.add(BattleAttrType.RESIST, addAttr);
				break;
				
			case SubItemType.COMMAND_STONE:
				this.battleAttr.add(BattleAttrType.NONE, addAttr);
				break;
				
			default:
				break;
			}
		}
		return this;
	}
	
	/**
	 * 命签附加的战斗属性
	 * @param divination 命签基础数据
	 * @param divinationAttr 命签附加属性
	 * @return
	 */
	@JsonIgnore
	public RoleAttr add(Divination divination, DivinationAttr divinationAttr) {
		if (divinationAttr != null) {
			switch (divination.getTypeId()) {
			case DivinationType.ATTACK:
				this.battleAttr.add(BattleAttrType.ATTACK, divinationAttr.getValue());
				break;

			case DivinationType.DEFEND:
				this.battleAttr.add(BattleAttrType.DEFEND, divinationAttr.getValue());
				break;
				
			case DivinationType.STRATEGY_ATTACK:
				this.battleAttr.add(BattleAttrType.STRATEGYATTACK, divinationAttr.getValue());
				break;
				
			case DivinationType.STRATEGY_DEFEND:
				this.battleAttr.add(BattleAttrType.STRATEGYDEFEND, divinationAttr.getValue());
				break;
				
			case DivinationType.CRIT:
				this.battleAttr.add(BattleAttrType.CRIT, divinationAttr.getValue());
				break;
				
			case DivinationType.RESIST:
				this.battleAttr.add(BattleAttrType.RESIST, divinationAttr.getValue());
				break;
				
			case DivinationType.COMMAND_AMOUNT:
				this.battleAttr.add(BattleAttrType.NONE, divinationAttr.getValue());
				break;
				
			default:
				break;
			}
		}
		return this;
	}
	
	/**
	 * 军团科技属性
	 * @param powerTech 武力科技
	 * @param brainsTech 智力科技
	 * @param charmTech 魅力科技
	 * @param skillPowerTech 技能威力科技
	 * @param commandTech 统帅科技
	 */
	@JsonIgnore
	public RoleAttr(ArmyGroupTechUpgrade powerTech, ArmyGroupTechUpgrade brainsTech, 
			ArmyGroupTechUpgrade charmTech, ArmyGroupTechUpgrade skillPowerTech,	
			ArmyGroupTechUpgrade commandTech) {
		battleAttr = new BattleAttr();
		if (powerTech != null) {
			this.power = powerTech.getValue();
		}
		if (brainsTech != null) {
			this.brains = brainsTech.getValue();
		}
		if (charmTech != null) {
			this.charm = charmTech.getValue();
		}
		if (skillPowerTech != null) {
			this.skillPower = skillPowerTech.getValue();
		}
		if (commandTech != null) {
			this.command = commandTech.getValue();
		}
	}
	
	/**
	 * 武将装备附加属性
	 * @param heroEquipAddAttrType 武将装备的附加属性类型
	 * @param value 附加属性的值
	 */
	@JsonIgnore
	public void add(HeroEquipAddAttrType heroEquipAddAttrType, double value) {
		switch (heroEquipAddAttrType) {
		case ATTACK:
			this.battleAttr.add(BattleAttrType.ATTACK, value);
			break;

		case DEFEND:
			this.battleAttr.add(BattleAttrType.DEFEND, value);
			break;
			
		case STRATEGY_ATTACK:
			this.battleAttr.add(BattleAttrType.STRATEGYATTACK, value);
			break;
			
		case STRATEGY_DEFEND:
			this.battleAttr.add(BattleAttrType.STRATEGYDEFEND, value);
			break;
			
		case CRIT:
			this.battleAttr.add(BattleAttrType.CRIT, value);
			break;
			
		case RESIST:
			this.battleAttr.add(BattleAttrType.RESIST, value);
			break;
			
		case SKILLPOWER:
			this.battleAttr.add(BattleAttrType.SKILLPOWER, value);
			break;
			
		case COMMAND_AMOUNT:
			this.battleAttr.add(BattleAttrType.NONE, value);
			break;
			
		case WALKER:
			this.addWalker(value);
			break;
			
		case RIDER:
			this.addRider(value);
			break;
			
		case MAGICIAN:
			this.addMagician(value);
			break;
			
		case SUPPLY:
			this.addSupply(value);
			break;
			
		case ARCHER:
			this.addArcher(value);
			break;
			
		default:
			break;
		}
	}
	
	/**
	 * 武将装备套装附加的属性
	 * @param heroEquipSuitAttr 武将装备套装属性
	 */
	@JsonIgnore
	public void add(HeroEquipSuitAttr heroEquipSuitAttr) {
		switch (heroEquipSuitAttr.getAttrType()) {
		case HeroEquipSuitAttrType.ATTACK:
			this.battleAttr.add(BattleAttrType.ATTACK, heroEquipSuitAttr.getAttrValue());
			break;

		case HeroEquipSuitAttrType.DEFEND:
			this.battleAttr.add(BattleAttrType.DEFEND, heroEquipSuitAttr.getAttrValue());
			break;
			
		case HeroEquipSuitAttrType.STRATEGY_ATTACK:
			this.battleAttr.add(BattleAttrType.STRATEGYATTACK, heroEquipSuitAttr.getAttrValue());
			break;
			
		case HeroEquipSuitAttrType.STRATEGY_DEFEND:
			this.battleAttr.add(BattleAttrType.STRATEGYDEFEND, heroEquipSuitAttr.getAttrValue());
			break;
			
		case HeroEquipSuitAttrType.CRIT:
			this.battleAttr.add(BattleAttrType.CRIT, heroEquipSuitAttr.getAttrValue());
			break;
			
		case HeroEquipSuitAttrType.RESIST:
			this.battleAttr.add(BattleAttrType.RESIST, heroEquipSuitAttr.getAttrValue());
			break;
			
		case HeroEquipSuitAttrType.SKILLPOWER:
			this.battleAttr.add(BattleAttrType.SKILLPOWER, heroEquipSuitAttr.getAttrValue());
			break;
			
		case HeroEquipSuitAttrType.COMMAND_AMOUNT:
			this.battleAttr.add(BattleAttrType.NONE, heroEquipSuitAttr.getAttrValue());
			break;
			
		case HeroEquipSuitAttrType.WALKER:
			this.addWalker(heroEquipSuitAttr.getAttrValue());
			break;
			
		case HeroEquipSuitAttrType.RIDER:
			this.addRider(heroEquipSuitAttr.getAttrValue());
			break;
			
		case HeroEquipSuitAttrType.MAGICIAN:
			this.addMagician(heroEquipSuitAttr.getAttrValue());
			break;
			
		case HeroEquipSuitAttrType.SUPPLY:
			this.addSupply(heroEquipSuitAttr.getAttrValue());
			break;
			
		case HeroEquipSuitAttrType.ARCHER:
			this.addArcher(heroEquipSuitAttr.getAttrValue());
			break;
			
		case HeroEquipSuitAttrType.POWER:
			this.addPower(heroEquipSuitAttr.getAttrValue());
			break;
			
		case HeroEquipSuitAttrType.BRAINS:
			this.addBrains(heroEquipSuitAttr.getAttrValue());
			break;
			
		case HeroEquipSuitAttrType.CHARM:
			this.addCharm(heroEquipSuitAttr.getAttrValue());
			break;
			
		case HeroEquipSuitAttrType.COMMAND:
			this.addCommand(heroEquipSuitAttr.getAttrValue());
			break;
			
		default:
			break;
		}
	}
	
	/**
	 * Buff药水附加的属性
	 * @param buffItems Buff道具列表
	 */
	@JsonIgnore
	public RoleAttr(List<Item> buffItems) {
		battleAttr = new BattleAttr();
		if (CollectionUtils.isNotEmpty(buffItems)) {
			for (Item item: buffItems) {
				switch (item.getSubItemType()) {
				case SubItemType.POWER_LIQUID:
					this.addPower(item.getActionValue());
					break;

				case SubItemType.BRAINS_LIQUID:
					this.addBrains(item.getActionValue());
					break;
					
				case SubItemType.CHARM_LIQUID:
					this.addCharm(item.getActionValue());
					break;
					
				case SubItemType.COMMAND_LIQUID:
					this.addCommand(item.getActionValue());
					break;
					
				case SubItemType.SKILLPOWER_LIQUID:
					this.addSkillPower(item.getActionValue());
					break;
					
				default:
					break;
				}
			}
		}
	}
	
	/**
	 * 猛将录的附加属性
	 * @param heroCollects 猛将录列表
	 */
	@JsonIgnore
	public RoleAttr(Set<HeroCollect> heroCollects) {
		battleAttr = new BattleAttr();
		if (CollectionUtils.isNotEmpty(heroCollects)) {
			for (HeroCollect heroCollect: heroCollects) {
				this.addPower(heroCollect.getAddedPower());
				this.addCharm(heroCollect.getAddedCharm());
				this.addBrains(heroCollect.getAddedBrains());
				this.addCommand(heroCollect.getAddedCommander());
				this.addSkillPower(heroCollect.getAddedSkillPower());
			}
		}
	}
	
	/**
	 * 宝石共鸣附加的属性
	 * @param jewelLevelAttr
	 */
	@JsonIgnore
	public RoleAttr(JewelLevelAttr jewelLevelAttr) {
		battleAttr = new BattleAttr();
		this.power = jewelLevelAttr.getAddedPower();
		this.brains = jewelLevelAttr.getAddedBrains();
		this.charm = jewelLevelAttr.getAddedCharm();
		this.skillPower = jewelLevelAttr.getAddedSkillPower();
		this.command = jewelLevelAttr.getAddedCommand();
		
		this.battleAttr.add(BattleAttrType.ATTACK, jewelLevelAttr.getAddedAttack());
		this.battleAttr.add(BattleAttrType.DEFEND, jewelLevelAttr.getAddedDefend());
		this.battleAttr.add(BattleAttrType.STRATEGYATTACK, jewelLevelAttr.getAddedStrategyAttack());
		this.battleAttr.add(BattleAttrType.STRATEGYDEFEND, jewelLevelAttr.getAddedStrategyDefend());
		this.battleAttr.add(BattleAttrType.CRIT, jewelLevelAttr.getAddedCrit());
		this.battleAttr.add(BattleAttrType.RESIST, jewelLevelAttr.getAddedResist());
		this.battleAttr.add(BattleAttrType.NONE, jewelLevelAttr.getAddedCommandAmount());
	}
	
	/**
	 * 主公天赋属性加成
	 * @param playerTalentAddAttr
	 */
	@JsonIgnore
	public RoleAttr(PlayerTalentAddAttr playerTalentAddAttr) {
		battleAttr = new BattleAttr();
		this.power = playerTalentAddAttr.getAddedPower();
		this.brains = playerTalentAddAttr.getAddedBrains();
		this.charm = playerTalentAddAttr.getAddedCharm();
		this.skillPower = playerTalentAddAttr.getAddedSkillPower();
		this.command = playerTalentAddAttr.getAddedCommand();
		
		this.battleAttr.add(BattleAttrType.ATTACK, playerTalentAddAttr.getAddedAttack());
		this.battleAttr.add(BattleAttrType.DEFEND, playerTalentAddAttr.getAddedDefend());
		this.battleAttr.add(BattleAttrType.STRATEGYATTACK, playerTalentAddAttr.getAddedStrategyAttack());
		this.battleAttr.add(BattleAttrType.STRATEGYDEFEND, playerTalentAddAttr.getAddedStrategyDefend());
		this.battleAttr.add(BattleAttrType.CRIT, playerTalentAddAttr.getAddedCrit());
		this.battleAttr.add(BattleAttrType.RESIST, playerTalentAddAttr.getAddedResist());
		this.battleAttr.add(BattleAttrType.NONE, playerTalentAddAttr.getAddedCommandAmount());
	}
	
	/** 
	 * 图腾的附加属性
	 * @param totemConfig 图腾基础数据
	 * @param totemSpirit 灵附加的属性
	 * @param totemSoul 魂附加的属性
	 */
	@JsonIgnore
	public RoleAttr(TotemConfig totemConfig, TotemSpirit totemSpirit,
			TotemSoul totemSoul) {
		battleAttr = new BattleAttr();
		// 图腾基础属性
		this.battleAttr.add(BattleAttrType.ATTACK, totemConfig.getAttack());
		this.battleAttr.add(BattleAttrType.DEFEND, totemConfig.getDefend());
		this.battleAttr.add(BattleAttrType.STRATEGYATTACK, totemConfig.getStrategyAttack());
		this.battleAttr.add(BattleAttrType.STRATEGYDEFEND, totemConfig.getStrategyDefend());
		this.battleAttr.add(BattleAttrType.CRIT, totemConfig.getCrit());
		this.battleAttr.add(BattleAttrType.RESIST, totemConfig.getResist());
		this.battleAttr.add(BattleAttrType.SKILLPOWER, totemConfig.getSkillPower());
		this.battleAttr.add(BattleAttrType.SKILLDEFEND, totemConfig.getSkillDefend());
		this.battleAttr.add(BattleAttrType.NONE, totemConfig.getCommandAmount());
		
		// 龙魂之魂增加的属性
		if (totemSoul != null) {
			this.battleAttr.add(BattleAttrType.ATTACK, totemSoul.getAttack());
			this.battleAttr.add(BattleAttrType.DEFEND, totemSoul.getDefend());
			this.battleAttr.add(BattleAttrType.STRATEGYATTACK, totemSoul.getStrategyAttack());
			this.battleAttr.add(BattleAttrType.STRATEGYDEFEND, totemSoul.getStrategyDefend());
			this.battleAttr.add(BattleAttrType.CRIT, totemSoul.getCrit());
			this.battleAttr.add(BattleAttrType.RESIST, totemSoul.getResist());
			this.battleAttr.add(BattleAttrType.SKILLPOWER, totemSoul.getSkillPower());
			this.battleAttr.add(BattleAttrType.SKILLDEFEND, totemSoul.getSkillDefend());
			this.battleAttr.add(BattleAttrType.NONE, totemSoul.getCommandAmount());
		}
		
		// 龙魂之灵增加的属性
		if (totemSpirit != null) {
			this.battleAttr.add(BattleAttrType.ATTACK, totemConfig.getAttack() * totemSpirit.getAddedRate());
			this.battleAttr.add(BattleAttrType.DEFEND, totemConfig.getDefend() * totemSpirit.getAddedRate());
			this.battleAttr.add(BattleAttrType.STRATEGYATTACK, totemConfig.getStrategyAttack() * totemSpirit.getAddedRate());
			this.battleAttr.add(BattleAttrType.STRATEGYDEFEND, totemConfig.getStrategyDefend() * totemSpirit.getAddedRate());
			this.battleAttr.add(BattleAttrType.CRIT, totemConfig.getCrit() * totemSpirit.getAddedRate());
			this.battleAttr.add(BattleAttrType.RESIST, totemConfig.getResist() * totemSpirit.getAddedRate());
			this.battleAttr.add(BattleAttrType.SKILLPOWER, totemConfig.getSkillPower() * totemSpirit.getAddedRate());
			this.battleAttr.add(BattleAttrType.SKILLDEFEND, totemConfig.getSkillDefend() * totemSpirit.getAddedRate());
			this.battleAttr.add(BattleAttrType.NONE, totemConfig.getCommandAmount() * totemSpirit.getAddedRate());
		}
	}
	
	/**
	 * 主公装备属性
	 * @param equip 主公装备
	 */
	@JsonIgnore
	public RoleAttr(Equip equip) {
		battleAttr = new BattleAttr();
		this.power = equip.getInitPower();
		this.brains = equip.getInitBrains();
		this.charm = equip.getInitCharm();
		this.command = equip.getInitCommand();
		this.skillPower = equip.getInitSkillPower();
		
		this.battleAttr.add(BattleAttrType.SKILLPOWER, equip.getInitSkillPower());
		this.battleAttr.add(BattleAttrType.SKILLDEFEND, equip.getInitSkillDefend());
	}
	
	/**
	 * 练兵技能的属性
	 * @param trainingSkillAttr 练兵技能属性
	 */
	@JsonIgnore
	public RoleAttr(TrainingAttr trainingSkillAttr) {
		battleAttr = new BattleAttr();
		if (trainingSkillAttr != null && trainingSkillAttr.getAttrType() > 0) {
			switch (trainingSkillAttr.getAttrType()) {
			case TrainingAttrType.ATTACK:
				this.battleAttr.add(BattleAttrType.ATTACK, trainingSkillAttr.getAttrValue());
				break;

			case TrainingAttrType.DEFEND:
				this.battleAttr.add(BattleAttrType.DANDER, trainingSkillAttr.getAttrValue());
				break;
				
			case TrainingAttrType.STRATEGY_ATTACK:
				this.battleAttr.add(BattleAttrType.STRATEGYATTACK, trainingSkillAttr.getAttrValue());
				break;
				
			case TrainingAttrType.STRATEGY_DEFEND:
				this.battleAttr.add(BattleAttrType.STRATEGYDEFEND, trainingSkillAttr.getAttrValue());
				break;
				
			case TrainingAttrType.CRIT:
				this.battleAttr.add(BattleAttrType.CRIT, trainingSkillAttr.getAttrValue());
				break;
				
			case TrainingAttrType.RESIST:
				this.battleAttr.add(BattleAttrType.RESIST, trainingSkillAttr.getAttrValue());
				break;
				
			case TrainingAttrType.COMMAND_AMOUNT:
				this.battleAttr.add(BattleAttrType.NONE, trainingSkillAttr.getAttrValue());
				break;

			default:
				break;
			}
		}
	}
	
	/**
	 * 坐骑的属性
	 * @param horseConfig
	 */
	@JsonIgnore
	public RoleAttr(HorseConfig horseConfig) {
		battleAttr = new BattleAttr();
		this.power = horseConfig.getPower();
		this.brains = horseConfig.getBrains();
		this.charm = horseConfig.getCharm();
		this.command = horseConfig.getCommand();
		this.skillPower = horseConfig.getSkillPower();
	}

	/**
	 * 命签等级附加的属性
	 * @param divinationLevelAttr
	 */
	@JsonIgnore
	public RoleAttr(DivinationLevelAttr divinationLevelAttr) {
		battleAttr = new BattleAttr();
		this.power = divinationLevelAttr.getAddedPower();
		this.brains = divinationLevelAttr.getAddedBrains();
		this.charm = divinationLevelAttr.getAddedCharm();
		this.skillPower = divinationLevelAttr.getAddedSkillPower();
		this.command = divinationLevelAttr.getAddedCommand();
		
		this.battleAttr.add(BattleAttrType.ATTACK, divinationLevelAttr.getAddedAttack());
		this.battleAttr.add(BattleAttrType.DEFEND, divinationLevelAttr.getAddedDefend());
		this.battleAttr.add(BattleAttrType.STRATEGYATTACK, divinationLevelAttr.getAddedStrategyAttack());
		this.battleAttr.add(BattleAttrType.STRATEGYDEFEND, divinationLevelAttr.getAddedStrategyDefend());
		this.battleAttr.add(BattleAttrType.CRIT, divinationLevelAttr.getAddedCrit());
		this.battleAttr.add(BattleAttrType.RESIST, divinationLevelAttr.getAddedResist());
		this.battleAttr.add(BattleAttrType.NONE, divinationLevelAttr.getAddedCommandAmount());
	}
	
	/**
	 * 武将装附魔属性
	 * @param attrTypeId 属性类型id
	 * @param value 属性的值
	 */
	@JsonIgnore
	public void add(int attrTypeId, int value) {
		switch (attrTypeId) {
		case AttrTypeId.ATTACK:
			this.battleAttr.add(BattleAttrType.ATTACK, value);
			break;

		case AttrTypeId.DEFEND:
			this.battleAttr.add(BattleAttrType.DEFEND, value);
			break;
			
		case AttrTypeId.STRATEGY_ATTACK:
			this.battleAttr.add(BattleAttrType.STRATEGYATTACK, value);
			break;
			
		case AttrTypeId.STRATEGY_DEFEND:
			this.battleAttr.add(BattleAttrType.STRATEGYDEFEND, value);
			break;
			
		case AttrTypeId.CRIT:
			this.battleAttr.add(BattleAttrType.CRIT, value);
			break;
			
		case AttrTypeId.RESIST:
			this.battleAttr.add(BattleAttrType.RESIST, value);
			break;
			
		case AttrTypeId.SKILLPOWER:
			this.battleAttr.add(BattleAttrType.SKILLPOWER, value);
			break;
			
		case AttrTypeId.COMMAND_AMOUNT:
			this.battleAttr.add(BattleAttrType.NONE, value);
			break;
			
		case AttrTypeId.SKILLDEFEND:
			this.battleAttr.add(BattleAttrType.SKILLDEFEND, value);
			break;
			
		default:
			break;
		}
	}
	
	@JsonIgnore
	public RoleAttr add(RoleAttr attr) {
		if (attr != null) {
			this.archer += attr.archer;
			this.brains += attr.brains;
			this.charm += attr.charm;
			this.command += attr.command;
			this.magician += attr.magician;
			this.power += attr.power;
			this.rider += attr.rider;
			this.skillPower += attr.skillPower;
			this.supply += attr.supply;
			this.walker += attr.walker;
			this.battleAttr.add(attr.battleAttr);
		}
		return this;
	}
	
	
	@JsonIgnore
	public void addPower(double power) {
		this.power += power;
	}
	
	@JsonIgnore
	public void addBrains(double brains) {
		this.brains += brains;
	}
	
	@JsonIgnore
	public void addCharm(double charm) {
		this.charm += charm;
	}
	
	@JsonIgnore
	public void addCommand(double command) {
		this.command += command;
	}
	
	@JsonIgnore
	public void addSkillPower(double skillPower) {
		this.skillPower += skillPower;
	}
	
	@JsonIgnore
	public void addRider(double rider) {
		this.rider += rider;
	}
	
	@JsonIgnore
	public void addSupply(double supply) {
		this.supply += supply;
	}
	
	@JsonIgnore
	public void addWalker(double walker) {
		this.walker += walker;
	}
	
	@JsonIgnore
	public void addArcher(double archer) {
		this.archer += archer;
	}

	@JsonIgnore
	public void addMagician(double magician) {
		this.magician += magician;
	}
	
	public double getPower() {
		return power;
	}

	public void setPower(double power) {
		this.power = power;
	}

	public double getBrains() {
		return brains;
	}

	public void setBrains(double brains) {
		this.brains = brains;
	}

	public double getCharm() {
		return charm;
	}

	public void setCharm(double charm) {
		this.charm = charm;
	}

	public double getSkillPower() {
		return skillPower;
	}

	public void setSkillPower(double skillPower) {
		this.skillPower = skillPower;
	}

	public double getCommand() {
		return command;
	}

	public void setCommand(double command) {
		this.command = command;
	}

	public double getWalker() {
		return walker;
	}

	public void setWalker(double walker) {
		this.walker = walker;
	}

	public double getRider() {
		return rider;
	}

	public void setRider(double rider) {
		this.rider = rider;
	}

	public double getArcher() {
		return archer;
	}

	public void setArcher(double archer) {
		this.archer = archer;
	}

	public double getMagician() {
		return magician;
	}

	public void setMagician(double magician) {
		this.magician = magician;
	}

	public double getSupply() {
		return supply;
	}

	public void setSupply(double supply) {
		this.supply = supply;
	}

	public BattleAttr getBattleAttr() {
		return battleAttr;
	}

	public void setBattleAttr(BattleAttr battleAttr) {
		this.battleAttr = battleAttr;
	}
	
}
