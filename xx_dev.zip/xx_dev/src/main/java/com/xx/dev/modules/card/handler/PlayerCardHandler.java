package com.xx.dev.modules.card.handler;

import java.util.Map;

import org.apache.mina.core.session.IoSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xx.common.socket.handler.RequestProcessor;
import com.xx.common.socket.handler.RequestProcessorAdapter;
import com.xx.common.socket.model.Request;
import com.xx.common.socket.model.Response;
import com.xx.dev.config.Module;
import com.xx.dev.model.Result;
import com.xx.dev.modules.card.model.PlayerCardDto;
import com.xx.dev.modules.card.service.PlayerCardService;
import com.xx.dev.modules.server.SessionManager;
import com.xx.dev.modules.server.handler.HandlerSupport;

/**
 * 月卡处理接口
 * @author jy
 *
 */
@Service
public class PlayerCardHandler extends HandlerSupport{

	private int module = Module.PLAYER_CARD;
	
	@Autowired
	private SessionManager sessionManager;
	
	@Autowired
	private PlayerCardService playerCardService;
	
	@Override
	protected void init() {
		registerProcessor(getPlayerCardInfo);
		registerProcessor(openPlayerCard);
		registerProcessor(getPower);
		//registerProcessor(finishFJTX);
		registerProcessor(getBuffer);
	}

	private RequestProcessor getPlayerCardInfo = new RequestProcessorAdapter(module, PlayerCardCmd.GET_PLAYER_CARD_INFO) {
		@Override
		public void process(IoSession session, Request request, Response response) {
			
			long playerId = sessionManager.getPlayerId(session);
			
			Result<PlayerCardDto> result = playerCardService.getPlayerCardInfo(playerId);
			
			response.setValue(result);
			
			session.write(response);
		}
	};
	
	private RequestProcessor openPlayerCard = new RequestProcessorAdapter(module, PlayerCardCmd.OPEN_PLAYER_CARD, Map.class) {
		@SuppressWarnings("unchecked")
		@Override
		public void process(IoSession session, Request request, Response response) {
			
			long playerId = sessionManager.getPlayerId(session);
			
			Map<String, Object> params = (Map<String, Object>) request.getValue();
			
			int num = (Integer)params.get("num");
			
			Result<PlayerCardDto> result = playerCardService.openPlayerCardWithGold(playerId, num);
			
			response.setValue(result);
			
			session.write(response);
		}
	};
	
	
	private RequestProcessor getPower = new RequestProcessorAdapter(module, PlayerCardCmd.GET_POWER) {
		@Override
		public void process(IoSession session, Request request, Response response) {
			
			long playerId = sessionManager.getPlayerId(session);
			
			Result<PlayerCardDto> result = playerCardService.getEnergy(playerId);
			
			response.setValue(result);
			
			session.write(response);
		}
	};
	
//	private RequestProcessor finishFJTX = new RequestProcessorAdapter(module, PlayerCardCmd.FINISH_FJTX_TASKS) {
//		@Override
//		public void process(IoSession session, Request request, Response response) {
//			
//			long playerId = sessionManager.getPlayerId(session);
//			
//			Result<PlayerCardDto> result = playerCardService.finishFJTX(playerId);
//			
//			response.setValue(result);
//			
//			session.write(response);
//		}
//	};
	
	private RequestProcessor getBuffer = new RequestProcessorAdapter(module, PlayerCardCmd.GET_DAILY_BUFFER) {
		@Override
		public void process(IoSession session, Request request, Response response) {
			
			long playerId = sessionManager.getPlayerId(session);
			
			Result<PlayerCardDto> result = playerCardService.getBuffer(playerId);
			
			response.setValue(result);
			
			session.write(response);
		}
	};
}
