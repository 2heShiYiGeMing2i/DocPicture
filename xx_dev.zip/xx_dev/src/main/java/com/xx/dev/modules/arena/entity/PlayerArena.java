package com.xx.dev.modules.arena.entity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.apache.commons.lang.StringUtils;
import org.codehaus.jackson.type.TypeReference;

import com.xx.common.db.cache.DbLoadInitializer;
import com.xx.common.db.model.BaseModel;
import com.xx.common.util.JsonUtils;
import com.xx.dev.modules.arena.model.ChallengeDto;


/**
 * 玩家竞技场信息
 * 
 * @author bingshan
 */
@Entity
@Table(name = "playerArena")
public class PlayerArena extends BaseModel<Long> implements DbLoadInitializer {
	
	private static final long serialVersionUID = 733469495645475910L;

	/**
	 * 角色ID
	 */
	@Id
	@Column(columnDefinition = "bigint(20) not null comment '角色id'")
	private Long playerId;
	
	/**
	 * 当天(重置时间)挑战次数
	 */
	@Column(columnDefinition="tinyint(4) default '0' comment '当天(重置时间)挑战次数'")
	private Integer challengeCount = 0;
	
	/**
	 * 最近一次挑战时间(ms)
	 */
	@Column(columnDefinition="bigint(20) default '0' comment '最近一次挑战时间(ms)'")
	private Long challengeTime = 0L;
	
	/**
	 * 自最后一次挑战以来累计cd时间(ms)
	 */
	@Column(columnDefinition="bigint(20) default '0' comment '自最后一次挑战以来累计cd时间(ms)'")
	private Long cdTime = 0L;
	
	/**
	 * 下次可挑战时间(ms)
	 */
	@Column(columnDefinition="bigint(20) default '0' comment '下次可挑战时间(ms)'")
	private Long nextChallengeTime = 0L;
	
	/**
	 * 当天(重置时间)购买次数
	 */
	@Column(columnDefinition="tinyint(4) default '0' comment '当天(重置时间)购买次数'")
	private Integer buyCount = 0;
	
	/**
	 * 当天(重置时间)之前的剩余购买次数
	 */
	@Column(columnDefinition="tinyint(4) default '0' comment '当天(重置时间)之前的剩余购买次数'")
	private Integer preLeftBuyCount = 0;
	
	/**
	 * 上次重置时间
	 */
	@Column(columnDefinition="datetime comment '上次重置时间'")
	private Date refreshTime = new Date();
	
	/**
	 * 当前连胜
	 */
	@Column(columnDefinition="int(10) default '0' comment '当前连胜'")
	private Integer wins = 0;
	
	/**
	 * 宝箱id
	 */
	@Column(columnDefinition="int(10) default '0' comment '宝箱id'")
	private Integer boxId = 0;
	
	/**
	 * 宝箱状态：0-未领取 1-已领取
	 */
	@Column(columnDefinition="tinyint(4) default '0' comment '宝箱状态：0-未领取 1-已领取'")
	private Integer boxStatus = 0;
	
	/**
	 * 宝箱奖励倍数
	 */
	@Column(columnDefinition="int(10) default '1' comment '宝箱奖励倍数'")
	private Integer boxCount = 1;
	
	/**
	 * 结算排名
	 */
	@Column(columnDefinition="int(10) default '0' comment '结算排名'")
	private Integer balanceRank = 0;
	
	/**
	 * 历史最高排名
	 */
	@Column(columnDefinition="int(10) default '0' comment '历史最高排名'")
	private Integer topRank = 0;
	
	/**
	 * 是否曾经挑战过竞技场, 0-否  1-是
	 */
	@Column(columnDefinition="tinyint(4) default '0' comment '是否曾经挑战过竞技场, 0-否  1-是'")
	private Integer challenged = 0;
	
	/**
	 * 挑战历史
	 */
	@Lob
	@Column(columnDefinition = "text comment '信息'")
	private String challengeHis = "";
	
	/**
	 * 挑战历史
	 */
	@Transient
	private final List<ChallengeDto> challengeList = new ArrayList<ChallengeDto>();
	
	public static PlayerArena valueOf(long playerId) {
		PlayerArena p = new PlayerArena();
		p.playerId = playerId;
		return p;
	}

	@Override
	public void doAfterLoad() {
		if (StringUtils.isBlank(this.challengeHis)) {
			return;
		}
		
		TypeReference<List<ChallengeDto>> valueTypeRef = new TypeReference<List<ChallengeDto>>() {};
		List<ChallengeDto> list = JsonUtils.jsonString2Object(this.challengeHis, valueTypeRef);
		if (list != null && !list.isEmpty()) {
			Collections.sort(list);
			this.challengeList.addAll(list);
		}
	}



	@Override
	public Long getId() {
		return this.playerId;
	}

	@Override
	public void setId(Long id) {
		this.playerId = id;
	}

	public Long getPlayerId() {
		return playerId;
	}

	public void setPlayerId(Long playerId) {
		this.playerId = playerId;
	}

	public Integer getChallengeCount() {
		return challengeCount;
	}

	public void setChallengeCount(Integer challengeCount) {
		this.challengeCount = challengeCount;
	}

	public Long getNextChallengeTime() {
		return nextChallengeTime;
	}

	public void setNextChallengeTime(Long nextChallengeTime) {
		this.nextChallengeTime = nextChallengeTime;
	}

	public Integer getBuyCount() {
		return buyCount;
	}

	public void setBuyCount(Integer buyCount) {
		this.buyCount = buyCount;
	}

	public Integer getPreLeftBuyCount() {
		return preLeftBuyCount;
	}

	public void setPreLeftBuyCount(Integer preLeftBuyCount) {
		this.preLeftBuyCount = preLeftBuyCount;
	}

	public Date getRefreshTime() {
		return refreshTime;
	}

	public void setRefreshTime(Date refreshTime) {
		this.refreshTime = refreshTime;
	}

	public Integer getWins() {
		return wins;
	}

	public void setWins(Integer wins) {
		this.wins = wins;
	}

	public Integer getBoxId() {
		return boxId;
	}

	public void setBoxId(Integer boxId) {
		this.boxId = boxId;
	}

	public Integer getBoxStatus() {
		return boxStatus;
	}

	public void setBoxStatus(Integer boxStatus) {
		this.boxStatus = boxStatus;
	}

	public Integer getBalanceRank() {
		return balanceRank;
	}

	public void setBalanceRank(Integer balanceRank) {
		this.balanceRank = balanceRank;
	}

	public Integer getTopRank() {
		return topRank;
	}

	public void setTopRank(Integer topRank) {
		this.topRank = topRank;
	}

	public String getChallengeHis() {
		return challengeHis;
	}

	public void setChallengeHis(String challengeHis) {
		this.challengeHis = challengeHis;
	}

	public List<ChallengeDto> getChallengeList() {
		return challengeList;
	}

	public Integer getBoxCount() {
		return boxCount;
	}

	public void setBoxCount(Integer boxCount) {
		this.boxCount = boxCount;
	}

	public Integer getChallenged() {
		return challenged;
	}

	public void setChallenged(Integer challenged) {
		this.challenged = challenged;
	}

	public Long getChallengeTime() {
		return challengeTime;
	}

	public void setChallengeTime(Long challengeTime) {
		this.challengeTime = challengeTime;
	}

	public Long getCdTime() {
		return cdTime;
	}

	public void setCdTime(Long cdTime) {
		this.cdTime = cdTime;
	}

}
