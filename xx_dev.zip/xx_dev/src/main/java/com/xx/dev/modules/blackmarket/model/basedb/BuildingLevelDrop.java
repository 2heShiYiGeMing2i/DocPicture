package com.xx.dev.modules.blackmarket.model.basedb;

import com.xx.common.basedb.anno.Id;
import com.xx.common.basedb.anno.Resource;

/**
 * 黑市物品掉落表
 * 
 * @author Along
 *
 */
@Resource
public class BuildingLevelDrop {

	/**
	 * 黑市建筑等级
	 */
	@Id
	private int buildingLevel;
	
	/**
	 * 物品掉落编号
	 */
	private String dropNo;

	public int getBuildingLevel() {
		return buildingLevel;
	}

	public void setBuildingLevel(int buildingLevel) {
		this.buildingLevel = buildingLevel;
	}

	public String getDropNo() {
		return dropNo;
	}

	public void setDropNo(String dropNo) {
		this.dropNo = dropNo;
	}
	
}
