package com.xx.dev.modules.armygroup.model;

import java.util.Date;

/**
 * 军团捐献日志DTO
 * 
 * @author Along
 *
 */
public class ArmyGroupContributeDto {

	/**
	 * id
	 */
	private long id;
	
	/**
	 * 玩家id
	 */
	private long playerId;
	
	/**
	 * 玩家名称
	 */
	private String playerName;
	
	/**
	 * 建筑id
	 */
	private int buildingId;
	
	/**
	 * 捐献事件id
	 */
	private int eventId;
	
	/**
	 * 捐献时间
	 */
	private Date contributeTime;
	
	/**
	 * 完成度
	 */
	private int progress;
	
	/**
	 * 贡献值
	 */
	private int contribute;
	
	/**
	 * 银元奖励
	 */
	private int silverReward;
	
	/**
	 * 道具id
	 */
	private int itemId;
	
	/**
	 * 道具数量
	 */
	private int itemAmount;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getPlayerId() {
		return playerId;
	}

	public void setPlayerId(long playerId) {
		this.playerId = playerId;
	}

	public String getPlayerName() {
		return playerName;
	}

	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}

	public int getBuildingId() {
		return buildingId;
	}

	public void setBuildingId(int buildingId) {
		this.buildingId = buildingId;
	}

	public int getEventId() {
		return eventId;
	}

	public void setEventId(int eventId) {
		this.eventId = eventId;
	}

	public Date getContributeTime() {
		return contributeTime;
	}

	public void setContributeTime(Date contributeTime) {
		this.contributeTime = contributeTime;
	}

	public int getProgress() {
		return progress;
	}

	public void setProgress(int progress) {
		this.progress = progress;
	}

	public int getContribute() {
		return contribute;
	}

	public void setContribute(int contribute) {
		this.contribute = contribute;
	}

	public int getSilverReward() {
		return silverReward;
	}

	public void setSilverReward(int silverReward) {
		this.silverReward = silverReward;
	}

	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public int getItemAmount() {
		return itemAmount;
	}

	public void setItemAmount(int itemAmount) {
		this.itemAmount = itemAmount;
	}

}
