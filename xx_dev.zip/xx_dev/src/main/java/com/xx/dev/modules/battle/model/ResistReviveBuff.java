/**
 * @file:ResistReviveBuff.java
 * @author:David
 **/
package com.xx.dev.modules.battle.model;

import com.xx.dev.modules.skill.model.basedb.SkillEffect;

/**
 * @class:ResistReviveBuff
 * @description:抗复活效果
 * @author:David
 * @version:v1.0
 * @date:2013-4-28
 **/
public class ResistReviveBuff extends AbstractBuff {
	//技能效果
	private SkillEffect skillEffect;
	public ResistReviveBuff(int effectBaseValueType, double effectBase,
			int effectValueType, double effect, int startRound, int persistRound,SkillEffect skillEffect) {
		super(effectBaseValueType, effectBase, effectValueType, effect, startRound,
				persistRound);
		this.skillEffect = skillEffect;
	}
	public SkillEffect getSkillEffect() {
		return skillEffect;
	}
	public void setSkillEffect(SkillEffect skillEffect) {
		this.skillEffect = skillEffect;
	}
}

