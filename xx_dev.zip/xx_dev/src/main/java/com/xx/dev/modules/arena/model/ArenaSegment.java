package com.xx.dev.modules.arena.model;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;


/**
 * 竞技场分段信息
 * 
 * @author bingshan
 */
public class ArenaSegment implements Comparable<ArenaSegment> {

	/**
	 * 分段id(主键id)
	 */
	private int id;
	
	/**
	 * 分段排名起始(小)
	 */
	private int minRank;
	
	/**
	 * 分段排名截止（大）
	 */
	private int maxRank;
	
	/**
	 * 可见区间
	 */
	private int step = 1;

	public ArenaSegment(int id, int minRank, int maxRank, int step) {
		super();
		this.id = id;
		this.minRank = minRank;
		this.maxRank = maxRank;
		this.step = step;
		if (this.step < 1) {
			this.step = 1;
		}
	}

	public int getId() {
		return id;
	}

	public int getMinRank() {
		return minRank;
	}

	public int getMaxRank() {
		return maxRank;
	}

	public int getStep() {
		return step;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		
		if (!(obj instanceof ArenaSegment)) {
			return false;
		}
		
		ArenaSegment rhs = (ArenaSegment) obj;
		return new EqualsBuilder().append(this.getId(), rhs.getId())
									.isEquals();
	}
	
	@Override
	public int hashCode() {
		return new HashCodeBuilder(305668771, 1793910479)
							.append(this.getId())
							.toHashCode();
	}

	@Override
	public int compareTo(ArenaSegment o) {
		return this.id <= o.id ? -1 : 1;
	}
	
}
