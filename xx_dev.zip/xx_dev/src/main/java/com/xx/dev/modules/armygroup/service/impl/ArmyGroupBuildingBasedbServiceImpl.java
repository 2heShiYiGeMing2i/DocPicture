package com.xx.dev.modules.armygroup.service.impl;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Service;

import com.xx.common.basedb.BasedbAdapter;
import com.xx.dev.modules.armygroup.model.basedb.ArmyGroupBuildingOpen;
import com.xx.dev.modules.armygroup.service.ArmyGroupBuildingBasedbService;

/**
 * 军团建筑基础数据服务接口
 * 
 * @author Along
 *
 */
@Service
public class ArmyGroupBuildingBasedbServiceImpl extends BasedbAdapter implements
		ArmyGroupBuildingBasedbService {

	private List<ArmyGroupBuildingOpen> buildings = null;
	
	@Override
	public List<ArmyGroupBuildingOpen> getBuildings() {
		return this.buildings;
	}

	@Override
	public Class<?>[] listenedClass() {
		return new Class<?>[] {ArmyGroupBuildingOpen.class};
	}

	@Override
	public void initialize() {
		List<ArmyGroupBuildingOpen> tmpBuildings = this.basedbService.listAll(ArmyGroupBuildingOpen.class);
		if (CollectionUtils.isNotEmpty(tmpBuildings)) {
			Collections.sort(tmpBuildings, new Comparator<ArmyGroupBuildingOpen>() {
				@Override
				public int compare(ArmyGroupBuildingOpen o1, ArmyGroupBuildingOpen o2) {
					if (o1 == null && o2 == null) {
						return 0;
					} else if (o1 == null) {
						return 1;
					} else if (o2 == null) {
						return -1;
					} else if (o1.getId() == o2.getId()) {
						return 0;
					} else if (o1.getId() < o2.getId()) {
						return -1;
					} else {
						return 1;
					}
				}
			});
		}
		if (CollectionUtils.isNotEmpty(buildings)) {
			this.buildings.clear();
		} else {
			this.buildings = new CopyOnWriteArrayList<ArmyGroupBuildingOpen>();
		}
		if (CollectionUtils.isNotEmpty(tmpBuildings)) {
			this.buildings.addAll(tmpBuildings);
		}
	}

}
