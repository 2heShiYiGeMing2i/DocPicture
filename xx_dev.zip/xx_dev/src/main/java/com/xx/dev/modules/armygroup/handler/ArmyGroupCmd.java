package com.xx.dev.modules.armygroup.handler;

import com.xx.dev.modules.armygroup.model.ArmyGroupContributeDto;
import com.xx.dev.modules.armygroup.model.ArmyGroupDto;
import com.xx.dev.modules.armygroup.model.ArmyGroupMemberDto;
import com.xx.dev.modules.reward.result.ValueResultSet;

/**
 * 军团模块
 * 
 * @author Along
 *
 */
public interface ArmyGroupCmd {

	public static final String MODULE_NAME = "ARMYGROUP";
	
	/**
	 * 创建军团
	 * @param name 军团名称
	 * @param useGold 是否使用金币 {@link Integer} 0-不使用金币 非0-使用金币
	 * @return Map {
	 * 				"result" : {@link ArmyGroupResult}
	 * 				"content" : {@link ValueResultSet} 要更新的属性集
	 * 				"armyGroupDto" : {@link ArmyGroupDto} 
	 * 				"armyGroupMemberDto" : {@link ArmyGroupMemberDto} 
	 * 				"goldDiscount" : {@link Integer} VIP折扣优惠的元宝数量
	 * 				}
	 */
	int CREATE_ARMY_GROUP = 1;

	/**
	 * 分页获取军团列表
	 * @param startIndex 开始序号
	 * @param fetchCount 数量
	 * @return Map {
	 * 				"result" : {@link ArmyGroupResult}
	 * 				"content" : {@link List<ArmyGroupDto>} 军团列表
	 * 				"amount" : {@link Integer} 总数量
	 * 				}
	 */
	int GET_ARMY_GROUPS = 2;
	
	/**
	 * 获取军团信息
	 * @param name 军团名称
	 * @return Map {
	 * 				"result" : {@link ArmyGroupResult}
	 * 				"content" : {@link ArmyGroupDto} 军团信息
	 * 				}
	 */
	int GET_ARMY_GROUP = 3;
	
	/**
	 * 申请加入军团
	 * @param id 军团id
	 * @return {@link ArmyGroupResult}
	 */
	int APPLY_JOIN_ARMY_GROUP = 4;
	
	/**
	 * 获取军团申请列表
	 * @return {@link List<PlayerDto>}
	 */
	int GET_ARMY_GROUP_APPLY_LIST = 5;
	
	/**
	 * 获取申请列表
	 * @return {@link List<ArmyGroupDto>}
	 */
	int GET_APPLY_LIST = 6;
	
	/**
	 * 批准申请
	 * @param applyId 申请id
	 * @return {@link ArmyGroupResult}
	 */
	int APPROVE_APPLY = 7;
	
	/**
	 * 拒绝申请
	 * @param applyId 申请id
	 * @return {@link ArmyGroupResult}
	 */
	int REFUSE_APPLY = 8;
	
	/**
	 * 邀请加入军团
	 * @param playerName 邀请接收人名称
	 * @return {@link ArmyGroupResult}
	 */
	int INVITE_JOIN_ARMY_GROUP = 9;
	
	/**
	 * 退出军团
	 * @return {@link ArmyGroupResult}
	 */
	int QUIT_ARMY_GROUP = 10;
	
	/**
	 * 发送招贤榜
	 * @param content 内容
	 * @return {@link ArmyGroupResult}
	 */
	int ADVERTISE = 11;
	
	/**
	 * 修改军团宣言
	 * @param content 内容
	 * @return Map {
	 * 				"result" : {@link ArmyGroupResult}
	 * 				"content" : {@link ArmyGroupDto} 
	 * 				}
	 */
	int UPDATE_DECLARATION = 12;
	
	/**
	 * 发送军团邮件
	 * @param title 标题
	 * @param content 内容
	 * @return {@link ArmyGroupResult}
	 */
	int SEND_ARMY_GROUP_EMAIL = 13;
	
	/**
	 * 购买虎符
	 * @param amount 数量
	 * @return Map {
	 * 				"result" : {@link ArmyGroupResult}
	 * 				"content" : {@link ValueResultSet} 要更新的属性集
	 * 				"goldDiscount" : {@link Integer} VIP折扣优惠的元宝数量
	 * 				}
	 */
	int BUY_HUFU = 14;
	
	/**
	 * 获取军团成员列表
	 * @return {@link List<ArmyGroupMemberDto}
	 */
	int GET_ARMY_GROUP_MEMBERS = 15;
	
	/**
	 * 领取粮草福利
	 * @return Map {
	 * 				"result" : {@link ArmyGroupResult}
	 * 				"content" : {@link ValueResultSet} 要更新的属性集
	 * 				"armyGroupMemberDto" : {@link ArmyGroupMemberDto} 
	 * 				}
	 */
	int RECEIVEFOODS = 16;
	
	/**
	 * 领取武将经验福利
	 * @return Map {
	 * 				"result" : {@link ArmyGroupResult}
	 * 				"content" : {@link ValueResultSet} 要更新的属性集
	 * 				"armyGroupMemberDto" : {@link armyGroupMemberDto} 
	 * 				}
	 */
	int RECEIVEEXPLOIT = 17;
	
	/**
	 * 升|降职
	 * @param userId 被操作的团员id
	 * @param positionId 新的职位id
	 * @return Map {
	 * 				"result" : {@link ArmyGroupResult}
	 * 				"content" : {@link ValueResultSet} 要更新的属性集
	 * 				"armyGroupMemberDto" : {@link ArmyGroupMemberDto} 
	 * 				}
	 */
	int CHANGE_POSITION = 18;
	
	/**
	 * 踢人
	 * @param userId 被踢出的人id
	 * @param reason 踢人的理由
	 * @return Map {
	 * 				"result" : {@link ArmyGroupResult}
	 * 				"armyGroupDto" : {@link ArmyGroupDto} 
	 * 				}
	 */
	int KICK_OUT_SOMEONE = 19;
	
	/**
	 * 转让团长
	 * @param userId 新团长的id
	 * @return Map {
	 * 				"result" : {@link ArmyGroupResult}
	 * 				"content" : {@link ValueResultSet} 要更新的属性集
	 * 				"armyGroupDto" : {@link ArmyGroupDto} 
	 * 				}
	 */
	int TRANSFER_CHIEF = 20;
	
	/**
	 * 进入军团界面
	 * @return Map {
	 * 				"result" : {@link ArmyGroupResult}
	 * 				"content" : {@link ArmyGroupDto} 军团对象（军团对象不为空表示已经加入军团；否则返回军团列表）
	 * 				"amount" ： {@link Integer} 军团的数量
	 * 				"armyGroups" : {@link List<ArmyGroupDto>} 军团列表
	 * 				"armyGroupMemberDto" : {@link ArmyGroupMemberDto} 军团成员
	 * 				"armyGroupBuildingDtos" : {@link List<ArmyGroupBuildingDto>} 军团建筑列表
	 * 				}
	 */
	int ENTER_ARMY_GROUP = 21;

	/**
	 * 取消加入军团申请
	 * @param id 军团id
	 * @return {@link ArmyGroupResult}
	 */
	int CANCEL_APPLY_JOIN_ARMY_GROUP = 22;
	
	/**
	 * 捐赠虎符
	 * @param buildingId 建筑id
	 * @param useGold 是否自动购买（-1不自动购买；0自动用银元购买；1自动用元宝购买）
	 * @return Map {
	 * 				"result" : {@link ArmyGroupResult}
	 * 				"content" : {@link ValueResultSet} 要更新的属性集 
	 * 				"armyGroupDto" : {@link armyGroupDto} 军团
	 * 				"armyGroupMemberDto" : {@link armyGroupMemberDto} 军团成员
	 * 				"armyGroupContributeDto" : {@link ArmyGroupContributeDto} 军团捐献记录
	 * 				"armyGroupBuildingDto" : {@link armyGroupBuildingDto} 军团建筑
	 * 				"goldDiscount" : {@link Integer} VIP折扣优惠的元宝数量
	 * 				"armyGroupBuildingDtos" : {@link List<ArmyGroupBuildingDto>} 军团建筑列表
	 * 				}
	 */
	int CONTRIBUTE_HUFU = 23;

	/**
	 * 获取捐赠列表
	 * @return {@link List<ArmyGroupContributeDto>}
	 */
	int GET_ARMY_GROUP_CONTRIBUTES = 24;
	
	/**
	 * 军团科技升级
	 * @param techId 军团科技id
	 * @return Map {
	 * 				"result" : {@link ArmyGroupResult}
	 * 				"content" : {@link ArmyGroupMemberDto}
	 * 				}
	 */
	int UPGRADE_ARMY_GROUP_TECH = 25;

	/**
	 * 获取军团科技列表
	 * @return {@link List<ArmyGroupTechDto>}
	 */
	int GET_ARMY_GROUP_TECHS = 26;
	
	/**
	 * 弹劾团长
	 * @return Map {
	 * 				"result" : {@link ArmyGroupResult}
	 * 				"content" : {@link ArmyGroupDto} 
	 * 				"armyGroupMemberDto" : {@link ArmyGroupMemberDto}
	 * 				}
	 */
	int DELATE_CHIEF = 27;

	/**
	 * 同意所有申请
	 * @return {@link ArmyGroupResult}
	 */
	int APPROVE_APPLYS = 28;
	
	/**
	 * 拒绝所有申请
	 * @return {@link ArmyGroupResult}
	 */
	int REFUSE_APPLYS = 29;
	
	/**
	 * 购买军团商城物品
	 * @param goodsId 物品id
	 * @param amount 数量
	 * @return Map {
	 * 				"result" : {@link ArmyGroupResult}
	 * 				"content" : {@link ValueResultSet} 要更新的属性集
	 * 				"armyGroupMemberDto" : {@link armyGroupMemberDto} 军团成员
	 * 				}
	 */
	int BUY_ARMY_GROUP_GOODS = 30;
	
	/**
	 * 修改军团公告
	 * @param content 内容
	 * @return {@link ArmyGroupResult}
	 */
	int UPDATE_NOTICE = 31;
	
	/**
	 * 获取军团建筑列表
	 * @return {@link List<ArmyGroupBuildingDto>}
	 */
	int GET_ARMY_GROUP_BUILDINGS = 32;
	
	/**
	 * 获取军团
	 * @return {@link ArmyGroupDto}
	 */
	int RETURN_ARMY_GROUP = 33;
	
	/**
	 * 清除冷却时间
	 * @return  Map {
	 * 				"result" : {@link ArmyGroupResult}
	 * 				"content" : {@link ValueResultSet} 要更新的属性集
	 * 				"armyGroupMemberDto" : {@link ArmyGroupMemberDto}
	 * 				"freeGold" : {@link Integer} 节省的元宝
	 * 				}
	 */
	int CLEAR_COOL_TIME = 34;
	
	/**
	 * 修改军团名称
	 * @param content 军团名称
	 * @return {@link ArmyGroupResult}
	 */
	int RENAME_ARMY_GROUP = 35;
	
	/**
	 * 随机获取军团列表
	 * @param fetchCount 数量
	 * @return {@link List<ArmyGroupDto>} 军团列表
	 */
	int GET_RAND_ARMY_GROUPS = 36;
	
	/**
	 * 查找军团
	 * @param name 军团名称
	 * @return {@link List<ArmyGroupDto>}
	 */
	int SEARCH_ARMY_GROUPS = 37;
	
	//---------------------------------------------------
	/**
	 * 推送军团邀请{@link ArmyGroupDto}
	 */
	public static final int PUSH_INVITE = -1000;
	
	/**
	 * 推送军团申请
	 */
	public static final int PUSH_APLLY = -1001;
	
	/**
	 * 推送加入军团
	 * {@link ArmyGroupDto}
	 */
	public static final int PUSH_JOIN_ARMY_GROUP = -1002;
	
	/**
	 * 推送被踢出军团
	 */
	public static final int PUSH_KICK_OUT_ARMY_GROUP = -1003;
	
}
