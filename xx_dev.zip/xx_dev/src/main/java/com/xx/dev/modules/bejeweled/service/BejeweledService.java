package com.xx.dev.modules.bejeweled.service;

import com.xx.dev.model.Result;

/**
 * 宝箱迷阵
 * Created by LiangZengle on 2014/6/21.
 */
public interface BejeweledService {
    /**
     * 开箱子
     *
     * @param playerId
     * @return
     */
    Result<?> openBox(long playerId);

    /**
     * 自动清除
     *
     * @param playerId
     * @return
     */
    Result<?> autoClearUp(long playerId);

    /**
     * 增加步数
     *
     * @param playerId
     * @return
     */
    Result<?> addMove(long playerId);

    /**
     * 交换两个方块
     *
     * @param playerId
     * @param coordinates [x1,y1,x2,y2]
     * @return
     */
    Result<?> swap(long playerId, int[] coordinates);

    /**
     * 获取宝箱迷阵信息
     *
     * @param playerId
     * @return
     */
    Result<?> getBejeweledInfo(long playerId);
}
