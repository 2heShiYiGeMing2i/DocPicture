package com.xx.dev.modules.activity.handler;

import com.xx.dev.modules.task.handler.TaskResult;


/**
 * 活动系统返回码
 * 
 * @author bingshan
 */
public interface ActivityResult extends TaskResult {
	
	/**
	 * 不是任务活动
	 */
	int NOT_ACTIVITY_TASK = -20001;
	
	/**
	 * 活动未开启
	 */
	int ACTIVITY_NOT_OPENED = -20002;

}
