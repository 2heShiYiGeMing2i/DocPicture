package com.xx.dev.modules.building.model;

import com.xx.dev.modules.building.entity.PlayerBuilding;

/**
 * 主城建筑DTO
 * 
 * @author Along
 *
 */
public class PlayerBuildingDto {

	/**
	 * 建筑id
	 */
	private int id;
	
	/**
	 * 建筑等级
	 */
	private int level;
	
	/**
	 * 建筑品质
	 */
	private int quality;
	
	public static PlayerBuildingDto valueOf(PlayerBuilding playerBuilding) {
		PlayerBuildingDto result = new PlayerBuildingDto();
		result.setId(playerBuilding.getBuildingId());
		result.setLevel(playerBuilding.getLevel());
		result.setQuality(playerBuilding.getQuality());
		return result;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

	public int getQuality() {
		return quality;
	}

	public void setQuality(int quality) {
		this.quality = quality;
	}
	
}
