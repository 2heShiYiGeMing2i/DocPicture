package com.xx.dev.event;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.xx.common.event.AbstractReceiver;
import com.xx.dev.modules.chargeactivity.service.ChargeActivityService;
import com.xx.dev.modules.chargedraw.service.ChargeDrawService;
import com.xx.dev.modules.chargereturnactivity.service.ChargeActivityReturnService;
import com.xx.dev.modules.deposit.service.DepositService;
import com.xx.dev.modules.monarchfeast.service.MonarchFeastService;
import com.xx.dev.modules.specialshop.service.SpecialShopService;
import com.xx.dev.modules.vip.service.VipService;
import com.xx.dev.modules.worldcup.service.WorldCupService;

/**
 * 充值事件接收器
 * 
 * @author bingshan
 */
@Component
public class ChargeEventReceiver extends AbstractReceiver<ChargeEvent> {
	@Autowired
	private VipService vipService;
	
	@Autowired
	private ChargeActivityService chargeActivityService;

    @Autowired
    private WorldCupService worldCupService;
    
    @Autowired
    private SpecialShopService specialShopService;
	
    @Autowired
    private ChargeActivityReturnService chargeActivityReturnService;
    
    @Autowired
    private ChargeDrawService chargeDrawService;
    
    @Autowired
    private DepositService depositService;
    
    @Autowired
    private MonarchFeastService monarchFeastService;
    
	@Override
	public String[] getEventNames() {
		return new String[] {ChargeEvent.NAME};
	}

	@Override
	public void doEvent(ChargeEvent event) {
		if (event == null) {
			return;
		}
		//刷新VIP等级
		vipService.chargeGrowVip(event.getPlayerId());
		chargeActivityService.charge(event);

        // 世界杯
        worldCupService.onCharge(event);
        
        // 充值积分商店
        specialShopService.onCharge(event);
        
        //充值返还
        chargeActivityReturnService.onChargeEvent(event);
        
        // 充值抽奖
        chargeDrawService.onCharge(event);
        
        // 财富乐翻天
        depositService.onCharge(event);
        
        // 帝王盛宴
        monarchFeastService.onCharge(event);
	}

}
