package com.xx.dev.modules.armygroup.model;

/**
 * 军团科技类型
 * 
 * @author Along
 *
 */
public enum ArmyGroupTechType {

	/**
	 * 0-无
	 */
	NONE,
	
	/**
	 * 1-武力
	 */
	POWER,
	
	/**
	 * 2-智力
	 */
	BRAINS,
	
	/**
	 * 3-魅力
	 */
	CHARM,
	
	/**
	 * 4-统率
	 */
	COMMAND,
	
	/**
	 * 5-技能威力
	 */
	SKILLPOWER,
	
	/**
	 * 6-税收
	 */
	REVUNUE,
	
	/**
	 * 7-种植
	 */
	PLANT,
	
	/**
	 * 8-建筑
	 */
	BUILD,
	
	/**
	 * 9-科学
	 */
	SCIENCE;
	
}
