package com.xx.dev.modules.bejeweled.model;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.xx.common.util.JsonUtils;
import com.xx.common.util.RandomUtil;

import org.apache.commons.collections.CollectionUtils;

import java.util.*;

/**
 * Created by LiangZengle on 2014/6/18.
 */
public class BejeweledContext {
    public static final int EMPTY_VALUE = 0;
    /**
     * 行数
     */
    private int rows;
    /**
     * 列数
     */
    private int columns;
    /**
     * 方块种类数
     */
    private int kinds;
    private int[][] table;

    private BejeweledContext(int rows, int columns, int kinds) {
        this.rows = rows;
        this.columns = columns;
        this.kinds = kinds;
        table = new int[rows][columns];
        init();
    }

    public static BejeweledContext valueOf(int rows, int columns, int kinds) {
        return new BejeweledContext(rows, columns, kinds);
    }

    private void init() {
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                table[i][j] = randomValue();
            }
        }
        process();// 清除可以消除的方块
//        print("init");
    }

    private int randomValue() {
        return RandomUtil.betweenValue(1, kinds);
    }

    /**
     * 交换两个位置
     *
     * @param coordinates [srcX, srcY, destX, destY]
     * @return Collection of {@link ClearUpDto} if swap successfully, or null if failed
     */
    public Collection<ClearUpDto> swap(int... coordinates) {
        if (coordinates == null || coordinates.length != 4) {
            return null;
        }
        int column1 = coordinates[0], row1 = coordinates[1], column2 = coordinates[2], row2 = coordinates[3];
        if (column1 < 0 || column1 >= columns || row1 < 0 || row1 >= rows || column2 < 0 || column2 >= columns || row2 < 0 || row2 >= rows
                || (Math.abs(column1 - column2) + Math.abs(row1 - row2)) > 1) {
            return null;
        }
        swapWithoutCheck(row1, column1, row2, column2);
//        print("swap");

        return process();
    }

    public Collection<ClearUpDto> autoClearUp(int target, int count) {
        List<Cell> autoClearCells = Lists.newArrayListWithCapacity(count);
        // 先消除目标方块
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                if (count < 1) {
                    break;
                }
                if (table[i][j] == target) {
                    autoClearCells.add(Cell.valueOf(i, j, table[i][j]));
                    table[i][j] = EMPTY_VALUE;
                    count--;
                }
            }
        }
        // 目标方块不够，随机消除
        int loopLimit = 100;
        while (count > 0 && --loopLimit > 0) {
            int i = RandomUtil.nextInt(rows);
            int j = RandomUtil.nextInt(columns);
            if (table[i][j] != EMPTY_VALUE) {
                autoClearCells.add(Cell.valueOf(i, j, table[i][j]));
                table[i][j] = EMPTY_VALUE;
                count--;
            }
        }
//        print("auto clear up");

        Collection<Cell> newCells = fall();
        ClearUpDto clearUpDto = ClearUpDto.valueOf(autoClearCells, Collections.singletonList(autoClearCells.size()), takeSnapshot(), newCells);// 自动消除结果

        LinkedList<ClearUpDto> clearUpDtos = process();
        clearUpDtos.addFirst(clearUpDto);
        return clearUpDtos;
    }

    private void swapWithoutCheck(int row1, int column1, int row2, int column2) {
        int temp = table[row1][column1];
        table[row1][column1] = table[row2][column2];
        table[row2][column2] = temp;
    }

    /**
     * 重复执行：消除-掉落，直到没有可以消除的方块为止
     *
     * @return
     */
    private LinkedList<ClearUpDto> process() {
        Map.Entry<Set<Cell>, List<Integer>> clearUpResult = clearUp();
        LinkedList<ClearUpDto> clearUpDtos = Lists.newLinkedList();
        int loopLimit = 100;
        while (CollectionUtils.isNotEmpty(clearUpResult.getKey()) && --loopLimit > 0) {
            Collection<Cell> newCells = fall();
            clearUpDtos.add(ClearUpDto.valueOf(clearUpResult.getKey(), clearUpResult.getValue(), takeSnapshot(), newCells));
            clearUpResult = clearUp();
        }
        return clearUpDtos;
    }

    /**
     * 消除
     *
     * @return 被消除方块
     */
    private Map.Entry<Set<Cell>, List<Integer>> clearUp() {
        List<List<Cell>> rowCells = scanRow();
        List<List<Cell>> columnCells = scanColumn();

        Set<Cell> toBeEliminatedCells = Collections.emptySet();// 所有需要消除的方块
        List<Integer> eliminatedResult = Collections.emptyList();// 每次消除的方块数，用于计算得分
        if (CollectionUtils.isNotEmpty(rowCells) || CollectionUtils.isNotEmpty(columnCells)) {
            toBeEliminatedCells = new TreeSet<Cell>();
            eliminatedResult = Lists.newArrayListWithCapacity(rowCells.size() + columnCells.size());
            // 合并
            for (List<Cell> cells : rowCells) {
                toBeEliminatedCells.addAll(cells);
                eliminatedResult.add(cells.size());
            }
            for (List<Cell> cells : columnCells) {
                toBeEliminatedCells.addAll(cells);
                eliminatedResult.add(cells.size());
            }
            // 消除
            for (Cell cell : toBeEliminatedCells) {
                table[cell.getY()][cell.getX()] = EMPTY_VALUE;
            }
        }
//        print("clear");
        return Maps.immutableEntry(toBeEliminatedCells, eliminatedResult);
    }

    private List<List<Cell>> scanColumn() {
        return scan(false);
    }

    private List<List<Cell>> scanRow() {
        return scan(true);
    }

    private List<List<Cell>> scan(boolean isScanRow) {
        int outer = isScanRow ? rows : columns;
        int inner = isScanRow ? columns : rows;

        List<List<Cell>> total = Lists.newLinkedList();
        for (int i = 0; i < outer; i++) {
            int temp = -1;
            List<Cell> sameKindCells = Lists.newLinkedList();
            for (int j = 0; j < inner; j++) {
                int row = isScanRow ? i : j;
                int column = isScanRow ? j : i;
                int value = table[row][column];
                if (value != temp) {
                    if (sameKindCells.size() > 2) {
                        total.add(Lists.newArrayList(sameKindCells));
                    }
                    sameKindCells.clear();
                    temp = value;
                    sameKindCells.add(Cell.valueOf(row, column, value));
                } else {
                    sameKindCells.add(Cell.valueOf(row, column, value));
                    if (j == inner - 1 && sameKindCells.size() > 2) {
                        total.add(Lists.newArrayList(sameKindCells));
                    }
                }
            }
        }
        return total;
    }

    /**
     * 消除后填充<br/>
     * 自下往上遍历，遇到空值则循环从上一行找一个非空值进行交换<br/>
     * 如果第一行是空值，则随机一个值
     */
    private List<Cell> fall() {
        List<Cell> newCells = Lists.newArrayList();
        for (int column = 0; column < columns; column++) {
            int serialNo = 0;
            for (int row = rows - 1; row >= 0; row--) {
                int oldValue = table[row][column];
                if (oldValue == EMPTY_VALUE) {
                    int offset = 0, newValue, lastRow;
                    do {
                        lastRow = row - (++offset);
                        if (lastRow < 0) {
                            newValue = randomValue();
                            break;
                        }
                        newValue = table[lastRow][column];
                    } while (newValue == EMPTY_VALUE);

                    if (lastRow < 0) {
                        table[row][column] = newValue;
                        newCells.add(Cell.valueOf(lastRow + (serialNo--), column, newValue));
                    } else {
                        swapWithoutCheck(row, column, lastRow, column);
                    }
                }
            }
        }
        Collections.sort(newCells);

//        print("fall");
        return newCells;
    }

//    private void print(String title) {
//        System.out.println("---------------------" + title + "--------------------");
//        for (int[] cells : table) {
//            System.out.println(Arrays.toString(cells));
//        }
//        System.out.println();
//    }

    public String takeSnapshot() {
        return JsonUtils.object2JsonString(table);
    }
}
