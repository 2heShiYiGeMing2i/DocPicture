package com.xx.dev.modules.armygrouptrain.model;

public enum TrainStatus {

	/**
	 * 活動還沒有開始或者已經結束
	 * 值-0
	 */
	NONE,
	
	/**
	 * 活動開始的預備階段，玩家可以進入場景
	 * 值-1
	 */
	START,
	
	/**
	 * 可以請求試煉軍數據，玩家可以開始攻擊試煉軍
	 * 值-2
	 */
	ATTACK
}
