/**
 * @file:MultiBattleResult.java
 * @author:David
 **/
package com.xx.dev.modules.battle.model;

import java.util.ArrayList;
import java.util.List;

import com.xx.dev.modules.battle.core.BattleWinner;

/**
 * @class:MultiBattleResult
 * @description:多波战斗结果
 * @author:David
 * @version:v1.0
 * @date:2013-8-19
 **/
public class MultiBattleResult {
	/** 战斗胜方 BattleWinner */
	private BattleWinner winner = BattleWinner.DRAW_GAME;
	/** 多波战斗结果 **/
	private List<BattleResult> battleResults;
	/** 多波战斗大回合血量信息 **/
	private List<BattleBigRound> bigRounds;
	
		
	public MultiBattleResult() {
		super();
	}
	
	public MultiBattleResult(boolean isReport) {
		super();
		if(isReport){
			this.battleResults = new ArrayList<BattleResult>();
		}
	}
	public MultiBattleResult(boolean isReport, boolean isRound) {
		super();
		if(isReport){
			this.battleResults = new ArrayList<BattleResult>();
		}
		if(isRound){
			this.bigRounds = new ArrayList<BattleBigRound>();
		}
	}
	
	public BattleWinner getWinner() {
		return winner;
	}
	public void setWinner(BattleWinner winner) {
		this.winner = winner;
	}
	public List<BattleResult> getBattleResults() {
		return battleResults;
	}
	public void setBattleResults(List<BattleResult> battleResults) {
		this.battleResults = battleResults;
	}
	public List<BattleBigRound> getBigRounds() {
		return bigRounds;
	}

	public void setBigRounds(List<BattleBigRound> bigRounds) {
		this.bigRounds = bigRounds;
	}

	public void addBattleResult(BattleResult battleResult){
		if(battleResults != null){
			this.battleResults.add(battleResult);
		}
	}

	public void addBigRounds(BattleBigRound battleBigRound){
		if(bigRounds != null){
			this.bigRounds.add(battleBigRound);
		}
	}
	
	public List<BattleBigRoundInfo> getBattleBigRoundInfo(long playerId, BattleTeam battleTeam){
		List<BattleBigRoundInfo> result = null;
		if(bigRounds == null || bigRounds.isEmpty()){
			return null;
		}
		result = new ArrayList<BattleBigRoundInfo>();
		for (BattleBigRound bigRound : bigRounds) {
			if(battleTeam.equals(BattleTeam.OFFENSE_TEAM) && bigRound.getAttackerChanges().getPlayerId() == playerId){
				result.add(new BattleBigRoundInfo(bigRound.getCurrRound(), bigRound.getAttackerChanges()));
			}else if(battleTeam.equals(BattleTeam.DEFENSE_TEAM) && bigRound.getDefenderChanges().getPlayerId() == playerId){
				result.add(new BattleBigRoundInfo(bigRound.getCurrRound(), bigRound.getDefenderChanges()));
			}
		}
		return result;
	}
	
}

