package com.xx.dev.modules.bejeweled.model;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.codehaus.jackson.annotate.JsonIgnore;

/**
 * 格子
 * Created by LiangZengle on 2014/6/17.
 */
public class Cell implements Comparable<Cell> {
    /**
     * 方块类型: 1-6
     */
    private int value;

    /**
     * x坐标(列)
     */
    private int x;

    /**
     * y坐标(行)
     */
    private int y;

    /**
     * @param y     行
     * @param x     列
     * @param value
     * @return
     */
    public static Cell valueOf(int y, int x, int value) {
        Cell cell = new Cell();
        cell.x = x;
        cell.y = y;
        cell.value = value;
        return cell;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    @Override
    public int compareTo(Cell o) {
        if (this.y != o.y) {
            return this.y - o.y;
        }
        if (this.x != o.x) {
            return o.x - this.x;
        }
        return 0;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Cell)) {
            return false;
        }
        Cell cell = (Cell) obj;
        return new EqualsBuilder()
                .append(this.getX(), cell.getX())
                .append(this.getY(), cell.getY())
                .append(this.getValue(), cell.getValue())
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(305668771, 1793910479)
                .append(this.getX())
                .append(this.getY())
                .append(this.getValue())
                .toHashCode();
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }
}
