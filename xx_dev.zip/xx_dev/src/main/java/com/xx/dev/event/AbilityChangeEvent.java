package com.xx.dev.event;

import com.xx.common.event.Event;
import com.xx.dev.modules.player.handler.PlayerCmd;

/**
 * 战斗力变化事件
 * 
 * @author Along
 *
 */
public class AbilityChangeEvent {

	/**
	 * 事件名称
	 */
	public static final String NAME = PlayerCmd.MODULE_NAME + ":ABILITYCHANGE";
	
	/**
	 * 玩家id
	 */
	private long playerId;
	
	/**
	 * 战斗力
	 */
	private double ability;
	
	public static Event<AbilityChangeEvent> valueOf(long playerId, double ability) {
		AbilityChangeEvent body = new AbilityChangeEvent();
		body.playerId = playerId;
		body.ability = ability;
		return new Event<AbilityChangeEvent>(NAME, body);
	}

	public long getPlayerId() {
		return playerId;
	}

	public void setPlayerId(long playerId) {
		this.playerId = playerId;
	}

	public double getAbility() {
		return ability;
	}

	public void setAbility(double ability) {
		this.ability = ability;
	}
	
}
