package com.xx.dev.modules.card.service;

import com.xx.dev.modules.card.model.basedb.PlayerCardConfig;

public interface PlayerCardRuleService {

	/**
	 * 月卡基础数据
	 * @return
	 */
	PlayerCardConfig getPlayerCardConfig();

}
