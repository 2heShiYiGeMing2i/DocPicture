/**
 * @file:BattleSkillEffectInfo.java
 * @author:David
 **/
package com.xx.dev.modules.battle.model;

import com.xx.dev.modules.skill.model.SkillEffectType;
import com.xx.dev.modules.skill.model.basedb.Skill;
import com.xx.dev.modules.skill.model.basedb.SkillEffect;


/**
 * @class:BattleSkillEffectInfo
 * @description:战斗中所属某角色技能效果
 * @author:David
 * @version:v1.0
 * @date:2013-4-22
 **/
public class BattleSkillEffectInfo implements Cloneable{
	/**
	 * 技能效果
	 */
	private SkillEffect skillEffect;
	/**
	 * 所属技能
	 */
	private Skill skill;
	/**
	 * 技能伤害类型
	 */
	private int harmType = HarmType.NONE;
	/**
	 * 技能等级
	 */
	private int skillLevel = 0;
	/**
	 * 低级技能等级
	 */
	private int lowSkillLevel = 0;
	/**
	 * 当前剩余冷却回合
	 */
	private int leftCoolRound = 0;
	/**
	 * 技能效果促发次数
	 */
	private int currTriggerCount = 0;
	/**
	 * 累积的概率
	 */
	private double curRateCumsum = 0;
	/**
	 * 技能触发者所处pos
	 */
	private int triggerPos;
	/**
	 * 技能触发者ID
	 */
	private long triggerId;
	
	public void reset(){
		int effectType = this.skillEffect.getEffectType();
		//2014-7-6 复活和护盾技能信息保留不清除
		if(effectType != SkillEffectType.REVIVE && effectType != SkillEffectType.SHIELDS){
			this.leftCoolRound = skillEffect.getInitCoolRound(skillLevel);
			this.currTriggerCount = 0;
			this.curRateCumsum = 0;
		}
	}
	
	public BattleSkillEffectInfo(BattleCharacter battleCharacter, SkillEffect skillEffect, Skill skill, int skillLevel, int lowSkillLevel) {
		super();
		this.triggerId = battleCharacter.getId();
		this.triggerPos = battleCharacter.getTeamPosition();
		this.skillEffect = skillEffect;
		this.skill = skill;
		this.harmType = skill.getHarmType();
		this.skillLevel = skillLevel;
		this.lowSkillLevel = lowSkillLevel;
		this.leftCoolRound = skillEffect.getInitCoolRound(skillLevel);
	}
	public SkillEffect getSkillEffect() {
		return skillEffect;
	}
	public void setSkillEffect(SkillEffect skillEffect) {
		this.skillEffect = skillEffect;
	}
	public int getCurrTriggerCount() {
		return currTriggerCount;
	}
	public void setCurrTriggerCount(int currTriggerCount) {
		this.currTriggerCount = currTriggerCount;
	}
	public int getSkillLevel() {
		return skillLevel;
	}
	public void setSkillLevel(int skillLevel) {
		this.skillLevel = skillLevel;
	}
	public double getCurRateCumsum() {
		return curRateCumsum;
	}
	public void setCurRateCumsum(double curRateCumsum) {
		this.curRateCumsum = curRateCumsum;
	}
	public int getTriggerPos() {
		return triggerPos;
	}
	public void setTriggerPos(int triggerPos) {
		this.triggerPos = triggerPos;
	}
	public int getLeftCoolRound() {
		return leftCoolRound;
	}
	public void setLeftCoolRound(int leftCoolRound) {
		this.leftCoolRound = leftCoolRound;
	}
	public int getLowSkillLevel() {
		return lowSkillLevel;
	}
	public void setLowSkillLevel(int lowSkillLevel) {
		this.lowSkillLevel = lowSkillLevel;
	}
	public int getHarmType() {
		return harmType;
	}
	public void setHarmType(int harmType) {
		this.harmType = harmType;
	}
	public long getTriggerId() {
		return triggerId;
	}
	public void setTriggerId(long triggerId) {
		this.triggerId = triggerId;
	}
	public Skill getSkill() {
		return skill;
	}
	public void setSkill(Skill skill) {
		this.skill = skill;
	}
	/**
	 * @description:增加 技能效果促发次数
	 *
	 */
	public void increaseCurrTriggerCount() {
		this.currTriggerCount += 1;
	}
	/**
	 * 剩余冷却回合减一回合
	 */
	public void decrLeftCoolRound() {
		if (this.leftCoolRound > 0) {
			this.leftCoolRound --;
		}
	}
	public BattleSkillEffectInfo clone(){
		try {
			return (BattleSkillEffectInfo) super.clone();
		} catch (CloneNotSupportedException ex) {
			return null;
		}
	}
}

