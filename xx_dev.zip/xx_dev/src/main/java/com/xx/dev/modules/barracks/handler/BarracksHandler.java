
package com.xx.dev.modules.barracks.handler;

import java.lang.reflect.Type;
import java.util.HashMap;

import org.apache.commons.lang.StringUtils;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xx.common.socket.handler.RequestProcessor;
import com.xx.common.socket.model.Request;
import com.xx.common.socket.model.Response;
import com.xx.dev.config.Module;
import com.xx.dev.model.Result;
import com.xx.dev.modules.barracks.model.PlayerSoldierDto;
import com.xx.dev.modules.barracks.service.BarracksService;
import com.xx.dev.modules.reward.result.ValueResultSet;
import com.xx.dev.modules.server.SessionManager;
import com.xx.dev.modules.server.handler.HandlerSupport;

/**
 * 兵营模块
 * 
 * @author Along
 *
 */
@Service
public class BarracksHandler extends HandlerSupport {

	private Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	private SessionManager sessionManager;
	
	@Autowired
	private BarracksService barracksService;

	@Override
	protected void init() {
		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				enter(session, response);
			}
			
			@Override
			public Type getType() {
				return null;
			}
			
			@Override
			public int getModule() {
				return Module.BARRACKS;
			}
			
			@Override
			public int getCmd() {
				return BarracksCmd.ENTER_BARRACKS;
			}
		});
		
		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				recruit_soldiers(session, request, response);
			}
			
			@Override
			public Type getType() {
				return HashMap.class;
			}
			
			@Override
			public int getModule() {
				return Module.BARRACKS;
			}
			
			@Override
			public int getCmd() {
				return BarracksCmd.RECRUIT_SOLDIERS;
			}
		});
		
		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				disband_soldiers(session, request, response);
			}
			
			@Override
			public Type getType() {
				return HashMap.class;
			}
			
			@Override
			public int getModule() {
				return Module.BARRACKS;
			}
			
			@Override
			public int getCmd() {
				return BarracksCmd.DISBAND_SOLDIERS;
			}
		});
		
		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				upgradeSoldierStar(session, request, response);
			}
			
			@Override
			public Type getType() {
				return HashMap.class;
			}
			
			@Override
			public int getModule() {
				return Module.BARRACKS;
			}
			
			@Override
			public int getCmd() {
				return BarracksCmd.UPGRADE_SOLDIER_STAR;
			}
		});
	}
	
	protected void upgradeSoldierStar(IoSession session, Request request,
			Response response) {
		Long playerId = sessionManager.getPlayerId(session);
		Result<ValueResultSet> result = null;
		try {
			result = barracksService.upgradeSoldierStarAction(playerId);
		} catch (Exception e) {
			result = Result.Error(BarracksResult.FAILURE);
			logger.error("升级兵阶", e);
		}		
		response.setValue(result);
		session.write(response);		
	}

	private void enter(IoSession session, Response response) {
		Long playerId = sessionManager.getPlayerId(session);
		Result<PlayerSoldierDto> result = null;
		try {
			result = barracksService.enterAction(playerId);
		} catch (Exception e) {
			result = Result.Error(BarracksResult.FAILURE);
			logger.error("进入兵营", e);
		}		
		response.setValue(result);
		session.write(response);
	}
	
	@SuppressWarnings("unchecked")
	private void recruit_soldiers(IoSession session, Request request,
			Response response) {
		Long playerId = sessionManager.getPlayerId(session);
		Result<PlayerSoldierDto> result = null;
		try {
			HashMap<String, Object> params = (HashMap<String, Object>) request.getValue();
			String sAmount = String.valueOf(params.get("amount"));
			if (StringUtils.isBlank(sAmount) || !StringUtils.isNumeric(sAmount)) {
				result = Result.Error(BarracksResult.PARAM_ERROR);
			} else {
				int amount = Integer.parseInt(sAmount);
				result = barracksService.recruitSoldiersAction(playerId, amount);
			}
		} catch (Exception e) {
			result = Result.Error(BarracksResult.FAILURE);
			logger.error("招募士兵", e);
		}		
		response.setValue(result);
		session.write(response);
	}
	
	@SuppressWarnings("unchecked")
	private void disband_soldiers(IoSession session, Request request,
			Response response) {
		Long playerId = sessionManager.getPlayerId(session);
		Result<PlayerSoldierDto> result = null;
		try {
			HashMap<String, Object> params = (HashMap<String, Object>) request.getValue();
			String sAmount = String.valueOf(params.get("amount"));
			if (StringUtils.isBlank(sAmount) || !StringUtils.isNumeric(sAmount)) {
				result = Result.Error(BarracksResult.PARAM_ERROR);
			} else {
				int amount = Integer.parseInt(sAmount);
				result = barracksService.disbandSoldiersAction(playerId, amount);
			}
		} catch (Exception e) {
			result = Result.Error(BarracksResult.FAILURE);
			logger.error("遣散士兵", e);
		}		
		response.setValue(result);
		session.write(response);
	}
	
}
