/**
 * @file:OpenId.java
 * @author:David
 **/
package com.xx.dev.constant;

/**
 * @class:OpenId
 * @description:各种开关的id常量定义
 * @author:David
 * @version:v1.0
 * @date:2013-6-20
 **/
public interface OpenId {
	/**
	 * 防沉迷开关
	 */
	String FCM_OPEN = "FCM_OPEN";

	/**
	 * 竞技场开关
	 */
	String ARENA_OPEN = "JJC_OPEN";

	/**
	 * 神兵活动总开关
	 */
	String MAGIC_OPEN = "MAGIC_OPEN";

	/**
	 * 神兵活动主公等级排行榜开关
	 */
	String MAGIC_PLAYERLEVEL_OPEN = "MAGIC_PLAYERLEVEL_OPEN";

	/**
	 * 神兵活动宝石等级排行榜开关
	 */
	String MAGIC_JEWEL_OPEN = "MAGIC_JEWEL_OPEN";

	/**
	 * 神兵活动总消费榜排行榜开关
	 */
	String MAGIC_CONSUME_OPEN = "MAGIC_CONSUME_OPEN";

	/**
	 * 神兵活动总战斗力排行榜
	 */
	String MAGIC_ABILITY_OPEN = "MAGIC_ABILITY_OPEN";

	/**
	 * 神兵活动军团等级排行榜
	 */
	String MAGIC_GUILD_LEVEL_OPEN = "MAGIC_GUILD_LEVEL_OPEN";

	/**
	 * 神兵活动竞技场排行榜
	 */
	String MAGIC_ARENA_OPEN = "MAGIC_ARENA_OPEN";

	/**
	 * 群雄争霸开关
	 */
	String CHAMPION_OPEN = "CHAMPION_OPEN";

	/**
	 * 360特权礼包开关
	 * */
	String TQ360_OPEN = "TQ360_OPEN";

	/**
	 * 决战长安活动开始开关
	 */
	String DECISIVE_CHANG_AN_OPEN = "DECISIVE_CHANG_AN_OPEN";

	/**
	 * 折扣商店开关
	 */
	String DISCOUNT_SHOP_OPEN = "DISCOUNT_SHOP_OPEN";

	/**
	 * 图腾排行开关
	 */
	String MAGIC_TOTEM_RANK_OPEN = "MAGIC_TOTEM_RANK_OPEN";

	/**
	 * 周理财计划开关
	 */
	String WEEK_MONEY_PLAN = "WEEK_MONEY_PLAN";

	/**
	 * 月理财计划开关
	 */
	String MONTH_MONEY_PLAN = "MONTH_MONEY_PLAN";

	/**
	 * 跨服群雄争霸开关
	 */
	String KF_CHAMPION_OPEN = "KF_CHAMPION_OPEN";

	/**
	 * 欢乐宝箱开关
	 */
	String HAPPY_BOX_OPEN = "HAPPY_BOX_OPEN";

	/**
	 * 神秘商店开关
	 */
	String MYSTERY_STORE = "WYDL_OPEN";

	/**
	 * 端午活动开关
	 */
	String DWHD_OPEN = "DWHD_OPEN";

	/**
	 * 端午商城开关
	 */
	String DWSD_OPEN = "DWSD_OPEN";

	/**
	 * 累计登陆礼包开关
	 */
	String LJDL_OPEN_2 = "LJDL_OPEN_2";

	/**
	 * 我的主队
	 */
	String WORLD_CUP_WDZD_OPEN = "WDZD_OPEN";

	/**
	 * 比赛竞猜
	 */
	String WORLD_CUP_BSJC_OPEN = "BSJC_OPEN";

	/**
	 * 卡牌宝箱
	 */
	String WORLD_CUP_KPCQ_OPEN = "KPCQ_OPEN";
	
	/**
	 * 世界杯卡牌
	 */
	String WORLD_CUP_KPSJ_OPEN = "KPSJ_OPEN";
	
	/**
	 * 总积分排行奖励领取开关
	 */
	String WORLD_CUP_KPPH_OPEN = "KPPH_OPEN";
	
	/**
	 * 世界杯活动开关
	 */
	String WORLD_CUP_WCHD_OPEN = "WCHD_OPEN";
	
	/**
	 * 元宝商店活动开关
	 */
	String GOLD_SHOP_OPEN = "YBSD_OPEN";
	
	/**
	 * 充值积分商店活动开关
	 */
	String INTEGRAL_SHOP_OPEN = "INTEGRAL_SHOP_OPEN";

	/**
	 * 风云争霸开关
	 */
	String FUNGWAN_OPEN = "FUNGWAN_OPEN";
	
	/**
	 * 灵翼入魂预热活动开关
	 */
	String NETHERWING_ACTIVITY_OPEN = "NETHERWING_ACTIVITY_OPEN";
	
	/**
	 * 充值返还活动开关
	 */
	String CHARGE_RETURN_ACTIVITY_OPEN = "CHARGE_RETURN_ACTIVITY_OPEN";
	
	/**
	 * 财富乐翻天活动总开关
	 */
	String DEPOSIT_ACTIVITY_OPEN = "DEPOSIT_ACTIVITY_OPEN";
	
	/**
	 * 财富乐翻天活动存款子开关
	 */
	String DEPOSIT_ACTIVITY_SAVE_MONEY_OPEN = "DEPOSIT_ACTIVITY_SAVE_MONEY_OPEN";
	
	/**
	 * 财富乐翻天活动取款子开关
	 */
	String DEPOSIT_ACTIVITY_REMOVE_MONEY_OPEN = "DEPOSIT_ACTIVITY_REMOVE_MONEY_OPEN";
	
	/**
	 * 帝王盛宴活动开关
	 */
	String MONARCH_FEAST_OPEN = "MONARCH_FEAST_OPEN";
	
}