package com.xx.dev.modules.champion.entity;

import java.util.Map;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.apache.commons.lang.StringUtils;
import org.codehaus.jackson.type.TypeReference;

import com.xx.common.db.cache.DbLoadInitializer;
import com.xx.common.db.model.BaseModel;
import com.xx.common.util.JsonUtils;


/**
 * 群雄争霸赛信息
 * 
 * @author bingshan
 */
@Entity
@Table(name = "championship")
public class Championship extends BaseModel<Integer> implements DbLoadInitializer {
	
	private static final long serialVersionUID = 797056450489539124L;

	/**
	 * 主键id
	 */
	@Id
	@Column(columnDefinition = "tinyint(4) not null comment '主键id'")
	private Integer id;
	
	/**
	 * 争霸赛日期
	 */
	@Column(columnDefinition="varchar(20) default '' comment '争霸赛日期'")
	private String championDay = "";
	
	/**
	 * 状态, 0-未计算 1-已计算  2-正在计算
	 */
	@Column(columnDefinition = "tinyint(4) default '0' comment '状态'")
	private Integer status = 0;
	
	/**
	 * 种子选手信息
	 */
	@Lob
	@Column(columnDefinition = "text comment '种子选手信息'")
	private String candidates = "";
	
	/**
	 * 已经初始化种子选手的日期
	 */
	@Column(columnDefinition="varchar(20) default '' comment '已经初始化种子选手的日期'")
	private String candidateDay = "";
	
	/**
	 * 第一名玩家id
	 */
	@Column(columnDefinition = "bigint(20) not null comment '第一名玩家id'")
	private Long topPlayerId = 0L;
	
	/**
	 * 种子选手Map {playerId: rank}
	 */
	@Transient
	private Map<Long, Integer> playerRankMap;
	
	public static Championship valueOf(int id)  {
		Championship championship = new Championship();
		championship.id = id;
		return championship;
	}

	@Override
	public void doAfterLoad() {
		if (StringUtils.isBlank(this.candidates)) {
			return;
		}
		
		TypeReference<Map<Long, Integer>> valueTypeRef = new TypeReference<Map<Long, Integer>>() {};
		this.playerRankMap = JsonUtils.jsonString2Object(this.candidates, valueTypeRef);
	}


	@Override
	public Integer getId() {
		return this.id;
	}

	@Override
	public void setId(Integer id) {
		this.id = id;
	}

	public String getChampionDay() {
		return championDay;
	}

	public void setChampionDay(String championDay) {
		this.championDay = championDay;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getCandidates() {
		return candidates;
	}

	public void setCandidates(String candidates) {
		this.candidates = candidates;
	}

	public String getCandidateDay() {
		return candidateDay;
	}

	public void setCandidateDay(String candidateDay) {
		this.candidateDay = candidateDay;
	}

	public Map<Long, Integer> getPlayerRankMap() {
		return playerRankMap;
	}

	public void setPlayerRankMap(Map<Long, Integer> playerRankMap) {
		this.playerRankMap = playerRankMap;
	}

	public Long getTopPlayerId() {
		return topPlayerId;
	}

	public void setTopPlayerId(Long topPlayerId) {
		this.topPlayerId = topPlayerId;
	}

}
