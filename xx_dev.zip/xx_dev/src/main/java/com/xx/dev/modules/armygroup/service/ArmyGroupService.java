package com.xx.dev.modules.armygroup.service;

import java.util.Date;
import java.util.List;
import java.util.Set;

import org.apache.mina.util.ConcurrentHashSet;

import com.xx.dev.model.Result;
import com.xx.dev.model.RoleAttr;
import com.xx.dev.modules.armygroup.entity.ArmyGroup;
import com.xx.dev.modules.armygroup.model.ArmyGroupBuildingDto;
import com.xx.dev.modules.armygroup.model.ArmyGroupContributeDto;
import com.xx.dev.modules.armygroup.model.ArmyGroupDto;
import com.xx.dev.modules.armygroup.model.ArmyGroupMemberDto;
import com.xx.dev.modules.armygroup.model.ArmyGroupTechDto;
import com.xx.dev.modules.armygroup.model.ArmyGroupTechType;
import com.xx.dev.modules.player.entity.Player;
import com.xx.dev.modules.player.model.PlayerDto;
import com.xx.dev.modules.reward.result.ValueResultSet;

/**
 * 军团服务接口
 * 
 * @author Along
 *
 */
/**
 * @author Along
 *
 */
public interface ArmyGroupService {

	/**
	 * 进入军团界面
	 * @param playerId 玩家id
	 * @return
	 */
	public Result<ArmyGroupDto> enterArmyGroupAction(long playerId);
	
	/**
	 * 创建军团
	 * @param playerId 创建人id
	 * @param name 军团名称
	 * @param useGold 是否使用金币
	 * @return
	 */
	public Result<ValueResultSet> createArmyGroupAction(long playerId, String name, int useGold);
	
	/**
	 * 获取军团信息
	 * @param name 军团名称
	 * @return
	 */
	public Result<ArmyGroupDto> getArmyGroupAction(String name);
	
	/**
	 * 申请加入军团
	 * @param playerId 玩家id
	 * @param id 军团id
	 * @return
	 */
	public int applyJoinArmyGroupAction(long playerId, long id);
	
	/**
	 * 获取军团申请列表
	 * @param playerId 审批人id
	 * @return
	 */
	public List<PlayerDto> getArmyGroupApplyListAction(long playerId);
	
	/**
	 * 获取已经申请的军团列表
	 * @param playerId 申请人id
	 * @return
	 */
	public List<ArmyGroupDto> getApplyListAction(long playerId);
	
	/**
	 * 批准申请
	 * @param playerId 批准人id
	 * @param applyId 申请id
	 * @return
	 */
	public int approveApplyAction(long playerId, long applyId);
	
	/**
	 * 拒绝申请
	 * @param playerId 批准人id
	 * @param applyId 申请id
	 * @return
	 */
	public int refuseApplyAction(long playerId, long applyId);
	
	/**
	 * 邀请加入军团
	 * @param playerId 发送邀请的玩家id
	 * @param playerName 邀请接收人名称
	 * @return
	 */
	public int inviteJoinArmyGroupAction(long playerId, String playerName);
	
	/**
	 * 退出军团
	 * @param playerId 玩家id
	 * @return
	 */
	public int quitArmyGroupAction(long playerId);
	
	/**
	 * 发送招贤榜
	 * @param playerId 发送者id
	 * @param content 内容
	 * @return
	 */
	public int advertiseAction(long playerId, String content);
	
	/**
	 * 修改军团宣言
	 * @param playerId 修改人id
	 * @param content 内容
	 * @return
	 */
	public Result<ArmyGroupDto> updateDeclarationAction(long playerId, String content);
	
	/**
	 * 购买虎符
	 * @param playerId 玩家id
	 * @param amount 数量
	 * @param useGold 是否使用金币
	 * @return
	 */
	public Result<ValueResultSet> buyHufuAction(long playerId, int amount, int useGold);
	
	/**
	 * 获取军团成员列表
	 * @param playerId 玩家id
	 * @return
	 */
	public List<ArmyGroupMemberDto> getArmyGroupMembersAction(long playerId);
	
	/**
	 * 领取粮草福利
	 * @param playerId 玩家id
	 * @return
	 */
	public Result<ValueResultSet> receiveFoodsAction(long playerId);
	
	/**
	 * 领取武将经验福利
	 * @param playerId 玩家id
	 * @return
	 */
	public Result<ValueResultSet> receiveHeroSoulAction(long playerId);
	
	/**
	 * 升|降职
	 * @param playerId 管理员id
	 * @param userId 被操作的团员id
	 * @param positionId 新的职位id
	 * @return
	 */
	public Result<ArmyGroupMemberDto> changePositionAction(long playerId, 
			long userId, int positionId);
	
	/**
	 * 踢人
	 * @param playerId 管理员id
	 * @param userId 被踢出的人id
	 * @param reason 原因
	 * @return
	 */
	public Result<ArmyGroupDto> kickOutSomeOneAction(long playerId, long userId,
			String reason);
	
	/**
	 * 转让团长
	 * @param playerId 团长id
	 * @param userId 新团长的id
	 * @return
	 */
	public Result<ArmyGroupDto> transferChiefAction(long playerId, long userId);

	/**
	 * 购买军团商城商品
	 * @param playerId 玩家id
	 * @param goodsId 商品id
	 * @param amount 数量
	 * @return
	 */
	public Result<ValueResultSet> buyGoodsAction(long playerId, int goodsId, int amount);

	/**
	 * 获取军团建筑列表
	 * @param playerId 玩家id
	 * @return
	 */
	public List<ArmyGroupBuildingDto> getArmyGroupBuildingsAction(long playerId);

	/**
	 * 取消加入军团申请
	 * @param playerId 玩家id
	 * @param id 军团id
	 * @return
	 */
	public int cancelApplyAction(long playerId, long id);

	/**
	 * 捐赠虎符
	 * @param playerId 玩家id
	 * @param buildingId 建筑id
	 * @param useGold 是否自动购买（-1不自动购买；0自动用银元购买；1自动用元宝购买）
	 * @return
	 */
	public Result<ValueResultSet> contributeHufuAction(long playerId, int buildingId, int useGold);

	/**
	 * 获取捐赠列表
	 * @param playerId 玩家id
	 * @return
	 */
	public List<ArmyGroupContributeDto> getArmyGroupContributesAction(long playerId);
	
	/**
	 * 军团科技升级
	 * @param playerId 玩家id
	 * @param techId 军团科技id
	 * @return
	 */
	public Result<ArmyGroupMemberDto> upgradeArmyGroupTechAction(long playerId, int techId);

	/**
	 * 获取军团科技列表
	 * @param playerId 玩家id
	 * @return
	 */
	public List<ArmyGroupTechDto> getPlayerArmyGroupTechsAction(long playerId);
	
	/**
	 * 弹劾团长
	 * @param playerId 提成弹劾的人的id
	 * @return
	 */
	public Result<ArmyGroupDto> delateChiefAction(long playerId);

	/**
	 * 同意所有申请
	 * @param playerId 批准人id
	 * @return
	 */
	public int approveApplysAction(long playerId);
	
	/**
	 * 拒绝所有申请
	 * @param playerId 批准人id
	 * @return
	 */
	public int refuseApplysAction(long playerId);
	
	/**
	 * 修改军团公告
	 * @param playerId 修改人id
	 * @param content 内容
	 * @return
	 */
	public int updateNoticeAction(long playerId, String content);
	
	/**
	 * 获取军团信息
	 * @param playerId 玩家id
	 * @return
	 */
	public ArmyGroupDto getArmyGroupDtoAction(long playerId);
	
	/**
	 * 清除冷却时间
	 * @param playerId 玩家id
	 * @return
	 */
	public Result<ValueResultSet> clearCoolTimeAction(long playerId);
	
	/**
	 * 分页获取军团列表
	 * @param startIndex 开始序号
	 * @param fetchCount 数量
	 * @return
	 */
	public Result<List<ArmyGroupDto>> getArmyGroupsAction(int startIndex,
			int fetchCount);

	/**
	 * 随机获取军团列表
	 * @param fetchCount 数量
	 * @return
	 */
	public List<ArmyGroupDto> getRandArmyGroupsAction(int fetchCount);
	
	/**
	 * 查找军团
	 * @param name 军团名称
	 * @return
	 */
	public List<ArmyGroupDto> searchArmyGroupsAction(String name);

	//-------------------------------------------------------------
	
	/**
	 * 获取军团列表
	 * @return
	 */
	public List<ArmyGroupDto> getArmyGroups();
	
	/**
	 * 获取军团科技属性
	 * @param playerId 玩家id
	 * @return
	 */
	public RoleAttr getArmyGroupTechAttr(long playerId);

	/**
	 * 获取军团科技Attr
	 * @param playerId 玩家id
	 * @param armyGroupTechType 科技类型(非战斗类型)
	 * @return
	 */
	public double getArmyGroupTechAttr(long playerId, ArmyGroupTechType armyGroupTechType);

	/**
	 * 获取军团信息
	 * @param player 玩家
	 * @return
	 */
	public ArmyGroupDto getArmyGroupDto(Player player);

	/**
	 * 检查能否发送军团邮件
	 * @param playerId 玩家id
	 * @return
	 */
	public ArmyGroup checkSendArmyGroupEmail(long playerId);

	/**
	 * 获取军团成员id列表
	 * @param playerId 玩家id
	 * @return
	 */
	public ConcurrentHashSet<Long> getPlayerArmyGroupMemberIds(long playerId);
	
	/**
	 * 获取军团成员列表
	 * @param armyGroupId 军团id
	 * @return
	 */
	public List<ArmyGroupMemberDto> getArmyGroupMemberDtos(long armyGroupId);

	/**
	 * 获取军团建筑列表
	 * @param armyGroupId 军团id
	 * @return
	 */
	public List<ArmyGroupBuildingDto> getArmyGroupBuildingDtos(long armyGroupId);

	/**
	 * 获取玩家的军团等级
	 * @param playerId 玩家id
	 * @return
	 */
	public int getPlayerArmyGroupLevel(long playerId);

	/**
	 * 军团改名
	 * @param playerId 玩家id
	 * @param content 军团名称
	 * @return
	 */
	public int renameAction(long playerId, String content);

	/**
	 * 推送有军团邮件
	 * @param armyGroupId 军团id
	 */
	public void pushNewMail(long armyGroupId);

	/**
	 * 能否接收军团邮件
	 * @param playerId 玩家id
	 * @param armyGroupId 军团id
	 * @param mailSendTime 邮件发送时间
	 * @return
	 */
	public boolean canReceiveMail(long playerId, long armyGroupId, Date mailSendTime);
	
	/**
	 * 获取军团成员id列表
	 * @param armyGroupId 军团id
	 * @return Set<Long>
	 */
	public Set<Long> getArmyGroupMemberIdList(long armyGroupId);

	/**
	 * 获取军团建筑等级
	 * @param armyGroupId 军团id
	 * @param buildingId 建筑编号
	 * @return
	 */
	public int getArmyGroupBuildingLevel(long armyGroupId, int buildingId);

	/**
	 * 返回武馆增加的血量比例（决战长安用）
	 * @param armyGroupId 军团id
	 * @return
	 */
	public double getKungFuSchoolHpAddRate(long armyGroupId);

	/**
	 * 获取军团信息
	 * @param armyGroupId 军团id
	 * @return
	 */
	public ArmyGroupDto getArmyGroupDto(long armyGroupId);
	
	/**
	 * 获取军团id
	 * @param playerId 玩家id
	 * @return
	 */
	public long getArmyGroupId(long playerId);

}
