package com.xx.dev.modules.armygrouptrain.service.impl;

import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.xx.common.basedb.BasedbAdapter;
import com.xx.dev.constant.GameRuleID;
import com.xx.dev.constant.IndexName;
import com.xx.dev.modules.armygrouptrain.model.basedb.TrainAreaConfig;
import com.xx.dev.modules.armygrouptrain.model.basedb.TrainArmy;
import com.xx.dev.modules.armygrouptrain.service.ArmyGroupTrainRuleService;
import com.xx.dev.utils.GameRuleService;

@Component
public class ArmyGroupTrainRuleServiceImpl extends BasedbAdapter implements ArmyGroupTrainRuleService{

	/**
	 * 第一關id
	 */
	private static int firstAreaId = 0;
	
	private final Map<Integer, List<Integer>> areaBatches = new ConcurrentHashMap<Integer, List<Integer>>();
	
	@Autowired
	private GameRuleService gameRuleService;
	
	@Override
	public Class<?>[] listenedClass() {
		return new Class[]{TrainAreaConfig.class, TrainArmy.class};
	}

	@Override
	public void initialize() {
		
		firstAreaId = 0;
		
		List<TrainAreaConfig> areaList = 
				basedbService.listAll(TrainAreaConfig.class);
		
		if(!CollectionUtils.isEmpty(areaList)){
			
			Collections.sort(areaList, new Comparator<TrainAreaConfig>() {
				@Override
				public int compare(TrainAreaConfig o1, TrainAreaConfig o2) {
					return o1.getSort() > o2.getSort() ? 1 : -1;
				}
			});
			
			firstAreaId = areaList.get(0).getId();
			
			int size = areaList.size() - 1;
			
			for(int i = 0; i < areaList.size(); i++){
				TrainAreaConfig previous = areaList.get(i);
				if(i >= size){
					break;
				}
				TrainAreaConfig next = areaList.get(i + 1);
				next.setPreAreaId(previous.getId());
				previous.setNextAreaId(next.getId());
			}
		}
		
		areaBatches.clear();
		
		List<TrainArmy> armyList = 
				basedbService.listAll(TrainArmy.class);
		if(!CollectionUtils.isEmpty(armyList)){
			
			Map<Integer, List<Integer>> tempBatches = new HashMap<Integer, List<Integer>>();
			for(TrainArmy army : armyList){
				List<Integer> batches = tempBatches.get(army.getAreaId());
				if(batches == null){
					batches = new LinkedList<Integer>();
					tempBatches.put(army.getAreaId(), batches);
				}
				batches.add(army.getBatch());
			}
			
			for(Entry<Integer, List<Integer>> entry : tempBatches.entrySet()){
				List<Integer> temp = entry.getValue();
				if(temp != null){
					Collections.sort(temp);
					List<Integer> batches = new CopyOnWriteArrayList<Integer>();
					batches.addAll(temp);
					areaBatches.put(entry.getKey(), batches);
				}
			}
		}
	}

	@Override
	public TrainAreaConfig getTrainArea(int areaId) {
		return basedbService.get(TrainAreaConfig.class, areaId);
	}

	@Override
	public TrainArmy getTrainArmy(int areaId, int batch) {
		return basedbService.getByUnique(TrainArmy.class, IndexName.ARMY_GROUP_TRAIN_AREA_INDEX, areaId, batch);
	}

	@Override
	public TrainArmy getNextTrainArmy(int areaId, int batch) {
		
		if(areaId <= 0){
			areaId = firstAreaId;
		}
		
		TrainAreaConfig area = getTrainArea(areaId);
		if(area == null){
			return null;
		}
		
		List<Integer> batches = areaBatches.get(areaId);
		if(batches == null || batches.size() == 0){
			return null;
		}
		
		if(batch <= 0){
			batch = batches.get(0);
		}
		else{
			int next = batches.indexOf(batch) + 1;
			if(next >= batches.size()){
				areaId = area.getNextAreaId();
				if(areaId <= 0){
					return null;
				}
				batches = areaBatches.get(areaId);
				if(batches == null || batches.size() == 0){
					return null;
				}
				batch = batches.get(0);
			}
			else{
				batch = batches.get(next);
			}
		}
		return getTrainArmy(areaId, batch);
	}

	@Override
	public long getDieCoolTime() {
		return gameRuleService.getAmountByID(GameRuleID.ARMY_GROUP_TRIAN_DIE_COOL_TIME).longValue();
	}

	@Override
	public long getBattleCoolTime() {
		return gameRuleService.getAmountByID(GameRuleID.ARMY_GROUP_TRIAN_BATTLE_COOL_TIME).longValue();
	}

}
