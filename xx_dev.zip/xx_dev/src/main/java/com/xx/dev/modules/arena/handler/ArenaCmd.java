package com.xx.dev.modules.arena.handler;

import com.xx.dev.modules.arena.model.PlayerArenaDto;
import com.xx.dev.modules.arena.model.PlayerRankDto;
import com.xx.dev.modules.battle.model.BattleResult;
import com.xx.dev.modules.hero.model.PlayerBattleLineupDto;
import com.xx.dev.modules.player.model.PlayerDto;
import com.xx.dev.modules.reward.result.ValueResultSet;


/**
 * 竞技场cmd
 * 
 * @author bingshan
 */
public interface ArenaCmd {
	
	/**
	 * 取得本人的竞技场信息
	 * @return {@link PlayerArenaDto}
	 */
	final int GET_MY_ARENA_INFO = 1;
	
	/**
	 * 取得玩家可挑战的玩家信息列表
	 * @return Map {"playerRankList":List<{@link PlayerRankDto}>
	 * 				"playerArenaDto": PlayerArenaDto
	 * 				}
	 *  
	 */
	final int GET_CHALLENGE_LIST = 2;
	
	/**
	 * 发起挑战
	 * @param rank 挑战名次(Integer)
	 * @return Map {"result":int {@link ArenaResult}
	 * 				"battleResult": 战报 {@link BattleResult}
	 * 				"valueResultSet": {@link ValueResultSet}
	 * 				"isWin":0-否  1-是
	 * 				}
	 */
	final int CHALLENGE = 3;
	
	/**
	 * 翻牌
	 * @param useGold 是否使用元宝领取 (Integer) 0-否 1-是
	 * @return Map {"result":int {@link ArenaResult}
	 *  			"valueResultSet": {@link ValueResultSet}
	 *  			"rewarded":已领取的奖励串
	 *  			"unRewarded":未领取的奖励串
	 *  			"vipSaved":vip节省值	
	 *  			}
	 */
	final int TURN_CARD = 4;
	
	/**
	 * 消除冷却CD
	 * @return Map {"result":int {@link ArenaResult}
	 *  			"valueResultSet": {@link ValueResultSet}
	 *  			"playerArenaDto": PlayerArenaDto
	 *  			"vipSaved":vip节省值	
	 *  			}
	 */
	final int ELIMINATE_CD = 5;
	
	/**
	 * 购买次数
	 * @param count 购买次数 (Integer)
	 * @return Map {"result":int {@link ArenaResult}
	 *  			"valueResultSet": {@link ValueResultSet}
	 *  			"playerArenaDto": PlayerArenaDto
	 *  			"realCount":实际购买次数
	 *  			"vipSaved":vip节省值	
	 *  			}
	 */
	final int BUY_COUNT = 6;
	
	/**
	 * 领取宝箱奖励
	 * @return Map {"result":int {@link ArenaResult}
	 *  			"valueResultSet": {@link ValueResultSet}
	 *  			}
	 */
	final int FETCH_BOX = 7;
	
	/**
	 * 取得排行榜
	 * @return List<{@link PlayerRankDto}>
	 */
	final int GET_RANK_LIST = 8;
	
	/**
	 * 取得战斗记录
	 * @return Map{"firstRanks":List<FirstRankDto> 第一名争夺记录
	 *  		   "challenges": List<ChallengeDto> 个人挑战记录
	 *  			}
	 */
	final int GET_CHALLENGE_HIS_LIST = 9;
	
	/**
	 * 侦查玩家阵型
	 * @param playerId {@link Long} 玩家id
	 * @return Map {
	 * 				"result" : {@link ArenaResult}
	 * 				"content" : {@link PlayerDto} 主公信息
	 * 				"playerBattleLineupDto" : {@link PlayerBattleLineupDto} 阵型信息
	 * 				"valueResultSet": {@link ValueResultSet}
	 * 				"vipSaved":vip节省值	
	 * 				}
	 */
	final int SPY = 10;
	
	/**
	 * 挑战NPC
	 * @param npcId NPC id(Integer)
	 * @return Map {"result":int {@link ArenaResult}
	 * 				"battleResult": 战报 {@link BattleResult}
	 * 				"valueResultSet": {@link ValueResultSet}
	 * 				"isWin":0-否  1-是
	 * 				}
	 */
	final int CHALLENGE_NPC = 11;
	
	/**
	 * 取得日排行榜信息
	 * @param days 需要取哪几天
	 * @return List<DayRankRewardDto>
	 */
	final int GET_DAY_RANKS = 12;
	
	/**
	 * 取得日排行榜奖励
	 * @param day 第几天
	 * @param rank 第几名
	 * @return Map {"result":int {@link ArenaResult}
	 * 				"valueResultSet": {@link ValueResultSet}
	 * 				}
	 */
	final int GET_DAY_RANK_REWARD = 13;
	
	/**
	 * 取得结算第一名玩家信息
	 * @return ArenaTopPlayerDto
	 */
	final int GET_BALANCE_TOP_PLAYER = 14;
	
	/**
	 * 推送挑战战斗记录
	 * @return Map {"type":0-第一名争夺记录  1-个人记录
	 * 				"firstRankDto":FirstRankDto
	 * 				"challengeDto":ChallengeDto
	 * 				}
	 */
	final int PUSH_CHALLENGE = 1001;
	
	/**
	 * 推送竞技场排名结算
	 * @return Map {"rank":个人排名
	 * 				"boxId":箱子id
	 * 				}
	 */
	final int PUSH_BALANCE = 1002;

}
