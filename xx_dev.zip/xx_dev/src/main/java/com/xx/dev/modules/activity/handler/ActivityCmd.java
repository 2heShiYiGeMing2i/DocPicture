package com.xx.dev.modules.activity.handler;

import com.xx.dev.modules.activity.model.PlayerActivityTaskDto;
import com.xx.dev.modules.reward.result.ValueResultSet;


/**
 * 活动系统cmd
 * 
 * @author bingshan
 */
public interface ActivityCmd {

	/**
	 * 取得玩家活动任务列表
	 * @param activityId 活动id
	 * @return List<PlayerActivityTaskDto>
	 */
	final int GET_ACTIVITY_TASK_LIST = 1;
	
	/**
	 * 接受活动任务
	 * @param taskIds 活动任务id数组
	 * @return Map数组, 其中  Map{"result":int {@link ActivityResult}
	 * 							"taskId":活动任务id
	 * 							"content": {@link PlayerActivityTaskDto}
	 * 							}
	 */
	final int RECEIVE_ACTIVITY_TASK = 2;
	
	/**
	 * 领取活动任务奖励
	 * @param taskId (Integer) 活动任务id
	 * @return Map {"result":int {@link ActivityResult}
	 * 				"taskId":活动任务id
	 * 				"content": {@link ValueResultSet}
	 * 				"taskDto":{@link PlayerActivityTaskDto}
	 * 				}
	 */
	final int GET_ACTIVITY_TASK_REWARD = 3;
	
	/**
	 * 取得玩家活动任务列表
	 * @param 活动id列表（直接传数组）
	 * @return Map<Integer, List<PlayerActivityTaskDto>> 
	 */
	final int GET_ACTIVITYS_TASK_LIST = 4;
	
}
