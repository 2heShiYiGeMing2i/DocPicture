package com.xx.dev.modules.armygroup.event;

import com.xx.common.event.Event;

/**
 * 军团升级（捐赠）事件
 * 
 * @author Along
 *
 */
public class ArmyGroupUpgradeEvent {

	/**
	 * 事件名称
	 */
	public static String NAME = "ArmyGroup:upgrade";
	
	/**
	 * 军团id
	 */
	private long id;
	
	/**
	 * 军团等级
	 */
	private int level;
	
	/**
	 * 完成度
	 */
	private int progress;
	
	public static Event<ArmyGroupUpgradeEvent> valueOf(long id, int level, 
			int progress) {
		ArmyGroupUpgradeEvent result = new ArmyGroupUpgradeEvent();
		result.setId(id);
		result.setLevel(level);
		result.setProgress(progress);
		return new Event<ArmyGroupUpgradeEvent>(NAME, result);
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

	public int getProgress() {
		return progress;
	}

	public void setProgress(int progress) {
		this.progress = progress;
	}
	
}
