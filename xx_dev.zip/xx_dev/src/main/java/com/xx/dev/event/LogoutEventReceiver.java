package com.xx.dev.event;

import java.util.Date;

import org.apache.mina.core.session.IoSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.xx.common.db.cache.DbCachedService;
import com.xx.common.event.AbstractReceiver;
import com.xx.common.event.EventBus;
import com.xx.common.log.LogHelper;
import com.xx.common.scheduling.ScheduledTask;
import com.xx.common.scheduling.Scheduler;
import com.xx.common.util.IpUtils;
import com.xx.dev.constant.AdultStatus;
import com.xx.dev.constant.SessionKeys;
import com.xx.dev.modules.arena.service.ArenaService;
import com.xx.dev.modules.journey.service.JourneyService;
import com.xx.dev.modules.loop.service.LoopService;
import com.xx.dev.modules.manpass.service.ManpassService;
import com.xx.dev.modules.multifuben.service.MultiFubenService;
import com.xx.dev.modules.player.entity.Player;
import com.xx.dev.modules.player.service.MainCityService;
import com.xx.dev.modules.player.service.PlayerService;
import com.xx.dev.modules.plunderfood.service.PlunderFoodService;
import com.xx.dev.modules.server.SanguohunServer;
import com.xx.dev.modules.server.SessionManager;
import com.xx.dev.utils.FCMHelper;

@Component
public class LogoutEventReceiver extends AbstractReceiver<LogoutEvent> {

	@Autowired
	private Scheduler scheduler;
	@Autowired
	private SessionManager sessionManager;
	@Autowired
	private DbCachedService dbCachedService;
	@Autowired
	private PlayerService playerService;
	@Autowired
	private ArenaService arenaService;
	@Autowired
	private JourneyService journeyService;
	@Autowired
	private EventBus eventBus;
	@Autowired
	private FCMHelper fcmHelper;
	@Autowired
	private ManpassService manpassService;
	@Autowired
	private SanguohunServer server;
	@Autowired
	private PlunderFoodService plunderFoodService;
	@Autowired
	private LoopService loopService;
	@Autowired
	private MultiFubenService multiFubenService;
	@Autowired
	private MainCityService mainCityService;
	@Autowired
	private LogHelper logHelper;
	
	/**
	 * 延时处理的时长
	 */
	private final long DELAY_INTERVALS = 120 * 1000;
	
	@Override
	public String[] getEventNames() {
		return new String[] {LogoutEvent.NAME};
	}

	@Override
	public void doEvent(LogoutEvent event) {
		if (event == null) {
			log.error("'{}' 事件消息体为 NULL", LogoutEvent.NAME);
			return;
		}
		IoSession session = event.getSession();
		long playerId = event.getPlayerId();
		
		this.doLogoutImmediately(playerId, session);
		
		//服务器正在关闭或者已经关闭
		if (this.server.isClosing() || !this.server.isRunning()) {
			doLogoutWithDelay(playerId, session);
		} else {
			this.scheduleLougout(playerId, session);
		}		
		
		String address = IpUtils.getRemoteIp(session);
		this.logHelper.logLogout(event.getLogoutTime(), playerId, address, session.getId());
	}

	/**
	 * 需要立即处理的登出
	 * @param playerId
	 * @param session
	 */
	private void doLogoutImmediately(final long playerId, final IoSession session){
		//征战天下
		journeyService.clearHook(playerId);
	}
	
	/**
	 * 需要延迟处理的登出
	 * @param playerId
	 * @param session
	 */
	private void doLogoutWithDelay(final long playerId, final IoSession session){
		//竞技场
		this.arenaService.playerLogout(playerId);
		//一夫当关
		this.manpassService.playerLogout(playerId);
				
		// 计算在线时间
		this.playerService.calculatePlayerOnlineTime(playerId, new Date());
		
		Player player = dbCachedService.get(playerId, Player.class);
		//防沉迷
		AdultStatus adultStatus = (AdultStatus)session.getAttribute(SessionKeys.ADULT_STATUS, AdultStatus.UNKOWN);
		if(adultStatus != AdultStatus.ADULT){//不是成年人才通知防沉迷
			fcmHelper.sendLogout(player.getUserName());
		}
		
		//军团抢粮
		plunderFoodService.userLogout(playerId);
		
		//富甲天下
		loopService.userLogout(playerId);
		
		//多人副本离开场景
		this.multiFubenService.leftScene(playerId);
		
		//离开主城场景
		this.mainCityService.leftCity(playerId);
	}
	
	/**
	 * 处理需要延时操作的事情
	 */
	private void scheduleLougout(final long playerId, final IoSession session) {
		this.scheduler.scheduleWithDelay(new ScheduledTask() {

			@Override
			public void run() {
				// 玩家不在线
				if (!sessionManager.isOnline(playerId)) {
					doLogoutWithDelay(playerId, session);
				}
			}

			@Override
			public String getName() {
				return "玩家登出时延时操作任务";
			}
			
		}, DELAY_INTERVALS);
	}

}
