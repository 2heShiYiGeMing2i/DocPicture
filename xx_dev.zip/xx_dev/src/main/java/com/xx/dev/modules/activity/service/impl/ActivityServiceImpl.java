package com.xx.dev.modules.activity.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.ArrayUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.xx.common.utility.lock.ChainLock;
import com.xx.common.utility.lock.LockUtils;
import com.xx.dev.model.Result;
import com.xx.dev.modules.activity.entity.PlayerActivity;
import com.xx.dev.modules.activity.entity.PlayerActivityTask;
import com.xx.dev.modules.activity.handler.ActivityResult;
import com.xx.dev.modules.activity.model.PlayerActivityTaskDto;
import com.xx.dev.modules.activity.model.basedb.Activity;
import com.xx.dev.modules.activity.model.basedb.ActivityTask;
import com.xx.dev.modules.activity.service.ActivityRuleService;
import com.xx.dev.modules.activity.service.ActivityService;
import com.xx.dev.modules.opencontrol.event.OpenControlEvent;
import com.xx.dev.modules.opencontrol.service.OpenControlService;
import com.xx.dev.modules.player.entity.Player;
import com.xx.dev.modules.reward.result.ValueResultSet;
import com.xx.dev.modules.server.SessionManager;
import com.xx.dev.modules.task.constant.TaskStatus;
import com.xx.dev.modules.task.service.impl.TaskServiceImpl;
import com.xx.dev.modules.task.support.TaskHelper;
import com.xx.dev.utils.CommonRule;

/**
 * 活动系统服务接口实现
 * 
 * @author bingshan
 */
@Component
public class ActivityServiceImpl extends TaskServiceImpl<PlayerActivityTask, ActivityTask, PlayerActivityTaskDto> implements ActivityService {

	@Autowired
	private ActivityRuleService activityRuleService;
	@Autowired
	private OpenControlService openControlService;
	@Autowired
	protected TaskHelper taskHelper;
	@Autowired
	private SessionManager sessionManager;

	@Override
	public ActivityTask getTask(int taskId) {
		return this.activityRuleService.getActivityTask(taskId);
	}

	@Override
	public PlayerActivityTask getPlayerTask(long playerId, int taskId) {
		String id = PlayerActivityTask.getPlayerTaskId(playerId, taskId);
		return this.dbCachedService.get(id, PlayerActivityTask.class);
	}

	@Override
	public PlayerActivity getPlayerActivity(long playerId, int activityId) {
		Player player = this.dbCachedService.get(playerId, Player.class);
		if (player == null) {
			return null;
		}
		
		Activity activity = this.activityRuleService.getActivity(activityId);
		if (activity == null || !activity.isTaskActivity()) {//不是任务活动
			return null;
		}
	
		String id = PlayerActivity.getPlayerActivityId(playerId, activityId);
		PlayerActivity playerActivity = this.dbCachedService.get(id, PlayerActivity.class);
		if (playerActivity == null) {
			Date now = new Date();
			boolean activityOpened = this.openControlService.isOpen(activity.getOpenId(), now);
			
			playerActivity = PlayerActivity.valueOf(id, playerId, activityId);
			playerActivity.setStatus(activityOpened ? 1 : 0);
			playerActivity = this.dbCachedService.submitNew2Queue(playerActivity);
		}		
		return playerActivity;
	}

	@Override
	public Result<PlayerActivityTaskDto> receiveTask(long playerId, int taskId) {
		Player player = this.dbCachedService.get(playerId, Player.class);
		if (player == null) {
			return Result.Error(ActivityResult.PLAYER_NOT_EXISTS);
		}
		
		ActivityTask activityTask = this.getTask(taskId);
		if (activityTask == null) {
			return Result.Error(ActivityResult.BASE_DATA_NOT_EXIST);
		}
		
		if (player.getOnlyVipLevel() < activityTask.getOpenVip()) {
			return Result.Error(ActivityResult.VIP_LEVEL_NO_ENOUGH);
		}
		
		int activityId = activityTask.getActivityId();
		Activity activity = this.activityRuleService.getActivity(activityId);
		if (activity == null) {
			return Result.Error(ActivityResult.BASE_DATA_NOT_EXIST);
		}
		if (!activity.isTaskActivity()) {
			return Result.Error(ActivityResult.NOT_ACTIVITY_TASK);
		}
		
		PlayerActivity playerActivity = this.getPlayerActivity(playerId, activityId);
		if (playerActivity == null || !playerActivity.isOpened()) {
			return Result.Error(ActivityResult.ACTIVITY_NOT_OPENED);
		}
		
		return super.receiveTask(playerId, taskId);
	}
	
	@Override
	public Result<ValueResultSet> getTaskReward(long playerId, int taskId) {
		ActivityTask activityTask = this.getTask(taskId);
		if (activityTask == null) {
			return Result.Error(ActivityResult.BASE_DATA_NOT_EXIST);
		}
		
		PlayerActivity playerActivity = this.getPlayerActivity(playerId, activityTask.getActivityId());
		if (playerActivity == null || !playerActivity.isOpened()) {
			return Result.Error(ActivityResult.ACTIVITY_NOT_OPENED);
		}
		
		return super.getTaskReward(playerId, taskId);
	}

	@Override
	protected void doAfterTaskRewardInLock(PlayerActivityTask playerTask, ActivityTask task) {
		//日常任务
		if (task.isDailyTask()) {
			//判断是否跨天
			if (CommonRule.isSameResetTime(playerTask.getRewardTime())) {
				playerTask.setRewardedCount(1);
			} else {
				playerTask.setRewardedCount(playerTask.getRewardedCount() + 1);
			}
		} else {
			playerTask.setRewardedCount(playerTask.getRewardedCount() + 1);
		}
		
		playerTask.setRewardTime(new Date());
		
		//已做完次数
		if (playerTask.getRewardedCount() >= task.getCount()) {
			return;
		}

		this.taskHelper.initTaskProgress(playerTask, task);
	}

	@Override
	public List<PlayerActivityTask> getPlayerActivityTasks(long playerId, int activityId) {
		Player player = this.dbCachedService.get(playerId, Player.class);
		if (player == null) {
			return null;
		}
		return getPlayerActivityTasks(player, activityId);
	}

	private List<PlayerActivityTask> getPlayerActivityTasks(Player player, int activityId) {
		List<ActivityTask> tasks = this.activityRuleService.getActivityTaskList(activityId);
		if (tasks == null || tasks.isEmpty()) {
			return null;
		}
		
		List<PlayerActivityTask> result = new ArrayList<PlayerActivityTask>(tasks.size());
		for (ActivityTask task: tasks) {
			if (player.getLevel() < task.getOpenLevel()) {
				continue;
			}
			if (player.getOnlyVipLevel() < task.getOpenVip()) {
				continue;
			}
			
			int taskId = task.getId();
			PlayerActivityTask pat = this.getPlayerTask(player.getId(), taskId);
			if (pat == null) {				
				Result<PlayerActivityTaskDto> receivedResult = this.receiveTask(player.getId(), taskId);
				Integer receivedCode = (Integer) receivedResult.get(Result.CODE);
				if (receivedCode != null && receivedCode == ActivityResult.SUCCESS) {
					pat = this.getPlayerTask(player.getId(), taskId);
				}
			}
			
			if (pat != null) {
				result.add(pat);
			}
		}
		return result;
	}
	
	@Override
	public Map<Integer, List<PlayerActivityTaskDto>> getPlayerActivityTasks(long playerId, int[] activityIds) {
		Map<Integer, List<PlayerActivityTaskDto>> result = null;
		Player player = this.dbCachedService.get(playerId, Player.class);
		if (player == null) {
			return result;
		}
		if (ArrayUtils.isEmpty(activityIds)) {
			return result;
		}
		result = new HashMap<Integer, List<PlayerActivityTaskDto>>();
		for (int activityId : activityIds) {
			List<PlayerActivityTask> playerActivityTasks = this.getPlayerActivityTasks(player, activityId);
			if (CollectionUtils.isNotEmpty(playerActivityTasks)) {
				result.put(activityId, PlayerActivityTaskDto.valueOf(playerActivityTasks));
			}
		}
		return result;
	}
	
	/**
	 * 取得任务活动列表
	 * @return List<Activity>
	 */
	private List<Activity> getTaskActivitys() {
		return this.activityRuleService.getActivityListByType(1);
	}

	@Override
	public List<PlayerActivityTask> getPlayerTaskList(long playerId) {
		List<Activity> activitys = getTaskActivitys();
		if (activitys == null || activitys.isEmpty()) {
			return null;
		}
		
		List<PlayerActivityTask> result = new ArrayList<PlayerActivityTask>(30);
		
		for (Activity activity: activitys) {
			int activityId = activity.getId();
			PlayerActivity playerActivity = this.getPlayerActivity(playerId, activityId);
			if (playerActivity == null || !playerActivity.isOpened()) {
				continue;
			}
					
			List<PlayerActivityTask> pats = this.getPlayerActivityTasks(playerId, activityId);
			if (pats != null && !pats.isEmpty()) {
				result.addAll(pats);
			}
		}
		
		return result;
	}

	@Override
	protected Set<String> getPlayerTaskIds(long playerId) {
		return null;
	}

	@Override
	protected int checkPreTask(long playerId, int preTaskId) {
		return ActivityResult.SUCCESS;
	}

	@Override
	protected PlayerActivityTask valueOf(String id, long playerId, int taskId, TaskStatus taskStatus) {
		return new PlayerActivityTask(id, playerId, taskId, taskStatus);
	}

	@Override
	protected PlayerActivityTaskDto valueOf(PlayerActivityTask playerActivityTask) {
		return PlayerActivityTaskDto.valueOf(playerActivityTask);
	}

	@Override
	public void doIfAcrossDay(long playerId) {
		Player player = this.dbCachedService.get(playerId, Player.class);
		if (player == null) {
			return;
		}
		
		List<Activity> activitys = getTaskActivitys();
		if (activitys == null || activitys.isEmpty()) {
			return;
		}
		
		for (Activity activity: activitys) {
			doCheckActivityState(player, activity);
		}
	}
	
	/**
	 * 活动状态检查
	 * @param player Player
	 * @param activity Activity
	 */
	private void doCheckActivityState(Player player, Activity activity) {
		long playerId = player.getId();
		int activityId = activity.getId();
		
		PlayerActivity playerActivity = this.getPlayerActivity(playerId, activityId);
		if (playerActivity == null) {
			return;
		}
		
		//当前活动与开关活动是否是同一个活动
		boolean isSameActivity = false;
		
		ChainLock chainLock = LockUtils.getLock(player);
		chainLock.lock();
		try {
			boolean playerActivityChanged = false;
			Date now = new Date();
			//当前活动是否开启
			boolean activityOpened = this.openControlService.isOpen(activity.getOpenId(), now);
			if (activityOpened) {
				if (!playerActivity.isOpened()) {
					playerActivity.setStatus(1);
					playerActivityChanged = true;
				}
				
				//当前活动是否是同一个活动
				isSameActivity = this.openControlService.isActive(activity.getOpenId(), playerActivity.getReceiveTime());
				if (!isSameActivity) {
					playerActivity.setReceiveTime(now);
					playerActivityChanged = true;
				}				
			} else {
				if (playerActivity.isOpened()) {
					playerActivity.setStatus(0);
					playerActivityChanged = true;
				}
			}
			if (playerActivityChanged) {
				this.dbCachedService.submitUpdated2Queue(playerActivity.getId(), PlayerActivity.class);
			}
		} finally {
			chainLock.unlock();
		}
		
		//活动没开启
		if (!playerActivity.isOpened()) {
			return;
		}
		
		//活动任务处理
		this.doCheckActivityTasks(playerId, activityId, isSameActivity);
	}
	
	/**
	 * 玩家现有活动任务处理
	 * @param playerId 玩家id
	 * @param activityId 活动id
	 * @param isSameActivity  当前活动与开关活动是否是同一个活动
	 */
	private void doCheckActivityTasks(long playerId, int activityId, boolean isSameActivity) {
		List<PlayerActivityTask> pats = this.getPlayerActivityTasks(playerId, activityId);
		if (pats == null || pats.isEmpty()) {
			return;
		}
		
		Date now = new Date();
		
		for (PlayerActivityTask p: pats) {
			ActivityTask activityTask = this.getTask(p.getTaskId());
			if (activityTask == null) {
				continue;
			}
			
			ChainLock chainLock = LockUtils.getLock(p);
			chainLock.lock();
			try {				
				if (isSameActivity) {
					//非日常任务
					if (!activityTask.isDailyTask()) {
						continue;
					}
					
					//是否跨天
					if (!CommonRule.isSameResetTime(p.getRewardTime())) {
						continue;
					}
				}
				
				this.taskHelper.initTaskProgress(p, activityTask);
				p.setRewardedCount(0);
				p.setRewardTime(now);
				this.dbCachedService.submitUpdated2Queue(p.getId(), PlayerActivityTask.class);
			} finally {
				chainLock.unlock();
			}				
		}
	}

	@Override
	public void doIfAcrossDay() {
		Set<Long> onlinePlayerIds = this.sessionManager.getOnlinePlayerIdList();
		for (long playerId: onlinePlayerIds) {
			this.doIfAcrossDay(playerId);
		}
	}

	@Override
	public void doOpenControlEvent(OpenControlEvent event) {
		if (event == null) {
			return;
		}
		
		if (event.getOpenControl() == null) {
			return;
		}
		
		List<Activity> activitys = this.activityRuleService.getActivityListByOpen(event.getOpenControl().getId());
		if (activitys == null || activitys.isEmpty()) {
			return;
		}
		
		for (Activity activity: activitys) {
			Set<Long> onlinePlayerIds = this.sessionManager.getOnlinePlayerIdList();
			for (long playerId: onlinePlayerIds) {
				Player player = this.dbCachedService.get(playerId, Player.class);
				if (player == null) {
					continue;
				}
				
				doCheckActivityState(player, activity);
			}
		}
	}

}
