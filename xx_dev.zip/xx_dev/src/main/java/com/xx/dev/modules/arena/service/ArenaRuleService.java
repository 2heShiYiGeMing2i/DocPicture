package com.xx.dev.modules.arena.service;

import java.util.List;

import com.xx.dev.modules.arena.model.basedb.ArenaBox;
import com.xx.dev.modules.arena.model.basedb.ArenaCard;
import com.xx.dev.modules.arena.model.basedb.ArenaDayRank;
import com.xx.dev.modules.arena.model.basedb.ArenaNpc;


/**
 * 竞技场系统基础数据接口
 * 
 * @author bingshan
 */
public interface ArenaRuleService {
	
	/**
	 * 根据主键id取得竞技场宝箱
	 * @param id 主键id
	 * @return ArenaBox
	 */
	ArenaBox getArenaBox(int id);
	
	/**
	 * 根据排名取得竞技场宝箱
	 * @param rank 名次
	 * @return ArenaBox
	 */
	ArenaBox getArenaBoxByRank(int rank);
	
	/**
	 * 取得随机卡牌
	 * @return ArenaCard
	 */
	ArenaCard getRandomCards();
	
	/**
	 * 获取竞技场npc列表
	 * @param fetchCount 获取数量
	 * @return List<ArenaNpc>
	 */
	List<ArenaNpc> getArenaNpcList(int fetchCount);
	
	/**
	 * 获取ArenaNpc
	 * @param npcId 主键id
	 * @return ArenaNpc
	 */
	ArenaNpc getArenaNpc(int npcId);

	/**
	 * 竞技场结算奖励活动倍数
	 * @return int
	 */
	int getRewardActivityMultiple();
	
	/**
	 * 取得竞技场天排名奖励
	 * @param day 第几天
	 * @param rank 排名
	 * @return ArenaDayRank
	 */
	ArenaDayRank getArenaDayRank(int day, int rank);
	
	/**
	 * 竞技场天排名奖励最大天数
	 * @return int
	 */
	int getMaxDayOfDayRankReward();
	
	/**
	 * 竞技场天排名奖励最大排名
	 * @return int
	 */
	int getMaxRankOfDayRankReward();
}
