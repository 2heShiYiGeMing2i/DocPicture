package com.xx.dev.modules.armygrouptrain.model.basedb;

import java.util.ArrayList;
import java.util.List;

import com.xx.common.basedb.InitializeBean;
import com.xx.common.basedb.anno.Id;
import com.xx.common.basedb.anno.Index;
import com.xx.common.basedb.anno.Resource;
import com.xx.common.util.Splitable;
import com.xx.dev.constant.IndexName;

/**
 * 
 * 軍團試煉的軍隊配置
 * 
 * @author jy
 *
 */
@Resource
public class TrainArmy implements InitializeBean{
	
	/**
	 * 基礎數據id
	 */
	@Id
	private int id;
	
	/**
	 * 副本-一個關卡，包含試煉軍和boss等，屬於不同的批次
	 */
	@Index(name = IndexName.ARMY_GROUP_TRAIN_AREA_INDEX, order = 0)
	private int areaId;
	
	/**
	 * 批次，比如第一批是普通試煉軍，第二批是boss等
	 */
	@Index(name = IndexName.ARMY_GROUP_TRAIN_AREA_INDEX, order = 1)
	private int batch;
	
	/**
	 * 開始時生成的試煉軍數量
	 */
	private int sum;
	
	/**
	 * 試煉軍
	 */
	private String army;
	
	/**
	 * 玩家是否后手
	 */
	private int armyAttack;
	
	/**
	 * 主公名字
	 */
	private String npcName;
	
	/**
	 * 主公等级
	 */
	private int npcLevel;
	
	/**
	 * 主公图像
	 */
	private String npcPic;

	/**
	 * 擊殺軍隊的獎勵
	 */
	private String rewards;
	
	/**
	 * 擊殺軍隊的掉落獎勵
	 */
	private String drops;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getArmy() {
		return army;
	}

	public void setArmy(String army) {
		this.army = army;
	}

	public int getArmyAttack() {
		return armyAttack;
	}

	public void setArmyAttack(int armyAttack) {
		this.armyAttack = armyAttack;
	}

	public String getNpcName() {
		return npcName;
	}

	public void setNpcName(String npcName) {
		this.npcName = npcName;
	}

	public int getNpcLevel() {
		return npcLevel;
	}

	public void setNpcLevel(int npcLevel) {
		this.npcLevel = npcLevel;
	}

	public String getNpcPic() {
		return npcPic;
	}

	public void setNpcPic(String npcPic) {
		this.npcPic = npcPic;
	}

	public boolean isArmyAttack() {
		return armyAttack == 1;
	}

	public int getAreaId() {
		return areaId;
	}

	public void setAreaId(int areaId) {
		this.areaId = areaId;
	}

	public int getBatch() {
		return batch;
	}

	public void setBatch(int batch) {
		this.batch = batch;
	}

	public String getRewards() {
		return rewards;
	}

	public void setRewards(String rewards) {
		this.rewards = rewards;
	}

	public int getSum() {
		return sum;
	}

	public void setSum(int sum) {
		this.sum = sum;
	}

	public String getDrops() {
		return drops;
	}

	public void setDrops(String drops) {
		this.drops = drops;
	}

	private Integer[] armyIds = {};
	
	@Override
	public void afterPropertiesSet() {
		if(this.army == null || this.army.trim().length() == 0){
			return;
		}
		String[] armStrings = this.army.trim().split(Splitable.ELEMENT_SPLIT);
		List<Integer> armIntegers = new ArrayList<Integer>(armStrings.length);
		for (String string : armStrings) {
			armIntegers.add(Integer.valueOf(string));
		}
		this.armyIds = armIntegers.toArray(armyIds);
	}

}
