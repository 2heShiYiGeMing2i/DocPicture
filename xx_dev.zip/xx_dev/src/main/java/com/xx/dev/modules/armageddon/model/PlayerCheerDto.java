/**
 * @file:PlayerCheerDto.java
 * @author:David
 **/
package com.xx.dev.modules.armageddon.model;

import com.xx.dev.modules.player.entity.Player;

/**
 * @class:PlayerCheerDto
 * @description:大决战邀请助阵人信息
 * @author:David
 * @version:v1.0
 * @date:2013-5-21
 **/
public class PlayerCheerDto {
	public int state;				//何种关系 0-豪杰 1---好友  2---特殊豪杰 奖励功勋 = 好友
	public long playerId;			//助阵人ID
	public Integer headId = 0;      //主公头像id
	public String playerName;		//助阵人名字
	public int playerLevel = 0;        //助阵人等级
	public double ability = 0D;		//助阵人战斗力
	
	public PlayerCheerDto() {
		super();
	}

	public PlayerCheerDto(int state, Player player) {
		super();
		this.state = state;
		this.playerId = player.getId();
		this.headId = player.getHeadId();
		this.playerName = player.getPlayerName();
		this.playerLevel = player.getLevel();
		this.ability = player.getTotalAbility();
	}	
}

