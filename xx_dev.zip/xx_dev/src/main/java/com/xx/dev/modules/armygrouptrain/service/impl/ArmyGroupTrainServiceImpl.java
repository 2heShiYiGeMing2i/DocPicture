package com.xx.dev.modules.armygrouptrain.service.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.xx.common.basedb.BasedbService;
import com.xx.common.db.cache.DbCachedService;
import com.xx.common.scheduling.Scheduled;
import com.xx.common.scheduling.ValueType;
import com.xx.common.util.DatePattern;
import com.xx.common.util.DateUtil;
import com.xx.common.util.JsonUtils;
import com.xx.common.utility.lock.ChainLock;
import com.xx.common.utility.lock.LockUtils;
import com.xx.dev.config.Module;
import com.xx.dev.constant.BattleType;
import com.xx.dev.constant.BattleWaveID;
import com.xx.dev.constant.IndexName;
import com.xx.dev.constant.LogSource;
import com.xx.dev.model.Result;
import com.xx.dev.modules.armygroup.model.ArmyGroupBuildingType;
import com.xx.dev.modules.armygroup.model.basedb.ArmyGroupBuildingUpgrade;
import com.xx.dev.modules.armygroup.service.ArmyGroupService;
import com.xx.dev.modules.armygrouptrain.entity.ArmyGroupTrainInfo;
import com.xx.dev.modules.armygrouptrain.handler.ArmyGroupTrainCmd;
import com.xx.dev.modules.armygrouptrain.handler.ArmyGroupTrainResult;
import com.xx.dev.modules.armygrouptrain.model.ArmyDto;
import com.xx.dev.modules.armygrouptrain.model.ArmyVO;
import com.xx.dev.modules.armygrouptrain.model.TrainDto;
import com.xx.dev.modules.armygrouptrain.model.TrainPlayerDetailDto;
import com.xx.dev.modules.armygrouptrain.model.TrainPlayerDto;
import com.xx.dev.modules.armygrouptrain.model.TrainPlayerRankDto;
import com.xx.dev.modules.armygrouptrain.model.TrainPlayerRankVO;
import com.xx.dev.modules.armygrouptrain.model.TrainPlayerVO;
import com.xx.dev.modules.armygrouptrain.model.TrainStatus;
import com.xx.dev.modules.armygrouptrain.model.TrainVO;
import com.xx.dev.modules.armygrouptrain.model.basedb.TrainAreaConfig;
import com.xx.dev.modules.armygrouptrain.model.basedb.TrainArmy;
import com.xx.dev.modules.armygrouptrain.service.ArmyGroupTrainRuleService;
import com.xx.dev.modules.armygrouptrain.service.ArmyGroupTrainService;
import com.xx.dev.modules.battle.core.BattleWinner;
import com.xx.dev.modules.battle.model.BattleCharacter;
import com.xx.dev.modules.battle.model.BattleGroup;
import com.xx.dev.modules.battle.model.BattlePlayerInfo;
import com.xx.dev.modules.battle.model.BattleResult;
import com.xx.dev.modules.battle.model.BattleTeam;
import com.xx.dev.modules.battle.model.MultiBattleResult;
import com.xx.dev.modules.battle.service.BattleService;
import com.xx.dev.modules.chapter.service.ChapterRuleService;
import com.xx.dev.modules.chitchat.model.NoticeDto;
import com.xx.dev.modules.chitchat.model.NoticeId;
import com.xx.dev.modules.chitchat.model.NoticeKey;
import com.xx.dev.modules.chitchat.service.NoticeService;
import com.xx.dev.modules.drop.model.DropResult;
import com.xx.dev.modules.drop.service.DropService;
import com.xx.dev.modules.fashionequip.service.FashionEquipService;
import com.xx.dev.modules.honor.service.HonorService;
import com.xx.dev.modules.horse.service.HorseService;
import com.xx.dev.modules.netherwing.service.NetherwingService;
import com.xx.dev.modules.player.entity.Player;
import com.xx.dev.modules.player.service.PlayerService;
import com.xx.dev.modules.push.PushHelper;
import com.xx.dev.modules.reward.action.RewardActionSet;
import com.xx.dev.modules.reward.constant.InBagRule;
import com.xx.dev.modules.reward.model.Reward;
import com.xx.dev.modules.reward.result.ValueResultSet;
import com.xx.dev.modules.reward.service.RewardService;
import com.xx.dev.modules.reward.support.RewardHelper;

/**
 * 軍團試煉實現
 * @author jy
 *
 */
@Component
public class ArmyGroupTrainServiceImpl implements ArmyGroupTrainService{
	
	private static final Logger logger = LoggerFactory.getLogger(ArmyGroupTrainServiceImpl.class);
	
	private TrainStatus status = TrainStatus.NONE;;
	
	@Autowired
	private ArmyGroupTrainRuleService ruleService;
	
	@Autowired
	private BattleService battleService;
	
	@Autowired
	private RewardService rewardService;
	
	@Autowired
	private DropService dropService;
	
	@Autowired
	private ChapterRuleService chapterRuleService;
	
	@Autowired
	private DbCachedService dbCachedService;
	
	@Autowired
	private PlayerService playerService;
	
	@Autowired
	private PushHelper pushHelper;
	
	@Autowired
	private ArmyGroupService armyGroupService;
	
	@Autowired
	private HorseService horseService;
	
	@Autowired
	private NetherwingService netherwingService;
	
	@Autowired
	private FashionEquipService fashionEquipService;
	
	@Autowired
	private NoticeService noticeService;
	
	@Autowired
	private BasedbService basedbService;
	
	@Autowired
	private HonorService honorService;
	
	/**
	 * 活動開始時間
	 */
	@Autowired
	@Qualifier("ARMY_GROUP_TRAIN_START_TIME")
	private String startExpr;
	
	/**
	 * 攻擊開始時間
	 */
	@Autowired
	@Qualifier("ARMY_GROUP_TRAIN_ATTACK_START_TIME")
	private String attackExpr;
	
	/**
	 * 活動結束時間
	 */
	@Autowired
	@Qualifier("ARMY_GROUP_TRAIN_END_TIME")
	private String endExpr;
	
	/**
	 * 軍隊id生成器，必須保證在整個活動期間的所有軍隊有不同的id
	 */
	private AtomicInteger armyIdGenerator = new AtomicInteger(0);
	
	/**
	 * 軍團試煉玩家的信息
	 * key-玩家id
	 * value-玩家試煉信息
	 */
	private final ConcurrentHashMap<Long, TrainPlayerVO> trainPlayers = 
			new ConcurrentHashMap<Long, TrainPlayerVO>();
	
	/**
	 * 
	 * 軍團試煉的戰鬥進度信息
	 * 
	 * key-軍團id
	 * value-當前關卡進度信息，以及在場景中的玩家等
	 */
	private final ConcurrentHashMap<Long, TrainVO> trainGroups = 
			new ConcurrentHashMap<Long, TrainVO>();
	
	/**
	 * 活動的開始時間
	 */
	private long activityStartTime = 0L;
	
	@Override
	public Result<TrainPlayerDto> attack(long playerId, int areaId, int armyId) {

		if(status != TrainStatus.ATTACK){
			return Result.Error(ArmyGroupTrainResult.ATTACK_NOT_START);
		}
		
		TrainAreaConfig area = ruleService.getTrainArea(areaId);
		if(area == null){
			return Result.Error(ArmyGroupTrainResult.BASE_DATA_NOT_EXIST);
		}

		Player player = dbCachedService.get(playerId, Player.class);
		if(player == null){
			return Result.Error(ArmyGroupTrainResult.PLAYER_NOT_EXISTS);
		}
		
		long armyGroupId = armyGroupService.getArmyGroupId(playerId);
		
		if(armyGroupId <= 0){
			return Result.Error(ArmyGroupTrainResult.NOT_IN_ARMY_GROUP);
		}
		
		TrainPlayerVO trainPlayer = getTrainPlayer(playerId);
		if(trainPlayer == null){//在進入場景的時候必定會創建
			return Result.Error(ArmyGroupTrainResult.PLAYER_UN_PARTICIPATE);
		}
		
		long groupId = trainPlayer.getGroupId();
		if(groupId != armyGroupId){
			return Result.Error(ArmyGroupTrainResult.PLAYER_UN_PARTICIPATE);
		}
		
		if(inCoolTime(trainPlayer)){
			return Result.Error(ArmyGroupTrainResult.IN_COOL_TIME);
		}
		
		TrainVO train = trainGroups.get(groupId);//在進入場景的時候必定會創建
		if(train == null){
			return Result.Error(ArmyGroupTrainResult.PLAYER_UN_PARTICIPATE);
		}
		
		if(train.getAreaId() != areaId){//已經通關或參數錯誤
			return Result.Error(ArmyGroupTrainResult.AREA_BREAKED);
		}
		
		ArmyVO army = train.getArmy(armyId);
		
		if(army == null){
			return Result.Error(ArmyGroupTrainResult.ARMY_UN_EXISTS);
		}
		
		if(army.getKilled() == 1){
			return Result.Error(ArmyGroupTrainResult.ARMY_KILLED);
		}

		TrainArmy trainArmy = ruleService.getTrainArmy(train.getAreaId(), train.getBatch());
		if(trainArmy == null){
			return Result.Error(ArmyGroupTrainResult.BASE_DATA_NOT_EXIST);
		}
		
		if(army.getKilled() == 1){
			return Result.Error(ArmyGroupTrainResult.ARMY_KILLED);
		}
		
		boolean isContinue = false;
		for (int i = 0; i < 100; i ++) {
			if(army.getKilled() == 1){//已經死亡則不用再打
				return Result.Error(ArmyGroupTrainResult.ARMY_KILLED);
			}
			if(army.getIsInBattle() == 0){
				ChainLock armyLock = LockUtils.getLock(army);
				armyLock.lock();
				try{
					
					if(army.getKilled() == 1){//已經死亡則不用再打
						return Result.Error(ArmyGroupTrainResult.ARMY_KILLED);
					}
					
					if(army.getIsInBattle() == 0){//沒有死亡的軍隊，且不在戰鬥狀態中
						army.setIsInBattle(1);
						isContinue = true;
						break;
					}
					
				}
				catch(Exception e){
					e.printStackTrace();
				}
				finally{
					armyLock.unlock();
				}
			}
			if(army.getIsInBattle() == 1){
				try {
					Thread.sleep(10);
				} catch (Exception ex) {
					logger.error(ex.getMessage(), ex);
				}
			}
		}
		if(!isContinue){
			return Result.Error(ArmyGroupTrainResult.FAILURE);
		}
		
		ValueResultSet valueResultSet = null;
		
		double harm = 0;//用於計算排名
		double harmPercent = 0;
		boolean isRefresh = false;//是否需要刷新軍隊批次
		boolean attackWin = false;
		List<BattleResult> battleResults = null;
		double initHp = 0;
		List<BattleCharacter> npcUnit = null;
		try{
			if(inCoolTime(trainPlayer)){
				return Result.Error(ArmyGroupTrainResult.IN_COOL_TIME);
			}
			trainPlayer.setLastBattleTime(new Date());
			//處理戰鬥
			double npcAbility = this.chapterRuleService.armyToFightAbility(trainArmy.getArmy());
			
			BattlePlayerInfo armyBpi = new BattlePlayerInfo(trainArmy.getNpcName(), trainArmy.getNpcLevel(), trainArmy.getNpcPic(), npcAbility);
			
			if(army.getKilled() == 1){
				return Result.Error(ArmyGroupTrainResult.ARMY_KILLED);
			}
			npcUnit = army.getFightUnits();//獲得該軍隊的一個副本
			if(npcUnit == null){
				army.initArmyFightUnits(chapterRuleService.armyToFightUnit(trainArmy.getArmy()));
				npcUnit = army.getFightUnits();//獲得該軍隊的一個副本
			}
			
			initHp = army.getCurHp();
			
			BattlePlayerInfo userBpi = new BattlePlayerInfo(player);

			List<List<BattleCharacter>> userUnits = playerService.getMultiUserBattleCharacter(playerId, BattleWaveID.ARMY_GROUP_TRAIN);
			
			List<BattleGroup> attackGroups = new ArrayList<BattleGroup>();
			
			List<BattleGroup> defenseGroups = new ArrayList<BattleGroup>();

			BattleGroup armyGroup = null;
			
			if(!trainArmy.isArmyAttack()){
				for (List<BattleCharacter> userUnit : userUnits) {
					BattleGroup battleGroup = new BattleGroup(BattleTeam.OFFENSE_TEAM, userUnit, userBpi, 0);
					attackGroups.add(battleGroup);
				}
				armyGroup = new BattleGroup(BattleTeam.DEFENSE_TEAM, npcUnit, armyBpi, 0);
				defenseGroups.add(armyGroup);
			}
			else{
				for (List<BattleCharacter> userUnit : userUnits) {
					BattleGroup battleGroup = new BattleGroup(BattleTeam.DEFENSE_TEAM, userUnit, userBpi, 0);
					defenseGroups.add(battleGroup);
				}
				armyGroup = new BattleGroup(BattleTeam.OFFENSE_TEAM, npcUnit, armyBpi, 0);
				attackGroups.add(armyGroup);
			}
			
			MultiBattleResult multiBattleResult = battleService.multiWaveBattle(BattleType.PVE, attackGroups, defenseGroups, true);
			//战斗结果
			battleResults = multiBattleResult.getBattleResults();
			
			//是否胜利
			attackWin = multiBattleResult.getWinner().equals(trainArmy.isArmyAttack() ? BattleWinner.DEFENSE_TEAM : BattleWinner.OFFENSE_TEAM);
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			ChainLock armyLock = LockUtils.getLock(army);
			armyLock.lock();
			try{
				if(army.getIsInBattle() == 0){
					return Result.Error(ArmyGroupTrainResult.FAILURE);
				}
				
				army.setIsInBattle(0);
				//刷新軍隊
				if(attackWin){
					army.setKilled(1);
					harm = initHp;
				}
				else{
					double curHp = army.saveHp(npcUnit);
					//根據血量計算獎勵
					harm = initHp - curHp;
					harmPercent = harm / army.getTotalHp();
				}
			}
			catch(Exception e){
				e.printStackTrace();
			}
			finally{
				armyLock.unlock();
			}
		}
//		Set<Long> players = null;
		boolean isLastArea = false;//最後一關
		if(attackWin){
			ChainLock trainLock = LockUtils.getLock(train);
			trainLock.lock();
			try{
				train.decreaseArmy();//減少軍隊
				if(train.allKilled()){//全部死亡
					isRefresh = refreshBatch(train);//刷新到下一批
					if(!isRefresh){
						isLastArea = true;
					}
				}
			}
			catch(Exception e){
				e.printStackTrace();
			}
			finally{
				trainLock.unlock();
			}
		}
		
		if(isRefresh){
			TrainDto dto = TrainDto.valueOf(train);
			pushHelper.push(train.getPlayers(), Module.ARMY_GROUP_TRAIN, ArmyGroupTrainCmd.PUSH_ARMY_GROUP_AREA, dto);
		}
		if(harm > 0){
			ArmyDto armyDto = ArmyDto.valueOf(armyId, army);
			pushHelper.push(train.getPlayers(), Module.ARMY_GROUP_TRAIN, ArmyGroupTrainCmd.PUSH_ARMY_GROUP_ARMY, armyDto);
		}
		
		
		if(isRefresh && areaId != train.getAreaId() || isLastArea){//通關獎勵發放
			
			int level = armyGroupService.getArmyGroupBuildingLevel(armyGroupId, ArmyGroupBuildingType.LUBAN_LANE.ordinal());
			double added = 0.0;
			ArmyGroupBuildingUpgrade armyGroupBuildingUpgrade = basedbService.getByUnique(
					ArmyGroupBuildingUpgrade.class, IndexName.ARMY_GROUP_BUILDING_UPGRADE_INDEX, 
					ArmyGroupBuildingType.LUBAN_LANE.ordinal(), level);
			if (armyGroupBuildingUpgrade != null) {
				added = armyGroupBuildingUpgrade.getValue();
			}
			
			Set<Long> players = train.getPlayers();
			
			for(Long playerIdInScene : players){
				Player playerInScene = dbCachedService.get(playerIdInScene, Player.class);
				if(playerInScene == null){
					continue;
				}
				TrainPlayerVO playerVO = trainPlayers.get(playerIdInScene);
				if(playerVO == null){
					continue;
				}
				ChainLock playerLock = LockUtils.getLock(playerInScene);
				playerLock.lock();
				try{
					List<Reward> brs = rewardService.parseRewards(playerIdInScene, area.getRewards(), true);
					
					if(added > 0){
						for(Reward reward : brs){
							reward.increase((int)(reward.getCount() * added));
						}
					}
					
					RewardActionSet rewardActionSet = this.rewardService.tryRewards(playerIdInScene, brs, InBagRule.MAIL_IF_FULL, true);
					if (rewardActionSet.isNotOK()) {
						continue;
					}
					
					playerVO.addRewards(brs);
					
					ValueResultSet rs = this.rewardService.executeRewards(playerIdInScene, rewardActionSet, LogSource.ARMY_GROUP_TRAIN_REWARDS);
					Map<String, Object> values = new HashMap<String, Object>();
					values.put("valueResultSet", rs);
					pushHelper.push(playerIdInScene, Module.ARMY_GROUP_TRAIN, ArmyGroupTrainCmd.PUSH_ACTIVITY_BREAK_REWARDS, values);
				}
				catch(Exception e){
					e.printStackTrace();
				}
				finally{
					playerLock.unlock();
				}
			}
		}
		if(isRefresh && areaId != train.getAreaId() || isLastArea){
			Map<String, Object> values = new HashMap<String, Object>();
			values.put(NoticeKey.NUMBER_1, areaId);
			NoticeDto noticeDto = NoticeDto.valueOf(NoticeId.ARMY_GROUP_TRAIN_BREAK, values);
			noticeService.pushNotice(playerId, noticeDto);
		}
		List<Reward> rewards = new ArrayList<Reward>();
		
		Date now = new Date();
		String drops = "";
		TrainPlayerRankVO rank = null;

		ChainLock playerLock = LockUtils.getLock(player);
		playerLock.lock();
		try{
			trainPlayer.setLastBattleTime(now);
			if(attackWin){
				if(!StringUtils.isEmpty(trainArmy.getRewards())){
					List<Reward> tempSet = rewardService.parseRewards(playerId, trainArmy.getRewards(), false);
					rewards.addAll(tempSet);
					trainPlayer.addRewards(RewardHelper.copyRewards(tempSet));
				}
				if(!StringUtils.isEmpty(trainArmy.getDrops())){
					DropResult dropResult = dropService.doDrop(playerId, trainArmy.getDrops());
					rewards.addAll(dropResult.getRewardList());
					drops = dropResult.toRewardString();
				}
			}
			else{
				trainPlayer.setStatus(1);//死亡
				if(harmPercent > 0){
					if(!StringUtils.isEmpty(trainArmy.getRewards())){
						rewards.addAll(rewardService.parseRewards(playerId, trainArmy.getRewards(), false));
					}
					if(rewards.size() > 0){
						for(Reward reward : rewards){
							reward.increase(-(int)(reward.getCount() * (1 - harmPercent)));
						}
						trainPlayer.addRewards(RewardHelper.copyRewards(rewards));
					}
				}
			}
			
			if(rewards.size() > 0){
				RewardHelper.combineRewards(rewards);
				RewardActionSet rewardActionSet = this.rewardService.tryRewards(playerId, rewards, InBagRule.MAIL_IF_FULL, true);
				if (rewardActionSet.isNotOK()) {
					return Result.Error(rewardActionSet.getResultCode());
				}
				valueResultSet = this.rewardService.executeRewards(playerId, rewardActionSet, LogSource.ARMY_GROUP_TRAIN_REWARDS);
				
			}

		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			playerLock.unlock();
		}
		
		if(harm > 0){
			//刷新排名
			ArmyGroupTrainInfo trainInfo = getArmyGroupTrainRanksInfo(groupId);
			ChainLock rankLock = LockUtils.getLock(trainInfo);
			rankLock.lock();
			try{
				rank = refreshRanks(trainInfo, playerId, player.getTotalAbility(), harm);
			}
			catch(Exception e){
				e.printStackTrace();
			}
			finally{
				rankLock.unlock();
			}
			
		}
		//軍團公告
		if(attackWin && StringUtils.isNotEmpty(drops)){
			Map<String, Object> values = new HashMap<String, Object>();
			values.put(NoticeKey.PLAYERNAME1, player.getPlayerName());
			values.put(NoticeKey.DROPS, drops);
			NoticeDto noticeDto = NoticeDto.valueOf(NoticeId.ARMY_GROUP_TRAIN_KILL_MONSTER, values);
			noticeService.pushNotice(playerId, noticeDto);
		}
		//個人公告
		if(attackWin && StringUtils.isNotEmpty(drops)){
			//軍團公告
			Map<String, Object> values = new HashMap<String, Object>();
			values.put(NoticeKey.NUMBER_1, (int)harm);
			values.put(NoticeKey.REWARDS, trainArmy.getRewards());
			values.put(NoticeKey.DROPS, drops);
			NoticeDto noticeDto = NoticeDto.valueOf(NoticeId.ARMY_GROUP_TRAIN_BATTLE_WIN, values);
			noticeService.pushNotice(playerId, noticeDto);
		}
//		else{
//			Map<String, Object> values = new HashMap<String, Object>();
//			values.put(NoticeKey.NUMBER_1, (int)harm);
//			values.put(NoticeKey.REWARDS, RewardHelper.toRewardString(rewards));
//			NoticeDto noticeDto = NoticeDto.valueOf(NoticeId.ARMY_GROUP_TRAIN_BATTLE_FAIL, values);
//			noticeService.pushNotice(playerId, noticeDto);
//		}
		
		if(rank != null){
			TrainPlayerRankDto dto = TrainPlayerRankDto.valueOf(rank, player.getPlayerName());
			pushHelper.push(train.getPlayers(), Module.ARMY_GROUP_TRAIN, ArmyGroupTrainCmd.PUSH_ARMY_GROUP_TRAIN_RANK, dto);
		}
		
		if(!attackWin){
			Set<Long> players = new HashSet<Long>(train.getPlayers());
			players.remove(playerId);
			if(players.size() > 0){
				Map<String, Object> values = new HashMap<String, Object>();
				values.put("status", 5);
				values.put("playerId", playerId);
				pushHelper.push(players, Module.ARMY_GROUP_TRAIN, ArmyGroupTrainCmd.PUSH_SCENE_CHANGE, values);
			}
		}
		
		if(isLastArea){
			ChainLock trainLock = LockUtils.getLock(train);
			trainLock.lock();
			try{
				if(!train.isFinished()){
					train.setFinished(true);
				}
			}
			catch(Exception e){
				e.printStackTrace();
			}
			finally{
				trainLock.unlock();
			}
			
			Set<Long> players = train.getPlayers();
			if(players != null && players.size() > 0){
				for(Long playerIdInScene : players){
					TrainPlayerVO tp = trainPlayers.get(playerIdInScene);
					if(tp == null){
						continue;
					}
					try{
						List<Reward> prs = tp.getRewards();
						if(!CollectionUtils.isEmpty(prs)){
							RewardHelper.combineRewards(prs);
							String rs = RewardHelper.toRewardString(prs);
							Map<String, Object> values = new HashMap<String, Object>();
							values.put("rewards", rs);
							pushHelper.push(playerIdInScene, Module.ARMY_GROUP_TRAIN, ArmyGroupTrainCmd.PUSH_ACTIVITY_TOTAL_REWARDS, values);
						}
					}
					catch(Exception e){
						e.printStackTrace();
					}
				}
				//推送結束
				Map<String, Object> values = new HashMap<String, Object>();
				values.put("status", TrainStatus.NONE.ordinal());
				pushHelper.push(players, Module.ARMY_GROUP_TRAIN, ArmyGroupTrainCmd.PUSH_ACTIVITY_STATUS_CHANGE, values);
			}
		}
		TrainPlayerDto content = TrainPlayerDto.valueOf(playerId, getCoolTime(trainPlayer), trainPlayer.getStatus());
		Result<TrainPlayerDto> result = Result.Success(content);
		result.addContent("battleResults", battleResults);
		result.addContent("valueResultSet", valueResultSet);
		return result;
	}

	private TrainPlayerRankVO refreshRanks(ArmyGroupTrainInfo trainInfo, long playerId, double ability, double harm) {
		
		TrainPlayerRankVO rankVO = trainInfo.getTrainPlayerRank(playerId);
		if(rankVO == null){
			rankVO = TrainPlayerRankVO.valueOf(playerId);
			trainInfo.addTrainPlayerRank(rankVO);
		}
		
		rankVO.setAbility(ability);
		rankVO.setHarm(rankVO.getHarm() + harm);
		
		String ranks = JsonUtils.object2JsonString(trainInfo.getTrainRanks().values());
		trainInfo.setRanks(ranks);
		
		dbCachedService.submitUpdated2Queue(trainInfo.getId(), trainInfo.getClass());
		
		
		return rankVO;
	}

	private boolean inCoolTime(TrainPlayerVO trainPlayer) {
		return getCoolTime(trainPlayer) > 0;
	}

	private boolean refreshBatch(TrainVO train) {
		TrainArmy trainArmy = ruleService.getNextTrainArmy(train.getAreaId(), train.getBatch());
		if(trainArmy == null){
			return false;//全部通關
		}
		int sum = trainArmy.getSum();//需要克隆的軍隊數量
		train.initArmyCounter(sum);
		
		train.setAreaId(trainArmy.getAreaId());
		train.setBatch(trainArmy.getBatch());
		train.setId(trainArmy.getId());
		train.getArmys().clear();
		
		for(int i = 0; i < sum; i++){
			int armyId = armyIdGenerator.incrementAndGet();
			ArmyVO army = new ArmyVO();
			train.getArmys().put(armyId, army);
			
			List<BattleCharacter> npcUnit = chapterRuleService.armyToFightUnit(trainArmy.getArmy());
			army.initArmyFightUnits(npcUnit);
		}
		
		return true;
	}

	private long getCoolTime(TrainPlayerVO trainPlayer){
		
		Date battleTime = trainPlayer.getLastBattleTime();
		if(battleTime != null){
			long endTime;
			if(trainPlayer.getStatus() == 1){
				endTime = battleTime.getTime() + ruleService.getBattleCoolTime() + ruleService.getDieCoolTime();
			}
			else{
				endTime = battleTime.getTime() + ruleService.getBattleCoolTime();
			}
			
			long coolTime = endTime - System.currentTimeMillis();
			if(coolTime > 0){
				return coolTime;
			}
		}
		return 0L;
	}
	@Override
	public Result<TrainPlayerDto> getMyTrainInfo(long playerId) {
		
		if(status == TrainStatus.NONE){
			return Result.Error(ArmyGroupTrainResult.ACTIVITY_NOT_START);
		}
		
		Player player = dbCachedService.get(playerId, Player.class);
		if(player == null){
			return Result.Error(ArmyGroupTrainResult.PLAYER_NOT_EXISTS);
		}
		//如果不是軍團成員則返回錯誤碼
		long armyGroupId = armyGroupService.getArmyGroupId(playerId);
		if(armyGroupId <= 0){
			return Result.Error(ArmyGroupTrainResult.NOT_IN_ARMY_GROUP);
		}
		TrainVO train = getTrain(armyGroupId);
		if(train == null || train.isFinished()){
			return Result.Error(ArmyGroupTrainResult.ACTIVITY_NOT_START);
		}
		
		TrainPlayerVO trainPlayer = getTrainPlayer(playerId);
		
		//將玩家加入場景
		addPlayer(armyGroupId, playerId, trainPlayer);
		
		TrainPlayerDto content = TrainPlayerDto.valueOf(playerId, getCoolTime(trainPlayer), trainPlayer.getStatus());
		
		Result<TrainPlayerDto> result = Result.Success(content);
		
		Set<Long> players = train.getPlayers();
		
		List<TrainPlayerDetailDto> playersInScene = new ArrayList<TrainPlayerDetailDto>(players.size());
		
		for(Long playerIdInScene : players){
			if(playerIdInScene == null){
				continue;
			}
			if(playerIdInScene == playerId){
				continue;
			}
			TrainPlayerVO p = trainPlayers.get(playerIdInScene);
			Player playerInScene = dbCachedService.get(playerIdInScene, Player.class);
			if(playerInScene == null){
				continue;
			}
			
			TrainPlayerDetailDto dto = toDetail(playerIdInScene, p);
			playersInScene.add(dto);
		}
		
		result.addContent("players", playersInScene);
		result.addContent("status", status);
		result.addContent("startTime", activityStartTime);
		return result;
	}

	private TrainVO getTrain(long armyGroupId) {

		TrainVO train = trainGroups.get(armyGroupId);
		if(train == null){
			train = TrainVO.valueOf(armyGroupId);
			TrainVO previous = trainGroups.putIfAbsent(armyGroupId, train);
			if(previous != null){
				train = previous;
			}
		}
		return train;
	}

	private void addPlayer(long armyGroupId, long playerId, TrainPlayerVO trainPlayer) {
		
		TrainVO train = getTrain(armyGroupId);

		if(train == null){
			return;
		}
		
		if(train.getPlayers().size() > 0){
			List<Long> players = new ArrayList<Long>(train.getPlayers());
			players.remove((Long)playerId);
			TrainPlayerDetailDto dto = toDetail(playerId, trainPlayer);
			Map<String, Object> values = new HashMap<String, Object>();
			values.put("status", 1);
			values.put("player", dto);
			pushHelper.push(players, Module.ARMY_GROUP_TRAIN, ArmyGroupTrainCmd.PUSH_SCENE_CHANGE, values);
		}
//		ChainLock lock = LockUtils.getLock(train);
//		lock.lock();
//		try{
//			train.getPlayers().add(playerId);
//		}
//		catch(Exception e){
//			e.printStackTrace();
//		}
//		finally{
//			lock.unlock();
//		}
		train.getPlayers().add(playerId);
	}

	private TrainPlayerVO getTrainPlayer(long playerId) {
		TrainPlayerVO trainPlayer = trainPlayers.get(playerId);
		if(trainPlayer == null){
			long armyGroupId = armyGroupService.getArmyGroupId(playerId);
			if(armyGroupId <= 0){
				return null;
			}
			trainPlayer = TrainPlayerVO.valueOf(armyGroupId);
			TrainPlayerVO previous = trainPlayers.putIfAbsent(playerId, trainPlayer);
			if(previous != null){
				trainPlayer = previous;
			}
		}
		
		if(trainPlayer.getStatus() == 1){
			Date battleTime = trainPlayer.getLastBattleTime();
			if(battleTime != null){
				Date now = new Date();
				if(now.getTime() > (battleTime.getTime() + ruleService.getBattleCoolTime() + ruleService.getDieCoolTime())){
					trainPlayer.setStatus(0);
				}
			}
			else{
				trainPlayer.setStatus(0);
			}
		}
		
		return trainPlayer;
	}
	
	@Scheduled(name = "军团试炼活动开始", value = "ARMY_GROUP_TRAIN_START_TIME", type = ValueType.BEANNAME)
	private void start() {
		if(status == TrainStatus.START){
			return;
		}
		status = TrainStatus.START;
		
		activityStartTime = System.currentTimeMillis();
		Map<String, Object> values = new HashMap<String, Object>();
		values.put("status", status.ordinal());
		pushHelper.pushAll(Module.ARMY_GROUP_TRAIN, ArmyGroupTrainCmd.PUSH_ACTIVITY_STATUS_CHANGE, values);
		
		NoticeDto noticeDto = NoticeDto.valueOf(NoticeId.ARMY_GROUP_TRAIN_START, null);
		noticeService.pushNotice(-1L, noticeDto);
		
	}
	
	@Scheduled(name = "军团试炼活动攻击开始", value = "ARMY_GROUP_TRAIN_ATTACK_START_TIME", type = ValueType.BEANNAME)
	private void attackStart() {
		
		if(status == TrainStatus.ATTACK){
			return;
		}
		
		status = TrainStatus.ATTACK;
		
		if(trainGroups.size() > 0){
			for(TrainVO train : trainGroups.values()){
				if(train == null){
					continue;
				}
				boolean isRefresh = false;
				if(train.getArmys().size() == 0){
					ChainLock trainLock = LockUtils.getLock(train);
					trainLock.lock();
					try{
						if(train.getArmys().size() == 0){
							isRefresh = refreshBatch(train);//刷新到下一批
						}
					}
					catch(Exception e){
						e.printStackTrace();
					}
					finally{
						trainLock.unlock();
					}
				}
				
				if(isRefresh){
					if(train.getPlayers().size() > 0){
						TrainDto dto = TrainDto.valueOf(train);
						pushHelper.push(train.getPlayers(), Module.ARMY_GROUP_TRAIN, ArmyGroupTrainCmd.PUSH_ARMY_GROUP_AREA, dto);
					}
				}
			}
		}
		Map<String, Object> values = new HashMap<String, Object>();
		values.put("status", status.ordinal());
		pushHelper.pushAll(Module.ARMY_GROUP_TRAIN, ArmyGroupTrainCmd.PUSH_ACTIVITY_STATUS_CHANGE, values);
	}
	
	@Scheduled(name = "军团试炼活动结束", value = "ARMY_GROUP_TRAIN_END_TIME", type = ValueType.BEANNAME)
	private void end() {
		//清除緩存、保存排名
		if(status == TrainStatus.NONE){
			return;
		}
		status = TrainStatus.NONE;
		
		if(trainGroups.size() > 0){
			for(TrainVO train : trainGroups.values()){
				if(train.isFinished()){
					continue;
				}
				Set<Long> players = train.getPlayers();
				if(players != null && players.size() > 0){
					for(Long playerId : players){
						TrainPlayerVO trainPlayer = trainPlayers.get(playerId);
						if(trainPlayer == null){
							continue;
						}
						try{
							List<Reward> rewards = trainPlayer.getRewards();
							if(!CollectionUtils.isEmpty(rewards)){
								RewardHelper.combineRewards(rewards);
								String rs = RewardHelper.toRewardString(rewards);
								Map<String, Object> values = new HashMap<String, Object>();
								values.put("rewards", rs);
								pushHelper.push(playerId, Module.ARMY_GROUP_TRAIN, ArmyGroupTrainCmd.PUSH_ACTIVITY_TOTAL_REWARDS, values);
							}
						}
						catch(Exception e){
							e.printStackTrace();
						}
					}
				}
			}
		}
		armyIdGenerator.set(0);
		
		trainPlayers.clear();
		
		trainGroups.clear();
		
		activityStartTime = 0L;
		
		Map<String, Object> values = new HashMap<String, Object>();
		values.put("status", status.ordinal());
		pushHelper.pushAll(Module.ARMY_GROUP_TRAIN, ArmyGroupTrainCmd.PUSH_ACTIVITY_STATUS_CHANGE, values);
	}

//	@LifecycleMethod(lifecycle = Lifecycle.BUSSINESS_INITIALIZE, name = "军团试炼初始化")
//	private void init() {
//		
//		Date now = new Date();
//		CronSequenceGenerator sequenceGenerator = new CronSequenceGenerator(
//				startExpr, TimeZone.getDefault());
//		Date startTime = sequenceGenerator.next(now);
//		if (DateUtils.isSameDay(now, startTime)) {//還沒有開始今日的軍團試煉
//			return;
//		}
//		
//		sequenceGenerator = new CronSequenceGenerator(attackExpr,
//				TimeZone.getDefault());
//		Date attackTime = sequenceGenerator.next(now);
//		if (DateUtils.isSameDay(now, attackTime)) {//還沒有開始戰鬥階段
//			status = TrainStatus.START;
//			activityStartTime = System.currentTimeMillis();
//			return;
//		}
//		
//		sequenceGenerator = new CronSequenceGenerator(endExpr,
//				TimeZone.getDefault());
//		Date endTime = sequenceGenerator.next(now);
//		if (DateUtils.isSameDay(now, endTime)) {//戰鬥階段還沒有結束
//			status = TrainStatus.ATTACK;
//			return;
//		}
//		status = TrainStatus.NONE;
//	}
	
	@Override
	public TrainDto getArmyGroupTrainInfo(long playerId) {
		
//		if(status != TrainStatus.ATTACK){
//			return Result.Error(ArmyGroupTrainResult.ATTACK_NOT_START);
//		}
//		
//		TrainPlayerVO trainPlayer = trainPlayers.get(playerId);
//		if(trainPlayer == null){
//			return Result.Error(ArmyGroupTrainResult.PLAYER_UN_PARTICIPATE);
//		}
//		
//		Player player = dbCachedService.get(playerId, Player.class);
//		if(player == null){
//			return Result.Error(ArmyGroupTrainResult.PLAYER_NOT_EXISTS);
//		}
//		
//		ArmyGroupMember member = dbCachedService.get(playerId, ArmyGroupMember.class);
//		if(member == null){
//			return Result.Error(ArmyGroupTrainResult.NOT_IN_ARMY_GROUP);
//		}
//		long armyGroupId = member.getArmyGroupId();
//		if(armyGroupId <= 0){
//			return Result.Error(ArmyGroupTrainResult.NOT_IN_ARMY_GROUP);
//		}
		if(status != TrainStatus.ATTACK){
			return null;
		}
		
		TrainPlayerVO trainPlayer = trainPlayers.get(playerId);
		if(trainPlayer == null){
			return null;
		}
		
		Player player = dbCachedService.get(playerId, Player.class);
		if(player == null){
			return null;
		}
		
		long armyGroupId = armyGroupService.getArmyGroupId(playerId);
		if(armyGroupId <= 0){
			return null;
		}
		TrainVO train = getTrain(armyGroupId);
		boolean isRefresh = false;
		
		if(train.getArmys().size() == 0){
			isRefresh = init(train);
		}
		if(isRefresh){
			if(train.getPlayers().size() > 1){
				TrainDto dto = TrainDto.valueOf(train);
				List<Long> players = new ArrayList<Long>(train.getPlayers());
				players.remove((Long)playerId);
				pushHelper.push(players, Module.ARMY_GROUP_TRAIN, ArmyGroupTrainCmd.PUSH_ARMY_GROUP_AREA, dto);
			}
		}
		TrainDto content = TrainDto.valueOf(train);
		
//		return Result.Success(content);
		return content;
	}

	private boolean init(TrainVO train) {
		ChainLock trainLock = LockUtils.getLock(train);
		trainLock.lock();
		try{
			if(train.getArmys().size() == 0){
				refreshBatch(train);//刷新到下一批
				return true;
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
		finally{
			trainLock.unlock();
		}
		return false;
	}

	@Override
	public void leaveTrainScene(long playerId) {
		
		if(status == TrainStatus.NONE){
			return;
		}
		
		Player player = dbCachedService.get(playerId, Player.class);
		if(player == null){
			return;
		}
		
		long armyGroupId = armyGroupService.getArmyGroupId(playerId);
		if(armyGroupId <= 0){
			return;
		}
		
		TrainVO train = trainGroups.get(armyGroupId);
		if(train == null){
			return;
		}
		
		boolean isChanged = train.getPlayers().remove(playerId);
		if(isChanged){
			if(train.getPlayers().size() > 0){
				Map<String, Object> values = new HashMap<String, Object>();
				values.put("status", 2);
				values.put("playerId", playerId);
				pushHelper.push(train.getPlayers(), Module.ARMY_GROUP_TRAIN, ArmyGroupTrainCmd.PUSH_SCENE_CHANGE, values);
			}
		}
		
	}

	@Override
	public Result<List<TrainPlayerRankDto>> getTrainRanks(long playerId) {
		
		Player player = dbCachedService.get(playerId, Player.class);
		if(player == null){
			return Result.Error(ArmyGroupTrainResult.PLAYER_NOT_EXISTS);
		}
		
		long armyGroupId = armyGroupService.getArmyGroupId(playerId);
		if(armyGroupId <= 0){
			return Result.Error(ArmyGroupTrainResult.NOT_IN_ARMY_GROUP);
		}
		List<TrainPlayerRankDto> rankList = getRanks(armyGroupId);
		
		Result<List<TrainPlayerRankDto>> result = Result.Success(rankList);
		return result;
	}

	private List<TrainPlayerRankDto> getRanks(long armyGroupId) {

		ArmyGroupTrainInfo trainInfo = getArmyGroupTrainRanksInfo(armyGroupId);
		
		List<TrainPlayerRankDto> rankList;
		
		Collection<TrainPlayerRankVO> ranks = trainInfo.getTrainRanks().values();
		if(!CollectionUtils.isEmpty(ranks)){
			rankList = new ArrayList<TrainPlayerRankDto>(ranks.size());
			for(TrainPlayerRankVO rank : ranks){
				if(rank == null){
					continue;
				}
				long trainPlayerId = rank.getPlayerId();
				Player player = dbCachedService.get(trainPlayerId, Player.class);
				if(player == null){
					continue;
				}
				TrainPlayerRankDto dto = TrainPlayerRankDto.valueOf(rank, player.getPlayerName());
				rankList.add(dto);
			}
		}
		else{
			rankList = new ArrayList<TrainPlayerRankDto>();
		}
		return rankList;
	}

	private ArmyGroupTrainInfo getArmyGroupTrainRanksInfo(long armyGroupId) {
		ArmyGroupTrainInfo trainInfo = dbCachedService.get(armyGroupId, ArmyGroupTrainInfo.class);
		if(trainInfo == null){
			trainInfo = ArmyGroupTrainInfo.valueOf(armyGroupId);
			trainInfo = dbCachedService.submitNew2Queue(trainInfo);
		}
		Date now = new Date();
		String today = DateUtil.date2String(now, DatePattern.PATTERN_YYYY_MM_DD);
		if(!today.equalsIgnoreCase(trainInfo.getDate())){//不是同一屆
			if(status.ordinal() != TrainStatus.NONE.ordinal()){
				//新的比賽已經開始
				ChainLock lock = LockUtils.getLock(trainInfo);
				lock.lock();
				try{
					if(!today.equalsIgnoreCase(trainInfo.getDate())){//不是同一屆
						trainInfo.setDate(today);
						trainInfo.setRanks("");
						trainInfo.getTrainRanks().clear();
						dbCachedService.submitUpdated2Queue(trainInfo.getId(), ArmyGroupTrainInfo.class);
					}
				}
				catch(Exception e){
					e.printStackTrace();
				}
				finally{
					lock.unlock();
				}
			}
		}
		
		return trainInfo;
	}

	@Override
	public void moveInTrainScene(long playerId, String path) {
		
		TrainPlayerVO p = this.trainPlayers.get(playerId);
		if (p == null) {
			return;
		}
		
		long armyGroupId = armyGroupService.getArmyGroupId(playerId);
		if(armyGroupId <= 0){
			return;
		}
		
		TrainVO train = trainGroups.get(armyGroupId);
		if(train == null){
			return;
		}
		
		ChainLock chainLock = LockUtils.getLock(p);
		chainLock.lock();
		try {
			p.setPath(path);
		} finally {
			chainLock.unlock();
		}
		
		if (train.getPlayers() == null || train.getPlayers().isEmpty()) {
			return;
		}
		
		List<Long> toPlayerIds = new ArrayList<Long>(train.getPlayers());
		toPlayerIds.remove((Long)playerId);
		if (toPlayerIds.size() > 0) {
			Map<String, Object> values = new HashMap<String, Object>();
			values.put("status", 3);
			values.put("player", toDetail(playerId, p));
			this.pushHelper.push(toPlayerIds, Module.ARMY_GROUP_TRAIN, ArmyGroupTrainCmd.PUSH_SCENE_CHANGE, values);
		}
	}

	@Override
	public void updateCurLocation(long playerId, String curLoc) {
		TrainPlayerVO p = this.trainPlayers.get(playerId);
		if (p == null) {
			return;
		}
		
		ChainLock chainLock = LockUtils.getLock(p);
		chainLock.lock();
		try {
			p.setCurLoc(curLoc);
		} finally {
			chainLock.unlock();
		}
	}

	@Override
	public String getCurLocation(long playerId) {
		TrainPlayerVO p = this.trainPlayers.get(playerId);
		return p != null ? p.getCurLoc() : null;
	}
	
	private TrainPlayerDetailDto toDetail(long playerId, TrainPlayerVO p){
		
		TrainPlayerDetailDto result = new TrainPlayerDetailDto();
		
		result.setPlayerId(playerId);
		result.setPath(p.getPath());
		result.setCurrLoc(p.getCurLoc());
		
		Player player = this.dbCachedService.get(playerId, Player.class);
		if (player != null) {
			result.setPlayerName(player.getPlayerName());
			result.setCountry(player.getCountry());
			result.setHeadId(player.getHeadId());
			result.setSex(player.getSex().ordinal());
			result.setLevel(player.getLevel());			
		}
		
		int horseId = this.horseService.getPlayerHorseId(playerId);
		result.setHorseId(horseId);
		int netherwingId = this.netherwingService.getPlayerNetherwingId(playerId);
		result.setNetherwingId(netherwingId);
		int fashionEquipId = fashionEquipService.getFashionEquipId(playerId);
		result.setFashionEquipId(fashionEquipId);
		int honorId = this.honorService.getPlayerHonorId(playerId);
		result.setHonorId(honorId);
		return result;
	}

	@Override
	public boolean isArmyGroupTrain(long playerId) {
		return status.ordinal() > TrainStatus.NONE.ordinal();
	}

	@Override
	public void updatePlayerInfo(long playerId) {
		
		if(status == TrainStatus.NONE){
			return;
		}
		
		TrainPlayerVO trainPlayer = trainPlayers.get(playerId);
		if (trainPlayer == null) {
			return;
		}
		
		TrainVO train = trainGroups.get(trainPlayer.getGroupId());
		if (train == null) {
			return;
		}
		
		Set<Long> playerIds = train.getPlayers();
		if (playerIds == null || playerIds.isEmpty()) {
			return;
		}
		if(!playerIds.contains(playerId)){
			return;
		}
		
		List<Long> toPlayerIds = new ArrayList<Long>(playerIds);
		toPlayerIds.remove((Long)playerId);
		if (toPlayerIds.size() > 0) {
			Map<String, Object> values = new HashMap<String, Object>();
			values.put("status", 4);
			values.put("player", toDetail(playerId, trainPlayer));
			this.pushHelper.push(toPlayerIds, Module.ARMY_GROUP_TRAIN, ArmyGroupTrainCmd.PUSH_SCENE_CHANGE, values);
		}
	}

	@Override
	public void playerLogin(long playerId) {
		
		if(status == TrainStatus.NONE){
			return;
		}
		
		TrainPlayerVO trainPlayer = trainPlayers.get(playerId);
		if (trainPlayer == null) {
			return;
		}
		
		TrainVO train = trainGroups.get(trainPlayer.getGroupId());
		if (train == null) {
			return;
		}
		
		Set<Long> playerIds = train.getPlayers();
		if (playerIds == null || playerIds.isEmpty()) {
			return;
		}
		boolean isRemoved = train.getPlayers().remove(playerId);
		if(isRemoved){
			List<Long> toPlayerIds = new ArrayList<Long>(playerIds);
			
			if (toPlayerIds.size() > 0) {
				Map<String, Object> values = new HashMap<String, Object>();
				values.put("status", 2);
				values.put("playerId", playerId);
				this.pushHelper.push(toPlayerIds, Module.ARMY_GROUP_TRAIN, ArmyGroupTrainCmd.PUSH_SCENE_CHANGE, values);
			}
		}
		
		
	}

	@Override
	public Result<String> getCurStatus(long playerId) {
		Result<String> result = Result.Success("");
		result.addContent("status", status.ordinal());
		return result;
	}
}
