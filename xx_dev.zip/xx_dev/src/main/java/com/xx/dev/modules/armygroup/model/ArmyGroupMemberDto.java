package com.xx.dev.modules.armygroup.model;

import com.xx.dev.modules.armygroup.entity.ArmyGroupMember;
import com.xx.dev.modules.player.entity.Player;

/**
 * 军团成员DTO对象
 * 
 * @author Along
 *
 */
public class ArmyGroupMemberDto {

	/**
	 * 玩家id
	 */
	private long id;
	
	/**
	 * 头像id
	 */
	private int headId;
	
	/**
	 * 奴隶身份状态
	 */
	private int slaveStatus;
	
	/**
	 * 主人名称
	 */
	private String masterName;
	
	/**
	 * 玩家名称
	 */
	private String name;
	
	/**
	 * 玩家等级
	 */
	private int level;
	
	/**
	 * 玩家VIP等级
	 */
	private int vipLevel;
	
	/**
	 * 军团职位id
	 */
	private int positionId;
	
	/**
	 * 累计贡献值（计算贡献等级）
	 */
	private int contribute;
	
	/**
	 * 当前贡献值
	 */
	private int curContribute;
	
	/**
	 * 战斗力
	 */
	private double ability;
	
	/**
	 * 是否在线
	 */
	private boolean onLine;
	
	/**
	 * 最后登录时间
	 */
	private long lastLoginTime;
	
	/**
	 * 已经领取粮草福利的次数
	 */
	private int receiveFoodsTimes;
	
	/**
	 * 已经领取武将经验福利的次数
	 */
	private int receiveHeroSoulTimes;
	
	/**
	 * 退出军团的时间
	 */
	private long quitTime;
	
	/**
	 * 加入军团的时间
	 */
	private long joinTime;
	
	public static ArmyGroupMemberDto valueOf(Player player, boolean onLine, 
			ArmyGroupMember armyGroupMember, int slaveStatus, String masterName) {
		ArmyGroupMemberDto result = new ArmyGroupMemberDto();
		result.setAbility(player.getTotalAbility());
		result.setContribute(armyGroupMember.getContribute());
		result.setCurContribute(armyGroupMember.getCurContribute());
		result.setId(armyGroupMember.getId());
		result.setLastLoginTime(player.getLoginTime().getTime());
		result.setLevel(player.getLevel());
		result.setHeadId(player.getHeadId());
		result.setName(player.getPlayerName());
		result.setSlaveStatus(slaveStatus);
		result.setMasterName(masterName);
		result.setOnLine(onLine);
		result.setPositionId(armyGroupMember.getPositionId());
		result.setVipLevel(player.getVipLevel());
		result.setReceiveHeroSoulTimes(0);
		result.setReceiveFoodsTimes(0);
		result.setQuitTime(armyGroupMember.getQuitTime().getTime());
		if (armyGroupMember.getJoinTime() != null) {
			result.setJoinTime(armyGroupMember.getJoinTime().getTime());
		}
		return result;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public int getHeadId() {
		return headId;
	}

	public void setHeadId(int headId) {
		this.headId = headId;
	}

	public int getSlaveStatus() {
		return slaveStatus;
	}

	public void setSlaveStatus(int slaveStatus) {
		this.slaveStatus = slaveStatus;
	}

	public String getMasterName() {
		return masterName;
	}

	public void setMasterName(String masterName) {
		this.masterName = masterName;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

	public int getVipLevel() {
		return vipLevel;
	}

	public void setVipLevel(int vipLevel) {
		this.vipLevel = vipLevel;
	}

	public int getPositionId() {
		return positionId;
	}

	public void setPositionId(int positionId) {
		this.positionId = positionId;
	}

	public int getContribute() {
		return contribute;
	}

	public void setContribute(int contribute) {
		this.contribute = contribute;
	}

	public int getCurContribute() {
		return curContribute;
	}

	public void setCurContribute(int curContribute) {
		this.curContribute = curContribute;
	}

	public double getAbility() {
		return ability;
	}

	public void setAbility(double ability) {
		this.ability = ability;
	}

	public long getLastLoginTime() {
		return lastLoginTime;
	}

	public void setLastLoginTime(long lastLoginTime) {
		this.lastLoginTime = lastLoginTime;
	}

	public int getReceiveFoodsTimes() {
		return receiveFoodsTimes;
	}

	public void setReceiveFoodsTimes(int receiveFoodsTimes) {
		this.receiveFoodsTimes = receiveFoodsTimes;
	}

	public int getReceiveHeroSoulTimes() {
		return receiveHeroSoulTimes;
	}

	public void setReceiveHeroSoulTimes(int receiveHeroSoulTimes) {
		this.receiveHeroSoulTimes = receiveHeroSoulTimes;
	}

	public boolean isOnLine() {
		return onLine;
	}

	public void setOnLine(boolean onLine) {
		this.onLine = onLine;
	}

	public long getQuitTime() {
		return quitTime;
	}

	public void setQuitTime(long quitTime) {
		this.quitTime = quitTime;
	}

	public long getJoinTime() {
		return joinTime;
	}

	public void setJoinTime(long joinTime) {
		this.joinTime = joinTime;
	}
	
}
