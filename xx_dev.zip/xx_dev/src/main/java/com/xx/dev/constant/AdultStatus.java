/**
 * @file:AdultStatus.java
 * @author:David
 **/
package com.xx.dev.constant;
/**
 * @class:AdultStatus
 * @description:成年状态定义 -1-未知 0-未成年  1-成年
 * @author:David
 * @version:v1.0
 * @date:2013-6-21
 **/
public enum AdultStatus {
	
	/**
	 * 0-未知
	 */
	UNKOWN,
	
	/**
	 * 1-未成年
	 */
	IMMATURITY,
	
	/**
	 * 2-成年
	 */
	ADULT,

}

