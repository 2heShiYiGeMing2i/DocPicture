package com.xx.dev.modules.arena.entity;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.apache.commons.lang.StringUtils;
import org.codehaus.jackson.type.TypeReference;

import com.xx.common.db.cache.DbLoadInitializer;
import com.xx.common.db.model.BaseModel;
import com.xx.common.util.JsonUtils;
import com.xx.dev.modules.arena.model.DayRankRewardVO;


/**
 * 竞技场天排行奖励
 * 
 * @author bingshan
 */
@Entity
@Table(name = "arenaDayRankReward")
public class ArenaDayRankReward extends BaseModel<Integer> implements DbLoadInitializer {
	private static final long serialVersionUID = 6651868149521690238L;

	/**
	 * 主键id, 第几天
	 */
	@Id
	@Column(columnDefinition = "int(11) not null comment '主键id'")
	private Integer id;
	
	/**
	 * 天排行信息, List<DayRankRewardVO>
	 */
	@Lob
	@Column(columnDefinition = "longtext comment '天排行信息'")
	private String dayRanks = "";
	
	/**
	 * {rank: DayRankRewardVO}
	 */
	@Transient
	private final Map<Integer, DayRankRewardVO> rankMap = new ConcurrentHashMap<Integer, DayRankRewardVO>();

	@Override
	public void doAfterLoad() {
		if (StringUtils.isBlank(this.dayRanks)) {
			return;
		}
		
		TypeReference<List<DayRankRewardVO>> valueTypeRef = new TypeReference<List<DayRankRewardVO>>() {};
		List<DayRankRewardVO> list = JsonUtils.jsonString2Object(this.dayRanks, valueTypeRef);
		if (list != null && !list.isEmpty()) {
			for (DayRankRewardVO d : list) {
				this.rankMap.put(d.getRank(), d);
			}
		}
	}

	@Override
	public Integer getId() {
		return this.id;
	}

	@Override
	public void setId(Integer id) {
		this.id = id;
	}

	public String getDayRanks() {
		return dayRanks;
	}

	public void setDayRanks(String dayRanks) {
		this.dayRanks = dayRanks;
	}

	public Map<Integer, DayRankRewardVO> getRankMap() {
		return rankMap;
	}

}
