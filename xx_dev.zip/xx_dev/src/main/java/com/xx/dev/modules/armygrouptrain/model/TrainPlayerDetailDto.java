package com.xx.dev.modules.armygrouptrain.model;

import com.xx.dev.constant.Sex;
import com.xx.dev.modules.player.entity.Player;

/**
 * 場景中玩家的詳細信息
 * @author jy
 *
 */
public class TrainPlayerDetailDto {

	/**
	 * 玩家id
	 */
	private long playerId;

	/**
	 * 主公名称
	 */
	private String playerName;
	
	/**
	 * 国家id
	 */
	private int country = 0;
	
	/**
	 * 主公头像id
	 */
	private int headId = 0;
	
	/**
	 * 性别 {@link Sex}
	 */
	private int sex = Sex.FEMALE.ordinal();

	/**
	 * 等级
	 */
	private int level = 1;
	
	/**
	 * 路径
	 */
	private String path;
	
	/**
	 * 当前位置
	 */
	private String currLoc;
	
	/**
	 * 坐骑外形id
	 */
	private int horseId;

	/**
	 * 灵翼外形
	 */
	private int netherwingId;
	
	/**
	 * 灵翼外形
	 */
	private int fashionEquipId;
	
	/**
	 * 称号id
	 */
	private int honorId;
	
	public long getPlayerId() {
		return playerId;
	}

	public void setPlayerId(long playerId) {
		this.playerId = playerId;
	}

	public String getPlayerName() {
		return playerName;
	}

	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}

	public int getCountry() {
		return country;
	}

	public void setCountry(int country) {
		this.country = country;
	}

	public int getHeadId() {
		return headId;
	}

	public void setHeadId(int headId) {
		this.headId = headId;
	}

	public int getSex() {
		return sex;
	}

	public void setSex(int sex) {
		this.sex = sex;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getCurrLoc() {
		return currLoc;
	}

	public void setCurrLoc(String currLoc) {
		this.currLoc = currLoc;
	}

	public int getHorseId() {
		return horseId;
	}

	public void setHorseId(int horseId) {
		this.horseId = horseId;
	}

	public int getNetherwingId() {
		return netherwingId;
	}

	public void setNetherwingId(int netherwingId) {
		this.netherwingId = netherwingId;
	}

	public int getFashionEquipId() {
		return fashionEquipId;
	}

	public void setFashionEquipId(int fashionEquipId) {
		this.fashionEquipId = fashionEquipId;
	}

	public int getHonorId() {
		return honorId;
	}

	public void setHonorId(int honorId) {
		this.honorId = honorId;
	}

	public static TrainPlayerDetailDto valueOf(Player player) {
		TrainPlayerDetailDto dto = new TrainPlayerDetailDto();
		dto.playerId = player.getId();
		dto.playerName = player.getPlayerName();
		dto.country = player.getCountry();
		dto.headId = player.getHeadId();
		dto.sex = player.getSex().ordinal();
		dto.level = player.getLevel();
		return dto;
	}
	
	
}
