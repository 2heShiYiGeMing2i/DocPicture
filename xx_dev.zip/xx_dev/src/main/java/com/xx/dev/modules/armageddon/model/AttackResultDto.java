/**
 * @file:AttackResultDto.java
 * @author:David
 **/
package com.xx.dev.modules.armageddon.model;

import java.util.ArrayList;
import java.util.List;





import com.xx.dev.modules.battle.model.BattleGroupDto;
import com.xx.dev.modules.battle.model.BattleResult;

/**
 * @class:AttackResultDto
 * @description:
 * @author:David
 * @version:v1.0
 * @date:2013-5-22
 **/
public class AttackResultDto {
	/** 玩家是否胜利 **/
	private boolean win = false;
	/** 玩家是否首破 **/
	private boolean breakTop = false;
	/** 累计奖励 List<Reward> toString**/
	private String rewardList;
	/** 战斗一列进攻方 **/
	private List<BattleGroupDto> attackOneGroup = new ArrayList<BattleGroupDto>();
	/** 战斗一列防守方 **/
	private List<BattleGroupDto> defendOneGroup = new ArrayList<BattleGroupDto>();
	/** 战斗二列进攻方  **/
	private List<BattleGroupDto> attackTwoGroup = new ArrayList<BattleGroupDto>();
	/** 战斗二列防守方**/
	private List<BattleGroupDto> defendTwoGroup = new ArrayList<BattleGroupDto>();
	/** 战斗三列进攻方 **/
	private List<BattleGroupDto> attackThreeGroup = new ArrayList<BattleGroupDto>();
	/** 战斗三列防守方 **/
	private List<BattleGroupDto> defendThreeGroup = new ArrayList<BattleGroupDto>();
	/** 战斗一列结果 **/
	private List<BattleResult> battleOneResult = new ArrayList<BattleResult>();
	/** 战斗二列结果 **/
	private List<BattleResult> battleTwoResult = new ArrayList<BattleResult>();
	/** 战斗三列结果 **/
	private List<BattleResult> battleThreeResult = new ArrayList<BattleResult>();
	
	public void addAttackOneGroup(BattleGroupDto battleGroupDto){
		this.attackOneGroup.add(battleGroupDto);
	}
	public void addAttackTwoGroup(BattleGroupDto battleGroupDto){
		this.attackTwoGroup.add(battleGroupDto);
	}
	public void addAttackThreeGroup(BattleGroupDto battleGroupDto){
		this.attackThreeGroup.add(battleGroupDto);
	}
	public void addDefendOneGroup(BattleGroupDto battleGroupDto){
		this.defendOneGroup.add(battleGroupDto);
	}
	public void addDefendTwoGroup(BattleGroupDto battleGroupDto){
		this.defendTwoGroup.add(battleGroupDto);
	}
	public void addDefendThreeGroup(BattleGroupDto battleGroupDto){
		this.defendThreeGroup.add(battleGroupDto);
	}
	public boolean isWin() {
		return win;
	}
	public void setWin(boolean win) {
		this.win = win;
	}
	public String getRewardList() {
		return rewardList;
	}
	public void setRewardList(String rewardList) {
		this.rewardList = rewardList;
	}
	public List<BattleResult> getBattleOneResult() {
		return battleOneResult;
	}
	public void setBattleOneResult(List<BattleResult> battleOneResult) {
		this.battleOneResult = battleOneResult;
	}
	public List<BattleResult> getBattleTwoResult() {
		return battleTwoResult;
	}
	public void setBattleTwoResult(List<BattleResult> battleTwoResult) {
		this.battleTwoResult = battleTwoResult;
	}
	public List<BattleResult> getBattleThreeResult() {
		return battleThreeResult;
	}
	public void setBattleThreeResult(List<BattleResult> battleThreeResult) {
		this.battleThreeResult = battleThreeResult;
	}
	public boolean isBreakTop() {
		return breakTop;
	}
	public void setBreakTop(boolean breakTop) {
		this.breakTop = breakTop;
	}
	public List<BattleGroupDto> getAttackOneGroup() {
		return attackOneGroup;
	}
	public void setAttackOneGroup(List<BattleGroupDto> attackOneGroup) {
		this.attackOneGroup = attackOneGroup;
	}
	public List<BattleGroupDto> getDefendOneGroup() {
		return defendOneGroup;
	}
	public void setDefendOneGroup(List<BattleGroupDto> defendOneGroup) {
		this.defendOneGroup = defendOneGroup;
	}
	public List<BattleGroupDto> getAttackTwoGroup() {
		return attackTwoGroup;
	}
	public void setAttackTwoGroup(List<BattleGroupDto> attackTwoGroup) {
		this.attackTwoGroup = attackTwoGroup;
	}
	public List<BattleGroupDto> getDefendTwoGroup() {
		return defendTwoGroup;
	}
	public void setDefendTwoGroup(List<BattleGroupDto> defendTwoGroup) {
		this.defendTwoGroup = defendTwoGroup;
	}
	public List<BattleGroupDto> getAttackThreeGroup() {
		return attackThreeGroup;
	}
	public void setAttackThreeGroup(List<BattleGroupDto> attackThreeGroup) {
		this.attackThreeGroup = attackThreeGroup;
	}
	public List<BattleGroupDto> getDefendThreeGroup() {
		return defendThreeGroup;
	}
	public void setDefendThreeGroup(List<BattleGroupDto> defendThreeGroup) {
		this.defendThreeGroup = defendThreeGroup;
	}
	public List<BattleResult> getBattleResult(int i) {
		switch (i) {
		case 0:
			return battleOneResult;
		case 1:
			return battleTwoResult;
		case 2:
			return battleThreeResult;
		default:
			return null;
		}
	}
	public void addBattleOneResult(BattleResult battleResult){
		this.battleOneResult.add(battleResult);
	}
	public void addBattleTwoResult(BattleResult battleResult){
		this.battleTwoResult.add(battleResult);
	}
	public void addBattleThreeResult(BattleResult battleResult){
		this.battleThreeResult.add(battleResult);
	}

}

