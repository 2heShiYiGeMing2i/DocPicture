/**
 * @file:ValueType.java
 * @author:David
 **/
package com.xx.dev.constant;
/**
 * @class:ValueType
 * @description:数值类型
 * @author:David
 * @version:v1.0
 * @date:2013-4-19
 **/
public enum ValueType {

	/**
	 * 0-无
	 */
	NONE,
	
	/**
	 * 1-固定值
	 */
	FIX,
	
	/**
	 * 2-百分比
	 */
	PERCENT;
	
	public static ValueType valueOf(int valueType){
		switch (valueType) {
		case 1:
			return FIX;
		case 2:
			return PERCENT;
		default:
			return NONE;
		}
	}
}

