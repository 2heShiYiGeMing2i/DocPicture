/**
 * @file:BattleBigRoundInfo.java
 * @author:David
 **/
package com.xx.dev.modules.battle.model;
/**
 * @class:BattleBigRoundInfo
 * @description:
 * @author:David
 * @version:v1.0
 * @date:2014-1-10
 **/
public class BattleBigRoundInfo {
	/** 当前大回合数 */
	private int currRound;
	/** 血量变化值 **/
	private BattleAttrChanges attrChanges;
	
	
	public BattleBigRoundInfo(int currRound, BattleAttrChanges attrChanges) {
		super();
		this.currRound = currRound;
		this.attrChanges = attrChanges;
	}
	public int getCurrRound() {
		return currRound;
	}
	public void setCurrRound(int currRound) {
		this.currRound = currRound;
	}
	public BattleAttrChanges getAttrChanges() {
		return attrChanges;
	}
	public void setAttrChanges(BattleAttrChanges attrChanges) {
		this.attrChanges = attrChanges;
	}
	
}

