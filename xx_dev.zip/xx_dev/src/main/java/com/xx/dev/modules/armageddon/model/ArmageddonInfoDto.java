/**
 * @file:ArmageddonInfoDto.java
 * @author:David
 **/
package com.xx.dev.modules.armageddon.model;

import org.apache.commons.lang.StringUtils;

import com.xx.dev.modules.armageddon.entity.PlayerArmageddonInfo;
import com.xx.dev.modules.drop.model.DropResult;
import com.xx.dev.modules.reward.support.RewardHelper;
import com.xx.dev.utils.ServiceFactory;

/**
 * @class:ArmageddonInfoDto
 * @description:
 * @author:David
 * @version:v1.0
 * @date:2013-5-21
 **/
public class ArmageddonInfoDto {
	/**
	 * 当前据点进度ID
	 */
	private Integer missionId = -1;
	/**
	 * 当前已开放最大副本ID
	 */
	private Integer openMissionId = -1;
	/**
	 * 最近通关的最大副本ID
	 */
	private Integer lastMissionId;
	/**
	 * 当前累计的奖励串结果是否可以领取(据点通关)
	 */
	private boolean reward = false;
	/** 
	 * 累计奖励 List<Reward> toString
	 */
	private String rewardList;
	/**
	 * 当前剩余免费次数
	 */
	private Integer times = 0;
	/**
	 * 难度 1-容易 2-困难
	 */
	private int hardType = 0;
	/**
	 * 战斗CD时间
	 */
	private long battleCdTime = -1l;
	/**
	 * 是否首次进入 
	 */
	private boolean first = true;
	
	public ArmageddonInfoDto() {
		super();
	}
	public ArmageddonInfoDto(PlayerArmageddonInfo playerChapterInfo, int rewardTimes) {
		super();
		this.missionId = playerChapterInfo.getCurMissionId();
		this.openMissionId = playerChapterInfo.getMissionId();
		this.lastMissionId = playerChapterInfo.getLastMissionId();
		this.reward = playerChapterInfo.isReward();
		if(StringUtils.isNotBlank(playerChapterInfo.getRewardResult())){
			DropResult result = ServiceFactory.getDropService().parseDropResult(playerChapterInfo.getId(), playerChapterInfo.getRewardResult(), playerChapterInfo.getNoticeResult());
			this.rewardList = RewardHelper.toRewardString(result.getRewardList());
		}
		if(playerChapterInfo.isRewardSameResetTime()){
			this.times = rewardTimes;
		}else {
			this.times = playerChapterInfo.getTimes();
		}
		this.hardType = playerChapterInfo.getHardType().ordinal();
		this.battleCdTime = playerChapterInfo.getBattleCdTime();
		this.first = playerChapterInfo.isFirst();
	}
	public Integer getMissionId() {
		return missionId;
	}
	public void setMissionId(Integer missionId) {
		this.missionId = missionId;
	}
	public Integer getOpenMissionId() {
		return openMissionId;
	}
	public void setOpenMissionId(Integer openMissionId) {
		this.openMissionId = openMissionId;
	}
	public boolean isReward() {
		return reward;
	}
	public void setReward(boolean reward) {
		this.reward = reward;
	}
	public String getRewardList() {
		return rewardList;
	}
	public void setRewardList(String rewardList) {
		this.rewardList = rewardList;
	}
	public Integer getTimes() {
		return times;
	}
	public void setTimes(Integer times) {
		this.times = times;
	}
	public int getHardType() {
		return hardType;
	}
	public void setHardType(int hardType) {
		this.hardType = hardType;
	}
	public Integer getLastMissionId() {
		return lastMissionId;
	}
	public void setLastMissionId(Integer lastMissionId) {
		this.lastMissionId = lastMissionId;
	}
	public long getBattleCdTime() {
		return battleCdTime;
	}
	public void setBattleCdTime(long battleCdTime) {
		this.battleCdTime = battleCdTime;
	}
	public boolean isFirst() {
		return first;
	}
	public void setFirst(boolean first) {
		this.first = first;
	}
	
}

