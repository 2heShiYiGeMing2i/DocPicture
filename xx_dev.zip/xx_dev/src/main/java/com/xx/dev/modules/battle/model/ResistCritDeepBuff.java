/**
 * @file:ResistCritDeepBuff.java
 * @author:David
 **/
package com.xx.dev.modules.battle.model;
/**
 * @class:ResistCritDeepBuff
 * @description:格挡伤害加深或减免
 * @author:David
 * @version:v1.0
 * @date:2013-4-30
 **/
public class ResistCritDeepBuff extends AbstractBuff {

	public ResistCritDeepBuff(int effectBaseValueType, double effectBase,
			int effectValueType, double effect, int startRound, int persistRound) {
		super(effectBaseValueType, effectBase, effectValueType, effect, startRound,
				persistRound);
	}

}

