package com.xx.dev.constant;

/**
 * 用户被踢下线的原因
 * 
 * @author Along
 *
 */
public enum CloseReason {

	/**0-链接关闭(客户端对此不做反应仅不让重连)*/
	COMMON_CLOSE,
	
	/**1-在其他地方登陆*/
	ANOTHER_LOGIN,
	
	/**2-被管理后台踢下线*/
	KICKED,
	
	/**3-IP被封*/
	IP_BLOCKED,
	
	/**4-账号被封*/
	LOGIN_BLOCKED,
	
	/**5-服务器关闭*/
	SERVER_CLOSING;
	
}

