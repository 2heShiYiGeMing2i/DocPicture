/**
 * @file:BattleCmd.java
 * @author:David
 **/
package com.xx.dev.modules.battle.hanlder;
/**
 * @class:BattleCmd
 * @description:战斗模块
 * @author:David
 * @version:v1.0
 * @date:2013-4-27
 **/
public interface BattleCmd {

	final String MODULE_NAME = "BATTLE";
	
	int BATTLE_TEST = 1;
}

