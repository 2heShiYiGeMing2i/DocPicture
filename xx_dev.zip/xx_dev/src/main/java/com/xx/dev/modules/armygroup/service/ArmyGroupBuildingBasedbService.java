package com.xx.dev.modules.armygroup.service;

import java.util.List;

import com.xx.dev.modules.armygroup.model.basedb.ArmyGroupBuildingOpen;

/**
 * 军团建筑基础数据服务接口
 * 
 * @author Along
 *
 */
public interface ArmyGroupBuildingBasedbService {

	/**
	 * 获取排过序的军团建筑列表
	 * @return
	 */
	public List<ArmyGroupBuildingOpen> getBuildings();
	
}
