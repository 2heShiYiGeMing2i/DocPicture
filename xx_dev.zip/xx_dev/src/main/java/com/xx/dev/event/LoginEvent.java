package com.xx.dev.event;

import java.util.Date;

import org.apache.mina.core.session.IoSession;

import com.xx.common.event.Event;
import com.xx.dev.constant.LoginWay;
import com.xx.dev.modules.player.handler.PlayerCmd;

/**
 * 用户登录事件
 * 
 * @author Along
 *
 */
public class LoginEvent {

	/**
	 * 登录事件
	 */
	public static final String NAME = PlayerCmd.MODULE_NAME + ":LOGIN";

	/**
	 * 用户id
	 */
	private long id = -1L;

	/**
	 * 登录的Session
	 */
	private IoSession currSession;

	/**
	 * 被踢的Session
	 */
	private IoSession kickSession;

	/**
	 * 登录时间
	 */
	private Date loginTime;

	/**
	 * 登陆方式
	 */
	private LoginWay loginWay;

	public long getPlayerId() {
		return id;
	}

	public IoSession getCurrSession() {
		return currSession;
	}

	public IoSession getKickSession() {
		return kickSession;
	}

	public Date getLoginTime() {
		return loginTime;
	}

	public LoginWay getLoginWay() {
		return loginWay;
	}

	public static Event<LoginEvent> valueOf(long id, IoSession currSession,
			Date loginTime, LoginWay loginWay) {
		return valueOf(id, currSession, null, loginTime, loginWay);
	}

	public static Event<LoginEvent> valueOf(long id, IoSession currSession,
			IoSession kickSession, Date loginTime, LoginWay loginWay) {
		LoginEvent body = new LoginEvent();
		body.id = id;
		body.currSession = currSession;
		body.kickSession = kickSession;
		body.loginTime = loginTime;
		body.loginWay = loginWay;
		return new Event<LoginEvent>(NAME, body);
	}

}
