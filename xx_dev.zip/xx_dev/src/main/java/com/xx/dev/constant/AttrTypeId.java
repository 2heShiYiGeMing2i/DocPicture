package com.xx.dev.constant;

/**
 * 属性类型编号
 * 
 * @author Along
 *
 */
public interface AttrTypeId {
	
	/**
	 * 1-物攻
	 */
	int ATTACK = 1;
	
	/**
	 * 2-物防
	 */
	int DEFEND = 2;
	
	/**
	 * 3-策攻
	 */
	int STRATEGY_ATTACK = 3;
	
	/**
	 * 4-策防
	 */
	int STRATEGY_DEFEND = 4;
	
	/**
	 * 5-暴击
	 */
	int CRIT = 5;
	
	/**
	 * 6-格挡
	 */
	int RESIST = 6;
	
	/**
	 * 7-带兵数量
	 */
	int COMMAND_AMOUNT = 7;
	
	/**
	 * 8-技能威力
	 */
	int SKILLPOWER = 8;
	
	/**
	 * 9-步兵相性
	 */
	int WALKER = 9;
	
	/**
	 * 10-骑兵相性
	 */
	int RIDER = 10;
	
	/**
	 * 11-谋士相性
	 */
	int MAGICIAN = 11;
	
	/**
	 * 12-辎重相性
	 */
	int SUPPLY =12;
	
	/**
	 * 13-弓兵相性
	 */
	int ARCHER = 13;
	
	
	/**
	 * 武力
	 */
	int POWER = 21;
	
	/**
	 * 智力
	 */
	int BRAINS = 22;
	
	/**
	 * 魅力
	 */
	int CHARM = 23;
	
	/**
	 * 统帅
	 */
	int COMMAND = 24;
	
	/**
	 * 技能防御
	 */
	int SKILLDEFEND = 25;
	
}
