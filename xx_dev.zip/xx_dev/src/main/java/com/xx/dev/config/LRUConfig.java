/**
 * @file:LRUConfig.java
 * @author:David
 **/
package com.xx.dev.config;
/**
 * @class:LRUConfig
 * @description:游戏服务端公共LRU参数配置管理
 * @author:David
 * @version:v1.0
 * @date:2013-4-18
 **/
public interface LRUConfig {

	/**
	 * 聊天时间缓存队列长度
	 */
	public static final int TIMECD_SIZE = 1000;
	/** 
	 * 技能效果集缓存 
	 */
	public final static int SKILL_EFFECT = 1000;
	/**
	 * 单人副本战斗上下文缓存
	 */
	public final static int CHAPTER = 2000;
	/**
	 * 武将技能刷新技能ID缓存
	 */
	public final static int SKILL_REFLUSH = 2000;
	/**
	 * 单人副本张角模拟数据缓存
	 */
	public final static int CHAPTER_MOCK = 5000;
}

