/**
 * @file:BattlePlayerInfo.java
 * @author:David
 **/
package com.xx.dev.modules.battle.model;

import com.xx.dev.constant.CharacterType;
import com.xx.dev.modules.player.entity.Player;
import com.xx.dev.utils.ServiceFactory;

/**
 * @class:BattlePlayerInfo
 * @description:战斗主公信息
 * @author:David
 * @version:v1.0
 * @date:2013-6-18
 **/
public class BattlePlayerInfo {
	/**
	 * 角色类型
	 */
	private CharacterType characterType;
	/**
	 * 主公ID
	 */
	private Long playerId;
	/**
	 * 主公名称
	 */
	private String playerName;
	/**
	 * 主公等级
	 */
	private int playerLevel;
	/**
	 * 主公头像
	 */
	private int playerHeadId = -1;
	/**
	 * NPC头像
	 */
	private String npcPic;
	/** 
	 * 战斗力
	 */
	private double ability = 0.0;
	/**
	 * 军威的等级 
	 */
	private int junWeiLevel = 0;
	
	public BattlePlayerInfo() {
		super();
	}

	public BattlePlayerInfo(Player player) {
		super();
		this.characterType = CharacterType.PLAYER;
		this.playerId = player.getId();
		this.playerName = player.getPlayerName();
		this.playerLevel = player.getLevel();
		this.playerHeadId = player.getHeadId();
		this.ability = player.getAbility(); 
		this.junWeiLevel = ServiceFactory.getTrainingService().getJunWeiSkillLevel(playerId);
	}
	
	public BattlePlayerInfo(String playerName, int playerLevel, int playerHeadId, double ability,
			int junWeiLevel) {// 玩家镜像，当作是PVP，军威生效
		super();
		this.playerName = playerName;
		this.playerLevel = playerLevel;
		this.playerHeadId = playerHeadId;
		this.ability = ability;
		this.junWeiLevel = junWeiLevel;
		this.characterType = CharacterType.PLAYER;
	}
	
	public BattlePlayerInfo(String playerName, int playerLevel, int playerHeadId, double ability) {// 玩家镜像，当作是PVE，军威不生效
		super();
		this.playerName = playerName;
		this.playerLevel = playerLevel;
		this.playerHeadId = playerHeadId;
		this.ability = ability;
		this.characterType = CharacterType.NPC;
	}
	
	public BattlePlayerInfo(String playerName, int playerLevel, String npcPic, double ability) {
		super();
		this.playerName = playerName;
		this.playerLevel = playerLevel;
		this.npcPic = npcPic;
		this.ability = ability;
		this.characterType = CharacterType.NPC;
	}

	public String getPlayerName() {
		return playerName;
	}
	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}
	public int getPlayerLevel() {
		return playerLevel;
	}
	public void setPlayerLevel(int playerLevel) {
		this.playerLevel = playerLevel;
	}
	public int getPlayerHeadId() {
		return playerHeadId;
	}
	public void setPlayerHeadId(int playerHeadId) {
		this.playerHeadId = playerHeadId;
	}
	public String getNpcPic() {
		return npcPic;
	}
	public void setNpcPic(String npcPic) {
		this.npcPic = npcPic;
	}
	public double getAbility() {
		return ability;
	}
	public void setAbility(double ability) {
		this.ability = ability;
	}

	public Long getPlayerId() {
		return playerId;
	}

	public void setPlayerId(Long playerId) {
		this.playerId = playerId;
	}

	public int getJunWeiLevel() {
		return junWeiLevel;
	}

	public void setJunWeiLevel(int junWeiLevel) {
		this.junWeiLevel = junWeiLevel;
	}

	public CharacterType getCharacterType() {
		return characterType;
	}

	public void setCharacterType(CharacterType characterType) {
		this.characterType = characterType;
	}
	
}

