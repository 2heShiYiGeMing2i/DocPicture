package com.xx.dev.modules.barracks.handler;

import com.xx.dev.constant.CommonConstant;

/**
 * 兵营模块状态码
 * 
 * @author Along
 *
 */
public interface BarracksResult extends CommonConstant {

	/**
	 * 官府等级不够
	 */
	int NO_ENOUGH_OFFICE_LEVEL = -10001;
	
	/**
	 * 冷却中
	 */
	int COOLING = -10002;
	
	/**
	 * 兵营等级不够
	 */
	int NO_ENOUGH_BARRACKS_LEVEL = -10003;
	
	/**
	 * 已经训练过该兵种
	 */
	int HAD_TRAINED = -10004;
	
	/**
	 * 士兵人数上限
	 */
	int SOLDIER_AMOUNT_LIMIT = -10005;
	
	/**
	 * 必须先训练上一阶的兵种
	 */
	int MUST_TRAIN_PRE_STAR = -10006;
	
	/**
	 * 士兵数量不足
	 */
	int NO_ENOUGH_SOLDIER_AMOUNT = -10007;
	
	/**
	 * 兵营未开放
	 */
	int BARRACKS_NO_OPEN = -10008;
	
	/**
	 * 不能再升级（已经是最高级）
	 */
	int CAN_NOT_UPGRADE = -10009;
	
}
