package com.xx.dev.combineserver;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

import org.apache.commons.lang.ArrayUtils;

/**
 * 合服模块
 * 
 * @author Along
 *
 */
public class CombineServer {

	/**
	 * 删除错误的数据SQL（玩家id=0）
	 */
	private static final String DEL_ERROR_DATA_FILE = "sql/delErrorData.sql";
	
	/**
	 * 移除低级非人民币玩家SQL
	 */
	private static final String REMOVE_PLAYER_FILE = "sql/removePlayer.sql";
	
	/**
	 * 合服后更新数据SQL（移除没人军团，修复没有团长的军团，玩家重名处理，军团重名处理等）
	 */
	private static final String UPDATE_DATA_FILE = "sql/updateData.sql";
	
	/**
	 * 忽略不导出的表[数据库名.表名]
	 */
	private static final String IGNORE_TABLE = "--ignore-table=%s.%s";
	
	/**
	 * 备份的时候是否添加选项 --add-drop-table
	 */
	private static final String DROP_TABLE = "--add-drop-table";
	
	public static void main(String[] args) {
		JdbcCfg.init();
		if (!JdbcCfg.ready) {
			System.out.println("读取Jdbc配置文件失败。");
			System.exit(-1);
			return;
		}
		CombineCfg.init();
		if (!CombineCfg.ready) {
			System.out.println("读取合服配置文件失败。");
			System.exit(-1);
			return;
		}
		CombineServerInfoCfg.init(JdbcCfg.serverInfo.getUserName(), JdbcCfg.serverInfo.getPassword());
		if (!CombineServerInfoCfg.ready) {
			System.out.println("读取合服数据库配置文件失败。");
			System.exit(-1);
			return;
		}
		
		boolean isSuccess = false;
		String filePath = getTmpFileFullPath(JdbcCfg.serverInfo.getDatabase());
		int retryTimes = 1;
		while (retryTimes <= CombineCfg.retryTimes) {
			isSuccess = backupTargetDatabase(filePath, retryTimes);
			if (isSuccess) {
				break;
			} else {
				retryTimes++;
			}
		}
		
		if (isSuccess) {// 成功备份目标数据库
			retryTimes = 1;
			isSuccess = false;
			while (retryTimes <= CombineCfg.retryTimes) {
				isSuccess = process(filePath, retryTimes);
				if (isSuccess) {
					break;
				} else {
					retryTimes++;
				}
			}
			
			if (CombineCfg.cleanTempFile) {
				File file = new File(filePath);
				if (file.isFile() && file.exists()) {// 路径为文件且不为空则进行删除
					file.delete();
				}
				
				File folder = new File(getTmpFolder());
				if (folder.exists()) {
					file.delete();
				}
			}
			
			if (isSuccess) {
				System.exit(0);
				System.out.println("成功合服。");
			} else {
				System.exit(2);
				System.out.println("合服失败。");
			}
		} else {
			System.exit(1);
			System.out.println("合服失败。");
		}
	}

	/**
	 * 备份目标库到文件
	 * @param filePath 保存文件的路径
	 * @param retryTimes 重试次数
	 * @return
	 */
	private static boolean backupTargetDatabase(String filePath, int retryTimes) {
		boolean isSaveSuccess = saveToFile(CombineCfg.mysqlPath, JdbcCfg.serverInfo.getHost(), JdbcCfg.serverInfo.getPort(), 
				JdbcCfg.serverInfo.getUserName(), JdbcCfg.serverInfo.getPassword(), JdbcCfg.serverInfo.getDatabase(), filePath, true, true);
		if (isSaveSuccess) {
			return true;
		} else {
			System.out.println(String.format("第%d次备份数据库'%s'失败。", retryTimes, JdbcCfg.serverInfo.getDatabase()));
			return false;
		}
	}

	/**
	 * 合服处理
	 * @param filePath 目标库的备份路径
	 * @param retryTimes 重试次数
	 * @return
	 */
	private static boolean process(String filePath, int retryTimes) {
		boolean result = false;
		
		if (retryTimes > 1) {// 清空目标库
			boolean isImportSuccess = execSqlFile(CombineCfg.mysqlPath, JdbcCfg.serverInfo.getHost(), 
					JdbcCfg.serverInfo.getPort(), JdbcCfg.serverInfo.getUserName(), JdbcCfg.serverInfo.getPassword(), 
					JdbcCfg.serverInfo.getDatabase(), filePath);
			if (!isImportSuccess) {
				System.out.println(String.format("第%d次恢复数据库'%s'失败。", retryTimes, JdbcCfg.serverInfo.getDatabase()));
				return result;
			}
		}
		
		boolean isFirst = true;
		int successTimes = 0;
		for (int key : CombineServerInfoCfg.serverInfos.keySet()) {
			ServerInfo serverInfo = CombineServerInfoCfg.serverInfos.get(key);
			boolean isCombineSuccess = combineDatabase(serverInfo, isFirst);
			if (!isCombineSuccess) {
				break;
			} else {
				if (isFirst) {
					isFirst = false;
				}
				successTimes++;
			}
		}
		
		if (successTimes == CombineServerInfoCfg.serverInfos.keySet().size()) {
			System.out.println(String.format("第%d次成功合并%d个数据库。", retryTimes, successTimes));
		} else {
			System.out.println(String.format("第%d次合并%d个数据库失败。", retryTimes, CombineServerInfoCfg.serverInfos.keySet().size()));
			return result;
		}
		
		// 处理合并后的数据
		boolean isDeleteSuccess = execSqlFile(CombineCfg.mysqlPath, JdbcCfg.serverInfo.getHost(), 
				JdbcCfg.serverInfo.getPort(), JdbcCfg.serverInfo.getUserName(), JdbcCfg.serverInfo.getPassword(), 
				JdbcCfg.serverInfo.getDatabase(), getFileFullPath(REMOVE_PLAYER_FILE));
		if (isDeleteSuccess) {// 移除低级非人民币玩家数据
			boolean isUpdateSuccess = execSqlFile(CombineCfg.mysqlPath, JdbcCfg.serverInfo.getHost(), 
					JdbcCfg.serverInfo.getPort(), JdbcCfg.serverInfo.getUserName(), JdbcCfg.serverInfo.getPassword(), 
					JdbcCfg.serverInfo.getDatabase(), getFileFullPath(UPDATE_DATA_FILE));
			if (isUpdateSuccess) {// 合服后修改数据
				result = true;
			} else {
				System.out.println(String.format("第%d次合服后修改数据失败。", retryTimes));
				return result;
			}
		} else {
			System.out.println(String.format("第%d次移除低级非人民币玩家数据失败。", retryTimes));
			return result;
		}
		return result;
	}
	
	/**
	 * 合并数据库
	 * @param serverCfg 数据库配置
	 * @param isFirst 是否是第一个服
	 * @return
	 */
	private static boolean combineDatabase(ServerInfo serverCfg, boolean isFirst) {
		boolean result = false;
		String filePath = getTmpFileFullPath(serverCfg.getDatabase());
		// 备份到文件
		boolean isSaveSuccess = saveToFile(CombineCfg.mysqlPath, serverCfg.getHost(), serverCfg.getPort(), 
				serverCfg.getUserName(), serverCfg.getPassword(), serverCfg.getDatabase(), filePath, isFirst, false);
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		if (isSaveSuccess) {// 从备份文件导入目标库
			boolean isImportSuccess = execSqlFile(CombineCfg.mysqlPath, JdbcCfg.serverInfo.getHost(), 
					JdbcCfg.serverInfo.getPort(), JdbcCfg.serverInfo.getUserName(), JdbcCfg.serverInfo.getPassword(), 
					JdbcCfg.serverInfo.getDatabase(), filePath);
			if (isImportSuccess) {// 删除会引起主键重复的数据
				boolean isDelSuccess = execSqlFile(CombineCfg.mysqlPath, JdbcCfg.serverInfo.getHost(), 
						JdbcCfg.serverInfo.getPort(), JdbcCfg.serverInfo.getUserName(), JdbcCfg.serverInfo.getPassword(), 
						JdbcCfg.serverInfo.getDatabase(), getFileFullPath(DEL_ERROR_DATA_FILE));
				if (isDelSuccess) {
					result = true;
				}
			}
		}
		if (CombineCfg.cleanTempFile) {
			File file = new File(filePath);
			if (file.isFile() && file.exists()) {// 路径为文件且不为空则进行删除
				file.delete();
			}
		}
		return result;
	}

	private static String getTmpFolder() {
		StringBuilder buf = new StringBuilder();
		// 用当前classPath
		//String path = CombineServer.class.getResource("/").getPath();
		String path = System.getProperty("user.dir");
		buf.append(path).append(CombineCfg.folder);
		String folder = buf.toString();
		File file = new File(folder);
		if (!file.exists()) {// 创建临时目录
			file.mkdir();
		}
		return folder;
	}
	
	private static String getTmpFileFullPath(String fileName) {
		StringBuilder buf = new StringBuilder();
		String folder = getTmpFolder();
		buf.append(folder).append(fileName);
		return buf.toString();
	}
	
	private static String getFileFullPath(String fileName) {
		StringBuilder buf = new StringBuilder();
		String path = System.getProperty("user.dir");
		buf.append(path).append("/").append(fileName);
		return buf.toString();
	}
	
	private static boolean saveToFile(String mysqlPath, String host, String port, String userName, String password, 
			String database, String filePath, boolean isFirst, boolean isDropTable) {
		boolean result = false;
		Process process = null;
		try {
			String dropTableString = "";
			String mysqldumpString = "%smysqldump -h%s -P%s -u%s -p%s --default-character-set=utf8 -v -t -n -c -q --compact %s %s %s -r %s";
			String ignoreTables = getIgnoreTables(database, CombineCfg.ignoreTables, false);
			String importOneTables = getIgnoreTables(database, CombineCfg.importOneTables, isFirst);
			if (isDropTable) {
				mysqldumpString = "%smysqldump -h%s -P%s -u%s -p%s --default-character-set=utf8 -v -n -c -q --compact %s %s %s -r %s";
				dropTableString = DROP_TABLE;
				ignoreTables = "";
				importOneTables = "";
			}
	        mysqldumpString = String.format(mysqldumpString, mysqlPath, host, port, userName, password, ignoreTables + importOneTables, 
	        		dropTableString, database, filePath);
	        System.out.println(String.format("ready save '%s' to file %s!", database, filePath));
			Runtime runtime = Runtime.getRuntime();
			process = runtime.exec(mysqldumpString);

			/*
			 * 外部的进程必须与主进程同步，因为主进程要知道外部的线程是否成功执行后才可以返回，这样就必须调用waitFor()方法，
			 * 而Process的waitFor()方法是可能阻塞线程的执行的，如果waitFor()方法会写缓存，包括标准输入缓存和标准错误缓存，如果
			 * 这两个缓存写满了，而这两个又没有被读取使用掉，那么waitFor()方法就会阻塞，等待缓存被读取，所以要加下面这一段来
			 * 保证在任何时候缓存都被正确读取，这样才可以保证waitFor()方法顺畅的执行完毕，而不至于应阻塞进入死锁。
			 */
			final BufferedReader errBr = new BufferedReader(new InputStreamReader(process.getErrorStream(), "utf8"));
			MyThread readThread = 
				new MyThread() {
					public void run() {
						String errLine = null;
						try {
							while (isFlag() && (errLine = errBr.readLine()) != null) {
								System.out.println(errLine);
							}
							errBr.close();
						} catch (IOException e) {
							e.printStackTrace();
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				};
			readThread.start();
			
			int exitVal = process.waitFor();
			if (exitVal == 0) {
				System.out.println(String.format("'%s' success save to file %s!", database, filePath));
				result = true;
			} else {
				System.out.println(String.format("'%s' failed to save file %s!", database, filePath));
			}
			readThread.setFlag(false);
		} catch (Exception e) {
			e.printStackTrace();
		} catch (Error e) {
			e.printStackTrace();
		} finally {
			try {
				process.getErrorStream().close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return result;
	}

	private static boolean execSqlFile(String mysqlPath, String host, String port, String userName, String password, String database, String filePath) {  
		boolean result = false;
		Process process = null;
        try {   
            String openMysqlString = "%smysql -h%s -P%s -u%s -p%s --default-character-set=utf8";
            openMysqlString = String.format(openMysqlString, mysqlPath, host, port, userName, password);
            String sql1 = "use %s";
            sql1 = String.format(sql1, database);
            String sql2 = "source %s";
            sql2 = String.format(sql2, filePath);
            
            System.out.println(String.format("database'%s' ready exec '%s'!", database, filePath));
            Runtime runtime = Runtime.getRuntime();   
            process = runtime.exec(openMysqlString);  
            final BufferedReader inBufferedReader = new BufferedReader(new InputStreamReader(process.getInputStream(), "utf8"));
            MyThread readInThread = 
            	new MyThread() {
	            	public void run() {
	            		String infoLine = null;
	            		try {
	            			while ((infoLine = inBufferedReader.readLine()) != null) {
	            				System.out.println(infoLine);
	            			}
	            			inBufferedReader.close();
	            		} catch (IOException e) {
	            			e.printStackTrace();
	            		} catch (Exception e) {
	            			e.printStackTrace();
	            		}
	            	}
            	};
            readInThread.start();
            
			final BufferedReader errBufferedReader = new BufferedReader(new InputStreamReader(process.getErrorStream(), "utf8"));
			MyThread readErrThread = 
				new MyThread() {
					public void run() {
						String errLine = null;
						try {
							while ((errLine = errBufferedReader.readLine()) != null) {
								System.out.println(errLine);
							}
							errBufferedReader.close();
						} catch (IOException e) {
							e.printStackTrace();
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				};
			readErrThread.start();
			
			OutputStream outputStream = process.getOutputStream();
			OutputStreamWriter writer = new OutputStreamWriter(outputStream);
			writer.write(sql1 + "\r\n" + sql2);
			writer.flush();
			writer.close();
			outputStream.close();
			  
			int exitVal = process.waitFor();
			if (exitVal == 0) {
				System.out.println(String.format("'%s' success exec file %s!", database, filePath));
				result = true;
			} else {
				System.out.println(String.format("'%s' failed to exec file %s!", database, filePath));
			}
			readInThread.setFlag(false);
			readErrThread.setFlag(false);
        } catch (Exception e) {   
            e.printStackTrace();   
        } finally {
			try {
				process.getInputStream().close();
				process.getErrorStream().close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}  
        return result;
    }
	
	/**
	 * 返回导表的时候要忽略的表设置
	 * @param database 数据库
	 * @param ignoreTables 要忽略的数据表数组
	 * @param isFirst 是否是第一个库
	 * @return
	 */
	private static String getIgnoreTables(String database, String[] ignoreTables, boolean isFirst) {
		if (isFirst) {
			return "";
		} else {
			if (ArrayUtils.isNotEmpty(ignoreTables)) {
				StringBuilder buf = new StringBuilder();
				for (int i = 0; i < ignoreTables.length; i++) {
					String tableName = ignoreTables[i];
					tableName = tableName.trim();
					buf.append(String.format(IGNORE_TABLE, database, tableName)).append(" ");
				}
				return buf.toString();
			} else {
				return "";
			}
		}
	}
	
}
