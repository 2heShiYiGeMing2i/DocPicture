package com.xx.dev.modules.arena.model.basedb;

import com.xx.common.basedb.anno.Id;
import com.xx.common.basedb.anno.Resource;


/**
 * 竞技场卡牌信息
 * 
 * @author bingshan
 */
@Resource
public class ArenaCard {
	/**
	 * 主键id
	 */
	@Id
	private int id;
	
	/**
	 * 奖励串
	 */
	private String reward;
	
	/**
	 * 掉落概率
	 */
	private int rate = 0;
	
	/**
	 * 满值 
	 */
	private int fullValue = 100;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getReward() {
		return reward;
	}

	public void setReward(String reward) {
		this.reward = reward;
	}

	public int getRate() {
		return rate;
	}

	public void setRate(int rate) {
		this.rate = rate;
	}

	public int getFullValue() {
		return fullValue;
	}

	public void setFullValue(int fullValue) {
		this.fullValue = fullValue;
	}
}
