package com.xx.dev.modules.bejeweled.model.basedb;

import com.xx.common.basedb.anno.Id;
import com.xx.common.basedb.anno.Index;
import com.xx.common.basedb.anno.Resource;
import com.xx.dev.constant.IndexName;

/**
 * Created by LiangZengle on 2014/6/23.
 */
@Resource
public class BejeweledBox {

    @Id
    private int id;

    /**
     * 宝箱等级
     */
    @Index(name = IndexName.BEJEWELED_BOX_LEVEL_INDEX)
    private int level;

    /**
     * 升级需要的分数
     */
    private int score;

    /**
     * 奖励串
     */
    private String reward;

    /**
     * 掉落串
     */
    private String drop;

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public String getDrop() {
        return drop;
    }

    public void setDrop(String drop) {
        this.drop = drop;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public String getReward() {
        return reward;
    }

    public void setReward(String reward) {
        this.reward = reward;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
