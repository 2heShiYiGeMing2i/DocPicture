/**
 * @file:HpAttackBuff.java
 * @author:David
 **/
package com.xx.dev.modules.battle.model;
/**
 * @class:HpAttackBuff
 * @description:生命越低则攻击越高
 * @author:David
 * @version:v1.0
 * @date:2013-4-28
 **/
public class HpAttackBuff extends AbstractBuff {
	/**
	 * 物理攻击或者策略攻击
	 */
	private int attrType;
	
	public HpAttackBuff(int attrType, int effectBaseValueType, double effectBase,
			int effectValueType, double effect, int startRound, int persistRound) {
		super(effectBaseValueType, effectBase, effectValueType, effect, startRound,
				persistRound);
		this.attrType = attrType;
	}
	
	public int getAttrType() {
		return attrType;
	}


	public void setAttrType(int attrType) {
		this.attrType = attrType;
	}

	/**
	 * @description:重新赋值	
	 * @param attrType
	 * @param value
	 * @param persistRound
	 */
	public void reflush(int attrType, int effectBaseValueType,
			double effectBase, int effectValueType, double effect, int startRound,
			int persistRound) {
		this.attrType = attrType;
		super.reflush(effectBaseValueType, effectBase, effectValueType, effect, startRound, persistRound);
	}
}

