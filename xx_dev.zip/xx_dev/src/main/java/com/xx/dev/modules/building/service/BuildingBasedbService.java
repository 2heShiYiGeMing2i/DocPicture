package com.xx.dev.modules.building.service;

import java.util.List;

import com.xx.dev.modules.building.model.basedb.CityElement;

/**
 * 主城建筑基础数据服务接口
 * 
 * @author Along
 *
 */
public interface BuildingBasedbService {

	/**
	 * 获取排过序的主城建筑列表
	 * @return
	 */
	public List<CityElement> getCityElements();
	
}
