/**
 * @file:BattleCharacterDto.java
 * @author:David
 **/
package com.xx.dev.modules.battle.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;


/**
 * @class:BattleCharacterDto
 * @description:战斗对象 供客户端使用
 * @author:David
 * @version:v1.0
 * @date:2013-4-26
 **/
public class BattleCharacterDto {
	/** 战斗ID（唯一键） **/
	private Long id;
	/** 玩家ID 如果是 NPC,则是npcID**/
	private long playerId = -1l;
	/** 是否是BOSS 0-非boss 1-是boss */
	private int boss = 0;
	/** 角色类型 */
	private int characterType;
	/** 兵种 */
	private int armType;
	/** 兵阶 **/
	private int armStar;
	/** 带兵数 */
	private int armyCount = 0;
	/** 武将基础数据类型 **/
	private int heroType;
	/** 武将星级 **/
	private int heroStar;
	/**
	 * 武将品阶
	 */
	private int heroRank;
	/** 职业 */
	private int heroVocation;
	/** 等级 **/
	private int level;
	/** 战斗属性 **/
	private BattleAttr battleAttr;
	/** HP上限 */
	public double maxHp;
	/** 战斗所属方阵 */
	private BattleTeam battleTeam;
	/** 玩家在方阵中的出手位置 **/
	private Integer teamPosition = 0;
	/** 主动技能ID  */
	private List<Integer> activeSkillId;
	/** 自定义武将头像ID **/
	private int customHeroHeadId = -1;
	/** 自定义武将名称 **/
	private String customHeroName;
	/** 当前技能ID列表 {skillId: skillLevel}*/
	private Map<Integer, Integer> skillLevelMap;
	/** 战斗力  */
	private double ability = 0.0;
	/** 是否邀请主将 **/
	private boolean cheer = false;
	
	public BattleCharacterDto(BattleCharacter battleCharacter) {
		super();
		this.id = battleCharacter.getId();
		this.playerId = battleCharacter.getPlayerId();
		this.boss = battleCharacter.getBoss();
		this.characterType = battleCharacter.getCharacterType().ordinal();
		this.armType = battleCharacter.getArmType();
		this.armStar = battleCharacter.getArmStar();
		this.armyCount = battleCharacter.getArmyCount();
		this.heroType = battleCharacter.getHeroType();
		this.heroStar = battleCharacter.getHeroStar();
		this.heroRank = battleCharacter.getHeroRank();
		this.heroVocation = battleCharacter.getHeroVocation();
		this.level = battleCharacter.getLevel();
		this.battleAttr = battleCharacter.getBattleAttr().clone();
		this.maxHp = battleCharacter.getMaxHp();
		this.battleTeam = battleCharacter.getBattleTeam();
		this.teamPosition = battleCharacter.getTeamPosition();
		if(battleCharacter.getActiveSkillList() != null && battleCharacter.getActiveSkillList().length > 0){
			BattleSkillInfo[] activeSkillList = battleCharacter.getActiveSkillList();
			activeSkillId = new ArrayList<Integer>();
			for (BattleSkillInfo battleSkillInfo : activeSkillList) {
				activeSkillId.add(battleSkillInfo.getSkill().getId());
			}
		}
		this.customHeroHeadId = battleCharacter.getCustomHeroHeadId();
		this.customHeroName = battleCharacter.getCustomHeroName();
		this.skillLevelMap = battleCharacter.getSkillLevelMap();
		this.ability = battleCharacter.getAbility();
		this.cheer = battleCharacter.isCheer();
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public int getCharacterType() {
		return characterType;
	}
	public void setCharacterType(int characterType) {
		this.characterType = characterType;
	}
	public int getArmType() {
		return armType;
	}
	public void setArmType(int armType) {
		this.armType = armType;
	}
	public int getArmyCount() {
		return armyCount;
	}
	public void setArmyCount(int armyCount) {
		this.armyCount = armyCount;
	}
	public int getHeroVocation() {
		return heroVocation;
	}
	public void setHeroVocation(int heroVocation) {
		this.heroVocation = heroVocation;
	}
	public int getLevel() {
		return level;
	}
	public void setLevel(int level) {
		this.level = level;
	}
	public BattleAttr getBattleAttr() {
		return battleAttr;
	}
	public void setBattleAttr(BattleAttr battleAttr) {
		this.battleAttr = battleAttr;
	}
	public double getMaxHp() {
		return maxHp;
	}
	public void setMaxHp(double maxHp) {
		this.maxHp = maxHp;
	}
	public BattleTeam getBattleTeam() {
		return battleTeam;
	}
	public void setBattleTeam(BattleTeam battleTeam) {
		this.battleTeam = battleTeam;
	}
	public Integer getTeamPosition() {
		return teamPosition;
	}
	public void setTeamPosition(Integer teamPosition) {
		this.teamPosition = teamPosition;
	}
	public long getPlayerId() {
		return playerId;
	}
	public void setPlayerId(long playerId) {
		this.playerId = playerId;
	}
	public int getArmStar() {
		return armStar;
	}
	public void setArmStar(int armStar) {
		this.armStar = armStar;
	}
	public int getHeroType() {
		return heroType;
	}
	public void setHeroType(int heroType) {
		this.heroType = heroType;
	}
	public int getHeroStar() {
		return heroStar;
	}
	public void setHeroStar(int heroStar) {
		this.heroStar = heroStar;
	}
	public int getHeroRank() {
		return heroRank;
	}
	public void setHeroRank(int heroRank) {
		this.heroRank = heroRank;
	}
	public int getBoss() {
		return boss;
	}
	public void setBoss(int boss) {
		this.boss = boss;
	}
	public List<Integer> getActiveSkillId() {
		return activeSkillId;
	}
	public void setActiveSkillId(List<Integer> activeSkillId) {
		this.activeSkillId = activeSkillId;
	}
	public int getCustomHeroHeadId() {
		return customHeroHeadId;
	}
	public void setCustomHeroHeadId(int customHeroHeadId) {
		this.customHeroHeadId = customHeroHeadId;
	}
	public String getCustomHeroName() {
		return customHeroName;
	}
	public void setCustomHeroName(String customHeroName) {
		this.customHeroName = customHeroName;
	}
	public Map<Integer, Integer> getSkillLevelMap() {
		return skillLevelMap;
	}
	public void setSkillLevelMap(Map<Integer, Integer> skillLevelMap) {
		this.skillLevelMap = skillLevelMap;
	}
	public double getAbility() {
		return ability;
	}
	public void setAbility(double ability) {
		this.ability = ability;
	}
	public boolean isCheer() {
		return cheer;
	}
	public void setCheer(boolean cheer) {
		this.cheer = cheer;
	}
}

