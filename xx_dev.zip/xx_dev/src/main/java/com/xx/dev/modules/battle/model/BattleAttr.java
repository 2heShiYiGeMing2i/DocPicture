/**
 * @file:BattleAttr.java
 * @author:David
 **/
package com.xx.dev.modules.battle.model;


/**
 * @class:BattleAttr
 * @description:
 * @author:David
 * @version:v1.0
 * @date:2013-4-19
 **/
public class BattleAttr implements Cloneable{
	/** 物理攻击 */
	public double attack = 0;
	
	/** 物理防御 */
	public double defend = 0;
	
	/** 策略攻击 */
	public double strategyAttack = 0;
	
	/** 策略防御 */
	public double strategyDefend = 0;
	
	/** 暴击率 */
	public double crit = 0;
	
	/** 格挡率 */
	public double resist = 0;
	
	/** 技能威力 */
	public double skillPower = 0;
	
	/** 生命 HP */
	public double hp = 0;
	
	/** 带兵数  */
	public int commandAmount;
	
	/**
	 * 技能防御
	 */
	public double skillDefend = 0;

	public BattleAttr() {
		super();
	}
	public BattleAttr(double attack, double defend, double strategyAttack,
			double strategyDefend, double crit, double resist,
			double skillPower, double hp, double skillDefend) {
		super();
		this.attack = attack;
		this.defend = defend;
		this.strategyAttack = strategyAttack;
		this.strategyDefend = strategyDefend;
		this.crit = crit;
		this.resist = resist;
		this.skillPower = skillPower;
		this.hp = hp;
		this.skillDefend = skillDefend;
	}
	public BattleAttr(double attack, double defend, double strategyAttack,
			double strategyDefend, double crit, double resist, double skillPower, 
			double hp, int commandAmount, double skillDefend) {
		super();
		this.attack = attack;
		this.defend = defend;
		this.strategyAttack = strategyAttack;
		this.strategyDefend = strategyDefend;
		this.crit = crit;
		this.resist = resist;
		this.skillPower = skillPower;
		this.hp = hp;
		this.commandAmount = commandAmount;
		this.skillDefend = skillDefend;
	}
	/**
	 * 相乘、增益
	 * @param battleAttr BattleAttr
	 * @return 血量的增益，供兵量扣减使用
	 */
	public int increase(double increase) {
		if (increase <= 0) {
			return 0;
		}
		int value = Double.valueOf(this.hp *increase).intValue();
		increase = increase+1;
		this.attack *= increase;
		this.defend *= increase;
		this.strategyAttack *= increase;
		this.strategyDefend *= increase;
		this.skillPower *= increase;
		this.hp += value;
		this.skillDefend *= increase;
		return value;
	}
	/**
	 * 相加
	 * @param battleAttr BattleAttr
	 */
	public void add(BattleAttr battleAttr) {
		if (battleAttr == null) {
			return;
		}
		this.attack += battleAttr.attack;
		this.defend += battleAttr.defend;
		this.strategyAttack += battleAttr.strategyAttack;
		this.strategyDefend += battleAttr.strategyDefend;
		this.crit += battleAttr.crit;
		this.resist += battleAttr.resist;
		this.skillPower += battleAttr.skillPower;
		this.hp += battleAttr.hp;
		this.commandAmount += battleAttr.commandAmount;
		this.skillDefend += battleAttr.skillDefend;
	}
	/**
	 * 重置清零
	 */
	public void reset() {
		this.attack = 0;
		this.defend = 0;
		this.strategyAttack = 0;
		this.strategyDefend = 0;
		this.crit = 0;
		this.resist = 0;
		this.skillPower = 0;
		this.hp  = 0;
		this.commandAmount = 0;
		this.skillDefend = 0;
	}
	/**
	 * 得到对应类型的值
	 * @param attrType 战斗属性类型 {@link BattleAttrType}
	 */
	public double getValue(int attrType){
		switch (attrType) {
		case BattleAttrType.ATTACK:
			return attack;
		case BattleAttrType.DEFEND:
			return defend;
		case BattleAttrType.STRATEGYATTACK:
			return strategyAttack;
		case BattleAttrType.STRATEGYDEFEND:
			return strategyDefend;
		case BattleAttrType.CRIT:
			return crit;
		case BattleAttrType.RESIST:
			return resist;
		case BattleAttrType.SKILLPOWER:
			return skillPower;
		case BattleAttrType.HP:
			return hp;
		case BattleAttrType.NONE:// 带兵数
			return commandAmount;
		case BattleAttrType.SKILLDEFEND:
			return skillDefend;
		default:
			return 0;
		}
	}
	/**
	 * 加某个战斗属性类型值
	 * @param attrType 战斗属性类型 {@link BattleAttrType}
	 * @param value 具体数值
	 */
	public void add(int attrType, double value) {
		switch (attrType) {
		case BattleAttrType.ATTACK:
			this.attack += value;
			break;
		case BattleAttrType.DEFEND:
			this.defend += value;
			break;
		case BattleAttrType.STRATEGYATTACK:
			this.strategyAttack += value;
			break;
		case BattleAttrType.STRATEGYDEFEND:
			this.strategyDefend += value;
			break;
		case BattleAttrType.CRIT:
			this.crit += value;
			break;
		case BattleAttrType.RESIST:
			this.resist += value;
			break;
		case BattleAttrType.SKILLPOWER:
			this.skillPower += value;
			break;
		case BattleAttrType.HP:
			this.hp += value;
			break;
		case BattleAttrType.NONE:// 带兵数
			this.commandAmount += value;
			break;
		case BattleAttrType.SKILLDEFEND:// 技能防御
			this.skillDefend += value;
			break;
		default:
			break;
		}
	}
	public BattleAttr clone(){
		try {
			return (BattleAttr) super.clone();
		} catch (CloneNotSupportedException ex) {
			return null;
		}
	}
	
}

