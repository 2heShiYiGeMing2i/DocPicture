/**
 * @file:BattleRule.java
 * @author:David
 **/
package com.xx.dev.modules.battle.core;

import java.util.HashMap;
import java.util.Map;

/**
 * @class:BattleRule
 * @description:战斗基本规则
 * @author:David
 * @version:v1.0
 * @date:2013-4-19
 **/
public interface BattleRule {
	/** 进攻方阵形 **/
	public final int[] OFFENSE_POS = {1,3,5,7,9,11};
	/** 防守方阵形 **/
	public final int[] DEFENSE_POS = {2,4,6,8,10,12};
	/** 十字方阵信息 **/
	public final Map<Integer, int[]> CROSS_MAP = new HashMap<Integer, int[]>();
	/** 一列方阵信息 **/
	public final Map<Integer, int[]> LINE_MAP = new HashMap<Integer, int[]>();
	/** 后排单体对位信息 **/
	public final Map<Integer, int[]> BACK_SINGLE_MAP = new HashMap<Integer, int[]>();
}

