package com.xx.dev.event;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.xx.common.event.AbstractReceiver;
import com.xx.dev.modules.deposit.service.DepositService;
import com.xx.dev.modules.monarchfeast.service.MonarchFeastService;

/**
 * 消费事件接收器
 * 
 * @author along
 */
@Component
public class ConsumeEventReceiver extends AbstractReceiver<ConsumeEvent> {
    
    @Autowired
    private DepositService depositService;
    
    @Autowired
    private MonarchFeastService monarchFeastService;
    
	@Override
	public String[] getEventNames() {
		return new String[] {ConsumeEvent.NAME};
	}

	@Override
	public void doEvent(ConsumeEvent event) {
		if (event == null) {
			return;
		}
        
        // 财富乐翻天
        depositService.onConsume(event);
        
        // 帝王盛宴
        monarchFeastService.onConsume(event);
	}

}
