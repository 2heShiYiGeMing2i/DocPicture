package com.xx.dev.modules.card.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.xx.common.db.model.BaseModel;

/**
 * 玩家月卡存储信息
 * @author jy
 *
 */
@Entity
@Table(name = "playerCard")
public class PlayerCard extends BaseModel<Long>{

	/**
	 * 
	 */
	private static final long serialVersionUID = 4392535973594803121L;

	@Id
	@Column(columnDefinition = "bigint(20) not null comment '玩家id'")
	private Long playerId;
	
	/**
	 * 是否激活月卡，0-未激活，1-已经激活
	 * 
	 * 不是必须的字段，不过可以简化逻辑判断，比如如果没有开通则不需要进行时间相关的比较判断
	 */
	@Column(columnDefinition = "int(11) NOT NULL COMMENT '是否激活月卡，0-未激活，1-已经激活'")
	private int isOpen = 0;
	
	/**
	 * 月卡结束时间，可累加
	 */
	@Column(columnDefinition = "datetime comment '月卡结束时间'")
	private Date endTime = new Date();
	
	/**
	 * 月卡特权领取时间
	 */
	@Column(columnDefinition = "datetime comment '月卡特权领取时间'")
	private Date getTime = new Date();
	
	/**
	 * 是否领取体力，0-未领取，1-已经领取
	 */
	@Column(columnDefinition = "int(11) NOT NULL COMMENT '是否领取体力，0-未领取，1-已经领取'")
	private int energyGetState = 0;
	
	/**
	 * 是否领取富甲天下，0-未领取，1-已经领取
	 */
	@Column(columnDefinition = "int(11) NOT NULL COMMENT '是否领取富甲天下，0-未领取，1-已经领取'")
	private int fjtxGetState = 0;
	
	/**
	 * 是否领取每日buffer，0-未领取，1-已经领取
	 */
	@Column(columnDefinition = "int(11) NOT NULL COMMENT '是否领取每日buffer，0-未领取，1-已经领取'")
	private int bufferGetState = 0;
	
	@Override
	public Long getId() {
		return playerId;
	}

	@Override
	public void setId(Long id) {
		this.playerId = id;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public Date getGetTime() {
		return getTime;
	}

	public void setGetTime(Date getTime) {
		this.getTime = getTime;
	}

	public int getEnergyGetState() {
		return energyGetState;
	}

	public void setEnergyGetState(int powerGetState) {
		this.energyGetState = powerGetState;
	}

	public int getFjtxGetState() {
		return fjtxGetState;
	}

	public void setFjtxGetState(int fjtxGetState) {
		this.fjtxGetState = fjtxGetState;
	}

	public int getBufferGetState() {
		return bufferGetState;
	}

	public void setBufferGetState(int bufferGetState) {
		this.bufferGetState = bufferGetState;
	}

	
	public int getIsOpen() {
		return isOpen;
	}

	public void setIsOpen(int isOpen) {
		this.isOpen = isOpen;
	}

	public static PlayerCard valueOf(long playerId) {
		PlayerCard playerCard = new PlayerCard();
		playerCard.playerId = playerId;
		return playerCard;
	}

	public boolean isOpen() {
		return isOpen == 1;
	}

	/**
	 * 清空所有状态为0
	 */
	public void reset() {
		isOpen = 0;
		energyGetState = 0;
		fjtxGetState = 0;
		bufferGetState = 0;
	}

	public boolean bufferGeted() {
		return bufferGetState == 1;
	}

	public void getBuffer(Date now) {
		getTime = now;
		bufferGetState = 1;
	}

	public void finishFJTX(Date now) {
		getTime = now;
		fjtxGetState = 1;
	}

	public boolean finishFJTX() {
		return fjtxGetState == 1;
	}

	public void getEnergy(Date now) {
		getTime = now;
		energyGetState = 1;
	}

	public boolean energyGeted() {
		return energyGetState == 1;
	}
}
