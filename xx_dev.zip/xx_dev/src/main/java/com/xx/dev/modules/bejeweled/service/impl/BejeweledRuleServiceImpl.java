package com.xx.dev.modules.bejeweled.service.impl;

import com.xx.common.basedb.BasedbAdapter;
import com.xx.common.basedb.BasedbService;
import com.xx.common.util.RandomUtil;
import com.xx.dev.constant.IndexName;
import com.xx.dev.modules.bejeweled.model.BejeweledContext;
import com.xx.dev.modules.bejeweled.model.Goal;
import com.xx.dev.modules.bejeweled.model.basedb.BejeweledBox;
import com.xx.dev.modules.bejeweled.model.basedb.BejeweledCfg;
import com.xx.dev.modules.bejeweled.model.basedb.BejeweledClearUp;
import com.xx.dev.modules.bejeweled.model.basedb.BejeweledGoal;
import com.xx.dev.modules.bejeweled.service.BejeweledRuleService;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Created by LiangZengle on 2014/6/21.
 */
@Component
public class BejeweledRuleServiceImpl extends BasedbAdapter implements BejeweledRuleService {
    public static final int ROWS = 6, COLUMNS = 6, KINDS = 6;

    private int totalGoalRate;
    private int totalAutoClearUpCountRate;

    @Autowired
    private BasedbService basedbService;

    @Override
    public int getAchieveGoalScore(Goal goal) {
        BejeweledGoal bejeweledGoal = basedbService.get(BejeweledGoal.class, goal.getCount());
        return bejeweledGoal == null ? 0 : bejeweledGoal.getScore();
    }

    @Override
    public int randomAutoClearUpCount() {
        List<BejeweledClearUp> bejeweledClearUps = basedbService.listAll(BejeweledClearUp.class);
        if (CollectionUtils.isEmpty(bejeweledClearUps)) {
            return 0;
        }
        if (bejeweledClearUps.size() == 1) {
            return bejeweledClearUps.get(0).getId();
        }

        int r = RandomUtil.nextInt(totalAutoClearUpCountRate);
        for (BejeweledClearUp bejeweledClearUp : bejeweledClearUps) {
            if (bejeweledClearUp.getRate() > r) {
                return bejeweledClearUp.getId();
            }
            r -= bejeweledClearUp.getRate();
        }
        return 0;
    }

    @Override
    public Goal randomGoal() {
        List<BejeweledGoal> bejeweledGoals = basedbService.listAll(BejeweledGoal.class);
        if (CollectionUtils.isEmpty(bejeweledGoals)) {
            return Goal.valueOf(0, 0);
        }
        if (bejeweledGoals.size() == 1) {
            BejeweledGoal bejeweledGoal = bejeweledGoals.get(0);
            return Goal.valueOf(RandomUtil.betweenValue(1, KINDS), bejeweledGoal.getId());

        }
        int r = RandomUtil.nextInt(totalGoalRate);
        for (BejeweledGoal bejeweledGoal : bejeweledGoals) {
            if (bejeweledGoal.getRate() > r) {
                return Goal.valueOf(RandomUtil.betweenValue(1, KINDS), bejeweledGoal.getId());
            }
            r -= bejeweledGoal.getRate();
        }
        return Goal.valueOf(0, 0);
    }

    @Override
    public BejeweledContext newBejeweledContext(long playerId) {
        return BejeweledContext.valueOf(ROWS, COLUMNS, KINDS);
    }

    @Override
    public BejeweledBox getBox(int boxLevel) {
        return basedbService.getByUnique(BejeweledBox.class, IndexName.BEJEWELED_BOX_LEVEL_INDEX, boxLevel);
    }

    @Override
    public int getScore(Integer count) {
        BejeweledClearUp bejeweledClearUp = basedbService.get(BejeweledClearUp.class, count);
        return bejeweledClearUp == null ? 0 : bejeweledClearUp.getScore();
    }

    @Override
    public BejeweledCfg getBejeweledCfg() {
        return basedbService.get(BejeweledCfg.class, BejeweledCfg.ID);
    }

    @Override
    public Class<?>[] listenedClass() {
        return new Class<?>[]{BejeweledGoal.class, BejeweledClearUp.class};
    }

    @Override
    public void initialize() {
        List<BejeweledGoal> bejeweledGoals = basedbService.listAll(BejeweledGoal.class);
        if (CollectionUtils.isNotEmpty(bejeweledGoals)) {
            int totalRate = 0;
            for (BejeweledGoal bejeweledGoal : bejeweledGoals) {
                totalRate += bejeweledGoal.getRate();
            }
            totalGoalRate = totalRate;
        }

        List<BejeweledClearUp> bejeweledClearUps = basedbService.listAll(BejeweledClearUp.class);
        if (CollectionUtils.isNotEmpty(bejeweledClearUps)) {
            int totalRate = 0;
            for (BejeweledClearUp bejeweledClearUp : bejeweledClearUps) {
                totalRate += bejeweledClearUp.getRate();
            }
            totalAutoClearUpCountRate = totalRate;
        }
    }
}
