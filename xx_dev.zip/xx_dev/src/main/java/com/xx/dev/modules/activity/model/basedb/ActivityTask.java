package com.xx.dev.modules.activity.model.basedb;

import com.xx.common.basedb.anno.Index;
import com.xx.common.basedb.anno.Resource;
import com.xx.dev.constant.IndexName;
import com.xx.dev.modules.task.model.basedb.BaseTask;


/**
 * 活动任务
 * 
 * @author bingshan
 */
@Resource
public class ActivityTask extends BaseTask {
	
	/**
	 * 活动id
	 */
	@Index(name = IndexName.ACTIVITY_TASK_ACTIVITY_ID_INDEX, order = 0)
	private int activityId;
	
	/**
	 * 是否日常任务, 0-否  1-是
	 */
	private int dailyTask = 0;
	
	/**
	 * 可做次数(日常任务是指每天可做次数)
	 */
	private int count = 1;
	
	/**
	 * 开放的真实vip等级
	 */
	private int openVip = 0;
	
	public boolean isDailyTask() {
		return this.dailyTask == 1;
	}

	public int getActivityId() {
		return activityId;
	}

	public void setActivityId(int activityId) {
		this.activityId = activityId;
	}

	public int getDailyTask() {
		return dailyTask;
	}

	public void setDailyTask(int dailyTask) {
		this.dailyTask = dailyTask;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public int getOpenVip() {
		return openVip;
	}

	public void setOpenVip(int openVip) {
		this.openVip = openVip;
	}
	
}
