package com.xx.dev.modules.arena.model;

/**
 * 玩家排名信息dto
 * 
 * @author bingshan
 */
public class PlayerRankDto {
	
	/**
	 * 排名
	 */
	private int rank = 0;
	
	/**
	 * 角色id
	 */
	private long playerId;
	
	/**
	 * 主公名称
	 */
	private String playerName;
	
	/**
	 * 等级
	 */
	private int level;
	
	/**
	 * 官职
	 */
	private int jobId;
	
	/**
	 * 头像id
	 */
	private int headId;
	
	/**
	 * 类型：0-玩家  1-npc
	 */
	private int type = 0;
	
	public static PlayerRankDto valueOf(int rank, long playerId) {
		return valueOf(rank, playerId, 0);
	}
	
	public static PlayerRankDto valueOf(int rank, long playerId, int type) {
		PlayerRankDto p = new PlayerRankDto();
		p.rank = rank;
		p.playerId = playerId;
		p.type = type;
		return p;
	}

	public int getRank() {
		return rank;
	}

	public void setRank(int rank) {
		this.rank = rank;
	}

	public long getPlayerId() {
		return playerId;
	}

	public void setPlayerId(long playerId) {
		this.playerId = playerId;
	}

	public String getPlayerName() {
		return playerName;
	}

	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

	public int getJobId() {
		return jobId;
	}

	public void setJobId(int jobId) {
		this.jobId = jobId;
	}

	public int getHeadId() {
		return headId;
	}

	public void setHeadId(int headId) {
		this.headId = headId;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}
	
}
