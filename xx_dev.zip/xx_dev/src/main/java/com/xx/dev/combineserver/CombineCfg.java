package com.xx.dev.combineserver;

import java.util.Properties;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.support.PropertiesLoaderUtils;

/**
 * 合服配置
 * 
 * @author Along
 *
 */
public class CombineCfg {

	private static Logger logger = LoggerFactory.getLogger(CombineCfg.class);

	/**
	 * 配置文件名
	 */
	private static final String CONFIG_FILE_NAME = "combineCfg.properties";
	
	/**
	 * MySql的安装路径
	 */
	private static final String MYSQL_PATH = "mysql.path";
	
	/**
	 * 临时文件夹
	 */
	private static final String PROCESS_CLEAN_TEMP_FOLDER = "process.clean.temp.folder";
	
	/**
	 * 是否清除临时文件
	 */
	private static final String PROCESS_CLEAN_TEMP_FILE = "process.clean.temp.files";
	
	/**
	 * 重试次数
	 */
	private static final String PROCESS_RETRY_TIMES = "process.retry.times";
	
	/**
	 * 不用导数据的表
	 */
	private static final String IGNORE_TABLES = "ignore.tables";
	
	/**
	 * 只导第一个库的表
	 */
	private static final String IMPORT_ONE_TABLES = "import.one.tables";

	private static Properties properties = null;
	
	public static boolean ready = false;
	
	public static String mysqlPath;
	
	public static String folder;
	
	public static boolean cleanTempFile = true;
	
	public static int retryTimes = 1;
	
	public static String[] ignoreTables;
	
	public static String[] importOneTables;
	
	static {
		init();
	}
	
	/**
	 * 刷新配置
	 */
	public static void init(){
		try {
			properties = PropertiesLoaderUtils.loadProperties(new ClassPathResource(CONFIG_FILE_NAME));
			mysqlPath = String.valueOf(getProperty(MYSQL_PATH));
			folder = String.valueOf(getProperty(PROCESS_CLEAN_TEMP_FOLDER));
			cleanTempFile = Boolean.parseBoolean(String.valueOf(getProperty(PROCESS_CLEAN_TEMP_FILE)));
			retryTimes = Integer.parseInt(String.valueOf(getProperty(PROCESS_RETRY_TIMES)));
			String ignoreTableString = String.valueOf(getProperty(IGNORE_TABLES));
			if (StringUtils.isNotBlank(ignoreTableString)) {
				ignoreTables = ignoreTableString.split(",");
			}
			String importOneTableString = String.valueOf(getProperty(IMPORT_ONE_TABLES));
			if (StringUtils.isNotBlank(importOneTableString)) {
				importOneTables = importOneTableString.split(",");
			}
			ready = true;
		} catch (Exception e) {
			logger.error("加载合服配置文件出错!", e);
		}
	}

	/**
	 * 获取属性
	 * @param key
	 * @return
	 */
	public static Object getProperty(String key){
		if(properties != null){
			return (Object) properties.get(key);
		}
		return null;
	}
	
}
