package com.xx.dev.modules.armygroup.handler;

import com.xx.dev.constant.CommonConstant;

/**
 * 军团模块状态码
 * 
 * @author Along
 *
 */
public interface ArmyGroupResult extends CommonConstant {

	/**
	 * 军团名称已经存在
	 */
	int ARMY_GROUP_NAME_HAD_EXISTS = -10001;
	
	/**
	 * 已经加入军团
	 */
	int HAD_JOIN_ARMY_GROUP = -10002;
	
	/**
	 * 军团不存在
	 */
	int ARMY_GROUP_NOT_EXISTS = -10003;
	
	/**
	 * 申请数量上限
	 */
	int APPLY_AMOUNT_LIMIT = -10004;
	
	/**
	 * 已经申请过该军团
	 */
	int HAD_APPLY = -10005;
	
	/**
	 * 没有操作权限
	 */
	int HAD_NOT_AUTH = -10006;
	
	/**
	 * 申请不存在
	 */
	int APPLY_NO_EXISTS = -10007;
	
	/**
	 * 军团成员上限
	 */
	int ARMY_GROUP_MEMBER_LIMIT = -10008;
	
	/**
	 * 还没有加入军团
	 */
	int HAD_NOT_JOIN_ARMY_GROUP = -10009;
	
	/**
	 * 团长还不能退出军团（军团人数超过1人）
	 */
	int CAN_NOT_QUIT_ARMY_GROUP = -10010;
	
	/**
	 * 当天已经领取过粮草福利
	 */
	int TODAY_HAD_RECEIVED_FOODS = -10011;
	
	/**
	 * 当天已经领取过武将经验福利
	 */
	int TODAY_HAD_RECEIVED_HERO_SOUL = -10012;
	
	/**
	 * 军团商城商品没开放
	 */
	int ARMY_GROUP_GOODS_NOT_OPEN = -10013;
	
	/**
	 * 军团商城商品每日购买数量限制
	 */
	int ARMY_GROUP_GOODS_BUY_AMOUNT_LIMIT = -10014;
	
	/**
	 * 贡献分不够
	 */
	int CONTRIBUTE_NO_ENOUGH = -10015;
	
	/**
	 * 未满足弹劾条件
	 */
	int CAN_NOT_DELATE = -10016;
	
	/**
	 * 发送招贤榜的次数已经用完
	 */
	int SEND_ADVERTISE_TIMES_LIMIT = -10017;
	
	/**
	 * 退出军团冷却中
	 */
	int QUIT_COOLING = -10018;
	
	/**
	 * 没有在冷却中（不用清除冷却时间）
	 */
	int NO_COOLING = -10019;
	
	/**
	 * 不能超过军团等级
	 */
	int ARMY_GROUP_LEVEL_NO_ENOUGH = -10020;
	
	/**
	 * 军团活动中，不能退出，踢人，解散
	 */
	int IN_PLUNDER_FOOD = -10021;
	
	/**
	 * 等级不够27级不能加入军团
	 */
	int JOIN_MIN_LEVEL_LIMIT = -10022;
	
	/**
	 * 等级不够27级不能被邀请加入军团
	 */
	int INVITE_MIN_LEVEL_LIMIT = -10023;
	
	/**
	 * 军团职位人数上限
	 */
	int ARMY_GROUP_POSITION_LIMIT = -10024;
	
	/**
	 * 军团科技等级上限
	 */
	int TECH_LEVEL_LIMIT = -10025;
	
	/**
	 * 军团活动中，不能退出，踢人，解散
	 */
	int IN_ARMY_GROUP_TRAIN = -10026;
}
