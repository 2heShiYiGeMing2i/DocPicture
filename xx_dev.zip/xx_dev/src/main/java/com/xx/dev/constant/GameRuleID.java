/**
 * @file:GameRuleID.java
 * @author:David
 **/
package com.xx.dev.constant;

/**
 * @class:GameRuleID
 * @description:固定规则表相关ID（延续勇者之塔，保持策划习惯）
 * @author:David
 * @version:v1.0
 * @date:2013-4-23
 **/
public interface GameRuleID {

	// ------------------1主公---------------------------
	/**
	 * 主公自动添加1点体力的时间（10分钟）
	 */
	int PLAYER_AUTO_ADD_ENENGY = 103;

	/**
	 * 每次购买增加的体力值
	 */
	int PLAYER_BUY_ENERGY_TIMES = 106;

	/**
	 * 可以获得体力Buff的最小等级
	 */
	int PLAYER_MIN_ADD_ENERGY_BUFF_LEVEL = 107;

	/**
	 * 主公天赋等级属性加成开放等级
	 */
	int PLAYER_TALENT_LEVEL_ATTR_OPEN_LEVEL = 109;
	// -------------------2聊天---------------------------
	/**
	 * 小喇叭道具id
	 */
	int CHITCHAT_TRUMPET_ITEM_ID = 201;
	
	/**
	 * 最小聊天等级
	 */
	int CHITCHAT_MIN_CHAT_LEVEL = 108;

	// --------------------3邮件--------------------------
	/**
	 * 发送私人邮件
	 */
	int MAIL_SEND_PLAYER_MAIL = 301;

	// --------------------4武将--------------------------
	/**
	 * 最小减兵等级
	 */
	int HERO_MIN_REDUCE_SOLDIER_LEVEL = 402;

	/**
	 * 自定义武将的阵营
	 */
	int CUSTOM_HERO_CAMP = 405;

	/**
	 * 武将改名卡道具id
	 */
	int HERO_RENAME_CARD_ITEM_ID = 406;

	/**
	 * 可保存阵型的最小任务id
	 */
	int HERO_MIN_SAVE_LINEUP_TASK_ID = 409;

	/**
	 * 可保存阵型的最小主公等级要求
	 */
	int HERO_MIN_SAVE_LINEUP_LEVEL = 410;

	/**
	 * 最小减兵据点id
	 */
	int HERO_MIN_REDUCE_SOLDIER_MISSION_ID = 411;

	/**
	 * 主公等级到x级后武将经验池满也允许玩家继续打单人副本
	 */
	int HERO_SOUL_LIMIT_LEVEL = 414;

	/**
	 * 武将下野开放等级
	 */
	int HERO_DISBAND_OPEN_LEVEL = 415;
	
	/**
	 * 升级宝石共鸣等级的道具id
	 */
	int HERO_UPGRADE_RESONATE_LEVEL_ITEM_ID = 417;
	
	/**
	 * VIP提升的武将经验上限开放主公等级
	 */
	int HERO_VIP_SOUL_LIMIT_OPEN_LEVEL = 418;
	
	/**
	 * 360龙将类型id（不能修改名字）
	 */
	int HERO_360_CUSTOM_HERO_TYPE = 420;
	
	/**
	 * 武将上阵限制规则生效等级
	 */
	int HERO_EMBATTLE_LIMIT_LEVEL = 421;
	
	/**
	 * 武将传授开放等级
	 */
	int HERO_TECH_OPEN_LEVEL = 422;
	
	/**
	 * 提升神将战魄等级所需的武将最小星级
	 */
	int SOU_SKILL_UPGRADE_HERO_STAR = 423;

	// ------------------7冷却队列---------------
	/**
	 * 队列冷却符道具id
	 */
	int COOL_QUEUE_CLEAR_COOL_TIME_ITEM_ID = 701;

	// ----------------- 8 单人副本 -------------
	/** 801-挂机时每个据点消耗的时间 单位：毫秒 */
	int SINGLE_HOOK_TIME_PER_AREA = 801;

	/** 805-单人副本报存最近击破战报条数 **/
	int CHAPTER_REPORT_COUNT = 805;

	/** 806 100 单人副本排行榜人数 **/
	int CHAPTER_RANK_LIMIT = 806;
	
	// -------------------9道具-------------------
	/**
	 * 每日最多可以使用经验丹的数量
	 */
	int ITEM_USE_EXP_PILL_AMOUNT = 909;
	
	// ----------------- 10 战斗系统怒气上限 -------------
	/** 1001-战斗系统怒气上限 */
	int BATTLE_MAX_DANDER = 1001;
	/** 1002-战斗系统最大回合数 */
	int BATTLE_MAX_ROUND = 1002;

	// -----------------11背包---------------------------
	/**
	 * 自动开启的背包格子数量
	 */
	int PACK_AUTO_OPEN_CELL_AMOUNT = 1101;

	// -----------------12技能---------------------------
	/**
	 * 每天技能刷新的免费次数
	 */
	int SKILL_RELUSH_TIMES = 1201;
	
	/**
	 * 龙将战魄技能升级消耗的道具id
	 */
	int CUSTOM_HERO_SOUL_SKILL_UPGRADE_ITEMID = 1203;
	
	// -----------------13远征异族-----------------------
	/**
	 * 远征异族每天的次数上限
	 */
	int INVADE_TIME = 1301;

	/**
	 * 远征异族当天的购买上限
	 */
	int INVADE_BUY_TIME = 1302;
	/**
	 * 排行总人数
	 */
	int INVADE_BATTLE_RANK = 1303;

	// -----------------14税收---------------------------
	/**
	 * 手动收取粮草的最小时间（分钟）
	 */
	int REVENUE_RECEIVE_FOODS_TIME = 1401;

	/**
	 * 手动收取银元的最小时间（分钟）
	 */
	int REVENUE_RECEIVE_SILVER_TIME = 1402;

	/**
	 * 自动收取粮草的最小时间（秒）
	 */
	int REVENUE_AUTO_RECEIVE_FOODS_TIME = 1403;

	/**
	 * 自动收取银元的最小时间（秒）
	 */
	int REVENUE_AUTO_RECEIVE_SILVER_TIME = 1404;

	/**
	 * 初始化粮草收取次数
	 */
	int REVENUE_INIT_FOODS_TIMES = 1405;

	/**
	 * 初始化银元收取次数
	 */
	int REVENUE_INIT_SILVER_TIMES = 1406;

	/**
	 * 粮草征税冷却时间（秒）
	 */
	int REVENUE_FOODS_COOLTIME = 1407;

	/**
	 * 银元征税冷却时间（秒）
	 */
	int REVENUE_SILVER_COOLTIME = 1408;

	/**
	 * 粮草征税冷却队列长度（秒）
	 */
	int REVENUE_FOODS_COOLQUEUE = 1409;

	/**
	 * 银元征税冷却队列长度（秒）
	 */
	int REVENUE_SILVER_COOLQUEUE = 1410;

	/**
	 * 普通征收银两的次数
	 */
	int REVENUE_SILVER_TIMES = 1411;

	/**
	 * 普通征收粮食的次数
	 */
	int REVENUE_FOODS_TIMES = 1412;

	/**
	 * 强征银元令道具id
	 */
	int REVENUE_PRESS_SILVER_ITEM_ID = 1413;

	/**
	 * 强征粮食令道具id
	 */
	int REVENUE_PRESS_FOODS_ITEM_ID = 1414;

	// -----------------15 酒馆---------------------------

	// ----------------- 16 精英副本 -------------

	/** 1601-精英副本 挂机时每个据点消耗的时间 单位：毫秒 */
	int CREAM_HOOK_TIME_PER_AREA = 1601;

	// ------------------17武将装备------------------------
	/**
	 * 每天免费洗炼次数
	 */
	int HERO_EQUIP_FREE_BAPTIZE_TIMES = 1701;

	/**
	 * 精钢石道具id
	 */
	int HERO_EQUIP_DIAMOND_ITEM_ID = 1702;

	/**
	 * 洗炼石道具id
	 */
	int HERO_EQUIP_BAPTIZE_ITEM_ID = 1706;

	/**
	 * 宝石共鸣属性开放等级
	 */
	int HERO_EQUIP_JEWEL_RESONATE_ATTR_OPEN_LEVEL = 1707;

	/**
	 * 宝石共鸣属性开放单人副本据点id
	 */
	int HERO_EQUIP_JEWEL_RESONATE_ATTR_OPEN_MISSION_ID = 1708;
	
	/**
	 * 宝石连锁属性开放等级
	 */
	int HERO_EQUIP_JEWEL_LEVEL_ATTR_OPEN_LEVEL = 1709;

	/**
	 * 宝石连锁属性开放单人副本据点id
	 */
	int HERO_EQUIP_JEWEL_LEVEL_ATTR_OPEN_MISSION_ID = 1710;
	
	/**
	 * 披风穿戴VIP等级限制
	 */
	int HERO_EQUIP_CAPE_VIP_LEVEL_LIMIT = 1711;
	
	/**
	 * 披风穿戴主公等级限制
	 */
	int HERO_EQUIP_CAPE_LEVEL_LIMIT = 1712;
	
	/**
	 * 传承宝石共鸣的比例
	 */
	int HERO_EQUIP_INHERIT_JEWEL_RESONATE_RATE = 1713;
	
	/**
	 * 宝石升级最小宝石等级和要求
	 */
	int HERO_EQUIP_JEWEL_UPGRADE_LEVEL_LIMIT = 1714;	
	
	// -----------------18 好友---------------------------
	/** 1801-好友和陌生人 总和大小 */
	int RELATION_FRIEND_AND_STRANGER_SIZE = 1801;
	/** 1802-助阵好友列表总数 **/
	int CHEER_LIMIT = 1802;
	/** 1803-助阵好友 好友数量下限 **/
	int CHEER_FRIEND_LOW = 1803;
	/** 1804-助阵好友 好友数量上限 **/
	int CHEER_FRIEND_HIGH = 1804;
	/** 1805-助阵好友筛选等级段范围 **/
	int CHEER_FRIEND_LEVEL = 1805;
	/** 1806-邀请助战好友是玩家的好友 获得功勋 **/
	int CHEER_FRIEND_EXPLOIT = 1806;
	/** 1807-邀请助战好友豪杰 获得功勋 **/
	int CHEER_EXPLOIT = 1807;
	/** 1808-邀请好友CD回合 **/
	int CHEER_CD = 1808;
	/** 1813-送礼祝福时，送给对方的道具ID */
	int RELATION_BLESS_ITEM = 1813;
	/** 1814-好友等级祝福礼包 最低等级 */
	int RELATION_LEVEL_LIMIT = 1814;
	/** 1815-好友战斗力礼包 最低等级 */
	int RELATION_ABILITY_LEVEL_LIMIT = 1815;

	/** 1817-玩家达到多少等级 弹出一键好友 */
	int RELATION_FRIEND_LEVEL = 1817;
	/** 1818-弹出一键好友数量 */
	int RELATION_FRIEND_LEVEL_NUM = 1818;
	// -----------------21 征战天下---------------------------
	/** 2101-征战天下每天的次数 */
	int JOURNEY_TIME = 2101;
	/** 2102-征战天下增加单次道具Id */
	int JOURNEY_TIME_ITEM = 2102;
	/** 2103-征战天下道具每日购买次数 上限 */
	int JOURNEY_BUY_TIME = 2103;
	/** 2104-征战天下每天免费的复活次数 */
	int JOURNEY_REVIVE_TIME = 2104;
	/** 2105-征战天下 战役排行总人数 */
	int JOURNEY_BATTLE_RANK = 2105;
	/** 2106-征战天下 挂机时每个据点消耗的时间 单位：毫秒 */
	int JOURNEY_HOOK_TIME_PER_AREA = 2106;

	// ------------------23 官府事件----------------
	/**
	 * 每天可以处理的官府事件数量
	 */
	int WISH_EVENT_MAX_TIMES = 2301;

	/**
	 * 发生官府事件的时间间隔（分钟）
	 */
	int WISH_EVENT_REFRESH_TIME = 2303;

	/**
	 * 未处理的官府事件的最大累积数量
	 */
	int WISH_EVENT_MAX_EVENT = 2304;

	/**
	 * 每天可免费刷新官府事件的次数
	 */
	int WISH_EVENT_FREE_REFRESH_AMOUNT = 2305;

	/**
	 * 官府事件活动期间每天额外增加的可以处理的官府事件数量
	 */
	int WISH_EVENT_EXT_TIMES = 2306;

	/**
	 * 官府事件刷新符道具id
	 */
	int WISH_EVENT_REFRESH_ITEM_ID = 2307;

	/**
	 * 官府事件5星符道具id
	 */
	int WISH_EVENT_FIVE_STAR_ITEM_ID = 2308;
	// -----------------24 大决战---------------------------
	/** 2401- 大决战每天的收益次数 */
	// int ARMAGEDDON_TIME = 2401;
	/** 2402- 大决战每次开始后的CD时间(ms) */
	int ARMAGEDDON_CD_TIME = 2402;
	/** 2403- 大决战 最低等级要求 **/
	int ARMAGEDDON_LV_LIMIT = 2403;
	/** 2404-助阵好友列表总数 **/
	int ARMAGEDDONCHEER_LIMIT = 2404;
	/** 2405-助阵好友 好友数量下限 **/
	int ARMAGEDDONCHEER_FRIEND_LOW = 2405;
	/** 2406-助阵好友 好友数量上限 **/
	int ARMAGEDDONCHEER_FRIEND_HIGH = 2406;
	/** 2407-邀请好友CD回合 **/
	int ARMAGEDDONCHEER_CD = 2407;
	/** 2408-刷新邀请助战 消费 元宝数 **/
	/* int ARMAGEDDONCHEER_COST = 2408; */
	/** 2409-邀请助战好友是玩家的好友 获得功勋 **/
	int FRIEND_EXPLOIT = 2409;
	/** 2410-邀请助战好友豪杰 获得功勋 **/
	int EXPLOIT = 2410;

	// -----------------25黑市---------------------------
	int BLACK_MARKET_REFRESH_ITEM_ID = 2501;

	// -----------------26 命签---------------------------
	/**
	 * 命格的大小（求签以后存放没拾取的命签）
	 */
	int DIVINATION_GRID_AMOUNT = 2601;

	/**
	 * 一键求签的时候大于这个品质的命签才留下
	 */
	int DIVINATION_TAKE_MIN_QUALITY = 2602;

	/**
	 * 一键卖出的时候，小于这个品质的命签都卖掉
	 */
	int DIVINATION_SAIL_MAX_QUALITY = 2603;

	/**
	 * 一键拾取的时候，小于这个品质的命签都被合并
	 */
	int DIVINATION_PICKUP_MIN_QUALITY = 2604;

	/**
	 * 一键合并的时候，大于这个等级的命签不合并
	 */
	int DIVINATION_COMBINE_MAX_LEVEL = 2605;

	/**
	 * 战魂丹道具id
	 */
	int DIVINATION_DRILL_EXP_PILL_ITEM_ID = 2606;
	
	/**
	 * 命签锁定求签概率以后的消耗等级
	 */
	int DIVINATION_LOCK_TAKE_TYPE = 2607;
	
	/**
	 * 锁定求签道具（如意玉）
	 */
	int DIVINATION_LOCK_TAKE_STONE = 2608;
	
	/**
	 * 命签升级需要的上阵武将佩戴的橙色命签数量
	 */
	int DIVINATION_UPGRADE_MIN_DIVINATION_AMOUNT = 2609;
	
	/**
	 * 主公命签开放等级
	 */
	int DIVINATION_LEVEL_ATTR_OPEN_LEVEL = 2610;

	// -----------------27 攻城掠地---------------------------
	/**
	 * 攻城掠地 开放等级
	 */
	int PLUNDER_OPEN_LEVEL = 2701;
	/**
	 * 攻城掠地 等级段范围
	 */
	int PLUNDER_LEVEL_RANK = 2702;
	/**
	 * 攻城掠地 掠夺胜利 奖励积分
	 */
	int PLUNDER_WIN = 2703;
	/**
	 * 攻城掠地 掠夺失败 奖励积分
	 */
	int PLUNDER_LOSE = 2704;
	/**
	 * 攻城掠地每次掠夺后的CD时间(ms)
	 */
	int PLUNDER_CD_TIME = 2705;
	/**
	 * 攻城掠地 每天的收益次数
	 */
	int PLUNDER_TIME = 2706;
	/**
	 * 攻城掠地 每天宝箱领取次数
	 */
	int BOX_TIME = 2707;
	/**
	 * 攻城掠地 普通保护令 道具ID
	 */
	int PROTECT_ITEM = 2708;
	/**
	 * 攻城掠地 普通保护令 保护时间(ms)
	 */
	int PROTECT_TIME = 2709;
	/**
	 * 攻城掠地 高级保护令 道具ID
	 */
	int TOP_PROTECT_ITEM = 2710;
	/**
	 * 攻城掠地 高级保护令 保护时间(ms)
	 */
	int TOP_PROTECT_TIME = 2711;
	/**
	 * 攻城掠地 被掠夺多少次 进入保护时间
	 */
	int PROTECT_PLUNDER_TIME = 2712;
	/**
	 * 攻城掠地 被掠夺多少次后 保护时间(ms)
	 */
	int PLUNDER_PROTECT_TIME = 2713;
	/**
	 * 攻城掠地 普通保护令 使用CD时间(ms)
	 */
	int PROTECT_CD_TIME = 2714;
	/**
	 * 攻城掠地 高级保护令 使用CD时间(ms)
	 */
	int TOP_PROTECT_CD_TIME = 2715;
	/**
	 * 攻城掠地 鼓舞次数上限
	 */
	int INSPIRE_TIME_LIMIT = 2716;
	/**
	 * 攻城掠地 鼓舞有效时间
	 */
	int INSPIRE_CD_TIME = 2717;
	/**
	 * 攻城掠地 每次鼓舞加成 小数
	 */
	int INSPIRE_INCREASE = 2718;
	/**
	 * 攻城掠地 银两鼓舞成功几率
	 */
	int INSPIRE_SILVER_SUCESS = 2719;
	/**
	 * 攻城掠地追杀仇人持续时间（ms)
	 */
	int LOCK_ENEMY = 2720;
	/**
	 * 攻城掠地 库存上限的比率
	 */
	int SNATCHRATE = 2721;
	/**
	 * 攻城掠地 超过库存部分的比率
	 */
	int EXTSNATCHRATE = 2722;
	/**
	 * 攻城掠地 税收的比率
	 */
	int REVENUESNATCHRATE = 2723;
	/**
	 * 攻城掠地CD累积最大值
	 */
	int PLUNDER_MAXTIME = 2724;
	// -----------------28 竞技场---------------------------

	/**
	 * 竞技场挑战胜利声望
	 */
	int ARENA_CHALLENGE_WIN_FAME = 2801;

	/**
	 * 竞技场挑战失败声望
	 */
	int ARENA_CHALLENGE_LOSE_FAME = 2802;

	/**
	 * 竞技场固定挑战次数
	 */
	int ARENA_CHALLENGE_COUNT = 2803;

	/**
	 * 竞技场冷却CD(ms)
	 */
	int ARENA_CHALLENGE_CD = 2804;

	// /**
	// * 竞技场攻打npc任务id
	// */
	// int ARENA_NPC_TASK_ID = 2805;

	/**
	 * 竞技场结算奖励活动倍数
	 */
	int ARENA_REWARD_ACTIVITY_MULTIPLE = 2806;

	/**
	 * 竞技场CD累积最大值
	 */
	int ARENA_MAX_CD = 2807;

	// -----------------29军团-----------------------------
	/**
	 * 创建军团最低等级要求
	 */
	int ARMY_GROUP_CREATE_LEVEL_LIMIT = 2901;

	/**
	 * 创建军团消耗的银元数量
	 */
	int ARMY_GROUP_CREATE_COST_SILVER = 2902;

	/**
	 * 最大申请加入军团的次数
	 */
	int ARMY_GROUP_MAX_APPLY_AMOUNT = 2903;

	/**
	 * 捐献日志的数量
	 */
	int ARMY_GROUP_MAX_CONTRIBUTE_LOG_AMOUNT = 2905;

	/**
	 * 团长长期未上线被弹劾的时间（3天）
	 */
	int ARMY_GROUP_OFF_LINE_DAYS = 2906;

	/**
	 * 每天发送招贤榜的最大次数
	 */
	int ARMY_GROUP_MAX_SEND_ADVERTISE_TIMES = 2907;

	/**
	 * 虎符道具id
	 */
	int ARMY_GROUP_HU_FU_ITEM_ID = 2910;

	/**
	 * 退出军团后重新加入军团的冷却时间（小时）
	 */
	int ARMY_GROUP_QUIT_JOIN_COOL_TIME = 2911;

	/**
	 * 最小加入军团的等级
	 */
	int ARMY_GROUP_JOIN_MIN_LEVEL = 2913;
	
	/**
	 * 购买虎符消耗的银元
	 */
	int ARMY_GROUP_BUY_HUFU_COST = 2914;

	// -----------------30 群雄争霸-----------------------------

	/**
	 * 群雄争霸玩家最小等级限制
	 */
	int CHAMPION_PLAYER_MIN_LEVEL = 3001;

	/**
	 * 群雄争霸最多支持人数
	 */
	int CHAMPION_SUPPORT_MAX_COUNT = 3002;
	
	/**
	 * （外围赛）群雄争霸一次播放战报条数
	 */
	int CHAMPION_STAGE1_REPORTS_EVERY_TIME = 3003;
	
	/**
	 * （外围赛）群雄争霸赛播放时间间隔(ms)
	 */
	int CHAMPION_STAGE1_REPORT_TIMES_EVERY_TIME = 3004;

	/**
	 * 群雄争霸每次播放战报条数（资格赛、决赛）
	 */
	int CHAMPION_REPORT_COUNT_EVERY_TIME = 3006;

	/**
	 * 群雄争霸赛战报播放时间间隔(ms)（资格赛、决赛）
	 */
	int CHAMPION_REPORT_TIMES_EVERY_TIME = 3007;

	// -----------------36 礼包系统-----------------------------
	/**
	 * 连续登录礼包开放等级
	 */
	int CONTIN_LOGIN_LEVEL = 3601;
	/**
	 * 首次充值累计达到多少 元宝 领取首充礼包
	 */
	int FIRST_CHARGE = 3602;
	// -----------------37 日行一善-----------------------------
	/**
	 * 日行一善等级限制
	 */
	int GOODNESS_LEVEL = 3701;

	// -----------------38 VIP系统-----------------------------
	/**
	 * VIP每点成长值对应 消费金币数量
	 */
	int VIP_GOLD_VALUE = 3801;
	/**
	 * 一个月VIP 对应的VIP等级
	 */
	int VIP_ONE_LEVEL = 3802;
	/**
	 * 三个月 对应的VIP等级
	 */
	int VIP_TWO_LEVEL = 3803;
	/**
	 * 半年 对应的VIP等级
	 */
	int VIP_THREE_LEVEL = 3804;
	/**
	 * 临时VIP有效 主公等级
	 */
	int TMP_VIP_LEVEL = 3805;

	/**
	 * 赠送VIP卡获得的亲密度（双方都可获得）
	 */
	int VIP_FRIEND = 3810;
	// -----------------40猛将录系统------------------------
	/**
	 * 举荐书道具id
	 */
	int HERO_COLLECT_RECOMMEND_BOOK_ITEM_ID = 4001;

	// -----------------47成长基金---------------------
	/**
	 * 最大可购买等级
	 */
	int FUND_MAX_BUY_LEVEL = 4701;

	/**
	 * 每日最大可赠送次数
	 */
	int FUND_MAX_SEND_TIMES = 4702;

	/**
	 * 赠送获得的道具id
	 */
	int FUND_SEND_REWARD_ITEM_ID = 4703;
	
	/**
	 * 获赠VIP等级限制（大于这个等级不能获赠）
	 */
	int FUND_RECEIVED_MAX_VIP_LEVEL = 4704;
	
	/**
	 * 获赠VIP等级限制（小于这个等级不能获赠）
	 */
	int FUND_RECEIVED_MIN_VIP_LEVEL = 4705;

	//------------------新招贤馆（酒馆）---------------------
	
	/**缺省国家（没有选择国家）的神级招募掉落Id*/
	int NEW_PUB_DEFAULT_CAMP_SUPER_DROPS=4803;
	
	// -----------------50奴隶系统---------------------
	/**
	 * 奴隶的期限48小时
	 */
	int SLAVE_TIME = 5001;
	/**
	 * 每天工作时间24小时
	 */
	int SLAVE_WORK_TIME = 5002;
	/**
	 * 拥有奴隶上限3
	 */
	int SLAVE_LIMIT = 5003;
	/**
	 * 每天抓捕次数10
	 */
	int DAY_GRAB_TIME = 5004;
	/**
	 * 每天解救次数5
	 */
	int DAY_SAVE_TIME = 5005;
	/**
	 * 每天求救次数5
	 */
	int DAY_BE_SAVE_TIME = 5006;
	/**
	 * 安抚冷却时间20分钟
	 */
	int APPEASEDATE = 5007;
	/**
	 * 折磨冷却时间20分钟
	 */
	int AFFLICTDATE = 5008;
	/**
	 * 讨好冷却时间20分钟
	 */
	int PLEASEDATE = 5009;
	/**
	 * 诅咒冷却时间20分钟
	 */
	int CURSEDATE = 5010;
	/**
	 * 系统释放后保护时间15分钟
	 */
	int AUTO_PROTECT_TIME = 5011;
	/**
	 * 手动释放后保护时间15分钟
	 */
	int HAND_PROTECT_TIME = 5012;
	/**
	 * 赎身后保护时间30分钟
	 */
	int BUY_PROTECT_TIME = 5013;
	/**
	 * 被解救后保护时间15分钟
	 */
	int SAVE_PROTECT_TIME = 5014;
	/**
	 * 抓捕时，奴隶不能低于你10级
	 */
	int SLAVE_LEVEL_LIMIT = 5015;
	/**
	 * 解救时，对方主人不能低于你10级
	 */
	int BE_SAVE_LEVEL_LIMIT = 5016;
	/**
	 * 手下败将显示最新的个数
	 */
	int SLAVE_LOSER_LIMIT = 5017;
	/**
	 * 夺仆之敌显示最新的个数
	 */
	int SLAVE_ARMY_LIMIT = 5018;
	/**
	 * 日志显示最新的个数
	 */
	int SLAVE_LOG = 5019;
	/**
	 * 主人互动次数
	 */
	int DAY_TOUCH_TIME = 5020;
	/**
	 * 奴隶互动次数
	 */
	int DAY_BE_TOUCH_TIME = 5021;

	// -----------------51神兵阁-----------------------
	/**
	 * 自动出售的装备品质（7星）
	 */
	int EQUIP_RAFFLE_AUTO_SELL_EQUIP_GRADE = 5101;	
	// -----------------52抢粮活动-----------------------	
	/**
	 * 死亡复活时间
	 */
	int FEAST_REVIVE_CD_TIME = 5202;
	
	/**
	 * 战斗CD时间
	 */
	int FIGHT_CD_TIME_LIMIT = 5203;
	/**
	 * 活动准备时间
	 */
	int PLUNDER_PREPARE_TIME = 5204;
	/**
	 * 军团劫饷每次购买可获得的积分
	 */
	int PLUNDER_POINT = 5205;
	/**
	 * 军团劫饷结束回调接口
	 */
	int PLUNDER_CHECK_NUM = 5206;
	// -----------------54跑环玩法-----------------------
	/**
	 * 每隔X分钟赠送一个骰子
	 */
	int LOOP_ADD_DICE_MINUTE = 5401;
	/**
	 *每隔X小时赠送14个骰子
	 */
	int LOOP_ADD_DICE_HOUR = 5402;
	
	/**跑环玩法每天最多10个宝箱*/
	int LOOP_REWARD_MAX = 5403;
	
	/**跑环玩法触发BOSS的掷骰子总次数*/
	int LOOP_DICE_SUM = 5404;

	/** 生成boss间隔的时间2小时 */
	int LOOP_CREATE_BOSS_INTERVAL_TIME =5405;
	
	/**复活需要扣除的骰子数*/
    int LOOP_REVIVE_DICE_NUM	=5406;
    
   /** 跑环玩法挑战boss冷却时间(ms)	 */
    int LOOP_FIGHT_CD_TIME = 5407;
    
   /** 跑环玩法挑战boss死亡复活时间(ms)*/
    int LOOP_DEAD_CD_TIME = 5408;
    
    /**每天创建Boss最大次数*/
    int LOOP_CREATE_BOSS_MAX= 5409;
    
    /** 触发boss的几率*/
    int LOOP_CREATE_BOSS_CHANCE=5410;
    
    /**立即攻击Boss扣除骰子数*/
    int LOOP_IMMEDIATELY_ATTACK_BOSS_NUM=5411;
    
    /**幸运骰子隐藏的上限数量999*/
    int LOOP_LUCKY_DICE_LIMIT=5412;
    
    /**每天领取幸运骰子的个数*/    
    int  LOOP_EVERY_DAY_LUCKY_DICE_NUM=5413;
   
   /**第一次进入跑环任务的城池格子ID*/    
    int  LOOP_FRIST_GRID=5414;
  
    /**第一次进入跑环的任务ID */    
    int  LOOP_FRIST_TASK_ID=5415;
    
    /**第一次任务的目标城池ID（固定）*/
    int LOOP_FIRST_COMPLETE_TASK_CITY_ID= 5416;
    
    /**开启跑环的等级*/
    int LOOP_LEVEL_LIMIT=5417;
    
    /**完成前十个跑环任务给予倍数的奖励*/
    int LOOP_TASK_MULTIPLE_10=5418;
    
    /**完成前二十个跑环任务给予倍数的奖励*/
    int LOOP_TASK_MULTIPLE_20=5419;
    
    /**初始任务指引(方向)*/
    int LOOP_INIT_DIRECTION =5420; 
    
    /**普通骰子的购买数量(单次购买)*/
    int LOOP_BUY_COMMON_DICE_NUM=5421;
    
    /**幸运骰子的购买数量(单次购买)*/
    int LOOP_BUY_LUCKY_DICE_NUM=5422;
    
    /**boss超时的时间(ms)*/
    int LOOP_BOSS_TIME_OUT = 5423;
    
	/** 从起点出发到终点攻击boss的间隔时间(ms)*/
	int LOOP_READY_ATTACK_BOSS_TIME = 5424;	
	
	/**攻击boss是否减去玩家士兵(0不扣除，1扣除)*/
	int LOOP_REDUCE_SOLDIERS=5425;
	
	/**
	 * boss在n分钟内被击杀，下一次复活的时候等级+1
	 */
	int LOOP_BOSS_MIN_BEING_KILL_TIME = 5426;
	
	/**
	 * boss连续n次没有被击杀，下一次复活的时候等级-1
	 */
	int LOOP_BOSS_MAX_WIN_TIMES = 5427;
	
	/**
	 * boss超时的时候，攻击次数达到这个可以领取元宝奖励
	 */
	int LOOP_BOSS_MIN_ATTACK_TIMES = 5428;
	
	// -----------------55 摸金寻宝 ----------------------
    
    /**
     * 开启活动道具id
     */
    int TREASURE_OPEN_ACT_ITEM_ID = 5501;
    
    // ----------------60决战长安------------------------
    /**
     * 决战长安复活等待时间（秒）
     */
    int DECISIVE_CHANG_AN_RELIVE_CDTIME = 6001;
    
    /**
     * 决战长安行军时间（从复活区走到列表的时间，秒）
     */
    int DECISIVE_CHANG_AN_MARCH_TIME = 6002;
    
    /**
     * 决战长安战斗CD时间（秒）
     */
    int DECISIVE_CHANG_AN_BATTLE_CDTIME = 6003;
    
    /**
     * 决战长安开放入口以后多久开始（300秒）
     */
    int DECISIVE_CHANG_AN_STAR_TIME_AFTER_OPEN = 6004;
    
    //------------------61图腾------------------------
    
    /**
     * 龙魂之魂道具id
     */
    int TOTEM_SOUL_ITEM_ID = 6101;
    
    /**
     * 龙魂之灵道具id
     */
    int TOTEM_SPIRIT_ITEM_ID = 6102;
    
    /**
     * 每日清除祝福值的最小阶级
     */
    int TOTEM_CLEAR_LUCKY_VALUE_MIN_GRADE = 6104;
    
    /**
     * 图腾经验BUF最大比例(0.9)
     */
    int TOTEM_EXP_BUF_MAX_RATE = 6106;
    
    /**
	 * 图腾升阶活动大暴击经验倍率
	 */
	int TOTEM_UPGRADE_EXP_L_RATE = 6107;
	
	/**
	 * 图腾升阶活动小暴击经验倍率
	 */
	int TOTEM_UPGRADE_EXP_M_RATE = 6108;
	
    //------------------63折扣商店------------------------
    
    /**
     * 折扣商店显示物品数量
     */
    int DISCOUNT_SHOP_MATERIAL_COUNT = 6301;
    
    /**
     * 折扣商店刷新时间间隔(ms)
     */
    int DISCOUNT_SHOP_REFRESH_INTERVAL = 6302;
    
    /**
     * 折扣商店购买时间间隔(ms)
     */
    int DISCOUNT_SHOP_BUY_INTERVAL = 6303; 
    
    //------------- 65理财计划  ---------------------
    
    /**
     * 周理财计划购买需要多少级
     */
    int MONEY_PLAN_WEEK_LV = 6501;
    
    /**
     * 月理财计划购买需要多少级
     */
    int MONEY_PLAN_MONTH_LV = 6502;
    
    /**
	 * 消费一返回金币获得这么多的积分
	 */
	int SCORES_EQUALS_ONE_FUND_GOLD_COST = 6503;
	
	/**
	 * 抵扣一金币需要这么多个积分
	 */
	int SCORES_EQUALS_ONE_GOLD_PAY = 6504;
	
	/**
	 * 月理财计划多少号开始可以买
	 */
	int MONEY_PLAN_BEGIN_DAYS = 6505;
	
	
	//------------- 66多人副本  ---------------------
	
	/**
	 * 多人副本申请取代队长持续时间
	 */
	int MULTIFUBEN_CANDIDATE_PERSIST_TIME = 6601;
	
	/**
	 * 多人副本攻击cd时间
	 */
	int MULTIFUBEN_ATTACK_CD_TIME = 6602;
    
	//------------- 67积分活动  ---------------------
	
	/**
	 * 祝福的好友所需等级
	 */
	int BlESS_FRIEND_LEVEL = 6701;
	
	/**
	 * 领取好友祝福礼包上限
	 */
	int RECEIVE_BLESS_COUNT_LIMIT = 6702;
	
	// --------------- 70 植树节活动  -------------------
	
	/**
	 * 购买种子获得的道具id
	 */
	int PLANT_BUY_SEED_REWARD_ITEMID = 7001;
	
	/**
	 * 兑换消耗多少次
	 */
	int PLANT_OBIAN_COST_COUNT = 7002;
	
	/**
	 * 兑换获得什么道具id
	 */
	int PLANT_OBIAN_REWARD_ITEMID = 7003;
	
	/**
	 * 购买种子使用货币类型
	 */
	int PLANT_BUY_SEED_COST_TYPE = 7004;
	// --------------71团购---------------------
	/**
	 * 跨服团购可购买的开放等级
	 */
	int GROUP_PURCHASE_OPEN_LEVEL = 7102;
	
	// --------------72月卡---------------------
	
	/**
	 * 月卡道具id
	 */
	int MONTH_CARD_ITEM_ID = 7201;
	
	/**
	 * 月卡增益Buff道具id
	 */
	int MONTH_CARD_BUFF_ITEM_ID = 7202;
	
	// ---------------73练兵--------------------
	
	/**
	 * 练兵开放等级
	 */
	int TRAINING_OPEN_LEVEL = 7301;
	
	// --------------75幸运抽奖-----------------
	
	/**
	 * 幸运抽奖消耗的道具id
	 */
	int LUCKY_DRAW_COST_ITEM_ID = 7501;
	
	// --------------76 宝石道具转换---------------
	
	/**
	 * 每天可以转换宝石的次数
	 */
	int STONE_ITEM_CONVERT_TIMES = 7601;

	// --------------81 跨服群雄争霸---------------
	/**
	 * 跨服争霸参与的服务器最低等级
	 */
	int KF_CHAMPION_MIN_LEVEL = 8101;
	
	// --------------82全服摸金寻宝---------------
	
	/**
	 * 全服摸金开启活动道具id
	 */
	int SERVER_TREASURE_OPEN_ACT_ITEM_ID = 8201;
	
	// -------------84劳动节种植活动--------------
	
	/**
	 * 购买肥料获得的道具id
	 */
	int LABOR_PLANT_BUY_FERTILIZER_REWARD_ITEMID = 8401;
	
	/**
	 * 兑换消耗多少次
	 */
	int LABOR_PLANT_OBIAN_COST_COUNT = 8402;
	
	/**
	 * 兑换获得什么道具id
	 */
	int LABOR_PLANT_OBIAN_REWARD_ITEMID = 8403;
	
	/**
	 * 购买肥料使用的货币类型
	 */
	int LABOR_PLANT_BUY_FERTILIZER_COST_TYPE = 8404;
	
	// -------------86欢乐宝箱--------------
	/**
	 * 欢乐宝箱刷新的时间间隔
	 */
	int HAPPY_BOX_REFRESH_TIME_INTERVAL = 8601;
	
	// -------------87坐骑-----------------
	
	/**
	 * 坐骑开放等级
	 */
	int HORSE_OPEN_LEVEL = 8701;
	
	/**
	 * 初始获得的坐骑id
	 */
	int HORSE_INIT_HORSE_ID = 8702;
	
	/**
	 * 坐骑培养道具id
	 */
	int HORSE_TRAIN_ITEM_ID = 8703;
	
	/**
	 * 坐骑每次培养增加的经验
	 */
	int HORSE_TRAIN_ADD_EXP = 8704;
	
	/**
	 * 坐骑培养大暴击经验倍率
	 */
	int HORSE_TRAIN_L_RATE = 8705;
	
	/**
	 * 坐骑培养小暴击经验倍率
	 */
	int HORSE_TRAIN_M_RATE = 8706;
	
	/**
	 * 坐骑培养开放等级
	 */
	int HORSE_TRAIN_OPEN_LEVEL = 8707;

    // -------------88神秘商店-----------------
    /**
     * 神秘商店商品数量(一次刷出多少个商品)
     */
    int MYSTERY_STORE_CELL_COUNT = 8801;

    /**
     * 神秘商店刷新间隔
     */
    int MYSTERY_STORE_REFRESH_INTERVAL = 8802;

    /**
     * 神秘商店刷新道具id
     */
    int MYSTERY_STORE_REFRESH_ITEM_ID = 8803;

    // -------------89端午活动-----------------
    /**
     * 粽叶id
     */
    int DUAN_WU_ZONG_YE_ID = 8901;
    /**
     * 馅料id
     */
    int DUAN_WU_XIAN_LIAO_ID = 8902;
    /**
     * 糯米id
     */
    int DUAN_WU_NUO_MI_ID = 8903;
    /**
     * 粽子id
     */
    int DUAN_WU_ZONG_ZI_ID = 8904;
    /**
     * 赠品道具id
     */
    int DUAN_WU_CONSUME_REWARD_ITEM_ID = 8905;
    /**
     * 购买多少个馅料可领取赠品
     */
    int DUAN_WU_REWARD_BOUGHT_COUNT = 8907;
    /**
     * 制作一个粽子需要粽叶数
     */
    int DUAN_WU_REQUIRE_ZONG_YE_COUNT = 8908;
    /**
     * 制作一个粽子需要糯米数
     */
    int DUAN_WU_REQUIRE_NUO_MI_COUNT = 8909;
    /**
     * 制作一个粽子需要馅料数
     */
    int DUAN_WU_REQUIRE_XIAN_LIAO_COUNT = 8910;
    /**
     * 每日任务数
     */
    int DUAN_WU_TASK_COUNT = 8911;
    /**
     * 粽叶价格
     */
    int DUAN_WU_ZONG_YE_COST = 8914;
    /**
     * 馅料价格
     */
    int DUAN_WU_NUO_MI_COST = 8915;

    // -------------90灵翼-----------------
    /**
     * 灵翼培养道具id
     */
	int NETHERWING_TRAIN_ITEM_ID = 9001;
	
	/**
	 * 灵翼入魂丹道具id
	 */
	int NETHERWING_SOUL_TRAIN_ITEM_ID = 9002;
	
	/**
	 * 灵翼单次培养增加经验
	 */
	int NETHERWING_TRAIN_ADD_EXP = 9003;

	/**
	 * 灵翼小暴击倍率
	 */
	int NETHERWING_TRAIN_M_RATE = 9004;
	
	/**
	 * 灵翼大暴击倍率
	 */
	int NETHERWING_TRAIN_L_STAR = 9005;

	/**
	 * 灵翼单次培养需要道具数量
	 */
	int NETHERWING_TRAIN_NEED_ITEMS = 9006;
	
	/**
	 * 灵翼單次入魂增加经验
	 */
	int NETHERWING_SOUL_TRAIN_ADD_EXP = 9007;

	/**
	 * 灵翼入魂小暴击倍率
	 */
	int NETHERWING_SOUL_TRAIN_M_RATE = 9008;
	
	/**
	 * 灵翼入魂大暴击倍率
	 */
	int NETHERWING_SOUL_TRAIN_L_RATE = 9009;
	
	/**
	 * 灵翼单次入魂需要道具数量
	 */
	int NETHERWING_SOUL_TRAIN_NEED_ITEMS = 9010;
	
	/**
	 * 灵翼高级培养的连续次数
	 */
	int NETHERWING_MULTI_TRAIN_TIMES = 9011;
	
	/**
	 * 灵翼高级入魂的连续次数
	 */
	int NETHERWING_MULTI_SOUL_TRAIN_TIMES = 9012;
	
	/**
	 * 超级暴击触发的经验差阀值
	 */
	int NETHERWING_TRAIN_SUPER_RATE_LIMIT = 9013;
	
	/**
	 * 灵翼池大小
	 */
	int NETHERWING_POOL_SIZE = 9014;
	
	// -------------91跨服掠夺-----------------
	
	/**
	 * 跨服掠夺最低玩家等级限制
	 */
	int KF_LOOT_MIN_PLAYER_LEVEL = 9101;
	
	/**
	 * 跨服掠夺每天默认掠夺次数
	 */
	int KF_LOOT_DEFAULT_LOOT_COUNT = 9102;
	
	/**
	 * 跨服掠夺自动刷新时间间隔（ms）
	 */
	int KF_LOOT_AUTO_REFRESH_INTERVAL = 9103;
	
	/**
	 * 跨服掠夺对手数量
	 */
	int KF_LOOT_TARGET_AMOUNT = 9104;
	
	/**
	 * 跨服掠夺对手池子数量
	 */
	int KF_LOOT_TARGET_POOL_AMOUNT = 9105;
	
	/**
	 * 跨服掠夺cd时间（ms）
	 */
	int KF_LOOT_CD_TIME = 9106;
	
	/**
	 * 跨服掠夺最大累计cd时间（ms）
	 */
	int KF_LOOT_MAX_CD_TIME = 9107;
	
	/**
	 * 军团试炼死亡冷却（ms)
	 */
	int ARMY_GROUP_TRIAN_DIE_COOL_TIME = 9301;
	
	/**
	 * 军团试炼战斗冷却（ms)
	 */
	int ARMY_GROUP_TRIAN_BATTLE_COOL_TIME = 9302;
	
	// ---------------风云争霸94----------------
	/**
	 * 退出战队的冷却时间
	 */
	int FUNG_WAN_QUIT_TEAM_CD_TIME = 9401;
	
	/**
	 * 免费献花次数
	 */
	int FLOWERS_FREE_COUNT = 9402;
	
	/**
	 * 免费塞蛋次数
	 */
	int EGGS_FREE_COUNT = 9403;
	
	/**
	 * 更新数据的冷却时间
	 */
	int FUNG_WAN_UPDATE_DATE_CD_TIME = 9404;
	
	/**
	 * 战力占比
	 */
	int FUNG_WAN_ABILITY_PERCENT = 9405;
	
	//----------------真龙宝库95---------
    /**
     * 真龙宝库开放等级
     */
	int TREASURE_HOUSE_OPEN_LEVEL = 9501;

    /**
     * 钥匙宝箱id
     */
    int TREASURE_HOUSE_KEY_BOX_ID = 9502;

    /**
     * 购买钥匙宝箱获得的水晶数
     */
    int TREASURE_HOUSE_CRYSTAL_COUNT = 9503;

	//----------------充值返还元宝活动96---------
	/**
	 * 充值返还元宝比例
	 */
	int CHARGE_RETURN_PERCENT = 9601;
	
	/**
	 * 內幣充值額度上限
	 */
	int CHARGE_RMB_AMOUNT_LIMIT = 9602;
	
	// ---------------充值抽奖活动99---------------
	
	/**
	 * 最小充值金额
	 */
	int CHARGE_DRAW_MIN_CHARGE_MONEY = 9901;
	
	/**
	 * 每天可获得的最大抽奖次数
	 */
	int CHARGE_DRAW_DRAW_TIMES_LIMIT = 9902;
	
	//----------------时装模块 98---------
	/**
	 * 時裝開放等級
	 */
	int FASHION_EQUIP_OPEN_LEVEL = 9801;
	/**
	 * 衣柜快速升级需要衣柜先达到的等级
	 */
	int BUEARU_UPGRADE_OPEN_LEVEL = 9802;
	//----------------跨服天梯模块 101---------
	/**
	 * 跨服天梯开放等级
	 */
	int KF_LADDER_OPEN_LEVEL = 10104;
	
	/**
	 * 跨服天梯每日可挑战次数
	 */
	int KF_LADDER_DEFAULT_CHALLENGE_COUNT = 10103;
	
	/**
	 * 购买目标消耗元宝数
	 */
	int KF_LADDER_BUY_TARGET_COST = 10101;
	
	/**
	 * 购买挑战次数消耗元宝数
	 */
	int KF_LADDER_BUY_CHALLENGE_COUNT_COST = 10102;
	
	/**
	 * 跨服天梯积分清除百分比
	 */
	int KF_LADDER_SCORE_CLEAR_PERCENT = 10106;
	
	/**
	 * 跨服天梯排行榜入榜人數限制
	 */
	int KF_LADDER_RANKS_LIMIT = 10105;
	
	/**
	 * 跨服天梯排行榜入榜人數限制
	 */
	int KF_LADDER_CHALLENGE_COUNT_BUY_LIMIT = 10108;
	
	/**
	 * 跨服天梯可显示的排名数量限制
	 */
	int KF_LADDER_SHOW_RANK_LIMIT = 10109;
	// ------------------称号102-------------------------
	
	/**
	 * 等级排名第一称号id
	 */
	int HONOR_PLAYER_LEVEL_RANK_FIRST = 10201;
	
	/**
	 * 等级排名第二称号id
	 */
	int HONOR_PLAYER_LEVEL_RANK_SECOND = 10202;
	
	/**
	 * 等级排名第三称号id
	 */
	int HONOR_PLAYER_LEVEL_RANK_THIRD = 10203;
	
	/**
	 * 战力排名第一称号id
	 */
	int HONOR_PLAYER_ABILITY_RANK_FIRST = 10204;
	
	/**
	 * 战力排名第二称号id
	 */
	int HONOR_PLAYER_ABILITY_RANK_SECOND = 10205;
	
	/**
	 * 战力排名第三称号id
	 */
	int HONOR_PLAYER_ABILITY_RANK_THIRD = 10206;
	
	/**
	 * 竞技场排名第一称号id
	 */
	int HONOR_ARENA_RANK_FIRST = 10207;
	
	/**
	 * 竞技场排名第二称号id
	 */
	int HONOR_ARENA_RANK_SECOND = 10208;
	
	/**
	 * 竞技场排名第三称号id
	 */
	int HONOR_ARENA_RANK_THIRD = 10209;
	
	
	// ------------------财富乐翻天103------------------
	
	/**
	 * 幸运星获得的利率
	 */
	int DEPOSIT_STAR_RATE = 10301;
	
}