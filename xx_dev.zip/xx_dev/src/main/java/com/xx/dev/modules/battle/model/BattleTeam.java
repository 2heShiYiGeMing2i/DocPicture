/**
 * @file:BattleTeam.java
 * @author:David
 **/
package com.xx.dev.modules.battle.model;

/**
 * @class:BattleTeam
 * @description:战斗方阵
 * @author:David
 * @version:v1.0
 * @date:2013-4-19
 **/
public enum BattleTeam {

	/**
	 * 0-进攻方
	 */
	OFFENSE_TEAM,
	/**
	 * 1-防守方
	 */
	DEFENSE_TEAM;

	public static BattleTeam valueOf(int value){
		switch (value) {
		case 1:
			return DEFENSE_TEAM;
		default:
			return OFFENSE_TEAM;
		}
	}
}

