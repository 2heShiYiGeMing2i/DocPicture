/**
 * @file:PlayerArmageddonInfo.java
 * @author:David
 **/
package com.xx.dev.modules.armageddon.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.xx.common.db.model.BaseModel;
import com.xx.dev.constant.HookStatus;
import com.xx.dev.modules.journey.model.HardType;
import com.xx.dev.utils.CommonRule;

/**
 * @class:PlayerArmageddonInfo
 * @description:玩家大决战信息
 * @author:David
 * @version:v1.0
 * @date:2013-5-21
 **/
@Entity
@Table(name = "playerArmageddonInfo")
public class PlayerArmageddonInfo extends BaseModel<Long>{
	private static final long serialVersionUID = -5960328454729208021L;
	public static final int INIT_VALUE = -1;
	/**
	 * 主键（玩家id）
	 */
	@Id
	@Column(columnDefinition = "bigint(20) not null comment '玩家id'")
	private Long id;
	/**
	 * 当前副本进度(保存最高已进入的副本id)
	 */
	@Column(columnDefinition = "int(11) default '-1' comment '当前据点进度(保存最高已进入的据点id)'")
	private Integer missionId = INIT_VALUE;
	/**
	 * 当前据点据点进度ID(要打的下一个据点,还未打)
	 */
	@Column(columnDefinition = "int(11) default '-1' comment '当前据点军队进度ID'")
	private Integer curMissionId = INIT_VALUE;
	
	/**
	 * 最近通关的最大副本ID
	 */
	@Column(columnDefinition = "int(11) default '-1' comment '最近通关的最大据点ID'")
	private Integer lastMissionId = INIT_VALUE;
	
	/**
	 * 挂机状态 0-正常 1-挂机中  2-挂机结束
	 */
	@Column(columnDefinition = "tinyint(3) default '0' comment '挂机状态 0-正常 1-挂机中  2-挂机结束'")
	private Integer hookStatus = HookStatus.NORMAL;
	
	/**
	 * 当前累计的奖励串结果 {DropResult#rewardList}
	 */
	@Column(columnDefinition = "text comment '当前累计的奖励串结果'")
	private String rewardResult;
	/**
	 * 当前累计的奖励串结果 {DropResult#noticeSet}
	 */
	@Column(columnDefinition = "text comment '当前累计的奖励串结果'")
	private String noticeResult;
	/**
	 * 当前累计的奖励串结果是否可以领取(据点通关)
	 */
	@Column(columnDefinition = "tinyint(3) default '0' comment '当前累计的奖励串结果是否可以领取(据点通关)'")
	private boolean reward = false;
	/**
	 * 当前困难模式
	 */
	@Column(columnDefinition = "tinyint(3) default '0' comment '当前困难模式'")
	private HardType hardType = HardType.NONE;
	
	/**
	 * 当前剩余次数
	 */
	@Column(columnDefinition = "int(11) default '0' comment '当前已用次数'")
	private Integer times = 0;
	/**
	 * 收益次数最后计算时间
	 */
	@Column(columnDefinition = "datetime default '2012-01-01 00:00:00' comment '收益次数最后计算时间'")
	private Date incomeDate = CommonRule.MIN_DATE;
	/**
	 * 战斗CD时间
	 */
	@Column(columnDefinition = "bigint(20) not null comment '战斗CD时间'")
	private long battleCdTime = -1l;
	/**
	 * 是否首次进入 
	 */
	@Column(columnDefinition = "tinyint(3) default '1' comment '是否首次进入 '")
	private boolean first = true;
	@Override
	public Long getId() {
		return id;
	}

	@Override
	public void setId(Long id) {
		this.id = id;
	}

	public Integer getMissionId() {
		return missionId;
	}

	public void setMissionId(Integer missionId) {
		this.missionId = missionId;
	}

	public Integer getCurMissionId() {
		return curMissionId;
	}

	public void setCurMissionId(Integer curMissionId) {
		this.curMissionId = curMissionId;
	}

	public Integer getHookStatus() {
		return hookStatus;
	}

	public void setHookStatus(Integer hookStatus) {
		this.hookStatus = hookStatus;
	}

	public String getRewardResult() {
		return rewardResult;
	}

	public void setRewardResult(String rewardResult) {
		this.rewardResult = rewardResult;
	}

	public boolean isReward() {
		return reward;
	}

	public void setReward(boolean reward) {
		this.reward = reward;
	}

	public String getNoticeResult() {
		return noticeResult;
	}

	public void setNoticeResult(String noticeResult) {
		this.noticeResult = noticeResult;
	}

	public HardType getHardType() {
		return hardType;
	}

	public void setHardType(HardType hardType) {
		this.hardType = hardType;
	}

	public Integer getTimes() {
		return times;
	}

	public void setTimes(Integer times) {
		this.times = times;
	}

	public Date getIncomeDate() {
		return incomeDate;
	}

	public void setIncomeDate(Date incomeDate) {
		this.incomeDate = incomeDate;
	}

	public boolean isRewardSameResetTime() {
		return CommonRule.isSameResetTime(this.incomeDate, CommonRule.FOUR_HOUR_RESET_TIME);
	}
	
	public long getBattleCdTime() {
		return battleCdTime;
	}

	public void setBattleCdTime(long battleCdTime) {
		this.battleCdTime = battleCdTime;
	}

	public Integer getLastMissionId() {
		return lastMissionId;
	}

	public void setLastMissionId(Integer lastMissionId) {
		this.lastMissionId = lastMissionId;
	}

	public boolean decreaseRewardTime() {
		if(this.times > 0){
			this.times --;
			return true;
		}
		return false;
	}
	
	public boolean isFirst() {
		return first;
	}

	public void setFirst(boolean first) {
		this.first = first;
	}

	@Transient
	public boolean isBattleCD(){
		return this.battleCdTime >= System.currentTimeMillis();
	}
}

