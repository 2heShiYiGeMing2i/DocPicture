package com.xx.dev.modules.arena.model.basedb;

import com.xx.common.basedb.anno.Id;
import com.xx.common.basedb.anno.Resource;


/**
 * 竞技场宝箱
 * 
 * @author bingshan
 */
@Resource
public class ArenaBox {
	
	/**
	 * 主键id
	 */
	@Id
	private int id;
	
	/**
	 * 起始排名(小)
	 */
	private int minRak;
	
	/**
	 * 截止排名(大)
	 */
	private int maxRank;
	
	/**
	 * 奖励串
	 */
	private String rewards;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getMinRak() {
		return minRak;
	}

	public void setMinRak(int minRak) {
		this.minRak = minRak;
	}

	public int getMaxRank() {
		return maxRank;
	}

	public void setMaxRank(int maxRank) {
		this.maxRank = maxRank;
	}

	public String getRewards() {
		return rewards;
	}

	public void setRewards(String rewards) {
		this.rewards = rewards;
	}

}
