package com.xx.dev.modules.blackmarket.model.basedb;

import com.xx.common.basedb.anno.Id;
import com.xx.common.basedb.anno.Index;
import com.xx.common.basedb.anno.Resource;
import com.xx.dev.constant.IndexName;

/**
 * 市场资源表
 * 
 * @author Along
 *
 */
@Resource
public class Market {

	@Id
	private int id;
	
	/**
	 * 类型
	 */
	@Index(name = IndexName.MARKET_TYPE_INDEX)
	private int type;
	
	/**
	 * 物品奖励串
	 */
	private String goodsReward;
	
	/**
	 * 购买消耗
	 */
	private String buyPrice;
	
	/**
	 * 开放的VIP等级
	 */
	private int vipLevel;
	
	/**
	 * 开放的玩家等级
	 */
	private int playerLevel;
	
	/**
	 * 开放的官职等级
	 */
	private int playerJob;
	
	/**
	 * 开放的建筑等级
	 */
	private int buildingLevel;
	
	/**
	 * 全服总限量
	 */
	private int serverLimit;
	
	/**
	 * 个人总限量
	 */
	private int selfLimit;
	
	/**
	 * 全服每日总限量
	 */
	private int dayServerLimit;
	
	/**
	 * 个人每日总限量
	 */
	private int daySelfLimit;
	
	/**
	 * 单人副本据点id
	 */
	private int missionId;
	
	/**
	 * 征战天下击破据点id
	 */
	private int areaId;
	
	/**
	 * 征战天下据点的难度（1：普通据点 2：困难据点）
	 */
	private int difficulty;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public String getGoodsReward() {
		return goodsReward;
	}

	public void setGoodsReward(String goodsReward) {
		this.goodsReward = goodsReward;
	}

	public String getBuyPrice() {
		return buyPrice;
	}

	public void setBuyPrice(String buyPrice) {
		this.buyPrice = buyPrice;
	}

	public int getVipLevel() {
		return vipLevel;
	}

	public void setVipLevel(int vipLevel) {
		this.vipLevel = vipLevel;
	}

	public int getPlayerJob() {
		return playerJob;
	}

	public void setPlayerJob(int playerJob) {
		this.playerJob = playerJob;
	}

	public int getBuildingLevel() {
		return buildingLevel;
	}

	public void setBuildingLevel(int buildingLevel) {
		this.buildingLevel = buildingLevel;
	}

	public int getServerLimit() {
		return serverLimit;
	}

	public void setServerLimit(int serverLimit) {
		this.serverLimit = serverLimit;
	}

	public int getSelfLimit() {
		return selfLimit;
	}

	public void setSelfLimit(int selfLimit) {
		this.selfLimit = selfLimit;
	}

	public int getDayServerLimit() {
		return dayServerLimit;
	}

	public void setDayServerLimit(int dayServerLimit) {
		this.dayServerLimit = dayServerLimit;
	}

	public int getDaySelfLimit() {
		return daySelfLimit;
	}

	public void setDaySelfLimit(int daySelfLimit) {
		this.daySelfLimit = daySelfLimit;
	}

	public int getPlayerLevel() {
		return playerLevel;
	}

	public void setPlayerLevel(int playerLevel) {
		this.playerLevel = playerLevel;
	}

	public int getAreaId() {
		return areaId;
	}

	public void setAreaId(int areaId) {
		this.areaId = areaId;
	}

	public int getMissionId() {
		return missionId;
	}

	public void setMissionId(int missionId) {
		this.missionId = missionId;
	}

	public int getDifficulty() {
		return difficulty;
	}

	public void setDifficulty(int difficulty) {
		this.difficulty = difficulty;
	}
	
}
