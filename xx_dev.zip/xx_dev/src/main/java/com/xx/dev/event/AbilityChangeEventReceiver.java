package com.xx.dev.event;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.xx.common.event.AbstractReceiver;
import com.xx.dev.modules.magic.service.AbilityRankService;

/**
 * 战斗力变化事件接收器
 * 
 * @author Along
 *
 */
@Component
public class AbilityChangeEventReceiver extends
		AbstractReceiver<AbilityChangeEvent> {
	
	@Autowired
	private AbilityRankService abilityRankService;

	@Override
	public String[] getEventNames() {
		return new String[] {AbilityChangeEvent.NAME};
	}

	@Override
	public void doEvent(AbilityChangeEvent event) {
		long playerId = event.getPlayerId();
		
		//战斗力排行榜
		this.abilityRankService.doAbilityEvent(playerId, event.getAbility());
	}

}
