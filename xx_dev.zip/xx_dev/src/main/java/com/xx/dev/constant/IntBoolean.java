package com.xx.dev.constant;

/**
 * 布尔值映射
 * 
 * @author Along
 *
 */
public interface IntBoolean {

	int TRUE = 1;

	int FALSE = 0;

}
