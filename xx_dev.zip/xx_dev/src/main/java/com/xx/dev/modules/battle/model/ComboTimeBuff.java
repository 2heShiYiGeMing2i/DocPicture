/**
 * @file:ComboTimeBuff.java
 * @author:David
 **/
package com.xx.dev.modules.battle.model;
/**
 * @class:ComboTimeBuff
 * @description:连击次数
 * @author:David
 * @version:v1.0
 * @date:2013-4-30
 **/
public class ComboTimeBuff extends AbstractBuff {

	public ComboTimeBuff(int effectBaseValueType, double effectBase,
			int effectValueType, double effect, int startRound, int persistRound) {
		super(effectBaseValueType, effectBase, effectValueType, effect, startRound,
				persistRound);
	}

}

