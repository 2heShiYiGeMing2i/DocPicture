package com.xx.dev.constant;

/**
 * 玩家身份标识
 * 
 * @author Along
 *
 */
public enum Identify {

	/**
	 * 0-普通身份
	 */
	COMMON,

	/**
	 * 1-GM身份标识
	 */
	GM,
	
	/**
	 * 2-指导员标识
	 */
	INSTRUCTOR
	
}
