package com.xx.dev.modules.arena.model;


/**
 * 日排行奖励信息
 * 
 * @author bingshan
 */
public class DayRankRewardVO {
	
	/**
	 * 排名
	 */
	private int rank;
	
	/**
	 * 玩家id
	 */
	private long playerId;
	
	/**
	 * 奖励状态：0-未领取 1-领取
	 */
	private int rewardStatus = 0;
	
	public static DayRankRewardVO valueOf(int rank, long playerId) {
		DayRankRewardVO d = new DayRankRewardVO();
		d.rank = rank;
		d.playerId = playerId;
		return d;
	}

	public int getRank() {
		return rank;
	}

	public void setRank(int rank) {
		this.rank = rank;
	}

	public int getRewardStatus() {
		return rewardStatus;
	}

	public void setRewardStatus(int rewardStatus) {
		this.rewardStatus = rewardStatus;
	}

	public long getPlayerId() {
		return playerId;
	}

	public void setPlayerId(long playerId) {
		this.playerId = playerId;
	}

}
