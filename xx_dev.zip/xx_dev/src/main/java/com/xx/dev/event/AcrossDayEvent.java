package com.xx.dev.event;

import com.xx.common.event.Event;
import com.xx.dev.modules.common.service.CommonService;


/**
 * 跨天事件
 * 
 * @author bingshan
 */
public class AcrossDayEvent {
	
	/**
	 * 跨天事件
	 */
	public static final String NAME = CommonService.MODULE_NAME + ":ACROSSDAY";
	
	public static Event<AcrossDayEvent> valueOf() {
		AcrossDayEvent e = new AcrossDayEvent();
		return new Event<AcrossDayEvent>(NAME, e);
	}

}
