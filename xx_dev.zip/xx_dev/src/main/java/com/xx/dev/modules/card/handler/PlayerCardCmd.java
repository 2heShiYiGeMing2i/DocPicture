package com.xx.dev.modules.card.handler;

import com.xx.dev.modules.card.model.PlayerCardDto;
import com.xx.dev.modules.reward.result.ValueResultSet;

public interface PlayerCardCmd {

	/**
	 * 获取玩家月卡信息
	 * @return Map {
	 * 				"result" : {@link PlayerCardResult}
	 * 				"content" : {@link PlayerCardDto}
	 * 				}
	 */
	public static final int GET_PLAYER_CARD_INFO = 1;
	
	/**
	 * 使用元宝开通月卡
	 * @param 
	 * num-购买月卡数量
	 * 
	 * @return Map {
	 * 				"result" : {@link PlayerCardResult}
	 * 				"content" : {@link PlayerCardDto}
	 * 				"valueResultSet": {@link ValueResultSet}
	 * 				"goldDiscount":{Integer}//打折的元宝数
	 * 				}
	 */
	public static final int OPEN_PLAYER_CARD = 2;
	
	/**
	 * 领取体力
	 * @return Map {
	 * 				"result" : {@link PlayerCardResult}
	 * 				"content" : {@link PlayerCardDto}
	 * 				"valueResultSet" : {@link ValueResultSet}
	 * 				}
	 */
	public static final int GET_POWER = 3;
	/**
	 * 一键完成富甲天下任务
	 * @return Map {
	 * 				"result" : {@link PlayerCardResult}
	 * 				"content" : {@link PlayerCardDto}
	 * 				"rewardString" : {@link String}
	 * 				"valueResultSet" : {@link ValueResultSet}
	 * 				}
	 */
	public static final int FINISH_FJTX_TASKS = 4;
	/**
	 * 领取每日buffer
	 * @return Map {
	 * 				"result" : {@link PlayerCardResult}
	 * "content" : {@link PlayerCardDto}
	 * 				}
	 */
	public static final int GET_DAILY_BUFFER = 5;
	
}
