package com.xx.dev.modules.arena.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.codehaus.jackson.type.TypeReference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.xx.common.basedb.BasedbService;
import com.xx.common.db.cache.DbCachedService;
import com.xx.common.runtime.Lifecycle;
import com.xx.common.runtime.LifecycleMethod;
import com.xx.common.scheduling.Scheduled;
import com.xx.common.scheduling.ValueType;
import com.xx.common.util.DateUtil;
import com.xx.common.util.JsonUtils;
import com.xx.common.util.RandomUtil;
import com.xx.common.utility.lock.ChainLock;
import com.xx.common.utility.lock.LockUtils;
import com.xx.dev.config.Module;
import com.xx.dev.constant.BattleType;
import com.xx.dev.constant.BattleWaveID;
import com.xx.dev.constant.FormulaID;
import com.xx.dev.constant.GameRuleID;
import com.xx.dev.constant.GoldRuleID;
import com.xx.dev.constant.LogSource;
import com.xx.dev.constant.OpenId;
import com.xx.dev.constant.RewardType;
import com.xx.dev.constant.SysKey;
import com.xx.dev.model.Result;
import com.xx.dev.modules.arena.entity.ArenaDayRankReward;
import com.xx.dev.modules.arena.entity.ArenaInfo;
import com.xx.dev.modules.arena.entity.PlayerArena;
import com.xx.dev.modules.arena.handler.ArenaCmd;
import com.xx.dev.modules.arena.handler.ArenaResult;
import com.xx.dev.modules.arena.model.ChallengeDto;
import com.xx.dev.modules.arena.model.DayRankRewardVO;
import com.xx.dev.modules.arena.model.FirstRankDto;
import com.xx.dev.modules.arena.model.PlayerArenaDto;
import com.xx.dev.modules.arena.model.PlayerArenaVo;
import com.xx.dev.modules.arena.model.PlayerRankDto;
import com.xx.dev.modules.arena.model.RankVo;
import com.xx.dev.modules.arena.model.basedb.ArenaBox;
import com.xx.dev.modules.arena.model.basedb.ArenaCard;
import com.xx.dev.modules.arena.model.basedb.ArenaDayRank;
import com.xx.dev.modules.arena.model.basedb.ArenaNpc;
import com.xx.dev.modules.arena.rule.ArenaRule;
import com.xx.dev.modules.arena.service.ArenaRuleService;
import com.xx.dev.modules.arena.service.ArenaService;
import com.xx.dev.modules.battle.core.BattleWinner;
import com.xx.dev.modules.battle.model.BattleCharacter;
import com.xx.dev.modules.battle.model.BattleGroup;
import com.xx.dev.modules.battle.model.BattlePlayerInfo;
import com.xx.dev.modules.battle.model.BattleResult;
import com.xx.dev.modules.battle.model.BattleTeam;
import com.xx.dev.modules.battle.model.MultiBattleResult;
import com.xx.dev.modules.battle.service.BattleService;
import com.xx.dev.modules.champion.service.ChampionService;
import com.xx.dev.modules.chapter.service.ChapterRuleService;
import com.xx.dev.modules.chitchat.model.NoticeDto;
import com.xx.dev.modules.chitchat.model.NoticeId;
import com.xx.dev.modules.chitchat.model.NoticeKey;
import com.xx.dev.modules.chitchat.service.NoticeService;
import com.xx.dev.modules.hero.service.HeroService;
import com.xx.dev.modules.honor.service.HonorService;
import com.xx.dev.modules.magic.service.ArenaRankService;
import com.xx.dev.modules.opencontrol.service.OpenControlService;
import com.xx.dev.modules.player.entity.Player;
import com.xx.dev.modules.player.model.PlayerDto;
import com.xx.dev.modules.player.model.basedb.Vip;
import com.xx.dev.modules.player.service.PlayerService;
import com.xx.dev.modules.push.PushHelper;
import com.xx.dev.modules.reward.action.RewardActionSet;
import com.xx.dev.modules.reward.model.Reward;
import com.xx.dev.modules.reward.model.SimpleReward;
import com.xx.dev.modules.reward.result.ValueResultSet;
import com.xx.dev.modules.reward.service.RewardService;
import com.xx.dev.modules.reward.support.RewardHelper;
import com.xx.dev.modules.slave.service.SlaveService;
import com.xx.dev.modules.task.event.ArenaEvent;
import com.xx.dev.modules.task.service.MainFeederTaskService;
import com.xx.dev.modules.task.service.TaskBus;
import com.xx.dev.modules.vip.service.VipService;
import com.xx.dev.utils.CommonRule;
import com.xx.dev.utils.FormulaHelper;
import com.xx.dev.utils.GameRuleService;

/**
 * 竞技场系统接口实现
 * 
 * @author bingshan
 */
@Component
public class ArenaServiceImpl implements ArenaService {
	private static final Logger logger = LoggerFactory.getLogger(ArenaServiceImpl.class);
	
	@Autowired
	private DbCachedService dbCachedService;
	@Autowired
	private PlayerService playerService;
	@Autowired
	private ArenaRuleService arenaRuleService;	
	@Autowired
	private GameRuleService gameRuleService;
	@Autowired
	private RewardService rewardService;
	@Autowired
	private BasedbService basedbService;
	@Autowired
	private FormulaHelper formulaHelper;
	@Autowired
	private HeroService heroService;
	@Autowired
	private PushHelper pushHelper;
	@Autowired
	private MainFeederTaskService mainFeederTaskService;
	@Autowired
	private ChapterRuleService chapterRuleService;
	@Autowired
	private TaskBus taskBus;
	@Autowired
	private VipService vipService;
	@Autowired
	private OpenControlService openControlService;
	@Autowired
	private NoticeService noticeService;
	@Autowired
	private BattleService battleService;
	@Autowired
	private SlaveService slaveService;
	@Autowired
	private ChampionService championService;
	@Autowired
	private ArenaRankService arenaRankService;
	@Autowired
	private HonorService honorService;
	
	
	/**
	 * 当前竞技场最大排名
	 */
	private final AtomicInteger maxRanking = new AtomicInteger(0);
	
	/**
	 * 排名Map {名次：RankVo }
	 */
	private final ConcurrentMap<Integer, RankVo> rankMap = new ConcurrentHashMap<Integer, RankVo>();
	
	/**
	 * 玩家竞技场信息 {playerId: PlayerArenaVo}
	 */
	private final ConcurrentMap<Long, PlayerArenaVo> playerMap = new ConcurrentHashMap<Long, PlayerArenaVo>();
	
	/**
	 * 竞技场锁
	 */
	private final ReadWriteLock arenaLock = new ReentrantReadWriteLock();
	
	/**
	 * 竞技场结算第一名
	 */
	private long topPlayerId = 0L;
	
	
	@Override
	public PlayerArena getPlayerArena(long playerId) {
		Player player = this.dbCachedService.get(playerId, Player.class);
		if (player == null) {
			return null;
		}
		
		PlayerArena playerArena = this.dbCachedService.get(playerId, PlayerArena.class);
		if (playerArena == null) {
			playerArena = PlayerArena.valueOf(playerId);
			playerArena = this.dbCachedService.submitNew2Queue(playerArena);
		} else {
			//判断是否跨天
			if (CommonRule.isSameResetTime(playerArena.getRefreshTime())) {
				ChainLock chainLock = LockUtils.getLock(player);
				chainLock.lock();
				try {
					if (CommonRule.isSameResetTime(playerArena.getRefreshTime())) {
						//免费挑战次数
						int freeChallengeCount = this.gameRuleService.getAmountByID(GameRuleID.ARENA_CHALLENGE_COUNT).intValue();
						int challengeCount = playerArena.getChallengeCount();					
						int leftBuyCount = playerArena.getBuyCount() + playerArena.getPreLeftBuyCount();						
						if (challengeCount > freeChallengeCount) {
							leftBuyCount -= (challengeCount - freeChallengeCount);
						}
						if (leftBuyCount < 0) {
							leftBuyCount = 0;
						}
						
						playerArena.setChallengeCount(0);
						playerArena.setBuyCount(0);
						playerArena.setPreLeftBuyCount(leftBuyCount);
						playerArena.setRefreshTime(new Date());
						this.dbCachedService.submitUpdated2Queue(playerArena.getId(), PlayerArena.class);
					}
				} finally {
					chainLock.unlock();
				}
			}
		}
		return playerArena;
	}

	@Override
	public List<PlayerRankDto> getChallengeList(long playerId) {
		Player player = this.dbCachedService.get(playerId, Player.class);
		PlayerArena playerArena = this.getPlayerArena(playerId);
		if (player == null || playerArena == null) {
			return null;
		}
		
		//是否曾经挑战过竞技场
		boolean challenged = playerArena.getChallenged() != 0;
		if (challenged) {
			return this.getPlayerChallengeList(playerId);
			
		} else {//npc
			List<PlayerRankDto> result = new ArrayList<PlayerRankDto>(ArenaRule.CHALLENGE_LIST_COUNT);
			List<ArenaNpc> npcList = this.arenaRuleService.getArenaNpcList(ArenaRule.CHALLENGE_LIST_COUNT - 1);
			if (npcList != null && npcList.size() > 0) {
				for (ArenaNpc npc: npcList) {
					PlayerRankDto d = PlayerRankDto.valueOf(npc.getId(), npc.getId(), 1);
					result.add(d);
				}
			}
			result.add(PlayerRankDto.valueOf(0, playerId));
			this.fillPlayerRankDto(result);
			return result;
		}		
	}
	
//	/**
//	 * 竞技场npc任务是否完成
//	 * @param playerId 玩家id
//	 * @return boolean
//	 */
//	private boolean npcTaskFinished(long playerId) {
//		int taskId = this.gameRuleService.getAmountByID(GameRuleID.ARENA_NPC_TASK_ID).intValue();
//		Task task = this.mainFeederTaskService.getTask(taskId);
//		if (task == null) {
//			return true;
//		}
//		
//		TaskStatus taskStatus = this.mainFeederTaskService.getPlayerTaskStatus(playerId, taskId);
//		return taskStatus.ordinal() >= TaskStatus.FINISHED.ordinal();
//	}
	
	/**
	 * 取得可挑战的真实玩家列表
	 * @param playerId 玩家id
	 * @return Result<List<PlayerRankDto>>
	 */
	private List<PlayerRankDto> getPlayerChallengeList(long playerId) {
		List<PlayerRankDto> rankList = new ArrayList<PlayerRankDto>(ArenaRule.CHALLENGE_LIST_COUNT);
		
		PlayerArenaVo playerArenaVo = this.getPlayerArenaVo(playerId);
		
		Lock lock = this.arenaLock.readLock();
		lock.lock();
		try {			
			int playerRank = playerArenaVo.getRank();
//			List<Integer> challengeList = ArenaRule.getRankListOfChallenge(playerRank, maxRanking.get());
			List<Integer> challengeList = this.getRankListOfChallenge(playerArenaVo);
			if (!challengeList.isEmpty()) {
				for (int i = challengeList.size() - 1; i >= 0; i --) {
					int rank = challengeList.get(i);							
					RankVo rankVo = this.rankMap.get(rank);
					if (rankVo != null) {
						PlayerRankDto pr = PlayerRankDto.valueOf(rank, rankVo.getPlayerId());
						rankList.add(pr);
					}
				}
			}
			
			//不包含自己
			if (!challengeList.contains(playerRank)) {
				PlayerRankDto pr = PlayerRankDto.valueOf(playerRank, playerId);
				rankList.add(pr);
			}
		} finally {
			lock.unlock();
		}
		
		this.fillPlayerRankDto(rankList);
		return rankList;
	}
	
	/**
	 * 取得可挑战的排名列表
	 * @param playerArenaVo PlayerArenaVo
	 * @return List<Integer>
	 */
	private List<Integer> getRankListOfChallenge(PlayerArenaVo playerArenaVo) {
		int maxRank = maxRanking.get();
		
		//未上榜且排名已满
		if (maxRank == ArenaRule.MAX_RANKING_COUNT && playerArenaVo.getRank() <= 0) {
			if (playerArenaVo.getMaxRank() > 0) {
				maxRank = playerArenaVo.getMaxRank();
			}
		}
		
		return ArenaRule.getRankListOfChallenge(playerArenaVo.getRank(), maxRank);
	}
	
	/**
	 * 填充玩家排名信息dto
	 * @param pr PlayerRankDto
	 */
	private void fillPlayerRankDto(PlayerRankDto pr) {
		Player player = this.dbCachedService.get(pr.getPlayerId(), Player.class);
		if (player == null) {
			return;
		}
		
		pr.setPlayerName(player.getPlayerName());
		pr.setLevel(player.getLevel());
		pr.setJobId(player.getJobId());
		pr.setHeadId(player.getHeadId());
	}
	
	/**
	 * 填充玩家排名信息dto
	 * @param rankList List<PlayerRankDto>
	 */
	private void fillPlayerRankDto(List<PlayerRankDto> rankList) {
		for (PlayerRankDto pr: rankList) {
			if (pr.getType() == 0) {
				this.fillPlayerRankDto(pr);
			}			
		}
	}
	
	/**
	 * 取得玩家竞技场VO
	 * @param playerId 玩家id
	 * @return PlayerArenaVo
	 */
	private PlayerArenaVo getPlayerArenaVo(long playerId) {
		PlayerArenaVo playerArenaVo = this.playerMap.get(playerId);
		if (playerArenaVo == null) {
			playerArenaVo = PlayerArenaVo.valueOf(playerId);
			PlayerArenaVo exists = this.playerMap.putIfAbsent(playerId, playerArenaVo);
			if (exists != null) {
				playerArenaVo = exists;
			}
		}
		
		//玩家已上榜或者榜数已满
		if (playerArenaVo.getRank() > 0 && playerArenaVo.getRank() <= ArenaRule.MAX_RANKING_COUNT 
												|| this.maxRanking.get() >= ArenaRule.MAX_RANKING_COUNT) {
			return playerArenaVo;
		}
		
		Lock lock = this.arenaLock.writeLock();
		lock.lock();
		try {
			if (playerArenaVo.getRank() > 0 && playerArenaVo.getRank() <= ArenaRule.MAX_RANKING_COUNT 
					|| this.maxRanking.get() >= ArenaRule.MAX_RANKING_COUNT) {
				return playerArenaVo;
			}
			
			int playerRank = this.maxRanking.incrementAndGet();
			playerArenaVo.setRank(playerRank);
			
			RankVo rankVo = RankVo.valueOf(playerRank, playerId);
			RankVo existRank = this.rankMap.put(playerRank, rankVo);
			if (existRank != null) {
				logger.error("竞技场排名错乱[rank: {}]", playerRank);
			}
		} finally {
			lock.unlock();
		}
		return playerArenaVo; 
	}
	
	@Override
	public Result<String> challenge(long playerId, int rank) {
		return this.challenge(playerId, false, rank);
	}
	
	@Override
	public Result<String> challengeNpc(long playerId, int npcId) {
		return this.challenge(playerId, true, npcId);
	}

	/**
	 * 发起挑战
	 * @param playerId 玩家id
	 * @param isChallengeNpc 是否挑战npc
	 * @param rankOrNpcId 名次或者npcId
	 * @return Result
	 */
	private Result<String> challenge(long playerId, boolean isChallengeNpc, int rankOrNpcId) {
		int resultCode = heroService.checkPlayerBattleAttr(playerId, false);
		if (resultCode != ArenaResult.SUCCESS) {
			return Result.Error(resultCode); 
		}
		
		Player player = this.dbCachedService.get(playerId, Player.class);
		PlayerArena playerArena = this.getPlayerArena(playerId);
		if (player == null || playerArena == null) {
			return Result.Error(ArenaResult.PLAYER_NOT_EXISTS);
		}

		ChainLock chainLock = LockUtils.getLock(player);
		chainLock.lock();
		try {
			if (playerArena.getNextChallengeTime() > System.currentTimeMillis()) {
				return Result.Error(ArenaResult.CHALLENGE_CD_LIMIT); 
			}
			
			//可以挑战的总次数
			int totalChallengeCount = this.gameRuleService.getAmountByID(GameRuleID.ARENA_CHALLENGE_COUNT).intValue();
			totalChallengeCount += (playerArena.getBuyCount() + playerArena.getPreLeftBuyCount());
			if (playerArena.getChallengeCount() >= totalChallengeCount) {
				return Result.Error(ArenaResult.CHALLENGE_COUNT_LIMIT);
			}
			//预加冷却时间
			playerArena.setNextChallengeTime(System.currentTimeMillis() + 120000);	
		} finally {
			chainLock.unlock();
		}
		
		ValueResultSet valueResultSet = null;		
		//进行挑战
		Result<String> result = null;
		if (isChallengeNpc) {
			int npcId = rankOrNpcId;
			result = doChallengeNpc(playerId, npcId);
		} else {
			int rank = rankOrNpcId;
			result = doChallenge(playerId, rank);
		}
				
		//挑战是否正常完成
		boolean success = (Integer) result.get(Result.CODE) == ArenaResult.SUCCESS;
		PlayerArenaVo playerArenaVo = null;
		if (success) {
			playerArenaVo = this.getPlayerArenaVo(playerId);
		}
		
		long cd = this.gameRuleService.getAmountByID(GameRuleID.ARENA_CHALLENGE_CD).intValue();
		long maxCd = this.gameRuleService.getAmountByID(GameRuleID.ARENA_MAX_CD).intValue();
		
		//挑战方连胜数
		int playerWins = 0;
		//挑战是否胜利
		boolean isWin = false;
		chainLock = LockUtils.getLock(player);
		chainLock.lock();
		try {
			if (success) {
				playerArena.setChallenged(1);
				playerArena.setChallengeCount(playerArena.getChallengeCount() + 1);
				
				//上次的cd持续时间
				long cdPersistTime = playerArena.getChallengeTime() + playerArena.getCdTime();
				//当前挑战时间
				long challengeTime = System.currentTimeMillis();
				//当前累计cd
				long cdTime = cd;
				if (cdPersistTime > challengeTime) {//之前还有累计cd时间
					cdTime = cdPersistTime - challengeTime + cd;
				}
				playerArena.setChallengeTime(challengeTime);
				playerArena.setCdTime(cdTime);
				
				if (cdTime >= maxCd) {//达到最大累计时间
					long nextChallengeTime = challengeTime + cdTime;
					playerArena.setNextChallengeTime(nextChallengeTime);
				} else {
					playerArena.setNextChallengeTime(0L);
				}
				
				//挑战是否胜利
				isWin = result.get("isWin") != null && ((Integer)result.get("isWin")) == 1;
				if (isWin) {
					playerArena.setWins(playerArena.getWins() + 1);
					Integer currRank = (Integer) result.get("currRank");
					if (currRank != null) {
						if (playerArena.getTopRank() <= 0 || playerArena.getTopRank() > 0 && currRank < playerArena.getTopRank()) {
							playerArena.setTopRank(currRank);
						}
					}
					playerWins = playerArena.getWins();
				} else {
					playerWins = playerArena.getWins();
					playerArena.setWins(0);
				}
				
				//功勋奖励
				int fame = this.gameRuleService.getAmountByID(isWin ? GameRuleID.ARENA_CHALLENGE_WIN_FAME : GameRuleID.ARENA_CHALLENGE_LOSE_FAME).intValue();
				SimpleReward fameReward = new SimpleReward(RewardType.EXPLOIT, Math.abs(fame));
				RewardActionSet rewardActionSet = this.rewardService.tryRewards(playerId, fameReward);
				if (rewardActionSet.isNotOK()) {
					playerArena.setNextChallengeTime(0L);
					return Result.Error(rewardActionSet.getResultCode());
				}				
				valueResultSet = this.rewardService.executeRewards(playerId, rewardActionSet, LogSource.ARENA_CHALLENGE);
				
				//翻牌奖励
				playerArenaVo.getRewards().clear();
				playerArenaVo.setTurn(false);
				ArenaCard arenaCard = this.arenaRuleService.getRandomCards();
				if (arenaCard != null) {
					List<Reward> rewards = this.rewardService.parseRewards(playerId, arenaCard.getReward(), false);
					if (rewards != null && !rewards.isEmpty()) {
						playerArenaVo.getRewards().addAll(rewards);
					}
				}
				
				//当未上榜且榜单已满， 取可挑战列表时需要随机
				if (playerArenaVo.getRank() <= 0 && maxRanking.get() == ArenaRule.MAX_RANKING_COUNT) {
					int randomSeed = ArenaRule.LAST_RANKING_RANDOM_SEED;
					int maxRank = ArenaRule.MAX_RANKING_COUNT - RandomUtil.nextInt(randomSeed);
					playerArenaVo.setMaxRank(maxRank);					
				} else {
					playerArenaVo.setMaxRank(0);
				}
				
			} else {
				playerArena.setNextChallengeTime(0L);				
				return result;
			}
		} finally {
			chainLock.unlock();
		}
	
		result.addContent("valueResultSet", valueResultSet);		
		ChallengeDto challengeDto = (ChallengeDto) result.remove("challengeDto");
		
		//被挑战方连胜数
		int rivalWins = 0;
		long aimPlayerId = challengeDto.getRivalId();
		if (!isChallengeNpc) {			
			Player aimPlayer = this.dbCachedService.get(aimPlayerId, Player.class);
			PlayerArena aimPlayerArena = this.getPlayerArena(aimPlayerId);
			if (aimPlayer != null && aimPlayerArena != null) {
				chainLock = LockUtils.getLock(aimPlayer);
				chainLock.lock();
				try {
					//挑战胜利
					if (isWin) {
						rivalWins = aimPlayerArena.getWins();
						aimPlayerArena.setWins(0);
					} else {
						aimPlayerArena.setWins(aimPlayerArena.getWins() + 1);
						rivalWins = aimPlayerArena.getWins();
					}
				}  finally {
					chainLock.unlock();
				}
				
				if (isWin) {
					this.slaveService.addLoser(playerId, aimPlayerId);
				}
			}
		}
		
		//处理挑战记录
		this.doChallengeRecord(challengeDto);		
		this.dbCachedService.submitUpdated2Queue(playerArena.getId(), PlayerArena.class);
		
		if (!isChallengeNpc) {
			this.dbCachedService.submitUpdated2Queue(aimPlayerId, PlayerArena.class);
		}		
		
		this.doAnnounce(challengeDto, playerWins, rivalWins);
		this.taskBus.post(ArenaEvent.valueOf(playerId, isWin));
		return result;
	}
	
	/**
	 * 公告处理
	 * @param challengeDto ChallengeDto
	 * @param playerWins 挑战方连胜数
	 * @param rivalWins 被挑战方连胜数
	 */
	private void doAnnounce(ChallengeDto challengeDto, int playerWins, int rivalWins) {
		if (challengeDto == null) {
			return;
		}
		
		if (challengeDto.isChallengeNpc()) {
			return;
		}
		
		//挑战成功
		if (challengeDto.isChallengeWin()) {			
			doChallengeWinAnnounce(challengeDto.getPlayerName(), playerWins, challengeDto.getRivalName(), rivalWins);
			
		} else {//挑战失败
			doChallengeWinAnnounce(challengeDto.getRivalName(), rivalWins, challengeDto.getPlayerName(), playerWins);
		}
	}
	
	/**
	 * 挑战成功公告
	 * @param playerName 胜利方名
	 * @param playerWins 胜利方连胜数
	 * @param rivalName 失败方名
	 * @param rivalWinsBefore 失败方之前连胜数
	 */
	private void doChallengeWinAnnounce(String playerName, int playerWins, String rivalName, int rivalWinsBefore) {
		int noticeId = 0;
		if (playerWins == 10) {
			noticeId = NoticeId.ARENA_WINS_TEN;
		} else if (playerWins == 20) {
			noticeId = NoticeId.ARENA_WINS_TWENTY;
		} else if (playerWins >= 30 && playerWins % 10 == 0) {
			noticeId = NoticeId.ARENA_WINS_THIRTY;
		}
		
		if (noticeId > 0) {
			challengeAnnounce(noticeId, playerName, rivalName, playerWins);
		}
		
		if (rivalWinsBefore >= 10) {
			noticeId = NoticeId.ARENA_WINS_END;
			challengeAnnounce(noticeId, playerName, rivalName, rivalWinsBefore);
		}
	}
	
	/**
	 * 挑战公告
	 * @param noticeId
	 * @param playerName1
	 * @param playerName2
	 * @param wins
	 */
	private void challengeAnnounce(int noticeId, String playerName1, String playerName2, int wins) {
		Map<String, Object> values = new HashMap<String, Object>();
		values.put(NoticeKey.PLAYERNAME1, playerName1);
		values.put(NoticeKey.PLAYERNAME2, playerName2);
		values.put(NoticeKey.NUMBER_1, wins);
		NoticeDto noticeDto = NoticeDto.valueOf(noticeId, values);
		this.noticeService.pushNotice(-1L, noticeDto);
	}
	
	/**
	 * 处理挑战记录
	 * @param challengeDto ChallengeDto
	 */
	private void doChallengeRecord(ChallengeDto challengeDto) {
		if (challengeDto == null) {
			return;
		}

		long playerId = challengeDto.getPlayerId();
		Player player = this.dbCachedService.get(playerId, Player.class);
		if (player != null) {
			challengeDto.setPlayerName(player.getPlayerName());
		}
		long aimPlayerId = challengeDto.getRivalId();
		if (!challengeDto.isChallengeNpc()) {			
			Player aimPlayer = this.dbCachedService.get(aimPlayerId, Player.class);
			if (aimPlayer != null) {
				challengeDto.setRivalName(aimPlayer.getPlayerName());
			}
		}
			
		Map<String, Object> pushMap = new HashMap<String, Object>();
	
		if (!challengeDto.isChallengeNpc()) {
			pushMap.put("type", 1);
			pushMap.put("challengeDto", challengeDto);
			this.pushHelper.push(playerId, Module.ARENA, ArenaCmd.PUSH_CHALLENGE, pushMap);
			this.addChallengeHis(playerId, challengeDto);
			
			this.pushHelper.push(aimPlayerId, Module.ARENA, ArenaCmd.PUSH_CHALLENGE, pushMap);
			this.addChallengeHis(aimPlayerId, challengeDto);
		}
		
		//第一名争夺
		if (challengeDto.getRivalRankBefore() == 1 && challengeDto.isChallengeWin()) {
			FirstRankDto firstRankDto = FirstRankDto.valueOf(challengeDto);
			pushMap = new HashMap<String, Object>();
			pushMap.put("type", 0);
			pushMap.put("firstRankDto", firstRankDto);
			this.pushHelper.pushAll(Module.ARENA, ArenaCmd.PUSH_CHALLENGE, pushMap);
			
			this.addFirstRank(firstRankDto);
		}
	}
	
	/**
	 * 添加个人挑战历史记录
	 * @param playerId 玩家id
	 * @param challengeDto ChallengeDto
	 */
	private void addChallengeHis(long playerId, ChallengeDto challengeDto) {
		Player player = this.dbCachedService.get(playerId, Player.class);
		PlayerArena playerArena = this.getPlayerArena(playerId);
		if (player == null || playerArena == null) {
			return;
		}
		
		int hisCount = ArenaRule.ARENA_CHALLENGE_HIS_COUNT;
		
		ChainLock chainLock = LockUtils.getLock(player);
		chainLock.lock();
		try {
			List<ChallengeDto> challengeList = playerArena.getChallengeList();
			while (!challengeList.isEmpty() && challengeList.size() >= hisCount) {
				challengeList.remove(challengeList.size() - 1);
			}
			if (challengeList.isEmpty()) {
				challengeList.add(challengeDto);
			} else {
				challengeList.add(0, challengeDto);
			}			
			playerArena.setChallengeHis(JsonUtils.object2JsonString(challengeList));
		} finally {
			chainLock.unlock();
		}
	}
	
	/**
	 * 添加第一名挑战历史记录
	 * @param firstRankDto FirstRankDto
	 */
	private void addFirstRank(FirstRankDto firstRankDto) {
		int hisCount = ArenaRule.ARENA_CHALLENGE_HIS_COUNT;
		List<FirstRankDto> hisList = null;
		
		ArenaInfo ai = this.getArenaFirstRankInfo();
		synchronized(ai) {
			if (StringUtils.isNotBlank(ai.getInfo())) {
				TypeReference<List<FirstRankDto>> valueTypeRef = new TypeReference<List<FirstRankDto>>() {};
				hisList = JsonUtils.jsonString2Object(ai.getInfo(), valueTypeRef);
			}
			
			if (hisList == null) {
				hisList = new ArrayList<FirstRankDto>();
			} else if (hisList.size() >= hisCount) {
				Collections.sort(hisList);
				while (!hisList.isEmpty() && hisList.size() >= hisCount) {
					hisList.remove(hisList.size() - 1);
				}
			}
			
			hisList.add(firstRankDto);
			ai.setInfo(JsonUtils.object2JsonString(hisList));
		}
		
		this.dbCachedService.submitUpdated2Queue(ai.getId(), ArenaInfo.class);
	}
	
	/**
	 * 处理玩家之间的挑战
	 * @param playerId 玩家id
	 * @param aimRank 挑战名次
	 * @return Result<String>
	 */
	private Result<String> doChallenge(long playerId, int aimRank) {
		if (!this.rankMap.containsKey(aimRank)) {
			return Result.Error(ArenaResult.RANK_NOT_EXISTS);
		}
		
		PlayerArenaVo playerArenaVo = this.getPlayerArenaVo(playerId);
		//不可挑战该名次
		if (!this.canChallengeRank(playerId, aimRank)) {
			return Result.Error(ArenaResult.CANNOT_CHALLENGE_RANK);
		}
		ChallengeDto challengeDto = new ChallengeDto();
		//当前排名
		int currRank = 0;
		//目标玩家id
		long aimPlayerId = 0L;
		//战斗是否可以进行
		boolean battleContinue = false;
		
		//不可能循环这么多次
		for (int i = 0; i < 20000; i ++) {
			//两个名次是否正在被挑战
			boolean isChallenged = this.isRankChallenged(playerArenaVo.getRank()) || this.isRankChallenged(aimRank);
			if (!isChallenged) {
				Lock lock = this.arenaLock.writeLock();
				lock.lock();
				try {
					//不可挑战该名次
					if (!this.canChallengeRank(playerId, aimRank)) {
						return Result.Error(ArenaResult.CANNOT_CHALLENGE_RANK);
					}
					//是否正在挑战中
					isChallenged = this.isRankChallenged(playerArenaVo.getRank()) || this.isRankChallenged(aimRank);
					if (!isChallenged) {
						currRank = playerArenaVo.getRank();
						
						RankVo aimRankVo = this.rankMap.get(aimRank);
						if (aimRankVo == null) {//不可能为空
							return Result.Error(ArenaResult.FAILURE);
						}
						
						RankVo playerRankVo = this.rankMap.get(currRank);
						if (playerRankVo != null) {//如果为空,则为未上榜
							playerRankVo.setChallenged(true);
						}
						
						aimPlayerId = aimRankVo.getPlayerId();						
						aimRankVo.setChallenged(true);
						
						battleContinue = true;						
						challengeDto.set(playerId, currRank, aimPlayerId, aimRank, System.currentTimeMillis());
						break;
					}					
				} finally {
					lock.unlock();
				}
			}
			if (isChallenged) {
				try {
					Thread.sleep(5);
				} catch (Exception ex) {
					logger.error(ex.getMessage(), ex);
				}
			}
		}
		
		if (!battleContinue) {
			return Result.Error(ArenaResult.FAILURE);
		}
		
		int resultCode = ArenaResult.FAILURE;
		//挑战方
		List<List<BattleCharacter>> attackerUnits = null;
		//战斗结果
		List<BattleResult> battleResults = null;
		boolean attackWin = false;
		try {
			//挑战方真实数据
			Player player = this.dbCachedService.get(playerId, Player.class);
			BattlePlayerInfo attackerBpi = new BattlePlayerInfo(player);
			attackerUnits = playerService.getMultiPlayerBattleCharacter(playerId, BattleWaveID.ARENA, false);
			
			List<BattleGroup> offenseGroups = new ArrayList<BattleGroup>();
			for (List<BattleCharacter> userUnit : attackerUnits) {
				BattleGroup offenseGroup = new BattleGroup(BattleTeam.OFFENSE_TEAM, userUnit, attackerBpi, 0);
				offenseGroups.add(offenseGroup);
			}
			
			//被挑战方镜像
			Player aimPlayer = this.dbCachedService.get(aimPlayerId, Player.class);
			BattlePlayerInfo defenderBpi = new BattlePlayerInfo(aimPlayer);
			List<List<BattleCharacter>> defenderUnits = playerService.getMultiUserBattleCharacter(aimPlayerId, BattleWaveID.ARENA);
					
			List<BattleGroup> defenseGroups = new ArrayList<BattleGroup>();
			for (List<BattleCharacter> userUnit : defenderUnits) {
				BattleGroup defenseGroup = new BattleGroup(BattleTeam.DEFENSE_TEAM, userUnit, defenderBpi, 0);
				defenseGroups.add(defenseGroup);
			}
			
			// PVP的时候血量翻倍
			double increase = 1.0;
			for (BattleGroup battleGroup : defenseGroups) {// 防守方
				List<BattleCharacter> battleCharacters = battleGroup.getAliveCharacters();
				if (CollectionUtils.isNotEmpty(battleCharacters)) {
					for (BattleCharacter battleCharacter : battleCharacters) {
						battleCharacter.increaseHpBuffAttr(increase);
					}
				}
			}
			for (BattleGroup battleGroup : offenseGroups) {// 攻击方
				List<BattleCharacter> battleCharacters = battleGroup.getAliveCharacters();
				if (CollectionUtils.isNotEmpty(battleCharacters)) {
					for (BattleCharacter battleCharacter : battleCharacters) {
						battleCharacter.increaseHpBuffAttr(increase);
					}
				}
			}
			
			MultiBattleResult multiBattleResult = battleService.multiWaveBattle(BattleType.PVP, offenseGroups, defenseGroups, true);
			battleResults = multiBattleResult.getBattleResults();
			//是否胜利
			attackWin = multiBattleResult.getWinner().equals(BattleWinner.OFFENSE_TEAM);			
			resultCode = ArenaResult.SUCCESS;
		} finally {
			Lock lock = this.arenaLock.writeLock();
			lock.lock();
			try {
				currRank = playerArenaVo.getRank();
				RankVo playerRankVo = this.rankMap.get(currRank);
				RankVo aimRankVo = this.rankMap.get(aimRank);
				
				if (!aimRankVo.isChallenged()) {
					return Result.Error(ArenaResult.FAILURE);
				}				
				if (playerRankVo != null && !playerRankVo.isChallenged()) {
					return Result.Error(ArenaResult.FAILURE);
				}
				
				if (attackWin) {
					//排后面才需要换
					if (currRank <= 0 || currRank > aimRank) {
						//交换排名
						if (playerRankVo != null) {
							playerRankVo.setPlayerId(aimPlayerId);
						}					
						aimRankVo.setPlayerId(playerId);
						playerArenaVo.setRank(aimRank);
						PlayerArenaVo aimPlayerArenaVo = this.getPlayerArenaVo(aimPlayerId);
						aimPlayerArenaVo.setRank(currRank);
						challengeDto.set(aimRank, currRank, attackWin);
						currRank = aimRank;
					} else {
						challengeDto.setChallengeWin(attackWin);
					}				
				}

				if (playerRankVo != null) {
					playerRankVo.setChallenged(false);
				}				
				aimRankVo.setChallenged(false);	
			} finally {
				lock.unlock();
			}
		}

		Result<String> result = Result.ValueOf(resultCode, "");
		
		if (resultCode == ArenaResult.SUCCESS) {
			//扣减玩家兵力数量
			for (List<BattleCharacter> userUnit : attackerUnits) {
				heroService.reduceSoldiers(playerId, userUnit);
			}
			
			result.addContent("battleResult", battleResults);
			result.addContent("isWin", attackWin ? 1 : 0);
			result.addContent("currRank", currRank);
			result.addContent("challengeDto", challengeDto);
		}
		return result;
	}
	
	/**
	 * 是否可以挑战排名
	 * @param playerId 玩家id
	 * @param rank 挑战名次
	 * @return boolean
	 */
	private boolean canChallengeRank(long playerId, int rank) {
		PlayerArenaVo playerArenaVo = this.getPlayerArenaVo(playerId);
		if ((playerArenaVo.getRank() > ArenaRule.CHALLENGE_LIST_COUNT || rank > ArenaRule.CHALLENGE_LIST_COUNT)
				&& playerArenaVo.getRank() > 0 && playerArenaVo.getRank() <= rank) {
			return false;
		}
		//可挑战排名列表
//		List<Integer> challengeList = ArenaRule.getRankListOfChallenge(playerArenaVo.getRank(), this.maxRanking.get());
		List<Integer> challengeList = this.getRankListOfChallenge(playerArenaVo);
		return challengeList.contains(rank);
	}
	
	/**
	 * 名次是否正在被挑战
	 * @param rank 名次
	 * @return boolean
	 */
	private boolean isRankChallenged(int rank) {
		RankVo rankVo = this.rankMap.get(rank);
		return rankVo != null && rankVo.isChallenged();
	}
	
	/**
	 * 挑战npc
	 * @param playerId 玩家id
	 * @param npcId NPC ID
	 * @return Result
	 */
	private Result<String> doChallengeNpc(long playerId, int npcId) {
		ArenaNpc npc = this.arenaRuleService.getArenaNpc(npcId);
		if (npc == null) {
			return Result.Error(ArenaResult.BASE_DATA_NOT_EXIST);
		}
		
		int currRank = 0;
		PlayerArenaVo playerArenaVo = this.playerMap.get(playerId);
		if (playerArenaVo != null) {
			currRank = playerArenaVo.getRank();
		}
		
		ChallengeDto challengeDto = new ChallengeDto();
		challengeDto.set(playerId, currRank, npcId, 0, System.currentTimeMillis());
		challengeDto.setChallengeNpc(true);
		challengeDto.setRivalName(npc.getName());
		
		//挑战方真实数据
		Player player = this.dbCachedService.get(playerId, Player.class);
		BattlePlayerInfo attackerBpi = new BattlePlayerInfo(player);
		List<List<BattleCharacter>> attackerUnits = playerService.getMultiPlayerBattleCharacter(playerId, BattleWaveID.ARENA, false);
		
		List<BattleGroup> offenseGroups = new ArrayList<BattleGroup>();
		for (List<BattleCharacter> userUnit : attackerUnits) {
			BattleGroup offenseGroup = new BattleGroup(BattleTeam.OFFENSE_TEAM, userUnit, attackerBpi, 0);
			offenseGroups.add(offenseGroup);
		}
		
		//被挑战方镜像
		List<BattleCharacter> defenderUnit = this.chapterRuleService.armyToFightUnit(npc.getArmy());		
		double npcAbility = this.chapterRuleService.armyToFightAbility(npc.getArmy());
		
		BattleGroup defenseGroup = new BattleGroup(BattleTeam.DEFENSE_TEAM, defenderUnit, new BattlePlayerInfo(npc.getName(), npc.getLevel(), npc.getPic(), npcAbility), 0);
		List<BattleGroup> defenseGroups = new ArrayList<BattleGroup>();
		defenseGroups.add(defenseGroup);
		
		MultiBattleResult multiBattleResult = battleService.multiWaveBattle(BattleType.PVE, offenseGroups, defenseGroups, true);
		//战斗结果
		List<BattleResult> battleResults = multiBattleResult.getBattleResults();
		//是否胜利
		boolean attackWin = multiBattleResult.getWinner().equals(BattleWinner.OFFENSE_TEAM);
		
		//扣减玩家兵力数量
		for (List<BattleCharacter> userUnit : attackerUnits) {
			heroService.reduceSoldiers(playerId, userUnit);
		}		
		
		//挑战成功
		if (attackWin) {
			//加入竞技场
			playerArenaVo = this.getPlayerArenaVo(playerId);
			currRank = playerArenaVo.getRank();
			challengeDto.set(currRank, 0, attackWin);
		}
				
		Result<String> result = Result.Success("");
		result.addContent("battleResult", battleResults);
		result.addContent("isWin", attackWin ? 1 : 0);
		result.addContent("currRank", currRank);
		result.addContent("challengeDto", challengeDto);
		return result;
	}
	
	@Override
	public Result<String> turnCard(long playerId, boolean useGold) {
		Player player = this.dbCachedService.get(playerId, Player.class);
		if (player == null) {
			return Result.Error(ArenaResult.PLAYER_NOT_EXISTS);
		}
		
		PlayerArenaVo playerArenaVo = this.getPlayerArenaVo(playerId);
		//翻牌
		Reward fetchReward = null;
		//剩余的
		List<Reward> leftRewards = null;
		ValueResultSet valueResultSet = null;
		//vip节省值
		int vipSaved = 0;
		Result<String> result = Result.Success("");
		
		ChainLock chainLock = LockUtils.getLock(player);
		chainLock.lock();
		try {
			if (playerArenaVo.getRewards().isEmpty()) {
				return Result.Error(ArenaResult.NO_CARD);
			}
			if (playerArenaVo.isTurn() && !useGold) {
				return Result.Error(ArenaResult.CARD_REWARDED);
			}
			
			List<Reward> rewards = new ArrayList<Reward>();
			if (useGold) {
				int orignCost = this.gameRuleService.getGoldById(GoldRuleID.ARENA_CARD_FETCH_ALL);
				int cost = vipService.getGoldDiscountValue(player, orignCost);
				vipSaved = orignCost - cost;
				SimpleReward goldReward = SimpleReward.valueOf(RewardType.MONEY_MIX, cost);
				rewards.add(goldReward);
				rewards.addAll(playerArenaVo.getRewards());
			} else {
				leftRewards = playerArenaVo.getRewards();
				fetchReward = leftRewards.get(RandomUtil.nextInt(leftRewards.size()));
				rewards.add(fetchReward);
			}
			
			RewardActionSet rewardActionSet = this.rewardService.tryRewards(playerId, rewards);
			if (rewardActionSet.isNotOK()) {
				return Result.Error(rewardActionSet.getResultCode());
			}
			
			valueResultSet = this.rewardService.executeRewards(playerId, rewardActionSet, LogSource.ARENA_TURN_CARD);
			
			if (useGold) {
				result.addContent("rewarded", RewardHelper.toRewardString(playerArenaVo.getRewards()));
				playerArenaVo.getRewards().clear();
			} else {
				leftRewards.remove(fetchReward);
			}
			playerArenaVo.setTurn(true);
		} finally {
			chainLock.unlock();
		}

		result.addContent("valueResultSet", valueResultSet);
		
		if (fetchReward != null) {
			result.addContent("rewarded", fetchReward.toRewardString());
		}
		if (leftRewards != null) {
			result.addContent("unRewarded", RewardHelper.toRewardString(leftRewards));
		}
		if (vipSaved != 0) {
			result.addContent("vipSaved", vipSaved);
		}
		return result;
	}

	@Override
	public Result<String> eliminateCd(long playerId) {
		Player player = this.dbCachedService.get(playerId, Player.class);
		PlayerArena playerArena = this.getPlayerArena(playerId);
		if (player == null || playerArena == null) {
			return Result.Error(ArenaResult.PLAYER_NOT_EXISTS);
		}
		
		//折扣
		double clearArenaCoolTime = 1;
		//正式vip
		Vip vip = basedbService.get(Vip.class, player.getOnlyVipLevel());
		if (vip != null) {
			clearArenaCoolTime = vip.getClearArenaCoolTime();
		}
		
		//vip节省值
		int vipSaved = 0;
		
		ValueResultSet valueResultSet = null;
		
		ChainLock chainLock = LockUtils.getLock(player);
		chainLock.lock();
		try {
			long currTime = System.currentTimeMillis();
			long cdPersistTime = playerArena.getChallengeTime() + playerArena.getCdTime();
			if (cdPersistTime <= currTime) {
				return Result.Error(ArenaResult.NO_CHALLENGE_CD);
			}
			
			//多少分钟
//			int minutes = (int) Math.ceil((cdPersistTime - currTime) / (double) 60000) ;
//			int orignCost = this.gameRuleService.getGoldById(GoldRuleID.ARENA_ELIMINATE_CD) * minutes;
			int orignCost = this.gameRuleService.getGoldById(GoldRuleID.ARENA_ELIMINATE_CD);
			int cost = (int) vipService.getVipValue(orignCost, clearArenaCoolTime);
			vipSaved = orignCost - cost;
			if (cost != 0) {
				SimpleReward goldReward = SimpleReward.valueOf(RewardType.MONEY_MIX, cost);
				RewardActionSet rewardActionSet = this.rewardService.tryRewards(playerId, goldReward);
				if (rewardActionSet.isNotOK()) {
					return Result.Error(rewardActionSet.getResultCode());
				}
				
				valueResultSet = this.rewardService.executeRewards(playerId, rewardActionSet, LogSource.ARENA_ELIMINATE_CD);
			}
			
			playerArena.setNextChallengeTime(0L);
			playerArena.setCdTime(0L);
		} finally {
			chainLock.unlock();
		}
		
		Result<String> result = Result.Success("");
		if (valueResultSet != null) {
			result.addContent("valueResultSet", valueResultSet);
		}		
		result.addContent("playerArenaDto", PlayerArenaDto.valueOf(playerArena));
		result.addContent("vipSaved", vipSaved);
		return result;
	}

	@Override
	public Result<String> buyCount(long playerId, int count) {
		Player player = this.dbCachedService.get(playerId, Player.class);
		PlayerArena playerArena = this.getPlayerArena(playerId);
		if (player == null || playerArena == null) {
			return Result.Error(ArenaResult.PLAYER_NOT_EXISTS);
		}
		
		Vip vip = this.basedbService.get(Vip.class, player.getOnlyVipLevel());
		if (vip == null) {
			return Result.Error(ArenaResult.VIP_LEVEL_NO_ENOUGH);
		}
		
		if (count < 1) {
			count = 1;
		}
		//vip节省值
		int vipSaved = 0;
		//实际购买次数
		int realCount = 0;
		ValueResultSet valueResultSet = null;
		
		ChainLock chainLock = LockUtils.getLock(player);
		chainLock.lock();
		try {
			if (playerArena.getBuyCount() >= vip.getArenaCount()) {
				return Result.Error(ArenaResult.BUY_COUNT_LIMIT);
			}
			
			int costGold = 0;
			for (int i = 1; i <= count; i ++) {
				int currCount = playerArena.getBuyCount() + i;				
				int orignCost = this.formulaHelper.invoke(FormulaID.ARENA_BUY_COUNT, currCount).intValue();
				int cost = vipService.getGoldDiscountValue(player, orignCost);
				int totalCost = costGold + cost;
				SimpleReward goldReward = SimpleReward.valueOf(RewardType.MONEY_MIX, totalCost);
				RewardActionSet rewardActionSet = this.rewardService.tryRewards(playerId, goldReward);
				if (rewardActionSet.isNotOK()) {
					if (costGold == 0) {
						return Result.Error(rewardActionSet.getResultCode());
					} else {
						break;
					}					
				}
				
				realCount = i;
				costGold = totalCost;
				vipSaved += (orignCost - cost);
				if (currCount >= vip.getArenaCount()) {
					break;
				}
			}
			
			SimpleReward goldReward = SimpleReward.valueOf(RewardType.MONEY_MIX, costGold);
			RewardActionSet rewardActionSet = this.rewardService.tryRewards(playerId, goldReward);
			if (rewardActionSet.isNotOK()) {
				return Result.Error(rewardActionSet.getResultCode());
			}
			
			valueResultSet = this.rewardService.executeRewards(playerId, rewardActionSet, LogSource.ARENA_BUY_COUNT);
			playerArena.setBuyCount(playerArena.getBuyCount() + realCount);
		} finally {
			chainLock.unlock();
		}
		
		Result<String> result = Result.Success("");
		result.addContent("valueResultSet", valueResultSet);
		result.addContent("playerArenaDto", PlayerArenaDto.valueOf(playerArena));
		result.addContent("realCount", realCount);
		result.addContent("vipSaved", vipSaved);
		return result;
	}
	
	@Override
	public Result<String> fetchBoxReward(long playerId) {
		Player player = this.dbCachedService.get(playerId, Player.class);
		PlayerArena playerArena = this.getPlayerArena(playerId);
		if (player == null || playerArena == null) {
			return Result.Error(ArenaResult.PLAYER_NOT_EXISTS);
		}
		
		ValueResultSet valueResultSet = null;
		ChainLock chainLock = LockUtils.getLock(player);
		chainLock.lock();
		try {
			if (playerArena.getBoxId() == 0) {
				return Result.Error(ArenaResult.NO_BOX);
			}
			if (playerArena.getBoxStatus() == 1) {
				return Result.Error(ArenaResult.BOX_REWARDED);
			}
			
			ArenaBox box = this.arenaRuleService.getArenaBox(playerArena.getBoxId());
			if (box == null) {
				return Result.Error(ArenaResult.BASE_DATA_NOT_EXIST);
			}
			List<Reward> rewards = new ArrayList<Reward>(20);
			List<Reward> boxRewards = this.rewardService.parseRewards(playerId, box.getRewards(), false);
			if (boxRewards != null && !boxRewards.isEmpty()) {
				for (int i = 0; i < playerArena.getBoxCount(); i ++) {
					rewards.addAll(boxRewards);
				}
			}
			
			RewardActionSet rewardActionSet = this.rewardService.tryRewards(playerId, rewards);
			if (rewardActionSet.isNotOK()) {
				return Result.Error(rewardActionSet.getResultCode());
			}
			
			valueResultSet = this.rewardService.executeRewards(playerId, rewardActionSet, LogSource.ARENA_BOX_REWARD);
			playerArena.setBoxStatus(1);
			
		} finally {
			chainLock.unlock();
		}
		this.dbCachedService.submitUpdated2Queue(playerArena.getId(), playerArena.getClass());
		
		Result<String> result = Result.Success("");
		result.addContent("valueResultSet", valueResultSet);
		return result;
	}
	
	@Override
	public Result<PlayerDto> spy(long playerId, long spyPlayerId) {
		Player player = this.dbCachedService.get(playerId, Player.class);
		Player spyPlayer = this.dbCachedService.get(spyPlayerId, Player.class);
		if (player == null || spyPlayer == null) {
			return Result.Error(ArenaResult.PLAYER_NOT_EXISTS);
		}
		
		ValueResultSet valueResultSet = null;
		//侦查消耗
		int orignCost = this.gameRuleService.getGoldById(GoldRuleID.ARENA_SPY);
		int cost = 0;
		if (orignCost > 0) {
			cost = vipService.getGoldDiscountValue(player, orignCost);
			ChainLock chainLock = LockUtils.getLock(player);
			chainLock.lock();
			try {
				SimpleReward goldReward = SimpleReward.valueOf(RewardType.MONEY_MIX, cost);
				RewardActionSet rewardActionSet = this.rewardService.tryRewards(playerId, goldReward);
				if (rewardActionSet.isNotOK()) {
					return Result.Error(rewardActionSet.getResultCode());
				}
				
				valueResultSet = this.rewardService.executeRewards(playerId, rewardActionSet, LogSource.ARENA_SPY);			
			} finally {
				chainLock.unlock();
			}
		}
		
		//vip节省值
		int vipSaved = orignCost - cost;
		
		Result<PlayerDto> result = this.playerService.spyIntoPlayerBattleLineup(spyPlayerId);
		result.addContent("valueResultSet", valueResultSet);
		result.addContent("vipSaved", vipSaved);
		return result;
	}

	@Override
	public List<PlayerRankDto> getRankList() {
		int count = 20;
		List<PlayerRankDto> result = new ArrayList<PlayerRankDto>(count);
		
		Lock lock = this.arenaLock.readLock();
		lock.lock();
		try {
			for (int rank = 1; rank <= count; rank ++) {
				RankVo rankVo = this.rankMap.get(rank);
				if (rankVo != null) {
					PlayerRankDto pr = PlayerRankDto.valueOf(rank, rankVo.getPlayerId());
					result.add(pr);
				}
			}
		} finally {
			lock.unlock();
		}
		
		this.fillPlayerRankDto(result);
		return result;
	}

	@Override
	public void playerLogout(long playerId) {
		PlayerArenaVo playerArenaVo = this.playerMap.get(playerId);
		if (playerArenaVo == null) {
			return;
		}
		
		//上榜
		if (playerArenaVo.getRank() > 0 && playerArenaVo.getRank() <= ArenaRule.MAX_RANKING_COUNT) {
			return;
		}
		
		Lock lock = this.arenaLock.writeLock();
		lock.lock();
		try {
			//上榜
			if (playerArenaVo.getRank() > 0 && playerArenaVo.getRank() <= ArenaRule.MAX_RANKING_COUNT) {
				return;
			}
			
			//未上榜则删除
			this.playerMap.remove(playerId);			
		} finally {
			lock.unlock();
		}
	}
	
	@Override
	public Result<String> getDayRankReward(long playerId, int day, int rank) {
		Player player = this.dbCachedService.get(playerId, Player.class);
		if (player == null) {
			return Result.Error(ArenaResult.PLAYER_NOT_EXISTS);
		}
		
		ArenaDayRankReward dayRankReward = this.dbCachedService.get(day, ArenaDayRankReward.class);
		if (dayRankReward == null) {
			return Result.Error(ArenaResult.NO_REWARD);
		}
		
		ArenaDayRank arenaDayRank = this.arenaRuleService.getArenaDayRank(day, rank);
		if (arenaDayRank == null) {
			return Result.Error(ArenaResult.BASE_DATA_NOT_EXIST);
		}
		
		ValueResultSet valueResultSet = null;
		
		ChainLock chainLock = LockUtils.getLock(player, dayRankReward);
		chainLock.lock();
		try {
			DayRankRewardVO r = dayRankReward.getRankMap().get(rank);
			if (r == null || r.getPlayerId() != playerId) {
				return Result.Error(ArenaResult.NO_REWARD);
			}
			
			if (r.getRewardStatus() == 1) {
				return Result.Error(ArenaResult.REWARD_GETTED);
			}
			
			RewardActionSet rewardActionSet = this.rewardService.tryRewards(playerId, arenaDayRank.getReward());
			if (rewardActionSet.isNotOK()) {
				return Result.Error(rewardActionSet.getResultCode());
			}
			
			valueResultSet = this.rewardService.executeRewards(playerId, rewardActionSet, LogSource.ARENA_DAY_RANK_REWARD);
			
			r.setRewardStatus(1);
			
			String dayRanks = JsonUtils.object2JsonString(dayRankReward.getRankMap().values());
			dayRankReward.setDayRanks(dayRanks == null ? "" : dayRanks);
			this.dbCachedService.submitUpdated2Queue(dayRankReward.getId(), dayRankReward.getClass());
		} finally {
			chainLock.unlock();
		}
		
		Result<String> result = Result.Success("");
		result.addContent("valueResultSet", valueResultSet);
		return result;
	}

	/**
	 * 保存日排行奖励信息
	 * @param rankPlayerMap {rank: playerId}
	 */
	private void saveDayRankRewards(Map<Integer, Long> rankPlayerMap) {
		if (rankPlayerMap == null || rankPlayerMap.isEmpty()) {
			return;
		}
		
		Date openServerTime = SysKey.SERVER_OPEN_TIME.getDate();
		if (openServerTime == null) {
			return;
		}
		
		Date now = new Date();
		//开服第几天s
		int day = DateUtil.calc2DateTDOADays(openServerTime, now);
		day = Math.abs(day) + 1;
		
		//超过最大天数
		if (day > this.arenaRuleService.getMaxDayOfDayRankReward()) {
			return;
		}
		
		ArenaDayRankReward dayRankReward = this.getArenaDayRankReward(day);
		ChainLock chainLock = LockUtils.getLock(dayRankReward);
		chainLock.lock();
		try {
			dayRankReward.getRankMap().clear();
			
			for (Entry<Integer, Long> entry: rankPlayerMap.entrySet()) {
				int rank = entry.getKey();
				long playerId = entry.getValue();
				
				if (rank > this.arenaRuleService.getMaxRankOfDayRankReward()) {
					continue;
				}
				
				DayRankRewardVO r = DayRankRewardVO.valueOf(rank, playerId);
				dayRankReward.getRankMap().put(r.getRank(), r);
			}
			
			String dayRanks = JsonUtils.object2JsonString(dayRankReward.getRankMap().values());
			dayRankReward.setDayRanks(dayRanks == null ? "" : dayRanks);
			this.dbCachedService.submitUpdated2Queue(dayRankReward.getId(), dayRankReward.getClass());			
		} finally {
			chainLock.unlock();
		}
	}
	
	/**
	 * 取得ArenaDayRankReward
	 * @param id 第几天
	 * @return ArenaDayRankReward
	 */
	private ArenaDayRankReward getArenaDayRankReward(int id) {
		ArenaDayRankReward r = this.dbCachedService.get(id, ArenaDayRankReward.class);
		if (r == null) {
			r = new ArenaDayRankReward();
			r.setId(id);
			r = this.dbCachedService.submitNew2Queue(r);
		}
		
		return r;
	}
	
	/**
	 * 定时保存排名列表
	 */
	@Scheduled(name = "竞技场排名定时保存", value = "ARENA_SAVE_RANKS", type = ValueType.BEANNAME)
	private void scheduleSaveRankList() {
		//是否成功
		boolean success = saveArenaRanks();
		if (success) {
			return;
		}
		
		//手动刷新竞技场排名
		refreshArenaRanks();
	}
	
	/**
	 * 停服前保存竞技场排名
	 */
	@LifecycleMethod(lifecycle=Lifecycle.BUSSINESS_ON_CLOSING, name="停服前保存竞技场排名")
	private void saveBeforeShutdown() {
		scheduleSaveRankList();
	}
	
	/**
	 * 保存竞技场排名
	 * @return 是否成功
	 */
	private boolean saveArenaRanks() {
		List<RankVo> ranks = null;
		//{rank: playerId}
		Map<Integer, Long> rankPlayerIdMap = null;
				
		Lock lock = this.arenaLock.readLock();
		lock.lock();
		try {
			ranks = new ArrayList<RankVo>(this.rankMap.values());
			Collections.sort(ranks);
			
			rankPlayerIdMap = new HashMap<Integer, Long>(ranks.size());
			Set<Long> playerIds = new HashSet<Long>(ranks.size());
			
			//当前排名
			int currRank = 0;
			for (RankVo rankVo: ranks) {
				currRank ++;
				if (currRank != rankVo.getRank()) {
					logger.error("【竞技场】 排名有误！");
					return false;
				}
				if (!playerIds.add(rankVo.getPlayerId())) {
					logger.error("【竞技场】 排名角色重复！");
					return false;
				}
				rankPlayerIdMap.put(currRank, rankVo.getPlayerId());
			}
		} finally {
			lock.unlock();
		}
		
		String rankString = JsonUtils.object2JsonString(rankPlayerIdMap);
		ArenaInfo ai = this.getArenaRankListInfo();
		synchronized(ai) {
			ai.setInfo(rankString);
		}		
		this.dbCachedService.submitUpdated2Queue(ai.getId(), ArenaInfo.class);
		return true;
	}

	@Override
	public void refreshArenaRanks() {
		logger.error("【竞技场】 刷新竞技场排名！");
		
		//{rank: playerId}
		Map<Integer, Long> rankPlayerIdMap = null;
		
		Lock lock = this.arenaLock.writeLock();
		lock.lock();
		try {
			List<RankVo> ranks = new ArrayList<RankVo>(this.rankMap.values());
			this.rankMap.clear();
			Collections.sort(ranks);
			
			//{rank: playerId}
			rankPlayerIdMap = new HashMap<Integer, Long>(ranks.size());
			Set<Long> playerIds = new HashSet<Long>(ranks.size());
			
			//当前排名
			int currRank = 0;
			for (RankVo rankVo: ranks) {
				long playerId = rankVo.getPlayerId();
				//角色重复
				if (!playerIds.add(playerId)) {
					continue;
				}
				
				currRank ++;
				
				//排名Map
				RankVo currRankVo = RankVo.valueOf(currRank, playerId);
				this.rankMap.put(currRank, currRankVo);
				
				//玩家Map
				PlayerArenaVo playerArenaVo = this.playerMap.get(playerId);
				if (playerArenaVo != null) {
					playerArenaVo.setRank(currRank);
				} else {
					playerArenaVo = PlayerArenaVo.valueOf(playerId, currRank);
					this.playerMap.put(playerId, playerArenaVo);
				}
				
				rankPlayerIdMap.put(currRank, playerId);
			}
			//当前最大排名
			this.maxRanking.set(currRank);
			
			for (PlayerArenaVo playerArenaVo: this.playerMap.values()) {
				int rank = playerArenaVo.getRank();
				if (rank > 0) {
					RankVo rankVo = this.rankMap.get(rank);
					if (rankVo == null || rankVo.getPlayerId() != playerArenaVo.getPlayerId()) {
						playerArenaVo.setRank(0);
					}
				}
			}			
		} finally {
			lock.unlock();
		}
		
		String rankString = JsonUtils.object2JsonString(rankPlayerIdMap);
		ArenaInfo ai = this.getArenaRankListInfo();
		synchronized(ai) {
			ai.setInfo(rankString);
		}		
		this.dbCachedService.submitUpdated2Queue(ai.getId(), ArenaInfo.class);
		
		logger.error("【竞技场】 刷新竞技场排名完成！");
	}
	
	/**
	 * 竞技场排名结算
	 */
	@Scheduled(name = "竞技场排名结算", value = "ARENA_RANK_BALANCE", type = ValueType.BEANNAME)
	private void scheduleArenaRankBalance() {
		//{rank: playerId}
		Map<Integer, Long> rankPlayerMap = null;
		
		Lock lock = this.arenaLock.readLock();
		lock.lock();
		try {
			rankPlayerMap = new HashMap<Integer, Long>(this.rankMap.size());
			
			for (RankVo rankVo: this.rankMap.values()) {
				long playerId = rankVo.getPlayerId();
				int rank = rankVo.getRank();
				rankPlayerMap.put(rank, playerId);
			}			
		} finally {
			lock.unlock();
		}
		
		//奖励倍数
		int boxCount = 1;
		Date now = new Date();
		if (openControlService.isOpen(OpenId.ARENA_OPEN, now)) {
			int multiple = this.arenaRuleService.getRewardActivityMultiple();
			if (multiple > 1) {
				boxCount = multiple;
			}
		}
		
		//第一名角色名
		String playerNameOfFirstRank = null;
		
		for (Entry<Integer, Long> entry: rankPlayerMap.entrySet()) {
			int rank = entry.getKey();
			long playerId = entry.getValue();
			
			Player player = this.dbCachedService.get(playerId, Player.class);
			PlayerArena playerArena = this.getPlayerArena(playerId);
			if (player == null || playerArena == null) {
				continue;
			}
			
			if (rank == 1) {
				this.topPlayerId = playerId;
				playerNameOfFirstRank = player.getPlayerName();
			}
			
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("rank", rank);
			
			int boxId = 0;			
			ArenaBox box = this.arenaRuleService.getArenaBoxByRank(rank);
			if (box != null) {
				boxId = box.getId();
				map.put("boxId", boxId);
			}
			
			ChainLock chainLock = LockUtils.getLock(player);
			chainLock.lock();
			try {
				playerArena.setBalanceRank(rank);
				playerArena.setBoxId(boxId);
				playerArena.setBoxStatus(0);
				playerArena.setBoxCount(boxCount);
				
				// 发放称号
				if (rank == 1) {
					int honorId = gameRuleService.getAmountByID(
							GameRuleID.HONOR_ARENA_RANK_FIRST).intValue();
					this.honorService.addPlayerHonor(playerId, honorId);
				} else if (rank == 2) {
					int honorId = gameRuleService.getAmountByID(
							GameRuleID.HONOR_ARENA_RANK_SECOND).intValue();
					this.honorService.addPlayerHonor(playerId, honorId);
				} else if (rank == 3) {
					int honorId = gameRuleService.getAmountByID(
							GameRuleID.HONOR_ARENA_RANK_THIRD).intValue();
					this.honorService.addPlayerHonor(playerId, honorId);
				}
			} finally {
				chainLock.unlock();
			}
			
			this.dbCachedService.submitUpdated2Queue(playerArena.getId(), playerArena.getClass());
			this.pushHelper.push(playerId, Module.ARENA, ArenaCmd.PUSH_BALANCE, map);
		}
		
		if (playerNameOfFirstRank != null) {
			//第一名公告
			Map<String, Object> values = new HashMap<String, Object>();
			values.put(NoticeKey.PLAYERNAME1, playerNameOfFirstRank);
			NoticeDto noticeDto = NoticeDto.valueOf(NoticeId.ARENA_BALANCE_FIRST_RANK, values);
			this.noticeService.pushNotice(-1L, noticeDto);
		}
		
		//群雄争霸种子选手
		this.championService.arenaCandidates(rankPlayerMap);
		
		//保存日排行奖励信息
		this.saveDayRankRewards(rankPlayerMap);
		
		//保存结算第一名
		this.saveBalanceTopPlayer(this.topPlayerId);
	}

	/**
	 * 取得竞技场信息
	 * @param id 主键id
	 * @return ArenaInfo
	 */
	public ArenaInfo getArenaInfo(int id) {
		ArenaInfo ai = this.dbCachedService.get(id, ArenaInfo.class);
		if (ai == null) {
			ai = new ArenaInfo();
			ai.setId(id);
			ai = this.dbCachedService.submitNew2Queue(ai);
		}
		return ai;
	}
	
	/**
	 * 竞技场排名列表信息
	 * @return ArenaInfo
	 */
	private ArenaInfo getArenaRankListInfo() {
		return this.getArenaInfo(ArenaRule.ARENA_RANK_LIST_ID);
	}
	
	@Override
	public ArenaInfo getArenaFirstRankInfo() {
		return this.getArenaInfo(ArenaRule.ARENA_FIRST_RANK_RECORD_ID);
	}
	
	/**
	 * 取得竞技场结算第一名信息
	 * @return ArenaInfo
	 */
	private ArenaInfo getArenaBalanceTopInfo() {
		return this.getArenaInfo(ArenaRule.ARENA_BALANCE_TOP_PLAYER_RECORD_ID);
	}
	
	/**
	 * 保存结算排名第一名
	 * @param topPlayerId 第一名玩家id
	 */
	private void saveBalanceTopPlayer(long topPlayerId) {
		ArenaInfo ai = this.getArenaBalanceTopInfo();
		synchronized(ai) {
			ai.setInfo(String.valueOf(topPlayerId));
		}
		
		this.dbCachedService.submitUpdated2Queue(ai.getId(), ai.getClass());
	}
	
	/**
	 * 加载结算排名第一名信息
	 */
	private void loadBalanceTopPlayer() {
		ArenaInfo ai = this.getArenaBalanceTopInfo();
		if (StringUtils.isBlank(ai.getInfo())) {
			return;
		}
		
		try {
			this.topPlayerId = Long.valueOf(ai.getInfo());
		} catch (Exception ex) {
			logger.error("加载结算排名第一名信息错误！", ex);
		}
	}

	@Override
	public long getBalanceTopPlayerId() {
		return this.topPlayerId;
	}

	@LifecycleMethod(lifecycle=Lifecycle.BUSSINESS_INITIALIZE, name="竞技场初始化")
	private void init() {		
		//初始化现有排名
		initArenaRanks();
		
		//神兵活动竞技场排行榜初始化
		this.arenaRankService.init();
		
		//加载结算排名第一名信息
		this.loadBalanceTopPlayer();
	}
	
	/**
	 * 初始化现有排名
	 */
	private void initArenaRanks() {
		ArenaInfo ai = this.getArenaRankListInfo();
		if (StringUtils.isBlank(ai.getInfo())) {
			return;
		}
		
		TypeReference<Map<Integer, Long>> valueTypeRef = new TypeReference<Map<Integer, Long>>() {};
		Map<Integer, Long> rankPlayerIdMap = JsonUtils.jsonString2Object(ai.getInfo(), valueTypeRef);
		if (rankPlayerIdMap == null || rankPlayerIdMap.isEmpty()) {
			return;
		}
		
		Lock lock = this.arenaLock.writeLock();
		lock.lock();
		try {
			this.rankMap.clear();
			this.playerMap.clear();
			
			for (Entry<Integer, Long> entry: rankPlayerIdMap.entrySet()) {
				int rank = entry.getKey();
				long playerId = entry.getValue();
				
				RankVo rankVo = RankVo.valueOf(rank, playerId);
				this.rankMap.put(rank, rankVo);
				
				PlayerArenaVo playerArenaVo = PlayerArenaVo.valueOf(playerId, rank);
				this.playerMap.put(playerId, playerArenaVo);
			}	
		} finally {
			lock.unlock();
		}
		
		//刷新竞技场排名
		refreshArenaRanks();
	}

}
