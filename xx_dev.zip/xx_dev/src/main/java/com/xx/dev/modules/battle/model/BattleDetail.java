/**
 * @file:BattleDetail.java
 * @author:David
 **/
package com.xx.dev.modules.battle.model;

import java.util.ArrayList;
import java.util.List;


/**
 * @class:BattleDetail
 * @description:战报每个回合细节
 * @author:David
 * @version:v1.0
 * @date:2013-4-23
 **/
public class BattleDetail {
	/** 攻击方Id */
	private long id;
	/** 攻击方pos */
	private int attackerPos;
	/** 攻击类型 {@link BattleAttackType} */
	private int attackType = BattleAttackType.NONE.ordinal();
	/** 触发的主动技能id(如果是技能攻击) */
	private int activeSkillId = 0;
	/** 触发的主动技能冷却回合数 */
	private int coolRoundOfActiveSkill = 0;
	/** 当武将的技能冷却回合被减为0时，B武将再给A武将一个效果减少回合冷却的冗余属性。 负数**/
	private int leftCoolRoundBefore = 0;
	/** 当前生命值 */
	private double hp = 0;
	/** 当前怒气值 */
	private double dander = 0;
	/** 消耗怒气 */
	private double costDander = 0;
	/** 触发的效果列表 */
	private List<SkillEffectDetail> effectDetails = new ArrayList<SkillEffectDetail>();
	
	
	public BattleDetail(BattleCharacter battleCharacter) {
		super();
		this.id = battleCharacter.getId();
		this.attackerPos = battleCharacter.getTeamPosition();
	}
	
	public long getId() {
		return id;
	}

	public int getAttackerPos() {
		return attackerPos;
	}
	public void setAttackerPos(int attackerPos) {
		this.attackerPos = attackerPos;
	}
	public int getAttackType() {
		return attackType;
	}
	public void setAttackType(int attackType) {
		this.attackType = attackType;
	}
	public int getActiveSkillId() {
		return activeSkillId;
	}
	public void setActiveSkillId(int activeSkillId) {
		this.activeSkillId = activeSkillId;
	}
	public int getCoolRoundOfActiveSkill() {
		return coolRoundOfActiveSkill;
	}
	public void setCoolRoundOfActiveSkill(int coolRoundOfActiveSkill) {
		this.coolRoundOfActiveSkill = coolRoundOfActiveSkill;
	}
	public double getHp() {
		return hp;
	}
	public void setHp(double hp) {
		this.hp = hp;
	}
	public double getDander() {
		return dander;
	}
	public void setDander(double dander) {
		this.dander = dander;
	}
	public List<SkillEffectDetail> getEffectDetails() {
		return effectDetails;
	}
	public void setEffectDetails(List<SkillEffectDetail> effectDetails) {
		this.effectDetails = effectDetails;
	}
	public double getCostDander() {
		return costDander;
	}
	public void setCostDander(double costDander) {
		this.costDander = costDander;
	}

	public int getLeftCoolRoundBefore() {
		return leftCoolRoundBefore;
	}

	public void setLeftCoolRoundBefore(int leftCoolRoundBefore) {
		this.leftCoolRoundBefore = leftCoolRoundBefore;
	}
	
}

