package com.xx.dev.modules.activity.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.xx.dev.modules.task.constant.TaskStatus;
import com.xx.dev.modules.task.entity.AbstractPlayerTask;


/**
 * 玩家活动任务信息
 * 
 * @author bingshan
 */
@Entity
@Table(name = "playerActivityTask")
public class PlayerActivityTask extends AbstractPlayerTask {
	private static final long serialVersionUID = 6276324108121406822L;
	
	
	/**
	 * 已领奖次数(对应领奖日期)
	 */
	@Column(columnDefinition = "int(11) default '0' comment '已领奖次数'")
	private int rewardedCount = 0;
	
	/**
	 * 领奖时间
	 */
	@Column(columnDefinition = "datetime comment '领奖时间'")
	private Date rewardTime = new Date();
	

	public PlayerActivityTask() {
		super();
	}
	
	public PlayerActivityTask(String id, long playerId, int taskId, TaskStatus taskStatus) {
		super(id, playerId, taskId, taskStatus);
	}

	public int getRewardedCount() {
		return rewardedCount;
	}

	public void setRewardedCount(int rewardedCount) {
		this.rewardedCount = rewardedCount;
	}

	public Date getRewardTime() {
		return rewardTime;
	}

	public void setRewardTime(Date rewardTime) {
		this.rewardTime = rewardTime;
	}
}
