package com.xx.dev.event;

import java.util.Date;

import org.apache.mina.core.session.IoSession;

import com.xx.common.event.Event;
import com.xx.dev.modules.player.handler.PlayerCmd;

/**
 * 用户登出事件
 * 
 * @author Along
 *
 */
public class LogoutEvent {
	
	/** 
	 * 登出事件 
	 */
	public static final String NAME = PlayerCmd.MODULE_NAME + ":LOGOUT";
	
	/**
	 * 用户id
	 */
	private long playerId = -1L;
	
	/** 
	 * 登录的Session 
	 */
	private IoSession session;
	
	/**
	 * 登出时间
	 */
	private Date logoutTime;

	
	public long getPlayerId() {
		return playerId;
	}

	public IoSession getSession() {
		return session;
	}
	
	public Date getLogoutTime() {
		return logoutTime;
	}

	public static Event<LogoutEvent> valueOf(long id, IoSession session, Date logoutTime) {
		LogoutEvent body = new LogoutEvent();
		body.playerId = id;
		body.session = session;
		body.logoutTime = logoutTime;
		return new Event<LogoutEvent>(NAME, body);
	}
	
}

