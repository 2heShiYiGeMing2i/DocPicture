/**
 * @file:ArmageddonHandler.java
 * @author:David
 **/
package com.xx.dev.modules.armageddon.handler;

import java.lang.reflect.Type;
import java.util.HashMap;

import org.apache.mina.core.session.IoSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xx.common.socket.handler.RequestProcessor;
import com.xx.common.socket.model.Request;
import com.xx.common.socket.model.Response;
import com.xx.dev.config.Module;
import com.xx.dev.model.Result;
import com.xx.dev.modules.armageddon.model.ArmageddonInfoDto;
import com.xx.dev.modules.armageddon.model.AttackResultDto;
import com.xx.dev.modules.armageddon.model.BuyTimeDto;
import com.xx.dev.modules.armageddon.model.CheerInfoDto;
import com.xx.dev.modules.armageddon.model.CreateRoomDto;
import com.xx.dev.modules.armageddon.model.EnterInfoDto;
import com.xx.dev.modules.armageddon.model.FlushCheerDto;
import com.xx.dev.modules.armageddon.model.MissionRewardDto;
import com.xx.dev.modules.armageddon.service.ArmageddonService;
import com.xx.dev.modules.journey.handler.JourneyResult;
import com.xx.dev.modules.server.SessionManager;
import com.xx.dev.modules.server.handler.HandlerSupport;

/**
 * @class:ArmageddonHandler
 * @description:
 * @author:David
 * @version:v1.0
 * @date:2013-5-22
 **/
/*@Service*///2013-8-19 屏蔽大决战玩法
public class ArmageddonHandler extends HandlerSupport {
	@Autowired
	private SessionManager sessionManager;
	@Autowired
	private ArmageddonService armageddonService;

	@Override
	protected void init() {
		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				chapterInfo(session, request, response);
			}
			
			@Override
			public Type getType() {
				return HashMap.class;
			}
			
			@Override
			public int getModule() {
				return Module.ARMAGEDDON;
			}
			
			@Override
			public int getCmd() {
				return ArmageddonCmd.CHAPTER_INFO;
			}
		});
		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				createRoom(session, request, response);
			}
			
			@Override
			public Type getType() {
				return HashMap.class;
			}
			
			@Override
			public int getModule() {
				return Module.ARMAGEDDON;
			}
			
			@Override
			public int getCmd() {
				return ArmageddonCmd.CREATEROOM;
			}
		});
		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				cheerInfo(session, request, response);
			}
			
			@Override
			public Type getType() {
				return HashMap.class;
			}
			
			@Override
			public int getModule() {
				return Module.ARMAGEDDON;
			}
			
			@Override
			public int getCmd() {
				return ArmageddonCmd.CHEERINFO;
			}
		});
		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				flushCheerInfo(session, request, response);
			}
			
			@Override
			public Type getType() {
				return HashMap.class;
			}
			
			@Override
			public int getModule() {
				return Module.ARMAGEDDON;
			}
			
			@Override
			public int getCmd() {
				return ArmageddonCmd.FLUSHCHEERINFO;
			}
		});
		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				enterChapter(session, request, response);
			}
			
			@Override
			public Type getType() {
				return HashMap.class;
			}
			
			@Override
			public int getModule() {
				return Module.ARMAGEDDON;
			}
			
			@Override
			public int getCmd() {
				return ArmageddonCmd.ENTER_CHAPTER;
			}
		});
		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				attackMonster(session, request, response);
			}
			
			@Override
			public Type getType() {
				return HashMap.class;
			}
			
			@Override
			public int getModule() {
				return Module.ARMAGEDDON;
			}
			
			@Override
			public int getCmd() {
				return ArmageddonCmd.ATTACK_MONSTER;
			}
		});
		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				rewardArea(session, request, response);
			}
			
			@Override
			public Type getType() {
				return HashMap.class;
			}
			
			@Override
			public int getModule() {
				return Module.ARMAGEDDON;
			}
			
			@Override
			public int getCmd() {
				return ArmageddonCmd.REWARD_AREA;
			}
		});
		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				costCd(session, request, response);
			}
			
			@Override
			public Type getType() {
				return HashMap.class;
			}
			
			@Override
			public int getModule() {
				return Module.ARMAGEDDON;
			}
			
			@Override
			public int getCmd() {
				return ArmageddonCmd.COST_CD;
			}
		});
		
	}
	/** 秒CD时间 **/
	protected void costCd(IoSession session, Request request, Response response) {
		Long playerId = sessionManager.getPlayerId(session);
		Result<BuyTimeDto> result = null;
		try {
			result = armageddonService.buyTime(playerId);
			response.setValue(result);
		} catch (Exception e) {
			response.setValue(Result.Error(JourneyResult.FAILURE));
			e.printStackTrace();
		}
		session.write(response);
	}
	/** 领取通关奖励**/
	protected void rewardArea(IoSession session, Request request,
			Response response) {
		Long playerId = sessionManager.getPlayerId(session);
		Result<MissionRewardDto> result = null;
		try {
			result = armageddonService.rewardArea(playerId);
			response.setValue(result);
		} catch (Exception e) {
			response.setValue(Result.Error(JourneyResult.FAILURE));
			e.printStackTrace();
		}
		session.write(response);
		
	}
	/** 攻击据点里怪物 **/
	protected void attackMonster(IoSession session, Request request,
			Response response) {
		Long playerId = sessionManager.getPlayerId(session);
		@SuppressWarnings("unchecked")
		HashMap<String, Object> params = (HashMap<String, Object>) request.getValue();
		Result<AttackResultDto> result = null;
		try {
			int missionId = Integer.parseInt(String.valueOf(params.get("missionId")));
			result = armageddonService.attackMonster(playerId, missionId);
			response.setValue(result);
		} catch (Exception e) {
			response.setValue(Result.Error(JourneyResult.FAILURE));
			e.printStackTrace();
		}
		session.write(response);
	}
	/** 进入单人副本的据点 **/
	protected void enterChapter(IoSession session, Request request,
			Response response) {
		Long playerId = sessionManager.getPlayerId(session);
		@SuppressWarnings("unchecked")
		HashMap<String, Object> params = (HashMap<String, Object>) request.getValue();
		Result<EnterInfoDto> result= null;
		try {
			int missionId = Integer.parseInt(String.valueOf(params.get("missionId")));
			long cheerIdOne = Long.parseLong(String.valueOf(params.get("cheerIdOne")));
			long cheerIdTwo = Long.parseLong(String.valueOf(params.get("cheerIdTwo")));
			String formation = String.valueOf(params.get("formation"));
			int hardType = Integer.parseInt(String.valueOf(params.get("hardType")));
			result = armageddonService.enterChapter(playerId, cheerIdOne, cheerIdTwo, formation, missionId, hardType);
		} catch (Exception e) {
			response.setValue(Result.Error(JourneyResult.FAILURE));
			e.printStackTrace();
		}
		response.setValue(result);
		session.write(response);
	}
	/** 获取玩家助阵列表 **/
	protected void flushCheerInfo(IoSession session, Request request,
			Response response) {
		Long playerId = sessionManager.getPlayerId(session);
		@SuppressWarnings("unchecked")
		HashMap<String, Object> params = (HashMap<String, Object>) request.getValue();
		Result<FlushCheerDto> result = null;
		try {
			long cheerId = -1;
			if(params.get("cheerId") != null){
				cheerId = Long.parseLong(String.valueOf(params.get("cheerId")));
			}
			result = armageddonService.costFlushCheerInfo(playerId, cheerId);
			response.setValue(result);
		} catch (Exception e) {
			response.setValue(Result.Error(JourneyResult.FAILURE));
			e.printStackTrace();
		}
		session.write(response);
	}
	/** 获取玩家助阵列表 **/
	protected void cheerInfo(IoSession session, Request request,
			Response response) {
		Long playerId = sessionManager.getPlayerId(session);
		Result<CheerInfoDto> result = null;
		try {
			result = armageddonService.getCheerInfo(playerId);
			response.setValue(result);
		} catch (Exception e) {
			response.setValue(Result.Error(JourneyResult.FAILURE));
			e.printStackTrace();
		}
		session.write(response);
	}
	/** 创建房间 **/
	protected void createRoom(IoSession session, Request request,
			Response response) {
		Long playerId = sessionManager.getPlayerId(session);
		Result<CreateRoomDto> result = null;
		try {
			result = armageddonService.createRoom(playerId);
			response.setValue(result);
		} catch (Exception e) {
			response.setValue(Result.Error(JourneyResult.FAILURE));
			e.printStackTrace();
		}
		session.write(response);
	}
	/** 获取进度 **/
	protected void chapterInfo(IoSession session, Request request,Response response) {
		Long playerId = sessionManager.getPlayerId(session);
		Result<ArmageddonInfoDto> result = null;
		try {
			result = armageddonService.chapterInfo(playerId);
			response.setValue(result);
		} catch (Exception e) {
			response.setValue(Result.Error(JourneyResult.FAILURE));
			e.printStackTrace();
		}
		session.write(response);
	}

}

