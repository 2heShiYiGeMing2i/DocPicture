package com.xx.dev.modules.blackmarket.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.codehaus.jackson.type.TypeReference;

import com.xx.common.db.cache.DbLoadInitializer;
import com.xx.common.db.model.BaseModel;
import com.xx.common.util.JsonUtil;
import com.xx.common.util.JsonUtils;
import com.xx.dev.modules.mail.model.AddtionReward;

/**
 * 玩家黑市记录
 * 
 * @author Along
 *
 */
@Entity
@Table(name = "playerBalckMarket")
public class PlayerBlackMarket extends BaseModel<Long> implements DbLoadInitializer {

	private static final long serialVersionUID = 6400433048507143241L;

	/**
	 * 玩家id做主键
	 */
	@Id
	@Column(columnDefinition = "bigint(20) NOT NULL COMMENT '主键'")
	private Long id;
	
	/**
	 * 最后刷新物品的时间
	 */
	@Column(columnDefinition="datetime default '2013-01-01 00:00:00' comment '最后刷新物品的时间'")
	private Date lastRefreshTime;
	
	/**
	 * 已经使用的免费刷新次数
	 */
	@Column(columnDefinition = "int(11) NOT NULL COMMENT '已经使用的免费刷新次数'")
	private Integer freeRefreshTimes = 0;
	
	/**
	 * 最后免费刷新物品的时间
	 */
	@Column(columnDefinition="datetime default '2013-01-01 00:00:00' comment '最后免费刷新物品的时间'")
	private Date lastFreeRefreshTime;
	
	/**
	 * 已购买的物品id列表
	 */
	@Column(columnDefinition = "varchar(50) NOT NULL COMMENT '已购买的物品id列表'")
	private String goodsIds = "";
	
	/**
	 * 出售物品列表
	 */
	@Column(columnDefinition = "varchar(1000) NOT NULL COMMENT '出售物品列表'")
	private String goods = "";
	
	/**
	 * 黑市积分
	 */
	@Column(columnDefinition = "int(11) NOT NULL COMMENT '黑市积分'")
	private Integer integral = 0;
	
	/**
	 * 已购买的物品id列表
	 */
	@Transient
	private List<Integer> goodsIdList = new ArrayList<Integer>();
	
	/**
	 * 出售物品列表
	 */
	@Transient
	private List<AddtionReward> goodsList = new ArrayList<AddtionReward>();
	
	/**
	 * 是否已经刷新过
	 */
	@Column(columnDefinition = "int(11) NOT NULL COMMENT '是否已经刷新过'")
	private int firstRefresh = 0;

	//------------------------------------------------------------------------------
	@Override
	public void doAfterLoad() {
		if (StringUtils.isNotBlank(this.goods)) {
			TypeReference<List<AddtionReward>> typeReference = new TypeReference<List<AddtionReward>>() {
			};
			this.goodsList = JsonUtils.jsonString2Object(this.goods, typeReference);
		}
		if (StringUtils.isNotBlank(this.goodsIds)) {
			TypeReference<List<Integer>> typeReference = new TypeReference<List<Integer>>() {
			};
			this.goodsIdList = JsonUtils.jsonString2Object(this.goodsIds, typeReference);
		}
	}
	
	@Transient
	public List<Integer> getGoodsIdList() {
		return goodsIdList;
	}

	@Transient
	public void setGoodsIdList(List<Integer> goodsIdList) {
		this.goodsIdList = goodsIdList;
		this.goodsIds = JsonUtil.toJson(goodsIdList);
	}

	@Transient
	public List<AddtionReward> getGoodsList() {
		return goodsList;
	}

	@Transient
	public void setGoodsList(List<AddtionReward> goodsList) {
		this.goodsList = goodsList;
		this.goods = JsonUtil.toJson(goodsList);
	}
	//--------------------------------------------------------
	
	public PlayerBlackMarket() {
		
	}
	
	public PlayerBlackMarket(long playerId) {
		this.id = playerId;
		Date yesterday = DateUtils.addDays(new Date(), -1);
		this.lastFreeRefreshTime = yesterday;
		this.lastRefreshTime = yesterday;
	}
	
	@Override
	public Long getId() {
		return this.id;
	}

	@Override
	public void setId(Long id) {
		this.id = id;
	}

	public Date getLastRefreshTime() {
		return lastRefreshTime;
	}

	public void setLastRefreshTime(Date lastRefreshTime) {
		this.lastRefreshTime = lastRefreshTime;
	}

	public Integer getFreeRefreshTimes() {
		return freeRefreshTimes;
	}

	public void setFreeRefreshTimes(Integer freeRefreshTimes) {
		this.freeRefreshTimes = freeRefreshTimes;
	}

	public Date getLastFreeRefreshTime() {
		return lastFreeRefreshTime;
	}

	public void setLastFreeRefreshTime(Date lastFreeRefreshTime) {
		this.lastFreeRefreshTime = lastFreeRefreshTime;
	}

	public String getGoodsIds() {
		return goodsIds;
	}

	public void setGoodsIds(String goodsIds) {
		this.goodsIds = goodsIds;
	}

	public String getGoods() {
		return goods;
	}

	public void setGoods(String goods) {
		this.goods = goods;
	}

	public Integer getIntegral() {
		return integral;
	}

	public void setIntegral(Integer integral) {
		this.integral = integral;
	}

	public int getFirstRefresh() {
		return firstRefresh;
	}

	public void setFirstRefresh(int firstRefresh) {
		this.firstRefresh = firstRefresh;
	}

}
