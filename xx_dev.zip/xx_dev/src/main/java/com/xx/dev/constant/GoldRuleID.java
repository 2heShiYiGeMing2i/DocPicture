package com.xx.dev.constant;

/**
 * 元宝固定消费对应ID
 * 
 * @author bingshan
 */
public interface GoldRuleID {
	
	//-------------------4武将-----------------
	/**
	 * 重置自定义武将被动技能
	 */
	int RESET_CUSTOM_HERO_UNACEIVE_SKILL = 401;
	
	/**
	 * 传承主动技能
	 */
	int INHERIT_ACTIVE_SKILL = 402;
	
	/**
	 * 武将传授
	 */
	int HERO_TEACH_HERO = 403;
	
	//----------------- 8 单人副本 -------------
	/** 801 -- 副本结束一次挂机消耗 */
	int FUBEN_FINISH_HOOK = 801;
	
	//-------------------14税收----------------
	/**
	 * 清除粮草税收冷却时间
	 */
	int REVENUE_CLEAR_FOODS_COOLTIME = 1401;
	
	/**
	 * 清除银元税收冷却时间
	 */
	int REVENUE_CLEAR_SILVER_COOLTIME = 1402;
	
	/**
	 * 强征银元令道具的价格
	 */
	int REVENUE_PRESS_SILVER_ITEM_COST = 1403;
	
	/**
	 * 强征粮食令道具的价格
	 */
	int REVENUE_PRESS_FOODS_ITEM_COST = 1404;
	
	// ----------------- 16 精英副本 -------------
	/** 1601 -- 精英副本结束一次挂机消耗 */
	int CREAM_FINISH_HOOK = 1601;
	
	//--------------------17武将装备--------------
	
	/**
	 * 洗练锁定附近属性的价格
	 */
	int HERO_EQUIP_ADD_ATTR_COST = 1701;
	
	/**
	 * 精钢石价格
	 */
	int HERO_EQUIP_DIAMOND_COST = 1702;
	
	/**
	 * 精炼石价格
	 */
	int HERO_EQUIP_REFINE_STONE_COST = 1703;
	
	/**
	 * 传承宝石共鸣消耗的元宝
	 */
	int HERO_EQUIP_INHERIT_JEWEL_RESONATE_COST = 1704;
	
	// ----------------- 18好友系统 -------------
	/** 1801 -- 刷新要求助战好友消费元宝 */
	int CHEER_COST = 1801;
	/** 1802 -- 双倍祝福好友时的消耗 */
	int RELATION_GOLD_BLESS = 1802;
	// ----------------- 21 征战天下 -------------
	/** 2101 -- 征战天下结束一次挂机消耗 */
	int JOURNEY_FINISH_HOOK = 2101;
	// ------------------23民心事件--------------
	/**
	 * 刷新官府事件要花费的元宝数量
	 */
	int WISH_EVENT_REFRESH_COST = 2301;
	// ----------------- 24 大决战 -------------
	/** 2401 -- 刷新要求助战好友消费元宝 */
	int ARMAGEDDONCHEER_COST = 2401;
	/** 2402-大决战 每1分钟 CD购买花费元宝数 **/
	int ARMAGEDDONBUY_TIME = 2402;
	
	//-----------------26命签-------------------
	/**
	 * 锁定求签概率以后的求签雄消耗（只限单词求签）
	 */
	int DIVINATION_LOCK_RATE_LEVEL_COST = 2601;
	//-----------------28 攻城掠地---------------------------
	/**
	 * 攻城掠地 秒CD 每1分钟 CD购买花费元宝数
	 */
	int PLUNDER_BUY_TIME = 2701;
	/**
	 * 攻城掠地 元宝鼓舞花费
	 */
	int PLUNDER_INSPIRE = 2702;
	/**
	 * 攻城掠地 追杀仇人消耗元宝数
	 */
	int PLUNDER_LOCK_ENEMY = 2703;
	/**
	 * 攻城掠地 单次侦查元宝消费
	 */
	int PLUNDER_LOOK_UP = 2704;
	//-----------------28 竞技场---------------------------
	
	/**
	 * 竞技场秒CD
	 */
	int ARENA_ELIMINATE_CD = 2801;
	
	/**
	 * 竞技场翻牌全部拿取
	 */
	int ARENA_CARD_FETCH_ALL = 2802;
	
	/**
	 * 竞技场侦查
	 */
	int ARENA_SPY = 2803;
	
	//-----------------29军团----------------------------
	/**
	 * 创建军团花费的元宝数量
	 */
	int ARMY_GROUP_CREATE_COST = 2901;
	
	/**
	 * 购买虎符花费的元宝数量
	 */
	int ARMY_GROUP_BUY_HUFU_COST = 2902;
	
	/**
	 * 清除冷却时间花费的元宝数量
	 */
	int ARMY_GROUP_CLERA_COOL_TIME_COST = 2903;
	
	//-----------------38 VIP系统-----------------------------
	/**
	 * 开通VIP	一个月VIP所需元宝
	 */
	int VIP_ONE = 3801;
	/**
	 * 开通VIP	三个月VVIP所需元宝
	 */
	int VIP_TWO = 3802;
	/**
	 * 开通VIP	半年VIP所需元宝
	 */
	int VIP_THREE = 3803;
	
	//-----------------44 一夫当关-----------------------------
	
	/**
	 * 一夫当关挂机加速
	 */
	int MANPASS_HOOK_SPEED = 4401;

	//----------------46新精英副本-----------------
	/**
	 * 每个名将消耗2元宝扫荡
	 */
	int NEWCREAM_CLEAN = 4601;
	
	//----------------47成长基金-----------------
	/**
	 * 购买成长基金的消耗
	 */
	int FUND_BUY_FUND_COST = 4701;

	//----------------50奴隶系统-----------------
	/**
	 * 压榨1小时消耗的元宝数量
	 */
	int PRESSSLAVE_HOUR =  5001;
	/**
	 * 奴隶赎身消耗
	 */
	int SLAVE_BUY_SELF =  5002;

	//----------------52 军团抢粮-----------------
	/**
	 * 抢粮立即复活消费
	 */
	int PLUNDER_REVIVE_COST = 5201;
	
	// ---------------60决战长安-----------------
    /**
     * 决战长安复活消耗
     */
    int DECISIVE_CHANG_AN_RELIVE_COST = 6001;
    
    // ----------------61图腾-------------------
    
    /**
     * 图腾升阶消耗
     */
    int TOTEM_UPGRADE_COST = 6101;

    // ----------------72月卡-------------------
    
    /**
     * 开通月卡消耗
     */
    int PLAYER_CARD_COST = 7201;
    
    // ----------------73练兵--------------------
	/**
	 * 重置练兵技能消耗
	 */
	int TRAINING_RESET_TRAINING_SKILL_COST = 7301;
	
	// ----------------87坐骑--------------------
	
	/**
	 * 坐骑属性培养消耗
	 */
	int HORSE_ATTR_TRAIN_COST = 8701;

    // -------------88神秘商店-----------------
    /**
     * 神秘商店刷新消耗
     */
    int MYSTERY_STORE_REFRESH_COST = 8801;

    // -------------89端午活动-----------------
    /**
     * 馅料价格
     */
    int DUAN_WU_XIAN_LIAO_COST = 8902;

    //---------------90灵翼--------------
    /**
     * 培养需要金币
     */
	int NETHERWING_TRAIN_NEED_GOLDS = 9001;
	
	//---------------91 跨服掠夺--------------
	
	/**
	 * 跨服掠夺手工刷新消耗
	 */
	int KF_LOOT_REFRESH_COST = 9101;
	
	/**
	 * 跨服掠夺消除冷却CD消耗
	 */
	int KF_LOOT_ELIMINATE_CD_COST = 9102;
	
	//---------------94风云争霸-------------
	/**
	 * 消除退出战队CD的消耗元宝
	 */
	int FUNG_WAN_CLEAR_QUIT_TEAM_CD_COST = 9401;
	
	/**
	 * 清除更新数据cd的消耗元宝
	 */
	int FUNG_WAN_CLEAR_DATE_UPDATE_CD_COST = 9402;
	
	/** 
	 * 献花塞蛋1次消耗(单价) 
	 */
	int FUNG_WAN_FLOWER_OR_EGG_ONE_TIMES_COST = 9403;
	
	/** 
	 * 献花塞蛋10次消耗(单价) 
	 */
	int FUNG_WAN_FLOWER_OR_EGG_TEM_TIMES_COST = 9404;
	
	/** 
	 * 献花塞蛋100次消耗(单价) 
	 */
	int FUNG_WAN_FLOWER_OR_EGG_ONE_HUNDRED_TIMES_COST = 9405;

    //---------------95真龙宝库------------
    /**
     * 真龙宝库购买钥匙宝箱消耗
     */
    int TREASURE_HOUSE_KEY_BOX_COST = 9501;
	
}
