package com.xx.dev.modules.armygroup.event;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xx.common.event.AbstractReceiver;
import com.xx.dev.modules.magic.service.GuildLevelRankService;

/**
 * 军团升级事件接收器
 * 
 * @author Along
 *
 */
@Service
public class ArmyGroupUpgradeEventReceiver extends AbstractReceiver<ArmyGroupUpgradeEvent> {
	
	@Autowired
	private GuildLevelRankService guildLevelRankService;

	@Override
	public String[] getEventNames() {
		return new String[] {ArmyGroupUpgradeEvent.NAME};
	}

	@Override
	public void doEvent(ArmyGroupUpgradeEvent event) {

		//神兵活动军团等级事件处理
		guildLevelRankService.doGuildLevelEvent(event.getId(), event.getLevel(), event.getProgress());
	}

}
