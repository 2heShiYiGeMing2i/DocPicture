package com.xx.dev.modules.blackmarket.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xx.common.basedb.BasedbService;
import com.xx.common.db.cache.DbCachedService;
import com.xx.common.util.BeanUtil;
import com.xx.common.utility.lock.ChainLock;
import com.xx.common.utility.lock.LockUtils;
import com.xx.dev.constant.GameRuleID;
import com.xx.dev.constant.IndexName;
import com.xx.dev.constant.LogSource;
import com.xx.dev.constant.RewardType;
import com.xx.dev.model.Result;
import com.xx.dev.modules.blackmarket.entity.PlayerBlackMarket;
import com.xx.dev.modules.blackmarket.entity.PlayerMarket;
import com.xx.dev.modules.blackmarket.handler.BlackMarketResult;
import com.xx.dev.modules.blackmarket.model.PlayerBlackMarketDto;
import com.xx.dev.modules.blackmarket.model.basedb.BlackMarket;
import com.xx.dev.modules.blackmarket.model.basedb.BlackMarketChange;
import com.xx.dev.modules.blackmarket.model.basedb.BuildingLevelDrop;
import com.xx.dev.modules.blackmarket.model.basedb.Market;
import com.xx.dev.modules.blackmarket.service.BlackMarketService;
import com.xx.dev.modules.building.model.BuildingId;
import com.xx.dev.modules.building.service.BuildingService;
import com.xx.dev.modules.chapter.service.ChapterService;
import com.xx.dev.modules.drop.model.DropResult;
import com.xx.dev.modules.drop.service.DropService;
import com.xx.dev.modules.heroequip.model.basedb.HeroEquip;
import com.xx.dev.modules.item.service.ItemService;
import com.xx.dev.modules.journey.service.JourneyService;
import com.xx.dev.modules.mail.model.AddtionReward;
import com.xx.dev.modules.player.entity.Player;
import com.xx.dev.modules.player.service.PlayerService;
import com.xx.dev.modules.reward.action.RewardActionSet;
import com.xx.dev.modules.reward.model.HeroEquipReward;
import com.xx.dev.modules.reward.model.ItemReward;
import com.xx.dev.modules.reward.model.PlayerEquipReward;
import com.xx.dev.modules.reward.model.Reward;
import com.xx.dev.modules.reward.model.SimpleReward;
import com.xx.dev.modules.reward.result.ValueResultSet;
import com.xx.dev.modules.reward.service.RewardService;
import com.xx.dev.modules.task.event.BlackMarketChangeGoodsEvent;
import com.xx.dev.modules.task.event.BlackMarketRefreshEvent;
import com.xx.dev.modules.task.service.TaskBus;
import com.xx.dev.modules.vip.service.VipService;
import com.xx.dev.utils.CommonRule;
import com.xx.dev.utils.GameRuleService;

/**
 * 黑市服务接口实现类
 * 
 * @author Along
 *
 */
@Service
public class BlackMarketServiceImpl implements BlackMarketService {

	/**
	 * 缓存服务接口
	 */
	@Autowired
	private DbCachedService dbCachedService;
	
	/**
	 * 基础数据服务接口
	 */
	@Autowired
	private BasedbService basedbService;
	
	/**
	 * 奖励服务接口
	 */
	@Autowired
	private RewardService rewardService;
	
	/**
	 * 主公服务接口
	 */
	@Autowired
	private PlayerService playerService;
	
	/**
	 * 游戏规则服务接口
	 */
	@Autowired
	private GameRuleService gameRuleService;
	
	/**
	 * 掉落服务接口
	 */
	@Autowired
	private DropService dropService;
	
	/**
	 * 主城建筑服务接口
	 */
	@Autowired
	private BuildingService buildingService;
	
	/**
	 * VIP服务接口
	 */
	@Autowired
	private VipService vipService;
	
	/**
	 * 道具服务接口
	 */
	@Autowired
	private ItemService itemService;
	
	/**
	 * 征战天下服务接口
	 */
	@Autowired
	private JourneyService journeyService;
	
	/**
	 * 副本服务接口
	 */
	@Autowired
	private ChapterService chapterService;
	
	@Autowired
	private TaskBus taskBus;
	
	@Override
	public Result<PlayerBlackMarketDto> getBlackMarketAction(long playerId) {
		Player player = this.dbCachedService.get(playerId, Player.class);
		if (player == null) {
			return Result.Error(BlackMarketResult.FAILURE);
		}
		PlayerBlackMarketDto playerBlackMarketDto = null;
		ChainLock chainLock = LockUtils.getLock(player);
		chainLock.lock();
		try {
			PlayerBlackMarket playerBlackMarket = this.getPlayerBlackMarket(playerId);
			if (playerBlackMarket == null) {
				return Result.Error(BlackMarketResult.FAILURE);
			}
			playerBlackMarketDto = this.getPlayerBlackMarketDto(playerBlackMarket);
		} finally {
			chainLock.unlock();
		}
		return Result.Success(playerBlackMarketDto);
	}
	
	private PlayerBlackMarketDto getPlayerBlackMarketDto(PlayerBlackMarket playerBlackMarket) {
		PlayerBlackMarketDto result = new PlayerBlackMarketDto();
		BeanUtil.copyProperties(playerBlackMarket, result, "lastRefreshTime");
		result.setLastRefreshTime(playerBlackMarket.getLastRefreshTime().getTime());
		return result;
	}
	
	@Override
	public Result<PlayerBlackMarketDto> buyGoodsAction(long playerId,
			int index) {
		Player player = this.dbCachedService.get(playerId, Player.class);
		if (player == null) {
			return Result.Error(BlackMarketResult.FAILURE);
		}
		PlayerBlackMarketDto playerBlackMarketDto = null;
		ValueResultSet valueResultSet = null;
		ChainLock chainLock = LockUtils.getLock(player);
		chainLock.lock();
		try {
			PlayerBlackMarket playerBlackMarket = this.getPlayerBlackMarket(playerId);
			if (playerBlackMarket == null) {
				return Result.Error(BlackMarketResult.FAILURE);
			}
			if (CollectionUtils.isEmpty(playerBlackMarket.getGoodsList())) {
				return Result.Error(BlackMarketResult.NO_GOODS_CAN_BUY);
			}
			AddtionReward addtionReward = this.getAddtionReward(playerBlackMarket, index);
			if (addtionReward == null) {
				return Result.Error(BlackMarketResult.PARAM_ERROR);
			}
			if (playerBlackMarket.getGoodsIdList() != null && playerBlackMarket.getGoodsIdList().contains(index)) {
				return Result.Error(BlackMarketResult.HAD_BUY_GOODS);
			}
			// 购买消耗
			List<Reward> rewardCost = this.getHeroEquipCost(playerId, addtionReward);
			if (CollectionUtils.isEmpty(rewardCost)) {
				return Result.Error(BlackMarketResult.FAILURE);
			}
			List<Reward> rewards = new ArrayList<Reward>();
			rewards.addAll(rewardCost);
			rewards.add(addtionReward.toReward());
			RewardActionSet rewardActonSet = this.rewardService.tryRewards(playerId, rewards);
			if (rewardActonSet.isNotOK()) {
				return Result.Error(rewardActonSet.getResultCode());
			}
			valueResultSet = this.rewardService.executeRewards(playerId, rewardActonSet, 
					LogSource.BLACK_MARKET_BUY_GOODS);
			playerBlackMarket.getGoodsIdList().add(addtionReward.getIndex());
			playerBlackMarket.setGoodsIdList(playerBlackMarket.getGoodsIdList());
			this.dbCachedService.submitUpdated2Queue(playerId, PlayerBlackMarket.class);
			playerBlackMarketDto = this.getPlayerBlackMarketDto(playerBlackMarket);
		} finally {
			chainLock.unlock();
		}
		Result<PlayerBlackMarketDto> result = Result.Success(playerBlackMarketDto);
		result.addContent("valueResultSet", valueResultSet);
		return result;
	}

	/**
	 * 返回购买消耗（只支持装备）
	 * @param playerId 玩家id
	 * @param addtionReward 物品
	 * @return
	 */
	private List<Reward> getHeroEquipCost(long playerId, AddtionReward addtionReward) {
		List<Reward> result = null;
		if (addtionReward == null || addtionReward.getCount() <= 0) {
			return result;
		}
		if (addtionReward.getType() == RewardType.HERO_EQUIP.ordinal()) {
			HeroEquip heroEquip = this.basedbService.get(HeroEquip.class, addtionReward.getItemId());
			if (heroEquip != null) {
				result = new ArrayList<Reward>();
				SimpleReward reward = new SimpleReward(RewardType.SILVER, 
						-heroEquip.getBuyPrice() * addtionReward.getCount());
				result.add(reward);
			}
		}
		return result;
	}
	
	/**
	 * 返回购买的物品
	 * @param playerBlackMarket 玩家黑市对象
	 * @param index 物品编号
	 * @return
	 */
	private AddtionReward getAddtionReward(PlayerBlackMarket playerBlackMarket, int index) {
		if (playerBlackMarket == null) {
			return null;
		}
		if (CollectionUtils.isEmpty(playerBlackMarket.getGoodsList())) {
			return null;
		}
		for (AddtionReward addtionReward: playerBlackMarket.getGoodsList()) {
			if (addtionReward.getIndex() == index) {
				return addtionReward;
			}
		}
		return null;
	}
	
	@Override
	public Result<PlayerBlackMarketDto> refreshBlackMarketAction(long playerId) {
		Player player = this.dbCachedService.get(playerId, Player.class);
		if (player == null) {
			return Result.Error(BlackMarketResult.FAILURE);
		}
		PlayerBlackMarketDto playerBlackMarketDto = null;
		ValueResultSet valueResultSet = null;
		int goldDiscount = 0;
		ChainLock chainLock = LockUtils.getLock(player);
		chainLock.lock();
		try {
			PlayerBlackMarket playerBlackMarket = this.getPlayerBlackMarket(playerId);
			if (playerBlackMarket == null) {
				return Result.Error(BlackMarketResult.FAILURE);
			}
			BlackMarket blackMarket = this.basedbService.get(BlackMarket.class, 1);
			if (blackMarket == null) {
				return Result.Error(BlackMarketResult.BASE_DATA_NOT_EXIST);
			}
			if (playerBlackMarket.getFreeRefreshTimes() >= blackMarket.getFreeRefreshTimes()){// 免费刷新次数已经用完
				int itemId = this.gameRuleService.getAmountByID(GameRuleID.BLACK_MARKET_REFRESH_ITEM_ID).intValue();
				int itemAmount = this.itemService.getValidPlayerItemAmount(playerId, itemId);
				RewardActionSet rewardActonSet = null;
				if (itemAmount > 0) {// 使用刷新符
					ItemReward itemReward = ItemReward.valueOf(itemId, -1);
					rewardActonSet = this.rewardService.tryRewards(playerId, itemReward);
				} else {// 使用元宝
					int newGoldCost = this.vipService.getGoldDiscountValue(player, blackMarket.getRefreshCost());
					goldDiscount += (blackMarket.getRefreshCost() - newGoldCost);
					SimpleReward goldCost = new SimpleReward(RewardType.MONEY_MIX, -newGoldCost);
					rewardActonSet = this.rewardService.tryRewards(playerId, goldCost);
				}
				if (rewardActonSet.isNotOK()) {
					return Result.Error(rewardActonSet.getResultCode());
				}
				valueResultSet = this.rewardService.executeRewards(playerId, rewardActonSet, 
						LogSource.BLACK_MARKET_REFRESH_GOODS);
				playerBlackMarket.setIntegral(playerBlackMarket.getIntegral() + blackMarket.getRewardIntegral());
			} else {
				playerBlackMarket.setFreeRefreshTimes(playerBlackMarket.getFreeRefreshTimes() + 1);
			}
			// 刷新物品
			if (playerBlackMarket.getFirstRefresh() == 0) {// 第一次刷新物品
				playerBlackMarket.setGoodsList(this.getFirstGoodsList(playerId));
				playerBlackMarket.setFirstRefresh(1);
			} else {// 非第一次刷新物品
				playerBlackMarket.setGoodsList(this.getGoodsList(playerId));
			}
			playerBlackMarket.setGoodsIdList(new ArrayList<Integer>());
			this.dbCachedService.submitUpdated2Queue(playerId, PlayerBlackMarket.class);
			playerBlackMarketDto = this.getPlayerBlackMarketDto(playerBlackMarket);
		} finally {
			chainLock.unlock();
		}
		Result<PlayerBlackMarketDto> result = Result.Success(playerBlackMarketDto);
		result.addContent("valueResultSet", valueResultSet);
		result.addContent("goldDiscount", goldDiscount);
		this.taskBus.post(BlackMarketRefreshEvent.valueOf(playerId));
		return result;
	}

	@Override
	public Result<PlayerBlackMarketDto> intergalChangeAction(long playerId, int id, int amount) {
		if (amount <= 0 || amount > 99999999) {
			return Result.Error(BlackMarketResult.PARAM_ERROR);
		}
		Player player = this.dbCachedService.get(playerId, Player.class);
		if (player == null) {
			return Result.Error(BlackMarketResult.FAILURE);
		}
		PlayerBlackMarketDto playerBlackMarketDto = null;
		ValueResultSet valueResultSet = null;
		ChainLock chainLock = LockUtils.getLock(player);
		chainLock.lock();
		try {
			PlayerBlackMarket playerBlackMarket = this.getPlayerBlackMarket(playerId);
			if (playerBlackMarket == null) {
				return Result.Error(BlackMarketResult.FAILURE);
			}
			BlackMarketChange blackMarketChange = this.basedbService.get(BlackMarketChange.class, id);
			if (blackMarketChange == null) {
				return Result.Error(BlackMarketResult.PARAM_ERROR);
			}
			if (playerBlackMarket.getIntegral() < blackMarketChange.getIntegralCost() * amount) {// 积分不够
				return Result.Error(BlackMarketResult.NO_ENOUGH_INTERGAL);
			}
			int buildingLevel = this.buildingService.getBuildingLevel(playerId, BuildingId.BLACK_MARKET);
			if (blackMarketChange.getBuildingLevel() > buildingLevel) {// 市场等级限制
				return Result.Error(BlackMarketResult.MARKET_LEVEL_LIMIT);
			}
			List<Reward> rewards = this.rewardService.parseRewards(playerId, blackMarketChange.getGoods(), true);
			if (amount > 1 && CollectionUtils.isNotEmpty(rewards)) {
				for (Reward reward: rewards) {
					reward.increase(reward.getCount() * (amount - 1));
				}
			}
			RewardActionSet rewardActonSet = this.rewardService.tryRewards(playerId, rewards);
			if (rewardActonSet.isNotOK()) {
				return Result.Error(rewardActonSet.getResultCode());
			}
			valueResultSet = this.rewardService.executeRewards(playerId, rewardActonSet, 
					LogSource.BLACK_MARKET_INTERVAL_CHANGE);
			// 扣减黑市积分
			playerBlackMarket.setIntegral(playerBlackMarket.getIntegral() - blackMarketChange.getIntegralCost() * amount);
			this.dbCachedService.submitUpdated2Queue(playerId, PlayerBlackMarket.class);
			playerBlackMarketDto = this.getPlayerBlackMarketDto(playerBlackMarket);
		} finally {
			chainLock.unlock();
		}
		Result<PlayerBlackMarketDto> result = Result.Success(playerBlackMarketDto);
		result.addContent("valueResultSet", valueResultSet);
		return result;
	}
	
	@Override
	public Result<List<Integer>> getGoodsIdsAction(long playerId, int goodsType) {
		Player player = this.dbCachedService.get(playerId, Player.class);
		if (player == null) {
			return Result.Error(BlackMarketResult.FAILURE);
		}
		List<Market> markets = this.basedbService.listByIndex(Market.class, 
				IndexName.MARKET_TYPE_INDEX, goodsType);
		if (CollectionUtils.isEmpty(markets)) {
			return Result.Error(BlackMarketResult.NO_GOODS_CAN_BUY);
		}
		List<Integer> marketIds = null;
		ChainLock chainLock = LockUtils.getLock(player);
		chainLock.lock();
		try {
			marketIds = new ArrayList<Integer>();
			Date buyTime = new Date();
			for (Market market : markets) {
				if (this.isOpen(player, market)) {
					if (market.getServerLimit() > 0 || market.getDayServerLimit() > 0) {
						PlayerMarket playerMarket = this.getPlayerMarket(market.getId());
						if (this.isServerLimit(market, buyTime, playerMarket, 1)) {
							continue;
						}
					}
					if (market.getSelfLimit() > 0 || market.getDaySelfLimit() > 0) {
						PlayerMarket playerMarket = this.getPlayerMarket(playerId, market.getId());
						if (this.isSelfLimit(market, buyTime, playerMarket, 1)) {
							continue;
						}
					}
					marketIds.add(market.getId());
				}
			}
		} finally {
			chainLock.unlock();
		}
		return Result.Success(marketIds);
	}
	
	@Override
	public Result<ValueResultSet> changeGoodsAction(long playerId, int goodsId, int amount) {
		if (amount <= 0 || amount > 99999999) {
			return Result.Error(BlackMarketResult.PARAM_ERROR);
		}
		Player player = this.dbCachedService.get(playerId, Player.class);
		if (player == null) {
			return Result.Error(BlackMarketResult.FAILURE);
		}
		Market market = this.basedbService.get(Market.class, goodsId);
		if (market == null) {
			return Result.Error(BlackMarketResult.PARAM_ERROR);
		}
		ValueResultSet valueResultSet = null;
		if (market.getServerLimit() > 0 || market.getDayServerLimit() > 0) {// 全服总限量|全服每日限量
			PlayerMarket serverMarket = this.getPlayerMarket(goodsId);
			if (serverMarket == null) {
				return Result.Error(BlackMarketResult.FAILURE);
			}
			ChainLock chainLock = LockUtils.getLock(player, serverMarket);
			chainLock.lock();
			try {
				if (!this.isOpen(player, market)) {
					return Result.Error(BlackMarketResult.GOODS_NO_OPEN);
				}
				Date buyTime = new Date();
				if (this.isServerLimit(market, buyTime, serverMarket, amount)) {
					return Result.Error(BlackMarketResult.BUY_AMOUNT_LIMIT);
				}
				PlayerMarket playerMarket = null;
				if (market.getSelfLimit() > 0 || market.getDaySelfLimit() > 0) {
					playerMarket = this.getPlayerMarket(playerId, goodsId);
					if (this.isSelfLimit(market, buyTime, playerMarket, amount)) {
						return Result.Error(BlackMarketResult.BUY_AMOUNT_LIMIT);
					}
				}
				List<Reward> rewards = new ArrayList<Reward>();
				List<Reward> buyCost = this.rewardService.parseRewards(playerId, market.getBuyPrice(), true);
				if (CollectionUtils.isNotEmpty(buyCost)) {
					rewards.addAll(buyCost);
				}
				List<Reward> buyGoods = this.rewardService.parseRewards(playerId, market.getGoodsReward(), true);
				if (CollectionUtils.isNotEmpty(buyGoods)) {
					rewards.addAll(buyGoods);
				}
				if (amount > 1) {
					for (Reward reward : rewards) {
						reward.increase(reward.getCount() * (amount - 1));
					}
				}
				RewardActionSet rewardActonSet = this.rewardService.tryRewards(playerId, rewards);
				if (rewardActonSet.isNotOK()) {
					return Result.Error(rewardActonSet.getResultCode());
				}
				valueResultSet = this.rewardService.executeRewards(playerId, rewardActonSet, 
						LogSource.MARKET_BUY_GOODS);
				this.addBuyGoodsAmount(playerId, market, amount, buyTime);
			} finally {
				chainLock.unlock();
			}
		} else {
			ChainLock chainLock = LockUtils.getLock(player);
			chainLock.lock();
			try {
				if (!this.isOpen(player, market)) {
					return Result.Error(BlackMarketResult.GOODS_NO_OPEN);
				}
				Date buyTime = new Date();
				PlayerMarket playerMarket = null;
				if (market.getSelfLimit() > 0 || market.getDaySelfLimit() > 0) {
					playerMarket = this.getPlayerMarket(playerId, goodsId);
					if (this.isSelfLimit(market, buyTime, playerMarket, amount)) {
						return Result.Error(BlackMarketResult.BUY_AMOUNT_LIMIT);
					}
				}
				List<Reward> rewards = new ArrayList<Reward>();
				List<Reward> buyCost = this.rewardService.parseRewards(playerId, market.getBuyPrice(), true);
				if (CollectionUtils.isNotEmpty(buyCost)) {
					rewards.addAll(buyCost);
				}
				List<Reward> buyGoods = this.rewardService.parseRewards(playerId, market.getGoodsReward(), true);
				if (CollectionUtils.isNotEmpty(buyGoods)) {
					rewards.addAll(buyGoods);
				}
				if (amount > 1) {
					for (Reward reward : rewards) {
						reward.increase(reward.getCount() * (amount - 1));
					}
				}
				RewardActionSet rewardActonSet = this.rewardService.tryRewards(playerId, rewards);
				if (rewardActonSet.isNotOK()) {
					return Result.Error(rewardActonSet.getResultCode());
				}
				valueResultSet = this.rewardService.executeRewards(playerId, rewardActonSet, 
						LogSource.MARKET_BUY_GOODS);
				this.addBuyGoodsAmount(playerId, market, amount, buyTime);
			} finally {
				chainLock.unlock();
			}
		}
		this.taskBus.post(BlackMarketChangeGoodsEvent.valueOf(playerId, 1));
		return Result.Success(valueResultSet);
	}

	/**
	 * 刷新物品列表
	 * @param playerId 玩家id
	 * @return
	 */
	private List<AddtionReward> getGoodsList(long playerId) {
		List<AddtionReward> result = null;
		int blackMarketLevel = this.buildingService.getBuildingLevel(playerId, BuildingId.BLACK_MARKET);
		BuildingLevelDrop buildingLevelDrop = this.basedbService.get(BuildingLevelDrop.class, blackMarketLevel);
		if (buildingLevelDrop == null) {
			return null;
		}
		DropResult dropResult = this.dropService.doDrop(playerId, buildingLevelDrop.getDropNo());
		if (dropResult == null) {
			return result;
		}
		result = this.getAddtionRewards(dropResult.getRewardList());
		return result;
	}
	
	/**
	 * 刷新初始化物品列表
	 * @param playerId 玩家id
	 * @return
	 */
	private List<AddtionReward> getInitGoodsList(long playerId) {
		List<AddtionReward> result = null;
		BlackMarket blackMarket = this.basedbService.get(BlackMarket.class, 1);
		List<Reward> rewards = null;
		if (blackMarket != null) {
			rewards = this.rewardService.parseRewards(playerId, blackMarket.getInitGoods(), true);
		}
		result = getAddtionRewards(rewards);
		return result;
	}

	/**
	 * 刷新第一次物品列表
	 * @param playerId 玩家id
	 * @return
	 */
	private List<AddtionReward> getFirstGoodsList(long playerId) {
		List<AddtionReward> result = null;
		BlackMarket blackMarket = this.basedbService.get(BlackMarket.class, 1);
		List<Reward> rewards = null;
		if (blackMarket != null) {
			rewards = this.rewardService.parseRewards(playerId, blackMarket.getFirstGoods(), true);
		}
		result = getAddtionRewards(rewards);
		return result;
	}
	
	private List<AddtionReward> getAddtionRewards(List<Reward> rewards) {
		List<AddtionReward> result = null;
		if (CollectionUtils.isNotEmpty(rewards)) {
			result = new ArrayList<AddtionReward>();
			int index = 1;
			result = new ArrayList<AddtionReward>();
			for (Reward reward: rewards) {
				if (reward.getType() == RewardType.ITEM) {
					ItemReward itemReward = (ItemReward) reward;
					AddtionReward addtionReward = AddtionReward.valueOf(itemReward, index);
					result.add(addtionReward);
					index++;
				} else if (reward.getType() == RewardType.HERO_EQUIP) {
					HeroEquipReward equipReward = (HeroEquipReward) reward;
					AddtionReward addtionReward = AddtionReward.valueOf(equipReward, index);
					result.add(addtionReward);
					index++;
				} else if (reward.getType() == RewardType.PLAYER_EQUIP) {
					PlayerEquipReward equipReward = (PlayerEquipReward) reward;
					AddtionReward addtionReward = AddtionReward.valueOf(equipReward, index);
					result.add(addtionReward);
					index++;
				} 
			}
		}
		return result;
	}
	
	private void addBuyGoodsAmount(long playerId, Market market, int amount, Date buyTime) {
		if (market.getServerLimit() > 0 || market.getDayServerLimit() > 0) {
			PlayerMarket playerMarket = this.getPlayerMarket(market.getId());
			if (playerMarket != null) {
				playerMarket.setTotalAmount(playerMarket.getTotalAmount() + amount);
				if (CommonRule.isSameResetTime(playerMarket.getBuyTime())) {
					playerMarket.setBuyTime(buyTime);
					playerMarket.setEverydayAmount(amount);
				} else {
					playerMarket.setEverydayAmount(playerMarket.getEverydayAmount() + amount);
				}
				this.dbCachedService.submitUpdated2Queue(market.getId(), PlayerMarket.class);
			}
		}
		
		if (market.getSelfLimit() > 0 || market.getDaySelfLimit() > 0) {
			PlayerMarket playerMarket = this.getPlayerMarket(playerId, market.getId());
			if (playerMarket != null) {
				playerMarket.setTotalAmount(playerMarket.getTotalAmount() + amount);
				if (CommonRule.isSameResetTime(playerMarket.getBuyTime())) {
					playerMarket.setBuyTime(buyTime);
					playerMarket.setEverydayAmount(amount);
				} else {
					playerMarket.setEverydayAmount(playerMarket.getEverydayAmount() + amount);
				}
				this.dbCachedService.submitUpdated2Queue(playerMarket.getId(), PlayerMarket.class);
			}
		}
	}
	
	private boolean isServerLimit(Market market, Date buyTime, PlayerMarket playerMarket, int buyAmount) {
		boolean result = false;
		if (market.getServerLimit() > 0 && 
				playerMarket.getTotalAmount() + buyAmount > market.getServerLimit()) {// 全服总限量
			result = true;
			return result;
		}
		if (market.getDayServerLimit() > 0 && (!CommonRule.isSameResetTime(playerMarket.getBuyTime()) && 
				playerMarket.getEverydayAmount() + buyAmount > market.getDayServerLimit())) {// 全服每日限量
			result = true;
			return result;
		}
		return result;
	}
	
	private boolean isSelfLimit(Market market, Date buyTime, PlayerMarket playerMarket, int buyAmount) {
		boolean result = false;
		if (market.getSelfLimit() > 0 && 
				playerMarket.getTotalAmount() + buyAmount > market.getSelfLimit()) {// 个人总限量
			result = true;
			return result;
		}
		if (market.getDaySelfLimit() > 0 && (!CommonRule.isSameResetTime(playerMarket.getBuyTime()) && 
				playerMarket.getEverydayAmount() + buyAmount > market.getDaySelfLimit())) {// 个人每日限量
			result = true;
			return result;
		}
		return result;
	}
	
	private boolean isOpen(Player player, Market market) {
		boolean result = false;
		int marketLevel = this.buildingService.getBuildingLevel(player.getId(), BuildingId.BLACK_MARKET);
		if (market != null && player.getVipLevel() >= market.getVipLevel() && 
				player.getLevel() >= market.getPlayerLevel() && player.getJobId() >= market.getPlayerJob() && 
				marketLevel >= market.getBuildingLevel()) {
			int star = this.chapterService.getMissionStar(player.getId(), market.getMissionId());
			int areaId = this.journeyService.getBreakMaxMissionId(player.getId(),
					market.getDifficulty() == 1 ? true : false);
			if ((market.getMissionId() > 0 && star > 0 || market.getMissionId() <= 0) && 
					(market.getAreaId() > 0 && market.getAreaId() <= areaId || market.getAreaId() <= 0)) {// 据点限制
				result = true;
			}
		}
		return result;
	}
	
	private PlayerMarket getPlayerMarket(int goodsId) {
		PlayerMarket result = 
				this.dbCachedService.get(String.valueOf(goodsId), PlayerMarket.class);
		if (result == null) {
			result = this.dbCachedService.submitNew2Queue(PlayerMarket.valueOf(goodsId));
		}
		return result;
	}
	
	private PlayerMarket getPlayerMarket(long playerId, int goodsId) {
		PlayerMarket result = 
				this.dbCachedService.get(PlayerMarket.getKey(playerId, goodsId), PlayerMarket.class);
		if (result == null) {
			result = this.dbCachedService.submitNew2Queue(PlayerMarket.valueOf(playerId, goodsId));
		}
		return result;
	}
	
	/**
	 * 返回玩家黑市
	 * @param playerId 玩家id
	 * @return
	 */
	private PlayerBlackMarket getPlayerBlackMarket(long playerId) {
		PlayerBlackMarket result = this.dbCachedService.get(playerId, PlayerBlackMarket.class);
		boolean isInit = false;
		if (result == null) {
			result = this.dbCachedService.submitNew2Queue(new PlayerBlackMarket(playerId));
			isInit = true;
		}
		Date now = new Date();
		BlackMarket blackMarket = this.basedbService.get(BlackMarket.class, 1);
		Date newRefreshTime = DateUtils.addSeconds(result.getLastRefreshTime(), 
				blackMarket.getRefreshTime());
		if (newRefreshTime.before(now)) {// 要刷新物品
			if (isInit) {// 初始化物品
				result.setGoodsList(this.getInitGoodsList(playerId));
				result.setGoodsIdList(new ArrayList<Integer>());
				result.setLastRefreshTime(now);
				this.dbCachedService.submitUpdated2Queue(playerId, PlayerBlackMarket.class);
			} else {
				if (result.getFirstRefresh() == 1) {// 非第一次刷新物品
					result.setGoodsList(this.getGoodsList(playerId));
					result.setGoodsIdList(new ArrayList<Integer>());
					result.setLastRefreshTime(now);
					this.dbCachedService.submitUpdated2Queue(playerId, PlayerBlackMarket.class);
				}
			}
		}
		if (CommonRule.isSameResetTime(result.getLastFreeRefreshTime())) {// 要刷新免费刷新物品的时间
			result.setFreeRefreshTimes(0);
			result.setLastFreeRefreshTime(now);
			this.dbCachedService.submitUpdated2Queue(playerId, PlayerBlackMarket.class);
		}
		return result;
	}
	
}
