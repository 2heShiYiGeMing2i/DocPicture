package com.xx.dev.modules.armygroup.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

import com.xx.common.db.model.BaseModel;

/**
 * 军团实体类
 * 
 * @author Along
 *
 */
@Entity
@Table(name = "armyGroup")
public class ArmyGroup extends BaseModel<Long> {

	private static final long serialVersionUID = 601595581225183753L;

	/**
	 * 军团id
	 */
	@Id
	@Column(columnDefinition = "bigint(20) NOT NULL COMMENT '主键'")
	private Long id;
	
	/**
	 * 军团名称
	 */
	@Index(name = "armyGroup_name_index")
	@Column(columnDefinition = "varchar(50) NOT NULL COMMENT '军团名称'")
	private String name;
	
	/**
	 * 团长id
	 */
	@Column(columnDefinition = "bigint(20) NOT NULL COMMENT '团长id'")
	private long chief;
	
	/**
	 * 财富
	 */
	@Column(columnDefinition = "bigint(20) NOT NULL COMMENT '财富'")
	private long wealth = 0l;
	
	/**
	 * 排名
	 */
	@Column(columnDefinition = "int(11) NOT NULL COMMENT '排名'")
	private int ranking = -1;;
	
	/**
	 * 军团宣言
	 */
	@Column(columnDefinition = "varchar(1000) NOT NULL COMMENT '军团宣言'")
	private String declaration = "";
	
	/**
	 * 军团公告
	 */
	@Column(columnDefinition = "varchar(1000) NOT NULL COMMENT '军团公告'")
	private String notice = "";
	
	/**
	 * 当天发送招贤榜的次数
	 */
	@Column(columnDefinition = "int(11) NOT NULL COMMENT '当天发送招贤榜的次数'")
	private int advertiseTimes = 0;
	
	/**
	 * 最后发送招贤榜的时间
	 */
	@Column(columnDefinition="datetime default '2013-01-01 00:00:00' comment '最后发送招贤榜的时间'")
	private Date lastSendAdvertiseTime = new Date();
	
	/**
	 * 是否需要改名
	 */
	@Column(columnDefinition = "int(11) NOT NULL COMMENT '是否需要改名'")
	private int mustRename = 0;
	
	/**
	 * 最高多人副本ID
	 */
	@Column(columnDefinition="int(11) default '0' comment '最高多人副本ID'")
	private Integer multiFubenId = 0;
	
	/**
	 * 最高多人副本对应的耐久度
	 */
	@Column(columnDefinition="int(11) default '0' comment '最高多人副本对应的耐久度'")
	private Integer multiFubenDur = 0;
	
	public ArmyGroup() {
		
	}
	
	public ArmyGroup(long playerId, String name) {
		this.chief = playerId;
		this.name = name;
		this.advertiseTimes = 0;
		this.lastSendAdvertiseTime = new Date();
	}
	
	@Override
	public Long getId() {
		return this.id;
	}

	@Override
	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getChief() {
		return chief;
	}

	public void setChief(long chief) {
		this.chief = chief;
	}

	public long getWealth() {
		return wealth;
	}

	public void setWealth(long wealth) {
		this.wealth = wealth;
	}

	public int getRanking() {
		return ranking;
	}

	public void setRanking(int ranking) {
		this.ranking = ranking;
	}

	public String getDeclaration() {
		return declaration;
	}

	public void setDeclaration(String declaration) {
		this.declaration = declaration;
	}

	public String getNotice() {
		return notice;
	}

	public void setNotice(String notice) {
		this.notice = notice;
	}

	public int getAdvertiseTimes() {
		return advertiseTimes;
	}

	public void setAdvertiseTimes(int advertiseTimes) {
		this.advertiseTimes = advertiseTimes;
	}

	public Date getLastSendAdvertiseTime() {
		return lastSendAdvertiseTime;
	}

	public void setLastSendAdvertiseTime(Date lastSendAdvertiseTime) {
		this.lastSendAdvertiseTime = lastSendAdvertiseTime;
	}

	public int getMustRename() {
		return mustRename;
	}

	public void setMustRename(int mustRename) {
		this.mustRename = mustRename;
	}

	public Integer getMultiFubenId() {
		return multiFubenId;
	}

	public void setMultiFubenId(Integer multiFubenId) {
		this.multiFubenId = multiFubenId;
	}

	public Integer getMultiFubenDur() {
		return multiFubenDur;
	}

	public void setMultiFubenDur(Integer multiFubenDur) {
		this.multiFubenDur = multiFubenDur;
	}

}
