package com.xx.dev.modules.armygroup.model;

/**
 * 军团建筑类型
 * 
 * @author Along
 *
 */
public enum ArmyGroupBuildingType {

	/**
	 * 0-无
	 */
	NONE,
	
	/**
	 * 1-聚义堂
	 */
	JUYI_HALL,
	
	/**
	 * 2-账房
	 */
	ACCOUNTANT_OFFICE,
	
	/**
	 * 3-褒忠祠
	 */
	CLAN_HALL,
	
	/**
	 * 4-鲁班坊
	 */
	LUBAN_LANE,
	
	/**
	 * 5-武馆
	 */
	KUNGFU_SCHOOL,
	
	/**
	 * 6-祭坛
	 */
	ALTAR;
	
}
