package com.xx.dev.modules.activity.service;

import java.util.List;

import com.xx.dev.modules.activity.model.basedb.Activity;
import com.xx.dev.modules.activity.model.basedb.ActivityTask;


/**
 * 活动系统基础数据接口
 * 
 * @author bingshan
 */
public interface ActivityRuleService {
	
	/**
	 * 取得活动
	 * @param id 活动id
	 * @return Activity
	 */
	Activity getActivity(int id);
	
	/**
	 * 取得活动任务
	 * @param taskId 基础任务id
	 * @return ActivityTask
	 */
	ActivityTask getActivityTask(int taskId);

	/**
	 * 取得活动列表
	 * @return List<Activity>
	 */
	List<Activity> getActivityList();
	
	/**
	 * 根据活动类型取得活动列表
	 * @param type 活动类型
	 * @return List<Activity>
	 */
	List<Activity> getActivityListByType(int type);
	
	/**
	 * 根据活动开关取得活动列表
	 * @param openId 开关ID
	 * @return List<Activity>
	 */
	List<Activity> getActivityListByOpen(String openId);
	
	/**
	 * 取得某活动的任务列表
	 * @param activityId 活动id
	 * @return List<ActivityTask>
	 */
	List<ActivityTask> getActivityTaskList(int activityId);
}
