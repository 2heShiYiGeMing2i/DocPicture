package com.xx.dev.modules.armygroup.model.basedb;

import com.xx.common.basedb.anno.Id;
import com.xx.common.basedb.anno.Resource;

/**
 * 军团商店
 * 
 * @author Along
 *
 */
@Resource
public class ArmyGroupStore {

	/**
	 * id
	 */
	@Id
	private int id;
	
	/**
	 * 出售商品
	 */
	private String goods;
	
	/**
	 * 军团等级需求
	 */
	private int level;
	
	/**
	 * 价格（贡献度）
	 */
	private int contribute;
	
	/**
	 * 每日最大购买数量
	 */
	private int maxBuyAmount;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getGoods() {
		return goods;
	}

	public void setGoods(String goods) {
		this.goods = goods;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

	public int getContribute() {
		return contribute;
	}

	public void setContribute(int contribute) {
		this.contribute = contribute;
	}

	public int getMaxBuyAmount() {
		return maxBuyAmount;
	}

	public void setMaxBuyAmount(int maxBuyAmount) {
		this.maxBuyAmount = maxBuyAmount;
	}
	
}
