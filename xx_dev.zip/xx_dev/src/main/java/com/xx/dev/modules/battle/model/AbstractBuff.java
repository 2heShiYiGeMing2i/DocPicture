/**
 * @file:AbstractBuff.java
 * @author:David
 **/
package com.xx.dev.modules.battle.model;
/**
 * @class:AbstractBuff
 * @description:抽象战斗效果类
 * @author:David
 * @version:v1.0
 * @date:2013-4-25
 **/
public abstract class AbstractBuff {
	/**
	 * 效果值类型
	 */
	public int effectBaseValueType;
	/**
	 * 效果基础值
	 */
	public double effectBase;
	/**
	 * 效果值类型
	 */
	public int effectValueType;
	/**
	 * 效果值
	 */
	public double effect ;
	/**
	 * 开始大回合
	 */
	public int startRound;
	/**
	 * 剩余持续回合
	 */
	public int persistRound;

	public AbstractBuff(int effectBaseValueType, double effectBase,
			int effectValueType, double effect, int startRound, int persistRound) {
		super();
		this.effectBaseValueType = effectBaseValueType;
		this.effectBase = effectBase;
		this.effectValueType = effectValueType;
		this.effect = effect;
		this.startRound = startRound;
		this.persistRound = persistRound;
	}


	public int getEffectBaseValueType() {
		return effectBaseValueType;
	}


	public double getEffectBase() {
		return effectBase;
	}


	public int getEffectValueType() {
		return effectValueType;
	}


	public double getEffect() {
		return effect;
	}


	public int getPersistRound(int curRound) {
		if(curRound <= this.startRound){
			return persistRound;
		}
		int persistRound = this.persistRound - (curRound - this.startRound);
		return persistRound;
	}
	/**
	 * @description:成才赋值	
	 * @param attrType
	 * @param value
	 * @param startRound
	 * @param persistRound
	 */
	public void add(double effectBase, double effect, int startRound, 
			int persistRound) {
		this.effectBase += effectBase;
		this.effect += effect;
		this.startRound = startRound;
		this.persistRound = persistRound;
	}
	/**
	 * @description:重新赋值	
	 * @param attrType
	 * @param value
	 * @param startRound
	 * @param persistRound
	 */
	public void reflush(int effectBaseValueType,
			double effectBase, int effectValueType, double effect,int startRound, 
			int persistRound) {
		this.effectBaseValueType = effectBaseValueType;
		this.effectBase = effectBase;
		this.effectValueType = effectValueType;
		this.effect = effect;
		this.startRound = startRound;
		this.persistRound = persistRound;
	}


	public void setPersistRound(int persistRound) {
		this.persistRound = persistRound;
	}
	
}

