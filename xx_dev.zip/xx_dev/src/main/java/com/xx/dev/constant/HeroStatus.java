package com.xx.dev.constant;

/**
 * 武将状态
 * 
 * @author Along
 *
 */
public enum HeroStatus {

	/**
	 * 0-不出战
	 */
	NO_FIGHT,
	
	/**
	 * 1-出战
	 */
	FIGHT
	
}
