/**
 * @file:ArmageddonMission.java
 * @author:David
 **/
package com.xx.dev.modules.armageddon.model.basedb;

import java.util.ArrayList;
import java.util.List;

import com.xx.common.basedb.anno.Id;
import com.xx.common.basedb.anno.MinMax;
import com.xx.common.basedb.anno.Resource;
import com.xx.dev.modules.journey.model.HardType;

/**
 * @class:ArmageddonMission
 * @description:大决战据点表
 * @author:David
 * @version:v1.0
 * @date:2013-5-20
 **/
@Resource
public class ArmageddonMission {
	public static final String MIN_MAX_ID = "MIN_MAX_ID";

	/**
	 * 技能基础数据id
	 */
	@Id
	@MinMax(name = MIN_MAX_ID)
	private int id;
	/** 难度 **/
	private int difficulty = HardType.NONE.ordinal();
	/** 掉落 **/
	private String drops;
	/** 进攻消耗 **/
	private String costExpr;
	/** 奖励串 **/
	private String rewards;
	/** 开放等级 **/
	private Integer openLevel;
	/** 开放任务 **/
	private Integer openTaskId;
	/** 前置单人副本据点 **/
	private Integer openMissionId;
	/** 所属副本id **/
	private Integer	fubenId;
	/** 是否新手据点 **/
	private Integer	newArea;
	/** 首破奖励 **/
	private String firstBreakRewards;
	/** 以下字段不用填表 **/
	/**
	 * 部队id列表
	 */
	private List<Integer> armyList = new ArrayList<Integer>();
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDrops() {
		return drops;
	}
	public void setDrops(String drops) {
		this.drops = drops;
	}
	public String getCostExpr() {
		return costExpr;
	}
	public void setCostExpr(String costExpr) {
		this.costExpr = costExpr;
	}
	public String getRewards() {
		return rewards;
	}
	public void setRewards(String rewards) {
		this.rewards = rewards;
	}
	public Integer getOpenLevel() {
		return openLevel;
	}
	public void setOpenLevel(Integer openLevel) {
		this.openLevel = openLevel;
	}
	public Integer getOpenTaskId() {
		return openTaskId;
	}
	public void setOpenTaskId(Integer openTaskId) {
		this.openTaskId = openTaskId;
	}
	public Integer getOpenMissionId() {
		return openMissionId;
	}
	public void setOpenMissionId(Integer openMissionId) {
		this.openMissionId = openMissionId;
	}
	public Integer getFubenId() {
		return fubenId;
	}
	public void setFubenId(Integer fubenId) {
		this.fubenId = fubenId;
	}
	public Integer getNewArea() {
		return newArea;
	}
	public void setNewArea(Integer newArea) {
		this.newArea = newArea;
	}
	public String getFirstBreakRewards() {
		return firstBreakRewards;
	}
	public void setFirstBreakRewards(String firstBreakRewards) {
		this.firstBreakRewards = firstBreakRewards;
	}
	public int getDifficulty() {
		return difficulty;
	}
	public void setDifficulty(int difficulty) {
		this.difficulty = difficulty;
	}
	public List<Integer> getArmyList() {
		return armyList;
	}
	public void setArmyList(List<Integer> armyList) {
		this.armyList = armyList;
	}
	public void addArmy(int armyId){
		this.armyList.add(armyId);
	}
	
}

