/**
 * @file:CoreBattle.java
 * @author:David
 **/
package com.xx.dev.modules.battle.core;

import org.apache.commons.lang.ArrayUtils;

import com.xx.dev.constant.BattleType;
import com.xx.dev.constant.GameRuleID;
import com.xx.dev.modules.battle.model.BattleCharacter;
import com.xx.dev.modules.battle.model.BattleGroup;
import com.xx.dev.modules.battle.model.BattleReport;
import com.xx.dev.modules.battle.model.BattleResult;
import com.xx.dev.modules.battle.model.BattleTeam;
import com.xx.dev.modules.skill.model.basedb.SkillEffectConfig;
import com.xx.dev.utils.ServiceFactory;

/**
 * @class:CoreBattle
 * @description:战斗基本核心组件与功能
 * @author:David
 * @version:v1.0
 * @date:2013-4-19
 **/
public abstract class CoreBattle implements BattleRule {
	/** 战斗结果 **/
	private BattleResult battleResult;
	/** 战斗类型 **/
	private BattleType battleType;
	/** 当前大回合 */
	private int currRound = 0;
	/** 攻击回合数 */
	private int attackRound = 0;
	/** 攻击战斗群体 **/
	private BattleGroup attackGroup;
	/** 防守方战斗群体 **/
	private BattleGroup defendGroup;
	/** 当前回合战报对象 **/
	private BattleReport curBattleReport;
	/** 技能效果参数 **/
	private SkillEffectConfig skillEffectConfig;
	
	public CoreBattle(BattleType battleType, BattleGroup attackGroup, BattleGroup defendGroup, boolean isReport) {
		super();		
		this.battleResult = new BattleResult(isReport);
		this.battleType = battleType;
		this.attackGroup = attackGroup;
		this.defendGroup = defendGroup;
		this.attackGroup.setOpposeBattleGroup(this.defendGroup);
		this.defendGroup.setOpposeBattleGroup(this.attackGroup);
		this.battleResult.setAttackGroup(attackGroup.toBattleGroupDto());
		this.battleResult.setDefendGroup(defendGroup.toBattleGroupDto());
		this.skillEffectConfig = ServiceFactory.getBasedbService().get(SkillEffectConfig.class, battleType.ordinal());
		if(this.skillEffectConfig == null){
			this.skillEffectConfig = ServiceFactory.getBasedbService().get(SkillEffectConfig.class, BattleType.PVE.ordinal());
		}
	}
	public void createBattleRound(){
		this.battleResult.createBattleRound();
	}
	public BattleResult innerGetBattleResult() {
		return battleResult;
	}

	public void setBattleResult(BattleResult battleResult) {
		this.battleResult = battleResult;
	}

	public int getCurrRound() {
		return currRound;
	}

	public void setCurrRound(int currRound) {
		this.currRound = currRound;
	}

	public BattleGroup getAttackGroup() {
		return attackGroup;
	}

	public void setAttackGroup(BattleGroup attackGroup) {
		this.attackGroup = attackGroup;
	}

	public BattleGroup getDefendGroup() {
		return defendGroup;
	}

	public void setDefendGroup(BattleGroup defendGroup) {
		this.defendGroup = defendGroup;
	}

	public BattleType getBattleType() {
		return battleType;
	}

	public void setBattleType(BattleType battleType) {
		this.battleType = battleType;
	}
	
	public int getAttackRound() {
		return attackRound;
	}

	public void setAttackRound(int attackRound) {
		this.attackRound = attackRound;
	}
	
	public BattleReport getCurBattleReport() {
		return curBattleReport;
	}

	public void setCurBattleReport(BattleReport curBattleReport) {
		this.curBattleReport = curBattleReport;
	}
	
	public SkillEffectConfig getSkillEffectConfig() {
		return skillEffectConfig;
	}

	public void setSkillEffectConfig(SkillEffectConfig skillEffectConfig) {
		this.skillEffectConfig = skillEffectConfig;
	}

	//以下方法在战斗过程中使用
	public void increaseCurrround(){
		this.currRound ++;
	}
	public void increaseAttackRound(){
		this.attackRound ++;
	}
	public int getMaxRound(){
		return ServiceFactory.getGameRuleService().getAmountByID(GameRuleID.BATTLE_MAX_ROUND).intValue();
	}
	/**
	 * @description:根据具体位置返回出手角色	
	 * @param attackerPos
	 * @return
	 */
	public BattleCharacter getAttacker(int attackerPos){
		if(ArrayUtils.contains(OFFENSE_POS, attackerPos)){
			return attackGroup.getAttacker(attackerPos);
		}
		return defendGroup.getAttacker(attackerPos);
	}
	/**
	 * @description:返回阵营所在群体	
	 * @param battleTeam
	 * @return
	 */
	public BattleGroup getBattleGroup(BattleTeam battleTeam){
		if(BattleTeam.OFFENSE_TEAM.equals(battleTeam)){
			return attackGroup;
		}
		return defendGroup;
	}
	/**
	 * 攻击时 得到己方阵形
	 */
	public static int[] getSelfPos(BattleTeam battleTeam){
		if(BattleTeam.OFFENSE_TEAM.equals(battleTeam)){
			return OFFENSE_POS;
		}
		return DEFENSE_POS;
	}
	/**
	 * 攻击时 得到防守方阵形
	 */
	public static int[] getDefensePos(BattleTeam battleTeam){
		if(BattleTeam.OFFENSE_TEAM.equals(battleTeam)){
			return DEFENSE_POS;
		}
		return OFFENSE_POS;
	}
	/**
	 * 得到攻击时对应的十字阵容
	 */
	public static int[] getCrossPos(int attackerPos){
		return CROSS_MAP.get(attackerPos);
	}
	/**
	 * 得到后排单体对位信息
	 */
	public static int[] getBackSinglePos(int attackerPos){
		return BACK_SINGLE_MAP.get(attackerPos);
	}
	/**
	 * 得到攻击时对应的一列阵容
	 */
	public static int[] getLinePos(int attackerPos){
		return LINE_MAP.get(attackerPos);
		
	}
	/**
	 * 初始化基本规则
	 */
	static{
		/** 十字方阵信息 **/
		CROSS_MAP.put(1, new int[]{2,4,8});
		CROSS_MAP.put(2, new int[]{1,3,7});
		CROSS_MAP.put(3, new int[]{2,4,6,10});
		CROSS_MAP.put(4, new int[]{1,3,5,9});
		CROSS_MAP.put(5, new int[]{4,6,12});
		CROSS_MAP.put(6, new int[]{3,5,11});
		CROSS_MAP.put(7, new int[]{2,4,8});
		CROSS_MAP.put(8, new int[]{1,3,7});
		CROSS_MAP.put(9, new int[]{2,4,6,10});
		CROSS_MAP.put(10, new int[]{1,3,5,9});
		CROSS_MAP.put(11, new int[]{4,6,12});
		CROSS_MAP.put(12, new int[]{3,5,11});
		/** 一列方阵信息 **/
		LINE_MAP.put(1, new int[]{2,8});
		LINE_MAP.put(2, new int[]{1,7});
		LINE_MAP.put(3, new int[]{4,10});
		LINE_MAP.put(4, new int[]{3,9});
		LINE_MAP.put(5, new int[]{6,12});
		LINE_MAP.put(6, new int[]{5,11});
		LINE_MAP.put(7, new int[]{2,8});
		LINE_MAP.put(8, new int[]{1,7});
		LINE_MAP.put(9, new int[]{4,10});
		LINE_MAP.put(10, new int[]{3,9});
		LINE_MAP.put(11, new int[]{6,12});
		LINE_MAP.put(12, new int[]{5,11});
		/** 后排单体对位信息 **/
		BACK_SINGLE_MAP.put(1, new int[]{8,10,12,2,4,6});
		BACK_SINGLE_MAP.put(2, new int[]{7,9,11,1,3,5});
		BACK_SINGLE_MAP.put(3, new int[]{10,8,12,4,2,6});
		BACK_SINGLE_MAP.put(4, new int[]{9,7,11,3,1,5});
		BACK_SINGLE_MAP.put(5, new int[]{12,10,8,6,4,2});
		BACK_SINGLE_MAP.put(6, new int[]{11,9,7,5,3,1});
		BACK_SINGLE_MAP.put(7, new int[]{8,10,12,2,4,6});
		BACK_SINGLE_MAP.put(8, new int[]{7,9,11,1,3,5});
		BACK_SINGLE_MAP.put(9, new int[]{10,8,12,4,2,6});
		BACK_SINGLE_MAP.put(10, new int[]{9,7,11,3,1,5});
		BACK_SINGLE_MAP.put(11, new int[]{12,10,8,6,4,2});
		BACK_SINGLE_MAP.put(12, new int[]{11,9,7,5,3,1});
	}
}

