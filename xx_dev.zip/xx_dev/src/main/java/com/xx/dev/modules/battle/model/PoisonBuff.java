/**
 * @file:PoisonBuff.java
 * @author:David
 **/
package com.xx.dev.modules.battle.model;

import com.xx.dev.modules.skill.model.basedb.SkillEffect;

/**
 * @class:PoisonBuff
 * @description:中毒
 * @author:David
 * @version:v1.0
 * @date:2013-4-29
 **/
public class PoisonBuff extends AbstractBuff {
	/** 技能效果  */
	private SkillEffect skillEffect;
	/** 伤害公式 **/
	private String effectFormula;
	/** 敌方ID **/
	private long attackerId;
	/** 敌方等级 **/
	private int attackerLevel;
	/** 敌方POS **/
	private int attackerPos;
	
	public PoisonBuff(SkillEffect skillEffect, double effect, double effectBase,
			String effectFormula, int startRound, int persistRound, BattleCharacter attacker) {
		super(0, effectBase, 0, effect, startRound,
				persistRound);
		this.skillEffect = skillEffect;
		this.effectFormula = effectFormula;
		this.attackerId = attacker.getId();
		this.attackerLevel = attacker.getLevel();
		this.attackerPos = attacker.getTeamPosition();
	}

	public String getEffectFormula() {
		return effectFormula;
	}

	public void setEffectFormula(String effectFormula) {
		this.effectFormula = effectFormula;
	}
	
	public int getAttackerLevel() {
		return attackerLevel;
	}

	public void setAttackerLevel(int attackerLevel) {
		this.attackerLevel = attackerLevel;
	}
	
	public SkillEffect getSkillEffect() {
		return skillEffect;
	}

	public void setSkillEffect(SkillEffect skillEffect) {
		this.skillEffect = skillEffect;
	}
	
	public long getAttackerId() {
		return attackerId;
	}

	public void setAttackerId(long attackerId) {
		this.attackerId = attackerId;
	}

	public int getAttackerPos() {
		return attackerPos;
	}

	public void setAttackerPos(int attackerPos) {
		this.attackerPos = attackerPos;
	}

	/**
	 * @description:重新赋值	
	 * @param attrType
	 * @param value
	 * @param startRound
	 * @param persistRound
	 */
	public void reflush(SkillEffect skillEffect, double effect,
			double effectBase, String effectFormula,int startRound, 
			int persistRound, BattleCharacter attacker) {
		this.skillEffect = skillEffect;
		this.effect = effect;
		this.effectBase = effectBase;
		this.effectFormula = effectFormula;
		this.startRound = startRound;
		this.persistRound = persistRound;
		this.attackerId = attacker.getId();
		this.attackerLevel = attacker.getLevel();
		this.attackerPos = attacker.getTeamPosition();
	}
	
}

