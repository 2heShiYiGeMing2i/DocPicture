package com.xx.dev.modules.barracks.model.basedb;

import com.xx.common.basedb.anno.Id;
import com.xx.common.basedb.anno.Index;
import com.xx.common.basedb.anno.Resource;
import com.xx.dev.constant.IndexName;

/**
 * 相性系数
 * 
 * @author Along
 *
 */
@Resource
public class RelativeRigidity {

	/**
	 * id
	 */
	@Id
	private int id;
	
	/**
	 * 兵种
	 */
	@Index(name = IndexName.SOLDIER_RELATIVE_RIGIDITY_INDEX, order = 0)
	private int armType;
	
	/**
	 * 相性值下限
	 */
	private double minValue;
	
	/**
	 * 相性值上限
	 */
	private double maxValue;
	
	/**
	 * 相性系数
	 */
	private double ratio;
	
	/**
	 * 战斗系数
	 */
	private double battleRatio;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getArmType() {
		return armType;
	}

	public void setArmType(int armType) {
		this.armType = armType;
	}

	public double getMinValue() {
		return minValue;
	}

	public void setMinValue(double minValue) {
		this.minValue = minValue;
	}

	public double getMaxValue() {
		return maxValue;
	}

	public void setMaxValue(double maxValue) {
		this.maxValue = maxValue;
	}

	public double getRatio() {
		return ratio;
	}

	public void setRatio(double ratio) {
		this.ratio = ratio;
	}

	public double getBattleRatio() {
		return battleRatio;
	}

	public void setBattleRatio(double battleRatio) {
		this.battleRatio = battleRatio;
	}
	
}
