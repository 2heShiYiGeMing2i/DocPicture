package com.xx.dev.modules.armygrouptrain.service;

import com.xx.dev.modules.armygrouptrain.model.basedb.TrainAreaConfig;
import com.xx.dev.modules.armygrouptrain.model.basedb.TrainArmy;

/**
 * 軍團試煉規則定義接口
 * @author jy
 *
 */
public interface ArmyGroupTrainRuleService {

	/**
	 * 獲取副本配置
	 * @param areaId
	 * @return
	 */
	TrainAreaConfig getTrainArea(int areaId);

	/**
	 * 獲取試煉軍配置
	 * @param areaId
	 * @param batch
	 * @return
	 */
	TrainArmy getTrainArmy(int areaId, int batch);

	/**
	 * 獲取下一批次試煉軍
	 * @param areaId
	 * @param batch
	 * @return
	 */
	TrainArmy getNextTrainArmy(int areaId, int batch);

	/**
	 * 死亡冷卻時間
	 * @return
	 */
	long getDieCoolTime();

	/**
	 * 戰鬥冷卻時間
	 * @return
	 */
	long getBattleCoolTime();

}
