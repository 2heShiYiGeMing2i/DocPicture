/**
 * @file:BattleGroupDto.java
 * @author:David
 **/
package com.xx.dev.modules.battle.model;

import java.util.ArrayList;
import java.util.List;

import com.xx.dev.modules.horse.model.HorseAttrDto;
import com.xx.dev.modules.netherwing.model.NetherwingAttrDto;
import com.xx.dev.modules.totem.model.TotemAttrDto;

/**
 * @class:BattleGroupDto
 * @description:战斗系统返回客户端初始阵容
 * @author:David
 * @version:v1.0
 * @date:2013-4-26
 **/
public class BattleGroupDto {
	/**
	 * 主公名称
	 */
	private String playerName;
	/**
	 * 主公等级
	 */
	private int playerLevel;
	/**
	 * 主公头像
	 */
	private int playerHeadId = -1;
	/**
	 * NPC头像
	 */
	private String npcPic;
	/** 
	 * 战斗力
	 */
	private double ability = 0.0;
	/**
	 * 多人战斗时的唯一KEY，仅仅给客户端用，服务端没用到
	 */
	private int key;
	/** 
	 * 战斗所属方阵 
	 */
	private BattleTeam battleTeam;
	/**
	 * 怒气值
	 */
	private double dander = 0;
	/**
	 * 最大怒气值 
	 */
	private double danderMax = 0;
	/**
	 * 战斗成员
	 */
	private List<BattleCharacterDto> characterDtos = new ArrayList<BattleCharacterDto>(BattleGroup.MAX_FIGHT_POS);
	/**
	 * 是否先锋
	 */
	private boolean first = false;
	/**
	 * 图腾的战斗属性（给客户端显示用）
	 */
	private TotemAttrDto totemAttrDto;
	/**
	 * 坐骑的战斗属性(给客户端显示用)
	 */
	private HorseAttrDto horseAttrDto;
	/**
	 * 灵翼的战斗属性(给客户端显示用)
	 */
	private NetherwingAttrDto netherwingAttrDto;
	public BattleGroupDto(BattleTeam battleTeam, double dander, double danderMax, int key, String playerName, int playerLevel, int playerHeadId, String npcPic, double ability, boolean isFirst, TotemAttrDto totemAttrDto, HorseAttrDto horseAttrDto, NetherwingAttrDto netherwingAttrDto) {
		super();
		this.battleTeam = battleTeam;
		this.dander = dander;
		this.danderMax = danderMax;
		this.key = key;
		this.playerName = playerName;
		this.playerLevel = playerLevel;
		this.playerHeadId = playerHeadId;
		this.npcPic = npcPic;
		this.ability = ability;
		this.first = isFirst;
		this.totemAttrDto = totemAttrDto;
		this.horseAttrDto = horseAttrDto;
		this.netherwingAttrDto = netherwingAttrDto;
	}
	public BattleTeam getBattleTeam() {
		return battleTeam;
	}
	public void setBattleTeam(BattleTeam battleTeam) {
		this.battleTeam = battleTeam;
	}
	public double getDander() {
		return dander;
	}
	public void setDander(double dander) {
		this.dander = dander;
	}
	public double getDanderMax() {
		return danderMax;
	}
	public void setDanderMax(double danderMax) {
		this.danderMax = danderMax;
	}
	public List<BattleCharacterDto> getCharacterDtos() {
		return characterDtos;
	}
	public void setCharacterDtos(List<BattleCharacterDto> characterDtos) {
		this.characterDtos = characterDtos;
	}
	public int getKey() {
		return key;
	}
	public void setKey(int key) {
		this.key = key;
	}
	public String getPlayerName() {
		return playerName;
	}
	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}
	public int getPlayerLevel() {
		return playerLevel;
	}
	public void setPlayerLevel(int playerLevel) {
		this.playerLevel = playerLevel;
	}
	public int getPlayerHeadId() {
		return playerHeadId;
	}
	public void setPlayerHeadId(int playerHeadId) {
		this.playerHeadId = playerHeadId;
	}
	public String getNpcPic() {
		return npcPic;
	}
	public void setNpcPic(String npcPic) {
		this.npcPic = npcPic;
	}
	public double getAbility() {
		return ability;
	}
	public void setAbility(double ability) {
		this.ability = ability;
	}
	public boolean isFirst() {
		return first;
	}
	public void setFirst(boolean first) {
		this.first = first;
	}
	public TotemAttrDto getTotemAttrDto() {
		return totemAttrDto;
	}
	public void setTotemAttrDto(TotemAttrDto totemAttrDto) {
		this.totemAttrDto = totemAttrDto;
	}
	public HorseAttrDto getHorseAttrDto() {
		return horseAttrDto;
	}
	public void setHorseAttrDto(HorseAttrDto horseAttrDto) {
		this.horseAttrDto = horseAttrDto;
	}
	
	public NetherwingAttrDto getNetherwingAttrDto() {
		return netherwingAttrDto;
	}
	public void setNetherwingAttrDto(NetherwingAttrDto netherwingAttrDto) {
		this.netherwingAttrDto = netherwingAttrDto;
	}
	/**
	 * @description:添加团队成员	
	 * @param battleCharacterDto
	 */
	public void addBattleCharacterDto(BattleCharacterDto battleCharacterDto){
		this.characterDtos.add(battleCharacterDto);
	}
}

