package com.xx.dev.constant;

/**
 * 阵形
 * @author Along
 *
 */
public enum Lineup {

	/**
	 * 无
	 */
	NONE,

	ONE,
	
	TWO,
	
	THREE,
	
	FOUR,
	
	FIVE,
	
	SIX,
	
	SEVEN,
	
	EIGHT,
	
	NINE,
	
	TEN,
	
	ELEVEN,
	
	TWELVE;
	
	public static Lineup valueOf(int lineupId) {
		if (lineupId == ONE.ordinal()) {
			return ONE;
		} else if (lineupId == TWO.ordinal()) {
			return TWO;
		} if (lineupId == THREE.ordinal()) {
			return THREE;
		} if (lineupId == FOUR.ordinal()) {
			return FOUR;
		} if (lineupId == FIVE.ordinal()) {
			return FIVE;
		} if (lineupId == SIX.ordinal()) {
			return SIX;
		} if (lineupId == SEVEN.ordinal()) {
			return SEVEN;
		} if (lineupId == EIGHT.ordinal()) {
			return EIGHT;
		} if (lineupId == NINE.ordinal()) {
			return NINE;
		} if (lineupId == TEN.ordinal()) {
			return TEN;
		} if (lineupId == ELEVEN.ordinal()) {
			return ELEVEN;
		} if (lineupId == TWELVE.ordinal()) {
			return TWELVE;
		} else {
			return NONE;
		}
	}
	
}
