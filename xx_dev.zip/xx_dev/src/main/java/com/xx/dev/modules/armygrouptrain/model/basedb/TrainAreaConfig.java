package com.xx.dev.modules.armygrouptrain.model.basedb;

import com.xx.common.basedb.anno.Id;
import com.xx.common.basedb.anno.Resource;

/**
 * 試煉據點配置
 * 
 * @author jy
 *
 */
@Resource
public class TrainAreaConfig {

	/**
	 * 據點id
	 */
	@Id
	private int id;
	
	/**
	 * 據點的先後順序
	 */
	private int sort;
	
	/**
	 * 通關的獎勵
	 */
	private String rewards;
	
	//----------一下為自定義字段，不填表---------------
	private int preAreaId;
	
	private int nextAreaId;
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getSort() {
		return sort;
	}

	public void setSort(int sort) {
		this.sort = sort;
	}

	public String getRewards() {
		return rewards;
	}

	public void setRewards(String rewards) {
		this.rewards = rewards;
	}

	public void setPreAreaId(int areaId) {
		preAreaId = areaId;
	}

	public void setNextAreaId(int areaId) {
		nextAreaId = areaId;
	}

	public int getPreAreaId() {
		return preAreaId;
	}

	public int getNextAreaId() {
		return nextAreaId;
	}
	
	
}
