package com.xx.dev.modules.armygrouptrain.model;

/**
 * 軍團試煉排名信息
 * @author jy
 *
 */
public class TrainPlayerRankDto {

	/**
	 * 玩家id
	 */
	private long playerId;
	
	/**
	 * 名字
	 */
	private String name;
	
	/**
	 * 戰力
	 */
	private double ability;
	
	/**
	 * 造成的總傷害值
	 */
	private double harm;

	public long getPlayerId() {
		return playerId;
	}

	public void setPlayerId(long playerId) {
		this.playerId = playerId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getAbility() {
		return ability;
	}

	public void setAbility(double ability) {
		this.ability = ability;
	}

	public double getHarm() {
		return harm;
	}

	public void setHarm(double harm) {
		this.harm = harm;
	}

	public static TrainPlayerRankDto valueOf(TrainPlayerRankVO rank,
			String playerName) {
		TrainPlayerRankDto dto = new TrainPlayerRankDto();
		dto.playerId = rank.getPlayerId();
		dto.harm = rank.getHarm();
		dto.ability = rank.getAbility();
		dto.name = playerName;
		return dto;
	}
}
