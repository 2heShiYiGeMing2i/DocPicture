package com.xx.dev.constant;

/**
 * 基础数据索引名
 * <p>
 * 模块名_索引名
 * </p>
 *
 * @author Along
 */
public interface IndexName {

    /**
     * 武将等级升级表索引
     */
    String HERO_LEVEL_UPGRADE_INDEX = "HERO_LEVEL_UPGRADE_INDEX";

    /**
     * 武将进化表索引
     */
    String HERO_EVOLVE_INDEX = "HERO_EVOLVE_INDEX";

    /**
     * 武将天赋技能表索引
     */
    String HERO_TALENT_SKILL_INDEX = "HERO_TALENT_SKILL_INDEX";

    /**
     * 武将天赋技能升级表索引
     */
    String HERO_TALENT_SKILL_UPGRADE_INDEX = "HERO_TALENT_SKILL_UPGRADE_INDEX";

    /**
     * 武将配置表索引
     */
    String HERO_CONFIG_INDEX = "HERO_CONFIG_INDEX";

    /**
     * 武将配置表武将卡索引
     */
    String HERO_CONFIG_HEROCARD_INDEX = "HERO_CONFIG_HEROCARD_INDEX";

    /**
     * 武将觉醒表索引表
     */
    String HERO_AWAKE_INDEX = "HERO_AWAKE_INDEX";

    /**
     * 自定义武将主动技能索引表（开放星级）
     */
    String CUSTOM_HERO_ACTIVE_SKILL_STAR_INDEX = "CUSTOM_HERO_ACTIVE_SKILL_STAR_INDEX";

    /**
     * 自定义武将主动技能索引表（兵种类型）
     */
    String CUSTOM_HERO_ACTIVE_SKILL_ARMTYPE_INDEX = "CUSTOM_HERO_ACTIVE_SKILL_ARMTYPE_INDEX";

    /**
     * 士兵训练表索引
     */
    String SOLDIER_INDEX = "SOLDIER_INDEX";

    /**
     * 士兵相性表索引
     */
    String SOLDIER_RELATIVE_RIGIDITY_INDEX = "SOLDIER_RELATIVE_RIGIDITY_INDEX";

    /**
     * 主城建筑品质升级表索引
     */
    String BUILDING_QUALITY_UPGRADE_INDEX = "BUILDING_QUALITY_UPGRADE_INDEX";

    /**
     * 主城建筑等级升级表索引
     */
    String BUILDING_LEVEL_UPGRADE_INDEX = "BUILDING_LEVEL_UPGRADE_INDEX";

    /**
     * 掉落信息掉落编号索引
     */
    String DROP_INFO_DROP_NO = "DROP_INFO_DROP_NO";

    /**
     * 道具表道具类型索引
     */
    String ITEM_ITEMTYPE_INDEX = "ITEM_ITEMTYPE_INDEX";

    /**
     * 道具表道具等级索引
     */
    String ITEM_LEVEL_INDEX = "ITEM_LEVEL_INDEX";

    /**
     * 道具合成表目标道具索引
     */
    String ITEM_COMBINE_TARGET_ID_INDEX = "ITEM_COMBINE_TARGET_ITEMID_INDEX";

    /**
     * 仓库储量表索引
     */
    String REVENUE_LEVEL_QUALITY_INDEX = "REVENUE_LEVEL_QUALITY_INDEX";

    /**
     * 粮草生产率表索引
     */
    String REVENUE_FOODS_LEVEL_QUALITY_INDEX = "REVENUE_FOODS_LEVEL_QUALITY_INDEX";

    /**
     * 银元生产率表索引
     */
    String REVENUE_SILIVER_LEVEL_QUALITY_INDEX = "REVENUE_SILIVER_LEVEL_QUALITY_INDEX";

    /**
     * 武将装备附加属性表索引
     */
    String HERO_EQUIP_ADD_ATTR_INDEX = "HERO_EQUIP_ADD_ATTR_INDEX";

    /**
     * 武将装备精炼表索引
     */
    String HERO_EQUIP_REFINE_INDEX = "HERO_EQUIP_REFINE_INDEX";

    /**
     * 武将装备套装属性表索引
     */
    String HERO_EQUIP_SUIT_ATTR_INDEX = "HERO_EQUIP_SUIT_ATTR_INDEX";

    /**
     * 科技等级升级表索引
     */
    String TECH_UPGRADE_INDEX = "TECH_UPGRADE_INDEX";

    /**
     * 军阵科技等级升级表索引
     */
    String DRILL_TECH_UPGRADE_INDEX = "DRILL_TECH_UPGRADE_INDEX";

    /**
     * 命签基础表品质索引
     */
    String DIVINATION_QUALITY_INDEX = "DIVINATION_QUALITY_INDEX";

    /**
     * 命签升级表索引
     */
    String DIVINATION_UPGRADE_INDEX = "DIVINATION_UPGRADE_INDEX";

    /**
     * 命签属性表索引
     */
    String DIVINATION_ATTR_INDEX = "DIVINATION_ATTR_INDEX";

    /**
     * 军团科技升级表索引
     */
    String ARMY_GROUP_TECH_UPGRADE_INDEX = "ARMY_GROUP_TECH_UPGRADE";

    /**
     * 军团建筑升级表索引
     */
    String ARMY_GROUP_BUILDING_UPGRADE_INDEX = "ARMY_GROUP_BUILDING_UPGRADE";

    /**
     * 民心事件奖励表索引
     */
    String WISHREWARD_INDEX = "WISHREWARD_INDEX";

    /**
     * 武将组合技能索引
     */
    String HEROCOMPOSE = "HEROCOMPOSE_INDEX";

    /**
     * 武将组合克制索引
     */
    String HEROAGAINST = "HEROAGAINST_INDEX";

    /**
     * 目标系统章节ID索引
     */
    String GOAL_CHAPTER_ID_INDEX = "GOAL_CHAPTER_ID_INDEX";

    /**
     * 活动任务活动ID索引
     */
    String ACTIVITY_TASK_ACTIVITY_ID_INDEX = "ACTIVITY_TASK_ACTIVITY_ID_INDEX";

    /**
     * 开关表合服相关索引
     */
    String OPEN_CONTROL_COMBINED_TYPE_INDEX = "OPEN_CONTROL_COMBINED_TYPE_INDEX";

    /**
     * 活动类型索引
     */
    String ACTIVITY_TYPE_INDEX = "ACTIVITY_TYPE_INDEX";

    /**
     * 活动开关索引
     */
    String ACTIVITY_OPEN_INDEX = "ACTIVITY_OPEN_INDEX";

    /**
     * 一夫当关副本id索引
     */
    String MANPASS_AREA_ID_INDEX = "MANPASS_AREA_ID_INDEX";

    /**
     * 神兵抽奖牛逼装备索引
     */
    String EQUIP_RAFFLE_NIUBILITY_EQUIP_INDEX = "EQUIP_RAFFLE_NIUBILITY_EQUIP_INDEX";

    /**
     * 市场类型索引
     */
    String MARKET_TYPE_INDEX = "MARKET_TYPE_INDEX";

    /**
     * 全服活动任务活动ID索引
     */
    String SERVER_ACTIVITY_TASK_ACTIVITY_ID_INDEX = "SERVER_ACTIVITY_TASK_ACTIVITY_ID_INDEX";

    /**
     * VIP全服赠送礼包表活动ID索引
     */
    String VIP_SERVER_GIFT_ACTIVITY_ID_INDEX = "VIP_SERVER_GIFT_ACTIVITY_ID_INDEX";

    /**
     * VIP全服赠送礼包奖励表奖励ID索引
     */
    String VIP_SERVER_GIFT_REWARD_REWARD_ID_INDEX = "VIP_SERVER_GIFT_REWARD_REWARD_ID_INDEX";

    /**
     * 摸金全服赠送礼包表活动ID索引
     */
    String TREASURE_SERVER_GIFT_ACTIVITY_ID_INDEX = "TREASURE_SERVER_GIFT_ACTIVITY_ID_INDEX";

    /**
     * 摸金全服赠送礼包奖励表奖励ID索引
     */
    String TREASURE_SERVER_GIFT_REWARD_REWARD_ID_INDEX = "TREASURE_SERVER_GIFT_REWARD_REWARD_ID_INDEX";

    /**
     * 竞技场天排名奖励索引
     */
    String ARENA_DAY_RANK_INDEX = "ARENA_DAY_RANK_INDEX";

    /**
     * 理财计划  周理财计划期数奖励索引
     */
    String MONEY_PLAN_WEEK_PHASE_INDEX = "MONEY_PLAN_WEEK_PHASE_INDEX";

    /**
     * 理财计划 月理财计划期数奖励索引
     */
    String MONEY_PLAN_MONTH_PHASE_INDEX = "MONEY_PLAN_MONTH_PHASE_INDEX";

    /**
     * 积分活动 活动类型索引
     */
    String INTEGRATION_TYPE = "INTEGRATION_TYPE";

    /**
     * 练兵技能属性表索引
     */
    String TRAINING_SKILL_ATTR_INDEX = "TRAINING_SKILL_ATTR_INDEX";

    /**
     * 元宝活动表索引
     */
    String GOLD_DRAW_INDEX = "GOLD_DRAW_INDEX";

    /**
     * 皇城缉盗Npc等级索引
     */
    String ROYAL_NPC_LEVEL_INDEX = "ROYAL_NPC_LEVEL_INDEX";

    /**
     * 坐骑配置表品阶索引
     */
    String HORSE_CONFIG_RANK_INDEX = "HORSE_CONFIG_RANK_INDEX";

    /**
     * 坐骑配置表激活道具id索引
     */
    String HORSE_CONFIG_CARDID_INDEX = "HORSE_CONFIG_CARDID_INDEX";

    /**
     * 神秘商店大类索引
     */
    String MYSTERY_STORE_BASE_TYPE_INDEX = "MYSTERY_STORE_BASE_TYPE_INDEX";

	/**
     * 灵翼升级等级索引
     */
	String NETHERWING_UPGRADE_LEVEL_INDEX = "NETHERWING_UPGRADE_LEVEL_INDEX";
	
	/**
     * 灵翼类型索引
     */
	String NETHERWING_TYPE_INDEX = "NETHERWING_TYPE_INDEX";

	/**
     * 试炼军批次索引
     */
	String ARMY_GROUP_TRAIN_AREA_INDEX = "ARMY_GROUP_TRAIN_AREA_INDEX";
	
	/**
     * 灵翼活动奖励索引
     */
	String NETHERWING_ACTIVITY_CONFIG_INDEX = "NETHERWING_ACTIVITY_CONFIG_INDEX";

	/**
	 * 跨服群雄争霸等级奖励索引
	 */
	String KF_CHAMPION_LEVEL_REWARDS_INDEX = "KF_CHAMPION_LEVEL_REWARDS_INDEX";
	
	/**
	 * 风云争霸赛段索引
	 */
	String FUNG_WAN_RANK_REWARD_SECTION_INDEX = "FUNG_WAN_RANK_REWARD_SECTION_INDEX";

    /**
     * 宝箱迷阵宝箱品阶索引
     */
    String BEJEWELED_BOX_LEVEL_INDEX = "BEJEWELED_BOX_LEVEL_INDEX";
    
    /**
     * 称号激活道具id索引
     */
    String HONOR_UNLOCK_ITEMID_INDEX = "HONOR_UNLOCK_ITEMID_INDEX";
    
    /**
     * 称号类型索引
     */
    String HONOR_TYPE_INDEX = "HONOR_TYPE_INDEX";
    
}
