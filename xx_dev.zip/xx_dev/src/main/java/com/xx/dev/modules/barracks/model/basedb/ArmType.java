package com.xx.dev.modules.barracks.model.basedb;

import com.xx.common.basedb.anno.Id;
import com.xx.common.basedb.anno.Resource;

/**
 * 兵种表
 * 
 * @author Along
 *
 */
@Resource
public class ArmType {

	/**
	 * id
	 */
	@Id
	private Integer id;
	
	/**
	 * 兵种名称
	 */
	private String name;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
}
