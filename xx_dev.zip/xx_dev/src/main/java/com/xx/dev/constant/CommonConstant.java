package com.xx.dev.constant;

/**
 * @class:CommonConstant
 * @description:公共返回常量
 * @author:David
 * @version:v1.0
 * @date:2012-10-12
 **/
public interface CommonConstant {
	
	/** 操作成功 */
	int SUCCESS = 0;

	/** 操作失败 */
	int FAILURE = -1;
		
	/** 没操作权限 */
	int NO_RIGHT = -2;
	
	/** 基础数据不存在 */
	int BASE_DATA_NOT_EXIST = -3;
	
	/** 角色不存在 */
	int PLAYER_NOT_EXISTS = -4;
	
	/** 持久化异常 */
	int PERSISTENCE_ERROR = -5;
	
	/** 参数错误  */
	int PARAM_ERROR = -6;
	
	/** 用户不在线上*/
	int PLAYER_NOT_ONLINE = -7;
	
	/** 金币不足 */
	int GOLD_NOT_ENOUGH = -8;

	/** 银元不足 */
	int SILVER_NOT_ENOUGH = -9;
	
	/** 粮草不足 */
	int FOODS_NOT_ENOUGH = -10;
	
	/** 背包位置不够 */
	int PACK_NOT_ENOUGH = -11;

	/** 用户等级不够 */
	int PLAYER_LEVEL_NOT_ENOUGH = -12;
	
	/** 用户经验不够 */
	int PLAYER_EXP_NOT_ENOUGH = -13;
	
	/** 武将经验不够 */
	int SOUL_NOT_ENOUGH = -14;
	
	/** 水晶不够 */
	int CRYSTAL_NOT_ENOUGH = -15;
	
	/** 声望不够 */
	int FAME_NO_ENOUGH = -16;
	
	/** 功勋不够 */
	int EXPLOIT_NO_ENOUGH = -17;
	
	/** 积分不够 */
	int CREDIT_NO_ENOUGH = -18;
	
	/** 体力不够 */
	int ENERGY_NO_ENOUGH = -19;
	
	/** 体力buff不够 */
	int ENERGY_BUFF_NO_ENOUGH = -20;
	
	/** 基础数据有误*/
	int BASE_DATA_ERROR = -21;
	
	/** 战斗冷却中*/
	int ATTACK_COOLING = -22;
	
	/** 道具不够 */
	int ITEM_NO_ENOUGH = -23;
	
	/** 战魂不够 */
	int DRILL_EXP_NO_ENOUGH = -24;
	
	/** vip等级不够 */
	int VIP_LEVEL_NO_ENOUGH = -25;
	
	/** 官职不够 **/
	int JOB_NOT_ENOUGH = -26;
	
	/**
	 * 锯子令不足
	 */
	int JZL_NOT_ENOUGH = -27;
	
	/** 没有出战单位  **/
	int MUST_ATTACKER = -67;
	
	/** 道具数量为负*/
	int ITEM_COUNT_NEGATIVE = -68;
	
	/** 命签仓库已满 */
	int NO_ENOUGH_DIVINATION_STORE = -69;
	
	/** 非法的服标识*/
	int ILLEGAL_SERVER_ID = -99;

	
}

