package com.xx.dev.modules.blackmarket.model;

import java.util.ArrayList;
import java.util.List;

import com.xx.dev.modules.mail.model.AddtionReward;

/**
 * 玩家黑市DTO对象
 * 
 * @author Along
 *
 */
public class PlayerBlackMarketDto {

	/**
	 * 最后刷新物品的时间
	 */
	private long lastRefreshTime;
	
	/**
	 * 已经使用的免费刷新次数
	 */
	private Integer freeRefreshTimes;
	
	/**
	 * 黑市积分
	 */
	private Integer integral;
	
	/**
	 * 已购买的物品id列表
	 */
	private List<Integer> goodsIdList = new ArrayList<Integer>();
	
	/**
	 * 出售物品列表
	 */
	private List<AddtionReward> goodsList = new ArrayList<AddtionReward>();
	
	/**
	 * 是否已经刷新过
	 */
	private int firstRefresh;

	public long getLastRefreshTime() {
		return lastRefreshTime;
	}

	public void setLastRefreshTime(long lastRefreshTime) {
		this.lastRefreshTime = lastRefreshTime;
	}

	public Integer getFreeRefreshTimes() {
		return freeRefreshTimes;
	}

	public void setFreeRefreshTimes(Integer freeRefreshTimes) {
		this.freeRefreshTimes = freeRefreshTimes;
	}

	public Integer getIntegral() {
		return integral;
	}

	public void setIntegral(Integer integral) {
		this.integral = integral;
	}

	public List<Integer> getGoodsIdList() {
		return goodsIdList;
	}

	public void setGoodsIdList(List<Integer> goodsIdList) {
		this.goodsIdList = goodsIdList;
	}

	public List<AddtionReward> getGoodsList() {
		return goodsList;
	}

	public void setGoodsList(List<AddtionReward> goodsList) {
		this.goodsList = goodsList;
	}

	public int getFirstRefresh() {
		return firstRefresh;
	}

	public void setFirstRefresh(int firstRefresh) {
		this.firstRefresh = firstRefresh;
	}
	
}
