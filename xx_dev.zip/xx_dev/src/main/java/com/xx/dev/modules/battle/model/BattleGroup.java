/**
 * @file:BattleGroup.java
 * @author:David
 **/
package com.xx.dev.modules.battle.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.ArrayUtils;
import org.codehaus.jackson.annotate.JsonIgnore;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.xx.common.basedb.BasedbService;
import com.xx.common.util.RandomUtil;
import com.xx.common.util.Splitable;
import com.xx.common.util.StringUtils;
import com.xx.dev.constant.CharacterType;
import com.xx.dev.constant.GameRuleID;
import com.xx.dev.constant.IndexName;
import com.xx.dev.modules.battle.core.BattleRule;
import com.xx.dev.modules.hero.model.basedb.HeroAgainst;
import com.xx.dev.modules.hero.model.basedb.HeroCompose;
import com.xx.dev.modules.horse.model.HorseAttrDto;
import com.xx.dev.modules.netherwing.model.NetherwingAttrDto;
import com.xx.dev.modules.skill.model.SkillEffectTiming;
import com.xx.dev.modules.skill.model.basedb.SkillEffectConfig;
import com.xx.dev.modules.skill.service.SkillRuleService;
import com.xx.dev.modules.totem.model.TotemAttrDto;
import com.xx.dev.utils.ServiceFactory;



/**
 * @class:BattleGroup
 * @description:战斗群体，军队
 * @author:David
 * @version:v1.0
 * @date:2013-4-22
 **/
public class BattleGroup {
	private static final Logger logger = LoggerFactory.getLogger(BattleGroup.class);
	/**
	 * 多人战斗时的唯一KEY，仅仅给客户端用，服务端没用到
	 */
	private int key;
	/**
	 * 战斗单位最大出战位置
	 */
	public static final int MAX_BATTLE_POS = 12;
	/**
	 * 战斗单位最小出战位置
	 */
	public static final int MIN_BATTLE_POS = 1;
	/** 
	 * 战斗所属方阵 
	 */
	private BattleTeam battleTeam;
	/**
	 * 怒气值
	 */
	private double dander = 0;
	/**
	 * 最大怒气值 
	 */
	private double danderMax = 0;
	/**
	 * 所有成员 {位置id：BattleCharacter}
	 */
	private Map<Integer, BattleCharacter> characters;
	/**
	 * 存活成员位置{位置id}
	 */
	private List<Integer> alivePos;
	/**
	 * 光环技能成员{位置id}
	 */
	private List<Integer> unityPos;
	/**
	 * 战斗对手
	 */
	private BattleGroup opposeBattleGroup;
	/**
	 * 如果是NPCHERO，奖励掉落 
	 */
	private List<String> dropResult = new ArrayList<String>();
	/**
	 * 主将技能堆叠次数{skillId:次数}
	 */
	private Map<Integer, Integer> generalSkillCount = new HashMap<Integer, Integer>();
	/**
	 * 武将组合克制效果
	 * //{攻击者阵营：减少伤害}
	 */
	Map<Integer, Double> againstEffectMap = null;

	/**
	 * 角色类型
	 */
	private CharacterType characterType;
	/**
	 * 主公名称
	 */
	private String playerName;
	/**
	 * 主公等级
	 */
	private int playerLevel;
	/**
	 * 主公头像
	 */
	private int playerHeadId = -1;
	/**
	 * NPC头像
	 */
	private String npcPic;
	/** 
	 * 战斗力
	 */
	private double ability = 0.0;
	/**
	 * 是否先锋
	 */
	private boolean first = true;
	/**
	 * 军威的等级 
	 */
	private int junWeiLevel = 0;
	/**
	 * 图腾的战斗属性（给客户端显示用）
	 */
	private TotemAttrDto totemAttrDto;
	/**
	 * 坐骑的战斗属性(给客户端显示用)
	 */
	private HorseAttrDto horseAttrDto;
	/**
	 * 灵翼的战斗属性(给客户端显示用)
	 */
	private NetherwingAttrDto netherwingAttrDto;
	/**
	 * 普通战斗用这个
	 * create a instance  BattleGroup.   
	 * @param battleTeam
	 * @param battleCharacters
	 * @param battlePlayerInfo
	 * @param dander
	 */
	public BattleGroup(final BattleTeam battleTeam, final List<BattleCharacter> battleCharacters, final BattlePlayerInfo battlePlayerInfo, final double dander) {
		super();
		initGroup(battleCharacters);
		this.battleTeam = battleTeam;
		this.dander = dander;
		double danderMax = ServiceFactory.getGameRuleService().getAmountByID(GameRuleID.BATTLE_MAX_DANDER);
		this.danderMax = danderMax;
		this.playerName = battlePlayerInfo.getPlayerName();
		this.playerLevel = battlePlayerInfo.getPlayerLevel();
		this.playerHeadId = battlePlayerInfo.getPlayerHeadId();
		this.npcPic = battlePlayerInfo.getNpcPic();
		this.ability = battlePlayerInfo.getAbility();
		this.junWeiLevel = battlePlayerInfo.getJunWeiLevel();
		this.characterType = battlePlayerInfo.getCharacterType();
		initBattleCharacters(battleCharacters);
		if(battlePlayerInfo.getPlayerId() != null){
			this.totemAttrDto = ServiceFactory.getTotemService().getPlayerTotemAttrDto(battlePlayerInfo.getPlayerId());
			this.horseAttrDto = ServiceFactory.getHorseService().getPlayerHorseAttrDto(battlePlayerInfo.getPlayerId());
			this.netherwingAttrDto = ServiceFactory.getNetherwingService().getPlayerNetherwingAttrDto(battlePlayerInfo.getPlayerId());
		}
	}
	/**
	 * 多人战斗需要为每只队伍指定一个唯一key
	 * create a instance  BattleGroup.   
	 * @param battleTeam
	 * @param battleCharacters
	 * @param battlePlayerInfo
	 * @param dander
	 * @param key
	 */
	public BattleGroup(final BattleTeam battleTeam, final List<BattleCharacter> battleCharacters, final BattlePlayerInfo battlePlayerInfo, final double dander, final int key) {
		super();
		initGroup(battleCharacters);
		this.battleTeam = battleTeam;
		this.dander = dander;
		double danderMax = ServiceFactory.getGameRuleService().getAmountByID(GameRuleID.BATTLE_MAX_DANDER);
		this.danderMax = danderMax;
		this.playerName = battlePlayerInfo.getPlayerName();
		this.playerLevel = battlePlayerInfo.getPlayerLevel();
		this.playerHeadId = battlePlayerInfo.getPlayerHeadId();
		this.npcPic = battlePlayerInfo.getNpcPic();
		this.ability = battlePlayerInfo.getAbility();
		this.junWeiLevel = battlePlayerInfo.getJunWeiLevel();
		this.characterType = battlePlayerInfo.getCharacterType();
		this.key = key;
		initBattleCharacters(battleCharacters);
		if(battlePlayerInfo.getPlayerId() != null){
			this.totemAttrDto = ServiceFactory.getTotemService().getPlayerTotemAttrDto(battlePlayerInfo.getPlayerId());
			this.horseAttrDto = ServiceFactory.getHorseService().getPlayerHorseAttrDto(battlePlayerInfo.getPlayerId());
			this.netherwingAttrDto = ServiceFactory.getNetherwingService().getPlayerNetherwingAttrDto(battlePlayerInfo.getPlayerId());
		}
	}
	/**
	 * @description:Group初始化
	 * @param battleCharacters
	 */
	private void initGroup(List<BattleCharacter> battleCharacters) {
		this.characters = new HashMap<Integer, BattleCharacter>(MAX_FIGHT_POS);
		this.alivePos = new ArrayList<Integer>(MAX_FIGHT_POS);
		this.unityPos = new ArrayList<Integer>(MAX_FIGHT_POS);
	}
	/**
	 * @description:初始化群体中所有战斗角色	
	 * @param battleCharacters
	 */
	private void initBattleCharacters(List<BattleCharacter> battleCharacters) {
		if(battleCharacters == null || battleCharacters.isEmpty())
			return;
		//武将组合技能ID
		int composeSkillId = -1;
		List<Integer> heroTypes = new ArrayList<Integer>(battleCharacters.size());
		for (BattleCharacter battleCharacter : battleCharacters) {
			if(!battleCharacter.isCheer() && !heroTypes.contains(battleCharacter.getHeroType())){
				heroTypes.add(battleCharacter.getHeroType());
			}
		}
		Collections.sort(heroTypes);
		StringBuilder infoBuilder = new StringBuilder();
		SkillRuleService skillRuleService = ServiceFactory.getSkillRuleService();
		GOTO: for (int i = 0; i < heroTypes.size(); i++) {
			for (int j = i+1; j < heroTypes.size(); j++) {
				for (int j2 = j+1; j2 < heroTypes.size(); j2++) {
					infoBuilder.delete(0, infoBuilder.length());
					infoBuilder.append(heroTypes.get(i)).append(Splitable.ELEMENT_DELIMITER)
						.append(heroTypes.get(j)).append(Splitable.ELEMENT_DELIMITER)
							.append(heroTypes.get(j2)).append(Splitable.ELEMENT_DELIMITER);
					HeroCompose heroCompose = skillRuleService.loadHeroCompose(infoBuilder.toString());
					if(heroCompose != null){
						int count = 0;
						for (Integer heroType : heroTypes) {
							if(heroCompose.containHeroType(heroType)){
								count += 1;
							}
						}
						composeSkillId = heroCompose.getComposeSkill(count);
					}
					if(composeSkillId != -1){
						break GOTO;
					}
				}
			}
		}
		BasedbService basedbService = ServiceFactory.getBasedbService();
		for (int i = 0; i < heroTypes.size(); i++) {
			infoBuilder.delete(0, infoBuilder.length());
			infoBuilder.append(heroTypes.get(i)).append(Splitable.ELEMENT_DELIMITER);
		}
		HeroAgainst heroAgainst = basedbService.getByUnique(HeroAgainst.class, IndexName.HEROAGAINST, infoBuilder.toString());
		if(heroAgainst != null){
			this.againstEffectMap = new HashMap<Integer, Double>();
			this.againstEffectMap.putAll(heroAgainst.getAgainstEffectMap());
		}
		for (BattleCharacter battleCharacter : battleCharacters) {
			joinBattleCharacter(battleCharacter, composeSkillId);
		}
	}
	//默认武将组合技能等级
	private final static int COMPOSESKILLLEVEL = 1;
	/**
	 * @description:战斗队伍加入角色	
	 * @param battleCharacter
	 * @param composeSkillId 武将组合技能ID
	 */
	private void joinBattleCharacter(BattleCharacter battleCharacter, int composeSkillId){
		if(battleCharacter == null){
			return;
		}
		if(!battleCharacter.isDie() && battleCharacter.getBattleAttr().hp > 0){
			int position = battleCharacter.getTeamIndex();
			if (position < MIN_BATTLE_POS || position > MAX_BATTLE_POS ) {
				logger.error("战斗单位[id: {}, pos: {}] 战斗位置有问题, 被忽略掉！", new Object[] {battleCharacter.getId(), position});
			} else {
				battleCharacter.setBattleGroup(this);
				battleCharacter.setBattleTeam(battleTeam);
				battleCharacter.flushTeamPos();
				battleCharacter.setId(Long.valueOf(battleCharacter.getTeamPosition()));
				battleCharacter.addExtraSkill(composeSkillId, COMPOSESKILLLEVEL);
				battleCharacter.initSkillInfos();
				if(!StringUtils.isEmpty(battleCharacter.getDropExpr())){
					dropResult.add(battleCharacter.getDropExpr());
				}
				characters.put(battleCharacter.getTeamPosition(), battleCharacter);
				alivePos.add(battleCharacter.getTeamPosition());
				if(battleCharacter.isUnity()){
					unityPos.add(battleCharacter.getTeamPosition());
				}
				if(!battleCharacter.isCheer() && battleCharacter.getGeneralSkillId() != -1){
					Integer count = this.generalSkillCount.get(battleCharacter.getGeneralSkillId());
					if(count == null){
						count = 0;
					}
					count += 1;
					this.generalSkillCount.put(battleCharacter.getGeneralSkillId(), count);
				}
			}
		}
	}

	public BattleTeam getBattleTeam() {
		return battleTeam;
	}
	public void setBattleTeam(BattleTeam battleTeam) {
		this.battleTeam = battleTeam;
	}
	public Map<Integer, BattleCharacter> getCharacters() {
		return characters;
	}
	public void setCharacters(Map<Integer, BattleCharacter> characters) {
		this.characters = characters;
	}
	public List<Integer> getAlivePos() {
		return alivePos;
	}
	public void setAlivePos(List<Integer> alivePos) {
		this.alivePos = alivePos;
	}
	public BattleGroup getOpposeBattleGroup() {
		return opposeBattleGroup;
	}
	public void setOpposeBattleGroup(BattleGroup opposeBattleGroup) {
		this.opposeBattleGroup = opposeBattleGroup;
	}
	public double getDander() {
		return dander;
	}
	public void setDander(double dander) {
		this.dander = dander;
	}
	public double getDanderMax() {
		return danderMax;
	}
	public void setDanderMax(double danderMax) {
		this.danderMax = danderMax;
	}
	public List<Integer> getUnityPos() {
		return unityPos;
	}
	public void setUnityPos(List<Integer> unityPos) {
		this.unityPos = unityPos;
	}
	public List<String> getDropResult() {
		return dropResult;
	}
	public void setDropResult(List<String> dropResult) {
		this.dropResult = dropResult;
	}
	public int getKey() {
		return key;
	}
	public void setKey(int key) {
		this.key = key;
	}
	public String getPlayerName() {
		return playerName;
	}
	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}
	public int getPlayerLevel() {
		return playerLevel;
	}
	public void setPlayerLevel(int playerLevel) {
		this.playerLevel = playerLevel;
	}
	public int getPlayerHeadId() {
		return playerHeadId;
	}
	public void setPlayerHeadId(int playerHeadId) {
		this.playerHeadId = playerHeadId;
	}
	public String getNpcPic() {
		return npcPic;
	}
	public void setNpcPic(String npcPic) {
		this.npcPic = npcPic;
	}
	public double getAbility() {
		return ability;
	}
	public void setAbility(double ability) {
		this.ability = ability;
	}
	//以下方法在战斗过程中使用
	/**
	 * 加减怒气
	 * @param dander 加减值
	 */
	public void addDander(double dander) {
		this.dander += dander;
		
		if (this.dander < 0) {
			this.dander = 0;
		} else if (this.dander > this.danderMax) {
			this.dander = this.danderMax;
		}
	}
	/**
	 * 施放部队的辅助技能效果
	 * @param effectTiming SkillEffectTiming
	 * @param currRound 当前回合
	 */
	public void fireAssistSkillEffect(SkillEffectTiming effectTiming, int currRound, BattleReport battleReport, SkillEffectConfig skillEffectConfig) {
		for (int i = 0; i < alivePos.size(); i++) {
			BattleCharacter character = this.characters.get(alivePos.get(i));
			FootContext fcx = new FootContext(currRound, effectTiming, BattleAttackType.NONE, character, this, BattleTargetRange.DEFAULT, null, battleReport, skillEffectConfig);
			character.fireAssistSkillEffect(fcx);
		}
	}
	/**
	 * 施放部队的辅助技能效果
	 * @param effectTiming SkillEffectTiming
	 * @param currRound 当前回合
	 */
	public void fireAssistSkillEffect(SkillEffectTiming effectTiming, int currRound, BattleReport battleReport, SkillEffectConfig skillEffectConfig, BattleCharacter battleCharacter) {
		for (int i = 0; i < alivePos.size(); i++) {
			BattleCharacter character = this.characters.get(alivePos.get(i));
			if(character.getId().equals(battleCharacter.getId())){
				continue;
			}
			FootContext fcx = new FootContext(currRound, effectTiming, BattleAttackType.NONE, character, this, BattleTargetRange.DEFAULT, null, battleReport, skillEffectConfig);
			character.fireAssistSkillEffect(fcx);
			character.fireBuffEffects(currRound, effectTiming, battleReport, skillEffectConfig , this);
		}
	}
	/**
	 * 施放部队的状态效果
	 * @param stateTiming SkillEffectTiming
	 * @param currRound 当前回合
	 */
	public void fireBuffEffect(SkillEffectTiming stateTiming, int currRound, BattleReport battleReport, SkillEffectConfig skillEffectConfig) {
		for (int i = 0; i < alivePos.size(); i++) {
			BattleCharacter character = this.characters.get(alivePos.get(i));
			character.fireBuffEffects(currRound, stateTiming, battleReport, skillEffectConfig , this);
		}
	}
	/**
	 * 部队阵亡
	 * @return true/false
	 */
	public boolean isDead() {
		return getAlivePos().size() <= 0;
	}
	/**
	 * 得到出手角色
	 */
	public BattleCharacter getAttacker(int attackerPos){
		if(alivePos.contains(attackerPos)){
			return characters.get(attackerPos) ;
		}
		return null;
	}
	/**
	 * 得到对应的角色
	 */
	public BattleCharacter getCharacter(int attackerPos){
		return characters.get(attackerPos) ;
	}
	/**
	 * 移除死亡的角色
	 */
	public void removeDeadPos(Integer deadPos){
		this.alivePos.remove(deadPos);
		this.unityPos.remove(deadPos);
	}
	/**
	 * 当前位置是否有存活角色
	 */
	public boolean isAlive(int pos){
		return this.alivePos.contains(pos);
	}
	/**
	 * 得到当前存活低于指定血量的角色
	 */
	public List<Integer> getAliveHp(int hp){
		List<Integer> aliveHp = new ArrayList<Integer>();
		for (int i = 0; i < this.alivePos.size(); i++) {
			BattleCharacter battleCharacter = this.characters.get(this.alivePos.get(i));
			if(battleCharacter != null && battleCharacter.getBattleAttr().hp <= hp){
				if(aliveHp == null){
				}
				aliveHp.add(battleCharacter.getTeamPosition());
			}
		}
		return aliveHp;
	}
	/**
	 * 得到当前存活最低的角色
	 */
	public List<Integer> getAliveHpLimit(int size){
		List<Integer> aliveHp = new ArrayList<Integer>(size);
		List<BattleCharacter> battleCharacters = new ArrayList<BattleCharacter>();
		for (int i = 0; i < this.alivePos.size(); i++) {
			BattleCharacter battleCharacter = this.characters.get(this.alivePos.get(i));
			if(battleCharacter != null && !battleCharacter.isDie()){
				battleCharacters.add(battleCharacter);
			}
		}
		sortAliveHp(battleCharacters);
		for (int i = 0; i < battleCharacters.size(); i++) {
			aliveHp.add(battleCharacters.get(i).getTeamPosition());
			if(aliveHp.size() >= size){
				break;
			}
		}
		return aliveHp;
	}
	/**
	 * 得到当前存活最高的角色
	 */
	public List<Integer> getAliveHpTopLimit(int size){
		List<Integer> aliveHp = new ArrayList<Integer>(size);
		List<BattleCharacter> battleCharacters = new ArrayList<BattleCharacter>();
		for (int i = 0; i < this.alivePos.size(); i++) {
			BattleCharacter battleCharacter = this.characters.get(this.alivePos.get(i));
			if(battleCharacter != null && !battleCharacter.isDie()){
				battleCharacters.add(battleCharacter);
			}
		}
		sortAliveHp(battleCharacters);
		for (int i = battleCharacters.size()-1; i >= 0; i--) {
			aliveHp.add(battleCharacters.get(i).getTeamPosition());
			if(aliveHp.size() >= size){
				break;
			}
		}
		return aliveHp;
	}
	private  void sortAliveHp(List<BattleCharacter> battleCharacters) {
		Collections.sort(battleCharacters, new Comparator<BattleCharacter>() {
			@Override
			public int compare(BattleCharacter o1, BattleCharacter o2) {
				int o1Flag = (o1.getInitHp()-o1.getBattleAttr().hp) > 0?1:0;
				int o2Flag = (o2.getInitHp()-o2.getBattleAttr().hp) > 0?1:0;
				if (o1Flag > o2Flag) {
					return -1;
				}
				if (o1Flag < o2Flag) {
					return 1;
				}
				if (o1.getBattleAttr().hp < o2.getBattleAttr().hp) {
					return -1;
				}
				if (o1.getBattleAttr().hp > o2.getBattleAttr().hp) {
					return 1;
				}
				return 1;
			}
			
		});
	}
	/**
	 * 得到当前存活特定职业的角色
	 */
	public List<Integer> getAliveVocation(int[] vocation){
		List<Integer> aliveHp = new ArrayList<Integer>();
		for (int i = 0; i < this.alivePos.size(); i++) {
			BattleCharacter battleCharacter = this.characters.get(this.alivePos.get(i));
			if(battleCharacter != null && ArrayUtils.contains(vocation, battleCharacter.getHeroVocation())){
				aliveHp.add(battleCharacter.getTeamPosition());
			}
		}
		return aliveHp;
	}
	/**
	 * 得到当前存活特定兵种的角色
	 */
	public List<Integer> getAliveArmyType(int[] armyType){
		List<Integer> aliveHp = new ArrayList<Integer>();
		for (int i = 0; i < this.alivePos.size(); i++) {
			BattleCharacter battleCharacter = this.characters.get(this.alivePos.get(i));
			if(battleCharacter != null && ArrayUtils.contains(armyType, battleCharacter.getArmType())){
				aliveHp.add(battleCharacter.getTeamPosition());
			}
		}
		return aliveHp;
	}
	/**
	 * @description:得到当前存活角色列表	
	 * @return Collection<BattleCharacter>
	 */
	public List<BattleCharacter> getAliveCharacters(){
		List<BattleCharacter> list = new ArrayList<BattleCharacter>();
		for (int i = 0; i < this.alivePos.size(); i++) {
			BattleCharacter battleCharacter = characters.get(alivePos.get(i));
			if(battleCharacter != null && !battleCharacter.isDie()){
				list.add(battleCharacter);
			}
		}
		return list;
	}
	
	/**
	 * @description:随机得到指定数量存活角色列表	
	 * @return Collection<BattleCharacter>
	 */
	@JsonIgnore
	public List<BattleCharacter> getRandomAliveCharacters(int num){
		List<BattleCharacter> list = new ArrayList<BattleCharacter>();
		for (int i = 0; i < this.alivePos.size(); i++) {
			BattleCharacter battleCharacter = characters.get(alivePos.get(i));
			if(battleCharacter != null && !battleCharacter.isDie()){
				list.add(battleCharacter);
			}
		}
		Collections.shuffle(list);
		List<BattleCharacter> result = new ArrayList<BattleCharacter>(num);
		for (int i = 0; i < list.size(); i++) {
			if(result.size() >= num){
				 break;
			}
			result.add(list.get(i));
		}
		return result;
	}
	
	/**
	 * @description:随机得到指定数量武将	
	 * @param count
	 * @return
	 */
	public List<BattleCharacter> getAliveCharacters(int count){
		if(this.alivePos.size() <= count){
			return getAliveCharacters();
		}
		List<BattleCharacter> list = new ArrayList<BattleCharacter>();
		List<Integer> alivePos = new ArrayList<Integer>(this.alivePos);
		for (int i = 0; i < count; i++) {
			int index = RandomUtil.betweenValue(0, alivePos.size() - 1);
			Integer pos = alivePos.get(index);
			alivePos.remove(pos);
			BattleCharacter battleCharacter = characters.get(pos);
			if(battleCharacter != null && !battleCharacter.isDie())
				list.add(battleCharacter);
		}
		return list;
	}
	/**
	 * @description:得到当前存活角色列表	
	 * @return Collection<BattleCharacter>
	 */
	public List<BattleCharacter> getAliveCharacters(List<Integer> poslist){
		List<BattleCharacter> list = new ArrayList<BattleCharacter>();
		for (int i = 0; i < poslist.size(); i++) {
			BattleCharacter battleCharacter = characters.get(poslist.get(i));
			if(battleCharacter != null && !battleCharacter.isDie()){
				list.add(battleCharacter);
			}
		}
		return list;
	}
	/**
	 * @description:根据技能效果释放目标返回指定角色	
	 * @param attackerPos 攻击者阵形位置
	 * @param attackRange 技能攻击范围
	 * @param defenders 具体的位置
	 * @return
	 */
	public List<BattleCharacter> getAppointCharacters(Integer attackerPos,
			BattleTargetRange attackRange, List<Integer> defenders) {
		List<BattleCharacter> list = null;
		if(defenders != null && defenders.size() > 0){
			list = new ArrayList<BattleCharacter>();
			for (int i = 0; i < defenders.size(); i++) {
				BattleCharacter battleCharacter = characters.get(defenders.get(i));
				if(battleCharacter != null && !battleCharacter.isDie()){
					list.add(battleCharacter);
				}
			}
		}else if (BattleTargetRange.DEFAULT.equals(attackRange)){
			list = new ArrayList<BattleCharacter>(MIN_FIGHT_POS);
			Integer[] posOrders = getTargetPosOrders(attackerPos);
			int[] pos = getBattlePos();
			for (int i = 0; i < posOrders.length; i++) {
				int index = posOrders[i]-1;
				if(alivePos.contains(pos[index])){
					BattleCharacter battleCharacter = characters.get(pos[index]);
					if(battleCharacter != null && !battleCharacter.isDie()){
						list.add(battleCharacter);
						break;
					}
				}
			}
			
		}
		return list;
	}
	/**
	 * 得到除攻击角色外 合击出击角色列表
	 */
	public List<BattleCharacter> getAlliedAttacker(int curRound, BattleCharacter character){
		List<BattleCharacter> list = new ArrayList<BattleCharacter>();
		for (int i = 0; i < this.alivePos.size(); i++) {
			BattleCharacter battleCharacter = characters.get(alivePos.get(i));
			if(battleCharacter != null && !battleCharacter.isDie() && !battleCharacter.getId().equals(character.getId())){
				AlliedAttackBuff alliedAttackBuff = battleCharacter.getBuff().getAlliedAttackBuff();
				if(alliedAttackBuff != null && alliedAttackBuff.getPersistRound(curRound) > 0 ){
					list.add(battleCharacter);
				}
			}
		}
		return list;
	}
	/**
	 * @description:得到本对阵容	
	 * @return
	 */
	private int[] getBattlePos(){
		if(this.battleTeam.equals(BattleTeam.OFFENSE_TEAM)){
			return BattleRule.OFFENSE_POS;
		}
		return BattleRule.DEFENSE_POS;
	}
	/**
	 * 战斗单位最大出战位置
	 */
	public static final int MAX_FIGHT_POS = 6;
	
	/**
	 * 战斗单位最小出战位置
	 */
	public static final int MIN_FIGHT_POS = 1;
	
	/**
	 * 战斗单位中间出战位置
	 */
	final static Integer[][] ROWS = {{1,2,3,4,5,6},{2,1,3,5,4,6},{3,2,1,6,5,4},{1,2,3,4,5,6},{2,1,3,5,4,6},{3,2,1,6,5,4}};
	/**
	 * 取得攻击目标范围序列
	 * @param currPos 当前位置
	 * @return List<Integer>
	 */
	private static Integer[] getTargetPosOrders(int currPos) {
		if (currPos < MIN_FIGHT_POS || currPos > MAX_FIGHT_POS) {
			return ROWS[0];
		}
		return ROWS[currPos-1];
	}
	/**
	 * @description:转成客户端显示对象	
	 * @return
	 */
	public BattleGroupDto toBattleGroupDto(){
		BattleGroupDto battleGroupDto = new BattleGroupDto(battleTeam, dander, danderMax, key, playerName, playerLevel, playerHeadId, npcPic, ability, this.first, this.totemAttrDto, this.horseAttrDto, this.netherwingAttrDto);
		Collection<BattleCharacter> collection = characters.values();
		for (BattleCharacter battleCharacter : collection) {
			battleGroupDto.addBattleCharacterDto(battleCharacter.toBattleCharacterDto());
		}
		return battleGroupDto;
	}
	/**
	 * 得到主将技能的堆叠次数
	 */
	public int getGeneralSkillCount(int skillId){
		Integer count = generalSkillCount.get(skillId);
		if(count == null){
			count = 0;
		}
		return count;
	}
	/**
	 * @description:得到阵营的克制关系
	 * @param heroCamp
	 * @return
	 */
	public double getCampAgainstEffect(int heroCamp){
		if(againstEffectMap == null || !againstEffectMap.containsKey(heroCamp)){
			return 0;
		}
		return againstEffectMap.get(heroCamp);
	}
	public boolean isFirst() {
		return first;
	}
	public void setFirst(boolean first) {
		this.first = first;
	}
	public Map<Integer, Integer> getGeneralSkillCount() {
		return generalSkillCount;
	}
	public TotemAttrDto getTotemAttrDto() {
		return totemAttrDto;
	}
	public void setTotemAttrDto(TotemAttrDto totemAttrDto) {
		this.totemAttrDto = totemAttrDto;
	}
	public HorseAttrDto getHorseAttrDto() {
		return horseAttrDto;
	}
	public void setHorseAttrDto(HorseAttrDto horseAttrDto) {
		this.horseAttrDto = horseAttrDto;
	}
	public NetherwingAttrDto getNetherwingAttrDto() {
		return netherwingAttrDto;
	}
	public void setNetherwingAttrDto(NetherwingAttrDto netherwingAttrDto) {
		this.netherwingAttrDto = netherwingAttrDto;
	}
	public int getJunWeiLevel() {
		return junWeiLevel;
	}
	public void setJunWeiLevel(int junWeiLevel) {
		this.junWeiLevel = junWeiLevel;
	}
	public CharacterType getCharacterType() {
		return characterType;
	}
	public void setCharacterType(CharacterType characterType) {
		this.characterType = characterType;
	}
}

