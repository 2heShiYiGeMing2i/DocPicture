package com.xx.dev.event;

import com.xx.common.event.Event;

/**
 * 消费事件
 * 
 * @author along
 */
public class ConsumeEvent {
	
	/**
	 * 消费事件
	 */
	public static final String NAME = "PLAYER:CONSUME";
	
	/**
	 * 玩家id
	 */
	private long playerId;
	
	/**
	 * 金币
	 */
	private int gold;
	
	/**
	 * 内币
	 */
	private int rmb;
	
	/**
	 * 返还金币
	 */
	private int fundGold;
	
	public static Event<ConsumeEvent> valueOf(long playerId, int gold, int rmb, int fundGold) {
		ConsumeEvent consumeEvent = new ConsumeEvent();
		consumeEvent.playerId = playerId;
		consumeEvent.gold = gold;
		consumeEvent.rmb = rmb;
		consumeEvent.fundGold = fundGold;
		return new Event<ConsumeEvent>(NAME, consumeEvent);
	}
	
	public long getPlayerId() {
		return playerId;
	}

	public void setPlayerId(long playerId) {
		this.playerId = playerId;
	}

	/**
	 * 取得总数
	 * @return int
	 */
	public int getTotalAmount() {
		return this.gold + this.rmb + this.fundGold;
	}
	
	public int getGold() {
		return gold;
	}

	public void setGold(int gold) {
		this.gold = gold;
	}

	public int getRmb() {
		return rmb;
	}

	public void setRmb(int rmb) {
		this.rmb = rmb;
	}

	public int getFundGold() {
		return fundGold;
	}

	public void setFundGold(int fundGold) {
		this.fundGold = fundGold;
	}
	
}
