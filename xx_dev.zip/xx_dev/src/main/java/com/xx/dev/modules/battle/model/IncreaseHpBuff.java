/**
 * @file:IncreaseHpBuff.java
 * @author:David
 **/
package com.xx.dev.modules.battle.model;

import com.xx.dev.modules.skill.model.basedb.Skill;
import com.xx.dev.modules.skill.model.basedb.SkillEffect;

/**
 * @class:IncreaseHpBuff
 * @description:
 * @author:David
 * @version:v1.0
 * @date:2013-4-29
 **/
public class IncreaseHpBuff extends AbstractBuff {
	/** 技能类 **/
	private Skill skill;
	/** 技能效果类 **/
	private SkillEffect skillEffect;
	/** 技能等级 **/
	private int skillLevel;
	/** 低级技能等级 **/
	private int lowSkillLevel;
	/** 技能释放者 **/
	private BattleCharacter attacker;

	public IncreaseHpBuff(Skill skill, SkillEffect skillEffect, int skillLevel, int lowSkillLevel, double effectBase,
			int startRound, int persistRound, BattleCharacter attacker) {
		super(0, effectBase, 0, 0, startRound,
				persistRound);
		this.skill = skill;
		this.skillEffect = skillEffect;
		this.skillLevel = skillLevel;
		this.lowSkillLevel = lowSkillLevel;
		this.attacker = attacker;
	}
	
	public SkillEffect getSkillEffect() {
		return skillEffect;
	}

	public void setSkillEffect(SkillEffect skillEffect) {
		this.skillEffect = skillEffect;
	}

	public int getSkillLevel() {
		return skillLevel;
	}

	public void setSkillLevel(int skillLevel) {
		this.skillLevel = skillLevel;
	}

	public int getLowSkillLevel() {
		return lowSkillLevel;
	}

	public void setLowSkillLevel(int lowSkillLevel) {
		this.lowSkillLevel = lowSkillLevel;
	}

	public BattleCharacter getAttacker() {
		return attacker;
	}

	public void setAttacker(BattleCharacter attacker) {
		this.attacker = attacker;
	}
	
	public Skill getSkill() {
		return skill;
	}

	public void setSkill(Skill skill) {
		this.skill = skill;
	}

	/**
	 * @description:重新赋值	
	 * @param attrType
	 * @param value
	 * @param startRound
	 * @param persistRound
	 */
	public void reflush(Skill skill, SkillEffect skillEffect, int skillLevel, int lowSkillLevel, double effectBase,
			int startRound, int persistRound, BattleCharacter attacker) {
		this.effectBase = effectBase;
		this.startRound = startRound;
		this.persistRound = persistRound;
		this.skill = skill;
		this.skillEffect = skillEffect;
		this.skillLevel = skillLevel;
		this.lowSkillLevel = lowSkillLevel;
		this.attacker = attacker;
	}
}

