package com.xx.dev.modules.blackmarket.handler;

import com.xx.dev.constant.CommonConstant;

/**
 * 黑市模块状态码
 * 
 * @author Along
 *
 */
public interface BlackMarketResult extends CommonConstant {

	/**
	 * 没有商品可以购买
	 */
	int NO_GOODS_CAN_BUY = -10001;
	
	/**
	 * 已经购买过该物品
	 */
	int HAD_BUY_GOODS = -10002;
	
	/**
	 * 黑市积分不足
	 */
	int NO_ENOUGH_INTERGAL = -10003;
	
	/**
	 * 商品没有开放
	 */
	int GOODS_NO_OPEN = -10004;
	
	/**
	 * 购买数量限制
	 */
	int BUY_AMOUNT_LIMIT = -10005;
	
	/**
	 * 黑市等级限制
	 */
	int MARKET_LEVEL_LIMIT = -10006;
	
}
