/**
 * @file:BattleBigRound.java
 * @author:David
 **/
package com.xx.dev.modules.battle.model;
/**
 * @class:BattleBigRound
 * @description:
 * @author:David
 * @version:v1.0
 * @date:2014-1-10
 **/
public class BattleBigRound {
	/** 当前大回合数 */
	private int currRound;
	/** 进攻方血量变化值 **/
	private BattleAttrChanges attackerChanges;
	/** 进攻方血量变化值 **/
	private BattleAttrChanges defenderChanges;
	
	public BattleBigRound(int currRound) {
		super();
		this.currRound = currRound;
	}
	
	public int getCurrRound() {
		return currRound;
	}
	public void setCurrRound(int currRound) {
		this.currRound = currRound;
	}
	public BattleAttrChanges getAttackerChanges() {
		return attackerChanges;
	}
	public void setAttackerChanges(BattleAttrChanges attackerChanges) {
		this.attackerChanges = attackerChanges;
	}
	public BattleAttrChanges getDefenderChanges() {
		return defenderChanges;
	}
	public void setDefenderChanges(BattleAttrChanges defenderChanges) {
		this.defenderChanges = defenderChanges;
	}
	
}

