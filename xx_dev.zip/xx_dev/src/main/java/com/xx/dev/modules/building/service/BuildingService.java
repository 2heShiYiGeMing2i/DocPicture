package com.xx.dev.modules.building.service;

import java.util.List;

import com.xx.dev.model.Result;
import com.xx.dev.modules.building.entity.PlayerBuilding;
import com.xx.dev.modules.building.model.PlayerBuildingDto;

/**
 * 主城建筑服务接口
 * 
 * @author Along
 *
 */
public interface BuildingService {

	/**
	 * 返回主城开放的建筑
	 * @param playerId 玩家id
	 * @return
	 */
	public List<PlayerBuildingDto> getBuildingsAction(long playerId);
	
	/**
	 * 建筑升级
	 * @param playerId 玩家id
	 * @param buildingId 建筑id
	 * @return
	 */
	public Result<PlayerBuildingDto> upgradeLevelAction(long playerId, int buildingId);
	
	/**
	 * 升级建筑品质
	 * @param playerId 玩家id
	 * @param buildingId 建筑id
	 * @return
	 */
	public Result<PlayerBuildingDto> upgradeQualityAction(long playerId, int buildingId);
	
	/**
	 * 返回建筑的等级	
	 * @param playerId 玩家id
	 * @param buildingId 建筑Id
	 * @return
	 */
	public int getBuildingLevel(long playerId, int buildingId);
	
	/**
	 * 返回建筑的品质	
	 * @param playerId 玩家id
	 * @param buildingId 建筑Id
	 * @return
	 */
	public int getBuildingQuality(long playerId, int buildingId);

	/**
	 * 返回玩家所有的主城建筑列表
	 * @param playerId 玩家id
	 * @return
	 */
	public List<PlayerBuilding> getBuildings(long playerId);

	/**
	 * 进入主城
	 * @param playerId 玩家id
	 * @return
	 */
	public int enterCityAction(long playerId);

	/**
	 * 初始化建筑等级
	 * @param playerId 玩家id
	 */
	public void initPlayerBuildingLevel(long playerId);

	/**
	 * 返回建筑编号列表
	 * @param playerId 玩家id
	 * @param buildingType 建筑类型id
	 * @return
	 */
	public List<Integer> getBuildingIds(long playerId, int buildingType);
	
}
