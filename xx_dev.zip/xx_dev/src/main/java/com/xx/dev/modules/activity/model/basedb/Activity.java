package com.xx.dev.modules.activity.model.basedb;

import com.xx.common.basedb.anno.Id;
import com.xx.common.basedb.anno.Index;
import com.xx.common.basedb.anno.Resource;
import com.xx.dev.constant.IndexName;


/**
 * 活动基础数据表
 * 
 * @author bingshan
 */
@Resource
public class Activity {
	
	/**
	 * 主键id
	 */
	@Id
	private int id;
	
	/**
	 * 活动名称
	 */
	private String name;
	
	/**
	 * 开关id
	 */
	@Index(name = IndexName.ACTIVITY_OPEN_INDEX, order = 0)
	private String openId;
	
	/**
	 * 活动类型, 0-普通  1-任务活动
	 */
	@Index(name = IndexName.ACTIVITY_TYPE_INDEX, order = 0)
	private int type = 0;
	
	/**
	 * 是否任务活动
	 * @return boolean
	 */
	public boolean isTaskActivity() {
		return this.type == 1;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getOpenId() {
		return openId;
	}

	public void setOpenId(String openId) {
		this.openId = openId;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}
}
