package com.xx.dev.modules.armygrouptrain.handler;

import com.xx.dev.modules.common.handler.CommonResult;

public interface ArmyGroupTrainResult extends CommonResult{

	/**
	 *您未参加军团试炼
	 */
	int PLAYER_UN_PARTICIPATE = -10001;
	
	/**
	 *军团未参加军团试炼活动
	 */
	int GROUP_UN_PARTICIPATE = -10002;
	
	/**
	 *活动尚未开放
	 */
	int ACTIVITY_UN_OPEN = -10003;
	
	/**
	 *该军队不存在
	 */
	int ARMY_UN_EXISTS = -10004;
	
	/**
	 *已經通關
	 */
	int AREA_BREAKED = -10005;
	
	/**
	 *该军队已经被击杀
	 */
	int ARMY_KILLED = -10006;
	
	/**
	 *在冷卻時間段
	 */
	int IN_COOL_TIME = -10007;
	
	/**
	 *你沒有加入軍團
	 */
	int NOT_IN_ARMY_GROUP = -10008;
	
	/**
	 *試煉活動未開始
	 */
	int ACTIVITY_NOT_START = -10009;
	
	/**
	 *還沒有到刷怪開始時間
	 */
	int ATTACK_NOT_START = -10010;
	
	
}
