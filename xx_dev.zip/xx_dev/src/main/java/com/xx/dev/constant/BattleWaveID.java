/**
 * @file:BattleWaveID.java
 * @author:David
 **/
package com.xx.dev.constant;
/**
 * @class:BattleWaveID
 * @description:使用多波战斗的玩法ID汇总
 * @author:David
 * @version:v1.0
 * @date:2013-8-21
 **/
public interface BattleWaveID {
	/**
	 * 默认多波ID玩法ID，如果未指定就穿-1
	 */
	public static int DEFAULT_ID = -1;
	
	/**
	 * 单人副本
	 */
	public static int CHAPTER = 801;
	
	/**
	 * 新精英副本
	 */
	public static int NEW_CREAM = 4601;
	
	/**
	 * 征战天下
	 */
	public static int JOURNEY = 2101;
	
	/**
	 * 攻城掠地
	 */
	public static int PLUNDER = 2701;
	
	/**
	 * 竞技场
	 */
	public static int ARENA = 2801;
	
	/**
	 * 群雄争霸
	 */
	public static final int CHAMPION = 3001;
	
	/**
	 * 军团抢粮
	 */
	public static int PLUNDER_FOOD = 5201;
	
	/**
	 * 奴隶系统
	 */
	public static int SLAVE = 5001;
	
	/**
	 * 富甲天下Boss战斗
	 */
	public static int LOOP_BOSS = 5401;
	
	/**
	 * 摸金系统
	 */
	final int TREASURE = 5501;
	
	/**
	 * vip副本
	 */
	final int VIP_FUBEN = 5801;
	
	/**
	 * 决战长安
	 */
	public static int DECISIVE_CHANG_AN = 6001;
	
	/**
	 * 多人副本
	 */
	final int MULTIFUBEN = 6601;
	
	/**
	 * 积分活动-打怪兽
	 */
	public static int INTEGRATL_ACTIVITY = 6701;
	
	/**
	 * 跨服群雄争霸
	 */
	public static final int KF_CHAMPION = 8101;
	
	/**
	 * 跨服掠夺
	 */
	final int KF_LOOT = 9101;
	
	/**
	 * 军团试炼
	 */
	final int ARMY_GROUP_TRAIN = 9301;
	
	/**
	 * 风云争霸
	 */
	final int FUNG_WAN = 9401;
	
	/**
	 * 跨服天梯
	 */
	final int KF_LADDER = 10101;
	
}