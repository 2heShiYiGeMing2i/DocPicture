package com.xx.dev.event;

import com.xx.common.event.Event;
import com.xx.dev.constant.RewardType;


/**
 * 充值事件
 * 
 * @author bingshan
 */
public class ChargeEvent {
	
	/**
	 * 充值事件
	 */
	public static final String NAME = "CHARGE:CHARGE";
	
	/**
	 * 玩家id
	 */
	private long playerId;
	
	/**
	 * 奖励类型(金币, 内币)
	 */
	private RewardType rewardType;
	
	/**
	 * 充值数量
	 */
	private int addCount;
	
	public static Event<ChargeEvent> valueOf(long playerId, RewardType rewardType, int addCount) {
		ChargeEvent e = new ChargeEvent();
		e.playerId = playerId;
		e.rewardType = rewardType;
		e.addCount = addCount;
		return new Event<ChargeEvent>(NAME, e);
	}

	public long getPlayerId() {
		return playerId;
	}

	public void setPlayerId(long playerId) {
		this.playerId = playerId;
	}

	public RewardType getRewardType() {
		return rewardType;
	}

	public void setRewardType(RewardType rewardType) {
		this.rewardType = rewardType;
	}

	public int getAddCount() {
		return addCount;
	}

	public void setAddCount(int addCount) {
		this.addCount = addCount;
	}

}
