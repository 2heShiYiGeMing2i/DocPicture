package com.xx.dev.modules.card.service.impl;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.xx.common.basedb.BasedbService;
import com.xx.common.db.cache.DbCachedService;
import com.xx.common.util.DateUtil;
import com.xx.common.utility.lock.ChainLock;
import com.xx.common.utility.lock.LockUtils;
import com.xx.dev.constant.GameRuleID;
import com.xx.dev.constant.GoldRuleID;
import com.xx.dev.constant.LogSource;
import com.xx.dev.constant.RewardType;
import com.xx.dev.model.Result;
import com.xx.dev.modules.card.entity.PlayerCard;
import com.xx.dev.modules.card.handler.PlayerCardResult;
import com.xx.dev.modules.card.model.PlayerCardDto;
import com.xx.dev.modules.card.model.basedb.PlayerCardConfig;
import com.xx.dev.modules.card.service.PlayerCardRuleService;
import com.xx.dev.modules.card.service.PlayerCardService;
import com.xx.dev.modules.item.model.basedb.Item;
import com.xx.dev.modules.item.service.ItemService;
import com.xx.dev.modules.loop.service.LoopService;
import com.xx.dev.modules.player.entity.Player;
import com.xx.dev.modules.reward.action.RewardActionSet;
import com.xx.dev.modules.reward.model.SimpleReward;
import com.xx.dev.modules.reward.result.ValueResultSet;
import com.xx.dev.modules.reward.service.RewardService;
import com.xx.dev.modules.vip.service.VipService;
import com.xx.dev.utils.GameRuleService;

/**
 * 月卡相关逻辑处理实现
 * 
 * 
 * 月卡的初步实现
 * 1、基础数据表：{@link PlayerCardConfig}
 * 2、用户数据表：{@link PlayerCard} 用于记录玩家月卡的激活状态和结束时间以及相关领取状态和时间
 * 3、执行的操作：开通月卡、领取buffer、领取体力等
 * 
 * @author jy
 *
 */
@Component
public class PlayerCardServiceImpl implements PlayerCardService{

	private static final Logger logger = LoggerFactory.getLogger(PlayerCardServiceImpl.class);
	
	@Autowired
	private DbCachedService dbCachedService;
	
	@Autowired
	private PlayerCardRuleService playerCardRuleService;
	
	@Autowired
	private RewardService rewardService;
	
	@Autowired
	private GameRuleService gameRuleService;
	
	@Autowired
	private BasedbService basedbService;
	
	@Autowired
	private LoopService loopService;
	
	@Autowired
	private VipService vipService;
	
	@Autowired
	private ItemService itemService;
	
	@Override
	public Result<PlayerCardDto> getPlayerCardInfo(long playerId) {
		Player player = dbCachedService.get(playerId, Player.class);
		if(player == null){
			return Result.Error(PlayerCardResult.PLAYER_NOT_EXISTS);
		}
		PlayerCard playerCard = getPlayerCard(playerId);
		//如果过期则重置月卡状态
		if(playerCard.isOpen()){
			Date now = new Date();
			if(now.compareTo(playerCard.getEndTime()) > 0){
				ChainLock chainLock = LockUtils.getLock(player);
				chainLock.lock();
				try{
					if(now.compareTo(playerCard.getEndTime()) > 0){//已经过期
						playerCard.reset();
						dbCachedService.submitUpdated2Queue(playerCard.getId(), PlayerCard.class);
						PlayerCardDto dto = PlayerCardDto.valueOf(playerCard);
						return Result.Success(dto);
					}
				}
				catch(Exception e){
					logger.error(e.getMessage());
				}
				finally{
					chainLock.unlock();
				}
			}
			if(!DateUtil.isToday(playerCard.getGetTime()) || playerCard.getFjtxGetState() == 1){//非今日或者富甲天下已经完成，则需要重置今日月卡领取状态或者重新判断是否有可完成的富甲天下任务
				ChainLock chainLock = LockUtils.getLock(player);
				chainLock.lock();
				try{
					boolean ischange = false;
					if(!DateUtil.isToday(playerCard.getGetTime())){//状态没有重置
						playerCard.setBufferGetState(0);
						playerCard.setEnergyGetState(0);
						ischange = true;
					}
					if(loopService.hasLoop(playerId) && playerCard.getFjtxGetState() == 1){//有富甲天下任务做完成
						playerCard.setFjtxGetState(0);
						ischange = true;
					}
					if(ischange){
						dbCachedService.submitUpdated2Queue(playerCard.getId(), PlayerCard.class);
					}
				}
				catch(Exception e){
					logger.error(e.getMessage());
				}
				finally{
					chainLock.unlock();
				}
			}
		}
		PlayerCardDto dto = PlayerCardDto.valueOf(playerCard);
		return Result.Success(dto);
	}

	private PlayerCard getPlayerCard(long playerId) {
		PlayerCard playerCard = dbCachedService.get(playerId, PlayerCard.class);
		if(playerCard == null){
			playerCard = PlayerCard.valueOf(playerId);
			playerCard = dbCachedService.submitNew2Queue(playerCard);//保证对象的一致性
		}
		return playerCard;
	}
	
	@Override
	public Result<PlayerCardDto> openPlayerCardWithGold(long playerId, int num) {
		if(num <= 0){
			return Result.Error(PlayerCardResult.PARAM_ERROR);
		}
		
		Player player = dbCachedService.get(playerId, Player.class);
		if(player == null){
			return Result.Error(PlayerCardResult.PLAYER_NOT_EXISTS);
		}
		
		PlayerCardConfig playerCardConfig = playerCardRuleService.getPlayerCardConfig();
		if(playerCardConfig == null){
			return Result.Error(PlayerCardResult.BASE_DATA_NOT_EXIST);
		}
		int itemId = gameRuleService.getAmountByID(GameRuleID.MONTH_CARD_ITEM_ID).intValue();
		Item item = basedbService.get(Item.class, itemId);
		if(item == null){
			logger.error("月卡道具不存在！");
			return Result.Error(PlayerCardResult.BASE_DATA_NOT_EXIST);
		}
		
		int cost = gameRuleService.getGoldById(GoldRuleID.PLAYER_CARD_COST);
		if(cost <= 0){
			logger.error("月卡购买消费元宝数为0！");
			return Result.Error(PlayerCardResult.BASE_DATA_NOT_EXIST);
		}
		int validDays = (int)(item.getPersistTime() / (1000 * 24 * 60 * 60));
		if(validDays <= 0){
			logger.error("月卡有效时间小于等于0！");
			return Result.Error(PlayerCardResult.BASE_DATA_NOT_EXIST);
		}
		PlayerCard playerCard = getPlayerCard(playerId);
		int goldDiscount = 0;
		Result<PlayerCardDto> result = null;
		ChainLock chainLock = LockUtils.getLock(player);
		chainLock.lock();
		try{
			int needGold = cost * num;//需要的元宝
			int realCost = vipService.getGoldDiscountValue(player, needGold);//打折后的價格
			goldDiscount = needGold - realCost;
			SimpleReward reduce = new SimpleReward(RewardType.MONEY_RMB_GOLD, -realCost);
			RewardActionSet rewardActionSet = rewardService.tryRewards(playerId, reduce);
			if(rewardActionSet.isNotOK()){
				return Result.Error(rewardActionSet.getResultCode());
			}
			ValueResultSet valueResultSet = 
					rewardService.executeRewards(playerId, rewardActionSet, LogSource.PLAYER_CARD_BUY_WITH_GOLDS);
			
			openPlayerCard(playerCard, validDays * num);
			
			PlayerCardDto dto = PlayerCardDto.valueOf(playerCard);
			
			result = Result.Success(dto);
			result.put("valueResultSet", valueResultSet);
			result.put("goldDiscount", goldDiscount);
		}
		catch(Exception e){
			logger.error(e.getMessage());
		}
		finally{
			chainLock.unlock();
		}
		
		return result;
	}

	/**
	 * 开通月卡
	 * @param playerCard
	 * @param validDays
	 */
	private void openPlayerCard(PlayerCard playerCard, int validDays) {
		Date endTime;
		Date now = new Date();
		if(playerCard.isOpen() && now.compareTo(playerCard.getEndTime()) < 0){//还没有过期则取到期时间为起点追加一段时间
			endTime = DateUtil.add(playerCard.getEndTime(), validDays, 0, 0, 0);
		}
		else{//未开通或者已经到期则取现在时间为起点追加一段时间
			endTime = DateUtil.add(now, validDays, 0, 0, 0);
		}
		playerCard.setEndTime(endTime);
		playerCard.setIsOpen(1);
		dbCachedService.submitUpdated2Queue(playerCard.getId(), PlayerCard.class);
	}

	@Override
	public Result<PlayerCardDto> getEnergy(long playerId) {
		Player player = dbCachedService.get(playerId, Player.class);
		if(player == null){
			return Result.Error(PlayerCardResult.PLAYER_NOT_EXISTS);
		}
		PlayerCardConfig playerCardConfig = playerCardRuleService.getPlayerCardConfig();
		if(playerCardConfig == null){
			return Result.Error(PlayerCardResult.BASE_DATA_NOT_EXIST);
		}
		
		ChainLock chainLock = LockUtils.getLock(player);
		chainLock.lock();
		try{
			PlayerCard playerCard = getPlayerCard(playerId);
			if(!playerCard.isOpen()){//未开启
				return Result.Error(PlayerCardResult.PLAYER_CARD_UNOPEN);
			}
			Date now = new Date();
			if(now.compareTo(playerCard.getEndTime()) > 0){//已经过期
				return Result.Error(PlayerCardResult.PLAYER_CARD_DUE);
			}
			
			if(DateUtil.isToday(playerCard.getGetTime()) && playerCard.energyGeted()){//已完成
				return Result.Error(PlayerCardResult.PLAYER_CARD_ENERGY_REGETED);
			}
			
			if(DateUtil.isToday(playerCard.getGetTime()) && playerCard.energyGeted()){//已领取
				return Result.Error(PlayerCardResult.PLAYER_CARD_ENERGY_REGETED);
			}
			
			//TODO
			//是否需要有体力领取限制
			SimpleReward rewardEnergy = new SimpleReward(RewardType.ENERGY, playerCardConfig.getDailyPower());
			RewardActionSet rewardActonSet = this.rewardService.tryRewards(playerId, rewardEnergy);
			if (rewardActonSet.isNotOK()) {
				return Result.Error(rewardActonSet.getResultCode());
			}
			
			ValueResultSet valueResultSet = rewardService.executeRewards(playerId, rewardActonSet, LogSource.PLAYER_CARD_GET_ENERGY);
			
			playerCard.getEnergy(now);
			dbCachedService.submitUpdated2Queue(playerCard.getId(), PlayerCard.class);
			
			PlayerCardDto dto = PlayerCardDto.valueOf(playerCard);
			
			Result<PlayerCardDto> result = Result.Success(dto);
			result.put("valueResultSet", valueResultSet);
			return result;
		} catch(Exception e){
			logger.error(e.getMessage());
		} finally{
			chainLock.unlock();
		}
		return Result.Error(PlayerCardResult.FAILURE);
	}

	@Override
	public Result<PlayerCardDto> finishFJTX(long playerId) {
		Player player = dbCachedService.get(playerId, Player.class);
		if(player == null){
			return Result.Error(PlayerCardResult.PLAYER_NOT_EXISTS);
		}
		PlayerCardConfig playerCardConfig = playerCardRuleService.getPlayerCardConfig();
		if(playerCardConfig == null){
			return Result.Error(PlayerCardResult.BASE_DATA_NOT_EXIST);
		}
		PlayerCard playerCard = getPlayerCard(playerId);
		if(!playerCard.isOpen()){//未开启
			return Result.Error(PlayerCardResult.PLAYER_CARD_UNOPEN);
		}
		Date now = new Date();
		if(now.compareTo(playerCard.getEndTime()) > 0){//已经过期
			return Result.Error(PlayerCardResult.PLAYER_CARD_DUE);
		}
		
		if(DateUtil.isToday(playerCard.getGetTime()) && playerCard.finishFJTX()){//已完成
			return Result.Error(PlayerCardResult.PLAYER_CARD_FJTX_REGETED);
		}
		
		ChainLock chainLock = LockUtils.getLock(player);
		chainLock.lock();
		try{
			if(DateUtil.isToday(playerCard.getGetTime()) && playerCard.finishFJTX()){//已领取
				return Result.Error(PlayerCardResult.PLAYER_CARD_FJTX_REGETED);
			}
			//完成所有富甲天下的任务并获取奖励
			Result<String> rewardResult = loopService.completeLoop(playerId);
			
			playerCard.finishFJTX(now);
			dbCachedService.submitUpdated2Queue(playerCard.getId(), PlayerCard.class);
			
			PlayerCardDto dto = PlayerCardDto.valueOf(playerCard);
			Result<PlayerCardDto> result = Result.Success(dto);
			result.put("valueResultSet", rewardResult == null ? null : rewardResult.get("valueResultSet"));
			result.put("rewardString", rewardResult == null ? null : rewardResult.get("rewardString"));
			return result;
		} catch(Exception e){
			logger.error(e.getMessage());
		} finally{
			chainLock.unlock();
		}
		return Result.Error(PlayerCardResult.FAILURE);
	}

	@Override
	public Result<PlayerCardDto> getBuffer(long playerId) {
		Player player = dbCachedService.get(playerId, Player.class);
		if (player == null) {
			return Result.Error(PlayerCardResult.PLAYER_NOT_EXISTS);
		}
		
		PlayerCardConfig playerCardConfig = playerCardRuleService
				.getPlayerCardConfig();
		if (playerCardConfig == null) {
			return Result.Error(PlayerCardResult.BASE_DATA_NOT_EXIST);
		}
		
		ChainLock chainLock = LockUtils.getLock(player);
		chainLock.lock();
		try{
			PlayerCard playerCard = getPlayerCard(playerId);
			if (!playerCard.isOpen()) {// 未开启
				return Result.Error(PlayerCardResult.PLAYER_CARD_UNOPEN);
			}
			Date now = new Date();
			if (now.compareTo(playerCard.getEndTime()) > 0) {// 已经过期
				return Result.Error(PlayerCardResult.PLAYER_CARD_DUE);
			}
			
			if (DateUtil.isToday(playerCard.getGetTime()) && playerCard.bufferGeted()) {// 已领取
				return Result.Error(PlayerCardResult.PLAYER_CARD_BUFFER_REGETED);
			}
			
			int addBuffResult = this.itemService.addMonthCardBuff(playerId);
			if (addBuffResult != PlayerCardResult.SUCCESS) {// 添加月卡增益Buff失败
				return Result.Error(addBuffResult);
			}
			
			playerCard.getBuffer(now);
			dbCachedService.submitUpdated2Queue(playerCard.getId(), PlayerCard.class);
			
			return Result.Success(PlayerCardDto.valueOf(playerCard));
		} catch(Exception e){
			e.printStackTrace();
			logger.error(e.getMessage());
		} finally{
			chainLock.unlock();
		}
		return Result.Error(PlayerCardResult.FAILURE);
	}

	@Override
	public boolean isOpen(long playerId) {
		PlayerCard playerCard = getPlayerCard(playerId);
		Date now = new Date();
		if (playerCard.isOpen() && now.compareTo(playerCard.getEndTime()) < 0) {
			return true;
		}
		return false;
	}

	@Override
	public Result<String> openPlayerCardWithGood(long playerId, int days) {
		Player player = dbCachedService.get(playerId, Player.class);
		if(player == null){
			return Result.Error(PlayerCardResult.PLAYER_NOT_EXISTS);
		}
		
		PlayerCardConfig playerCardConfig = playerCardRuleService.getPlayerCardConfig();
		if(playerCardConfig == null){
			return Result.Error(PlayerCardResult.BASE_DATA_NOT_EXIST);
		}
		
		Result<String> result = null;
		ChainLock chainLock = LockUtils.getLock(player);
		chainLock.lock();
		try{
			PlayerCard playerCard = getPlayerCard(playerId);
			openPlayerCard(playerCard, days);
			result = Result.Success("");
		} finally{
			chainLock.unlock();
		}
		return result;
	}

}
