package com.xx.dev.constant;

/**
 * 登陆方式
 * 
 * @author along
 * 
 */
public enum LoginWay {

	/**
	 * 0-普通登陆
	 */
	NORMAL,

	/**
	 * 1-登陆器登陆
	 */
	LOGGER;

}