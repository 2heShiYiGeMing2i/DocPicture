/**
 * @file:Armageddon.java
 * @author:David
 **/
package com.xx.dev.modules.armageddon.model.basedb;

import java.util.ArrayList;
import java.util.List;

import com.xx.common.basedb.anno.Id;
import com.xx.common.basedb.anno.MinMax;
import com.xx.common.basedb.anno.Resource;
import com.xx.dev.modules.journey.model.HardType;

/**
 * @class:Armageddon
 * @description:大决战
 * @author:David
 * @version:v1.0
 * @date:2013-5-20
 **/
@Resource
public class Armageddon {
	public static final String MIN_MAX_ID = "MIN_MAX_ID";

	/**
	 * 技能基础数据id
	 */
	@Id
	@MinMax(name = MIN_MAX_ID)
	private int id;
	/** 以下字段不用填表 **/
	/**
	 * 简单据点id列表
	 */
	private List<Integer> areaList = new ArrayList<Integer>();
	/**
	 * 困难据点id列表
	 */
	private List<Integer> hardAreaList = new ArrayList<Integer>();

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public List<Integer> getAreaList() {
		return areaList;
	}

	public void setAreaList(List<Integer> areaList) {
		this.areaList = areaList;
	}
	
	public void addArea(int areaId, HardType hardType){
		switch (hardType) {
		case EASY:
			this.areaList.add(areaId);
			break;
		case HARD:
			this.hardAreaList.add(areaId);
			break;
		default:
			break;
		}
	}

	public List<Integer> getHardAreaList() {
		return hardAreaList;
	}

	public void setHardAreaList(List<Integer> hardAreaList) {
		this.hardAreaList = hardAreaList;
	}
	
	public List<Integer> getAreaList(HardType hardType){
		switch (hardType) {
		case EASY:
			return areaList;
		case HARD:
			return hardAreaList;
		default:
			return areaList;
		}
	}
}

