package com.xx.dev.modules.card.model.basedb;

import com.xx.common.basedb.anno.Id;
import com.xx.common.basedb.anno.Resource;
/**
 * 玩家月卡相关
 * @author jy
 *
 */
@Resource
public class PlayerCardConfig {

	public static final int PLAYER_CARD_ID = 1;
	
	/**
	 * 卡id
	 */
	@Id
	private int id;
	
//	/**
//	 * 使用道具购买的消耗
//	 */
//	private String buyCostGood;
//	
//	/**
//	 * 使用元宝购买的消耗
//	 */
//	private int buyCostGold;
//	
//	/**
//	 * 月卡的有效时间-天数
//	 */
//	private int validDays;
	
	/**
	 * 每日额外获取的体力
	 */
	private int dailyPower;
	
	/**
	 * buffer增加百分比-小数
	 */
	private double bufferPercent;
	
	/**
	 * buffer有效持续时间
	 * 分钟
	 */
	private int lastMinites;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

//	public String getBuyCostGood() {
//		return buyCostGood;
//	}
//
//	public void setBuyCostGood(String buyCostGood) {
//		this.buyCostGood = buyCostGood;
//	}

//	
//	public int getValidDays() {
//		return validDays;
//	}
//
//	public void setValidDays(int validDays) {
//		this.validDays = validDays;
//	}

	

	public double getBufferPercent() {
		return bufferPercent;
	}

	public int getDailyPower() {
		return dailyPower;
	}

	public void setDailyPower(int dailyPower) {
		this.dailyPower = dailyPower;
	}

	public void setBufferPercent(double bufferPercent) {
		this.bufferPercent = bufferPercent;
	}

	public int getLastMinites() {
		return lastMinites;
	}

	public void setLastMinites(int lastMinites) {
		this.lastMinites = lastMinites;
	}
	
	
}
