package com.xx.dev.constant;

import java.util.Date;

import com.xx.common.util.DatePattern;
import com.xx.common.util.DateUtil;

/**
 * 时间常量
 * 
 * @author Along
 * 
 */
public interface DateConstant {

	/**
	 * 一个很小的时间
	 */
	public static final Date MIN_DATE = DateUtil.string2Date(
			"2000-01-01 00:00:00", DatePattern.PATTERN_NORMAL);

	/**
	 * 一个很大的时间
	 */
	public static final Date MAX_DATE = DateUtil.string2Date(
			"2500-01-01 00:00:00", DatePattern.PATTERN_NORMAL);
}
