/**
 * @file:SysKey.java
 * @author:David
 **/
package com.xx.dev.constant;

import java.util.Collection;
import java.util.Date;

/**
 * @class:SysKey
 * @description:
 * @author:David
 * @version:v1.0
 * @date:2013-6-21
 **/
public enum SysKey {
	
	/**
	 * 服务器开张时间
	 */
	SERVER_OPEN_TIME("SERVER_OPEN_TIME", true, null),
	
	/**
	 * 服务器合服时间
	 */
	SERVER_COMBINE_TIME("SERVER_COMBINE_TIME", true, null),
	
	XUNLEI_VIP1_SEND_NUMBER("XUNLEI_VIP1_SEND_NUMBER", true, 1),
	
	XUNLEI_VIP2_SEND_NUMBER("XUNLEI_VIP2_SEND_NUMBER", true, 2);
	
	/**
	 * key的名称
	 */
	private String keyName = "";
	
	/**
	 * key的值
	 */
	private Object value;
	
	/**
	 * 是否持久化
	 */
	private boolean persistence;
	
	private SysKey(String keyName, boolean persistence, Object value){
		this.keyName = keyName;
		this.value = value;
		this.persistence = persistence;
	}
	
	public String getName(){
		return this.keyName;
	}
	
	public void setValue(Object value) {
		this.value = value;
	}
	
	public Object getValue() {
		return value;
	}
	
	public Boolean getBoolean(){
		return (Boolean)value;
	}
	
	public Number getNumber(){
		return (Number)value;
	}
	
	public Date getDate(){
		return (Date)value;
	}
	
	@SuppressWarnings("rawtypes")
	public Collection getCollection(){
		return (Collection)value; 
	}
	
	public boolean isPersistence() {
		return persistence;
	}

	public void setPersistence(boolean persistence) {
		this.persistence = persistence;
	}
	
}
