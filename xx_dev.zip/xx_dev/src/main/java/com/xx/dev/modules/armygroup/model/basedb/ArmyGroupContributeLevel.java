package com.xx.dev.modules.armygroup.model.basedb;

import com.xx.common.basedb.anno.Id;
import com.xx.common.basedb.anno.Resource;

/**
 * 军团贡献等级
 * 
 * @author Along
 *
 */
@Resource
public class ArmyGroupContributeLevel {

	/**
	 * 贡献等级
	 */
	@Id
	private int id;
	
	/**
	 * 所需贡献度
	 */
	private int contribute;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getContribute() {
		return contribute;
	}

	public void setContribute(int contribute) {
		this.contribute = contribute;
	}
	
}
