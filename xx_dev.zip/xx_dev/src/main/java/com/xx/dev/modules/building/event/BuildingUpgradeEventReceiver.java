package com.xx.dev.modules.building.event;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xx.common.basedb.BasedbService;
import com.xx.common.event.AbstractReceiver;
import com.xx.dev.modules.building.model.BuildingId;
import com.xx.dev.modules.building.model.basedb.CityElement;
import com.xx.dev.modules.tech.service.TechService;

/**
 * 主城建筑升级事件接收器
 * 
 * @author Along
 *
 */
@Service
public class BuildingUpgradeEventReceiver extends AbstractReceiver<BuildingUpgradeEvent> {

	@Autowired
	private BasedbService basedbService;
	
	@Autowired
	private TechService techService;
	
	//@Autowired
	//private DrillTechService drillTechService;
	
	@Override
	public String[] getEventNames() {
		return new String[] {BuildingUpgradeEvent.NAME};
	}

	@Override
	public void doEvent(BuildingUpgradeEvent event) {
		CityElement building = this.basedbService.get(CityElement.class, event.getBuildingId());
		if (building != null) {
			switch (building.getId()) {
			case BuildingId.GRAND_COUNCIL:// 军机处等级升级
				this.techService.pushCanUpgradeTech(event.getId(), event.getBuildingLevel());
				break;
				
			case BuildingId.DRILL:// 演武场等级升级
				//this.drillTechService.pushCanUpgradeDrillTech(event.getId(), event.getBuildingLevel());
				break;

			default:
				break;
			}
		}
	}

}
