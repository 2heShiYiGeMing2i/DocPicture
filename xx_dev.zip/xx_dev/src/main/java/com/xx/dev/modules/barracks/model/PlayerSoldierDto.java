package com.xx.dev.modules.barracks.model;


/**
 * 玩家空闲的兵DTO
 * 
 * @author Along
 *
 */
public class PlayerSoldierDto {

	/**
	 * 主键（玩家id）
	 */
	private long id;
	
	/**
	 * 兵阶
	 */
	private int star;
	
	/**
	 * 空闲的兵的人数
	 */
	private int amount;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public int getStar() {
		return star;
	}

	public void setStar(int star) {
		this.star = star;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}
	
}
