package com.xx.dev.modules.blackmarket.model.basedb;

import com.xx.common.basedb.anno.Id;
import com.xx.common.basedb.anno.Resource;

/**
 * 黑市积分兑换
 * 
 * @author Along
 *
 */
@Resource
public class BlackMarketChange {

	@Id
	private int id;
	
	/**
	 * 物品（奖励串格式）
	 */
	private String goods;
	
	/**
	 * 积分消耗（黑市积分）
	 */
	private int integralCost;
	
	/**
	 * 开放的建筑等级
	 */
	private int buildingLevel;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getGoods() {
		return goods;
	}

	public void setGoods(String goods) {
		this.goods = goods;
	}

	public int getIntegralCost() {
		return integralCost;
	}

	public void setIntegralCost(int integralCost) {
		this.integralCost = integralCost;
	}

	public int getBuildingLevel() {
		return buildingLevel;
	}

	public void setBuildingLevel(int buildingLevel) {
		this.buildingLevel = buildingLevel;
	}
	
}
