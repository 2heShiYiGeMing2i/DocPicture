package com.xx.dev.constant;

/**
 * 建筑的状态
 * 
 * @author Along
 *
 */
public enum BuildingStatus {

	/**
	 * 0-空闲中
	 */
	FREE,
	
	/**
	 * 1-升级中
	 */
	UPGRADE
	
}
