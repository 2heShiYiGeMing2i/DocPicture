package com.xx.dev.modules.armygrouptrain.model;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.mina.util.ConcurrentHashSet;

/**
 * 一個軍團的試煉信息
 * @author jy
 *
 */
public class TrainVO {

	/**
	 * 軍團id
	 */
	private long groupId;
	
	/**
	 * 當前場景中的玩家
	 */
	private final Set<Long> players = new ConcurrentHashSet<Long>();
	
	/**
	 * 對應的基礎數據id
	 */
	private int id;
	
	/**
	 * 當前副本id
	 */
	private int areaId;
	
	/**
	 * 當前在攻打的批次
	 */
	private int batch;
	
	/**
	 * 每個試煉軍當前的戰鬥信息，比如是否攻破等
	 * key-
	 */
	private final Map<Integer, ArmyVO> armys = new ConcurrentHashMap<Integer, ArmyVO>();

	private boolean isFinished = false;
	
	/**
	 * 軍隊數量計數器，當軍隊被消滅一個，就減一
	 */
	private AtomicInteger armyCounter;
	
	public long getGroupId() {
		return groupId;
	}

	public void setGroupId(long groupId) {
		this.groupId = groupId;
	}

	public Set<Long> getPlayers() {
		return players;
	}

	public int getAreaId() {
		return areaId;
	}

	public void setAreaId(int areaId) {
		this.areaId = areaId;
	}

	public int getBatch() {
		return batch;
	}

	public void setBatch(int batch) {
		this.batch = batch;
	}


	public Map<Integer, ArmyVO> getArmys() {
		return armys;
	}

	public ArmyVO getArmy(int armyId) {
		return armys.get(armyId);
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public boolean isFinished() {
		return isFinished;
	}

	public void setFinished(boolean isFinished) {
		this.isFinished = isFinished;
	}

	public static TrainVO valueOf(long armyGroupId) {
		TrainVO train = new TrainVO();
		train.groupId = armyGroupId;
		return train;
	}

	public void initArmyCounter(int sum) {
		armyCounter = new AtomicInteger(sum);
	}

	public boolean allKilled() {
		return armyCounter.get() <= 0;
	}

	public void decreaseArmy() {
		armyCounter.decrementAndGet();
	}

}
