/**
 * @file:BeatBackBuff.java
 * @author:David
 **/
package com.xx.dev.modules.battle.model;

import com.xx.dev.modules.skill.model.basedb.SkillEffect;

/**
 * @class:BeatBackBuff
 * @description:反击Buff
 * @author:David
 * @version:v1.0
 * @date:2013-5-3
 **/
public class BeatBackBuff extends AbstractBuff {
	/**
	 * 技能效果
	 */
	private SkillEffect skillEffect;
	/**
	 * 技能等级
	 */
	private int skillLevel = 0;
	/**
	 * 低级技能等级
	 */
	private int lowSkillLevel = 0;
	/**
	 * 技能伤害类型
	 */
	private int harmType = HarmType.NONE;
	/**
	 * 效果公式
	 */
	private String effectFormula;

	
	public BeatBackBuff(SkillEffect skillEffect, int harmType, int skillLevel, int lowSkillLevel, String effectFormula, int effectBaseValueType, double effectBase,
			int effectValueType, double effect, int startRound, int persistRound) {
		super(effectBaseValueType, effectBase, effectValueType, effect, startRound,
				persistRound);
		this.skillEffect = skillEffect;
		this.harmType = harmType;
		this.skillLevel = skillLevel;
		this.lowSkillLevel = lowSkillLevel;
		this.effectFormula = effectFormula;
	}
	/**
	 * @description:重新赋值	
	 * @param attrType
	 * @param value
	 * @param startRound
	 * @param persistRound
	 */
	public void reflush(SkillEffect skillEffect, int harmType, int skillLevel, int lowSkillLevel, String effectFormula,int effectBaseValueType,
			double effectBase, int effectValueType, double effect,int startRound, 
			int persistRound) {
		this.skillEffect = skillEffect;
		this.harmType = harmType;
		this.skillLevel = skillLevel;
		this.lowSkillLevel = lowSkillLevel;
		this.effectFormula = effectFormula;
		this.effectBaseValueType = effectBaseValueType;
		this.effectBase = effectBase;
		this.effectValueType = effectValueType;
		this.effect = effect;
		this.startRound = startRound;
		this.persistRound = persistRound;
	}

	public int getHarmType() {
		return harmType;
	}

	public void setHarmType(int harmType) {
		this.harmType = harmType;
	}
	public int getSkillLevel() {
		return skillLevel;
	}
	public void setSkillLevel(int skillLevel) {
		this.skillLevel = skillLevel;
	}
	public int getLowSkillLevel() {
		return lowSkillLevel;
	}
	public void setLowSkillLevel(int lowSkillLevel) {
		this.lowSkillLevel = lowSkillLevel;
	}
	public String getEffectFormula() {
		return effectFormula;
	}
	public void setEffectFormula(String effectFormula) {
		this.effectFormula = effectFormula;
	}
	public SkillEffect getSkillEffect() {
		return skillEffect;
	}
	public void setSkillEffect(SkillEffect skillEffect) {
		this.skillEffect = skillEffect;
	}
}

