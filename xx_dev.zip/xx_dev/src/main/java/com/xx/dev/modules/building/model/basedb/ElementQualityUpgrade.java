package com.xx.dev.modules.building.model.basedb;

import com.xx.common.basedb.anno.Id;
import com.xx.common.basedb.anno.Index;
import com.xx.common.basedb.anno.Resource;
import com.xx.dev.constant.IndexName;

/**
 * 建筑品质升级
 * 
 * @author Along
 *
 */
@Resource
public class ElementQualityUpgrade {

	/**
	 * id
	 */
	@Id
	private int id;
	
	/**
	 * 建筑id
	 */
	@Index(name = IndexName.BUILDING_QUALITY_UPGRADE_INDEX, order = 0)
	private int buildingId;
	
	/**
	 * 品质
	 */
	@Index(name = IndexName.BUILDING_QUALITY_UPGRADE_INDEX, order = 1)
	private int quality;
	
	/**
	 * 建筑等级
	 */
	private int buildingLevel;
	
	/**
	 * 玩家VIP等级
	 */
	private int vipLevel;
	
	/**
	 * 升品质消耗
	 */
	private String cost;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getBuildingId() {
		return buildingId;
	}

	public void setBuildingId(int buildingId) {
		this.buildingId = buildingId;
	}

	public int getQuality() {
		return quality;
	}

	public void setQuality(int quality) {
		this.quality = quality;
	}

	public int getBuildingLevel() {
		return buildingLevel;
	}

	public void setBuildingLevel(int buildingLevel) {
		this.buildingLevel = buildingLevel;
	}

	public int getVipLevel() {
		return vipLevel;
	}

	public void setVipLevel(int vipLevel) {
		this.vipLevel = vipLevel;
	}

	public String getCost() {
		return cost;
	}

	public void setCost(String cost) {
		this.cost = cost;
	}
	
}
