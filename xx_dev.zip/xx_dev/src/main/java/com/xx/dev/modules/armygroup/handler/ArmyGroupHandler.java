package com.xx.dev.modules.armygroup.handler;

import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xx.common.socket.handler.RequestProcessor;
import com.xx.common.socket.model.Request;
import com.xx.common.socket.model.Response;
import com.xx.dev.config.Module;
import com.xx.dev.model.Result;
import com.xx.dev.modules.armygroup.model.ArmyGroupBuildingDto;
import com.xx.dev.modules.armygroup.model.ArmyGroupContributeDto;
import com.xx.dev.modules.armygroup.model.ArmyGroupDto;
import com.xx.dev.modules.armygroup.model.ArmyGroupMemberDto;
import com.xx.dev.modules.armygroup.model.ArmyGroupTechDto;
import com.xx.dev.modules.armygroup.service.ArmyGroupService;
import com.xx.dev.modules.player.model.PlayerDto;
import com.xx.dev.modules.reward.result.ValueResultSet;
import com.xx.dev.modules.server.SessionManager;
import com.xx.dev.modules.server.handler.HandlerSupport;

/**
 * 军团模块
 * 
 * @author Along
 *
 */
@Service
public class ArmyGroupHandler extends HandlerSupport {

	private Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	private SessionManager sessionManager;
	
	@Autowired
	private ArmyGroupService armyGroupService;
	
	@Override
	protected void init() {
		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				createArmyGroup(session, request, response);
			}
			
			@Override
			public Type getType() {
				return HashMap.class;
			}
			
			@Override
			public int getModule() {
				return Module.ARMY_GROUP;
			}
			
			@Override
			public int getCmd() {
				return ArmyGroupCmd.CREATE_ARMY_GROUP;
			}
		});
		
		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				getArmyGroups(session, request, response);
			}
			
			@Override
			public Type getType() {
				return HashMap.class;
			}
			
			@Override
			public int getModule() {
				return Module.ARMY_GROUP;
			}
			
			@Override
			public int getCmd() {
				return ArmyGroupCmd.GET_ARMY_GROUPS;
			}
		});
		
		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				getArmyGroup(session, request, response);
			}
			
			@Override
			public Type getType() {
				return HashMap.class;
			}
			
			@Override
			public int getModule() {
				return Module.ARMY_GROUP;
			}
			
			@Override
			public int getCmd() {
				return ArmyGroupCmd.GET_ARMY_GROUP;
			}
		});
		
		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				applyJoinArmyGroup(session, request, response);
			}
			
			@Override
			public Type getType() {
				return HashMap.class;
			}
			
			@Override
			public int getModule() {
				return Module.ARMY_GROUP;
			}
			
			@Override
			public int getCmd() {
				return ArmyGroupCmd.APPLY_JOIN_ARMY_GROUP;
			}
		});
		
		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				getArmyGroupApplyList(session, request, response);
			}
			
			@Override
			public Type getType() {
				return null;
			}
			
			@Override
			public int getModule() {
				return Module.ARMY_GROUP;
			}
			
			@Override
			public int getCmd() {
				return ArmyGroupCmd.GET_ARMY_GROUP_APPLY_LIST;
			}
		});
		
		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				getApplyList(session, request, response);
			}
			
			@Override
			public Type getType() {
				return null;
			}
			
			@Override
			public int getModule() {
				return Module.ARMY_GROUP;
			}
			
			@Override
			public int getCmd() {
				return ArmyGroupCmd.GET_APPLY_LIST;
			}
		});
		
		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				approveApply(session, request, response);
			}
			
			@Override
			public Type getType() {
				return HashMap.class;
			}
			
			@Override
			public int getModule() {
				return Module.ARMY_GROUP;
			}
			
			@Override
			public int getCmd() {
				return ArmyGroupCmd.APPROVE_APPLY;
			}
		});
		
		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				refuseApply(session, request, response);
			}
			
			@Override
			public Type getType() {
				return HashMap.class;
			}
			
			@Override
			public int getModule() {
				return Module.ARMY_GROUP;
			}
			
			@Override
			public int getCmd() {
				return ArmyGroupCmd.REFUSE_APPLY;
			}
		});
		
		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				inviteJoinArmyGroup(session, request, response);
			}
			
			@Override
			public Type getType() {
				return HashMap.class;
			}
			
			@Override
			public int getModule() {
				return Module.ARMY_GROUP;
			}
			
			@Override
			public int getCmd() {
				return ArmyGroupCmd.INVITE_JOIN_ARMY_GROUP;
			}
		});
		
		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				quitArmyGroup(session, request, response);
			}
			
			@Override
			public Type getType() {
				return null;
			}
			
			@Override
			public int getModule() {
				return Module.ARMY_GROUP;
			}
			
			@Override
			public int getCmd() {
				return ArmyGroupCmd.QUIT_ARMY_GROUP;
			}
		});
		
		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				advertise(session, request, response);
			}
			
			@Override
			public Type getType() {
				return HashMap.class;
			}
			
			@Override
			public int getModule() {
				return Module.ARMY_GROUP;
			}
			
			@Override
			public int getCmd() {
				return ArmyGroupCmd.ADVERTISE;
			}
		});
		
		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				updateDeclaration(session, request, response);
			}
			
			@Override
			public Type getType() {
				return HashMap.class;
			}
			
			@Override
			public int getModule() {
				return Module.ARMY_GROUP;
			}
			
			@Override
			public int getCmd() {
				return ArmyGroupCmd.UPDATE_DECLARATION;
			}
		});
		
		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				buyHufu(session, request, response);
			}
			
			@Override
			public Type getType() {
				return HashMap.class;
			}
			
			@Override
			public int getModule() {
				return Module.ARMY_GROUP;
			}
			
			@Override
			public int getCmd() {
				return ArmyGroupCmd.BUY_HUFU;
			}
		});
		
		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				getArmyGroupMembers(session, request, response);
			}
			
			@Override
			public Type getType() {
				return null;
			}
			
			@Override
			public int getModule() {
				return Module.ARMY_GROUP;
			}
			
			@Override
			public int getCmd() {
				return ArmyGroupCmd.GET_ARMY_GROUP_MEMBERS;
			}
		});
		
		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				receiveFoods(session, request, response);
			}
			
			@Override
			public Type getType() {
				return null;
			}
			
			@Override
			public int getModule() {
				return Module.ARMY_GROUP;
			}
			
			@Override
			public int getCmd() {
				return ArmyGroupCmd.RECEIVEFOODS;
			}
		});
		
		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				receiveHeroSoul(session, request, response);
			}
			
			@Override
			public Type getType() {
				return null;
			}
			
			@Override
			public int getModule() {
				return Module.ARMY_GROUP;
			}
			
			@Override
			public int getCmd() {
				return ArmyGroupCmd.RECEIVEEXPLOIT;
			}
		});
		
		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				changePosition(session, request, response);
			}
			
			@Override
			public Type getType() {
				return HashMap.class;
			}
			
			@Override
			public int getModule() {
				return Module.ARMY_GROUP;
			}
			
			@Override
			public int getCmd() {
				return ArmyGroupCmd.CHANGE_POSITION;
			}
		});
		
		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				kickOutSomeone(session, request, response);
			}
			
			@Override
			public Type getType() {
				return HashMap.class;
			}
			
			@Override
			public int getModule() {
				return Module.ARMY_GROUP;
			}
			
			@Override
			public int getCmd() {
				return ArmyGroupCmd.KICK_OUT_SOMEONE;
			}
		});
		
		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				transferChief(session, request, response);
			}
			
			@Override
			public Type getType() {
				return HashMap.class;
			}
			
			@Override
			public int getModule() {
				return Module.ARMY_GROUP;
			}
			
			@Override
			public int getCmd() {
				return ArmyGroupCmd.TRANSFER_CHIEF;
			}
		});
		
		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				enterArmyGroup(session, request, response);
			}
			
			@Override
			public Type getType() {
				return null;
			}
			
			@Override
			public int getModule() {
				return Module.ARMY_GROUP;
			}
			
			@Override
			public int getCmd() {
				return ArmyGroupCmd.ENTER_ARMY_GROUP;
			}
		});
		
		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				cancelApply(session, request, response);
			}
			
			@Override
			public Type getType() {
				return HashMap.class;
			}
			
			@Override
			public int getModule() {
				return Module.ARMY_GROUP;
			}
			
			@Override
			public int getCmd() {
				return ArmyGroupCmd.CANCEL_APPLY_JOIN_ARMY_GROUP;
			}
		});
		
		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				contributeHufu(session, request, response);
			}
			
			@Override
			public Type getType() {
				return HashMap.class;
			}
			
			@Override
			public int getModule() {
				return Module.ARMY_GROUP;
			}
			
			@Override
			public int getCmd() {
				return ArmyGroupCmd.CONTRIBUTE_HUFU;
			}
		});
		
		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				getContributes(session, request, response);
			}
			
			@Override
			public Type getType() {
				return null;
			}
			
			@Override
			public int getModule() {
				return Module.ARMY_GROUP;
			}
			
			@Override
			public int getCmd() {
				return ArmyGroupCmd.GET_ARMY_GROUP_CONTRIBUTES;
			}
		});
		
		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				upgradeArmuGroupTech(session, request, response);
			}
			
			@Override
			public Type getType() {
				return HashMap.class;
			}
			
			@Override
			public int getModule() {
				return Module.ARMY_GROUP;
			}
			
			@Override
			public int getCmd() {
				return ArmyGroupCmd.UPGRADE_ARMY_GROUP_TECH;
			}
		});
		
		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				getTechs(session, request, response);
			}
			
			@Override
			public Type getType() {
				return null;
			}
			
			@Override
			public int getModule() {
				return Module.ARMY_GROUP;
			}
			
			@Override
			public int getCmd() {
				return ArmyGroupCmd.GET_ARMY_GROUP_TECHS;
			}
		});
		
		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				delateChief(session, request, response);
			}
			
			@Override
			public Type getType() {
				return null;
			}
			
			@Override
			public int getModule() {
				return Module.ARMY_GROUP;
			}
			
			@Override
			public int getCmd() {
				return ArmyGroupCmd.DELATE_CHIEF;
			}
		});
		
		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				approveApplys(session, request, response);
			}
			
			@Override
			public Type getType() {
				return null;
			}
			
			@Override
			public int getModule() {
				return Module.ARMY_GROUP;
			}
			
			@Override
			public int getCmd() {
				return ArmyGroupCmd.APPROVE_APPLYS;
			}
		});
		
		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				refuseApplys(session, request, response);
			}
			
			@Override
			public Type getType() {
				return null;
			}
			
			@Override
			public int getModule() {
				return Module.ARMY_GROUP;
			}
			
			@Override
			public int getCmd() {
				return ArmyGroupCmd.REFUSE_APPLYS;
			}
		});
		
		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				buyGoods(session, request, response);
			}
			
			@Override
			public Type getType() {
				return HashMap.class;
			}
			
			@Override
			public int getModule() {
				return Module.ARMY_GROUP;
			}
			
			@Override
			public int getCmd() {
				return ArmyGroupCmd.BUY_ARMY_GROUP_GOODS;
			}
		});
		
		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				updateNotice(session, request, response);
			}
			
			@Override
			public Type getType() {
				return HashMap.class;
			}
			
			@Override
			public int getModule() {
				return Module.ARMY_GROUP;
			}
			
			@Override
			public int getCmd() {
				return ArmyGroupCmd.UPDATE_NOTICE;
			}
		});
		
		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				getArmyGroupBuildings(session, request, response);
			}
			
			@Override
			public Type getType() {
				return null;
			}
			
			@Override
			public int getModule() {
				return Module.ARMY_GROUP;
			}
			
			@Override
			public int getCmd() {
				return ArmyGroupCmd.GET_ARMY_GROUP_BUILDINGS;
			}
		});
		
		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				returnArmyGroup(session, response);
			}
			
			@Override
			public Type getType() {
				return null;
			}
			
			@Override
			public int getModule() {
				return Module.ARMY_GROUP;
			}
			
			@Override
			public int getCmd() {
				return ArmyGroupCmd.RETURN_ARMY_GROUP;
			}
		});
		
		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				clearCoolTime(session, response);
			}
			
			@Override
			public Type getType() {
				return null;
			}
			
			@Override
			public int getModule() {
				return Module.ARMY_GROUP;
			}
			
			@Override
			public int getCmd() {
				return ArmyGroupCmd.CLEAR_COOL_TIME;
			}
		});
		
		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				renameArmyGroup(session, request, response);
			}
			
			@Override
			public Type getType() {
				return HashMap.class;
			}
			
			@Override
			public int getModule() {
				return Module.ARMY_GROUP;
			}
			
			@Override
			public int getCmd() {
				return ArmyGroupCmd.RENAME_ARMY_GROUP;
			}
		});
		
		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				getRandArmyGroups(session, request, response);
			}
			
			@Override
			public Type getType() {
				return HashMap.class;
			}
			
			@Override
			public int getModule() {
				return Module.ARMY_GROUP;
			}
			
			@Override
			public int getCmd() {
				return ArmyGroupCmd.GET_RAND_ARMY_GROUPS;
			}
		});
		
		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				searchArmyGroups(session, request, response);
			}
			
			@Override
			public Type getType() {
				return HashMap.class;
			}
			
			@Override
			public int getModule() {
				return Module.ARMY_GROUP;
			}
			
			@Override
			public int getCmd() {
				return ArmyGroupCmd.SEARCH_ARMY_GROUPS;
			}
		});
	}
	
	@SuppressWarnings("unchecked")
	protected void searchArmyGroups(IoSession session, Request request,
			Response response) {
		List<ArmyGroupDto> result = null;
		try {
			HashMap<String, Object> params = (HashMap<String, Object>) request.getValue();
			String name = String.valueOf(params.get("name"));
			result = armyGroupService.searchArmyGroupsAction(name);
		} catch (Exception e) {
			logger.error("查找军团", e);
		}		
		response.setValue(result);
		session.write(response);		
	}

	@SuppressWarnings("unchecked")
	protected void getRandArmyGroups(IoSession session, Request request,
			Response response) {
		List<ArmyGroupDto> result = null;
		try {
			HashMap<String, Object> params = (HashMap<String, Object>) request.getValue();
			String sFetchCount = String.valueOf(params.get("fetchCount"));
			int fetchCount = 5;
			if (StringUtils.isNotBlank(sFetchCount) && StringUtils.isNumeric(sFetchCount)) {
				fetchCount = Integer.parseInt(sFetchCount);
			}
			result = armyGroupService.getRandArmyGroupsAction(fetchCount);
		} catch (Exception e) {
			logger.error("随机获取军团列表", e);
		}		
		response.setValue(result);
		session.write(response);
	}

	@SuppressWarnings("unchecked")
	protected void renameArmyGroup(IoSession session, Request request,
			Response response) {
		Long playerId = sessionManager.getPlayerId(session);
		int result = ArmyGroupResult.FAILURE;
		try {
			HashMap<String, Object> params = (HashMap<String, Object>) request.getValue();
			String content = String.valueOf(params.get("content"));
			result = armyGroupService.renameAction(playerId, content);
		} catch (Exception e) {
			result = ArmyGroupResult.FAILURE;
			logger.error("修改军团名称", e);
		}		
		response.setValue(result);
		session.write(response);						
	}
	
	protected void clearCoolTime(IoSession session, Response response) {
		Long playerId = sessionManager.getPlayerId(session);
		Result<ValueResultSet> result = null;
		try {
			result = armyGroupService.clearCoolTimeAction(playerId);
		} catch (Exception e) {
			result = Result.Error(ArmyGroupResult.FAILURE);
			logger.error("清除冷却时间", e);
		}		
		response.setValue(result);
		session.write(response);			
	}

	protected void returnArmyGroup(IoSession session, Response response) {
		ArmyGroupDto result = null;
		Long playerId = sessionManager.getPlayerId(session);
		try {
			result = armyGroupService.getArmyGroupDtoAction(playerId);
		} catch (Exception e) {
			logger.error("返回军团", e);
		}		
		response.setValue(result);
		session.write(response);		
	}

	protected void getArmyGroupBuildings(IoSession session, Request request,
			Response response) {
		Long playerId = sessionManager.getPlayerId(session);
		List<ArmyGroupBuildingDto> result = null;
		try {
			result = armyGroupService.getArmyGroupBuildingsAction(playerId);
		} catch (Exception e) {
			logger.error("获取军团建筑列表", e);
		}		
		response.setValue(result);
		session.write(response);			
	}

	@SuppressWarnings("unchecked")
	protected void updateNotice(IoSession session, Request request,
			Response response) {
		Long playerId = sessionManager.getPlayerId(session);
		int result = ArmyGroupResult.FAILURE;
		try {
			HashMap<String, Object> params = (HashMap<String, Object>) request.getValue();
			String content = String.valueOf(params.get("content"));
			result = armyGroupService.updateNoticeAction(playerId, content);
		} catch (Exception e) {
			result = ArmyGroupResult.FAILURE;
			logger.error("修改公告", e);
		}		
		response.setValue(result);
		session.write(response);						
	}
	
	@SuppressWarnings("unchecked")
	protected void buyGoods(IoSession session, Request request,
			Response response) {
		Long playerId = sessionManager.getPlayerId(session);
		Result<ValueResultSet> result = null;
		try {
			HashMap<String, Object> params = (HashMap<String, Object>) request.getValue();
			int goodsId = -1;
			if (params.get("goodsId") != null) {
				goodsId = Integer.parseInt(String.valueOf(params.get("goodsId")));
			}
			int amount = 1;
			if (params.get("amount") != null) {
				amount = Integer.parseInt(String.valueOf(params.get("amount")));
			}
			result = armyGroupService.buyGoodsAction(playerId, goodsId, amount);
		} catch (Exception e) {
			result = Result.Error(ArmyGroupResult.PARAM_ERROR);
			logger.error("购买军团商品", e);
		}		
		response.setValue(result);
		session.write(response);					
	}

	protected void refuseApplys(IoSession session, Request request,
			Response response) {
		Long playerId = sessionManager.getPlayerId(session);
		int result = ArmyGroupResult.FAILURE;
		try {
			result = armyGroupService.refuseApplysAction(playerId);
		} catch (Exception e) {
			logger.error("拒绝所有申请", e);
		}		
		response.setValue(result);
		session.write(response);				
	}

	protected void approveApplys(IoSession session, Request request,
			Response response) {
		Long playerId = sessionManager.getPlayerId(session);
		int result = ArmyGroupResult.FAILURE;
		try {
			result = armyGroupService.approveApplysAction(playerId);
		} catch (Exception e) {
			logger.error("同意所有申请", e);
		}		
		response.setValue(result);
		session.write(response);					
	}

	protected void delateChief(IoSession session, Request request,
			Response response) {
		Long playerId = sessionManager.getPlayerId(session);
		Result<ArmyGroupDto> result = null;
		try {
			result = armyGroupService.delateChiefAction(playerId);
		} catch (Exception e) {
			logger.error("弹劾团长", e);
		}		
		response.setValue(result);
		session.write(response);				
	}

	protected void getTechs(IoSession session, Request request,
			Response response) {
		Long playerId = sessionManager.getPlayerId(session);
		List<ArmyGroupTechDto> result = null;
		try {
			result = armyGroupService.getPlayerArmyGroupTechsAction(playerId);
		} catch (Exception e) {
			logger.error("获取军团科技列表", e);
		}		
		response.setValue(result);
		session.write(response);				
	}

	@SuppressWarnings("unchecked")
	protected void upgradeArmuGroupTech(IoSession session, Request request,
			Response response) {
		Long playerId = sessionManager.getPlayerId(session);
		Result<ArmyGroupMemberDto> result = null;
		try {
			HashMap<String, Object> params = (HashMap<String, Object>) request.getValue();
			String sTechId = String.valueOf(params.get("techId"));
			if (StringUtils.isBlank(sTechId)) {
				result = Result.Error(ArmyGroupResult.PARAM_ERROR);
			} else {
				int techId = Integer.parseInt(sTechId);
				result = armyGroupService.upgradeArmyGroupTechAction(playerId, techId);
			}
		} catch (Exception e) {
			result = Result.Error(ArmyGroupResult.PARAM_ERROR);
			logger.error("升级军团科技", e);
		}		
		response.setValue(result);
		session.write(response);						
	}

	protected void getContributes(IoSession session, Request request,
			Response response) {
		Long playerId = sessionManager.getPlayerId(session);
		List<ArmyGroupContributeDto> result = null;
		try {
			result = armyGroupService.getArmyGroupContributesAction(playerId);
		} catch (Exception e) {
			logger.error("获取捐献日志列表", e);
		}		
		response.setValue(result);
		session.write(response);					
	}

	@SuppressWarnings("unchecked")
	protected void contributeHufu(IoSession session, Request request,
			Response response) {
		Long playerId = sessionManager.getPlayerId(session);
		Result<ValueResultSet> result = null;
		try {
			HashMap<String, Object> params = (HashMap<String, Object>) request.getValue();
			String sBuildingId = String.valueOf(params.get("buildingId"));
			if (StringUtils.isBlank(sBuildingId)) {
				result = Result.Error(ArmyGroupResult.PARAM_ERROR);
			} else {
				int buildingId = Integer.parseInt(sBuildingId);
				int useGold = -1;
				if (params.containsKey("useGold")) {
					useGold = Integer.parseInt(String.valueOf(params.get("useGold")));
				}
				result = armyGroupService.contributeHufuAction(playerId, buildingId, useGold);
			}
		} catch (Exception e) {
			result = Result.Error(ArmyGroupResult.PARAM_ERROR);
			logger.error("捐献虎符", e);
		}		
		response.setValue(result);
		session.write(response);				
	}

	@SuppressWarnings("unchecked")
	protected void cancelApply(IoSession session, Request request,
			Response response) {
		Long playerId = sessionManager.getPlayerId(session);
		int result = ArmyGroupResult.FAILURE;
		try {
			HashMap<String, Object> params = (HashMap<String, Object>) request.getValue();
			String sId = String.valueOf(params.get("id"));
			if (StringUtils.isBlank(sId)) {
				result = ArmyGroupResult.PARAM_ERROR;
			} else {
				long id = Long.parseLong(sId);
				result = armyGroupService.cancelApplyAction(playerId, id);
			}
		} catch (Exception e) {
			result = ArmyGroupResult.FAILURE;
			logger.error("取消加入军团申请", e);
		}		
		response.setValue(result);
		session.write(response);		
	}

	protected void enterArmyGroup(IoSession session, Request request,
			Response response) {
		Long playerId = sessionManager.getPlayerId(session);
		Result<ArmyGroupDto> result = null;
		try {
			result = armyGroupService.enterArmyGroupAction(playerId);
		} catch (Exception e) {
			result = Result.Error(ArmyGroupResult.FAILURE);
			logger.error("进入军团界面", e);
		}		
		response.setValue(result);
		session.write(response);				
	}

	@SuppressWarnings("unchecked")
	protected void transferChief(IoSession session, Request request,
			Response response) {
		Long playerId = sessionManager.getPlayerId(session);
		Result<ArmyGroupDto> result = null;
		try {
			HashMap<String, Object> params = (HashMap<String, Object>) request.getValue();
			String sUserId = String.valueOf(params.get("userId"));
			if (StringUtils.isBlank(sUserId) ||	!StringUtils.isNumeric(sUserId)) {
				result = Result.Error(ArmyGroupResult.PARAM_ERROR);
			} else {
				long userId = Long.parseLong(sUserId);
				result = armyGroupService.transferChiefAction(playerId, userId);
			}
		} catch (Exception e) {
			result = Result.Error(ArmyGroupResult.FAILURE);
			logger.error("转让团长", e);
		}		
		response.setValue(result);
		session.write(response);								
	}

	@SuppressWarnings("unchecked")
	protected void kickOutSomeone(IoSession session, Request request,
			Response response) {
		Long playerId = sessionManager.getPlayerId(session);
		Result<ArmyGroupDto> result = null;
		try {
			HashMap<String, Object> params = (HashMap<String, Object>) request.getValue();
			String sUserId = String.valueOf(params.get("userId"));
			String reason = String.valueOf(params.get("reason"));
			if (StringUtils.isBlank(sUserId) || StringUtils.isBlank(reason) || 
					!StringUtils.isNumeric(sUserId)) {
				result = Result.Error(ArmyGroupResult.PARAM_ERROR);
			} else {
				long userId = Long.parseLong(sUserId);
				result = armyGroupService.kickOutSomeOneAction(playerId, userId, reason);
			}
		} catch (Exception e) {
			result = Result.Error(ArmyGroupResult.FAILURE);
			logger.error("踢人", e);
		}		
		response.setValue(result);
		session.write(response);						
	}

	@SuppressWarnings("unchecked")
	protected void changePosition(IoSession session, Request request,
			Response response) {
		Long playerId = sessionManager.getPlayerId(session);
		Result<ArmyGroupMemberDto> result = null;
		try {
			HashMap<String, Object> params = (HashMap<String, Object>) request.getValue();
			String sUserId = String.valueOf(params.get("userId"));
			String sPositionId = String.valueOf(params.get("positionId"));
			if (StringUtils.isBlank(sUserId) || StringUtils.isBlank(sPositionId)) {
				result = Result.Error(ArmyGroupResult.PARAM_ERROR);
			} else {
				long userId = Long.parseLong(sUserId);
				int positionId = Integer.parseInt(sPositionId);
				result = armyGroupService.changePositionAction(playerId, userId, positionId);
			}
		} catch (Exception e) {
			result = Result.Error(ArmyGroupResult.FAILURE);
			logger.error("升降职", e);
		}		
		response.setValue(result);
		session.write(response);								
	}

	protected void receiveHeroSoul(IoSession session, Request request,
			Response response) {
		Long playerId = sessionManager.getPlayerId(session);
		Result<ValueResultSet> result = null;
		try {
			result = armyGroupService.receiveHeroSoulAction(playerId);
		} catch (Exception e) {
			result = Result.Error(ArmyGroupResult.FAILURE);
			logger.error("领取每日武将经验福利", e);
		}		
		response.setValue(result);
		session.write(response);				
	}

	protected void receiveFoods(IoSession session, Request request,
			Response response) {
		Long playerId = sessionManager.getPlayerId(session);
		Result<ValueResultSet> result = null;
		try {
			result = armyGroupService.receiveFoodsAction(playerId);
		} catch (Exception e) {
			result = Result.Error(ArmyGroupResult.FAILURE);
			logger.error("领取每日粮草福利", e);
		}		
		response.setValue(result);
		session.write(response);						
	}

	protected void getArmyGroupMembers(IoSession session, Request request,
			Response response) {
		Long playerId = sessionManager.getPlayerId(session);
		List<ArmyGroupMemberDto> result = null;
		try {
			result = armyGroupService.getArmyGroupMembersAction(playerId);
		} catch (Exception e) {
			logger.error("获取军团成员列表", e);
		}		
		response.setValue(result);
		session.write(response);				
	}

	@SuppressWarnings("unchecked")
	protected void buyHufu(IoSession session, Request request, Response response) {
		Long playerId = sessionManager.getPlayerId(session);
		Result<ValueResultSet> result = null;
		try {
			HashMap<String, Object> params = (HashMap<String, Object>) request.getValue();
			String sAmount = String.valueOf(params.get("amount"));
			String sUserGold = String.valueOf(params.get("useGold"));
			if (StringUtils.isBlank(sAmount) || StringUtils.isBlank(sUserGold)) {
				result = Result.Error(ArmyGroupResult.PARAM_ERROR);
			} else {
				int amount = Integer.parseInt(sAmount);
				int useGold = Integer.parseInt(sUserGold);
				result = armyGroupService.buyHufuAction(playerId, amount, useGold);
			}
		} catch (Exception e) {
			result = Result.Error(ArmyGroupResult.FAILURE);
			logger.error("购买虎符", e);
		}		
		response.setValue(result);
		session.write(response);							
	}

	@SuppressWarnings("unchecked")
	protected void updateDeclaration(IoSession session, Request request,
			Response response) {
		Long playerId = sessionManager.getPlayerId(session);
		Result<ArmyGroupDto> result;
		try {
			HashMap<String, Object> params = (HashMap<String, Object>) request.getValue();
			String content = String.valueOf(params.get("content"));
			result = armyGroupService.updateDeclarationAction(playerId, content);
		} catch (Exception e) {
			result = Result.Error(ArmyGroupResult.FAILURE);
			logger.error("修改宣言", e);
		}		
		response.setValue(result);
		session.write(response);						
	}

	@SuppressWarnings("unchecked")
	protected void advertise(IoSession session, Request request,
			Response response) {
		Long playerId = sessionManager.getPlayerId(session);
		int result = ArmyGroupResult.FAILURE;
		try {
			HashMap<String, Object> params = (HashMap<String, Object>) request.getValue();
			String content = String.valueOf(params.get("content"));
			if (StringUtils.isBlank(content)) {
				result = ArmyGroupResult.PARAM_ERROR;
			} else {
				result = armyGroupService.advertiseAction(playerId, content);
			}
		} catch (Exception e) {
			result = ArmyGroupResult.FAILURE;
			logger.error("发送招贤榜", e);
		}		
		response.setValue(result);
		session.write(response);				
	}

	protected void quitArmyGroup(IoSession session, Request request,
			Response response) {
		Long playerId = sessionManager.getPlayerId(session);
		int result = ArmyGroupResult.FAILURE;
		try {
			result = armyGroupService.quitArmyGroupAction(playerId);
		} catch (Exception e) {
			logger.error("退出军团", e);
		}		
		response.setValue(result);
		session.write(response);		
	}

	@SuppressWarnings("unchecked")
	protected void inviteJoinArmyGroup(IoSession session, Request request,
			Response response) {
		Long playerId = sessionManager.getPlayerId(session);
		int result = ArmyGroupResult.FAILURE;
		try {
			HashMap<String, Object> params = (HashMap<String, Object>) request.getValue();
			String playerName = String.valueOf(params.get("playerName"));
			if (StringUtils.isBlank(playerName)) {
				result = ArmyGroupResult.PARAM_ERROR;
			} else {
				result = armyGroupService.inviteJoinArmyGroupAction(playerId, playerName);
			}
		} catch (Exception e) {
			result = ArmyGroupResult.FAILURE;
			logger.error("邀请加入军团", e);
		}		
		response.setValue(result);
		session.write(response);					
	}

	@SuppressWarnings("unchecked")
	protected void refuseApply(IoSession session, Request request,
			Response response) {
		Long playerId = sessionManager.getPlayerId(session);
		int result = ArmyGroupResult.FAILURE;
		try {
			HashMap<String, Object> params = (HashMap<String, Object>) request.getValue();
			String sApplyId = String.valueOf(params.get("applyId"));
			if (StringUtils.isBlank(sApplyId) || !StringUtils.isNumeric(sApplyId)) {
				result = ArmyGroupResult.PARAM_ERROR;
			} else {
				long applyId = Long.parseLong(sApplyId);
				result = armyGroupService.refuseApplyAction(playerId, applyId);
			}
		} catch (Exception e) {
			result = ArmyGroupResult.FAILURE;
			logger.error("审核拒绝申请", e);
		}		
		response.setValue(result);
		session.write(response);				
	}

	@SuppressWarnings("unchecked")
	protected void approveApply(IoSession session, Request request,
			Response response) {
		Long playerId = sessionManager.getPlayerId(session);
		int result = ArmyGroupResult.FAILURE;
		try {
			HashMap<String, Object> params = (HashMap<String, Object>) request.getValue();
			String sApplyId = String.valueOf(params.get("applyId"));
			if (StringUtils.isBlank(sApplyId) || !StringUtils.isNumeric(sApplyId)) {
				result = ArmyGroupResult.PARAM_ERROR;
			} else {
				long applyId = Long.parseLong(sApplyId);
				result = armyGroupService.approveApplyAction(playerId, applyId);
			}
		} catch (Exception e) {
			result = ArmyGroupResult.FAILURE;
			logger.error("审核通过申请", e);
		}		
		response.setValue(result);
		session.write(response);		
	}

	protected void getArmyGroupApplyList(IoSession session, Request request,
			Response response) {
		Long playerId = sessionManager.getPlayerId(session);
		List<PlayerDto> result = null;
		try {
			result = armyGroupService.getArmyGroupApplyListAction(playerId);
		} catch (Exception e) {
			logger.error("获取军团申请列表", e);
		}		
		response.setValue(result);
		session.write(response);		
	}

	protected void getApplyList(IoSession session, Request request,
			Response response) {
		Long playerId = sessionManager.getPlayerId(session);
		List<ArmyGroupDto> result = null;
		try {
			result = armyGroupService.getApplyListAction(playerId);
		} catch (Exception e) {
			logger.error("获取已经申请的军团列表", e);
		}		
		response.setValue(result);
		session.write(response);				
	}

	@SuppressWarnings("unchecked")
	protected void applyJoinArmyGroup(IoSession session, Request request,
			Response response) {
		Long playerId = sessionManager.getPlayerId(session);
		int result = ArmyGroupResult.FAILURE;
		try {
			HashMap<String, Object> params = (HashMap<String, Object>) request.getValue();
			String sId = String.valueOf(params.get("id"));
			if (StringUtils.isBlank(sId)) {
				result = ArmyGroupResult.PARAM_ERROR;
			} else {
				long id = Long.parseLong(sId);
				result = armyGroupService.applyJoinArmyGroupAction(playerId, id);
			}
		} catch (Exception e) {
			result = ArmyGroupResult.FAILURE;
			logger.error("申请加入军团", e);
		}		
		response.setValue(result);
		session.write(response);
	}

	@SuppressWarnings("unchecked")
	protected void getArmyGroup(IoSession session, Request request,
			Response response) {
		Result<ArmyGroupDto> result = null;
		try {
			HashMap<String, Object> params = (HashMap<String, Object>) request.getValue();
			String name = String.valueOf(params.get("name"));
			if (StringUtils.isBlank(name)) {
				result = Result.Error(ArmyGroupResult.PARAM_ERROR);
			} else {
				result = armyGroupService.getArmyGroupAction(name);
			}
		} catch (Exception e) {
			result = Result.Error(ArmyGroupResult.FAILURE);
			logger.error("获取军团信息", e);
		}		
		response.setValue(result);
		session.write(response);
	}

	@SuppressWarnings("unchecked")
	protected void createArmyGroup(IoSession session, Request request,
			Response response) {
		Long playerId = sessionManager.getPlayerId(session);
		Result<ValueResultSet> result = null;
		try {
			HashMap<String, Object> params = (HashMap<String, Object>) request.getValue();
			String name = String.valueOf(params.get("name"));
			if (StringUtils.isBlank(name)) {
				result = Result.Error(ArmyGroupResult.PARAM_ERROR);
			} else {
				int useGold = 0;
				if (params.get("useGold") != null) {
					String sUseGold = String.valueOf(params.get("useGold"));
					useGold = Integer.parseInt(String.valueOf(sUseGold));
				}
				result = armyGroupService.createArmyGroupAction(playerId, name, useGold);
			}
		} catch (Exception e) {
			result = Result.Error(ArmyGroupResult.FAILURE);
			logger.error("创建军团", e);
		}		
		response.setValue(result);
		session.write(response);
	}

	@SuppressWarnings("unchecked")
	protected void getArmyGroups(IoSession session, Request request,
			Response response) {
		Result<List<ArmyGroupDto>> result = null;
		try {
			HashMap<String, Object> params = (HashMap<String, Object>) request.getValue();
			String sStartIndex = String.valueOf(params.get("startIndex"));
			String sFetchCount = String.valueOf(params.get("fetchCount"));
			if (StringUtils.isBlank(sStartIndex) || StringUtils.isBlank(sFetchCount)) {
				result = Result.Error(ArmyGroupResult.PARAM_ERROR);
			} else {
				int startIndex = Integer.parseInt(sStartIndex);
				int fetchCount = Integer.parseInt(sFetchCount);
				result = armyGroupService.getArmyGroupsAction(startIndex, fetchCount);
			}
		} catch (Exception e) {
			result = Result.Error(ArmyGroupResult.FAILURE);
			logger.error("分页获取军团列表", e);
		}		
		response.setValue(result);
		session.write(response);
	}

}
