/**
 * @file:DieAwayBuff.java
 * @author:David
 **/
package com.xx.dev.modules.battle.model;
/**
 * @class:DieAwayBuff
 * @description:假死（HP>1时，并当受到致命伤害时，生命保留XX点）
 * @author:David
 * @version:v1.0
 * @date:2013-4-30
 **/
public class DieAwayBuff extends AbstractBuff {

	public DieAwayBuff(int effectBaseValueType, double effectBase,
			int effectValueType, double effect, int startRound, int persistRound) {
		super(effectBaseValueType, effectBase, effectValueType, effect, startRound,
				persistRound);
	}

}

