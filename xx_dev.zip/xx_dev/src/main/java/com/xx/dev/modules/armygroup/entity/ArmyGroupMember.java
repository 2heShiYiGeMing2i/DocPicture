package com.xx.dev.modules.armygroup.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.commons.lang.time.DateUtils;
import org.hibernate.annotations.Index;

import com.xx.common.db.model.BaseModel;

/**
 * 军团成员
 * 
 * @author Along
 *
 */
@Entity
@Table(name = "armyGroupMember")
public class ArmyGroupMember extends BaseModel<Long> {

	private static final long serialVersionUID = 8256408885474717499L;

	/**
	 * 主键（玩家id做主键）
	 */
	@Id
	@Column(columnDefinition = "bigint(20) NOT NULL COMMENT '主键'")
	private Long id;
	
	/**
	 * 军团id（-1表示暂时没有加入任何军团）
	 */
	@Index(name = "armyGroup_member_index")
	@Column(columnDefinition = "bigint(20) NOT NULL COMMENT '军团id'")
	private long armyGroupId;
	
	/**
	 * 职位id
	 */
	@Column(columnDefinition = "int(11) NOT NULL COMMENT '职位id'")
	private int positionId = 0;
	
	/**
	 * 贡献值
	 */
	@Column(columnDefinition = "int(11) NOT NULL COMMENT '贡献值'")
	private int contribute = 0;
	
	/**
	 * 当前军团贡献值
	 */
	@Column(columnDefinition = "int(11) NOT NULL COMMENT '当前军团贡献值'")
	private int curContribute = 0;
	
	/**
	 * 最后领取粮草福利的时间
	 */
	@Column(columnDefinition="datetime default '2013-01-01 00:00:00' comment '最后领取粮草福利的时间'")
	private Date receiveFoodsTime;
	
	/**
	 * 最后领取武将经验福利的时间
	 */
	@Column(columnDefinition="datetime default '2013-01-01 00:00:00' comment '最后领取武将经验福利的时间'")
	private Date receiveHeroSoulTime;
	
	/**
	 * 加入军团的时间
	 */
	@Column(columnDefinition="datetime default '2013-01-01 00:00:00' comment '加入军团的时间'")
	private Date joinTime;
	
	/**
	 * 退出军团的时间
	 */
	@Column(columnDefinition="datetime default '2013-01-01 00:00:00' comment '退出军团的时间'")
	private Date quitTime;
	
	public ArmyGroupMember() {
		
	}
	
	public ArmyGroupMember(long id, long playerId, int positionId) {
		this.id = playerId;
		this.armyGroupId = id;
		this.positionId = positionId;
		Date now = new Date();
		receiveHeroSoulTime = DateUtils.addDays(now, -1);
		receiveFoodsTime = DateUtils.addDays(now, -1);
		joinTime = now;
		quitTime = DateUtils.addDays(now, -1);
	}
	
	@Override
	public Long getId() {
		return this.id;
	}

	@Override
	public void setId(Long id) {
		this.id = id;
	}

	public long getArmyGroupId() {
		return armyGroupId;
	}

	public void setArmyGroupId(long armyGroupId) {
		this.armyGroupId = armyGroupId;
	}

	public int getPositionId() {
		return positionId;
	}

	public void setPositionId(int positionId) {
		this.positionId = positionId;
	}

	public int getContribute() {
		return contribute;
	}

	public void setContribute(int contribute) {
		this.contribute = contribute;
	}

	public int getCurContribute() {
		return curContribute;
	}

	public void setCurContribute(int curContribute) {
		this.curContribute = curContribute;
	}

	public Date getReceiveFoodsTime() {
		return receiveFoodsTime;
	}

	public void setReceiveFoodsTime(Date receiveFoodsTime) {
		this.receiveFoodsTime = receiveFoodsTime;
	}

	public Date getReceiveHeroSoulTime() {
		return receiveHeroSoulTime;
	}

	public void setReceiveHeroSoulTime(Date receiveHeroSoulTime) {
		this.receiveHeroSoulTime = receiveHeroSoulTime;
	}

	public Date getJoinTime() {
		return joinTime;
	}

	public void setJoinTime(Date joinTime) {
		this.joinTime = joinTime;
	}

	public Date getQuitTime() {
		return quitTime;
	}

	public void setQuitTime(Date quitTime) {
		this.quitTime = quitTime;
	}

}
