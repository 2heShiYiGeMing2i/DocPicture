package com.xx.dev.modules.bejeweled.model.basedb;

import com.xx.common.basedb.anno.Id;
import com.xx.common.basedb.anno.Resource;

/**
 * 方块消除
 * Created by LiangZengle on 2014/6/23.
 */
@Resource
public class BejeweledClearUp {
    /**
     * 消除的个数
     */
    @Id
    private int id;

    /**
     * 得分
     */
    private int score;

    /**
     * 几率(用于自动消除时随机)
     */
    private int rate;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public int getRate() {
        return rate;
    }

    public void setRate(int rate) {
        this.rate = rate;
    }
}
