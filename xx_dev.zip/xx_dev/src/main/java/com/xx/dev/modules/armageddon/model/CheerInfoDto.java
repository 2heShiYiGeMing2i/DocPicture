/**
 * @file:CheerInfoDto.java
 * @author:David
 **/
package com.xx.dev.modules.armageddon.model;

import java.util.ArrayList;
import java.util.List;

/**
 * @class:CheerInfoDto
 * @description:
 * @author:David
 * @version:v1.0
 * @date:2013-5-21
 **/
public class CheerInfoDto {
	private List<PlayerCheerDto> playerCheerDtos = new ArrayList<PlayerCheerDto>();
	/**
	 * 当前已邀请人ID
	 */
	private List<PlayerCheerDto> cheerPlayers = new ArrayList<PlayerCheerDto>();
	
	public List<PlayerCheerDto> getPlayerCheerDtos() {
		return playerCheerDtos;
	}

	public void setPlayerCheerDtos(List<PlayerCheerDto> playerCheerDtos) {
		this.playerCheerDtos = playerCheerDtos;
	}
	
	public void addPlayerCheerDto(PlayerCheerDto playerCheerDto){
		this.playerCheerDtos.add(playerCheerDto);
	}
	
	public List<PlayerCheerDto> getCheerPlayers() {
		return cheerPlayers;
	}

	public void setCheerPlayers(List<PlayerCheerDto> cheerPlayers) {
		this.cheerPlayers = cheerPlayers;
	}

	public int size(){
		return playerCheerDtos.size();
	}
	
	public void addCheerPlayers(PlayerCheerDto playerCheerDto){
		this.cheerPlayers.add(playerCheerDto);
	}
}

