package com.xx.dev.modules.bejeweled.handler;

import com.xx.dev.constant.CommonConstant;

/**
 * 宝箱迷阵错误码
 * Created by LiangZengle on 2014/6/21.
 */
public interface BejeweledResult extends CommonConstant {

    /**
     * 增加步数次数限制
     */
    int ADD_MOVE_TIMES_LIMIT = -10001;

    /**
     * 步数用光了
     */
    int MOVES_LIMIT = -10002;

    /**
     * 分不够
     */
    int SCORE_NOT_ENOUGH = -10003;

    /**
     * 非法的移动：超过边界 or 距离 > 1
     */
    int ILLEGAL_MOVE = -10004;

}
