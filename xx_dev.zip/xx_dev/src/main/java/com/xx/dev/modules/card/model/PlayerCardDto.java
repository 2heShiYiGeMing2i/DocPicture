package com.xx.dev.modules.card.model;

import java.util.Date;

import com.xx.dev.modules.card.entity.PlayerCard;

/**
 * 客户端请求玩家月卡信息的返回数据
 * @author jy
 *
 */
public class PlayerCardDto {

	/**
	 * 是否激活月卡，0-未激活，1-已经激活
	 * 
	 */
	private int isOpen;
	/**
	 * 月卡结束时间，可累加
	 */
	private long endTime;
	
	/**
	 * 是否领取体力，0-未领取，1-已经领取
	 */
	private int energyGetState;
	
	/**
	 * 是否领取富甲天下，0-未领取，1-已经领取
	 */
	private int fjtxGetState;
	
	/**
	 * 是否领取每日buffer，0-未领取，1-已经领取
	 */
	private int bufferGetState;

	

	public long getEndTime() {
		return endTime;
	}

	public void setEndTime(long endTime) {
		this.endTime = endTime;
	}

	public int getEnergyGetState() {
		return energyGetState;
	}

	public void setEnergyGetState(int energyGetState) {
		this.energyGetState = energyGetState;
	}

	public int getFjtxGetState() {
		return fjtxGetState;
	}

	public void setFjtxGetState(int fjtxGetState) {
		this.fjtxGetState = fjtxGetState;
	}

	public int getBufferGetState() {
		return bufferGetState;
	}

	public void setBufferGetState(int bufferGetState) {
		this.bufferGetState = bufferGetState;
	}

	
	public int getIsOpen() {
		return isOpen;
	}

	public void setIsOpen(int isOpen) {
		this.isOpen = isOpen;
	}

	public static PlayerCardDto valueOf(PlayerCard playerCard) {
		PlayerCardDto dto = new PlayerCardDto();
		dto.endTime = playerCard.getEndTime() == null ? new Date().getTime() : playerCard.getEndTime().getTime();
		dto.isOpen = playerCard.getIsOpen();
		dto.energyGetState = playerCard.getEnergyGetState();
		dto.fjtxGetState = playerCard.getFjtxGetState();
		dto.bufferGetState = playerCard.getBufferGetState();
		return dto;
	}
	
	
}
