/**
 * @file:Module.java
 * @author:David
 **/
package com.xx.dev.config;
/**
 * @class:Module
 * @description:服务端 游戏模块 管理
 * @author:David
 * @version:v1.0
 * @date:2013-4-18
 **/
public interface Module {
	
	/**
	 * 管理后台
	 */
	int MIS = 0;
	
	/**
	 * 主公
	 */
	int PLAYER = 1;
	
	/**
	 * 聊天
	 */
	int CHITCHAT = 2;
	
	/**
	 * 邮件
	 */
	int MAIL = 3;
	
	/**
	 * 武将
	 */
	int HERO = 4;
	
	/**
	 * 兵营
	 */
	int BARRACKS = 5;
	
	/**
	 * 主城建筑
	 */
	int BUILDING = 6;
	
	/**
	 * 冷却队列
	 */
	int COOLQUEUE = 7;
	
	/**
	 * 单人副本
	 */
	int SINGLE_CHAPTER = 8;
	
	/**
	 * 道具
	 */
	int ITEM = 9;
	
	/**
	 * 战斗系统
	 */
	int BATTLE = 10;

	/**
	 * 背包
	 */
	int PACK = 11;

	/**
	 * 技能
	 */
	int SKILL = 12;
	
	/**
	 * 远征异族
	 */
	int INVADE = 13;
	
	/**
	 * 税收
	 */
	int REVENUE = 14;
	
//	/**
//	 * 酒馆
//	 */
//	int PUB = 15;
	
	/**
	 * 精英副本
	 */
	int CREAM = 16;
	
	/**
	 * 武将装备
	 */
	int HERO_EQUIP = 17;
	
	/**
	 * 好友系统
	 */
	int RELATION = 18;
	
	/**
	 * 科技（军机处）
	 */
	int TECH = 19;
	
	/**
	 * 演武场（军阵）
	 */
	int DRILL = 20;
	
	/**
	 * 征战天下
	 */
	int JOURNEY = 21;
	
	/**
	 * 任务
	 */
	int TASK = 22;
	
	/**
	 * 民心事件
	 */
	int WISH_EVENT = 23;
	
	/**
	 * 大决战
	 */
	int ARMAGEDDON = 24;
	
	/**
	 * 黑市
	 */
	int BLACK_MARKET = 25;
	
	/**
	 * 命签
	 */
	int DIVINATION = 26;
	
	/**
	 * 攻城掠地
	 */
	int PLUNDER = 27;
	
	/**
	 * 竞技场
	 */
	int ARENA = 28;
	
	/**
	 * 军团
	 */
	int ARMY_GROUP = 29;
	
	/**
	 * 群雄争霸
	 */
	int CHAMPIONSHIP = 30;
	
	/**
	 * 新手副本
	 */
	int NEWARMY = 31;
	
	/**
	 * 商城系统
	 */
	int SHOP = 32;
	
	/**
	 * 每日税收
	 */
	int DAYREVENUE = 33;
	
	/**
	 * 目标系统
	 */
	int GOAL = 34;
	
	/**
	 * 开关系统
	 */
	int OPEN_CTRL = 35;
	
	/**
	 * 礼包系统
	 */
	int GIFT = 36;
	
	/**
	 * 日行一善
	 */
	int GOODNESS = 37;
	
	/**
	 * VIP系统
	 */
	int VIP = 38;
	
	/**
	 * 每日奖励指引
	 */
	int DAILY_GUIDE = 39;
	
	/**
	 * 猛将录
	 */
	int HERO_COLLECT = 40;
	
	/**
	 * 神兵活动
	 */
	int MAGIC = 41;
	
	/**
	 * 活动
	 */
	int ACTIVITY = 42;
	
	/**
	 * 排行榜
	 */
	int RANKING = 43;
	
	/**
	 * 一夫当关
	 */
	int MANPASS = 44;
	
	/**
	 * 新精英副本
	 */
	int NEW_CREAM = 46;
	
	/**
	 * 成长基金
	 */
	int FUND = 47;
	
	/**
	 * 新酒馆
	 */
	int NEW_PUB = 48;
	
	/**
	 * 临时背包
	 */
	int TEMP_BAG = 49;
	
	/**
	 * 奴隶系统
	 */
	int SLAVE = 50;
	
	/**
	 * 神兵阁（神兵抽奖）
	 */
	int EQUIP_RAFFLE = 51;
	
	/**
	 * 抢粮
	 */
	int PLUNDER_FOOD = 52;
	
	/**
	 * 自定义活动
	 */
	int CUSTOM_ACTIVITY = 53;
	
	/**
	 * 跑环玩法
	 */
	int LOOP = 54;
	
	/**
	 * 摸金寻宝
	 */
	int TREASURE = 55;
	
	/**
	 * 全服活动任务
	 */
	int SERVER_ACTIVITY_TASK = 56;
	
	/**
	 * 360红钻vip
	 */
	int CN360_RED_VIP = 57;
	
	/**
	 * vip副本
	 */
	int VIP_FUBEN = 58;
	
	/**
	 * 360安全卫士特权
	 */
	int CN360_PRIVELEGE = 59;
	
	/**
	 * 决战长安
	 */
	int DECISIVE_CHANG_AN = 60;
	
	/**
	 * 图腾
	 */
	int TOTEM = 61;
	
	/**
	 * 迅雷会员
	 */
	int XUNLEI_MEMBER = 62;
	
	/**
	 * 折扣商店
	 */
	int DISCOUNT_SHOP = 63;
	
	/**
	 * YY会员
	 */
	int YY_MEMBER = 64;
	
	/**
	 * 理财计划
	 */
	int MONEY_PLAN = 65;
	
	/**
	 * 多人副本
	 */
	int MULTIFUBEN = 66;
	
	/**
	 * 积分活动
	 */
	int INTEGRATION = 67;
	
	/**
	 * 主公装备
	 */
	int PLAYER_EQUIP = 68;
	
	/**
	 * 元宵商店(特殊商店,用道具+资源买东西)
	 */
	int SPECIAL_SHOP = 69;
	
	/**
	 * 植树模块
	 */
	int PLANTING = 70;
	
	/**
	 * 团购
	 */
	int GROUP_PURCHASE = 71;
	
	/**
	 * 玩家月卡
	 */
	int PLAYER_CARD = 72;
	
	/**
	 * 练兵系统
	 */
	int TRAINING = 73;
	
	/**
	 * 百服活动礼包
	 */
	int HUNDRED_SERVER_ACTIVITY = 74;
	
	/**
	 * 幸运抽奖
	 */
	int LUCKY_DRAW = 75;
	
	/**
	 * 宝石道具转换
	 */
	int ITEM_CONVERT = 76;
	
	/**
	 * 爬塔PVE玩法
	 */
	int TOWER_PVE = 77;
	
	/**
	 * 充值活动
	 */
	int CHARGE_ACTIVITY = 78;
	
	/**
	 * 元宝抽奖
	 */
	int GOLD_DRAW = 79;
	
	/**
	 * 稀有物品抽奖
	 */
	int RARE_ITEM_DRAW = 80;
	
	/**
	 * 跨服群雄争霸
	 */
	int KF_CHAMPION = 81;
	
	/**
	 * 全服摸金寻宝
	 */
	int SERVER_TREASURE = 82;
	
	/**
	 * 37平台vip礼包
	 */
	int CN_37_VIP = 83;
	
	/**
	 * 劳动节种植活动
	 */
	int LABOR_PLANTING = 84;
	
	/**
	 * 皇城缉盗
	 */
	int ROYAL_TASK = 85;
	
	/**
	 * 欢乐宝箱
	 */
	int HAPPY_BOX = 86;
	
	/**
	 * 坐骑
	 */
	int HORSE = 87;

    /**
     * 神秘商店
     */
    int MYSTERY_STORE = 88;

    /**
     * 端午活动
     */
    int DUAN_WU = 89;

    /**
     * 灵翼
     */
    int NETHERWING = 90;
    
    /**
     * 跨服掠夺
     */
    int KF_LOOT = 91;

    /**
     * 世界杯
     */
    int WORLD_CUP = 92;
    
    /**
     * 军团试炼
     */
    int ARMY_GROUP_TRAIN = 93;
    
    /**
     * 风云争霸
     */
    int FUNG_WAN = 94;

    /**
     * 真龙宝库
     */
    int TREASURE_HOUSE = 95;

    /**
     * 充值返还活动
     */
    int CHARGE_RETURN_ACTIVITY = 96;

    /**
     * 宝箱迷阵
     */
    int BEJEWELED = 97;

    /**
     * 时装
     */
    int FASHION_EQUIP = 98;
    
    /**
     * 充值抽奖
     */
    int CHARGE_DRAW = 99;

    /**
     * 桃园结义
     */
    int SWORN = 100;
    
    /**
     * 跨服天梯
     */
    int KF_LADDER = 101;
    
    /**
     * 称号
     */
    int HONOR = 102;
    
    /**
     * 存款（财富乐翻天）
     */
    int DEPOSIT = 103;
    
    /**
     * 帝王盛宴
     */
    int MONARCH_FEAST = 104;
    
	/**
	 * 通用模块
	 */
	int COMMON_MODULE = 1000;
	
	/**
	 * 充值模块
	 */
	int CHARGE = 1001;
	
	/**
	 * 补丁模块
	 */
	int PATCH = 1002;

	
}

