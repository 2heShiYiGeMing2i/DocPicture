package com.xx.dev.constant;

/**
 * Session关闭模式
 * 
 * @author Along
 *
 */
public enum SessionCloseMode {

	/**
	 * 正常关闭
	 */
	NORMAL,
	
	/**
	 * 被踢下线
	 */
	KICKED,
	
	/**
	 * 服务器关闭
	 */
	SERVER_CLOING;
	
}
