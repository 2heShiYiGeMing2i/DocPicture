package com.xx.dev.modules.armygrouptrain.model;

/**
 * 我的試煉信息
 * @author jy
 *
 */
public class TrainPlayerDto {

	/**
	 * 玩家id
	 */
	private long playerId;
	
	/**
	 * 冷卻時間
	 */
	private long coolTime;

	/**
	 * 是否死亡，用於死亡冷卻，1表示死亡，0表示沒有死亡
	 */
	private int status;
	
	public long getCoolTime() {
		return coolTime;
	}

	public void setCoolTime(long coolTime) {
		this.coolTime = coolTime;
	}

	public long getPlayerId() {
		return playerId;
	}

	public void setPlayerId(long playerId) {
		this.playerId = playerId;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public static TrainPlayerDto valueOf(long playerId, long coolTime, int status) {
		TrainPlayerDto dto = new TrainPlayerDto();
		dto.coolTime = coolTime;
		dto.status = status;
		dto.playerId = playerId;
		return dto;
	}
	
	
}
