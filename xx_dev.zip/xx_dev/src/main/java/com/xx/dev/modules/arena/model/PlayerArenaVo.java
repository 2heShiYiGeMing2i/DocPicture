package com.xx.dev.modules.arena.model;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import com.xx.dev.modules.reward.model.Reward;

/**
 * 角色竞技场信息
 * 
 * @author bingshan
 */
public class PlayerArenaVo {

	/**
	 * 角色id
	 */
	private long playerId;
	
	/**
	 * 排名
	 */
	private int rank = 0;
	
	/**
	 * 可领的奖励
	 */
	private final List<Reward> rewards = new CopyOnWriteArrayList<Reward>();
	
	/**
	 * 是否翻过牌了
	 */
	private boolean isTurn = false;
	
	/**
	 * 当未上榜时获取可挑战列表时所传的最大排名值
	 */
	private int maxRank = 0;
	
	public static PlayerArenaVo valueOf(long playerId, int rank) {
		PlayerArenaVo p = new PlayerArenaVo();
		p.playerId = playerId;
		p.rank = rank;
		return p;
	}
	
	public static PlayerArenaVo valueOf(long playerId) {
		return valueOf(playerId, 0);
	}

	public long getPlayerId() {
		return playerId;
	}

	public void setPlayerId(long playerId) {
		this.playerId = playerId;
	}

	public int getRank() {
		return rank;
	}

	public void setRank(int rank) {
		this.rank = rank;
	}

	public List<Reward> getRewards() {
		return rewards;
	}

	public boolean isTurn() {
		return isTurn;
	}

	public void setTurn(boolean isTurn) {
		this.isTurn = isTurn;
	}

	public int getMaxRank() {
		return maxRank;
	}

	public void setMaxRank(int maxRank) {
		this.maxRank = maxRank;
	}
	
}
