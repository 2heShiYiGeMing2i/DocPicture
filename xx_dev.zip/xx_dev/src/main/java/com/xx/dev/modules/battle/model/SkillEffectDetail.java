/**
 * @file:SkillEffectDetail.java
 * @author:David
 **/
package com.xx.dev.modules.battle.model;

import java.util.ArrayList;
import java.util.List;

import com.xx.dev.modules.skill.model.SkillEffectType;

/**
 * @class:SkillEffectDetail
 * @description:技能效果信息
 * @author:David
 * @version:v1.0
 * @date:2013-4-23
 **/
public class SkillEffectDetail {
	
	/** 技能效果类型 {@link SkillEffectType}*/
	private int skillEffectType;
	/** 技能效果基础数据id*/
	private int skillEffectId;
	/** 影响到的属性 {@link BattleAttrType} (BUFF效果) */
	private int attrType = BattleAttrType.NONE;
	/** 技能触发者ID */
	private long triggerId;
	/** 技能触发者所处pos */
	private int triggerPos;
	/** 剩余回合数 */
	private int leftRound;
	/** 是否触发了团结 0-否 1-触发**/
	private int unity = 0;
	/** 玩家战斗属性变化集合 */
	private List<BattleAttrChanges> attrChanges = null;
	
	public SkillEffectDetail(int skillEffectType, int skillEffectId,
			int attrType,long triggerId, int triggerPos, int leftRound,
			List<BattleAttrChanges> attrChanges) {
		super();
		this.skillEffectType = skillEffectType;
		this.skillEffectId = skillEffectId;
		this.attrType = attrType;
		this.triggerId = triggerId;
		this.triggerPos = triggerPos;
		this.leftRound = leftRound;
		this.attrChanges = attrChanges;
	}
	public SkillEffectDetail(int skillEffectType, int skillEffectId,
			int attrType,long triggerId, int triggerPos, int leftRound,
			BattleAttrChanges attrChange) {
		super();
		this.skillEffectType = skillEffectType;
		this.skillEffectId = skillEffectId;
		this.attrType = attrType;
		this.triggerId = triggerId;
		this.triggerPos = triggerPos;
		this.leftRound = leftRound;
		this.attrChanges = new ArrayList<BattleAttrChanges>(1);
		this.attrChanges.add(attrChange);
	}
	public SkillEffectDetail(int skillEffectType, int skillEffectId,
			int attrType,long triggerId, int triggerPos, int leftRound) {
		super();
		this.skillEffectType = skillEffectType;
		this.skillEffectId = skillEffectId;
		this.attrType = attrType;
		this.triggerId = triggerId;
		this.triggerPos = triggerPos;
		this.leftRound = leftRound;
	}
	public int getSkillEffectType() {
		return skillEffectType;
	}
	public void setSkillEffectType(int skillEffectType) {
		this.skillEffectType = skillEffectType;
	}
	public int getSkillEffectId() {
		return skillEffectId;
	}
	public void setSkillEffectId(int skillEffectId) {
		this.skillEffectId = skillEffectId;
	}
	public int getAttrType() {
		return attrType;
	}
	public void setAttrType(int attrType) {
		this.attrType = attrType;
	}
	public int getTriggerPos() {
		return triggerPos;
	}
	public void setTriggerPos(int triggerPos) {
		this.triggerPos = triggerPos;
	}
	public int getLeftRound() {
		return leftRound;
	}
	public void setLeftRound(int leftRound) {
		this.leftRound = leftRound;
	}
	public List<BattleAttrChanges> getAttrChanges() {
		return attrChanges;
	}
	public void setAttrChanges(List<BattleAttrChanges> attrChanges) {
		this.attrChanges = attrChanges;
	}
	public long getTriggerId() {
		return triggerId;
	}
	public void setTriggerId(long triggerId) {
		this.triggerId = triggerId;
	}
	public int getUnity() {
		return unity;
	}
	public void setUnity(int unity) {
		this.unity = unity;
	}
}

