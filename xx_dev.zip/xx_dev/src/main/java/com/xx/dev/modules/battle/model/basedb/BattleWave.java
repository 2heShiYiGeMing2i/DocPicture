/**
 * @file:BattleWave.java
 * @author:David
 **/
package com.xx.dev.modules.battle.model.basedb;

import com.xx.common.basedb.anno.Id;
import com.xx.common.basedb.anno.Resource;

/**
 * @class:BattleWave
 * @description:战斗波次
 * @author:David
 * @version:v1.0
 * @date:2013-8-19
 **/
@Resource
public class BattleWave {

	/** 编号 */
	@Id
	private int id;

	/** 是否多波 0-非多波 1-多波*/
	private int waveBattle;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getWaveBattle() {
		return waveBattle;
	}

	public void setWaveBattle(int waveBattle) {
		this.waveBattle = waveBattle;
	}
		
}

