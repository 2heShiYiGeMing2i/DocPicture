/**
 * @file:ArmageddonRuleServiceImpl.java
 * @author:David
 **/
package com.xx.dev.modules.armageddon.service.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.xx.common.basedb.BasedbAdapter;
import com.xx.common.basedb.BasedbService;
import com.xx.common.util.Splitable;
import com.xx.dev.modules.armageddon.model.basedb.Armageddon;
import com.xx.dev.modules.armageddon.model.basedb.ArmageddonArmy;
import com.xx.dev.modules.armageddon.model.basedb.ArmageddonMission;
import com.xx.dev.modules.armageddon.service.ArmageddonRuleService;
import com.xx.dev.modules.battle.model.BattleCharacter;
import com.xx.dev.modules.chapter.model.basedb.NpcHero;
import com.xx.dev.modules.journey.model.HardType;

/**
 * @class:ArmageddonRuleServiceImpl
 * @description:大决战基础规则服务
 * @author:David
 * @version:v1.0
 * @date:2013-5-20
 **/
@Component
public class ArmageddonRuleServiceImpl extends BasedbAdapter implements ArmageddonRuleService {
	@Autowired
	protected BasedbService basedbService;

	@Override
	public int getFirstMissionId(HardType hardType) {
		int initId = basedbService.getMinValue(Armageddon.class, Armageddon.MIN_MAX_ID).intValue();
		Armageddon chapter = basedbService.get(Armageddon.class, initId);
		return chapter.getAreaList(hardType).get(0);
	}

	@Override
	public boolean isAreaTailOfFuben(int missionId, HardType hardType) {
		ArmageddonMission mission = basedbService.get(ArmageddonMission.class, missionId);
		if(mission != null){
			Armageddon chapter = basedbService.get(Armageddon.class, mission.getFubenId());
			if(chapter != null && !chapter.getAreaList(hardType).isEmpty()){
				return chapter.getAreaList(hardType).get(chapter.getAreaList().size() - 1) == missionId;
			}
		}
		return false;
	}

	@Override
	public boolean isArmyTailOfArea(int currArmyId, HardType hardType) {
		ArmageddonArmy army = basedbService.get(ArmageddonArmy.class, currArmyId);
		if(army != null){
			ArmageddonMission mission = basedbService.get(ArmageddonMission.class, army.getAreaId());
			if(mission != null && !mission.getArmyList().isEmpty()){
				return mission.getArmyList().get(mission.getArmyList().size() - 1) == currArmyId;
			}
		}
		return false;
	}

	@Override
	public ArmageddonMission getNextMissionByOrder(int missionId) {
		ArmageddonMission mission = basedbService.get(ArmageddonMission.class, missionId);
		if(mission != null){
			HardType hardType = HardType.valueOf(mission.getDifficulty());
			if(this.isAreaTailOfFuben(missionId, hardType)){//副本中的最后一个了
				int fubenId = mission.getFubenId();
				int index = fuben_id_list.indexOf(fubenId);
				if(index >= fuben_id_list.size() - 1){//最后一个副本最后一个据点
					return null;
				} 
				int nextFubenId =  fuben_id_list.get(index + 1);
				Armageddon nextFuben = this.basedbService.get(Armageddon.class, nextFubenId);
				if(nextFuben != null && nextFuben.getAreaList(hardType) != null && !nextFuben.getAreaList(hardType).isEmpty()){
					return this.basedbService.get(ArmageddonMission.class, nextFuben.getAreaList(hardType).get(0));
				}
			} else {
				return this.getNextArea(missionId);
			}
			
		}
		return null;
	}

	@Override
	public ArmageddonMission getNextArea(int missionId) {
		ArmageddonMission armyArea = this.basedbService.get(ArmageddonMission.class, missionId);
		if(armyArea != null){
			HardType hardType = HardType.valueOf(armyArea.getDifficulty());
			Armageddon fuben = this.basedbService.get(Armageddon.class, armyArea.getFubenId());
			if(fuben != null){
				List<Integer> areaIdList = fuben.getAreaList(hardType);
				if(areaIdList != null && !areaIdList.isEmpty()){
					int index = areaIdList.indexOf(missionId);
					if(index < 0){
						return null;
					}
					if(index >= areaIdList.size() - 1){//最后一个返回
						return null;
					}
					return this.basedbService.get(ArmageddonMission.class, areaIdList.get(index + 1));
				}
			}
		}
		return null;
	}

	@Override
	public Class<?>[] listenedClass() {
		return new Class<?>[]{ArmageddonMission.class, ArmageddonArmy.class};
	}
	/**排好序的单人副本列表  */
	private List<Integer> fuben_id_list = new ArrayList<Integer>();
	@Override
	public void initialize() {
		this.initFuben();
	}
	
	/**
	 * 初始化副本和据点的对应关系
	 */
	private void initFuben(){
		//处理困难部队
		Collection<ArmageddonArmy> armyHardCollection = basedbService.listAll(ArmageddonArmy.class);
		if(armyHardCollection != null && !armyHardCollection.isEmpty()){
			for (ArmageddonArmy army : armyHardCollection) {
				ArmageddonMission mission = basedbService.get(ArmageddonMission.class, army.getAreaId());
				if(mission != null){
					mission.addArmy(army.getId());
				}
			}
		}
		//处理据点
		Collection<ArmageddonMission> missions = basedbService.listAll(ArmageddonMission.class);
		if(missions != null && !missions.isEmpty()){
			for (ArmageddonMission mission : missions) {
				Collections.sort(mission.getArmyList(), EASY_ARMY_COMPARATOR);
				Armageddon chapter  = basedbService.get(Armageddon.class, mission.getFubenId());
				HardType hardType =	HardType.valueOf(mission.getDifficulty());
				if(chapter != null){
					chapter.addArea(mission.getId(), hardType);
				}
			}
		}
		
		List<Integer> fubenIdList = new ArrayList<Integer>();
		//处理副本
		Collection<Armageddon> fubenCollection = this.basedbService.listAll(Armageddon.class);
		if(fubenCollection != null && !fubenCollection.isEmpty()){
			for(Armageddon chapter : fubenCollection){
				Collections.sort(chapter.getAreaList(), MISSION_COMPARATOR);
				Collections.sort(chapter.getHardAreaList(), MISSION_COMPARATOR);
				fubenIdList.add(chapter.getId());
			}
		}
		Collections.sort(fubenIdList);
		fuben_id_list = fubenIdList;
	}
	
	public final Comparator<Integer> MISSION_COMPARATOR = new Comparator<Integer>() {
		@Override
		public int compare(Integer o1, Integer o2) {
			ArmageddonMission area1 = basedbService.get(ArmageddonMission.class, o1);
			ArmageddonMission area2 = basedbService.get(ArmageddonMission.class, o2);
			return area1.getId() > area2.getId() ? 1 : -1;
		}
	};
	
	public final Comparator<Integer> EASY_ARMY_COMPARATOR = new Comparator<Integer>() {
		@Override
		public int compare(Integer o1, Integer o2) {
			
			ArmageddonArmy army1 = basedbService.get(ArmageddonArmy.class, o1);
			ArmageddonArmy army2 = basedbService.get(ArmageddonArmy.class, o2);
			if (army1.getBatch() < army2.getBatch()) {
				return -1;
			}
			if (army1.getBatch() > army2.getBatch()) {
				return 1;
			}
			return 1;
		}
	};
	@Override
	public ArmageddonArmy getFirstArmyOfArea(int missionId) {
		ArmageddonMission armyArea = this.basedbService.get(ArmageddonMission.class, missionId);
		if (armyArea != null) {
			if (!armyArea.getArmyList().isEmpty()) {
				int firstArmyId = armyArea.getArmyList().get(0);
				return this.basedbService.get(ArmageddonArmy.class, firstArmyId);
			}
		}
		return null;
	}

	@Override
	public ArmageddonArmy getNextArmy(int areaId, int armyId) {
		ArmageddonArmy fubenArmy = this.basedbService.get(ArmageddonArmy.class, armyId);
		if(fubenArmy != null){
			ArmageddonMission fubenArea = this.basedbService.get(ArmageddonMission.class, areaId);
			if(fubenArea != null){
				List<Integer> armyList = fubenArea.getArmyList();
				if(armyList != null && !armyList.isEmpty()){
					int index = armyList.indexOf(armyId);
					if(index < 0){
						return null;
					}
					if(index >= armyList.size() - 1){//最后一个返回
						return null;
					}
					return this.basedbService.get(ArmageddonArmy.class, armyList.get(index + 1));
				}
			}
		}
		return null;
	}

	@Override
	public boolean isArmyHeadOfArea(int armyId) {
		ArmageddonArmy fubenArmy = this.basedbService.get(ArmageddonArmy.class, armyId);
		if(fubenArmy != null){
			ArmageddonMission fubenArea = this.basedbService.get(ArmageddonMission.class, fubenArmy.getAreaId());
			if(fubenArea != null && !fubenArea.getArmyList().isEmpty()){
				return fubenArea.getArmyList().get(0) == armyId;
			}
		}
		return false;
	}

	@Override
	public List<BattleCharacter> getFightUnit(int armyId) {
		ArmageddonArmy fubenArmy = this.basedbService.get(ArmageddonArmy.class, armyId);
		String army = fubenArmy.getArmy();
		String[] armIds = army.split(Splitable.ELEMENT_SPLIT);
		List<BattleCharacter> battleCharacters = new ArrayList<BattleCharacter>();
		for (int i = 0; i < armIds.length; i++) {
			NpcHero npcHero = this.basedbService.get(NpcHero.class, Integer.parseInt(armIds[i]));
			if(npcHero == null){
				continue;
			}
			BattleCharacter battleCharacter = new BattleCharacter(npcHero, (i+1));
			battleCharacters.add(battleCharacter);
		}
		return battleCharacters;
	}

	@Override
	public double getAbility(int armyId) {
		ArmageddonArmy fubenArmy = this.basedbService.get(ArmageddonArmy.class, armyId);
		String army = fubenArmy.getArmy();
		String[] armIds = army.split(Splitable.ELEMENT_SPLIT);
		double ability = 0; 
		for (int i = 0; i < armIds.length; i++) {
			NpcHero npcHero = this.basedbService.get(NpcHero.class, Integer.parseInt(armIds[i]));
			if(npcHero == null){
				continue;
			}
			ability += npcHero.getAbility();
		}
		return ability;
	}
}

