/**
 * @file:ArmageddonRuleService.java
 * @author:David
 **/
package com.xx.dev.modules.armageddon.service;

import java.util.List;

import com.xx.dev.modules.armageddon.model.basedb.ArmageddonArmy;
import com.xx.dev.modules.armageddon.model.basedb.ArmageddonMission;
import com.xx.dev.modules.battle.model.BattleCharacter;
import com.xx.dev.modules.journey.model.HardType;

/**
 * @class:ArmageddonRuleService
 * @description:大决战基本规则服务
 * @author:David
 * @version:v1.0
 * @date:2013-5-20
 **/
public interface ArmageddonRuleService {
	/**
	 * @description:获取第一个据点id
	 * @return
	 */
	public int getFirstMissionId(HardType hardType);
	
	/**
	 * 判断据点是不是副本的最后一个据点
	 * @param areaId
	 * @return
	 */
	public boolean isAreaTailOfFuben(int missionId, HardType hardType);
	
	/**
	 * @description:判断部队是不是据点最后一个
	 * @param currArmyId
	 * @return
	 */
	public boolean isArmyTailOfArea(int currArmyId, HardType hardType);
	
	/**
	 * 按单人副本顺序获取下一个据点 
	 * @param areaId 据点id
	 * @return
	 */
	public ArmageddonMission getNextMissionByOrder(int missionId);
	
	/**
	 * 获取同一个副本的下一个据点
	 * @param areaId 据点id
	 * @return null表示没有了
	 */
	public ArmageddonMission getNextArea(int missionId);
	
	/**
	 * 获取据点里的第一个怪物部队
	 * @param areaId
	 * @return
	 */
	public ArmageddonArmy getFirstArmyOfArea(int missionId);
	
	/**
	 * 获取同据点的下一支部队
	 * @param areaId 据点id
	 * @param armyId 部队id
	 * @return  null表示没有了
	 */
	public ArmageddonArmy getNextArmy(int areaId, int armyId);
	
	/**
	 * 判断部队是不是据点第一个
	 * @param armyId 部队id
	 * @return
	 */
	public boolean isArmyHeadOfArea(int armyId);
	
	/**
	 * @description:获取怪物部队的战斗单元
	 * @param armyId
	 * @return
	 */
	public List<BattleCharacter> getFightUnit(int armyId);
	
	/**
	 * @description:获取怪物部队的战斗力
	 * @param armyId
	 * @return
	 */
	public double getAbility(int armyId);
}

