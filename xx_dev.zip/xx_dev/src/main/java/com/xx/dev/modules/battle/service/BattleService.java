/**
 * @file:BattleService.java
 * @author:David
 **/
package com.xx.dev.modules.battle.service;


import java.util.List;

import com.xx.dev.constant.BattleType;
import com.xx.dev.modules.battle.model.BattleCharacter;
import com.xx.dev.modules.battle.model.BattleGroup;
import com.xx.dev.modules.battle.model.MultiBattleResult;

/**
 * @class:BattleService
 * @description:
 * @author:David
 * @version:v1.0
 * @date:2013-5-9
 **/
public interface BattleService {

	/**************************客户端接口部分*******************************/
	/***************************服务端内部**********************************/
	public BattleCharacter getRobotPlayerBattleCharacter(long playerId, int teamPosition);
	
	/**
	 * @description:是否多波次战斗	
	 * @param BattleWaveID {BattleWaveID}
	 * @return
	 */
	public boolean isMultiWaveBattle(int battleWaveId);
	/**
	 * @description:多波战斗	
	 * @param battleType
	 * @param attackGroup
	 * @param defendGroup
	 * @param isReport
	 * @return
	 */
	public MultiBattleResult multiWaveBattle(BattleType battleType, List<BattleGroup> attackGroups, List<BattleGroup> defendGroups, boolean isReport);
	/**
	 * @description:多波战斗	
	 * @param battleType
	 * @param attackGroup
	 * @param defendGroup
	 * @param isReport
	 * @param isRound
	 * @return
	 */
	public MultiBattleResult multiWaveBattle(BattleType battleType, List<BattleGroup> attackGroups, List<BattleGroup> defendGroups, boolean isReport, boolean isRound);
	/**
	 * @description:战斗完成清除战斗遗留属性，重置初始血量	
	 * @param battleCharacters
	 */
	public void reflushBattleAttr(List<BattleCharacter> battleCharacters);
}

