package com.xx.dev.modules.armygroup.model;

import com.xx.dev.modules.armygroup.entity.ArmyGroupTech;

/**
 * 军团科技DTO对象
 * 
 * @author Along
 *
 */
public class ArmyGroupTechDto {
	
	/**
	 * 科技id
	 */
	private int techId;
	
	/**
	 * 科技等级
	 */
	private int level;
	
	public static ArmyGroupTechDto valueOf(ArmyGroupTech armyGroupTech) {
		ArmyGroupTechDto result = new ArmyGroupTechDto();
		result.setTechId(armyGroupTech.getTechId());
		result.setLevel(armyGroupTech.getLevel());
		return result;
	}

	public int getTechId() {
		return techId;
	}

	public void setTechId(int techId) {
		this.techId = techId;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}
	
}
