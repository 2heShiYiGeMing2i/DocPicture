package com.xx.dev.modules.arena.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

import com.xx.common.db.model.BaseModel;

/**
 * 竞技场信息
 * 
 * @author bingshan
 */
@Entity
@Table(name = "arenaInfo")
public class ArenaInfo extends BaseModel<Integer> {
	private static final long serialVersionUID = -6715581859138827754L;

	/**
	 * 主键id
	 */
	@Id
	@Column(columnDefinition = "tinyint(4) not null comment '主键id'")
	private Integer id;
	
	/**
	 * 信息
	 */
	@Lob
	@Column(columnDefinition = "longtext comment '信息'")
	private String info = "";

	@Override
	public Integer getId() {
		return id;
	}

	@Override
	public void setId(Integer id) {
		this.id = id;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

}
