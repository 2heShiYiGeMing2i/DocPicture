/**
 * @file:BattleRound.java
 * @author:David
 **/
package com.xx.dev.modules.battle.model;

import java.util.ArrayList;
import java.util.List;

/**
 * @class:BattleRound
 * @description:战斗大回合战报
 * @author:David
 * @version:v1.0
 * @date:2013-6-25
 **/
public class BattleRound {
	/** 当前大回合数 */
	private int currRound;
	/** 战斗攻方的血量信息 **/
	private List<BattleAttrChanges> attackChanges = new ArrayList<BattleAttrChanges>();
	/** 战斗防守方的血量信息 **/
	private List<BattleAttrChanges> defendChanges = new ArrayList<BattleAttrChanges>();
	
	public BattleRound(int currRound) {
		super();
		this.currRound = currRound;
	}

	public int getCurrRound() {
		return currRound;
	}

	public void setCurrRound(int currRound) {
		this.currRound = currRound;
	}

	public List<BattleAttrChanges> getAttackChanges() {
		return attackChanges;
	}

	public void setAttackChanges(List<BattleAttrChanges> attackChanges) {
		this.attackChanges = attackChanges;
	}

	public List<BattleAttrChanges> getDefendChanges() {
		return defendChanges;
	}

	public void setDefendChanges(List<BattleAttrChanges> defendChanges) {
		this.defendChanges = defendChanges;
	}

	public void addAttackChanges(BattleAttrChanges battleAttrChanges){
		this.attackChanges.add(battleAttrChanges);
	}
	public void addDefendChanges(BattleAttrChanges battleAttrChanges){
		this.defendChanges.add(battleAttrChanges);
	}
}

