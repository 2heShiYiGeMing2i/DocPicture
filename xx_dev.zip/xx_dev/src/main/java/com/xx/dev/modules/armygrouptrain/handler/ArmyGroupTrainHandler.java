package com.xx.dev.modules.armygrouptrain.handler;

import java.util.List;
import java.util.Map;

import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.xx.common.socket.handler.RequestProcessor;
import com.xx.common.socket.handler.RequestProcessorAdapter;
import com.xx.common.socket.model.Request;
import com.xx.common.socket.model.Response;
import com.xx.dev.config.Module;
import com.xx.dev.model.Result;
import com.xx.dev.modules.armygrouptrain.model.TrainDto;
import com.xx.dev.modules.armygrouptrain.model.TrainPlayerDto;
import com.xx.dev.modules.armygrouptrain.model.TrainPlayerRankDto;
import com.xx.dev.modules.armygrouptrain.service.ArmyGroupTrainService;
import com.xx.dev.modules.server.SessionManager;
import com.xx.dev.modules.server.handler.HandlerSupport;

/**
 * 軍團試煉指令處理器
 * @author jy
 *
 */
@Component
public class ArmyGroupTrainHandler extends HandlerSupport{

	private int module = Module.ARMY_GROUP_TRAIN;
	
	private Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	private SessionManager sessionManager;
	
	@Autowired
	private ArmyGroupTrainService armyGroupTrainService;
	
	@Override
	protected void init() {
		registerProcessor(attack);
		registerProcessor(getMyTrainInfo);
		registerProcessor(getArmyGroupTrainInfo);
		registerProcessor(leaveScene);
		registerProcessor(getTrainRanks);
		registerProcessor(moveInTrainScene);
		registerProcessor(updateCurLocation);
		registerProcessor(getCurLocation);
		registerProcessor(getCurStatus);
	}

	private RequestProcessor attack = new RequestProcessorAdapter(module, ArmyGroupTrainCmd.ATTACK, Map.class){

		@SuppressWarnings("unchecked")
		@Override
		public void process(IoSession session, Request request,
				Response response) {
			
			Long playerId = sessionManager.getPlayerId(session);
			Result<TrainPlayerDto> result = null;
			try {
				Map<String, Object> params = (Map<String, Object>)request.getValue();
				int areaId = (Integer)params.get("areaId");
				int armyId = (Integer)params.get("armyId");
				result = armyGroupTrainService.attack(playerId, areaId, armyId);
			} catch (Exception e) {
				result = Result.Error(ArmyGroupTrainResult.FAILURE);
				logger.error("进攻试炼军异常", e);
			}
			response.setValue(result);
			session.write(response);
		}
	};
	
	private RequestProcessor getMyTrainInfo = new RequestProcessorAdapter(module, ArmyGroupTrainCmd.GET_MY_TRAIN_INFO, null){
		
		@Override
		public void process(IoSession session, Request request,
				Response response) {
			
			Long playerId = sessionManager.getPlayerId(session);
			Result<TrainPlayerDto> result = null;
			try {
				result = armyGroupTrainService.getMyTrainInfo(playerId);
			} catch (Exception e) {
				result = Result.Error(ArmyGroupTrainResult.FAILURE);
				logger.error("获取我的军团试炼信息异常", e);
			}
			response.setValue(result);
			session.write(response);
		}
	};
	
	
	private RequestProcessor getArmyGroupTrainInfo = new RequestProcessorAdapter(module, ArmyGroupTrainCmd.GET_ARMY_GROUP_TRAIN_INFO, null){
		
		@Override
		public void process(IoSession session, Request request,
				Response response) {
			
			Long playerId = sessionManager.getPlayerId(session);
			TrainDto result = null;
			try {
				result = armyGroupTrainService.getArmyGroupTrainInfo(playerId);
			} catch (Exception e) {
				logger.error("获取军团试炼怪物信息异常", e);
			}
			response.setValue(result);
			session.write(response);
		}
	};
	
	private RequestProcessor leaveScene = new RequestProcessorAdapter(module, ArmyGroupTrainCmd.LEAVE_ARMY_GROUP_TRAIN_SCENE, null){
		
		@Override
		public void process(IoSession session, Request request,
				Response response) {
			
			long playerId = sessionManager.getPlayerId(session);
			armyGroupTrainService.leaveTrainScene(playerId);
		}
	};
	
	private RequestProcessor getTrainRanks = new RequestProcessorAdapter(module, ArmyGroupTrainCmd.GET_ARMY_GROUP_TRAIN_RANKS, null){
		
		@Override
		public void process(IoSession session, Request request,
				Response response) {
			
			long playerId = sessionManager.getPlayerId(session);
			Result<List<TrainPlayerRankDto>> result = null;
			try {
				result = armyGroupTrainService.getTrainRanks(playerId);
			} catch (Exception e) {
				result = Result.Error(ArmyGroupTrainResult.FAILURE);
				logger.error("获取军团试炼怪物信息异常", e);
			}
			response.setValue(result);
			session.write(response);
		}
	};
	
	private RequestProcessor moveInTrainScene = new RequestProcessorAdapter(module, ArmyGroupTrainCmd.MOVE_IN_TRAIN_SCENE, Map.class) {
		@SuppressWarnings("unchecked")
		@Override
		public void process(IoSession session, Request request, Response response) {
			Long playerId = sessionManager.getPlayerId(session);
			Map<String, Object> params = (Map<String, Object>) request.getValue();
			String path = (String) params.get("path");
			armyGroupTrainService.moveInTrainScene(playerId, path);
		}
	};
	
	private RequestProcessor updateCurLocation = new RequestProcessorAdapter(module, ArmyGroupTrainCmd.UPDATE_CUR_LOCATION, Map.class) {
		@SuppressWarnings("unchecked")
		@Override
		public void process(IoSession session, Request request, Response response) {
			Long playerId = sessionManager.getPlayerId(session);
			Map<String, Object> params = (Map<String, Object>) request.getValue();
			String curLoc = (String) params.get("currLoc");
			armyGroupTrainService.updateCurLocation(playerId, curLoc);
		}
	};
	
	private RequestProcessor getCurLocation = new RequestProcessorAdapter(module, ArmyGroupTrainCmd.GET_CUR_LOCATION) {
		@Override
		public void process(IoSession session, Request request, Response response) {
			Long playerId = sessionManager.getPlayerId(session);
			String curLoc = armyGroupTrainService.getCurLocation(playerId);
			response.setValue(curLoc);
			session.write(response);
		}
	};
	
	private RequestProcessor getCurStatus = new RequestProcessorAdapter(module, ArmyGroupTrainCmd.GET_CUR_STATUS) {
		@Override
		public void process(IoSession session, Request request, Response response) {
			Long playerId = sessionManager.getPlayerId(session);
			Result<String> result = armyGroupTrainService.getCurStatus(playerId);
			response.setValue(result);
			session.write(response);
		}
	};
}
