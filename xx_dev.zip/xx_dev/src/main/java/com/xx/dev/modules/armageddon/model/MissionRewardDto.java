/**
 * @file:MissionRewardDto.java
 * @author:David
 **/
package com.xx.dev.modules.armageddon.model;

import com.xx.dev.modules.reward.result.ValueResultSet;

/**
 * @class:MissionRewardDto
 * @description:
 * @author:David
 * @version:v1.0
 * @date:2013-5-21
 **/
public class MissionRewardDto {
	/** 通关奖励结果 **/
	private ValueResultSet valueResultSet;
	/** 玩家大决战信息 **/
	private ArmageddonInfoDto armageddonInfoDto;
	public ValueResultSet getValueResultSet() {
		return valueResultSet;
	}
	public void setValueResultSet(ValueResultSet valueResultSet) {
		this.valueResultSet = valueResultSet;
	}
	public ArmageddonInfoDto getArmageddonInfoDto() {
		return armageddonInfoDto;
	}
	public void setArmageddonInfoDto(ArmageddonInfoDto armageddonInfoDto) {
		this.armageddonInfoDto = armageddonInfoDto;
	}
	
}

