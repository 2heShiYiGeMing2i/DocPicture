/**
 * @file:CharacterType.java
 * @author:David
 **/
package com.xx.dev.constant;

/**
 * @class:CharacterType
 * @description:游戏通用角色类型
 * @author:David
 * @version:v1.0
 * @date:2013-4-19
 **/
public enum CharacterType {

	/**
	 * 玩家角色 0
	 */
	PLAYER,
	/**
	 * NPC角色 1
	 */
	NPC;
	public static CharacterType valueOf(int value){
		switch (value) {
		case 0:
			return CharacterType.PLAYER;
		case 1:
			return CharacterType.NPC;
		default:
			return CharacterType.PLAYER;
		}
	}
}

