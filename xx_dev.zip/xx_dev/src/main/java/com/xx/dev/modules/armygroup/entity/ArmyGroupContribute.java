package com.xx.dev.modules.armygroup.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

import com.xx.common.db.model.BaseModel;

/**
 * 军团捐赠记录
 * 
 * @author Along
 *
 */
@Entity
@Table(name = "armyGroupContribute")
public class ArmyGroupContribute extends BaseModel<Long> {

	private static final long serialVersionUID = 4885141920309365504L;

	/**
	 * id
	 */
	@Id
	private Long id;
	
	/**
	 * 军团id
	 */
	@Index(name = "armyGroup_contribute_index")
	@Column(columnDefinition = "bigint(20) NOT NULL COMMENT '军团id'")
	private long armyGroupId;
	
	/**
	 * 玩家id
	 */
	@Column(columnDefinition = "bigint(20) NOT NULL COMMENT '玩家id'")
	private long playerId;
	
	/**
	 * 建筑id
	 */
	@Column(columnDefinition = "int(11) not null comment '建筑id'")
	private int buildingId;
	
	/**
	 * 捐献事件id
	 */
	@Column(columnDefinition = "int(11) not null comment '捐献事件id'")
	private int eventId;
	
	/**
	 * 捐献时间
	 */
	@Column(columnDefinition="datetime default '2013-01-01 00:00:00' comment '捐献时间'")
	private Date contributeTime;
	
	/**
	 * 完成度
	 */
	@Column(columnDefinition = "int(11) not null comment '完成度'")
	private int progress;
	
	/**
	 * 贡献值
	 */
	@Column(columnDefinition = "int(11) not null comment '贡献值'")
	private int contribute;
	
	/**
	 * 银元奖励
	 */
	@Column(columnDefinition = "int(11) not null comment '银元奖励'")
	private int silverReward;
	
	/**
	 * 道具id
	 */
	@Column(columnDefinition = "int(11) not null comment '道具id'")
	private int itemId;
	
	/**
	 * 道具数量
	 */
	@Column(columnDefinition = "int(11) not null comment '道具数量'")
	private int itemAmount;
	
	public ArmyGroupContribute() {
		
	}
	
	public ArmyGroupContribute(long armyGroupId, long playerId, int buildingId, int eventId, 
			int progress, int contribute, int silverReward, int itemId, int itemAmount) {
		this.armyGroupId = armyGroupId;
		this.playerId = playerId;
		this.buildingId = buildingId;
		this.eventId = eventId;
		this.contributeTime = new Date();
		this.progress = progress;
		this.contribute = contribute;
		this.silverReward = silverReward;
		this.itemId = itemId;
		this.itemAmount = itemAmount;
	}
	
	@Override
	public Long getId() {
		return this.id;
	}

	@Override
	public void setId(Long id) {
		this.id = id;
	}

	public long getArmyGroupId() {
		return armyGroupId;
	}

	public void setArmyGroupId(long armyGroupId) {
		this.armyGroupId = armyGroupId;
	}

	public long getPlayerId() {
		return playerId;
	}

	public void setPlayerId(long playerId) {
		this.playerId = playerId;
	}

	public int getBuildingId() {
		return buildingId;
	}

	public void setBuildingId(int buildingId) {
		this.buildingId = buildingId;
	}

	public int getEventId() {
		return eventId;
	}

	public void setEventId(int eventId) {
		this.eventId = eventId;
	}

	public Date getContributeTime() {
		return contributeTime;
	}

	public void setContributeTime(Date contributeTime) {
		this.contributeTime = contributeTime;
	}

	public int getProgress() {
		return progress;
	}

	public void setProgress(int progress) {
		this.progress = progress;
	}

	public int getContribute() {
		return contribute;
	}

	public void setContribute(int contribute) {
		this.contribute = contribute;
	}

	public int getSilverReward() {
		return silverReward;
	}

	public void setSilverReward(int silverReward) {
		this.silverReward = silverReward;
	}

	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public int getItemAmount() {
		return itemAmount;
	}

	public void setItemAmount(int itemAmount) {
		this.itemAmount = itemAmount;
	}

}
