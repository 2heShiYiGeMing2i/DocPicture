package com.xx.dev.modules.armygrouptrain.model;

/**
 * 玩家試煉傷害排名
 * @author jy
 *
 */
public class TrainPlayerRankVO {

	/**
	 * 玩家id
	 */
	private long playerId;
	
	/**
	 * 總傷害值
	 */
	private double harm;
	
	/**
	 * 戰鬥力
	 */
	private double ability;

	public long getPlayerId() {
		return playerId;
	}

	public void setPlayerId(long playerId) {
		this.playerId = playerId;
	}

	public double getHarm() {
		return harm;
	}

	public void setHarm(double harm) {
		this.harm = harm;
	}

	public double getAbility() {
		return ability;
	}

	public void setAbility(double ability) {
		this.ability = ability;
	}

	public static TrainPlayerRankVO valueOf(long playerId) {
		TrainPlayerRankVO rankVO = new TrainPlayerRankVO();
		rankVO.playerId = playerId;
		return rankVO;
	}
	
	
}
