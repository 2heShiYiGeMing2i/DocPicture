/**
 * @file:BattleCharacter.java
 * @author:David
 **/
package com.xx.dev.modules.battle.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import org.codehaus.jackson.annotate.JsonIgnore;

import com.xx.common.basedb.BasedbService;
import com.xx.dev.constant.CharacterType;
import com.xx.dev.constant.FormulaID;
import com.xx.dev.constant.ValueType;
import com.xx.dev.modules.battle.core.Battle;
import com.xx.dev.modules.battle.core.BattleRule;
import com.xx.dev.modules.chapter.model.basedb.NpcHero;
import com.xx.dev.modules.skill.model.EffectInfo;
import com.xx.dev.modules.skill.model.SkillBaseType;
import com.xx.dev.modules.skill.model.SkillEffectTiming;
import com.xx.dev.modules.skill.model.SkillEffectType;
import com.xx.dev.modules.skill.model.SkillType;
import com.xx.dev.modules.skill.model.basedb.Skill;
import com.xx.dev.modules.skill.model.basedb.SkillEffect;
import com.xx.dev.modules.skill.model.basedb.SkillEffectConfig;
import com.xx.dev.modules.skill.service.SkillService;
import com.xx.dev.modules.skill.skilleffects.Effect;
import com.xx.dev.modules.skill.skilleffects.HurtEffect;
import com.xx.dev.modules.skill.skilleffects.IncreaseHpEffect;
import com.xx.dev.modules.skill.skilleffects.SkillEffectService;
import com.xx.dev.utils.FormulaHelper;
import com.xx.dev.utils.ServiceFactory;

/**
 * @class:BattleCharacter
 * @description:战斗角色（对应带兵的武将）
 * @author:David
 * @version:v1.0
 * @date:2013-4-19
 **/
public class BattleCharacter implements Cloneable{
	/** 战斗ID（唯一键） **/
	private Long id;
	/** 玩家ID 如果是 NPC,则是npcID**/
	private long playerId = -1l;
	/** 是否是BOSS 0-非boss 1-是boss */
	private int boss = 0;
	/** 武将ID **/
	private long heroId;
	/** 武将基础数据类型 **/
	private int heroType;
	/** 武将阵营 **/
	private int heroCamp = 0;
	/** 武将星级 **/
	private int heroStar = 0;
	/**
	 * 武将品阶
	 */
	private int heroRank = 0;
	/** 角色类型 */
	private CharacterType characterType;
	/** 兵种 */
	private int armType;
	/** 兵阶 **/
	private int armStar;
	/** 带兵数 */
	private int armyCount = 0;
	/** 战斗系数 默认值：1 **/
	private double battleRatio = 1;
	/** 职业 */
	private int heroVocation;
	/** 等级 **/
	private int level;
	/** 战斗属性 **/
	private BattleAttr battleAttr;
	/** 初始HP上限（进入战斗时候血量） **/
	private double initHp;
	/** HP上限 */
	public double maxHp;
	/** 护盾hp */
	private double shieldsHp = 0;
	/** 当前技能ID列表 {skillId: skillLevel}*/
	private Map<Integer, Integer> skillLevelMap;
	/** 当前技能ID对应旧低级技能ID列表 {skillId: skillLevel}*/
	private Map<Integer, Integer> lowSkillLevelMap;
	/** 战斗所属阵容 */
	private BattleGroup battleGroup;
	/** 战斗所属方阵 */
	private BattleTeam battleTeam;
	/** 玩家在方阵中的出手顺序,初始值 **/
	private Integer teamIndex = 0;
	/** 玩家在方阵中的出手位置 **/
	private Integer teamPosition = 0;
	/** 是否具有团结光环 **/
	private boolean unity = false;
	/** 是否死亡状态 */
	private boolean die = false;
	/** 战斗Buff **/
	private Buff buff = new Buff();
	/** 掉落 **/
	private String dropExpr;
	/**
	 * 普通攻击技能
	 */
	private BattleSkillInfo defaultSkillInfo;
	/**
	 * 主动技能列表
	 */
	private BattleSkillInfo[] activeSkillList = {};
	/**
	 * 辅助技能效果Map(初始化后就不变) {SkillEffectTiming：技能效果}
	 */
	private ConcurrentMap<SkillEffectTiming, ConcurrentMap<BattleSkillEffectInfo, Effect>> assistEffectMap = new ConcurrentHashMap<SkillEffectTiming, ConcurrentMap<BattleSkillEffectInfo, Effect>>();
	
	/** 业务系统额外增加的血量，用于扣减兵力使用 **/
	private int extraHp = 0;
	/**
	 * 主将技能ID
	 */
	private int generalSkillId = -1;
	/** 是否邀请主将 **/
	private boolean cheer = false;
	/** 是否主将 **/
	private boolean general = false;
	/** 战斗力  */
	private double ability = 0.0;
	/** 自定义武将头像ID **/
	private int customHeroHeadId = -1;
	/** 自定义武将名称 **/
	private String customHeroName;
	/** 特殊战斗不允许伤害波动 **/
	private boolean noWave = false;
	
	public void reset(){
		if(defaultSkillInfo != null){
			defaultSkillInfo.reset();
		}
		if(activeSkillList != null && activeSkillList.length > 0){
			for (BattleSkillInfo battleSkillInfo : activeSkillList) {
				battleSkillInfo.reset();
			}
		}
		Collection<ConcurrentMap<BattleSkillEffectInfo, Effect>> collection = this.assistEffectMap.values();
		if(collection != null && !collection.isEmpty()){
			for (Map<BattleSkillEffectInfo, Effect> linkedHashMap : collection) {
				Set<BattleSkillEffectInfo> set = linkedHashMap.keySet();
				for (BattleSkillEffectInfo battleSkillEffectInfo : set) {
					battleSkillEffectInfo.reset();
				}
			}
		}
	}
	public BattleCharacter() {
		super();
	}
	public BattleCharacter(NpcHero npcHero, Integer teamPosition) {
		super();
		this.id = Long.valueOf(npcHero.getId());
		this.playerId = Long.valueOf(npcHero.getId());
		this.boss = npcHero.getBoss();
		this.heroType = npcHero.getHeroId();
		this.heroCamp = npcHero.getHeroCamp();
		this.characterType = CharacterType.NPC;
		this.armType = npcHero.getArmType();
		this.armStar = npcHero.getArmStar();
		this.armyCount = npcHero.getArmyCount();
		this.heroVocation = npcHero.getHeroVocation();
		this.level = npcHero.getLevel();
		this.battleAttr = new BattleAttr(npcHero.getAttack(), npcHero.getDefend(), npcHero.getStrategyAttack(), npcHero.getStrategyDefend(), npcHero.getCrit(), npcHero.getResist(), npcHero.getSkillPower(), npcHero.getHp(), npcHero.getSkillDefend());
		this.initHp = battleAttr.hp;
		this.maxHp = battleAttr.hp;
		this.skillLevelMap = new HashMap<Integer, Integer>(npcHero.getSkillLevelMap());
		this.lowSkillLevelMap = new HashMap<Integer, Integer>();
		this.teamIndex = teamPosition;
		this.dropExpr = npcHero.getDropExpr();
		this.ability = npcHero.getAbility();
		//读取普通攻击技能
		/*initDefaultSkill();*/
		//初始化技能信息
		/*initSkillInfos();*/
	}
	public BattleCharacter(long playerId, long heroId, int heroType, int heroCamp, int heroStar, int heroRank, double battleRatio, 
			CharacterType characterType, int armType, int armStar, int armyCount, int heroVocation, int level, BattleAttr battleAttr,
			double maxHp, Map<Integer, Integer> skillLevelMap, Map<Integer, Integer> lowSkillLevelMap, Integer teamPosition, double ability) {
		super();
		this.playerId = playerId;
		this.heroId = heroId;
		this.heroType = heroType;
		this.heroCamp = heroCamp;
		this.heroStar = heroStar;
		this.heroRank = heroRank;
		this.battleRatio = battleRatio;
		this.characterType = characterType;
		this.armType = armType;
		this.armStar = armStar;
		this.armyCount = armyCount;
		this.heroVocation = heroVocation;
		this.level = level;
		this.battleAttr = battleAttr;
		this.initHp = battleAttr.hp;
		this.maxHp = maxHp;
		this.skillLevelMap = skillLevelMap;
		this.lowSkillLevelMap = lowSkillLevelMap;
		this.teamIndex = teamPosition;
		this.ability = ability;
		//读取普通攻击技能
		/*initDefaultSkill();*/
		//初始化技能信息
		/*initSkillInfos();*/
	}
	public BattleCharacter(long playerId, long heroId, int heroType, int heroCamp, int heroStar, int heroRank, double battleRatio, 
			CharacterType characterType, int armType, int armStar, int armyCount, int heroVocation, int level, BattleAttr battleAttr,
			double maxHp, Map<Integer, Integer> skillLevelMap, Map<Integer, Integer> lowSkillLevelMap, Integer teamPosition, double ability, int customHeroHeadId, String customHeroName) {
		super();
		this.playerId = playerId;
		this.heroId = heroId;
		this.heroType = heroType;
		this.heroCamp = heroCamp;
		this.heroStar = heroStar;
		this.heroRank = heroRank;
		this.battleRatio = battleRatio;
		this.characterType = characterType;
		this.armType = armType;
		this.armStar = armStar;
		this.armyCount = armyCount;
		this.heroVocation = heroVocation;
		this.level = level;
		this.battleAttr = battleAttr;
		this.initHp = battleAttr.hp;
		this.maxHp = maxHp;
		this.skillLevelMap = skillLevelMap;
		this.lowSkillLevelMap = lowSkillLevelMap;
		this.teamIndex = teamPosition;
		this.ability = ability;
		this.customHeroHeadId = customHeroHeadId;
		this.customHeroName = customHeroName;
		//读取普通攻击技能
		/*initDefaultSkill();*/
		//初始化技能信息
		/*initSkillInfos();*/
	}
	public BattleCharacter(long playerId, long heroId, CharacterType characterType, int armType, int armStar,
			int armyCount, double battleRatio, int heroVocation, int level, BattleAttr battleAttr,
			double maxHp, Map<Integer, Integer> skillLevelMap, Map<Integer, Integer> lowSkillLevelMap,
			BattleTeam battleTeam, Integer teamPosition, double ability) {
		super();
		this.playerId = playerId;
		this.heroId = heroId;
		this.characterType = characterType;
		this.armType = armType;
		this.armStar = armStar;
		this.armyCount = armyCount;
		this.battleRatio = battleRatio;
		this.heroVocation = heroVocation;
		this.level = level;
		this.battleAttr = battleAttr;
		this.initHp = battleAttr.hp;
		this.maxHp = maxHp;
		this.skillLevelMap = skillLevelMap;
		this.lowSkillLevelMap = lowSkillLevelMap;
		this.battleTeam = battleTeam;
		this.teamIndex = teamPosition;
		this.ability = ability;
		//读取普通攻击技能
		/*initDefaultSkill();*/
		//初始化技能信息
		/*initSkillInfos();*/
	}
	/*private static final int DEFAULT_SKILL_ID = 0;*/
	/**
	 * @description:读取普通攻击技能
	 *
	 */
	/*private void initDefaultSkill() {
		SkillService skillService = ServiceFactory.getSkillService();
		BasedbService basedbService = ServiceFactory.getBasedbService(); 
		Skill skill = basedbService.get(Skill.class, DEFAULT_SKILL_ID);
		Map<SkillEffectTiming, List<EffectInfo>> map = skillService.getEffectMapOfSkill(DEFAULT_SKILL_ID);
		this.defaultSkillInfo = new BattleSkillInfo(skill, 0, effectToInfo(DEFAULT_SKILL_ID, 0, map));
	}*/
	/**
	 * @description:增加额外的技能，必须要在	initSkillInfos方法调用前使用才会生效
	 * @param skillId
	 * @param skillLevel
	 */
	public void addExtraSkill(int skillId,int skillLevel){
		if(skillLevelMap == null){
			return;
		}
		skillLevelMap.put(skillId, skillLevel);
	}
	/**
	 * @description:初始化技能信息
	 * 战斗时初始化才有位置信息
	 *
	 */
	public void initSkillInfos() {
		if(skillLevelMap == null || skillLevelMap.isEmpty())
			return;
		boolean isAddAssist = true;				
		if(this.assistEffectMap != null && !this.assistEffectMap.isEmpty()){
			isAddAssist = false;
		}
		//{skillId: skillLevel}
		SkillService skillService = ServiceFactory.getSkillService();
		BasedbService basedbService = ServiceFactory.getBasedbService(); 
		Set<Entry<Integer, Integer>> skillSet = skillLevelMap.entrySet();
		List<BattleSkillInfo> activeSkillList = new ArrayList<BattleSkillInfo>();
		for (Entry<Integer, Integer> entry : skillSet) {
			Skill skill = basedbService.get(Skill.class, entry.getKey());
			if(skill == null)
				continue;
			if(skill.getSkillType() == SkillType.CAPTAIN.ordinal()){
				this.generalSkillId = skill.getId();
				if(!isCheer() && !isGeneral()){//主将技能只会在主将或者 邀请玩家身上生效
					continue;
				}
			}
			if(skill.getBaseType() == SkillBaseType.ACTIVE_SKILL.ordinal()){
				Map<SkillEffectTiming, List<EffectInfo>> map = skillService.getEffectMapOfSkill(entry.getKey());
				BattleSkillInfo battleSkillInfo = new BattleSkillInfo(skill, entry.getValue(), effectToInfo(entry.getKey(), entry.getValue(), map));
				activeSkillList.add(battleSkillInfo);
			}else if(skill.getBaseType() == SkillBaseType.NONE.ordinal()){
				Map<SkillEffectTiming, List<EffectInfo>> map = skillService.getEffectMapOfSkill(entry.getKey());
				this.defaultSkillInfo = new BattleSkillInfo(skill, 0, effectToInfo(entry.getKey(), 0, map));
			}else if(isAddAssist){
				Map<SkillEffectTiming, List<EffectInfo>> map = skillService.getEffectMapOfSkill(entry.getKey());
				addAssistEffects(entry.getKey(), entry.getValue(), map);
			}
		}
		sortActiveSkills(activeSkillList);
		this.activeSkillList = activeSkillList.toArray(this.activeSkillList);
	}
	/**
	 * @description:添加辅助技能效果
	 * @param skillId
	 * @param skillLevel
	 * @param map Map<SkillEffectTiming, List<EffectInfo>>
	 */
	private void addAssistEffects(Integer skillId, Integer skillLevel, Map<SkillEffectTiming, List<EffectInfo>> map) {
		if (map == null || map.isEmpty()) {
			return;
		}
		SkillService skillService = ServiceFactory.getSkillService();
		for (Entry<SkillEffectTiming, List<EffectInfo>> entry: map.entrySet()) {
			SkillEffectTiming timing = entry.getKey();
			List<EffectInfo> effectList = entry.getValue();
			
			if (!effectList.isEmpty()) {
				ConcurrentMap<BattleSkillEffectInfo, Effect> assistEffectMap = this.assistEffectMap.get(timing);
				if (assistEffectMap == null) {
					assistEffectMap = new ConcurrentHashMap<BattleSkillEffectInfo, Effect>();
					this.assistEffectMap.put(timing, assistEffectMap);
				}
				for (EffectInfo effectInfo : effectList) {
					SkillEffect skillEffect = effectInfo.getSkillEffect();
					if(skillEffect.getEffectType() == SkillEffectType.UNITY){
						this.unity = true;
						continue;
					}
					BattleSkillEffectInfo battleSkillEffectInfo = new BattleSkillEffectInfo(this, skillEffect, skillService.loadSkill(skillId), skillLevel, getLowSkillLevel(skillId));
					assistEffectMap.put(battleSkillEffectInfo, effectInfo.getEffect());
				}
			}
		}	
	}
	/**
	 * 主动技能排序
	 */
	private void sortActiveSkills(List<BattleSkillInfo> activeSkillList) {
		Collections.sort(activeSkillList, new Comparator<BattleSkillInfo>() {
			@Override
			public int compare(BattleSkillInfo o1, BattleSkillInfo o2) {
				if (o1.getSkill().getBaseType() < o2.getSkill().getBaseType()) {
					return -1;
				}
				if (o1.getSkill().getBaseType() > o2.getSkill().getBaseType()) {
					return 1;
				}
				return 1;
			}
			
		});
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public CharacterType getCharacterType() {
		return characterType;
	}
	public void setCharacterType(CharacterType characterType) {
		this.characterType = characterType;
	}
	public int getArmType() {
		return armType;
	}
	public void setArmType(int armType) {
		this.armType = armType;
	}
	public int getArmyCount() {
		return armyCount;
	}
	public void setArmyCount(int armyCount) {
		this.armyCount = armyCount;
	}
	public int getHeroVocation() {
		return heroVocation;
	}
	public void setHeroVocation(int heroVocation) {
		this.heroVocation = heroVocation;
	}
	public int getLevel() {
		return level;
	}
	public void setLevel(int level) {
		this.level = level;
	}
	public BattleAttr getBattleAttr() {
		return battleAttr;
	}
	public void setBattleAttr(BattleAttr battleAttr) {
		this.battleAttr = battleAttr;
	}
	public double getMaxHp() {
		return maxHp;
	}
	public void setMaxHp(double maxHp) {
		this.maxHp = maxHp;
	}
	public Map<Integer, Integer> getSkillLevelMap() {
		return skillLevelMap;
	}
	public void setSkillLevelMap(Map<Integer, Integer> skillLevelMap) {
		this.skillLevelMap = skillLevelMap;
	}
	public BattleTeam getBattleTeam() {
		return battleTeam;
	}
	public void setBattleTeam(BattleTeam battleTeam) {
		this.battleTeam = battleTeam;
	}
	public Integer getTeamPosition() {
		return teamPosition;
	}
	public void setTeamPosition(Integer teamPosition) {
		this.teamPosition = teamPosition;
	}
	public boolean isDie() {
		return die;
	}
	public void setDie(boolean die) {
		this.die = die;
	}
	public boolean isBlock(int curRound) {
		if(buff.getBlockBuff() != null && buff.getBlockBuff().getPersistRound(curRound) > 0){
			//眩晕一次后递减
			if(buff.getBlockBuff().persistRound > 0){
				buff.getBlockBuff().setPersistRound(buff.getBlockBuff().persistRound - 1);
			}
			return true;
		}
		return false;
	}
	public BattleSkillInfo[] getActiveSkillList() {
		return activeSkillList;
	}
	public void setActiveSkillList(BattleSkillInfo[] activeSkillList) {
		this.activeSkillList = activeSkillList;
	}
	public BattleSkillInfo getDefaultSkillInfo() {
		return defaultSkillInfo;
	}
	public void setDefaultSkillInfo(BattleSkillInfo defaultSkillInfo) {
		this.defaultSkillInfo = defaultSkillInfo;
	}
	public Buff getBuff() {
		return buff;
	}
	public void setBuff(Buff buff) {
		this.buff = buff;
	}
	public double getShieldsHp() {
		return shieldsHp;
	}
	public void setShieldsHp(double shieldsHp) {
		this.shieldsHp = shieldsHp;
	}
	public Map<Integer, Integer> getLowSkillLevelMap() {
		return lowSkillLevelMap;
	}
	public void setLowSkillLevelMap(Map<Integer, Integer> lowSkillLevelMap) {
		this.lowSkillLevelMap = lowSkillLevelMap;
	}
	public int getArmStar() {
		return armStar;
	}
	public void setArmStar(int armStar) {
		this.armStar = armStar;
	}
	
	public double getInitHp() {
		return initHp;
	}

	public void setInitHp(double initHp) {
		this.initHp = initHp;
	}
	
	public Integer getTeamIndex() {
		return teamIndex;
	}

	public void setTeamIndex(Integer teamIndex) {
		this.teamIndex = teamIndex;
	}
	
	public boolean isUnity() {
		return unity;
	}

	public void setUnity(boolean unity) {
		this.unity = unity;
	}
	
	public BattleGroup getBattleGroup() {
		return battleGroup;
	}

	public void setBattleGroup(BattleGroup battleGroup) {
		this.battleGroup = battleGroup;
	}
	
	public int getHeroType() {
		return heroType;
	}
	public void setHeroType(int heroType) {
		this.heroType = heroType;
	}
	public String getDropExpr() {
		return dropExpr;
	}
	public void setDropExpr(String dropExpr) {
		this.dropExpr = dropExpr;
	}
	public long getPlayerId() {
		return playerId;
	}
	public void setPlayerId(long playerId) {
		this.playerId = playerId;
	}
	public long getHeroId() {
		return heroId;
	}
	public void setHeroId(long heroId) {
		this.heroId = heroId;
	}
	public int getExtraHp() {
		return extraHp;
	}
	public void setExtraHp(int extraHp) {
		this.extraHp = extraHp;
	}
	public int getHeroStar() {
		return heroStar;
	}
	public void setHeroStar(int heroStar) {
		this.heroStar = heroStar;
	}
	public int getHeroRank() {
		return heroRank;
	}
	public void setHeroRank(int heroRank) {
		this.heroRank = heroRank;
	}
	public boolean isGeneral() {
		return general;
	}
	public void setGeneral(boolean general) {
		this.general = general;
	}
	public boolean isCheer() {
		return cheer;
	}
	public void setCheer(boolean cheer) {
		this.cheer = cheer;
	}
	public int getGeneralSkillId() {
		return generalSkillId;
	}
	public void setGeneralSkillId(int generalSkillId) {
		this.generalSkillId = generalSkillId;
	}
	public int getHeroCamp() {
		return heroCamp;
	}
	public void setHeroCamp(int heroCamp) {
		this.heroCamp = heroCamp;
	}
	public double getBattleRatio() {
		return battleRatio;
	}
	public void setBattleRatio(double battleRatio) {
		this.battleRatio = battleRatio;
	}
	public int getBoss() {
		return boss;
	}
	public void setBoss(int boss) {
		this.boss = boss;
	}
	public double getAbility() {
		return ability;
	}
	public void setAbility(double ability) {
		this.ability = ability;
	}
	public int getCustomHeroHeadId() {
		return customHeroHeadId;
	}
	public void setCustomHeroHeadId(int customHeroHeadId) {
		this.customHeroHeadId = customHeroHeadId;
	}
	public String getCustomHeroName() {
		return customHeroName;
	}
	public void setCustomHeroName(String customHeroName) {
		this.customHeroName = customHeroName;
	}	
	public boolean isNoWave() {
		return noWave;
	}
	public void setNoWave(boolean noWave) {
		this.noWave = noWave;
	}
	//一下方法在战斗过程中使用
	/**
	 * 施放辅助技能效果
	 * @param fcx FootContext
	 */
	public void fireAssistSkillEffect(FootContext fcx) {
		Map<BattleSkillEffectInfo, Effect> effectMap = this.assistEffectMap.get(fcx.getTiming());
		this.fireSkillEffect(fcx, effectMap);
	}
	/**
	 * 施放技能效果
	 * @param fcx FootContext
	 * @param effectMap  Map<BattleSkillEffectInfo, Effect> effectMap
	 */
	private void fireSkillEffect(FootContext fcx, Map<BattleSkillEffectInfo, Effect> effectMap) {
		if (effectMap != null && !effectMap.isEmpty()) {
			Set<Entry<BattleSkillEffectInfo, Effect>> effectSet = effectMap.entrySet();
			for (Entry<BattleSkillEffectInfo, Effect> entry : effectSet) {
				BattleSkillEffectInfo battleSkillEffectInfo = entry.getKey();
				Effect effect = entry.getValue();
				List<Integer> attackPosList = new ArrayList<Integer>();
				Battle.buildAttackPosList(this, battleGroup, attackPosList, battleSkillEffectInfo.getSkill());
				fcx.setAttackRange(battleSkillEffectInfo.getSkill().getAttackTargetRange());
				if(fcx.getDefenders() == null || fcx.getDefenders().isEmpty()){
					fcx.setDefenders(attackPosList);
				}
				effect.doEffect(battleSkillEffectInfo, fcx);
			}
		}
	}
	/**
	 * @description:扣减主动技能冷却回合
	 *
	 */
	public void decrActiveSkillCoolRound() {
		if (this.activeSkillList == null || this.activeSkillList.length <= 0) {
			return;
		}
		
		for (BattleSkillInfo skillInfoVO: this.activeSkillList) {
			if (skillInfoVO.isCoolRound()) {
				//减一出手回合
				skillInfoVO.decrLeftCoolRound();
			} else {
				skillInfoVO.setCoolRound(true);
			}
		}
	}
	/**
	 * @description:释放技能	
	 * @return
	 */
	public BattleSkillInfo fireActiveSkill(BattleGroup battleGroup, Map<Integer, Double> costAttr) {
		if (this.activeSkillList == null || this.activeSkillList.length <= 0) {
			return defaultSkillInfo;
		}
		for (int i = 0; i < this.activeSkillList.length; i++) {
			BattleSkillInfo battleSkillInfo = this.activeSkillList[i];

			//当前冷却回合
			int currLeftCoolRound = battleSkillInfo.getLeftCoolRound();
			//还在冷却中
			if (currLeftCoolRound > 0) {
				continue;
			}
			int skillLevel = battleSkillInfo.getSkillLevel();

			//消耗怒气
			double costDander = battleSkillInfo.getSkill().getDanderCost(skillLevel);
			double dander = battleGroup.getDander();
			if (battleSkillInfo.getSkill().getDanderType() == ValueType.PERCENT.ordinal()) {
				if (dander < 1) {
					continue;
				}
				costDander *= dander;
			}
			costDander = Math.ceil(costDander);
			if (dander < costDander) {
				continue;
			}
			if(costDander > 0){
				battleGroup.addDander(-costDander);
				costAttr = new HashMap<Integer, Double>();
				costAttr.put(BattleAttrType.DANDER, costDander);
			}
			battleSkillInfo.incCurrTriggerCount();
			battleSkillInfo.setCoolRound(false);
			battleSkillInfo.setLeftCoolRound(battleSkillInfo.getSkill().getCoolRound(skillLevel));
			battleSkillInfo.setLeftCoolRoundBefore(0);
			return battleSkillInfo;
		}
		return defaultSkillInfo;
	}
	/**
	 * 取得玩家的某个技能等级
	 * @param skillId 技能id
	 * @return 技能等级
	 */
	public int getSkillLevel(int skillId) {
		Integer skillLevel = this.skillLevelMap.get(skillId);
		return skillLevel != null ? skillLevel : 0;
	}
	/**
	 * @description:释放假死技能	
	 * @param hp
	 */
	public void dieAway(double hp){
		this.battleAttr.hp = hp;
	}
	/**
	 * 玩家复活
	 */
	public void revive(double hp){
		if(this.die){
			this.battleAttr.hp = hp;
			this.die = false;
		}
	}
	/**
	 * 加减hp
	 * @param hp 加减值
	 */
	public void addHp(double hp, FootContext fcx) {					
		//设置具体效果值
		if(fcx != null && fcx.isHpAfterFlag()){
			fcx.setEffectValue(hp);
		}
		//扣血且有护盾
		if (hp < 0 && this.shieldsHp > 0) {
			double leftHp = this.shieldsHp + hp;
			if (leftHp >= 0) {
				this.shieldsHp = leftHp;
				hp = 0;
				return;
			} else {
				this.shieldsHp = 0;
				hp = leftHp;
			}
		}
		
		this.battleAttr.hp += hp;
		if (this.battleAttr.hp > this.initHp) {
			this.battleAttr.hp = this.initHp;
		}
		if(fcx.isHpAfterFlag()){
			fcx.setHpAfter(this.battleAttr.hp);
		}else {
			fcx.setHpAfterFlag(true);
		}
		if (this.battleAttr.hp <= 0) {
			this.battleAttr.hp = 0;
			this.die = true;
			if(fcx != null){
				List<Integer> defends = new ArrayList<Integer>();
				defends.add(fcx.getAttacker().getTeamPosition());
				FootContext fContext = new FootContext(fcx.getCurrRound(), SkillEffectTiming.DEAD, fcx.getAttackType(), this, getBattleGroup(), fcx.getAttackRange(), defends, fcx.getBattleReport(), fcx.getSkillEffectConfig());
				fireAssistSkillEffect(fContext);
				if(fContext.getEffectDetails() != null){
					if(fcx.getEffectDetails() == null){
						fcx.setEffectDetails(fContext.getEffectDetails());
					}else {
						fcx.getEffectDetails().addAll(fContext.getEffectDetails());
					}
				}
			}
		}
	}

	/**
	 * @description:得到低级技能ID	
	 * @param skillId
	 * @return
	 */
	public int getLowSkillLevel(int skillId){
		if(lowSkillLevelMap == null){
			return 0;
		}
		return lowSkillLevelMap.get(skillId) == null? 0:lowSkillLevelMap.get(skillId);
	}
	/**
	 * @description:技能效果集转换成战斗过程中 技能效果集
	 * @param skillId
	 * @param skillLevel
	 * @param map Map<SkillEffectTiming, Map<BattleSkillEffectInfo, Effect>>
	 * @return
	 */
	public Map<SkillEffectTiming, LinkedHashMap<BattleSkillEffectInfo, Effect>> effectToInfo(Integer skillId, Integer skillLevel, Map<SkillEffectTiming, List<EffectInfo>> map){
		Map<SkillEffectTiming, LinkedHashMap<BattleSkillEffectInfo, Effect>> effectMap = new HashMap<SkillEffectTiming, LinkedHashMap<BattleSkillEffectInfo,Effect>>();
		if (map == null || map.isEmpty()) {
			return effectMap;
		}
		SkillService skillService = ServiceFactory.getSkillService();
		for (Entry<SkillEffectTiming, List<EffectInfo>> entry: map.entrySet()) {
			SkillEffectTiming timing = entry.getKey();
			List<EffectInfo> effectList = entry.getValue();
			if (!effectList.isEmpty()) {
				LinkedHashMap<BattleSkillEffectInfo, Effect> infoMap = new LinkedHashMap<BattleSkillEffectInfo, Effect>();
				for (EffectInfo effectInfo : effectList) {
					BattleSkillEffectInfo battleSkillEffectInfo = new BattleSkillEffectInfo(this, effectInfo.getSkillEffect(), skillService.loadSkill(skillId), skillLevel, getLowSkillLevel(skillId));
					infoMap.put(battleSkillEffectInfo, effectInfo.getEffect());
				}
				effectMap.put(timing, infoMap);
			}
		}
		return effectMap;
	}
	private int getTeamPos(BattleTeam battleTeam){
		if(BattleTeam.OFFENSE_TEAM.equals(battleTeam)){
			return BattleRule.OFFENSE_POS[teamIndex-1];
		}
		return BattleRule.DEFENSE_POS[teamIndex-1];
	}
	/**
	 * @description:转换成客户端显示对象	
	 * @return
	 */
	public BattleCharacterDto toBattleCharacterDto(){
		BattleCharacterDto battleCharacterDto = new BattleCharacterDto(this);
		return battleCharacterDto;
	}
	/**
	 * @description:	
	 * @param battleSkillEffectInfo
	 * @param fcx
	 * @return
	 */
	private List<SkillEffectDetail> getEffectList(SkillEffectTiming stateTiming, BattleReport battleReport) {
		if(battleReport == null){
			return null;
		}
		if(SkillEffectTiming.EVERY_ROUND.equals(stateTiming)){
			return battleReport.getInitEffects();
		}
		BattleDetail battleDetail = battleReport.loadBattleDetail(getTeamPosition());
		if(battleDetail == null){
			return null;
		}
		return battleDetail.getEffectDetails();
	}
	/**
	 * 施放状态效果
	 * @param currRound 当前回合
	 * @param stateTiming SkillEffectTiming
	 */
	public void fireBuffEffects(int currRound, SkillEffectTiming stateTiming, BattleReport battleReport, SkillEffectConfig skillEffectConfig, BattleGroup battleGroup) {
		List<Integer> stateList = this.buff.listTimeingState(stateTiming.ordinal());
		if(stateList == null || stateList.isEmpty()){
			return;
		}
		FormulaHelper formulaHelper = ServiceFactory.getFormulaHelper();
		BattleGroup attackerGroup = battleGroup.getOpposeBattleGroup();
		List<SkillEffectDetail> initEffects = getEffectList(stateTiming, battleReport);
		//中毒
		Map<Integer, PoisonBuff> poisonBuffs = buff.getPoisonBuff();
		PoisonBuff poisonBuff;
		for (Integer effectId : stateList) {
			poisonBuff = poisonBuffs.get(effectId);
			if(die){
				break;
			}else if(poisonBuff == null){
				continue;
			}
			if(poisonBuff.getPersistRound(currRound) > 0){
				double shieldsHpBefore = getShieldsHp();
				double hpBefore = battleAttr.hp;
				double value = this.battleAttr.hp*poisonBuff.getEffect() + poisonBuff.getEffectBase();
				//中毒伤害	当前大回合数	回合伤害加成	修正系数	我方等级	敌方等级	等级压制			
				value = formulaHelper.invoke(FormulaID.BATLE_POISON, value, currRound, skillEffectConfig.getRoundHurt(), skillEffectConfig.getReairNum(), this.level, poisonBuff.getAttackerLevel(), skillEffectConfig.getLevelEnhance()).doubleValue();
				BattleCharacter attacker = attackerGroup.getAttacker(poisonBuff.getAttackerPos());
				List<Integer> defenders = new ArrayList<Integer>(1);
				defenders.add(getTeamPosition());
				FootContext fContext = new FootContext(currRound, stateTiming, BattleAttackType.NONE, attacker, attackerGroup, BattleTargetRange.DEFAULT, defenders, battleReport, skillEffectConfig);
				this.addHp(-value, fContext);
				double hpAfter = battleAttr.hp;
				double shieldsHpAfter = getShieldsHp();
				if(initEffects != null){
					SkillEffect skillEffect = poisonBuff.getSkillEffect();
					BattleAttrChanges attrChanges = new BattleAttrChanges(this, (hpAfter-hpBefore), hpAfter, fContext.getEffectValue(), (shieldsHpAfter-shieldsHpBefore), shieldsHpAfter);
					SkillEffectDetail skillEffectDetail = new SkillEffectDetail(skillEffect.getEffectType(), skillEffect.getId(), skillEffect.getAttrType(), poisonBuff.getAttackerId(), poisonBuff.getAttackerPos(), poisonBuff.getPersistRound(currRound), attrChanges);
					initEffects.add(skillEffectDetail);
				}
				if(die){
					battleGroup.removeDeadPos(getTeamPosition());
				}
			}
		}
		if(die){
			return;
		}
		SkillEffectService skillEffectService = ServiceFactory.getSkillEffectService();
		IncreaseHpEffect increaseHpEffect = skillEffectService.getIncreaseHpEffect();
		HurtEffect hurtEffect = skillEffectService.getHurtEffect();
		//加血
		//中毒
		Map<Integer, IncreaseHpBuff> increaseHpBuffs = buff.getIncreaseHpBuff();
		IncreaseHpBuff increaseHpBuff;
		for (Integer effectId : stateList) {
			if(increaseHpBuffs.containsKey(effectId)){
				increaseHpBuff = increaseHpBuffs.get(effectId);
				int persistRound = increaseHpBuff.getPersistRound(currRound);
				if(persistRound > 0){
					Skill skill = increaseHpBuff.getSkill();
					SkillEffect skillEffect = increaseHpBuff.getSkillEffect();
					BattleCharacter attacker = increaseHpBuff.getAttacker();
					double shieldsHpBefore = getShieldsHp();
					double hpBefore = battleAttr.hp;
					double actEffect = increaseHpEffect.calcIncreaseValue(skill, skillEffect, currRound, skillEffectConfig, increaseHpBuff.getSkillLevel(), increaseHpBuff.getLowSkillLevel(), attacker, this);
					actEffect *= hurtEffect.getWaveValue(increaseHpBuff.getAttacker(), currRound, skillEffectConfig);
					addHp(actEffect, null);
					double hpAfter = battleAttr.hp;
					double shieldsHpAfter = getShieldsHp();
					if(initEffects != null){
						BattleAttrChanges attrChanges = new BattleAttrChanges(this, (hpAfter-hpBefore), hpAfter, actEffect, (shieldsHpAfter-shieldsHpBefore), shieldsHpAfter);
						SkillEffectDetail skillEffectDetail = new SkillEffectDetail(skillEffect.getEffectType(), skillEffect.getId(), skillEffect.getAttrType(), attacker.getId(), attacker.getTeamPosition(), persistRound, attrChanges);
						initEffects.add(skillEffectDetail);
					}
				}
			}
		}
	}
	/**
	 * @description:刷新对应阵容的位置	
	 *
	 */
	public void flushTeamPos() {
		this.teamPosition = getTeamPos(battleTeam);
	}
	/**
	 * 按百分比额外提升玩家战斗属性
	 */
	public void increaseBatleAttr(double increase){
		int value = this.battleAttr.increase(increase);
		this.extraHp += value;
		this.initHp = this.battleAttr.hp;
		this.maxHp += value;
	}
	
	/**
	 * 应用血量Buff
	 * @param increase 增加的倍数
	 */
	public void increaseHpBuffAttr(double increase) {
		if (increase > 0) {
			int value = Double.valueOf(this.getBattleAttr().hp * increase).intValue();
			this.getBattleAttr().add(BattleAttrType.HP, value);
			this.extraHp += value;
			this.initHp = this.getBattleAttr().hp;
			this.maxHp += value;
		}
	}
	
	public BattleCharacter clone(){
		try {
			BattleCharacter bc = (BattleCharacter) super.clone();
			
			if(battleAttr != null){
				bc.battleAttr = battleAttr.clone();
			}
			
			bc.buff = new Buff();
			
			if(!assistEffectMap.isEmpty()){
				ConcurrentMap<SkillEffectTiming, ConcurrentMap<BattleSkillEffectInfo, Effect>> assistEffectMap = new ConcurrentHashMap<SkillEffectTiming, ConcurrentMap<BattleSkillEffectInfo,Effect>>();
				Set<Entry<SkillEffectTiming, ConcurrentMap<BattleSkillEffectInfo, Effect>>> set = assistEffectMap.entrySet();
				for (Entry<SkillEffectTiming, ConcurrentMap<BattleSkillEffectInfo, Effect>> entry : set) {
					ConcurrentMap<BattleSkillEffectInfo, Effect> newMap = new ConcurrentHashMap<BattleSkillEffectInfo, Effect>(); 
					
					Map<BattleSkillEffectInfo, Effect> effectMap = entry.getValue();
					Set<Entry<BattleSkillEffectInfo, Effect>> newSet = effectMap.entrySet();
					for (Entry<BattleSkillEffectInfo, Effect> entry2 : newSet) {
						newMap.put(entry2.getKey().clone(), entry2.getValue());
					}
					assistEffectMap.put(entry.getKey(), newMap);
				}
				bc.assistEffectMap = assistEffectMap;
			}
			return bc;
		} catch (CloneNotSupportedException ex) {
			return null;
		}
	}
	
	public ConcurrentMap<SkillEffectTiming, ConcurrentMap<BattleSkillEffectInfo, Effect>> loadAssistEffectMap() {
		return assistEffectMap;
	}
	
	public void changeSkillCound(double actEffect){
		if(this.activeSkillList != null){
			for (BattleSkillInfo battleSkillInfo : this.activeSkillList) {
				if(actEffect > 0){
					battleSkillInfo.increaseLeftCoolRound(Double.valueOf(actEffect).intValue());
				}else {
					battleSkillInfo.decreaseLeftCoolRound(Double.valueOf(actEffect).intValue());
				}
			}
		}
	}
	@JsonIgnore
	public int getActiveSkillLeftCoolRound(){
		if(this.activeSkillList.length > 0){
			return activeSkillList[0].getLeftCoolRound();
		}
		return 0;
	}
	@JsonIgnore
	public int getActiveSkillLeftCoolRoundBefore(){
		if(this.activeSkillList.length > 0){
			return activeSkillList[0].getLeftCoolRoundBefore();
		}
		return 0;
	}	
}

