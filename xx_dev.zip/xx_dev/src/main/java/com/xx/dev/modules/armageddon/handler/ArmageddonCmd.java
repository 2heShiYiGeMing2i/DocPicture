/**
 * @file:ArmageddonCmd.java
 * @author:David
 **/
package com.xx.dev.modules.armageddon.handler;
/**
 * @class:ArmageddonCmd
 * @description:大决战指令
 * @author:David
 * @version:v1.0
 * @date:2013-5-22
 **/
public interface ArmageddonCmd {

	final String MODULE_NAME = "ARMAGEDDON";
	
	/**
	 * 获取进度
	 * @return ArmageddonInfoDto
	 */
	int CHAPTER_INFO = 1;
	
	/**
	 * 创建房间
	 * @return CreateRoomDto
	 */
	int CREATEROOM = 2;
	
	/**
	 * 获取玩家助阵列表
	 * @return CheerInfoDto
	 */
	int CHEERINFO = 3;
	
	/**
	 * 付费获取玩家助阵列表
	 * @param long cheerId 需要保留的cheerId
	 * @return FlushCheerDto
	 */
	int FLUSHCHEERINFO = 4;
	
	/**
	 * 进入单人副本的据点
	 * @param missionId 据点id
	 * @param cheerIdOne 邀请玩家ID
	 * @param cheerIdTwo 邀请玩家ID
	 * @param formation 玩家ID_1|玩家ID_2|玩家ID_3
	 * @param hardType 困难模式 1 - 简单  2 - 困难
	 * @return EnterInfoDto
	 */
	int ENTER_CHAPTER = 5;
	
	/**
	 * 攻击据点里怪物
	 * @param missionId 部队所属据点id
	 * @return AttackResultDto
	 */
	int ATTACK_MONSTER = 6;
	
	/**
	 * 领取通关奖励
	 * @return MissionRewardDto
	 */
	int REWARD_AREA = 7;
	
	/**
	 * 秒CD时间
	 * @return BuyTimeDto
	 */
	int COST_CD = 8;
}

