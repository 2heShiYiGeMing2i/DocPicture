package com.xx.dev.event;

import java.util.Date;

import org.apache.mina.core.session.IoSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.xx.common.db.cache.DbCachedService;
import com.xx.common.event.AbstractReceiver;
import com.xx.common.log.LogHelper;
import com.xx.common.util.DateUtil;
import com.xx.common.util.IpUtils;
import com.xx.dev.constant.AdultStatus;
import com.xx.dev.constant.SessionKeys;
import com.xx.dev.modules.activity.service.ActivityService;
import com.xx.dev.modules.armygrouptrain.service.ArmyGroupTrainService;
import com.xx.dev.modules.cn360privilege.service.PrivilegeGiftService;
import com.xx.dev.modules.cnxunleimember.service.XunleiMemberService;
import com.xx.dev.modules.cnyymember.service.YYMemberService;
import com.xx.dev.modules.duanwu.service.DuanWuService;
import com.xx.dev.modules.fund.service.FundService;
import com.xx.dev.modules.kfchampion.service.KFChampionService;
import com.xx.dev.modules.mail.service.MailService;
import com.xx.dev.modules.moneyplan.service.MoneyPlanService;
import com.xx.dev.modules.multifuben.service.MultiFubenService;
import com.xx.dev.modules.player.entity.Player;
import com.xx.dev.modules.relation.service.RelationService;
import com.xx.dev.modules.reward.service.RewardService;
import com.xx.dev.modules.royaltask.service.RoyalTaskService;
import com.xx.dev.modules.server.SessionManager;
import com.xx.dev.modules.vip.service.VipService;
import com.xx.dev.modules.vipfb.service.VipFbService;
import com.xx.dev.modules.worldcup.service.WorldCupService;
import com.xx.dev.platform.sanliuling.RedVipHelper;
import com.xx.dev.utils.FCMHelper;

@Component
public class LoginEventReceiver extends AbstractReceiver<LoginEvent> {

	/**
	 * session管理接口
	 */
	@Autowired
	private SessionManager sessionManager;
	
	/**
	 * 邮件服务接口
	 */
	@Autowired
	private MailService mailService;
	@Autowired
	private FCMHelper fcmHelper;
	@Autowired
	private DbCachedService dbCachedService;
	@Autowired
	private VipService vipService;
	@Autowired
	private ActivityService activityService;
	@Autowired
	private FundService fundService;
	@Autowired
	private RelationService relationService;
	@Autowired
	private RedVipHelper redVipHelper;
	@Autowired
	private VipFbService vipFbService;
	@Autowired
	private PrivilegeGiftService privilegeGiftService;
	@Autowired
	private XunleiMemberService xunleiMemberService;
	@Autowired
	private YYMemberService yyMemberService;
	@Autowired
	private MoneyPlanService moneyPlanService;
	@Autowired
	private MultiFubenService multiFubenService;
	/**
	 * 奖励服务接口
	 */
	@Autowired
	private RewardService rewardService;
	
	@Autowired
	private KFChampionService kFChampionService;
	@Autowired
	private RoyalTaskService royalTaskService;
    @Autowired
    private DuanWuService duanWuService;
    @Autowired
    private WorldCupService worldCupService;
    @Autowired
    private ArmyGroupTrainService armyGroupTrainService;
	/**
	 * 日志接口
	 */
	@Autowired
	private LogHelper logHelper;
	
	@Override
	public String[] getEventNames() {
		return new String[] {LoginEvent.NAME};
	}

	@Override
	public void doEvent(LoginEvent event) {
		if (event == null) {
			log.error("'{}' 事件消息体为 NULL", LoginEvent.NAME);
			return;
		}
		
		long playerId = event.getPlayerId();
		
		//活动任务跨天处理
		activityService.doIfAcrossDay(playerId);
		
		Date loginTime = event.getLoginTime();
		IoSession session = event.getCurrSession();
		if (session != null) {
			session.setAttribute(SessionKeys.LOGIN_TIME, loginTime);
			
			// 保存登陆日志
			String address = IpUtils.getRemoteIp(session);
			this.logHelper.logLogin(new Date(), playerId, address, event.getLoginWay().ordinal(), 
					session.getId());
			
			//收取新邮件
			this.mailService.receiveMail(playerId);
		}
		Player player = dbCachedService.get(playerId, Player.class);
		//防沉迷
		AdultStatus adultStatus = (AdultStatus)session.getAttribute(SessionKeys.ADULT_STATUS, AdultStatus.UNKOWN);
		if(adultStatus != AdultStatus.ADULT){//不是成年人才通知防沉迷
			fcmHelper.sendLogin(player.getUserName());
		}
		//VIP成长值
		if(!DateUtil.isToday(player.getVipIncomeDate())){
			vipService.loginGrowValue(playerId);
		}
		
		//推送可以购买基金|有新基金可以领
		this.fundService.hadNewFund(playerId);
		
		relationService.hasRelationFriend(playerId);
		
		//重置vip副本次数
		this.vipFbService.resetAttackCount(playerId);
		
		if (player.getLevel() > 5) {
			//红钻vip
			this.redVipHelper.asyncRefreshRedVip(playerId);
			//异步刷新特权图标
			this.privilegeGiftService.asyncRefreshPriviLevel(playerId);
			//迅雷会员
			xunleiMemberService.playerLogin(playerId);
			
			yyMemberService.playerLogin(playerId);
		}
		
		//多人副本
		this.multiFubenService.doPlayerLogin(playerId);
		
		//清除返还金币积分
		this.moneyPlanService.acrossDayClearScores(playerId);
		
		kFChampionService.playerLogin(playerId);
		
		//皇城缉盗
		this.royalTaskService.doPlayerLogin(playerId);

        // 端午活动
        duanWuService.onPlayerLogin(playerId);

        // 世界杯活动
        worldCupService.onPlayerLogin(playerId);
        
        //军团试炼活动
        armyGroupTrainService.playerLogin(playerId);
	}

}
