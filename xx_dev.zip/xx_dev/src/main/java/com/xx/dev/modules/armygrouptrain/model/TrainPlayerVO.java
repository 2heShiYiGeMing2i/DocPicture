package com.xx.dev.modules.armygrouptrain.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.xx.dev.constant.DateConstant;
import com.xx.dev.modules.reward.model.Reward;

/**
 * 試煉玩家的信息
 * @author jy
 *
 */
public class TrainPlayerVO {

	/**
	 * 進入試煉時的軍團id
	 */
	private long groupId;
	
	/**
	 * 上一次戰鬥時間，在戰鬥結束的時候設置，用於判斷
	 */
	private Date lastBattleTime = DateConstant.MIN_DATE;
	
	/**
	 * 狀態，是否死亡，1表示死亡，0表示沒有死亡
	 */
	private int status = 0;

	/**
	 * 路徑
	 */
	private String path;
	
	/**
	 * 當前位置
	 */
	private String curLoc;
	
	/**
	 * 整個活動期間獲得的獎勵
	 */
	private List<Reward> rewards = new ArrayList<Reward>();
	
	public long getGroupId() {
		return groupId;
	}

	public void setGroupId(long groupId) {
		this.groupId = groupId;
	}

	public Date getLastBattleTime() {
		return lastBattleTime;
	}

	public void setLastBattleTime(Date lastBattleTime) {
		this.lastBattleTime = lastBattleTime;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public static TrainPlayerVO valueOf(long groupId) {
		TrainPlayerVO vo = new TrainPlayerVO();
		vo.groupId = groupId;
		return vo;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getCurLoc() {
		return curLoc;
	}

	public void setCurLoc(String curLoc) {
		this.curLoc = curLoc;
	}

	public List<Reward> getRewards() {
		return rewards;
	}

	public void setRewards(List<Reward> rewards) {
		this.rewards = rewards;
	}

	public void addRewards(List<Reward> rewards) {
		this.rewards.addAll(rewards);
	}
	
}
