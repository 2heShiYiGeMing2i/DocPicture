package com.xx.dev.modules.arena.rule;

import java.util.ArrayList;
import java.util.List;

import com.xx.dev.modules.arena.model.ArenaSegment;


/**
 * 竞技场配置
 * 
 * @author bingshan
 */
public class ArenaRule {
	
	/**
	 * 竞技场排名列表ID
	 */
	public static final int ARENA_RANK_LIST_ID = 1;
	
	/**
	 * 竞技场第一名挑战胜利记录ID
	 */
	public static final int ARENA_FIRST_RANK_RECORD_ID = 2;
	
	/**
	 * 竞技场结算排名记录ID
	 */
	public static final int ARENA_BALANCE_TOP_PLAYER_RECORD_ID = 10;
	
	/**
	 * 竞技场挑战历史记录数
	 */
	public static final int ARENA_CHALLENGE_HIS_COUNT = 3;
	
	/**
	 * 最大上榜数量
	 */
	public static final int MAX_RANKING_COUNT = 5000;
	
	/**
	 * 最后可挑战排名随机种子
	 */
	public static final int LAST_RANKING_RANDOM_SEED = 100;
	
	/**
	 * 挑战列表人数(包含自己)
	 */
	public static final int CHALLENGE_LIST_COUNT = 10;
	
	/**
	 * 竞技场分段信息
	 */
	private static final List<ArenaSegment> ARENA_SEGMENTS = createArenaSegments();
	
	/**
	 * 创建竞技场分段信息
	 * @return List<ArenaSegment>
	 */
	private static List<ArenaSegment> createArenaSegments() {
		List<ArenaSegment> result = new ArrayList<ArenaSegment>();
		
		ArenaSegment seg1 = new ArenaSegment(1, 1, 100, 1);
		ArenaSegment seg2 = new ArenaSegment(2, 101, 500, 10);
		ArenaSegment seg3 = new ArenaSegment(3, 501, 2000, 50);
		ArenaSegment seg4 = new ArenaSegment(4, 2001, 5000, 100);
		
		result.add(seg1);
		result.add(seg2);
		result.add(seg3);
		result.add(seg4);
		
		return result;
	}
	
	/**
	 * 取得可挑战的排名列表
	 * @param playerRank 玩家排名
	 * @param currMaxRank 当前最大排名
	 * @return List<Integer>
	 */
	public static List<Integer> getRankListOfChallenge(int playerRank, int currMaxRank) {
		List<Integer> result = new ArrayList<Integer>(CHALLENGE_LIST_COUNT);
		if (currMaxRank <= 0) {
			return result;
		}
		
		//排名全十
		if (currMaxRank <= CHALLENGE_LIST_COUNT || playerRank > 0 && playerRank <= CHALLENGE_LIST_COUNT) {
			for (int rank = CHALLENGE_LIST_COUNT; rank > 0; rank --) {
				result.add(rank);
			}
			return result;
		}
		
		int nextRank = 0;
		//上榜
		boolean isInRank = playerRank > 0 && playerRank <= currMaxRank;
		if (isInRank) {
			nextRank = playerRank;
			result.add(playerRank);
		} else {
			nextRank = currMaxRank;
		}
		//剩余个数
		int leftCount = CHALLENGE_LIST_COUNT - 1;
		
		for (int i = ARENA_SEGMENTS.size() - 1; i >= 0; i --) {
			ArenaSegment seg = ARENA_SEGMENTS.get(i);
			while (leftCount > 0 && nextRank >= seg.getMinRank() && nextRank <= seg.getMaxRank()) {
				if (nextRank != playerRank) {
					result.add(nextRank);
					leftCount -= 1;					
				}				
				nextRank -= seg.getStep();
				if (nextRank < seg.getMinRank()) {
					nextRank = seg.getMinRank() - 1;
					break;
				}
			}
			
			if (leftCount <= 0) {
				break;
			}
		}
		
		return result;
	}
	
	
	
}
