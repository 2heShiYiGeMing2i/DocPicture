/**
 * @file:FlushCheerDto.java
 * @author:David
 **/
package com.xx.dev.modules.armageddon.model;

import java.util.List;

import com.xx.dev.modules.reward.result.ValueResultSet;

/**
 * @class:FlushCheerDto
 * @description:
 * @author:David
 * @version:v1.0
 * @date:2013-5-21
 **/
public class FlushCheerDto {
	private ValueResultSet valueResultSet;
	private List<PlayerCheerDto> playerCheerDtos;
	private double discountValue;
	
	public ValueResultSet getValueResultSet() {
		return valueResultSet;
	}
	public void setValueResultSet(ValueResultSet valueResultSet) {
		this.valueResultSet = valueResultSet;
	}
	public List<PlayerCheerDto> getPlayerCheerDtos() {
		return playerCheerDtos;
	}
	public void setPlayerCheerDtos(List<PlayerCheerDto> playerCheerDtos) {
		this.playerCheerDtos = playerCheerDtos;
	}
	public double getDiscountValue() {
		return discountValue;
	}
	public void setDiscountValue(double discountValue) {
		this.discountValue = discountValue;
	}
	
}

