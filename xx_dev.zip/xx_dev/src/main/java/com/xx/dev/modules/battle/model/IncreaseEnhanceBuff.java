/**
 * @file:IncreaseEnhanceBuff.java
 * @author:David
 **/
package com.xx.dev.modules.battle.model;
/**
 * @class:IncreaseEnhanceBuff
 * @description:回复加强 或 被回复加强
 * @author:David
 * @version:v1.0
 * @date:2013-4-29
 **/
public class IncreaseEnhanceBuff extends AbstractBuff {

	public IncreaseEnhanceBuff(int effectBaseValueType, double effectBase,
			int effectValueType, double effect, int startRound, int persistRound) {
		super(effectBaseValueType, effectBase, effectValueType, effect, startRound,
				persistRound);
	}

}

