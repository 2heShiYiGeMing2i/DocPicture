/**
 * @file:CreateRoomDto.java
 * @author:David
 **/
package com.xx.dev.modules.armageddon.model;
/**
 * @class:CreateRoomDto
 * @description:
 * @author:David
 * @version:v1.0
 * @date:2013-5-21
 **/
public class CreateRoomDto {
	private long roomNo;

	public long getRoomNo() {
		return roomNo;
	}

	public void setRoomNo(long roomNo) {
		this.roomNo = roomNo;
	}
	
}

