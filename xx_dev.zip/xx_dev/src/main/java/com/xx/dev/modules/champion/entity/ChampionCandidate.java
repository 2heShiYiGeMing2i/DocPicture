package com.xx.dev.modules.champion.entity;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.apache.commons.lang.StringUtils;
import org.apache.mina.util.ConcurrentHashSet;
import org.codehaus.jackson.type.TypeReference;

import com.xx.common.db.cache.DbLoadInitializer;
import com.xx.common.db.model.BaseModel;
import com.xx.common.util.JsonUtils;


/**
 * 群雄争霸种子选手信息
 * 
 * @author bingshan
 */
@Entity
@Table(name = "championCandidate")
public class ChampionCandidate extends BaseModel<Long> implements DbLoadInitializer {
	private static final long serialVersionUID = 7433284028377698578L;

	/**
	 * 角色ID, 0-其他
	 */
	@Id
	@Column(columnDefinition = "bigint(20) not null comment '角色id'")
	private Long playerId;
	
	/**
	 * 排名
	 */
	@Column(columnDefinition = "int(11) default '0' comment '排名'")
	private Integer rank = 0;
	
	/**
	 * 支持者(json)
	 */
	@Lob
	@Column(columnDefinition = "longtext comment '支持者(json)'")
	private String supports = "";
	
	/**
	 * supports转化过来
	 */
	@Transient
	private final Set<Long> supportIds = new ConcurrentHashSet<Long>();
	
	public static ChampionCandidate valueOf(long playerId, int rank) {
		ChampionCandidate c = new ChampionCandidate();
		c.playerId = playerId;
		c.rank = rank;
		return c;
	}

	@Override
	public void doAfterLoad() {
		if (StringUtils.isBlank(this.supports)) {
			return;
		}
		
		TypeReference<Set<Long>> valueTypeRef = new TypeReference<Set<Long>>() {};
		Set<Long> ids = JsonUtils.jsonString2Object(this.supports, valueTypeRef);
		if (ids != null && !ids.isEmpty()) {
			this.supportIds.addAll(ids);
		}
	}

	@Override
	public Long getId() {
		return this.playerId;
	}

	@Override
	public void setId(Long id) {
		this.playerId = id;
	}

	public Long getPlayerId() {
		return playerId;
	}

	public void setPlayerId(Long playerId) {
		this.playerId = playerId;
	}

	public Integer getRank() {
		return rank;
	}

	public void setRank(Integer rank) {
		this.rank = rank;
	}

	public String getSupports() {
		return supports;
	}

	public void setSupports(String supports) {
		this.supports = supports;
	}

	public Set<Long> getSupportIds() {
		return supportIds;
	}
}
