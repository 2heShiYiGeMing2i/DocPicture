package com.xx.dev.modules.building.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xx.common.basedb.BasedbService;
import com.xx.common.db.cache.DbCachedService;
import com.xx.common.event.EventBus;
import com.xx.common.util.Splitable;
import com.xx.common.utility.lock.ChainLock;
import com.xx.common.utility.lock.LockUtils;
import com.xx.dev.constant.IndexName;
import com.xx.dev.constant.LogSource;
import com.xx.dev.model.Result;
import com.xx.dev.modules.building.entity.PlayerBuilding;
import com.xx.dev.modules.building.event.BuildingUpgradeEvent;
import com.xx.dev.modules.building.handler.BuildingResult;
import com.xx.dev.modules.building.model.BuildingId;
import com.xx.dev.modules.building.model.BuildingType;
import com.xx.dev.modules.building.model.PlayerBuildingDto;
import com.xx.dev.modules.building.model.basedb.CityElement;
import com.xx.dev.modules.building.model.basedb.ElementQualityUpgrade;
import com.xx.dev.modules.building.model.basedb.ElementUpgrade;
import com.xx.dev.modules.building.service.BuildingBasedbService;
import com.xx.dev.modules.building.service.BuildingService;
import com.xx.dev.modules.coolqueue.model.CoolQueueDto;
import com.xx.dev.modules.coolqueue.model.CoolQueueType;
import com.xx.dev.modules.coolqueue.service.CoolQueueService;
import com.xx.dev.modules.player.entity.Player;
import com.xx.dev.modules.revenue.service.RevenueService;
import com.xx.dev.modules.reward.action.RewardActionSet;
import com.xx.dev.modules.reward.result.ValueResultSet;
import com.xx.dev.modules.reward.service.RewardService;
import com.xx.dev.modules.server.SessionManager;
import com.xx.dev.modules.task.event.BuildingEvent;
import com.xx.dev.modules.task.event.FoodsOutputEvent;
import com.xx.dev.modules.task.event.SilverOutputEvent;
import com.xx.dev.modules.task.service.TaskBus;

/**
 * 主城建筑服务接口实现类
 * 
 * @author Along
 *
 */
@Service
public class BuildingServiceImpl implements BuildingService {

	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	/**
	 * Session管理器
	 */
	@Autowired
	private SessionManager sessionManager;
	
	/**
	 * 缓存服务接口
	 */
	@Autowired
	private DbCachedService dbCachedService;
	
	/**
	 * 基础数据服务接口
	 */
	@Autowired
	private BasedbService basedbService;
	
	/**
	 * 奖励服务接口
	 */
	@Autowired
	private RewardService rewardService;
	
	/**
	 * 冷却队列
	 */
	@Autowired
	private CoolQueueService coolQueueService;
	
	/**
	 * 税收服务接口
	 */
	@Autowired
	private RevenueService revenueService;
	
	/**
	 * 主城建筑基础数据表服务接口
	 */
	@Autowired
	private BuildingBasedbService buildingBasedbService;
	
	/**
	 * 事件总线
	 */
	@Autowired
	private EventBus eventBus;
	
	@Autowired
	private TaskBus taskBus;
	
	@Override
	public int enterCityAction(long playerId) {
		int result = BuildingResult.SUCCESS;
//		Player player = this.dbCachedService.get(playerId, Player.class);
//		if (player != null && player.getLevel() < 30) {
//			this.taskBus.post(EnterCityEvent.valueOf(playerId));
//		}
		return result;
	}
	
	@Override
	public List<PlayerBuildingDto> getBuildingsAction(long playerId) {
		List<PlayerBuildingDto> result = null;
		Player player = this.dbCachedService.get(playerId, Player.class);
		if (player != null) {
			 List<PlayerBuilding> playerBuildings = this.getBuildings(player);
			 if (CollectionUtils.isNotEmpty(playerBuildings)) {
				 result = new ArrayList<PlayerBuildingDto>();
				 for (PlayerBuilding playerBuilding: playerBuildings) {
					 PlayerBuildingDto playerBuildingDto = PlayerBuildingDto.valueOf(playerBuilding);
					 result.add(playerBuildingDto);
				 }
			 }
		}
		return result;
	}
	
	@Override
	public List<PlayerBuilding> getBuildings(long playerId) {
		List<PlayerBuilding> result = null;
		List<CityElement> buildings = this.buildingBasedbService.getCityElements();
		if (CollectionUtils.isNotEmpty(buildings)) {
			result = new ArrayList<PlayerBuilding>();
			for (int i = 0; i < buildings.size(); i++) {
				CityElement building = buildings.get(i);
				String key = PlayerBuilding.getKey(playerId, building.getId());
				PlayerBuilding playerBuilding = this.dbCachedService.get(key, PlayerBuilding.class);
				if (playerBuilding != null) {
					result.add(playerBuilding);
				}
			}
		}
		return result;
	}
	
	@Override
	public int getBuildingLevel(long playerId, int buildingId) {
		int result = -1;
		String key = PlayerBuilding.getKey(playerId, buildingId);
		PlayerBuilding playerBuilding = this.dbCachedService.get(key, 
				PlayerBuilding.class);
		if (playerBuilding != null) {
			result = playerBuilding.getLevel();
		}
		return result;
	}

	@Override
	public int getBuildingQuality(long playerId, int buildingId) {
		int result = -1;
		String key = PlayerBuilding.getKey(playerId, buildingId);
		PlayerBuilding playerBuilding = this.dbCachedService.get(key, 
				PlayerBuilding.class);
		if (playerBuilding != null) {
			result = playerBuilding.getQuality();
		}
		return result;
	}

	@Override
	public Result<PlayerBuildingDto> upgradeQualityAction(long playerId,
			int buildingId) {
		Player player = this.dbCachedService.get(playerId, Player.class);
		if (player == null) {
			return Result.Error(BuildingResult.FAILURE);
		}
		String key = PlayerBuilding.getKey(player.getId(), buildingId);
		PlayerBuilding playerBuilding = this.dbCachedService.get(key, PlayerBuilding.class);
		if (playerBuilding == null) {// 主城建筑不存在
			return Result.Error(BuildingResult.BUILDING_NOT_EXISTS);
		}
		ElementQualityUpgrade buildingQualityUpgrade = this.basedbService.getByUnique(
				ElementQualityUpgrade.class, IndexName.BUILDING_QUALITY_UPGRADE_INDEX, 
				buildingId, playerBuilding.getQuality() + 1);
		if (buildingQualityUpgrade == null) {// 基础数据不存在
			return Result.Error(BuildingResult.BASE_DATA_NOT_EXIST);
		}
		ValueResultSet valueResultSet = null;
		ChainLock chainLock = LockUtils.getLock(player);
		chainLock.lock();
		try {
			if (buildingQualityUpgrade.getBuildingLevel() > playerBuilding.getLevel()) {// 建筑的等级不够
				return Result.Error(BuildingResult.BUILDING_LEVEL_NO_ENOUGH);
			}
			if (player.getOldVipLevel() < buildingQualityUpgrade.getVipLevel()) {// 玩家VIP等级不够
				return Result.Error(BuildingResult.VIP_LEVEL_NO_ENOUGH);
			}
			// 判断是否够消耗
			RewardActionSet rewardActionSet = this.rewardService.tryRewards(playerId, 
					buildingQualityUpgrade.getCost());
			if (rewardActionSet.isNotOK()) {// 资源不足
				return Result.Error(rewardActionSet.getResultCode());
			}
			// 扣减升级消耗
			valueResultSet = this.rewardService.executeRewards(playerId, rewardActionSet, 
					LogSource.BUILDING_QUALITY_UPGRADE);
			playerBuilding.setQuality(playerBuilding.getQuality() + 1);
			this.dbCachedService.submitUpdated2Queue(key, PlayerBuilding.class);
		} finally {
			chainLock.unlock();
		}
		
		// 建筑任务事件
		this.taskBus.post(BuildingEvent.valueOf(playerId));
		// 粮食，银元产量事件
		this.postOutputEvent(playerId, buildingId);
		
		PlayerBuildingDto playerBuildingDto = PlayerBuildingDto.valueOf(playerBuilding);
		Result<PlayerBuildingDto> result = Result.Success(playerBuildingDto);
		result.addContent("valueResultSet", valueResultSet);
		return result;
	}

	@Override
	public Result<PlayerBuildingDto> upgradeLevelAction(long playerId, int buildingId) {
		Player player = this.dbCachedService.get(playerId, Player.class);
		if (player == null) {
			return Result.Error(BuildingResult.FAILURE);
		}
		CityElement cityElement = this.basedbService.get(CityElement.class, buildingId);
		if (cityElement == null) {// 主城建筑不存在
			return Result.Error(BuildingResult.BUILDING_NOT_EXISTS);
		}
		String key = PlayerBuilding.getKey(player.getId(), buildingId);
		PlayerBuilding playerBuilding = this.dbCachedService.get(key, PlayerBuilding.class);
		if (playerBuilding == null) {// 主城建筑不存在
			return Result.Error(BuildingResult.BUILDING_NOT_EXISTS);
		}
		ElementUpgrade buildingUpgrade = this.basedbService.getByUnique(
				ElementUpgrade.class, IndexName.BUILDING_LEVEL_UPGRADE_INDEX, 
				playerBuilding.getLevel(), cityElement.getType());
		if (buildingUpgrade == null) {// 基础数据不存在
			return Result.Error(BuildingResult.BASE_DATA_NOT_EXIST);
		}
		Result<PlayerBuildingDto> result;
		ValueResultSet valueResultSet;
		CoolQueueDto coolQueueDto = null;
		List<PlayerBuildingDto> newPlayerBuildingDtos;
		ChainLock chainLock = LockUtils.getLock(player);
		chainLock.lock();
		try {
			// 受其他建筑等级影响
			if (buildingId == BuildingId.OFFICE) {// 官府等级受主公等级影响
				if (player.getLevel() <= playerBuilding.getLevel()) {
					return Result.Error(BuildingResult.PLAYER_LEVEL_LIMIT);
				}
				if (!this.canUpgradeOfficeLevel(player, buildingUpgrade)) {// 产量不足
					return Result.Error(BuildingResult.OUTPUT_NO_ENOUGH);
				}
			} else {
				int officeLevel = this.getBuildingLevel(playerId, BuildingId.OFFICE);
				if (officeLevel <= playerBuilding.getLevel()) {// 其他建筑等级受官府等级限制
					return Result.Error(BuildingResult.OFFICE_LEVEL_LIMIT);
				}
				if (!this.canUpgradeNoOfficeLevel(player, buildingUpgrade)) {// 还没满足升级条件
					return Result.Error(BuildingResult.UPGRADE_LEVEL_LIMIT);
				}
			}
			// 判断是否够消耗
			RewardActionSet rewardActionSet = this.rewardService.tryRewards(playerId, buildingUpgrade.getCost());
			if (rewardActionSet.isNotOK()) {// 资源不足
				return Result.Error(rewardActionSet.getResultCode());
			}
			// 加入到冷却队列
			if (buildingUpgrade.getTime() > 0) {
				coolQueueDto = this.coolQueueService.addToCoolQueue(playerId, CoolQueueType.BUILDING, 
						buildingUpgrade.getTime());
				if (coolQueueDto == null) {// 冷却队列满
					return Result.Error(BuildingResult.QUEUE_IS_FULL);
				}
			}
			// 扣减升级消耗
			valueResultSet = this.rewardService.executeRewards(playerId, rewardActionSet, LogSource.BUILDING_LEVEL_UPGRADE);
			playerBuilding.setLevel(playerBuilding.getLevel() + 1);
			this.dbCachedService.submitUpdated2Queue(key, PlayerBuilding.class);
			// 刷新新建筑开放
			newPlayerBuildingDtos = this.getNewPlayerBuildingDtos(playerId, playerBuilding.getLevel());
			// 发送主城建筑升级事件
			this.eventBus.post(BuildingUpgradeEvent.valueOf(playerId, buildingId, playerBuilding.getLevel()));
		} finally {
			chainLock.unlock();
		}
		
		//建筑任务事件
		this.taskBus.post(BuildingEvent.valueOf(playerId));
		// 粮食，银元产量事件
		this.postOutputEvent(playerId, buildingId);
		
		PlayerBuildingDto playerBuildingDto = PlayerBuildingDto.valueOf(playerBuilding);
		result = Result.Success(playerBuildingDto);
		result.addContent("coolQueueDto", coolQueueDto);
		result.addContent("valueResultSet", valueResultSet);
		result.addContent("newPlayerBuildingDtos", newPlayerBuildingDtos);
		return result;
	}
	
	/**
	 * 粮食，银元产量事件
	 * @param playerId 玩家id
	 * @param buildingId 建筑id
	 */
	private void postOutputEvent(long playerId, int buildingId) {
		CityElement cityElement = this.basedbService.get(CityElement.class, buildingId);
		if (cityElement != null && (cityElement.getType() == BuildingType.FARM || 
				cityElement.getType() == BuildingType.WATERWHEEL)) {// 农田跟水车
			this.taskBus.post(FoodsOutputEvent.valueOf(playerId));
		}
		if (cityElement != null && (cityElement.getType() == BuildingType.HOUSE || 
				cityElement.getType() == BuildingType.MARKET)) {// 民居跟市场
			this.taskBus.post(SilverOutputEvent.valueOf(playerId));
		}
	}
	
	/**
	 * 能否升级（官府）
	 * @param player 玩家
	 * @param buildingUpgrade 建筑升级对象
	 * @return
	 */
	private boolean canUpgradeOfficeLevel(Player player, ElementUpgrade buildingUpgrade) {
		if (StringUtils.isEmpty(buildingUpgrade.getHarvestCondition())) {
			return true;
		}
		String[] conditionList = buildingUpgrade.getHarvestCondition().split(Splitable.ELEMENT_SPLIT);
		if (ArrayUtils.isEmpty(conditionList)) {
			return true;
		}
		for (String condition: conditionList) {
			String[] conditionItems = condition.split(Splitable.ATTRIBUTE_SPLIT);
			if (conditionItems != null && conditionItems.length == 2) {
				int type = Integer.parseInt(conditionItems[0]);
				int value = Integer.parseInt(conditionItems[1]);
				if ((type == 1 && this.revenueService.getSilverTotalOutput(player.getId()) < value) || 
						(type == 2 && this.revenueService.getFoodsTotalOutput(player.getId()) < value)) {// 不满足升级条件
					return false;
				}
			} else {// 升级条件格式错误
				logger.error("官府升级条件格式错误：{}", buildingUpgrade.getHarvestCondition());
			}
		}
		return true;
	}
	
	/**
	 * 能否升级（非官府）
	 * @param player 玩家
	 * @param buildingUpgrade 建筑升级对象
	 * @return
	 */
	private boolean canUpgradeNoOfficeLevel(Player player, ElementUpgrade buildingUpgrade) {
		if (StringUtils.isEmpty(buildingUpgrade.getUpgradeCondition())) {
			return true;
		}
		String[] conditionList = buildingUpgrade.getUpgradeCondition().split(Splitable.ELEMENT_SPLIT);
		if (ArrayUtils.isEmpty(conditionList)) {
			return true;
		}
		boolean result = false;
		List<PlayerBuilding> playerBuildings = this.getBuildings(player);
		if (CollectionUtils.isNotEmpty(playerBuildings)) {
			for (String condition: conditionList) {
				String[] conditionItems = condition.split(Splitable.ATTRIBUTE_SPLIT);
				if (conditionItems != null && conditionItems.length == 3) {
					int type = Integer.parseInt(conditionItems[0]);
					int amount = Integer.parseInt(conditionItems[1]);
					int level = Integer.parseInt(conditionItems[2]);
					if (!this.canUpgradeNoOfficeLevel(playerBuildings, type, level, amount)) {// 不满足升级条件
						return result;
					}
				} else {// 升级条件格式错误
					logger.error("非官府升级条件格式错误：{}", buildingUpgrade.getUpgradeCondition());
				}
			}
			result = true;
		}
		return result;
	}
	
	/**
	 * 能否升级（非官府）
	 * @param playerBuildings 玩家建筑列表
	 * @param type 建筑类型
	 * @param level 建筑等级
	 * @param amount 建筑数量
	 * @return
	 */
	private boolean canUpgradeNoOfficeLevel(List<PlayerBuilding> playerBuildings, int type, int level, int amount) {
		boolean result = false;
		int count = 0;
		for (PlayerBuilding playerBuilding: playerBuildings) {
			CityElement cityElement = this.basedbService.get(CityElement.class, playerBuilding.getBuildingId());
			if (cityElement != null && cityElement.getType() == type) {
				if (playerBuilding.getLevel() >= level) {
					count++;
				}
				if (count >= amount) {
					result = true;
					break;
				}
			}
		}
		return result;
	}
	
	@Override
	public void initPlayerBuildingLevel(long playerId) {
		this.getBuildingsAction(playerId);
		// 官府
		PlayerBuilding office = this.getPlayerBuilding(playerId, BuildingId.OFFICE);
		if (office != null) {
			office.setLevel(9);
			this.dbCachedService.submitUpdated2Queue(office.getId(), PlayerBuilding.class);
		}
		// 兵营
		PlayerBuilding barracks = this.getPlayerBuilding(playerId, BuildingId.BARRACKS);
		if (barracks != null) {
			barracks.setLevel(10);
			this.dbCachedService.submitUpdated2Queue(barracks.getId(), PlayerBuilding.class);
		}
		// 民居1
		PlayerBuilding house1 = this.getPlayerBuilding(playerId, 2);
		if (house1 != null) {
			house1.setLevel(1);
			this.dbCachedService.submitUpdated2Queue(house1.getId(), PlayerBuilding.class);
		}
		// 民居2
		PlayerBuilding house2 = this.getPlayerBuilding(playerId, 3);
		if (house2 != null) {
			house2.setLevel(1);
			this.dbCachedService.submitUpdated2Queue(house2.getId(), PlayerBuilding.class);
		}
		// 水田1
		PlayerBuilding farm1 = this.getPlayerBuilding(playerId, 9);
		if (farm1 != null) {
			farm1.setLevel(1);
			this.dbCachedService.submitUpdated2Queue(farm1.getId(), PlayerBuilding.class);
		}
		// 水田2
		PlayerBuilding farm2 = this.getPlayerBuilding(playerId, 10);
		if (farm2 != null) {
			farm2.setLevel(10);
			this.dbCachedService.submitUpdated2Queue(farm2.getId(), PlayerBuilding.class);
		}
	}
	
	/**
	 * 获取玩家建筑列表
	 * @param player 玩家
	 * @return
	 */
	private List<PlayerBuilding> getBuildings(Player player) {
		List<PlayerBuilding> result = null;
		List<CityElement> buildings = this.buildingBasedbService.getCityElements();
		if (CollectionUtils.isNotEmpty(buildings)) {
			result = new ArrayList<PlayerBuilding>();
			for (int i = 0; i < buildings.size(); i++) {
				CityElement building = buildings.get(i);
				if ((building.getType() == BuildingType.OFFICE && building.getOpenLevel() <= player.getLevel()) ||
						(building.getType() != BuildingType.OFFICE && building.getOpenLevel() <= this.getOfficeLevel(player.getId()))) {
					PlayerBuilding playerBuilding = this.addPlayerBuilding(player.getId(), building);
					result.add(playerBuilding);
				}
			}
		}
		return result;
	}
	
	/**
	 * 返回官府等级
	 * @param playerId 玩家id
	 * @return
	 */
	private int getOfficeLevel(long playerId) {
		return this.getBuildingLevel(playerId, BuildingId.OFFICE);
	}
	
	/**
	 * 返回玩家主城建筑
	 * @param playerId 玩家id
	 * @param buildingId 建筑id
	 * @return
	 */
	private PlayerBuilding getPlayerBuilding(long playerId, int buildingId) {
		String key = PlayerBuilding.getKey(playerId, buildingId);
		return this.dbCachedService.get(key, PlayerBuilding.class);
	}
	
	/**
	 * 添加主城建筑
	 * @param player 玩家
	 * @param buildingId 建筑id
	 * @return
	 */
	private PlayerBuilding addPlayerBuilding(long playerId, CityElement building) {
		String key = PlayerBuilding.getKey(playerId, building.getId());
		PlayerBuilding result = this.dbCachedService.get(key, PlayerBuilding.class);
		if (result == null) {
			result = this.dbCachedService.submitNew2Queue(new PlayerBuilding(playerId, building.getId()));
			if (building.getType() == BuildingType.HOUSE) {
				// 粮食，银元产量事件
				this.postOutputEvent(playerId, building.getId());
			}
			if (building.getType() == BuildingType.FARM) {
				// 粮食，银元产量事件
				this.postOutputEvent(playerId, building.getId());
			}
			if (building.getType() == BuildingType.MARKET || building.getType() == BuildingType.WATERWHEEL) {
				// 粮食，银元产量事件
				this.postOutputEvent(playerId, building.getId());
			}
		}
		return result;
	}
	
	@Override
	public List<Integer> getBuildingIds(long playerId, int buildingType) {
		List<Integer> result = null;
		Player player = this.dbCachedService.get(playerId, Player.class);
		if (player != null) {
			 List<PlayerBuilding> playerBuildings = this.getBuildings(player);
			 if (CollectionUtils.isNotEmpty(playerBuildings)) {
				 result = new ArrayList<Integer>();
				 for (PlayerBuilding playerBuilding: playerBuildings) {
					 CityElement cityElement = this.basedbService.get(CityElement.class, 
							 playerBuilding.getBuildingId());
					 if (cityElement != null && cityElement.getType() == buildingType) {
						 result.add(playerBuilding.getBuildingId());
					 }
				 }
			 }
		}
		return result;
	}
	
	/**
	 * 获取新开放的建筑列表
	 * @param playerId 玩家id
	 * @param officeLevel 官府等级
	 * @return
	 */
	private List<PlayerBuildingDto> getNewPlayerBuildingDtos(long playerId, int officeLevel) {
		List<PlayerBuildingDto> result = null;
		List<CityElement> buildings = this.basedbService.listAll(CityElement.class);
		if (CollectionUtils.isNotEmpty(buildings)) {
			result = new ArrayList<PlayerBuildingDto>();
			for (CityElement building: buildings) {
				if (building.getType() != BuildingType.OFFICE && building.getOpenLevel() <= officeLevel) {
					PlayerBuilding playerBuilding = this.getPlayerBuilding(playerId, building.getId());
					if (playerBuilding == null) {
						playerBuilding = this.addPlayerBuilding(playerId, building);
						PlayerBuildingDto playerBuildingDto = PlayerBuildingDto.valueOf(playerBuilding);
						result.add(playerBuildingDto);
					}
				}
			}
		}
		return result;
	}
	
}
