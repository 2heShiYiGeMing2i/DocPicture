/**
 * @file:BuyTimeDto.java
 * @author:David
 **/
package com.xx.dev.modules.armageddon.model;

import com.xx.dev.modules.reward.result.ValueResultSet;

/**
 * @class:BuyTimeDto
 * @description:
 * @author:David
 * @version:v1.0
 * @date:2013-5-25
 **/
public class BuyTimeDto {
	private ValueResultSet valueResultSet;
	private ArmageddonInfoDto armageddonInfoDto;
	/**
	 * 实际优惠的金额
	 */
	private double discountValue;
	
	
	public ValueResultSet getValueResultSet() {
		return valueResultSet;
	}

	public void setValueResultSet(ValueResultSet valueResultSet) {
		this.valueResultSet = valueResultSet;
	}

	public ArmageddonInfoDto getArmageddonInfoDto() {
		return armageddonInfoDto;
	}

	public void setArmageddonInfoDto(ArmageddonInfoDto armageddonInfoDto) {
		this.armageddonInfoDto = armageddonInfoDto;
	}

	public double getDiscountValue() {
		return discountValue;
	}

	public void setDiscountValue(double discountValue) {
		this.discountValue = discountValue;
	}
	
}

