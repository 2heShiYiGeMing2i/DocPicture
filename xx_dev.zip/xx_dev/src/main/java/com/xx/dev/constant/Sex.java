package com.xx.dev.constant;

/**
 * 性别定义
 * 
 * @author along
 * 
 */
public enum Sex {

	/**
	 * 0-未知
	 */
	UNKNOWN,

	/**
	 * 1-男
	 */
	MALE,

	/**
	 * 2-女
	 */
	FEMALE;
}