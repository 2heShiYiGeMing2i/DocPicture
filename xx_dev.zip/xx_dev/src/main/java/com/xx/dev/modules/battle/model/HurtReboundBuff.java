/**
 * @file:HurtReboundBuff.java
 * @author:David
 **/
package com.xx.dev.modules.battle.model;

import com.xx.dev.modules.skill.model.basedb.SkillEffect;

/**
 * @class:HurtReboundBuff
 * @description:伤害反弹
 * @author:David
 * @version:v1.0
 * @date:2013-4-27
 **/
public class HurtReboundBuff extends AbstractBuff {
	private SkillEffect skillEffect;
	public HurtReboundBuff(SkillEffect skillEffect,
			double effectBase, double effect, int startRound,
			int persistRound) {
		super(0, effectBase, 0, effect, startRound, persistRound);
		this.skillEffect = skillEffect;
	}
	public SkillEffect getSkillEffect() {
		return skillEffect;
	}
	public void setSkillEffect(SkillEffect skillEffect) {
		this.skillEffect = skillEffect;
	}
	public void reflush(SkillEffect skillEffect,
			double effectBase, double effect, int startRound,
			int persistRound) {
		super.reflush(0, effectBase, 0, effect, startRound, persistRound);
		this.skillEffect = skillEffect;
	}
}

