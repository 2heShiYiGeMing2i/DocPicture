package com.xx.dev.modules.barracks.model;

/**
 * 兵种类型id
 * 
 * @author Along
 *
 */
public interface ArmTypeId {

	/**
	 * 步兵
	 */
	int WALKER = 1;
	
	/**
	 * 骑兵
	 */
	int RIDER = 2;
	
	/**
	 * 弓兵
	 */
	int ARCHER = 3;
	
	/**
	 * 谋士
	 */
	int MAGICIAN = 4;
	
	/**
	 * 辎重
	 */
	int SUPPLY = 5;
	
}
