package com.xx.dev.event;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.xx.common.event.AbstractReceiver;
import com.xx.dev.modules.magic.service.TotemRankService;
/**
 * 图腾属性改变事件接收者
 * @author jy
 *
 */
@Component
public class TotemStateChangeReceiver extends AbstractReceiver<TotemStateChangeEvent> {
	
	@Autowired
	private TotemRankService totemRankService;
	
	@Override
	public String[] getEventNames() {
		return new String[] {TotemStateChangeEvent.NAME};
	}

	@Override
	public void doEvent(TotemStateChangeEvent event) {
		if(event != null){
			totemRankService.doTotemGradeEvent(event.getPlayerId(), event.getGrade(), event.getLuckValue());
		}
	}

}
