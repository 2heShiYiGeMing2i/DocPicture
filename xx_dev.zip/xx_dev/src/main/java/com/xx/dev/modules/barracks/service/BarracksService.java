package com.xx.dev.modules.barracks.service;

import com.xx.dev.model.Result;
import com.xx.dev.modules.barracks.entity.PlayerSoldier;
import com.xx.dev.modules.barracks.model.PlayerSoldierDto;
import com.xx.dev.modules.reward.result.ValueResultSet;

/**
 * 兵营服务接口
 * 
 * @author Along
 *
 */
public interface BarracksService {

	/**
	 * 进入兵营
	 * @param playerId 玩家id
	 * @return
	 */
	public Result<PlayerSoldierDto> enterAction(long playerId);
	
	/**
	 * 招募士兵
	 * @param playerId 玩家id
	 * @param amount 士兵数量
	 * @return
	 */
	public Result<PlayerSoldierDto> recruitSoldiersAction(long playerId, int amount);
	
	/**
	 * 遣散士兵
	 * @param playerId 玩家id
	 * @param amount 士兵数量
	 * @return
	 */
	public Result<PlayerSoldierDto> disbandSoldiersAction(long playerId, int amount);
	
	/**
	 * 升级兵阶
	 * @param playerId 玩家id
	 * @return
	 */
	public Result<ValueResultSet> upgradeSoldierStarAction(long playerId);
	
	//---------------------------------------------------------------------------------
	/**
	 * 士兵下阵（重新回到空闲状态）外面要加锁
	 * @param playerId 玩家id
	 * @param amount 士兵数量
	 * @return
	 */
	public int soldiersDisengage(long playerId, int amount);
	
	/**
	 * 士兵上阵（加入到武将方阵）外面要加锁
	 * @param playerId 玩家id
	 * @param amount 士兵数量
	 * @param isFull 是否必须补满
	 * @return
	 */
	public int soldiersJoinBattle(long playerId, int amount, boolean isFull);
	
	/**
	 * 返回玩家的兵
	 * @param playerId 玩家id
	 * @return
	 */
	public PlayerSoldier getPlayerSoldier(long playerId);

	/**
	 * 返回玩家兵营士兵上限
	 * @param playerId 玩家id
	 * @return
	 */
	public int getPlayerSoldierAmountLimit(long playerId);

	/**
	 * 初始化士兵数量
	 * @param playerId 玩家id
	 */
	public void initPlayerSoldierAmount(long playerId);

}
