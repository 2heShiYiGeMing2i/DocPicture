package com.xx.dev;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.xx.common.runtime.Lifecycle;
import com.xx.common.runtime.LifecycleManager;
import com.xx.dev.modules.server.SanguohunServer;

/**
 * 主程序
 *
 */
public class App 
{
	
	private static final Logger logger = LoggerFactory.getLogger(App.class);
	
    public static void main( String[] args )
    {
		ClassPathXmlApplicationContext applicationContext = new ClassPathXmlApplicationContext(new String[] { "applicationContext*.xml"});
		
		LifecycleManager.transferLifecycle(Lifecycle.CONFIGURATION);//通知加载配置文件信息
		
		LifecycleManager.transferLifecycle(Lifecycle.BASE_DB_LOAD);//通知进入基础数据加载阶段
		
		LifecycleManager.transferLifecycle(Lifecycle.CONTEXT_CONSTRUCT);//通知构建容器
		
		LifecycleManager.transferLifecycle(Lifecycle.CONTEXT_INITIALIZE);//通知容器初始化
		
		LifecycleManager.transferLifecycle(Lifecycle.VERSION_CUSTOM);//通知版本定制
		
		LifecycleManager.transferLifecycle(Lifecycle.PATCH_INSTALL);//通知补丁加载
		
		LifecycleManager.transferLifecycle(Lifecycle.OPEN_CONTROL_INITIALIZE);//开关初始化
		
		LifecycleManager.transferLifecycle(Lifecycle.BUSSINESS_INITIALIZE);//通知业务开始处理起服业务
		
		LifecycleManager.transferLifecycle(Lifecycle.BUSSINESS_INITIALIZE_2);//业务起服处理阶段2
		
		
//		LifecycleManager.transferLifecycle(Lifecycle.START_SOCKET_SERVER);//启动socket服务器
		
		SanguohunServer server = (SanguohunServer) applicationContext.getBean(SanguohunServer.class);
		server.start();
		
		while(server.isRunning()){
			try {
				Thread.sleep(10000);
			} catch (InterruptedException e) {
				logger.error("服务器主线程被打断...", e);
			}
		}
		
		applicationContext.close();
		
		logger.error("服务器主线程退出...");
		
		System.exit(0);
	}
}
