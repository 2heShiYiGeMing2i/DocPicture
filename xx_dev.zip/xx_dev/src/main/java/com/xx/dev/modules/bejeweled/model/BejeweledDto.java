package com.xx.dev.modules.bejeweled.model;

import com.xx.dev.modules.bejeweled.entity.PlayerBejeweled;
import com.xx.dev.modules.bejeweled.model.basedb.BejeweledCfg;

/**
 * Created by LiangZengle on 2014/6/23.
 */
public class BejeweledDto {
    /**
     * 剩余步数
     */
    private int leftMoves;

    /**
     * 分数
     */
    private int score;

    /**
     * 宝箱等级
     */
    private int boxLevel;

    /**
     * 剩余增加步数的次数
     */
    private int leftAddMoveTimes;

    /**
     * 当前目标
     */
    private Goal curGoal;

    /**
     * 下一目标
     */
    private Goal nextGoal;

    /**
     * 宝石迷阵信息: "[[4,2,4,6,4,3],[5,4,2,2,2,1],[1,2,1,6,5,2],[3,6,3,2,3,3],[4,1,2,5,4,4],[1,6,4,3,2,6]]"
     */
    private String bejeweled;

    public static BejeweledDto valueOf(PlayerBejeweled playerBejeweled, BejeweledCfg bejeweledCfg, String bejeweled) {
        BejeweledDto dto = new BejeweledDto();
        dto.leftMoves = Math.max(0, bejeweledCfg.getMaxMoves() - playerBejeweled.getTakenMoves());
        dto.score = playerBejeweled.getScore();
        dto.boxLevel = playerBejeweled.getBoxLevel();
        dto.leftAddMoveTimes = Math.max(0, bejeweledCfg.getAddMoveTimes() - playerBejeweled.getAddMoveTimes());
        dto.curGoal = playerBejeweled.getCurGoal();
        dto.nextGoal = playerBejeweled.getNextGoal();
        dto.bejeweled = bejeweled;
        return dto;
    }

    public int getLeftMoves() {
        return leftMoves;
    }

    public void setLeftMoves(int leftMoves) {
        this.leftMoves = leftMoves;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public int getBoxLevel() {
        return boxLevel;
    }

    public void setBoxLevel(int boxLevel) {
        this.boxLevel = boxLevel;
    }

    public int getLeftAddMoveTimes() {
        return leftAddMoveTimes;
    }

    public void setLeftAddMoveTimes(int leftAddMoveTimes) {
        this.leftAddMoveTimes = leftAddMoveTimes;
    }

    public Goal getCurGoal() {
        return curGoal;
    }

    public void setCurGoal(Goal curGoal) {
        this.curGoal = curGoal;
    }

    public Goal getNextGoal() {
        return nextGoal;
    }

    public void setNextGoal(Goal nextGoal) {
        this.nextGoal = nextGoal;
    }

    public String getBejeweled() {
        return bejeweled;
    }

    public void setBejeweled(String bejeweled) {
        this.bejeweled = bejeweled;
    }
}
