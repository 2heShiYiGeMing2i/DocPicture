package com.xx.dev.modules.barracks.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.xx.common.db.model.BaseModel;

/**
 * 玩家的兵
 * 
 * @author Along
 *
 */
@Entity
@Table(name = "playerSoldier")
public class PlayerSoldier extends BaseModel<Long> {

	private static final long serialVersionUID = 3593027413883745623L;
	
	/**
	 * 玩家id
	 */
	@Id
	@Column(columnDefinition = "bigint(20) not null comment '玩家id'")
	private Long id;
	
	/**
	 * 兵阶
	 */
	@Column(columnDefinition = "int(11) not null comment '兵阶'")
	private int star;
	
	/**
	 * 空闲兵的数量
	 */
	@Column(columnDefinition = "int(11) default '0' comment '空闲兵的数量'")
	private int amount;
	
	public static PlayerSoldier valueOf(long playerId) {
		PlayerSoldier result = new PlayerSoldier();
		result.setId(playerId);
		result.setStar(1);
		result.setAmount(0);
		return result;
	}
	
	@Override
	public Long getId() {
		return this.id;
	}

	@Override
	public void setId(Long id) {
		this.id = id;
	}

	public int getStar() {
		return star;
	}

	public void setStar(int star) {
		this.star = star;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

}
