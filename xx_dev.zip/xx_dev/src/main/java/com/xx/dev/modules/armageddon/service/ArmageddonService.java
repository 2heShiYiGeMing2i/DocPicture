/**
 * @file:ArmageddonService.java
 * @author:David
 **/
package com.xx.dev.modules.armageddon.service;


import com.xx.dev.model.Result;
import com.xx.dev.modules.armageddon.entity.PlayerArmageddonInfo;
import com.xx.dev.modules.armageddon.model.ArmageddonInfoDto;
import com.xx.dev.modules.armageddon.model.AttackResultDto;
import com.xx.dev.modules.armageddon.model.BuyTimeDto;
import com.xx.dev.modules.armageddon.model.CheerInfoDto;
import com.xx.dev.modules.armageddon.model.CreateRoomDto;
import com.xx.dev.modules.armageddon.model.EnterInfoDto;
import com.xx.dev.modules.armageddon.model.FlushCheerDto;
import com.xx.dev.modules.armageddon.model.MissionRewardDto;

/**
 * @class:ArmageddonService
 * @description:
 * @author:David
 * @version:v1.0
 * @date:2013-5-20
 **/
public interface ArmageddonService {

	/**************************客户端接口部分*******************************/
	/**
	 * @description:获取指定玩家单人副本进度	
	 * @param playerId
	 * @return
	 */
	Result<ArmageddonInfoDto> chapterInfo(Long playerId);
	
	/**
	 * 创建房间
	 * @param playerId
	 * @return
	 */
	Result<CreateRoomDto> createRoom(long playerId);
	
	/**
	 * @description:获取玩家助阵列表
	 * @param userId 用户id
	 * @return CheerInfoDto
	 */
	public Result<CheerInfoDto> getCheerInfo(long userId);
	
	/**
	 * @description:付费刷新助阵列表	
	 * @param userId
	 * @param cheerId
	 */
	public Result<FlushCheerDto> costFlushCheerInfo(long userId, long cheerId);
	
	/**
	 * 进入单人副本的据点
	 * @param playerId 用户id
	 * @param cheerIdOne 邀请玩家ID
	 * @param cheerIdTwo 邀请玩家ID
	 * @param formation 玩家ID_1|玩家ID_2|玩家ID_3
	 * @param missionId 据点id
	 * @param hardType 困难模式
	 */
	Result<EnterInfoDto> enterChapter(long playerId, long cheerIdOne, long cheerIdTwo, String formation, int missionId, int hardType);
	
	/**
	 * 攻击据点里怪物
	 * @param playerId 用户id
	 * @param missionId 部队所属据点id
	 */
	Result<AttackResultDto> attackMonster(long playerId, int missionId);
	
	/**
	 * 领取通关奖励
	 * @param userId 用户id
	 * @return
	 */
	Result<MissionRewardDto> rewardArea(long playerId);
	
	/**
	 * @description:秒Cd时间	
	 * @param playerId
	 * @return
	 */
	Result<BuyTimeDto> buyTime(long playerId);
	/***************************服务端内部**********************************/
	/**
	 * @description: 根据玩家Id获取大决战实体
	 * @param userId
	 * @return
	 */
	public PlayerArmageddonInfo getPlayerArmageddonInfo(Long playerId);
}

