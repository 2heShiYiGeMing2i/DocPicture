package com.xx.dev.modules.armygroup.service.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.math.RandomUtils;
import org.apache.commons.lang.time.DateUtils;
import org.apache.mina.util.ConcurrentHashSet;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.xx.common.basedb.BasedbService;
import com.xx.common.db.cache.DbCachedService;
import com.xx.common.db.service.CommonManager;
import com.xx.common.event.EventBus;
import com.xx.common.util.BeanUtil;
import com.xx.common.util.DateUtil;
import com.xx.common.util.EnumUtils;
import com.xx.common.util.RandomUtil;
import com.xx.common.utility.lock.ChainLock;
import com.xx.common.utility.lock.LockUtils;
import com.xx.dev.constant.FormulaID;
import com.xx.dev.constant.GameRuleID;
import com.xx.dev.constant.GoldRuleID;
import com.xx.dev.constant.IndexName;
import com.xx.dev.constant.LogSource;
import com.xx.dev.constant.RewardType;
import com.xx.dev.model.Result;
import com.xx.dev.model.RoleAttr;
import com.xx.dev.modules.armygroup.entity.ArmyGroup;
import com.xx.dev.modules.armygroup.entity.ArmyGroupApply;
import com.xx.dev.modules.armygroup.entity.ArmyGroupBuilding;
import com.xx.dev.modules.armygroup.entity.ArmyGroupBuyRecord;
import com.xx.dev.modules.armygroup.entity.ArmyGroupContribute;
import com.xx.dev.modules.armygroup.entity.ArmyGroupMember;
import com.xx.dev.modules.armygroup.entity.ArmyGroupTech;
import com.xx.dev.modules.armygroup.event.ArmyGroupTechUpdateEvent;
import com.xx.dev.modules.armygroup.event.ArmyGroupUpgradeEvent;
import com.xx.dev.modules.armygroup.handler.ArmyGroupCmd;
import com.xx.dev.modules.armygroup.handler.ArmyGroupResult;
import com.xx.dev.modules.armygroup.model.ArmyGroupBuildingDto;
import com.xx.dev.modules.armygroup.model.ArmyGroupBuildingType;
import com.xx.dev.modules.armygroup.model.ArmyGroupContributeDto;
import com.xx.dev.modules.armygroup.model.ArmyGroupDto;
import com.xx.dev.modules.armygroup.model.ArmyGroupMemberDto;
import com.xx.dev.modules.armygroup.model.ArmyGroupPositionType;
import com.xx.dev.modules.armygroup.model.ArmyGroupTechDto;
import com.xx.dev.modules.armygroup.model.ArmyGroupTechType;
import com.xx.dev.modules.armygroup.model.basedb.ArmyGroupAuth;
import com.xx.dev.modules.armygroup.model.basedb.ArmyGroupBuildingOpen;
import com.xx.dev.modules.armygroup.model.basedb.ArmyGroupBuildingUpgrade;
import com.xx.dev.modules.armygroup.model.basedb.ArmyGroupContributeEvent;
import com.xx.dev.modules.armygroup.model.basedb.ArmyGroupPositionNum;
import com.xx.dev.modules.armygroup.model.basedb.ArmyGroupStore;
import com.xx.dev.modules.armygroup.model.basedb.ArmyGroupTechUpgrade;
import com.xx.dev.modules.armygroup.service.ArmyGroupBuildingBasedbService;
import com.xx.dev.modules.armygroup.service.ArmyGroupService;
import com.xx.dev.modules.armygrouptrain.service.ArmyGroupTrainService;
import com.xx.dev.modules.chitchat.model.NoticeDto;
import com.xx.dev.modules.chitchat.model.NoticeId;
import com.xx.dev.modules.chitchat.model.NoticeKey;
import com.xx.dev.modules.chitchat.service.NoticeService;
import com.xx.dev.modules.drop.model.DropResult;
import com.xx.dev.modules.drop.service.DropService;
import com.xx.dev.modules.hero.model.HeroAttrSetType;
import com.xx.dev.modules.hero.service.HeroService;
import com.xx.dev.modules.item.model.basedb.Item;
import com.xx.dev.modules.item.service.ItemService;
import com.xx.dev.modules.mail.model.MailTemplateIds;
import com.xx.dev.modules.mail.service.MailService;
import com.xx.dev.modules.multifuben.service.MultiFubenService;
import com.xx.dev.modules.player.entity.Player;
import com.xx.dev.modules.player.model.PlayerAttrType;
import com.xx.dev.modules.player.model.PlayerDto;
import com.xx.dev.modules.player.model.basedb.Vip;
import com.xx.dev.modules.player.service.PlayerService;
import com.xx.dev.modules.plunderfood.service.PlunderFoodService;
import com.xx.dev.modules.push.PushHelper;
import com.xx.dev.modules.reward.action.RewardActionSet;
import com.xx.dev.modules.reward.model.HeroEquipReward;
import com.xx.dev.modules.reward.model.ItemReward;
import com.xx.dev.modules.reward.model.PlayerEquipReward;
import com.xx.dev.modules.reward.model.Reward;
import com.xx.dev.modules.reward.model.SimpleReward;
import com.xx.dev.modules.reward.result.ValueResultSet;
import com.xx.dev.modules.reward.service.RewardService;
import com.xx.dev.modules.server.SessionManager;
import com.xx.dev.modules.slave.entity.PlayerSlaveInfo;
import com.xx.dev.modules.slave.model.SlaveStatus;
import com.xx.dev.modules.slave.service.SlaveService;
import com.xx.dev.modules.task.event.FoodsOutputEvent;
import com.xx.dev.modules.task.event.GuildDonateEvent;
import com.xx.dev.modules.task.event.GuildEvent;
import com.xx.dev.modules.task.event.GuildMemberEvent;
import com.xx.dev.modules.task.event.SilverOutputEvent;
import com.xx.dev.modules.task.service.TaskBus;
import com.xx.dev.modules.tech.handler.TechResult;
import com.xx.dev.modules.treasure.service.TreasureService;
import com.xx.dev.modules.vip.service.VipService;
import com.xx.dev.utils.CommonRule;
import com.xx.dev.utils.FormulaHelper;
import com.xx.dev.utils.GameRuleService;

/**
 * 军团服务接口实现类
 * 
 * @author Along
 *
 */
@Service
public class ArmyGroupServiceImpl implements ArmyGroupService {

	private Logger logger = LoggerFactory.getLogger(getClass());
	
	/**
	 * session管理器
	 */
	@Autowired
	private SessionManager sessionManager;
	
	/**
	 * 缓存服务接口
	 */
	@Autowired
	private DbCachedService dbCachedService;
	
	/**
	 * 基础数据服务接口
	 */
	@Autowired
	private BasedbService basedbService;
	
	/**
	 * 奖励服务接口
	 */
	@Autowired
	private RewardService rewardService;
	
	/**
	 * 主公服务接口
	 */
	@Autowired
	private PlayerService playerService;
	
	/**
	 * 游戏规则服务接口
	 */
	@Autowired
	private GameRuleService gameRuleService;
	
	/**
	 * 通用数据管理接口
	 */
	@Autowired
	@Qualifier("commonManagerImpl")
	private CommonManager commonManager;
	
	/**
	 * 邮件服务接口
	 */
	@Autowired
	private MailService mailService;
	
	/**
	 * 军团建筑基础数据表服务接口
	 */
	@Autowired
	private ArmyGroupBuildingBasedbService armyGroupBuildingBasedbService;
	
	/**
	 * 武将服务接口
	 */
	@Autowired
	private HeroService heroService;
	
	/**
	 * 事件总线
	 */
	@Autowired
	private EventBus eventBus;
	
	/**
	 * 掉落服务接口
	 */
	@Autowired
	private DropService dropService;
	
	/**
	 * 公告服务接口
	 */
	@Autowired
	private NoticeService noticeService;
	
	/**
	 * VIP服务接口
	 */
	@Autowired
	private VipService vipService;
	
	/**
	 * 道具服务接口
	 */
	@Autowired
	private ItemService itemService;
	
	/**
	 * 截粮服务接口
	 */
	@Autowired
	private PlunderFoodService plunderFoodService;
	
	/**
	 * 军团试炼服务接口
	 */
	@Autowired
	private ArmyGroupTrainService armyGroupTrainService;
	
	/**
	 * 奴隶系统服务接口
	 */
	@Autowired
	private SlaveService slaveService;
	
	/**
	 * 推送帮助
	 */
	@Autowired
	private PushHelper pushHelper;
	
	/**
	 * 公式辅助类
	 */
	@Autowired
	private FormulaHelper formulaHelper;
	
	@Autowired
	private TaskBus taskBus;
	
	@Autowired
	private TreasureService treasureService;
	@Autowired
	private MultiFubenService multiFubenService;
	
	/**
	 * 军团最低职位id（团员）
	 */
	private final int MIN_POSITION_ID = 1;
	
	/**
	 * 军团最高职位id（团长）
	 */
	private final int MAX_POSITION_ID = 4;
	
	@Override
	public Result<ArmyGroupDto> enterArmyGroupAction(long playerId) {
		Player player = this.dbCachedService.get(playerId, Player.class);
		if (player == null) {
			return Result.Error(ArmyGroupResult.FAILURE);
		}
		int amount = 0;
		ArmyGroup armyGroup = null;
		ArmyGroupDto armyGroupDto = null;
		List<ArmyGroupDto> armyGroupDtos = null;
		ArmyGroupMemberDto armyGroupMemberDto = null;
		ArmyGroupMember armyGroupMember = this.dbCachedService.get(playerId, ArmyGroupMember.class);
		if (armyGroupMember != null) {
			armyGroupMemberDto = getArmyGroupMemberDto(player, armyGroupMember);
			if (armyGroupMember.getArmyGroupId() != -1) {// 已经加入军团
				armyGroup = this.dbCachedService.get(armyGroupMember.getArmyGroupId(), 
						ArmyGroup.class);
				if (armyGroup != null) {
					// 2013-11-01
					ChainLock chainLock = LockUtils.getLock(armyGroup);
					chainLock.lock();
					try {
						if (CommonRule.isSameResetTime(armyGroup.getLastSendAdvertiseTime())) {// 当天还没有发送过
							Date now = new Date();
							armyGroup.setAdvertiseTimes(0);
							armyGroup.setLastSendAdvertiseTime(now);
							this.dbCachedService.submitUpdated2Queue(armyGroup.getId(), ArmyGroup.class);
						}
					} finally {
						chainLock.unlock();
					}
					
					Player chief = this.dbCachedService.get(armyGroup.getChief(), Player.class);
					armyGroupDto = this.getArmyGroupDto(chief, armyGroup);
				}
			}
		}
		if (armyGroup == null) {// 还没有加入军团，传军团列表
			amount = getArmyGroupAmount();
			armyGroupDtos = getArmyGroupList(0, 50);
		}
		Result<ArmyGroupDto> result = Result.Success(armyGroupDto);
		result.addContent("amount", amount);
		result.addContent("armyGroups", armyGroupDtos);
		result.addContent("armyGroupMemberDto", armyGroupMemberDto);
		result.addContent("armyGroupBuildingDtos", this.getArmyGroupBuildingsAction(playerId));
		return result;
	}

	private ArmyGroupMemberDto getArmyGroupMemberDto(Player player, ArmyGroupMember armyGroupMember) {
		PlayerSlaveInfo playerSlaveInfo = this.slaveService.getPlayerSlaveInfo(player.getId());
		int slaveStatus = SlaveStatus.FREE.ordinal();
		String masterName = "";
		if (playerSlaveInfo != null) {
			slaveStatus = playerSlaveInfo.getStatus().ordinal();
			if (playerSlaveInfo.getMasterId() != null && playerSlaveInfo.getMasterId() > 0) {
				Player user = this.dbCachedService.get(playerSlaveInfo.getMasterId(), Player.class);
				if (user != null) {
					masterName = user.getPlayerName();
				}
			}
		}
		ArmyGroupMemberDto armyGroupMemberDto = ArmyGroupMemberDto.valueOf(player, 
				this.sessionManager.isOnline(player.getId()), armyGroupMember, slaveStatus, masterName);
		if (!CommonRule.isSameResetTime(armyGroupMember.getReceiveFoodsTime())) {
			armyGroupMemberDto.setReceiveFoodsTimes(1);
		}
		if (!CommonRule.isSameResetTime(armyGroupMember.getReceiveHeroSoulTime())) {
			armyGroupMemberDto.setReceiveHeroSoulTimes(1);
		}
		return armyGroupMemberDto;
	}
	
	@Override
	public Result<ValueResultSet> createArmyGroupAction(long playerId,
			String name, int useGold) {
		if (name == null || name.trim().length() == 0) {
			return Result.Error(ArmyGroupResult.PARAM_ERROR);
		}
		Player player = this.dbCachedService.get(playerId, Player.class);
		if (player == null) {
			return Result.Error(ArmyGroupResult.FAILURE);
		}
		int goldDiscount = 0;
		ArmyGroupMember armyGroupMember = null;
		ValueResultSet valueResultSet = null;
		ArmyGroup armyGroup = null;
		ArmyGroupMemberDto armyGroupMemberDto = null;
		ChainLock chainLock = LockUtils.getLock(player);
		chainLock.lock();
		try {
			armyGroupMember = this.dbCachedService.get(playerId, ArmyGroupMember.class);
			if (armyGroupMember != null && armyGroupMember.getArmyGroupId() != -1) {
				return Result.Error(ArmyGroupResult.HAD_JOIN_ARMY_GROUP);
			}
			int minLevel = this.gameRuleService.getAmountByID(GameRuleID.ARMY_GROUP_CREATE_LEVEL_LIMIT).intValue();
			if (player.getLevel() < minLevel) {
				return Result.Error(ArmyGroupResult.PLAYER_LEVEL_NOT_ENOUGH);
			}
			if (armyGroupMember != null) {
				int coolSeconds = this.gameRuleService.getAmountByID(GameRuleID.ARMY_GROUP_QUIT_JOIN_COOL_TIME).intValue();
				Date coolTime = DateUtils.addMilliseconds(armyGroupMember.getQuitTime(), coolSeconds * 1000);
				if (coolTime.after(new Date())) {// 冷却中
					return Result.Error(ArmyGroupResult.QUIT_COOLING);
				}
			} 
			SimpleReward reward = null;
			if (useGold == 0) {// 使用银元
				int silverCost = this.gameRuleService.getAmountByID(GameRuleID.ARMY_GROUP_CREATE_COST_SILVER).intValue();
				reward = new SimpleReward(RewardType.SILVER, -silverCost);
			} else {// 使用金币
				int goldCost = this.gameRuleService.getGoldById(GoldRuleID.ARMY_GROUP_CREATE_COST);
				int newGoldCost = this.vipService.getGoldDiscountValue(player, goldCost);
				goldDiscount = goldCost - newGoldCost;
				reward = new SimpleReward(RewardType.MONEY_MIX, -newGoldCost);
			}
			RewardActionSet rewardActonSet = this.rewardService.tryRewards(playerId, reward);
			if (rewardActonSet.isNotOK()) {
				return Result.Error(rewardActonSet.getResultCode());
			}
			name = name.trim();
			armyGroup = this.getArmyGroup(name);
			if (armyGroup != null) {// 军团名称已经存在
				return Result.Error(ArmyGroupResult.ARMY_GROUP_NAME_HAD_EXISTS);
			}
			// 创建军团
			boolean joinAgain = false;
			armyGroup = this.createArmyGroup(playerId, name);
			if (armyGroup.getChief() != playerId) {
				return Result.Error(ArmyGroupResult.ARMY_GROUP_NAME_HAD_EXISTS);
			}
			valueResultSet = this.rewardService.executeRewards(playerId, rewardActonSet, 
					LogSource.ARMY_GROUP_CREATE);
			if (armyGroupMember == null) {
				armyGroupMember = this.dbCachedService.submitNew2Queue(new ArmyGroupMember(armyGroup.getId(), 
						playerId, ArmyGroupPositionType.CHIEF));
			} else {
				armyGroupMember.setArmyGroupId(armyGroup.getId());
				armyGroupMember.setPositionId(ArmyGroupPositionType.CHIEF);
				armyGroupMember.setJoinTime(new Date());
				this.dbCachedService.submitUpdated2Queue(playerId, ArmyGroupMember.class);
				joinAgain = true;
			}
			if (joinAgain) {
				// 更新军团科技属性
				this.heroService.refreshLineupHerosAttr(playerId, HeroAttrSetType.ARMY_GROUP_TECH);
				// 刷新玩家属性
				this.playerService.refreshAttr(playerId, PlayerAttrType.HEROS);
				// 推送玩家属性刷新
				this.pushHelper.pushPlayerAttrRefresh(playerId, this.playerService.getPlayerDto(player));
				// 抛军团科技更新事件
				this.eventBus.post(ArmyGroupTechUpdateEvent.valueOf(playerId));
			}
		} finally {
			chainLock.unlock();
		}
		armyGroupMemberDto = this.getArmyGroupMemberDto(player, armyGroupMember);
		// 更新军团id缓存
		this.updateArmyGroupIdsCache(armyGroup.getId(), true);
		// 更新军团成员列表缓存
		this.updateArmyGroupMemberIdsCache(armyGroup.getId(), playerId, true);
		// 发送创建军团公告
		Map<String, Object> values = new HashMap<String, Object>();
		values.put(NoticeKey.PLAYERNAME1, player.getPlayerName());
		values.put(NoticeKey.ARMY_GROUP_NAME, armyGroup.getName());
		NoticeDto noticeDto = NoticeDto.valueOf(NoticeId.ARMY_GROUP_CREATE, values);
		this.noticeService.pushNotice(playerId, noticeDto);
		Result<ValueResultSet> result = Result.Success(valueResultSet);
		ArmyGroupDto armyGroupDto = this.getArmyGroupDto(player, armyGroup);
		result.addContent("armyGroupDto", armyGroupDto);
		result.addContent("armyGroupMemberDto", armyGroupMemberDto);
		result.addContent("goldDiscount", goldDiscount);
		this.taskBus.post(GuildMemberEvent.valueOf(playerId));
		return result;
	}
	
	@Override
	public List<ArmyGroupDto> getArmyGroups() {
		List<ArmyGroupDto> result = null;
		Collection<Long> armyGroupIdList = this.getArmyGroupIds();
		if (CollectionUtils.isNotEmpty(armyGroupIdList)) {
			result = new ArrayList<ArmyGroupDto>();
			for (Long id: armyGroupIdList) {
				ArmyGroupDto armyGroupDto = this.getArmyGroupDto(id);
				if (armyGroupDto != null) {
					result.add(armyGroupDto);
				}
			}
		}
		return result;
	}

	@Override
	public Result<List<ArmyGroupDto>> getArmyGroupsAction(int startIndex, int fetchCount) {
		if (fetchCount > 50) {
			fetchCount = 50;
		}
		int amount = getArmyGroupAmount();
		List<ArmyGroupDto> armyGroupDtos = getArmyGroupList(startIndex, fetchCount);
		Result<List<ArmyGroupDto>> result = Result.Success(armyGroupDtos);
		result.put("amount", amount);
		return result;
	}

	@SuppressWarnings("unchecked")
	private List<ArmyGroupDto> getArmyGroupList(int startIndex, int fetchCount) {
		DetachedCriteria listDc = DetachedCriteria.forClass(ArmyGroup.class)
				.setProjection(Projections.id())
				.addOrder(Order.asc("ranking"));
		List<Long> idList = this.commonManager.getCommonQueryResult(listDc, 
				startIndex, fetchCount);
		List<ArmyGroupDto> armyGroupDtos = null;
		if (CollectionUtils.isNotEmpty(idList)) {
			armyGroupDtos = new ArrayList<ArmyGroupDto>();
			for (long id : idList) {
				armyGroupDtos.add(this.getArmyGroupDto(id));
			}
		}
		return armyGroupDtos;
	}

	/**
	 * 返回军团数量
	 * @return
	 */
	private int getArmyGroupAmount() {
		int amount = 0;
		Collection<Long> armyGroupIdList = this.getArmyGroupIds();
		if (CollectionUtils.isNotEmpty(armyGroupIdList)) {
			amount = armyGroupIdList.size();
		}
		return amount;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<ArmyGroupDto> getRandArmyGroupsAction(int fetchCount) {
		List<ArmyGroupDto> result = null;
		if (fetchCount > 50) {
			fetchCount = 50;
		}
		
		int amount = getArmyGroupAmount();
		
		int tmpStartIndex = amount - fetchCount;
		int startIndex = 0;
		if (tmpStartIndex > 0) {
			startIndex = RandomUtils.nextInt(tmpStartIndex);
		}
		DetachedCriteria listDc = DetachedCriteria.forClass(ArmyGroup.class)
				.setProjection(Projections.id())
				.addOrder(Order.asc("id"));
		List<Long> idList = this.commonManager.getCommonQueryResult(listDc, 
				startIndex, fetchCount);
		if (CollectionUtils.isNotEmpty(idList)) {
			result = new ArrayList<ArmyGroupDto>();
			for (long id : idList) {
				result.add(this.getArmyGroupDto(id));
			}
		}
		return result;
	}
	
	@Override
	public Result<ArmyGroupDto> getArmyGroupAction(String name) {
		ArmyGroup armyGroup = this.getArmyGroup(name);
		if (armyGroup == null) {
			return Result.Error(ArmyGroupResult.ARMY_GROUP_NOT_EXISTS);
		}
		Player chief = this.dbCachedService.get(armyGroup.getChief(), Player.class);
		ArmyGroupDto armyGroupDto = null;
		if (chief != null) {
			armyGroupDto = this.getArmyGroupDto(chief, armyGroup);
		}
		return Result.Success(armyGroupDto);
	}

	@Override
	public ArmyGroupDto getArmyGroupDto(Player player) {
		ArmyGroupDto result = null;
		if (player != null) {
			ArmyGroupMember armyGroupMember = this.dbCachedService.get(
					player.getId(), ArmyGroupMember.class);
			if (armyGroupMember != null && armyGroupMember.getArmyGroupId() != -1) {// 已经加入军团
				result = this.getArmyGroupDto(armyGroupMember.getArmyGroupId());
			} 
		}
		return result;
	}
	
	@Override
	public ArmyGroupDto getArmyGroupDto(long armyGroupId) {
		ArmyGroupDto result = null;
		ArmyGroup armyGroup = this.getArmyGroup(armyGroupId);
		Player chief = this.dbCachedService.get(armyGroup.getChief(), Player.class);
		if (armyGroup != null && chief != null) {
			result = this.getArmyGroupDto(chief, armyGroup);
		}
		return result;
	}
	
	@Override
	public int applyJoinArmyGroupAction(long playerId, long id) {
		Player player = this.dbCachedService.get(playerId, Player.class);
		if (player == null) {
			return ArmyGroupResult.FAILURE;
		}
		ChainLock chainLock = LockUtils.getLock(player);
		chainLock.lock();
		try {
			int minLevel = this.gameRuleService.getAmountByID(GameRuleID.ARMY_GROUP_JOIN_MIN_LEVEL).intValue();
			if (player.getLevel() < minLevel) {
				return ArmyGroupResult.JOIN_MIN_LEVEL_LIMIT;
			}
			ArmyGroupMember armyGroupMember = this.dbCachedService.get(
					playerId, ArmyGroupMember.class);
			if (armyGroupMember != null && armyGroupMember.getArmyGroupId() != -1) {// 已经加入军团
				return ArmyGroupResult.HAD_JOIN_ARMY_GROUP;
			} 
			if (armyGroupMember != null) {
				int coolSeconds = this.gameRuleService.getAmountByID(GameRuleID.ARMY_GROUP_QUIT_JOIN_COOL_TIME).intValue();
				Date coolTime = DateUtils.addMilliseconds(armyGroupMember.getQuitTime(), coolSeconds * 1000);
				if (coolTime.after(new Date())) {// 冷却中
					return ArmyGroupResult.QUIT_COOLING;
				}
			} 
			ArmyGroup armyGroup = this.dbCachedService.get(id, ArmyGroup.class);
			if (armyGroup == null) {// 军团不存在
				return ArmyGroupResult.FAILURE;
			}
			// 判断军团人数是否超过上限
			int level = this.getArmyGroupLevel(armyGroup.getId());
			ArmyGroupBuildingUpgrade armyGroupBuildingUpgrade = this.basedbService.getByUnique(
					ArmyGroupBuildingUpgrade.class, IndexName.ARMY_GROUP_BUILDING_UPGRADE_INDEX, 
					ArmyGroupBuildingType.JUYI_HALL.ordinal(), level);
			if (armyGroupBuildingUpgrade == null) {
				return ArmyGroupResult.BASE_DATA_NOT_EXIST;
			}
			int memberAmount = this.getArmyGroupMemberAmount(armyGroup.getId());
			if (memberAmount >= armyGroupBuildingUpgrade.getValue()) {
				return ArmyGroupResult.ARMY_GROUP_MEMBER_LIMIT;
			}
			// 判断申请次数是否超过上限		
			int applyTimes = this.getApplyTimes(playerId);
			int maxApplyTimes = this.gameRuleService.getAmountByID(
					GameRuleID.ARMY_GROUP_MAX_APPLY_AMOUNT).intValue();
			if (applyTimes >= maxApplyTimes) {
				return ArmyGroupResult.APPLY_AMOUNT_LIMIT;
			}
			List<ArmyGroupApply> armyGroupApplys = this.getApplys(playerId);
			if (CollectionUtils.isNotEmpty(armyGroupApplys)) {
				for (ArmyGroupApply armyGroupApply: armyGroupApplys) {
					if (armyGroupApply.getArmyGroupId() == id) {
						return ArmyGroupResult.HAD_APPLY;
					}
				}
			}
			ArmyGroupApply armyGroupApply = this.dbCachedService.submitNew2Queue(
					new ArmyGroupApply(id, playerId));
			// 更新玩家申请军团列表缓存
			this.updateApplyIdsCache(playerId, armyGroupApply.getId(), true);
			// 更新军团申请id列表缓存
			this.updateArmyGroupApplyIdsCache(id, armyGroupApply.getId(), true);
			// 推送军团申请
			List<ArmyGroupMember> armyGroupMemberList = this.getArmyGroupMembers(id);
			if (CollectionUtils.isNotEmpty(armyGroupMemberList)) {
				for (ArmyGroupMember armyGroupMember2: armyGroupMemberList) {
					ArmyGroupAuth armyGroupAuth = this.basedbService.get(ArmyGroupAuth.class, 
							armyGroupMember2.getPositionId());
					if (armyGroupAuth != null && armyGroupAuth.getDispose() != 0) {// 有审批的权限
						this.pushHelper.pushArmyGroupApply(armyGroupMember2.getId());
					}
				}
			}
		} finally {
			chainLock.unlock();
		}
		return ArmyGroupResult.SUCCESS;
	}

	@Override
	public int cancelApplyAction(long playerId, long id) {
		Player player = this.dbCachedService.get(playerId, Player.class);
		if (player == null) {
			return ArmyGroupResult.FAILURE;
		}
		ChainLock chainLock = LockUtils.getLock(player);
		chainLock.lock();
		try {
			ArmyGroupApply armyGroupApply = null;
			List<ArmyGroupApply> armyGroupAppls = this.getApplys(playerId);
			if (CollectionUtils.isNotEmpty(armyGroupAppls)) {
				for (ArmyGroupApply newArmyGroupApply: armyGroupAppls) {
					if (newArmyGroupApply.getArmyGroupId() == id) {
						armyGroupApply = newArmyGroupApply;
						break;
					}
				}
			}
			if (armyGroupApply == null) {
				return ArmyGroupResult.FAILURE;
			}
			// 更新玩家申请军团列表缓存
			this.updateApplyIdsCache(playerId, armyGroupApply.getId(), false);
			// 更新军团申请id列表缓存
			this.updateArmyGroupApplyIdsCache(id, armyGroupApply.getId(), false);
			this.dbCachedService.submitDeleted2Queue(armyGroupApply.getId(), ArmyGroupApply.class);
		} finally {
			chainLock.unlock();
		}
		return ArmyGroupResult.SUCCESS;
	}
	
	@Override
	public List<PlayerDto> getArmyGroupApplyListAction(long playerId) {
		List<PlayerDto> result = null;
		Player player = this.dbCachedService.get(playerId, Player.class);
		if (player == null) {
			return result;
		}
		ArmyGroupMember armyGroupMember = this.dbCachedService.get(
				playerId, ArmyGroupMember.class);
		if (armyGroupMember == null || armyGroupMember.getArmyGroupId() == -1) {// 还没有加入军团
			return result;
		} 
		ChainLock chainLock = LockUtils.getLock(player, armyGroupMember);
		chainLock.lock();
		try {
			ArmyGroupAuth armyGroupAuth = this.basedbService.get(ArmyGroupAuth.class, 
					armyGroupMember.getPositionId());
			if (armyGroupAuth == null || armyGroupAuth.getDispose() == 0) {// 没有审批权限
				return result;
			}
			List<ArmyGroupApply> armyGroupApplys = 
					this.getArmyGroupApplys(armyGroupMember.getArmyGroupId());
			if (CollectionUtils.isNotEmpty(armyGroupApplys)) {
				result = new ArrayList<PlayerDto>();
				for (ArmyGroupApply armyGroupApply: armyGroupApplys) {
					Player applyPlayer = this.dbCachedService.get(armyGroupApply.getPlayerId(), 
							Player.class);
					PlayerDto applyPlayerDto = this.playerService.getPlayerDto(applyPlayer);
					result.add(applyPlayerDto);
				}
			}
		} finally {
			chainLock.unlock();
		}
		return result;
	}
	
	@Override
	public List<ArmyGroupDto> getApplyListAction(long playerId) {
		List<ArmyGroupDto> result = null;
		Player player = this.dbCachedService.get(playerId, Player.class);
		if (player == null) {
			return result;
		}
		ChainLock chainLock = LockUtils.getLock(player);
		chainLock.lock();
		try {
			ArmyGroupMember armyGroupMember = this.dbCachedService.get(
					playerId, ArmyGroupMember.class);
			if (armyGroupMember != null && armyGroupMember.getArmyGroupId() != -1) {// 已经加入军团
				return result;
			} 
			List<ArmyGroupApply> armyGroupApplies = this.getApplys(playerId);
			if (CollectionUtils.isNotEmpty(armyGroupApplies)) {
				result = new ArrayList<ArmyGroupDto>();
				for (ArmyGroupApply armyGroupApply: armyGroupApplies) {
					ArmyGroup armyGroup = this.getArmyGroup(armyGroupApply.getArmyGroupId());
					if (armyGroup != null) {
						Player chief = this.dbCachedService.get(armyGroup.getChief(), Player.class);
						if (chief != null) {
							ArmyGroupDto armyGroupDto = this.getArmyGroupDto(chief, armyGroup);
							result.add(armyGroupDto);
						}
					}
				}
			}
		} finally {
			chainLock.unlock();
		}
		return result;
	}

	@Override
	public int approveApplyAction(long playerId, long userId) {
		Player player = this.dbCachedService.get(playerId, Player.class);
		if (player == null) {
			return ArmyGroupResult.FAILURE;
		}
		Player user = this.dbCachedService.get(userId, Player.class);
		if (user == null) {
			return ArmyGroupResult.FAILURE;
		}
		ArmyGroupMember armyGroupMember = this.dbCachedService.get(playerId, ArmyGroupMember.class);
		if (armyGroupMember == null || armyGroupMember.getArmyGroupId() == -1) {// 还没有加入军团
			return ArmyGroupResult.FAILURE;
		}
		ArmyGroup armyGroup = this.dbCachedService.get(armyGroupMember.getArmyGroupId(), ArmyGroup.class);
		if (armyGroup == null) {
			return ArmyGroupResult.FAILURE;
		}
		List<ArmyGroupApply> armyGroupApplyList = this.getApplys(userId);
		ArmyGroupApply armyGroupApply = null;
		if (CollectionUtils.isNotEmpty(armyGroupApplyList)) {// 申请列表非空
			for (ArmyGroupApply armyGroupApply2: armyGroupApplyList) {
				if (armyGroupApply2.getArmyGroupId() == armyGroupMember.getArmyGroupId()) {
					armyGroupApply = armyGroupApply2;
					break;
				}
			}
		}
		if (armyGroupApply == null) {
			return ArmyGroupResult.APPLY_NO_EXISTS;
		}
		boolean joinAgain = false;
		ChainLock chainLock = LockUtils.getLock(player, armyGroup, user);
		chainLock.lock();
		try {
			ArmyGroupAuth armyGroupAuth = this.basedbService.get(ArmyGroupAuth.class, 
					armyGroupMember.getPositionId());
			if (armyGroupAuth == null || armyGroupAuth.getDispose() == 0) {// 没有审批权限
				return ArmyGroupResult.HAD_NOT_AUTH;
			}
			// 判断军团人数是否超过上限
			int level = this.getArmyGroupLevel(armyGroup.getId());
			ArmyGroupBuildingUpgrade armyGroupBuildingUpgrade = this.basedbService.getByUnique(
					ArmyGroupBuildingUpgrade.class, IndexName.ARMY_GROUP_BUILDING_UPGRADE_INDEX, 
					ArmyGroupBuildingType.JUYI_HALL.ordinal(), level);
			if (armyGroupBuildingUpgrade == null) {
				return ArmyGroupResult.BASE_DATA_NOT_EXIST;
			}
			int memberAmount = this.getArmyGroupMemberAmount(armyGroup.getId());
			if (memberAmount >= armyGroupBuildingUpgrade.getValue()) {
				return ArmyGroupResult.ARMY_GROUP_MEMBER_LIMIT;
			}
			// 删除申请列表
			if (CollectionUtils.isNotEmpty(armyGroupApplyList)) {
				for (ArmyGroupApply armyGroupApply2: armyGroupApplyList) {
					this.updateArmyGroupApplyIdsCache(armyGroupApply2.getArmyGroupId(), 
							armyGroupApply2.getId(), false);
					this.dbCachedService.submitDeleted2Queue(armyGroupApply2.getId(), ArmyGroupApply.class);
				}
			}
			String key = this.getApplyIdCacheKey(userId);
			this.dbCachedService.removeFromCommonCache(key);
			// 添加军团成员
			ArmyGroupMember newArmyGroupMember = this.dbCachedService.get(userId, ArmyGroupMember.class);
			if (newArmyGroupMember == null) {
				this.dbCachedService.submitNew2Queue(new ArmyGroupMember(armyGroup.getId(),
						userId, ArmyGroupPositionType.MEMBER));
			} else if (newArmyGroupMember.getArmyGroupId() == -1) {
				newArmyGroupMember.setArmyGroupId(armyGroup.getId());
				newArmyGroupMember.setPositionId(ArmyGroupPositionType.MEMBER);
				newArmyGroupMember.setJoinTime(new Date());
				this.dbCachedService.submitUpdated2Queue(userId, ArmyGroupMember.class);
				joinAgain = true;
			} else {
				return ArmyGroupResult.HAD_JOIN_ARMY_GROUP;
			}
			// 更新军团成员列表缓存
			this.updateArmyGroupMemberIdsCache(armyGroup.getId(), userId, true);
			// 推送加入军团
			Player chief = this.dbCachedService.get(armyGroup.getChief(), Player.class);
			ArmyGroupDto armyGroupDto = this.getArmyGroupDto(chief, armyGroup);
			this.pushHelper.pushJoinArmyGroup(userId, armyGroupDto);
			// 发送加入军团公告
			Map<String, Object> values = new HashMap<String, Object>();
			values.put(NoticeKey.PLAYERNAME1, user.getPlayerName());
			NoticeDto noticeDto = NoticeDto.valueOf(NoticeId.ARMY_GROUP_JOIN, values);
			this.noticeService.pushNotice(playerId, noticeDto);
			
			if (joinAgain) {
				// 更新军团科技属性
				this.heroService.refreshLineupHerosAttr(userId, HeroAttrSetType.ARMY_GROUP_TECH);
				// 刷新玩家属性
				this.playerService.refreshAttr(userId, PlayerAttrType.HEROS);
				// 推送玩家属性刷新
				this.pushHelper.pushPlayerAttrRefresh(userId, this.playerService.getPlayerDto(user));
				// 抛军团科技更新事件
				this.eventBus.post(ArmyGroupTechUpdateEvent.valueOf(userId));
			}
		} finally {
			chainLock.unlock();
		}
		
		this.taskBus.post(GuildEvent.valueOf(userId));
		this.taskBus.post(GuildMemberEvent.valueOf(userId));
		// 粮草总产量事件
		this.taskBus.post(FoodsOutputEvent.valueOf(userId));
		// 银元总产量事件
		this.taskBus.post(SilverOutputEvent.valueOf(userId));
				
		return ArmyGroupResult.SUCCESS;
	}

	@Override
	public int approveApplysAction(long playerId) {
		ArmyGroupMember armyGroupMember = this.dbCachedService.get(playerId, ArmyGroupMember.class);
		if (armyGroupMember == null || armyGroupMember.getArmyGroupId() == -1) {// 还没有加入军团
			return ArmyGroupResult.FAILURE;
		}
		ArmyGroup armyGroup = this.dbCachedService.get(armyGroupMember.getArmyGroupId(), ArmyGroup.class);
		if (armyGroup == null) {
			return ArmyGroupResult.FAILURE;
		}
		List<ArmyGroupApply> armyGroupApplyList = this.getArmyGroupApplys(armyGroup.getId());
		if (CollectionUtils.isEmpty(armyGroupApplyList)) {// 申请列表为空
			return ArmyGroupResult.SUCCESS;
		}
		for (ArmyGroupApply armyGroupApply: armyGroupApplyList) {
			this.approveApplyAction(playerId, armyGroupApply.getPlayerId());
		}
		return ArmyGroupResult.SUCCESS;
	}
	
	@Override
	public int refuseApplyAction(long playerId, long userId) {
		Player player = this.dbCachedService.get(playerId, Player.class);
		if (player == null) {
			return ArmyGroupResult.FAILURE;
		}
		ArmyGroupMember armyGroupMember = this.dbCachedService.get(playerId, ArmyGroupMember.class);
		if (armyGroupMember == null || armyGroupMember.getArmyGroupId() == -1) {// 还没有加入军团
			return ArmyGroupResult.FAILURE;
		}
		ArmyGroup armyGroup = this.dbCachedService.get(armyGroupMember.getArmyGroupId(), ArmyGroup.class);
		if (armyGroup == null) {
			return ArmyGroupResult.FAILURE;
		}
		List<ArmyGroupApply> armyGroupApplyList = this.getApplys(userId);
		if (CollectionUtils.isEmpty(armyGroupApplyList)) {// 申请列表为空
			return ArmyGroupResult.FAILURE;
		}
		ArmyGroupApply armyGroupApply = null;
		for (ArmyGroupApply armyGroupApply2: armyGroupApplyList) {
			if (armyGroupApply2.getArmyGroupId() == armyGroupMember.getArmyGroupId()) {
				armyGroupApply = armyGroupApply2;
				break;
			}
		}
		if (armyGroupApply == null) {
			return ArmyGroupResult.PARAM_ERROR;
		}
		ChainLock chainLock = LockUtils.getLock(player, armyGroup, armyGroupMember);
		chainLock.lock();
		try {
			ArmyGroupAuth armyGroupAuth = this.basedbService.get(ArmyGroupAuth.class, 
					armyGroupMember.getPositionId());
			if (armyGroupAuth == null || armyGroupAuth.getDispose() == 0) {// 没有审批权限
				return ArmyGroupResult.HAD_NOT_AUTH;
			}
			// 删除申请列表
			this.updateApplyIdsCache(armyGroupApply.getPlayerId(), armyGroupApply.getId(), false);
			this.updateArmyGroupApplyIdsCache(armyGroup.getId(), armyGroupApply.getId(), false);
			this.dbCachedService.submitDeleted2Queue(armyGroupApply.getId(), ArmyGroupApply.class);
		} finally {
			chainLock.unlock();
		}
		return ArmyGroupResult.SUCCESS;
	}
	
	@Override
	public int refuseApplysAction(long playerId) {
		Player player = this.dbCachedService.get(playerId, Player.class);
		if (player == null) {
			return ArmyGroupResult.FAILURE;
		}
		ArmyGroupMember armyGroupMember = this.dbCachedService.get(
				playerId, ArmyGroupMember.class);
		if (armyGroupMember == null || armyGroupMember.getArmyGroupId() == -1) {// 还没有加入军团
			return ArmyGroupResult.FAILURE;
		}
		ArmyGroup armyGroup = this.dbCachedService.get(armyGroupMember.getArmyGroupId(), ArmyGroup.class);
		if (armyGroup == null) {
			return ArmyGroupResult.FAILURE;
		}
		ChainLock chainLock = LockUtils.getLock(player, armyGroup, armyGroupMember);
		chainLock.lock();
		try {
			ArmyGroupAuth armyGroupAuth = this.basedbService.get(ArmyGroupAuth.class, 
					armyGroupMember.getPositionId());
			if (armyGroupAuth == null || armyGroupAuth.getDispose() == 0) {// 没有审批权限
				return ArmyGroupResult.HAD_NOT_AUTH;
			}
			List<ArmyGroupApply> armyGroupApplyList = this.getArmyGroupApplys(armyGroupMember.getArmyGroupId());
			if (CollectionUtils.isNotEmpty(armyGroupApplyList)) {
				for (ArmyGroupApply armyGroupApply: armyGroupApplyList) {
					// 删除申请列表
					this.updateApplyIdsCache(armyGroupApply.getPlayerId(), armyGroupApply.getId(), false);
					this.updateArmyGroupApplyIdsCache(armyGroupApply.getArmyGroupId(), armyGroupApply.getId(), false);
					this.dbCachedService.submitDeleted2Queue(armyGroupApply.getId(), ArmyGroupApply.class);
				}
			}
		} finally {
			chainLock.unlock();
		}
		return ArmyGroupResult.SUCCESS;
	}
	
	@Override
	public int inviteJoinArmyGroupAction(long playerId, String playerName) {
		Player player = this.dbCachedService.get(playerId, Player.class);
		if (player == null) {
			return ArmyGroupResult.FAILURE;
		}
		Player user = this.playerService.getPlayer(playerName);
		if (user == null) {
			return ArmyGroupResult.FAILURE;
		}
		int minLevel = this.gameRuleService.getAmountByID(GameRuleID.ARMY_GROUP_JOIN_MIN_LEVEL).intValue();
		if (user.getLevel() < minLevel) {
			return ArmyGroupResult.INVITE_MIN_LEVEL_LIMIT;
		}
		ArmyGroupMember armyGroupMember = this.dbCachedService.get(
				playerId, ArmyGroupMember.class);
		if (armyGroupMember == null || armyGroupMember.getArmyGroupId() == -1) {// 还没有加入军团
			return ArmyGroupResult.FAILURE;
		}
		ArmyGroup armyGroup = this.dbCachedService.get(
				armyGroupMember.getArmyGroupId(), ArmyGroup.class);
		if (armyGroup == null) {
			return ArmyGroupResult.FAILURE;
		}
		ArmyGroupMember userArmyGroupMember = this.dbCachedService.get(
				user.getId(), ArmyGroupMember.class);
		if (userArmyGroupMember != null && userArmyGroupMember.getArmyGroupId() != -1) {// 已经加入军团
			return ArmyGroupResult.HAD_JOIN_ARMY_GROUP;
		}
		ChainLock chainLock = LockUtils.getLock(player, armyGroup, armyGroupMember);
		chainLock.lock();
		try {
			ArmyGroupAuth armyGroupAuth = this.basedbService.get(ArmyGroupAuth.class, 
					armyGroupMember.getPositionId());
			if (armyGroupAuth == null || armyGroupAuth.getInvite() == 0) {// 没有邀请权限
				return ArmyGroupResult.HAD_NOT_AUTH;
			}
			// 判断军团人数是否超过上限
			int level = this.getArmyGroupLevel(armyGroup.getId());
			ArmyGroupBuildingUpgrade armyGroupBuildingUpgrade = this.basedbService.getByUnique(
					ArmyGroupBuildingUpgrade.class, IndexName.ARMY_GROUP_BUILDING_UPGRADE_INDEX, 
					ArmyGroupBuildingType.JUYI_HALL.ordinal(), level);
			if (armyGroupBuildingUpgrade == null) {
				return ArmyGroupResult.BASE_DATA_NOT_EXIST;
			}
			int memberAmount = this.getArmyGroupMemberAmount(armyGroup.getId());
			if (memberAmount >= armyGroupBuildingUpgrade.getValue()) {
				return ArmyGroupResult.ARMY_GROUP_MEMBER_LIMIT;
			}
			// 推送邀请
			ArmyGroupDto armyGroupDto = this.getArmyGroupDto(player, armyGroup);
			this.pushHelper.pushArmyGroupInvite(user.getId(), armyGroupDto);
		} finally {
			chainLock.unlock();
		}
		return ArmyGroupResult.SUCCESS;
	}

	@Override
	public int quitArmyGroupAction(long playerId) {
		if (this.plunderFoodService.isPlunderFood(playerId)) {
			return ArmyGroupResult.IN_PLUNDER_FOOD;
		}
		if (this.armyGroupTrainService.isArmyGroupTrain(playerId)) {
			return ArmyGroupResult.IN_ARMY_GROUP_TRAIN;
		}
		Player player = this.dbCachedService.get(playerId, Player.class);
		if (player == null) {
			return ArmyGroupResult.FAILURE;
		}
		ArmyGroupMember armyGroupMember = this.dbCachedService.get(
				playerId, ArmyGroupMember.class);
		if (armyGroupMember == null || armyGroupMember.getArmyGroupId() == -1) {// 还没有加入军团
			return ArmyGroupResult.HAD_NOT_JOIN_ARMY_GROUP;
		}
		ArmyGroup armyGroup = this.dbCachedService.get(
				armyGroupMember.getArmyGroupId(), ArmyGroup.class);
		if (armyGroup == null) {
			return ArmyGroupResult.FAILURE;
		}
		ChainLock chainLock = LockUtils.getLock(player, armyGroup, armyGroupMember);
		chainLock.lock();
		try {
			Date now = new Date();
			if (armyGroupMember.getPositionId() == ArmyGroupPositionType.CHIEF) {
				int armyGroupMemberAmount = this.getArmyGroupMemberAmount(armyGroup.getId());
				if (armyGroupMemberAmount > 1) {
					return ArmyGroupResult.CAN_NOT_QUIT_ARMY_GROUP;
				}
				// 删除军团，军团成员，缓存数据
				String key = this.getArmyGroupMemberIdCacheKey(armyGroup.getId());
				this.dbCachedService.removeFromCommonCache(key);
				// 更新军团id缓存
				this.updateArmyGroupIdsCache(armyGroup.getId(), false);
				this.dbCachedService.submitDeleted2Queue(armyGroup.getId(), ArmyGroup.class);
				armyGroupMember.setArmyGroupId(-1);
				armyGroupMember.setCurContribute(0);
				armyGroupMember.setPositionId(-1);
				armyGroupMember.setQuitTime(now);
				this.dbCachedService.submitUpdated2Queue(playerId, ArmyGroupMember.class);
			} else {
				// 扣除给军团的捐赠
				armyGroup.setWealth(armyGroup.getWealth() - armyGroupMember.getCurContribute());
				this.dbCachedService.submitUpdated2Queue(armyGroup.getId(), ArmyGroup.class);
				// 更新军团成员缓存
				this.updateArmyGroupMemberIdsCache(armyGroup.getId(), playerId, false);
				// 发送退出公告
				Map<String, Object> values = new HashMap<String, Object>();
				values.put(NoticeKey.PLAYERNAME1, player.getPlayerName());
				NoticeDto noticeDto = NoticeDto.valueOf(NoticeId.ARMY_GROUP_QUIT, values);
				this.noticeService.pushNotice(playerId, noticeDto);
				armyGroupMember.setArmyGroupId(-1);
				armyGroupMember.setCurContribute(0);
				armyGroupMember.setPositionId(-1);
				armyGroupMember.setQuitTime(now);
				this.dbCachedService.submitUpdated2Queue(playerId, ArmyGroupMember.class);
			}
			// 更新军团科技属性
			this.heroService.refreshLineupHerosAttr(playerId, HeroAttrSetType.ARMY_GROUP_TECH);
			// 刷新玩家属性
			this.playerService.refreshAttr(playerId, PlayerAttrType.HEROS);
			// 推送玩家属性刷新
			this.pushHelper.pushPlayerAttrRefresh(playerId, this.playerService.getPlayerDto(player));
			// 抛军团科技更新事件
			this.eventBus.post(ArmyGroupTechUpdateEvent.valueOf(playerId));
		} finally {
			chainLock.unlock();
		}
		
		this.treasureService.quitArmyGroup(playerId, armyGroup.getId());
		this.multiFubenService.leftScene(playerId);
		return ArmyGroupResult.SUCCESS;
	}

	@Override
	public int advertiseAction(long playerId, String content) {
		Player player = this.dbCachedService.get(playerId, Player.class);
		if (player == null) {
			return ArmyGroupResult.FAILURE;
		}
		ArmyGroupMember armyGroupMember = this.dbCachedService.get(
				playerId, ArmyGroupMember.class);
		if (armyGroupMember == null || armyGroupMember.getArmyGroupId() == -1) {// 还没有加入军团
			return ArmyGroupResult.FAILURE;
		}
		ArmyGroup armyGroup = this.dbCachedService.get(
				armyGroupMember.getArmyGroupId(), ArmyGroup.class);
		if (armyGroup == null) {
			return ArmyGroupResult.FAILURE;
		}
		ChainLock chainLock = LockUtils.getLock(player, armyGroup, armyGroupMember);
		chainLock.lock();
		try {
			// 判断军团人数是否超过上限
			int level = this.getArmyGroupLevel(armyGroup.getId());
			ArmyGroupBuildingUpgrade armyGroupBuildingUpgrade = this.basedbService.getByUnique(
					ArmyGroupBuildingUpgrade.class, IndexName.ARMY_GROUP_BUILDING_UPGRADE_INDEX, 
					ArmyGroupBuildingType.JUYI_HALL.ordinal(), level);
			if (armyGroupBuildingUpgrade == null) {
				return ArmyGroupResult.BASE_DATA_NOT_EXIST;
			}
			int memberAmount = this.getArmyGroupMemberAmount(armyGroup.getId());
			if (memberAmount >= armyGroupBuildingUpgrade.getValue()) {
				return ArmyGroupResult.ARMY_GROUP_MEMBER_LIMIT;
			}		
			ArmyGroupAuth armyGroupAuth = this.basedbService.get(ArmyGroupAuth.class, 
					armyGroupMember.getPositionId());
			if (armyGroupAuth == null || armyGroupAuth.getQuickInvite() == 0) {// 没有快速邀请的权限
				return ArmyGroupResult.HAD_NOT_AUTH;
			}
			if (CommonRule.isSameResetTime(armyGroup.getLastSendAdvertiseTime())) {// 当天还没有发送过
				Date now = new Date();
				armyGroup.setAdvertiseTimes(0);
				armyGroup.setLastSendAdvertiseTime(now);
				this.dbCachedService.submitUpdated2Queue(armyGroup.getId(), ArmyGroup.class);
			}
			int maxTimes = this.gameRuleService.getAmountByID(GameRuleID.ARMY_GROUP_MAX_SEND_ADVERTISE_TIMES).intValue();
			if (armyGroup.getAdvertiseTimes() >= maxTimes) {// 发送次数已经用完
				return ArmyGroupResult.SEND_ADVERTISE_TIMES_LIMIT;
			}
			armyGroup.setAdvertiseTimes(armyGroup.getAdvertiseTimes() + 1);
			this.dbCachedService.submitUpdated2Queue(armyGroup.getId(), ArmyGroup.class);
			// 发送招贤公告
			Map<String, Object> values = new HashMap<String, Object>();
			values.put(NoticeKey.PLAYERNAME1, player.getPlayerName());
			values.put(NoticeKey.ARMY_GROUP_ID, armyGroup.getId());
			values.put(NoticeKey.ARMY_GROUP_NAME, armyGroup.getName());
			values.put(NoticeKey.CONTENT, content);
			NoticeDto noticeDto = NoticeDto.valueOf(NoticeId.ARMY_GROUP_ADVERTISE, values);
			this.noticeService.pushNotice(playerId, noticeDto);
		} finally {
			chainLock.unlock();
		}
		return ArmyGroupResult.SUCCESS;
	}

	@Override
	public Result<ArmyGroupDto> updateDeclarationAction(long playerId, String content) {
		if (content != null && content.length() > 250) {
			return Result.Error(ArmyGroupResult.PARAM_ERROR);
		}
		Player player = this.dbCachedService.get(playerId, Player.class);
		if (player == null) {
			return Result.Error(ArmyGroupResult.FAILURE);
		}
		ArmyGroupMember armyGroupMember = this.dbCachedService.get(
				playerId, ArmyGroupMember.class);
		if (armyGroupMember == null || armyGroupMember.getArmyGroupId() == -1) {// 还没有加入军团
			return Result.Error(ArmyGroupResult.FAILURE);
		}
		ArmyGroup armyGroup = this.dbCachedService.get(
				armyGroupMember.getArmyGroupId(), ArmyGroup.class);
		if (armyGroup == null) {
			return Result.Error(ArmyGroupResult.FAILURE);
		}
		ArmyGroupDto armyGroupDto = null;
		ChainLock chainLock = LockUtils.getLock(player, armyGroup, armyGroupMember);
		chainLock.lock();
		try {
			ArmyGroupAuth armyGroupAuth = this.basedbService.get(ArmyGroupAuth.class, 
					armyGroupMember.getPositionId());
			if (armyGroupAuth == null || armyGroupAuth.getUpdateDeclaration() == 0) {// 没有修改宣言的权限
				return Result.Error(ArmyGroupResult.HAD_NOT_AUTH);
			}
			armyGroup.setDeclaration(content);
			this.dbCachedService.submitUpdated2Queue(armyGroup.getId(), ArmyGroup.class);
			armyGroupDto = this.getArmyGroupDto(armyGroup.getId());
		} finally {
			chainLock.unlock();
		}
		return Result.Success(armyGroupDto);
	}

	@Override
	public int updateNoticeAction(long playerId, String content) {
		if (content != null && content.length() > 250) {
			return ArmyGroupResult.PARAM_ERROR;
		}
		Player player = this.dbCachedService.get(playerId, Player.class);
		if (player == null) {
			return ArmyGroupResult.FAILURE;
		}
		ArmyGroupMember armyGroupMember = this.dbCachedService.get(
				playerId, ArmyGroupMember.class);
		if (armyGroupMember == null || armyGroupMember.getArmyGroupId() == -1) {// 还没有加入军团
			return ArmyGroupResult.FAILURE;
		}
		ArmyGroup armyGroup = this.dbCachedService.get(
				armyGroupMember.getArmyGroupId(), ArmyGroup.class);
		if (armyGroup == null) {
			return ArmyGroupResult.FAILURE;
		}
		ChainLock chainLock = LockUtils.getLock(player, armyGroup, armyGroupMember);
		chainLock.lock();
		try {
			ArmyGroupAuth armyGroupAuth = this.basedbService.get(ArmyGroupAuth.class, 
					armyGroupMember.getPositionId());
			if (armyGroupAuth == null || armyGroupAuth.getUpdateNotice() == 0) {// 没有修改公告的权限
				return ArmyGroupResult.HAD_NOT_AUTH;
			}
			armyGroup.setNotice(content);
			this.dbCachedService.submitUpdated2Queue(armyGroup.getId(), ArmyGroup.class);
		} finally {
			chainLock.unlock();
		}
		return ArmyGroupResult.SUCCESS;
	}

	@Override
	public ArmyGroup checkSendArmyGroupEmail(long playerId) {
		ArmyGroup result = null;
		Player player = this.dbCachedService.get(playerId, Player.class);
		if (player == null) {
			return result;
		}
		ArmyGroupMember armyGroupMember = this.dbCachedService.get(
				playerId, ArmyGroupMember.class);
		if (armyGroupMember == null || armyGroupMember.getArmyGroupId() == -1) {// 还没有加入军团
			return result;
		}
		ArmyGroup armyGroup = this.dbCachedService.get(armyGroupMember.getArmyGroupId(), ArmyGroup.class);
		if (armyGroup == null) {
			return result;
		}
		ChainLock chainLock = LockUtils.getLock(player, armyGroupMember);
		chainLock.lock();
		try {
			ArmyGroupAuth armyGroupAuth = this.basedbService.get(ArmyGroupAuth.class, 
					armyGroupMember.getPositionId());
			if (armyGroupAuth == null || armyGroupAuth.getSendEmail() == 0) {// 没有发送军团邮件的权限
				return result;
			}
			result = armyGroup;
		} finally {
			chainLock.unlock();
		}
		return result;
	}
	
	@Override
	public Result<ValueResultSet> buyHufuAction(long playerId, int amount, int useGold) {
		Player player = this.dbCachedService.get(playerId, Player.class);
		if (player == null) {
			return Result.Error(ArmyGroupResult.FAILURE);
		}
		if (amount <= 0) {
			return Result.Error(ArmyGroupResult.PARAM_ERROR);
		}
		int goldDiscount = 0;
		ValueResultSet valueResultSet = null;
		ChainLock chainLock = LockUtils.getLock(player);
		chainLock.lock();
		try {
			ArmyGroupMember armyGroupMember = this.dbCachedService.get(playerId, ArmyGroupMember.class);
			if (armyGroupMember == null) {
				armyGroupMember = this.dbCachedService.submitNew2Queue(new ArmyGroupMember(-1, playerId, -1));
			}
			SimpleReward goldReward = null;
			SimpleReward silverReward = null;
			int itemId = this.gameRuleService.getAmountByID(GameRuleID.ARMY_GROUP_HU_FU_ITEM_ID).intValue();
			Item item = this.basedbService.get(Item.class, itemId);
			if (item == null) {
				return Result.Error(ArmyGroupResult.BASE_DATA_NOT_EXIST);
			}
			if (useGold == 0) {// 使用银元
				int silverCost = this.gameRuleService.getAmountByID(GameRuleID.ARMY_GROUP_BUY_HUFU_COST).intValue();
				silverReward = new SimpleReward(RewardType.SILVER, -silverCost * amount);
			} else {// 使用金币
				int goldCost = this.gameRuleService.getGoldById(GoldRuleID.ARMY_GROUP_BUY_HUFU_COST);
				int newGoldCost = this.vipService.getGoldDiscountValue(player, goldCost);
				goldDiscount = (goldCost - newGoldCost) * amount;
				goldReward = new SimpleReward(RewardType.MONEY_MIX,	-newGoldCost * amount);
			}
			ItemReward itemReward = ItemReward.valueOf(itemId, amount);
			List<Reward> rewards = new ArrayList<Reward>();
			rewards.add(itemReward);
			if (goldReward != null) {
				rewards.add(goldReward);
			}
			if (silverReward != null) {
				rewards.add(silverReward);
			}
			RewardActionSet rewardActonSet = this.rewardService.tryRewards(playerId, rewards);
			if (rewardActonSet.isNotOK()) {
				return Result.Error(rewardActonSet.getResultCode());
			}
			valueResultSet = this.rewardService.executeRewards(playerId, rewardActonSet, 
					LogSource.ARMY_GROUP_BUY_HUFU);
		} finally {
			chainLock.unlock();
		}
		Result<ValueResultSet> result = Result.Success(valueResultSet);
		result.addContent("goldDiscount", goldDiscount);
		return result;
	}

	@Override
	public List<ArmyGroupMemberDto> getArmyGroupMembersAction(long playerId) {
		List<ArmyGroupMemberDto> result = null;
		Player player = this.dbCachedService.get(playerId, Player.class);
		if (player == null) {
			return result;
		}
		ArmyGroupMember armyGroupMember = this.dbCachedService.get(
				playerId, ArmyGroupMember.class);
		if (armyGroupMember == null || armyGroupMember.getArmyGroupId() == -1) {// 还没有加入军团
			return result;
		}
		ArmyGroup armyGroup = this.dbCachedService.get(armyGroupMember.getArmyGroupId(), ArmyGroup.class);
		if (armyGroup == null) {
			return result;
		}
		List<ArmyGroupMember> armyGroupMembers = this.getArmyGroupMembers(
				armyGroupMember.getArmyGroupId());
		if (CollectionUtils.isNotEmpty(armyGroupMembers)) {
			result = new ArrayList<ArmyGroupMemberDto>();
			for (ArmyGroupMember armyGroupMember2: armyGroupMembers) {
				Player user = this.dbCachedService.get(armyGroupMember2.getId(), Player.class);
				ArmyGroupMemberDto armyGroupMemberDto = 
						this.getArmyGroupMemberDto(user, armyGroupMember2);
				result.add(armyGroupMemberDto);
			}
		}
//		ChainLock chainLock = LockUtils.getLock(player, armyGroupMember, armyGroup);
//		chainLock.lock();
//		try {
//		} finally {
//			chainLock.unlock();
//		}
		return result;
	}

	@Override
	public ConcurrentHashSet<Long> getPlayerArmyGroupMemberIds(long playerId) {
		ConcurrentHashSet<Long> result = null;
		Player player = this.dbCachedService.get(playerId, Player.class);
		if (player == null) {
			return result;
		}
		ArmyGroupMember armyGroupMember = this.dbCachedService.get(
				playerId, ArmyGroupMember.class);
		if (armyGroupMember == null || armyGroupMember.getArmyGroupId() == -1) {// 还没有加入军团
			return result;
		} 
		result = new ConcurrentHashSet<Long>(this.getArmyGroupMemberIds(armyGroupMember.getArmyGroupId()));
		return result;
	}
	
	@Override
	public Result<ValueResultSet> receiveFoodsAction(long playerId) {
		Player player = this.dbCachedService.get(playerId, Player.class);
		if (player == null) {
			return Result.Error(ArmyGroupResult.FAILURE);
		}
		ArmyGroupMember armyGroupMember = this.dbCachedService.get(playerId, ArmyGroupMember.class);
		if (armyGroupMember == null ||armyGroupMember.getArmyGroupId() == -1) {// 还没加入军团
			return Result.Error(ArmyGroupResult.HAD_NOT_JOIN_ARMY_GROUP);
		}
		ValueResultSet valueResultSet = null;
		ArmyGroupMemberDto armyGroupMemberDto = null;
		ChainLock chainLock = LockUtils.getLock(player, armyGroupMember);
		chainLock.lock();
		try {
			Date now = new Date();
			if (!CommonRule.isSameResetTime(armyGroupMember.getReceiveFoodsTime())) {// 当天已经领取过
				return Result.Error(ArmyGroupResult.TODAY_HAD_RECEIVED_FOODS);
			}
			double added = 0.0;
			int level = this.getArmyGroupBuildingLevel(armyGroupMember.getArmyGroupId(), 
					ArmyGroupBuildingType.ACCOUNTANT_OFFICE.ordinal());
			ArmyGroupBuildingUpgrade armyGroupBuildingUpgrade = this.basedbService.getByUnique(
					ArmyGroupBuildingUpgrade.class, IndexName.ARMY_GROUP_BUILDING_UPGRADE_INDEX, 
					ArmyGroupBuildingType.ACCOUNTANT_OFFICE.ordinal(), level);
			if (armyGroupBuildingUpgrade != null) {
				added = armyGroupBuildingUpgrade.getValue();
			}
			int rewardFoods = formulaHelper.invoke(FormulaID.ARMY_GROUP_RECEIVE_FOODS, 
					player.getLevel(), added).intValue();
			SimpleReward reward = new SimpleReward(RewardType.FOODS, rewardFoods);
			RewardActionSet rewardActonSet = this.rewardService.tryRewards(playerId, reward);
			if (rewardActonSet.isNotOK()) {
				return Result.Error(rewardActonSet.getResultCode());
			}
			valueResultSet = this.rewardService.executeRewards(playerId, rewardActonSet, 
					LogSource.ARMY_GROUP_RECEIVE_FOODS);
			armyGroupMember.setReceiveFoodsTime(now);
			this.dbCachedService.submitUpdated2Queue(playerId, ArmyGroupMember.class);
		} finally {
			chainLock.unlock();
		}
		armyGroupMemberDto = getArmyGroupMemberDto(player, armyGroupMember);
		Result<ValueResultSet> result =  Result.Success(valueResultSet);
		result.addContent("armyGroupMemberDto", armyGroupMemberDto);
		return result;
	}

	@Override
	public Result<ValueResultSet> receiveHeroSoulAction(long playerId) {
		Player player = this.dbCachedService.get(playerId, Player.class);
		if (player == null) {
			return Result.Error(ArmyGroupResult.FAILURE);
		}
		ArmyGroupMember armyGroupMember = this.dbCachedService.get(playerId, ArmyGroupMember.class);
		if (armyGroupMember == null ||armyGroupMember.getArmyGroupId() == -1) {// 还没加入军团
			return Result.Error(ArmyGroupResult.HAD_NOT_JOIN_ARMY_GROUP);
		}
		ValueResultSet valueResultSet = null;
		ArmyGroupMemberDto armyGroupMemberDto = null;
		ChainLock chainLock = LockUtils.getLock(player, armyGroupMember);
		chainLock.lock();
		try {
			Date now = new Date();
			if (!CommonRule.isSameResetTime(armyGroupMember.getReceiveHeroSoulTime())) {// 当天已经领取过
				return Result.Error(ArmyGroupResult.TODAY_HAD_RECEIVED_HERO_SOUL);
			}
			int added = 0;
			int level = this.getArmyGroupBuildingLevel(armyGroupMember.getArmyGroupId(), 
					ArmyGroupBuildingType.CLAN_HALL.ordinal());
			ArmyGroupBuildingUpgrade armyGroupBuildingUpgrade = this.basedbService.getByUnique(
					ArmyGroupBuildingUpgrade.class, IndexName.ARMY_GROUP_BUILDING_UPGRADE_INDEX, 
					ArmyGroupBuildingType.CLAN_HALL.ordinal(), level);
			if (armyGroupBuildingUpgrade != null) {
				added = (int) armyGroupBuildingUpgrade.getValue();
			}
			//int rewardHeroSoul = formulaHelper.invoke(FormulaID.ARMY_GROUP_RECEIVE_HERO_SOUL, 
					//player.getLevel(), added).intValue();
			SimpleReward reward = new SimpleReward(RewardType.JZL, added);
			RewardActionSet rewardActonSet = this.rewardService.tryRewards(playerId, reward);
			if (rewardActonSet.isNotOK()) {
				return Result.Error(rewardActonSet.getResultCode());
			}
			valueResultSet = this.rewardService.executeRewards(playerId, rewardActonSet, 
					LogSource.ARMY_GROUP_RECEIVE_HERO_SOUL);
			armyGroupMember.setReceiveHeroSoulTime(now);
			this.dbCachedService.submitUpdated2Queue(playerId, ArmyGroupMember.class);
		} finally {
			chainLock.unlock();
		}
		armyGroupMemberDto = getArmyGroupMemberDto(player, armyGroupMember);
		Result<ValueResultSet> result =  Result.Success(valueResultSet);
		result.addContent("armyGroupMemberDto", armyGroupMemberDto);
		
		this.multiFubenService.pushPlayerJzlChanges(playerId);
		return result;
	}

	@Override
	public Result<ArmyGroupMemberDto> changePositionAction(long playerId,
			long userId, int positionId) {
		if (positionId < MIN_POSITION_ID || positionId > MAX_POSITION_ID) {
			return Result.Error(ArmyGroupResult.PARAM_ERROR);
		}
		Player player = this.dbCachedService.get(playerId, Player.class);
		if (player == null) {
			return Result.Error(ArmyGroupResult.FAILURE);
		}
		ArmyGroupMember armyGroupMember = this.dbCachedService.get(playerId, 
				ArmyGroupMember.class);
		if (armyGroupMember == null || armyGroupMember.getArmyGroupId() == -1) {// 还没有加入军团
			return Result.Error(ArmyGroupResult.FAILURE);
		}
		Player user = this.dbCachedService.get(userId, Player.class);
		if (user == null) {
			return Result.Error(ArmyGroupResult.FAILURE);
		}
		ArmyGroupMember armyGroupMember2 = this.dbCachedService.get(userId, 
				ArmyGroupMember.class);
		if (armyGroupMember2 == null || armyGroupMember2.getPositionId() == positionId) {
			return Result.Error(ArmyGroupResult.FAILURE);
		}
		ChainLock chainLock = LockUtils.getLock(player, armyGroupMember, armyGroupMember2);
		chainLock.lock();
		try {
			if (armyGroupMember.getArmyGroupId() != armyGroupMember2.getArmyGroupId()) {
				return Result.Error(ArmyGroupResult.PARAM_ERROR);
			}
			if (armyGroupMember.getPositionId() <= positionId) {// 权限不够
				return Result.Error(ArmyGroupResult.HAD_NOT_AUTH);
			}
			ArmyGroupAuth armyGroupAuth = this.basedbService.get(ArmyGroupAuth.class, 
					armyGroupMember.getPositionId());
			if (armyGroupAuth == null || armyGroupMember.getPositionId() <= armyGroupMember2.getPositionId()) {// 没有操作权限
				return Result.Error(ArmyGroupResult.HAD_NOT_AUTH);
			}
			ArmyGroupPositionNum armyGroupPositionNum = this.basedbService.get(ArmyGroupPositionNum.class, 
					positionId);
			if (armyGroupPositionNum != null) {
				if (this.getArmyGroupPositionAmount(armyGroupMember.getArmyGroupId(), armyGroupPositionNum) + 1 > 
				armyGroupPositionNum.getMaxCount()) {
					return Result.Error(ArmyGroupResult.ARMY_GROUP_POSITION_LIMIT);
				}
			}
			if (armyGroupMember2.getPositionId() < positionId) {// 升职
				if (armyGroupAuth.getPromote() == 0) {
					return Result.Error(ArmyGroupResult.HAD_NOT_AUTH);
				}
				// 发送升职公告
				Map<String, Object> values = new HashMap<String, Object>();
				values.put(NoticeKey.PLAYERNAME1, player.getPlayerName());
				values.put(NoticeKey.PLAYERNAME2, user.getPlayerName());
				NoticeDto noticeDto = null;
				if (positionId == ArmyGroupPositionType.DEPUTY_CHIEF) {
					noticeDto = NoticeDto.valueOf(NoticeId.ARMY_GROUP_UP_TO_DEPUTY_CHIEF, values);
				} else {
					noticeDto = NoticeDto.valueOf(NoticeId.ARMY_GROUP_UP_TO_OFFICIAL, values);
				}
				this.noticeService.pushNotice(playerId, noticeDto);
			} else {// 降职
				if (armyGroupAuth.getDemotion()== 0) {
					return Result.Error(ArmyGroupResult.HAD_NOT_AUTH);
				}
				// 发送降职公告
				Map<String, Object> values = new HashMap<String, Object>();
				values.put(NoticeKey.PLAYERNAME1, player.getPlayerName());
				values.put(NoticeKey.PLAYERNAME2, user.getPlayerName());
				NoticeDto noticeDto = null;
				if (positionId == ArmyGroupPositionType.OFFICIAL) {
					noticeDto = NoticeDto.valueOf(NoticeId.ARMY_GROUP_DOWN_TO_OFFICIAL, values);
				} else {
					noticeDto = NoticeDto.valueOf(NoticeId.ARMY_GROUP_DOWN_TO_MEMBER, values);
				}
				this.noticeService.pushNotice(playerId, noticeDto);
			}
			// 修改职位
			armyGroupMember2.setPositionId(positionId);
			this.dbCachedService.submitUpdated2Queue(userId, ArmyGroupMember.class);
		} finally {
			chainLock.unlock();
		}
		ArmyGroupMemberDto armyGroupMemberDto = this.getArmyGroupMemberDto(user, armyGroupMember2);
		return Result.Success(armyGroupMemberDto);
	}

	private int getArmyGroupPositionAmount(long armyGroupId, ArmyGroupPositionNum armyGroupPositionNum) {
		int result = 0;
		ConcurrentHashSet<Long> ids = this.getArmyGroupMemberIds(armyGroupId);
		if (CollectionUtils.isNotEmpty(ids)) {
			for (long userId : ids) {
				ArmyGroupMember armyGroupMember = this.dbCachedService.get(userId, ArmyGroupMember.class);
				if (armyGroupMember != null && armyGroupMember.getPositionId() == armyGroupPositionNum.getId()) {
					result += 1;
				}
			}
		}
		return result;
	}
	
	@Override
	public Result<ArmyGroupDto> kickOutSomeOneAction(long playerId, long userId, 
			String reason) {
		if (this.plunderFoodService.isPlunderFood(userId)) {
			return Result.Error(ArmyGroupResult.IN_PLUNDER_FOOD);
		}
		if (this.armyGroupTrainService.isArmyGroupTrain(playerId)) {
			return Result.Error(ArmyGroupResult.IN_ARMY_GROUP_TRAIN);
		}
		Player player = this.dbCachedService.get(playerId, Player.class);
		if (player == null) {
			return Result.Error(ArmyGroupResult.FAILURE);
		}
		Player user = this.dbCachedService.get(userId, Player.class);
		if (user == null) {
			return Result.Error(ArmyGroupResult.FAILURE);
		}
		ArmyGroupMember armyGroupMember = this.dbCachedService.get(
				playerId, ArmyGroupMember.class);
		if (armyGroupMember == null || armyGroupMember.getArmyGroupId() == -1) {// 还没有加入军团
			return Result.Error(ArmyGroupResult.FAILURE);
		}
		ArmyGroup armyGroup = this.dbCachedService.get(armyGroupMember.getArmyGroupId(), ArmyGroup.class);
		if (armyGroup == null) {
			return Result.Error(ArmyGroupResult.FAILURE);
		}
		ArmyGroupMember armyGroupMember2 = this.dbCachedService.get(userId, 
				ArmyGroupMember.class);
		if (armyGroupMember2 == null) {
			return Result.Error(ArmyGroupResult.FAILURE);
		}
		Player chief = null;
		ChainLock chainLock = LockUtils.getLock(player, user, armyGroup, armyGroupMember, armyGroupMember2);
		chainLock.lock();
		try {
			if (armyGroupMember.getArmyGroupId() != armyGroupMember2.getArmyGroupId()) {
				return Result.Error(ArmyGroupResult.PARAM_ERROR);
			}
			ArmyGroupAuth armyGroupAuth = this.basedbService.get(ArmyGroupAuth.class, 
					armyGroupMember.getPositionId());
			if (armyGroupAuth == null || armyGroupAuth.getKickOut() == 0 ||
					armyGroupMember.getPositionId() <= armyGroupMember2.getPositionId()) {// 没有踢人的权限
				return Result.Error(ArmyGroupResult.HAD_NOT_AUTH);
			}
			chief = this.dbCachedService.get(armyGroup.getChief(), Player.class);
			// 军团扣除这个玩家的贡献
			armyGroup.setWealth(armyGroup.getWealth() - armyGroupMember2.getCurContribute());
			this.dbCachedService.submitUpdated2Queue(armyGroup.getId(), ArmyGroup.class);
			// 踢人
			armyGroupMember2.setArmyGroupId(-1);
			armyGroupMember2.setPositionId(-1);
			armyGroupMember2.setCurContribute(0);
			this.dbCachedService.submitUpdated2Queue(userId, ArmyGroupMember.class);
			// 更新军团成员缓存
			this.updateArmyGroupMemberIdsCache(armyGroup.getId(), userId, false);
			// 更新军团科技属性
			this.heroService.refreshLineupHerosAttr(userId, HeroAttrSetType.ARMY_GROUP_TECH);
			// 刷新玩家属性
			this.playerService.refreshAttr(userId, PlayerAttrType.HEROS);
			// 推送玩家属性刷新
			this.pushHelper.pushPlayerAttrRefresh(userId, this.playerService.getPlayerDto(user));
			// 抛军团科技更新事件
			this.eventBus.post(ArmyGroupTechUpdateEvent.valueOf(userId));
			// 发送邮件告知踢人原因
			Map<String, Object> keyValues = new HashMap<String, Object>();
			keyValues.put(NoticeKey.ARMY_GROUP_NAME, armyGroup.getName());
			keyValues.put(NoticeKey.PLAYERNAME1, player.getPlayerName());
			keyValues.put(NoticeKey.CONTENT, reason);
			this.mailService.sendArmyGroupMail(playerId, userId, MailTemplateIds.KICKOUT_ARMY_GROUP, keyValues);
			// 发送踢人公告
			Map<String, Object> values = new HashMap<String, Object>();
			values.put(NoticeKey.PLAYERNAME1, user.getPlayerName());
			values.put(NoticeKey.PLAYERNAME2, player.getPlayerName());
			NoticeDto noticeDto = NoticeDto.valueOf(NoticeId.ARMY_GROUP_KICK_OUT, values);
			this.noticeService.pushNotice(playerId, noticeDto);
			// 推送被踢出军团
			this.pushHelper.pushKickOutArmyGroup(userId);
		} finally {
			chainLock.unlock();
		}
		ArmyGroupDto armyGroupDto = this.getArmyGroupDto(chief, armyGroup);
		Result<ArmyGroupDto> result = Result.Success(armyGroupDto);
		
		this.treasureService.quitArmyGroup(userId, armyGroup.getId());
		this.multiFubenService.leftScene(userId);
		return result;
	}

	@Override
	public Result<ArmyGroupDto> transferChiefAction(long playerId, long userId) {
		Player player = this.dbCachedService.get(playerId, Player.class);
		if (player == null) {
			return Result.Error(ArmyGroupResult.FAILURE);
		}
		ArmyGroupMember armyGroupMember = this.dbCachedService.get(
				playerId, ArmyGroupMember.class);
		if (armyGroupMember == null || armyGroupMember.getArmyGroupId() == -1) {// 还没有加入军团
			return Result.Error(ArmyGroupResult.FAILURE);
		}
		ArmyGroup armyGroup = this.dbCachedService.get(
				armyGroupMember.getArmyGroupId(), ArmyGroup.class);
		if (armyGroup == null) {
			return Result.Error(ArmyGroupResult.FAILURE);
		}
		Player user = this.dbCachedService.get(userId, Player.class);
		if (user == null) {
			return Result.Error(ArmyGroupResult.FAILURE);
		}
		ArmyGroupMember armyGroupMember2 = this.dbCachedService.get(userId, 
				ArmyGroupMember.class);
		if (armyGroupMember2 == null || armyGroupMember2.getArmyGroupId() == -1) {// 还没有加入军团
			return Result.Error(ArmyGroupResult.FAILURE);
		}
		ChainLock chainLock = LockUtils.getLock(player, armyGroup, armyGroupMember, armyGroupMember2);
		chainLock.lock();
		try {
			if (armyGroupMember.getArmyGroupId() != armyGroupMember2.getArmyGroupId()) {
				return Result.Error(ArmyGroupResult.PARAM_ERROR);
			}
			ArmyGroupAuth armyGroupAuth = this.basedbService.get(ArmyGroupAuth.class, 
					armyGroupMember.getPositionId());
			if (armyGroupAuth == null || armyGroupAuth.getTransfer() == 0) {// 没有转让的权限
				return Result.Error(ArmyGroupResult.HAD_NOT_AUTH);
			}
			// 互换职位
			int positionId = armyGroupMember.getPositionId();
			armyGroupMember.setPositionId(armyGroupMember2.getPositionId());
			this.dbCachedService.submitUpdated2Queue(playerId, ArmyGroupMember.class);
			armyGroupMember2.setPositionId(positionId);
			this.dbCachedService.submitUpdated2Queue(userId, ArmyGroupMember.class);
			armyGroup.setChief(userId);
			this.dbCachedService.submitUpdated2Queue(armyGroup.getId(), ArmyGroup.class);
			// 发送成为团长公告
			Map<String, Object> values = new HashMap<String, Object>();
			values.put(NoticeKey.PLAYERNAME1, user.getPlayerName());
			NoticeDto noticeDto = NoticeDto.valueOf(NoticeId.ARMY_GROUP_BEING_CHIEF, values);
			this.noticeService.pushNotice(playerId, noticeDto);
		} finally {
			chainLock.unlock();
		}
		ArmyGroupDto armyGroupDto = this.getArmyGroupDto(user, armyGroup);
		Result<ArmyGroupDto> result = Result.Success(armyGroupDto);
		return result;
	}

	@Override
	public Result<ArmyGroupDto> delateChiefAction(long playerId) {
		Player player = this.dbCachedService.get(playerId, Player.class);
		if (player == null) {
			return Result.Error(ArmyGroupResult.FAILURE);
		}
		ArmyGroupMember armyGroupMember = this.dbCachedService.get(playerId, 
				ArmyGroupMember.class);
		if (armyGroupMember == null || armyGroupMember.getArmyGroupId() == -1) {// 还没有加入军团
			return Result.Error(ArmyGroupResult.FAILURE);
		}
		ArmyGroup armyGroup = this.dbCachedService.get(
				armyGroupMember.getArmyGroupId(), ArmyGroup.class);
		if (armyGroup == null) {
			return Result.Error(ArmyGroupResult.FAILURE);
		}
		Player user = this.dbCachedService.get(armyGroup.getChief(), Player.class);
		if (user == null) {
			return Result.Error(ArmyGroupResult.FAILURE);
		}
		ArmyGroupMember armyGroupMember2 = this.dbCachedService.get(armyGroup.getChief(), 
				ArmyGroupMember.class);
		if (armyGroupMember2 == null || armyGroupMember2.getArmyGroupId() == -1) {// 还没有加入军团
			return Result.Error(ArmyGroupResult.FAILURE);
		}
		ChainLock chainLock = LockUtils.getLock(player, user, armyGroup, armyGroupMember, armyGroupMember2);
		chainLock.lock();
		try {
			ArmyGroupAuth armyGroupAuth = this.basedbService.get(ArmyGroupAuth.class, 
					armyGroupMember.getPositionId());
			if (armyGroupAuth == null || armyGroupAuth.getApplyChief() == 0) {// 没有弹劾的权限
				return Result.Error(ArmyGroupResult.HAD_NOT_AUTH);
			}
			// 判断团长是否很久没上线
			int offLineDays = this.gameRuleService.getAmountByID(GameRuleID.ARMY_GROUP_OFF_LINE_DAYS).intValue();
			Date now = new Date();
			int days = DateUtil.calc2DateTDOADays(user.getLoginTime(), now);
			if (days < offLineDays) {// 还未满足弹劾条件
				return Result.Error(ArmyGroupResult.CAN_NOT_DELATE);
			}
			// 互换职位
			int positionId = armyGroupMember.getPositionId();
			armyGroupMember.setPositionId(armyGroupMember2.getPositionId());
			this.dbCachedService.submitUpdated2Queue(playerId, ArmyGroupMember.class);
			armyGroupMember2.setPositionId(positionId);
			this.dbCachedService.submitUpdated2Queue(user.getId(), ArmyGroupMember.class);
			armyGroup.setChief(armyGroupMember.getId());
			this.dbCachedService.submitUpdated2Queue(armyGroup.getId(), ArmyGroup.class);
			// 发送邮件告知团长更换
			Map<String, Object> keyValues = new HashMap<String, Object>();
			keyValues.put(NoticeKey.ARMY_GROUP_NAME, armyGroup.getName());
			keyValues.put(NoticeKey.PLAYERNAME1, user.getPlayerName());
			keyValues.put(NoticeKey.PLAYERNAME2, player.getPlayerName());
			this.mailService.sendArmyGroupMail(playerId, -1, MailTemplateIds.DELATE_CHIEF, keyValues);
			// 发送成为团长公告
			Map<String, Object> values = new HashMap<String, Object>();
			values.put(NoticeKey.PLAYERNAME1, player.getPlayerName());
			NoticeDto noticeDto = NoticeDto.valueOf(NoticeId.ARMY_GROUP_BEING_CHIEF, values);
			this.noticeService.pushNotice(playerId, noticeDto);
		} finally {
			chainLock.unlock();
		}
		ArmyGroupDto armyGroupDto = this.getArmyGroupDto(player, armyGroup);
		ArmyGroupMemberDto armyGroupMemberDto = this.getArmyGroupMemberDto(player, armyGroupMember);
		Result<ArmyGroupDto> result = Result.Success(armyGroupDto);
		result.put("armyGroupMemberDto", armyGroupMemberDto);
		return result;
	}
	
	@Override
	public Result<ValueResultSet> buyGoodsAction(long playerId, int goodsId, int amount) {
		Player player = this.dbCachedService.get(playerId, Player.class);
		if (player == null) {
			return Result.Error(ArmyGroupResult.FAILURE);
		}
		if (amount <= 0) {
			return Result.Error(ArmyGroupResult.PARAM_ERROR);
		}
		ArmyGroupMember armyGroupMember = this.dbCachedService.get(playerId, 
				ArmyGroupMember.class);
		if (armyGroupMember == null || armyGroupMember.getArmyGroupId() == -1) {
			return Result.Error(ArmyGroupResult.FAILURE);
		}
		ValueResultSet valueResultSet = null;
		ArmyGroupMemberDto armyGroupMemberDto = null;
		ArmyGroupBuyRecord armyGroupBuyRecord = null;
		ChainLock chainLock = LockUtils.getLock(player, armyGroupMember);
		chainLock.lock();
		try {
			ArmyGroupStore armyGroupStore = this.basedbService.get(ArmyGroupStore.class, goodsId);
			if (armyGroupStore == null) {
				return Result.Error(ArmyGroupResult.BASE_DATA_NOT_EXIST);
			}
			if (armyGroupMember.getCurContribute() < armyGroupStore.getContribute() * amount) {// 贡献分不够
				return Result.Error(ArmyGroupResult.CONTRIBUTE_NO_ENOUGH);
			}
			int level = this.getArmyGroupLevel(armyGroupMember.getArmyGroupId());
			if (armyGroupStore.getLevel() > level) {
				return Result.Error(ArmyGroupResult.ARMY_GROUP_GOODS_NOT_OPEN);
			}
			if (armyGroupStore.getMaxBuyAmount() != -1) {// 每天购买数量有限制
				armyGroupBuyRecord = this.getArmyGroupRecord(playerId, goodsId);
				if (armyGroupBuyRecord == null) {
					return Result.Error(ArmyGroupResult.FAILURE);
				}
				Date now = new Date();
				if (CommonRule.isSameResetTime(armyGroupBuyRecord.getLastBuyTime())) {// 要刷新购买次数
					armyGroupBuyRecord.setAmount(0);
					armyGroupBuyRecord.setLastBuyTime(now);
					this.dbCachedService.submitUpdated2Queue(armyGroupBuyRecord.getId(), ArmyGroupBuyRecord.class);
				}
				if (armyGroupBuyRecord.getAmount() + amount > armyGroupStore.getMaxBuyAmount()) {// 购买次数上限
					return Result.Error(ArmyGroupResult.ARMY_GROUP_GOODS_BUY_AMOUNT_LIMIT);
				}
			}
			List<Reward> rewards = this.rewardService.parseRewards(playerId, armyGroupStore.getGoods(), true);
			if (amount > 1) {
				if (CollectionUtils.isNotEmpty(rewards)) {
					for (Reward reward: rewards) {
						reward.increase(reward.getCount() * (amount - 1));
					}
				}
			}
			RewardActionSet rewardActonSet = this.rewardService.tryRewards(playerId, rewards);
			if (rewardActonSet.isNotOK()) {
				return Result.Error(rewardActonSet.getResultCode());
			}
			if (armyGroupStore.getMaxBuyAmount() != -1) {// 增加购买数量
				armyGroupBuyRecord.setAmount(armyGroupBuyRecord.getAmount() + amount);
				this.dbCachedService.submitUpdated2Queue(armyGroupBuyRecord.getId(), ArmyGroupBuyRecord.class);
			}
			// 扣减贡献分
			armyGroupMember.setCurContribute(armyGroupMember.getCurContribute() - armyGroupStore.getContribute() * amount);
			this.dbCachedService.submitUpdated2Queue(playerId, ArmyGroupMember.class);
			valueResultSet = this.rewardService.executeRewards(playerId, rewardActonSet, 
					LogSource.ARMY_GROUP_BUY_GOODS);
		} finally {
			chainLock.unlock();
		}
		armyGroupMemberDto = getArmyGroupMemberDto(player, armyGroupMember);
		Result<ValueResultSet> result = Result.Success(valueResultSet);
		result.addContent("armyGroupMemberDto", armyGroupMemberDto);
		return result;
	}
	
	@Override
	public List<ArmyGroupBuildingDto> getArmyGroupBuildingsAction(long playerId) {
		List<ArmyGroupBuildingDto> result = null;
		ArmyGroupMember armyGroupMember = this.dbCachedService.get(playerId, ArmyGroupMember.class);
		if (armyGroupMember == null || armyGroupMember.getArmyGroupId() == -1) {
			return result;
		}
		result = getArmyGroupBuildingDtos(armyGroupMember.getArmyGroupId());
		return result;
	}

	@Override
	public List<ArmyGroupBuildingDto> getArmyGroupBuildingDtos(long armyGroupId) {
		List<ArmyGroupBuildingDto> result = null;
		List<ArmyGroupBuilding> armyGroupBuildings = this.getArmyGroupBuildings(armyGroupId);
		 if (CollectionUtils.isNotEmpty(armyGroupBuildings)) {
			 result = new ArrayList<ArmyGroupBuildingDto>();
			 for (ArmyGroupBuilding armyGroupBuilding: armyGroupBuildings) {
				 ArmyGroupBuildingDto armyGroupBuildingDto = ArmyGroupBuildingDto.valueOf(armyGroupBuilding);
				 result.add(armyGroupBuildingDto);
			 }
		 }
		return result;
	}
	
	@Override
	public Result<ValueResultSet> contributeHufuAction(long playerId, int buildingId, int useGold) {
		Player player = this.dbCachedService.get(playerId, Player.class);
		if (player == null) {
			return Result.Error(ArmyGroupResult.FAILURE);
		}
		ArmyGroupMember armyGroupMember = this.dbCachedService.get(playerId, ArmyGroupMember.class);
		if (armyGroupMember == null || armyGroupMember.getArmyGroupId() == -1) {
			return Result.Error(ArmyGroupResult.FAILURE);
		}
		ArmyGroup armyGroup = this.dbCachedService.get(armyGroupMember.getArmyGroupId(), ArmyGroup.class);
		if (armyGroup == null) {
			return Result.Error(ArmyGroupResult.FAILURE);
		}
		String key = ArmyGroupBuilding.getKey(armyGroup.getId(), buildingId);
		ArmyGroupBuilding armyGroupBuilding = this.dbCachedService.get(key, ArmyGroupBuilding.class);
		if (armyGroupBuilding == null) {
			return Result.Error(ArmyGroupResult.FAILURE);
		}
		int goldDiscount = 0;
		ArmyGroupDto armyGroupDto = null;
		ArmyGroupMemberDto armyGroupMemberDto = null;
		ValueResultSet valueResultSet = null;
		ArmyGroupContributeDto armyGroupContributeDto = null;
		ArmyGroupBuildingDto armyGroupBuildingDto = null;
		boolean upgrade = false;
		ChainLock chainLock = LockUtils.getLock(player, armyGroup, armyGroupBuilding);
		chainLock.lock();
		try {
			// 随机捐赠事件
			ArmyGroupContributeEvent armyGroupContributeEvent = this.ramdomArmyGroupContributeEvent();
			if (armyGroupContributeEvent == null) {
				return Result.Error(ArmyGroupResult.FAILURE);
			}
			int hufuItemId = this.gameRuleService.getAmountByID(GameRuleID.ARMY_GROUP_HU_FU_ITEM_ID).intValue();
			Item item = this.basedbService.get(Item.class, hufuItemId);
			if (item == null) {
				return Result.Error(ArmyGroupResult.BASE_DATA_NOT_EXIST);
			}
			int hufuAmount = this.itemService.getValidPlayerItemAmount(playerId, hufuItemId);
			SimpleReward goldReward = null;
			SimpleReward silverReward = null;
			ItemReward itemReward = null;
			if (useGold >= 0 && hufuAmount <=0) {// 没有虎符，自动购买
				if (useGold == 0) {// 用银元购买
					int silverCost = this.gameRuleService.getAmountByID(GameRuleID.ARMY_GROUP_BUY_HUFU_COST).intValue();
					silverReward = new SimpleReward(RewardType.SILVER, -silverCost);
				} else {// 用金币购买
					int goldCost = this.gameRuleService.getGoldById(GoldRuleID.ARMY_GROUP_BUY_HUFU_COST);
					int newGoldCost = this.vipService.getGoldDiscountValue(player, goldCost);
					goldDiscount = goldCost - newGoldCost;
					goldReward = new SimpleReward(RewardType.MONEY_MIX, -newGoldCost);
				}
			} else {// 判断虎符够不够
				itemReward = ItemReward.valueOf(hufuItemId, -1);
			}
			// 获得粮食
			int foods = RandomUtil.betweenValue(armyGroupContributeEvent.getMinFoods(), 
					armyGroupContributeEvent.getMaxFoods());
			SimpleReward foodsReward = null;
			if (foods > 0) {
				foodsReward = new SimpleReward(RewardType.FOODS, foods);
			}
			List<Reward> rewards = new ArrayList<Reward>();
			if (goldReward != null) {
				rewards.add(goldReward);
			}
			if (silverReward != null) {
				rewards.add(silverReward);
			}
			if (itemReward != null) {
				rewards.add(itemReward);
			}
			if (foodsReward != null) {
				rewards.add(foodsReward);
			}
			// 掉落
			int itemId = -1;
			int itemAmount = 0;
			DropResult dropResult = null;
			if (StringUtils.isNotBlank(armyGroupContributeEvent.getDrops())) {
				dropResult = this.dropService.doDrop(playerId, armyGroupContributeEvent.getDrops());
			}
			if (dropResult != null && CollectionUtils.isNotEmpty(dropResult.getRewardList())) {
				rewards.addAll(dropResult.getRewardList());
				Reward reward = dropResult.getRewardList().get(0);
				if (reward.getType() == RewardType.ITEM) {
					ItemReward tmpReward = (ItemReward) reward;
					itemId = tmpReward.getItemId();
					itemAmount = tmpReward.getCount();
				} else if (reward.getType() == RewardType.HERO_EQUIP) {
					HeroEquipReward tmpReward = (HeroEquipReward) reward;
					itemId = tmpReward.getEquipId();
					itemAmount = tmpReward.getCount();
				} else if (reward.getType() == RewardType.PLAYER_EQUIP) {
					PlayerEquipReward tmpReward = (PlayerEquipReward) reward;
					itemId = tmpReward.getEquipId();
					itemAmount = tmpReward.getCount();
				}
			}
			RewardActionSet rewardActonSet = this.rewardService.tryRewards(playerId, rewards);
			if (rewardActonSet.isNotOK()) {
				return Result.Error(rewardActonSet.getResultCode());
			}
			// 贡献值
			int contribute = RandomUtil.betweenValue(armyGroupContributeEvent.getMinContribute(), 
					armyGroupContributeEvent.getMaxContribute());
			// 建筑进度
			int progress = RandomUtil.betweenValue(armyGroupContributeEvent.getMinProgress(), 
					armyGroupContributeEvent.getMaxProgress());
			ArmyGroupBuildingUpgrade armyGroupBuildingUpgrade = this.basedbService.getByUnique(
					ArmyGroupBuildingUpgrade.class, IndexName.ARMY_GROUP_BUILDING_UPGRADE_INDEX, buildingId,
					armyGroupBuilding.getLevel());
			if (buildingId != ArmyGroupBuildingType.JUYI_HALL.ordinal() && armyGroupBuildingUpgrade != null && 
					armyGroupBuildingUpgrade.getProgress() != 0) {// 非聚义堂军团建筑还可以升级
				if (armyGroupBuilding.getProgress() + progress >= armyGroupBuildingUpgrade.getProgress()) {// 建筑升级
					int armyGoupLevel = this.getArmyGroupLevel(armyGroup.getId());
					if (armyGroupBuilding.getLevel() + 1 > armyGoupLevel) {// 不能超过军团等级
						return Result.Error(ArmyGroupResult.ARMY_GROUP_LEVEL_NO_ENOUGH);
					}
				}
			}
			
			valueResultSet = this.rewardService.executeRewards(playerId, rewardActonSet, 
					LogSource.ARMY_GROUP_CONTRIBUTE_HUFU);
			
			armyGroupMember.setCurContribute(armyGroupMember.getCurContribute() + contribute);
			armyGroupMember.setContribute(armyGroupMember.getContribute() + contribute);
			this.dbCachedService.submitUpdated2Queue(playerId, ArmyGroupMember.class);
			
			armyGroup.setWealth(armyGroup.getWealth() + contribute);
			this.dbCachedService.submitUpdated2Queue(armyGroup.getId(), ArmyGroup.class);
			
			if (armyGroupBuildingUpgrade != null && armyGroupBuildingUpgrade.getProgress() != 0) {// 军团建筑还可以升级
				if (armyGroupBuilding.getProgress() + progress >= armyGroupBuildingUpgrade.getProgress()) {// 建筑升级
					int tmp = armyGroupBuilding.getProgress() + progress - armyGroupBuildingUpgrade.getProgress();
					armyGroupBuilding.setProgress(tmp);
					armyGroupBuilding.setLevel(armyGroupBuilding.getLevel() + 1);
					// 如果是聚义堂，判断有没新的军团建筑开放（推送）
					if (buildingId == ArmyGroupBuildingType.JUYI_HALL.ordinal()) {
						this.getArmyGroupBuildings(armyGroupMember.getArmyGroupId());
						upgrade = true;
					}
				} else {// 增加完成度
					armyGroupBuilding.setProgress(armyGroupBuilding.getProgress() + progress);
				}
				this.dbCachedService.submitUpdated2Queue(key, ArmyGroupBuilding.class);
			}
			// 保存日志
			ArmyGroupContribute armyGroupContribute = saveContributeLog(playerId, armyGroup.getId(), 
					buildingId, armyGroupContributeEvent.getId(), progress, contribute, foods, itemId, itemAmount);
			
			// 发送公告
			//sendContributeNotice(buildingId, player, armyGroupContributeEvent, foods, itemId, contribute, progress);
			
			armyGroupContributeDto = this.getArmyGroupContributeDto(armyGroupContribute);
			armyGroupBuildingDto = ArmyGroupBuildingDto.valueOf(armyGroupBuilding);
		} finally {
			chainLock.unlock();
		}
		armyGroupMemberDto = getArmyGroupMemberDto(player, armyGroupMember);
		Result<ValueResultSet> result = Result.Success(valueResultSet);
		armyGroupDto = this.getArmyGroupDto(armyGroup.getId());
		result.addContent("armyGroupDto", armyGroupDto);
		result.addContent("armyGroupMemberDto", armyGroupMemberDto);
		result.addContent("armyGroupContributeDto", armyGroupContributeDto);
		result.addContent("armyGroupBuildingDto", armyGroupBuildingDto);
		result.addContent("goldDiscount", goldDiscount);
		if (upgrade) {
			result.addContent("armyGroupBuildingDtos", getArmyGroupBuildingDtos(armyGroup.getId()));
			ConcurrentHashSet<Long> userIds = this.getArmyGroupMemberIds(armyGroup.getId());
			if (CollectionUtils.isNotEmpty(userIds)) {
				for (Long userId : userIds) {
					this.taskBus.post(GuildEvent.valueOf(userId));
				}
			}
		}
		
		this.taskBus.post(GuildDonateEvent.valueOf(playerId));
		this.eventBus.post(ArmyGroupUpgradeEvent.valueOf(armyGroup.getId(), armyGroupDto.getLevel(),
				armyGroupBuilding.getProgress()));
		return result;
	}
	
	/**
	 * 保存捐赠日志
	 * @param playerId 玩家id
	 * @param armyGroupId 军团id
	 * @param buildingId 建筑id
	 * @param contributeEventId 捐赠事件id
	 * @param progress 进度
	 * @param contribute 捐赠数量
	 * @param foods 粮食
	 * @param itemId 道具id
	 * @param itemAmount 道具数量
	 * @return
	 */
	private ArmyGroupContribute saveContributeLog(long playerId, long armyGroupId, 
			int buildingId, int contributeEventId, int progress, int contribute, 
			int foods, int itemId, int itemAmount) {
		ArmyGroupContribute result = this.dbCachedService.submitNew2Queue(
				new ArmyGroupContribute(armyGroupId, playerId, buildingId, 
						contributeEventId, progress, contribute, foods, 
						itemId, itemAmount));
		this.updateArmyGroupContributeIdsCache(armyGroupId, result.getId(), true);
		
		LinkedHashSet<Long> ids = getArmyGroupContributeIds(armyGroupId);
		if (CollectionUtils.isNotEmpty(ids)) {
			int amount = this.gameRuleService.getAmountByID(
					GameRuleID.ARMY_GROUP_MAX_CONTRIBUTE_LOG_AMOUNT)
					.intValue();
			amount = Math.min(amount, 20);
			if (ids.size() > amount) {// 超过上限
				List<Long> delIds = new ArrayList<Long>();
				int size = ids.size() - amount;
				for (long id : ids) {
					delIds.add(id);
					dbCachedService.submitDeleted2Queue(id, ArmyGroupContribute.class);
					size--;
					if (size <= 0) {
						break;
					}
				}
				if (CollectionUtils.isNotEmpty(delIds)) {
					for (Long id : delIds) {
						updateArmyGroupContributeIdsCache(armyGroupId, id, false);
					}
				}
			}
		}
		return result;
	}

	/**
	 * 发送捐赠公告
	 * @param playerId
	 * @param buildingId
	 * @param player
	 * @param armyGroupContributeEvent
	 * @param foods
	 * @param itemId
	 * @param contribute
	 * @param progress
	 */
	public void sendContributeNotice(int buildingId,
			Player player, ArmyGroupContributeEvent armyGroupContributeEvent,
			int foods, int itemId, int contribute, int progress) {
		// 发送军团捐赠公告
		ArmyGroupBuildingOpen argArmyGroupBuildingOpen = this.basedbService.get(
				ArmyGroupBuildingOpen.class, buildingId);
		if (argArmyGroupBuildingOpen != null) {
			Map<String, Object> values = new HashMap<String, Object>();
			NoticeDto noticeDto = null;
			if (armyGroupContributeEvent.getId() == 1) {
				values.put(NoticeKey.PLAYERNAME1, player.getPlayerName());
				values.put(NoticeKey.BUILD_NAME, argArmyGroupBuildingOpen.getBuildingName());
				values.put(NoticeKey.NUMBER_1, progress);
				values.put(NoticeKey.NUMBER_2, contribute);
				noticeDto = NoticeDto.valueOf(NoticeId.ARMYGROUP_CONTRIBUTE1, values);
			} else if (armyGroupContributeEvent.getId() == 2) {
				values.put(NoticeKey.PLAYERNAME1, player.getPlayerName());
				values.put(NoticeKey.BUILD_NAME, argArmyGroupBuildingOpen.getBuildingName());
				values.put(NoticeKey.NUMBER_1, progress);
				values.put(NoticeKey.NUMBER_2, contribute);
				noticeDto = NoticeDto.valueOf(NoticeId.ARMYGROUP_CONTRIBUTE2, values);
			} else if (armyGroupContributeEvent.getId() == 3) {
				values.put(NoticeKey.PLAYERNAME1, player.getPlayerName());
				values.put(NoticeKey.BUILD_NAME, argArmyGroupBuildingOpen.getBuildingName());
				values.put(NoticeKey.NUMBER_1, progress);
				values.put(NoticeKey.NUMBER_2, contribute);
				values.put(NoticeKey.NUMBER_3, itemId);
				noticeDto = NoticeDto.valueOf(NoticeId.ARMYGROUP_CONTRIBUTE3, values);
			} else if (armyGroupContributeEvent.getId() == 4) {
				values.put(NoticeKey.PLAYERNAME1, player.getPlayerName());
				values.put(NoticeKey.BUILD_NAME, argArmyGroupBuildingOpen.getBuildingName());
				values.put(NoticeKey.NUMBER_1, progress);
				values.put(NoticeKey.NUMBER_2, contribute);
				values.put(NoticeKey.NUMBER_3, foods);
				noticeDto = NoticeDto.valueOf(NoticeId.ARMYGROUP_CONTRIBUTE4, values);
			} else if (armyGroupContributeEvent.getId() == 5) {
				values.put(NoticeKey.PLAYERNAME1, player.getPlayerName());
				values.put(NoticeKey.BUILD_NAME, argArmyGroupBuildingOpen.getBuildingName());
				values.put(NoticeKey.NUMBER_1, progress);
				values.put(NoticeKey.NUMBER_2, contribute);
				values.put(NoticeKey.NUMBER_3, foods);
				noticeDto = NoticeDto.valueOf(NoticeId.ARMYGROUP_CONTRIBUTE5, values);
			}
			if (noticeDto != null) {
				this.noticeService.pushNotice(player.getId(), noticeDto);
			}
		}
	}
	
	@Override
	public List<ArmyGroupContributeDto> getArmyGroupContributesAction(long playerId) {
		List<ArmyGroupContributeDto> result = null;
		ArmyGroupMember armyGroupMember = dbCachedService.get(playerId, ArmyGroupMember.class);
		if (armyGroupMember == null || armyGroupMember.getArmyGroupId() == -1) {
			return result;
		}
		ArmyGroup armyGroup = this.getArmyGroup(armyGroupMember.getArmyGroupId());
		if (armyGroup == null) {
			return result;
		}
		ChainLock chainLock = LockUtils.getLock(armyGroup);
		chainLock.lock();
		try {
			LinkedHashSet<Long> ids = getArmyGroupContributeIds(armyGroupMember.getArmyGroupId());
			if (CollectionUtils.isNotEmpty(ids)) {
				result = new ArrayList<ArmyGroupContributeDto>();
				for (long id : ids) {
					ArmyGroupContribute armyGroupContribute = 
							this.dbCachedService.get(id, ArmyGroupContribute.class);
					ArmyGroupContributeDto armyGroupContributeDto = 
							this.getArmyGroupContributeDto(armyGroupContribute);
					result.add(0, armyGroupContributeDto);
				}
			}
		} finally {
			chainLock.unlock();
		}
		return result;
	}
	
	@Override
	public List<ArmyGroupTechDto> getPlayerArmyGroupTechsAction(long playerId) {
		List<ArmyGroupTechDto> result = null;
		ArmyGroupMember armyGroupMember = this.dbCachedService.get(
				playerId, ArmyGroupMember.class);
		if (armyGroupMember == null || armyGroupMember.getArmyGroupId() == -1) {// 还没有加入军团
			return result;
		}
		result = new ArrayList<ArmyGroupTechDto>();
		for (ArmyGroupTechType armyGroupTechType: ArmyGroupTechType.values()) {
			ArmyGroupTech armyGroupTech = this.getArmyGroupTech(playerId, 
					armyGroupTechType.ordinal());
			if (armyGroupTech != null) {
				result.add(ArmyGroupTechDto.valueOf(armyGroupTech));
			}
		}
		return result;
	}
	
	@Override
	public Result<ArmyGroupMemberDto> upgradeArmyGroupTechAction(long playerId, int techId) {
		Player player = this.dbCachedService.get(playerId, Player.class);
		if (player == null) {
			return Result.Error(TechResult.FAILURE);
		}
		ArmyGroupMember armyGroupMember = this.dbCachedService.get(playerId, ArmyGroupMember.class);
		if (armyGroupMember == null || armyGroupMember.getArmyGroupId() == -1) {
			return Result.Error(ArmyGroupResult.FAILURE);
		}
		ArmyGroupTechType armyGroupTechType = EnumUtils.getEnum(ArmyGroupTechType.class, techId);
		if (armyGroupTechType == null || armyGroupTechType == ArmyGroupTechType.NONE) {
			return Result.Error(ArmyGroupResult.PARAM_ERROR);
		}
		ChainLock chainLock = LockUtils.getLock(player, armyGroupMember);
		chainLock.lock();
		try {
			ArmyGroupTech armyGroupTech = this.getArmyGroupTech(playerId, techId);
			if (armyGroupTech == null) {
				return Result.Error(ArmyGroupResult.FAILURE);
			}
			ArmyGroupTechUpgrade armyGroupTechUpgrade = this.basedbService.getByUnique(ArmyGroupTechUpgrade.class, 
					IndexName.ARMY_GROUP_TECH_UPGRADE_INDEX, armyGroupTech.getTechId(), armyGroupTech.getLevel());
			if (armyGroupTechUpgrade == null) {
				return Result.Error(ArmyGroupResult.BASE_DATA_NOT_EXIST);
			}
			if (armyGroupTechUpgrade.getContribute() <= 0) {
				return Result.Error(ArmyGroupResult.TECH_LEVEL_LIMIT);
			}
			// 判断贡献是否足够
			if (armyGroupMember.getCurContribute() < armyGroupTechUpgrade.getContribute()) {
				return Result.Error(ArmyGroupResult.CONTRIBUTE_NO_ENOUGH);
			}
			// 扣减捐献分
			armyGroupMember.setCurContribute(armyGroupMember.getCurContribute() - armyGroupTechUpgrade.getContribute());
			this.dbCachedService.submitUpdated2Queue(playerId, ArmyGroupMember.class);
			// 科技升级
			armyGroupTech.setLevel(armyGroupTech.getLevel() + 1);
			this.dbCachedService.submitUpdated2Queue(armyGroupTech.getId(), ArmyGroupTech.class);
			// 更新军团科技属性
			this.heroService.refreshLineupHerosAttr(playerId, HeroAttrSetType.ARMY_GROUP_TECH);
			// 刷新玩家属性
			this.playerService.refreshAttr(playerId, PlayerAttrType.HEROS);
			// 推送玩家属性刷新
			this.pushHelper.pushPlayerAttrRefresh(playerId, this.playerService.getPlayerDto(player));
			// 抛军团科技升级事件
			this.eventBus.post(ArmyGroupTechUpdateEvent.valueOf(playerId));
		} finally {
			chainLock.unlock();
		}
		
		// 粮草总产量事件
		if (armyGroupTechType == ArmyGroupTechType.PLANT) {
			this.taskBus.post(FoodsOutputEvent.valueOf(playerId));
		}
		// 银元总产量事件
		if (armyGroupTechType == ArmyGroupTechType.REVUNUE) {
			this.taskBus.post(SilverOutputEvent.valueOf(playerId));
		}
		
		ArmyGroupMemberDto armyGroupMemberDto = this.getArmyGroupMemberDto(player, armyGroupMember);
		Result<ArmyGroupMemberDto> result = Result.Success(armyGroupMemberDto);
		return result;
	}
	
	@Override
	public RoleAttr getArmyGroupTechAttr(long playerId) {
		ArmyGroupMember armyGroupMember = this.dbCachedService.get(playerId, ArmyGroupMember.class);
		if (armyGroupMember == null || armyGroupMember.getArmyGroupId() == -1) {// 没有加入军团的时候不生效
			return new RoleAttr();
		}
		ArmyGroupTech charmArmyGroupTech = this.getArmyGroupTech(playerId, ArmyGroupTechType.CHARM.ordinal());
		ArmyGroupTech brainsArmyGroupTech = this.getArmyGroupTech(playerId, ArmyGroupTechType.BRAINS.ordinal());
		ArmyGroupTech commandArmyGroupTech = this.getArmyGroupTech(playerId, ArmyGroupTechType.COMMAND.ordinal());
		ArmyGroupTech powerArmyGroupTech = this.getArmyGroupTech(playerId, ArmyGroupTechType.POWER.ordinal());
		ArmyGroupTech skillPowerArmyGroupTech = this.getArmyGroupTech(playerId, ArmyGroupTechType.SKILLPOWER.ordinal());
		ArmyGroupTechUpgrade brainsTech = null;
		if (brainsArmyGroupTech != null) {
			brainsTech = this.basedbService.getByUnique(ArmyGroupTechUpgrade.class, IndexName.ARMY_GROUP_TECH_UPGRADE_INDEX, 
					brainsArmyGroupTech.getTechId(), brainsArmyGroupTech.getLevel());
		}
		ArmyGroupTechUpgrade charmTech = null;
		if (charmArmyGroupTech != null) {
			charmTech = this.basedbService.getByUnique(ArmyGroupTechUpgrade.class, IndexName.ARMY_GROUP_TECH_UPGRADE_INDEX, 
					charmArmyGroupTech.getTechId(), charmArmyGroupTech.getLevel());
		}
		ArmyGroupTechUpgrade commandTech = null;
		if (commandArmyGroupTech != null) {
			commandTech = this.basedbService.getByUnique(ArmyGroupTechUpgrade.class, IndexName.ARMY_GROUP_TECH_UPGRADE_INDEX, 
					commandArmyGroupTech.getTechId(), commandArmyGroupTech.getLevel());
		}
		ArmyGroupTechUpgrade powerTech = null;
		if (powerArmyGroupTech != null) {
			powerTech= this.basedbService.getByUnique(ArmyGroupTechUpgrade.class, IndexName.ARMY_GROUP_TECH_UPGRADE_INDEX, 
					powerArmyGroupTech.getTechId(), powerArmyGroupTech.getLevel());
		}
		ArmyGroupTechUpgrade skillPowerTech = null;
		if (skillPowerArmyGroupTech != null) {
			skillPowerTech = this.basedbService.getByUnique(ArmyGroupTechUpgrade.class, IndexName.ARMY_GROUP_TECH_UPGRADE_INDEX, 
					skillPowerArmyGroupTech.getTechId(), skillPowerArmyGroupTech.getLevel());
		}
		RoleAttr result = new RoleAttr(powerTech, brainsTech, charmTech, skillPowerTech, commandTech);
		return result;
	}
	
	@Override
	public double getArmyGroupTechAttr(long playerId, ArmyGroupTechType armyGroupTechType) {
		double result = 0.0;
		ArmyGroupMember armyGroupMember = this.dbCachedService.get(playerId, ArmyGroupMember.class);
		if (armyGroupMember == null || armyGroupMember.getArmyGroupId() == -1) {// 没有加入军团的时候不生效
			return result;
		}
		if (armyGroupTechType == ArmyGroupTechType.PLANT || armyGroupTechType == ArmyGroupTechType.REVUNUE ||
				armyGroupTechType == ArmyGroupTechType.BUILD || armyGroupTechType == ArmyGroupTechType.SCIENCE) {
			ArmyGroupTech armyGroupTech = this.getArmyGroupTech(playerId, armyGroupTechType.ordinal());
			if (armyGroupTech != null) {
				ArmyGroupTechUpgrade armyGroupTechUpgrade = this.basedbService.getByUnique(ArmyGroupTechUpgrade.class, 
						IndexName.ARMY_GROUP_TECH_UPGRADE_INDEX, armyGroupTechType.ordinal(), armyGroupTech.getLevel());
				if (armyGroupTechUpgrade != null) {
					result = armyGroupTechUpgrade.getValue();
				}
			}
		}
		return result;
	}
	
	@Override
	public ArmyGroupDto getArmyGroupDtoAction(long playerId) {
		Player player = this.dbCachedService.get(playerId, Player.class);
		if (player == null) {
			return null;
		}
		return this.getArmyGroupDto(player);
	}
	
	@Override
	public List<ArmyGroupMemberDto> getArmyGroupMemberDtos(long armyGroupId) {
		List<ArmyGroupMemberDto> result = null;
		ConcurrentHashSet<Long> ids = this.getArmyGroupMemberIds(armyGroupId);
		if (CollectionUtils.isNotEmpty(ids)) {
			result = new ArrayList<ArmyGroupMemberDto>();
			for (long memberId: ids) {
				ArmyGroupMember armyGroupMember = this.dbCachedService.get(
						memberId, ArmyGroupMember.class);
				if (armyGroupMember != null) {
					Player user = this.dbCachedService.get(memberId, Player.class);
					ArmyGroupMemberDto armyGroupMemberDto = 
							this.getArmyGroupMemberDto(user, armyGroupMember);
					result.add(armyGroupMemberDto);
				}
			}
		}
		return result;
	}
	
	@Override
	public Result<ValueResultSet> clearCoolTimeAction(long playerId) {
		Player player = this.dbCachedService.get(playerId, Player.class);
		if (player == null) {
			return Result.Error(ArmyGroupResult.FAILURE);
		}
		ArmyGroupMember armyGroupMember = null;
		ValueResultSet valueResultSet = null;
		ArmyGroupMemberDto armyGroupMemberDto = null;
		int freeGold = 0;
		ChainLock chainLock = LockUtils.getLock(player);
		chainLock.lock();
		try {
			armyGroupMember = this.dbCachedService.get(playerId, ArmyGroupMember.class);
			if (armyGroupMember == null) {
				return Result.Error(ArmyGroupResult.NO_COOLING);
			}
			int coolSeconds = this.gameRuleService.getAmountByID(GameRuleID.ARMY_GROUP_QUIT_JOIN_COOL_TIME).intValue();
			Date coolTime = DateUtils.addMilliseconds(armyGroupMember.getQuitTime(), coolSeconds * 1000);
			Date now = new Date();
			if (coolTime.before(now)) {// 没有在冷却中
				return Result.Error(ArmyGroupResult.NO_COOLING);
			}
			int goldCost = 0;
			Vip vip = this.basedbService.get(Vip.class, player.getVipAndTmpVipLevel());
			int tmpCostGold = this.gameRuleService.getGoldById(GoldRuleID.ARMY_GROUP_CLERA_COOL_TIME_COST);
			goldCost = this.vipService.getVipValue(tmpCostGold, vip.getClearArmyGroupCoolTime());
			freeGold += tmpCostGold - goldCost;
			if (goldCost > 0) {
				SimpleReward goldReward = new SimpleReward(RewardType.MONEY_MIX, -goldCost);
				RewardActionSet rewardActonSet = this.rewardService.tryRewards(playerId, goldReward);
				if (rewardActonSet.isNotOK()) {
					return Result.Error(rewardActonSet.getResultCode());
				}
				valueResultSet = this.rewardService.executeRewards(playerId, rewardActonSet, 
						LogSource.ARMY_GROUP_CLEAR_COOL_TIME);
			}
			armyGroupMember.setQuitTime(DateUtils.addMilliseconds(now, -coolSeconds * 1000));
			this.dbCachedService.submitUpdated2Queue(playerId, ArmyGroupMember.class);
		} finally {
			chainLock.unlock();
		}
		armyGroupMemberDto = this.getArmyGroupMemberDto(player, armyGroupMember);
		Result<ValueResultSet> result = Result.Success(valueResultSet);
		result.addContent("armyGroupMemberDto", armyGroupMemberDto);
		if (freeGold > 0) {
			result.addContent("freeGold", freeGold);
		}
		return result;
	}
	
	@Override
	public int renameAction(long playerId, String content) {
		Player player = this.dbCachedService.get(playerId, Player.class);
		if (player == null) {
			return ArmyGroupResult.FAILURE;
		}
		ArmyGroupMember armyGroupMember = this.dbCachedService.get(
				playerId, ArmyGroupMember.class);
		if (armyGroupMember == null || armyGroupMember.getArmyGroupId() == -1) {// 还没有加入军团
			return ArmyGroupResult.FAILURE;
		}
		ArmyGroup armyGroup = this.dbCachedService.get(
				armyGroupMember.getArmyGroupId(), ArmyGroup.class);
		if (armyGroup == null) {
			return ArmyGroupResult.FAILURE;
		}
		ChainLock chainLock = LockUtils.getLock(player, armyGroup, armyGroupMember);
		chainLock.lock();
		try {
			if (armyGroupMember.getPositionId() != ArmyGroupPositionType.CHIEF) {// 没有修改公告的权限
				return ArmyGroupResult.HAD_NOT_AUTH;
			}
			if (armyGroup.getMustRename() == 0) {// 不能改名
				return ArmyGroupResult.HAD_NOT_AUTH;
			}
			ArmyGroup newArmyGroup = this.getArmyGroup(content);
			if (newArmyGroup != null) {// 军团名称已经存在
				return ArmyGroupResult.ARMY_GROUP_NAME_HAD_EXISTS;
			}
			armyGroup.setName(content);
			armyGroup.setMustRename(0);
			this.dbCachedService.submitUpdated2Queue(armyGroup.getId(), ArmyGroup.class);
		} finally {
			chainLock.unlock();
		}
		return ArmyGroupResult.SUCCESS;
	}
	
	/**
	 * 返回军团科技对象
	 * @param playerId 玩家id
	 * @param techId 科技id
	 * @return
	 */
	private ArmyGroupTech getArmyGroupTech(long playerId, int techId) {
		if (techId <= ArmyGroupTechType.NONE.ordinal()) {
			return null;
		}
		String key = ArmyGroupTech.getKey(playerId, techId);
		ArmyGroupTech result = this.dbCachedService.get(key, ArmyGroupTech.class);
		if (result == null) {
			result = this.dbCachedService.submitNew2Queue(new ArmyGroupTech(
					playerId, techId));
		}
		return result;
	}
	
	private ArmyGroupContributeDto getArmyGroupContributeDto(ArmyGroupContribute 
			armyGroupContribute) {
		ArmyGroupContributeDto armyGroupContributeDto = new ArmyGroupContributeDto();
		BeanUtil.copyProperties(armyGroupContribute, armyGroupContributeDto);
		Player user = this.dbCachedService.get(armyGroupContribute.getPlayerId(), Player.class);
		armyGroupContributeDto.setPlayerName(user.getPlayerName());
		return armyGroupContributeDto;
	}
	
	/**
	 * 随机捐赠事件
	 * @return
	 */
	private ArmyGroupContributeEvent ramdomArmyGroupContributeEvent() {
		ArmyGroupContributeEvent result = null;
		List<ArmyGroupContributeEvent> armyGroupContributeEvents = 
				this.basedbService.listAll(ArmyGroupContributeEvent.class);
		if (CollectionUtils.isEmpty(armyGroupContributeEvents)) {
			return result;
		}
		ArmyGroupContributeEvent armyGroupContributeEvent1 = armyGroupContributeEvents.get(0);
		int divinationRate = RandomUtils.nextInt(armyGroupContributeEvent1.getTotalRate() + 1);
		int currValue = 0;
		for (ArmyGroupContributeEvent armyGroupContributeEvent: armyGroupContributeEvents) {
			currValue += armyGroupContributeEvent.getRate();
			if (divinationRate <= currValue) {
				result = armyGroupContributeEvent;
				break;
			}
		}
		return result;
	}
	
	/**
	 * 获取军团商城商品购买记录
	 * @param playerId 玩家id
	 * @param goodsId 商品id
	 * @return
	 */
	private ArmyGroupBuyRecord getArmyGroupRecord(long playerId, int goodsId) {
		String key = ArmyGroupBuyRecord.getKey(playerId, goodsId);
		ArmyGroupBuyRecord result = this.dbCachedService.get(key, ArmyGroupBuyRecord.class);
		if (result == null) {
			result = this.dbCachedService.submitNew2Queue(new ArmyGroupBuyRecord(playerId, 
					goodsId));
		}
		return result;
	}
	
	private ArmyGroupDto getArmyGroupDto(Player player, ArmyGroup armyGroup) {
		int armyGroupLevel = this.getArmyGroupLevel(armyGroup.getId());
		ArmyGroupDto result = ArmyGroupDto.valueOf(player, armyGroup, armyGroupLevel, 
				this.getArmyGroupMemberAmount(armyGroup.getId()));
		return result;
	}
	
	@Override
	public int getPlayerArmyGroupLevel(long playerId) {
		int result = 0;
		Player player = this.dbCachedService.get(playerId, Player.class);
		if (player != null) {
			ArmyGroupDto armyGroupDto = this.getArmyGroupDto(player);
			if (armyGroupDto != null) {
				result = armyGroupDto.getLevel();
			}
		}
		return result;
	}
	
	@Override
	public void pushNewMail(long armyGroupId) {
		ConcurrentHashSet<Long> ids = this.getArmyGroupMemberIds(armyGroupId);
		if (CollectionUtils.isNotEmpty(ids)) {
			this.pushHelper.pushNewMail(ids);
		}
	}
	
	@Override
	public boolean canReceiveMail(long playerId, long armyGroupId, Date mailSendTime) {
		boolean result = false;
		ArmyGroupMember armyGroupMember = this.dbCachedService.get(playerId, ArmyGroupMember.class);
		if (armyGroupMember != null && armyGroupMember.getArmyGroupId() == armyGroupId && 
				armyGroupMember.getJoinTime().before(mailSendTime)) {
			result = true;
		}
		return result;
	}
	//------------------------------------------------------------------------------
	
	@Override
	public double getKungFuSchoolHpAddRate(long armyGroupId) {
		double result = 0.0;
		int level = this.getArmyGroupBuildingLevel(armyGroupId, ArmyGroupBuildingType.KUNGFU_SCHOOL.ordinal());
		ArmyGroupBuildingUpgrade armyGroupBuildingUpgrade = this.basedbService.getByUnique(
				ArmyGroupBuildingUpgrade.class, IndexName.ARMY_GROUP_BUILDING_UPGRADE_INDEX, 
				ArmyGroupBuildingType.KUNGFU_SCHOOL.ordinal(), level);
		if (armyGroupBuildingUpgrade != null) {
			result = armyGroupBuildingUpgrade.getValue();
		}
		return result;
	}
	
	/**
	 * 获取军团等级
	 * @param armyGroupId 军团id
	 * @return
	 */
	private int getArmyGroupLevel(long armyGroupId) {
		return this.getArmyGroupBuildingLevel(armyGroupId, ArmyGroupBuildingType.JUYI_HALL.ordinal());
	}
	
	/**
	 * 获取军团建筑等级
	 * @param armyGroupId 军团id
	 * @param buildingId 军团建筑id
	 * @return
	 */
	@Override
	public int getArmyGroupBuildingLevel(long armyGroupId, int buildingId) {
		int result = -1;
		String key = ArmyGroupBuilding.getKey(armyGroupId, buildingId);
		ArmyGroupBuilding armyGroupBuilding = this.dbCachedService.get(key, 
				ArmyGroupBuilding.class);
		if (armyGroupBuilding != null) {
			result = armyGroupBuilding.getLevel();
		}
		return result;
	}
	
	/**
	 * 返回军团建筑列表
	 * @param armyGroupId 军团id
	 * @return
	 */
	private List<ArmyGroupBuilding> getArmyGroupBuildings(long armyGroupId) {
		List<ArmyGroupBuilding> result = null;
		List<ArmyGroupBuildingOpen> buildings = this.armyGroupBuildingBasedbService.getBuildings();
		if (CollectionUtils.isNotEmpty(buildings)) {
			result = new ArrayList<ArmyGroupBuilding>();
			for (int i = 0; i < buildings.size(); i++) {
				ArmyGroupBuildingOpen building = buildings.get(i);
				if (building.getId() == ArmyGroupBuildingType.JUYI_HALL.ordinal()) {
					ArmyGroupBuilding armyGroupBuilding = this.addPlayerBuilding(
							armyGroupId, building.getId(), building.getInitLevel());
					result.add(armyGroupBuilding);
				} else {
					int level = this.getArmyGroupLevel(armyGroupId);
					if (building.getOpenLevel() <= level) {
						ArmyGroupBuilding armyGroupBuilding = this.addPlayerBuilding(
								armyGroupId, building.getId(), building.getInitLevel());
						result.add(armyGroupBuilding);
					}
				}
			}
		}
		return result;
	}
	
	/**
	 * 添加军团建筑
	 * @param armyGroupId 军团id
	 * @param buildingId 军团建筑id
	 */
	private ArmyGroupBuilding addPlayerBuilding(long armyGroupId, int buildingId,
			int initLevel) {
		String key = ArmyGroupBuilding.getKey(armyGroupId, buildingId);
		ArmyGroupBuilding result = this.dbCachedService.get(key, ArmyGroupBuilding.class);
		if (result == null) {
			result = this.dbCachedService.submitNew2Queue(new ArmyGroupBuilding(
					armyGroupId, buildingId, initLevel));
		}
		return result;
	}
	
	/**
	 * 创建新的军团
	 * @param playerId 玩家id
	 * @param name 军团名称
	 * @return
	 */
	private synchronized ArmyGroup createArmyGroup(long playerId, String name) {
		ArmyGroup result = this.getArmyGroup(name);
		if (result == null) {
			result = this.dbCachedService.submitNew2Queue(new ArmyGroup(playerId, name));
			// 创建军团建筑
			this.getArmyGroupBuildings(result.getId());
		}
		return result;
	}
	
	/**
	 * 返回军团捐献id列表缓存Key
	 * @return
	 */
	private String getArmyGroupContributeIdCacheKey(long armyGroupId) {
		StringBuilder buf = new StringBuilder();
		buf.append(ArmyGroupCmd.MODULE_NAME).append("_CONTRIBUTE");
		buf.append(armyGroupId);
		return buf.toString();
	}
	
	/** 
	 * 返回军团捐献id列表缓存
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private LinkedHashSet<Long> getArmyGroupContributeIds(long armyGroupId) {
		String idKey = this.getArmyGroupContributeIdCacheKey(armyGroupId);
		LinkedHashSet<Long> ids = 
				(LinkedHashSet<Long>) this.dbCachedService.getFromCommonCache(idKey);
		if (ids == null) {
			DetachedCriteria criteria = DetachedCriteria.forClass(ArmyGroupContribute.class)
									.add(Restrictions.eq("armyGroupId", armyGroupId))
									.addOrder(Order.asc("contributeTime"))
									.setProjection(Projections.id());
			List<Long> list = this.commonManager.getCommonQueryResult(criteria, -1, -1);
			if (list != null && list.size() > 0) {
				ids = new LinkedHashSet<Long>(list);
			} else {
				ids = new LinkedHashSet<Long>();
			}
			this.dbCachedService.put2CommonCacheIfAbsent(idKey, ids);
			ids = (LinkedHashSet<Long>) this.dbCachedService.getFromCommonCache(idKey);
		}
		return ids;
	}
	
	/**
	 * 更新军团捐献id列表缓存
	 * @param armyGroupId 军团id
	 * @param id 捐献id
	 * @param isAdd 是否添加
	 */
	private void updateArmyGroupContributeIdsCache(long armyGroupId, long id, boolean isAdd) {
		LinkedHashSet<Long> ids = this.getArmyGroupContributeIds(armyGroupId);
		if (ids != null) {
			if (isAdd) {
				ids.add(id);
			} else {
				ids.remove(id);
			}
		} else {
			if (isAdd) {
				ids = new LinkedHashSet<Long>();
				ids.add(id);
				String idKey = this.getArmyGroupContributeIdCacheKey(armyGroupId);
				this.dbCachedService.put2CommonCache(idKey, ids);
			}
		}
	}
	
	/**
	 * 返回军团id列表缓存Key
	 * @return
	 */
	private String getArmyGroupIdCacheKey() {
		StringBuilder buf = new StringBuilder();
		buf.append(ArmyGroupCmd.MODULE_NAME);
		return buf.toString();
	}
	
	/** 返回军团id列表缓存
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private ConcurrentHashSet<Long> getArmyGroupIds() {
		ConcurrentHashSet<Long> ids = null;
		String idKey = this.getArmyGroupIdCacheKey();
		ids = (ConcurrentHashSet<Long>) this.dbCachedService.getFromCommonCache(idKey);
		if (ids == null) {
			DetachedCriteria dc = DetachedCriteria.forClass(ArmyGroup.class)
													.setProjection(Projections.id());
			ids = this.dbCachedService.getCachedQueryResult(idKey, dc, -1, -1);
		}
		return ids;
	}
	
	/**
	 * 更新军团id列表缓存
	 * @param armyGroupId 军团id
	 * @param isAdd 是否添加
	 */
	private void updateArmyGroupIdsCache(Long armyGroupId, boolean isAdd) {
		ConcurrentHashSet<Long> ids = this.getArmyGroupIds();
		if (ids != null) {
			if (isAdd) {
				ids.add(armyGroupId);
			} else {
				ids.remove(armyGroupId);
			}
		} else {
			if (isAdd) {
				ids = new ConcurrentHashSet<Long>();
				ids.add(armyGroupId);
				String idKey = this.getArmyGroupIdCacheKey();
				this.dbCachedService.put2CommonCache(idKey, ids);
			}
		}
	}
	
	/**
	 * 获取军团申请列表
	 * @param id 军团id
	 * @return
	 */
	private List<ArmyGroupApply> getArmyGroupApplys(long id) {
		List<ArmyGroupApply> result = null;
		ConcurrentHashSet<Long> ids = this.getArmyGroupApplyIds(id);
		if (CollectionUtils.isNotEmpty(ids)) {
			result = new ArrayList<ArmyGroupApply>();
			for (long applyId: ids) {
				ArmyGroupApply armyGroupApply = this.dbCachedService.get(
						applyId, ArmyGroupApply.class);
				if (armyGroupApply != null) {
					result.add(armyGroupApply);
				}
			}
		}
		return result;
	}
	
	/**
	 * 返回军团申请列表缓存Key
	 * @param id 军团id
	 * @return
	 */
	private String getArmyGroupApplyIdCacheKey(long id) {
		StringBuilder buf = new StringBuilder(ArmyGroupCmd.MODULE_NAME);
		buf.append("_APPLY").append(id);
		return buf.toString();
	}
	
	/** 
	 * 返回军团申请列表缓存
	 * @param id 军团id
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private ConcurrentHashSet<Long> getArmyGroupApplyIds(long id) {
		ConcurrentHashSet<Long> ids = null;
		String idKey = this.getArmyGroupApplyIdCacheKey(id);
		ids = (ConcurrentHashSet<Long>) this.dbCachedService.getFromCommonCache(idKey);
		if (ids == null) {
			DetachedCriteria dc = DetachedCriteria.forClass(ArmyGroupApply.class)
													.add(Restrictions.eq("armyGroupId", id))
													.setProjection(Projections.id());
			ids = this.dbCachedService.getCachedQueryResult(idKey, dc, -1, -1);
		}
		return ids;
	}
	
	/**
	 * 更新军团申请列表缓存
	 * @param id 军团id
	 * @param applyId 申请id
	 * @param isAdd 是否添加
	 */
	private void updateArmyGroupApplyIdsCache(long id, Long applyId, boolean isAdd) {
		ConcurrentHashSet<Long> ids = this.getArmyGroupApplyIds(id);
		if (ids != null) {
			if (isAdd) {
				ids.add(applyId);
			} else {
				ids.remove(applyId);
			}
		} else {
			if (isAdd) {
				ids = new ConcurrentHashSet<Long>();
				ids.add(applyId);
				String idKey = this.getArmyGroupApplyIdCacheKey(id);
				this.dbCachedService.put2CommonCache(idKey, ids);
			}
		}
	}
	
	/**
	 * 获取申请的次数
	 * @param playerId 申请人id
	 * @return
	 */
	private int getApplyTimes(long playerId) {
		int result = 0;
		ConcurrentHashSet<Long> ids = this.getApplyIds(playerId);
		if (CollectionUtils.isNotEmpty(ids)) {
			result = ids.size();
		}
		return result;
	}
	
	/**
	 * 获取申请列表
	 * @param playerId 申请人id
	 * @return
	 */
	private List<ArmyGroupApply> getApplys(long playerId) {
		List<ArmyGroupApply> result = null;
		ConcurrentHashSet<Long> ids = this.getApplyIds(playerId);
		if (CollectionUtils.isNotEmpty(ids)) {
			result = new ArrayList<ArmyGroupApply>();
			for (long applyId: ids) {
				ArmyGroupApply armyGroupApply = this.dbCachedService.get(
						applyId, ArmyGroupApply.class);
				if (armyGroupApply != null) {
					result.add(armyGroupApply);
				}
			}
		}
		return result;
	}
	
	/**
	 * 返回申请列表缓存Key
	 * @param playerId 申请人id
	 * @return
	 */
	private String getApplyIdCacheKey(long playerId) {
		StringBuilder buf = new StringBuilder();
		buf.append("APPLY_").append(ArmyGroupCmd.MODULE_NAME).append(playerId);
		return buf.toString();
	}
	
	/** 
	 * 返回申请列表缓存
	 * @param playerId 申请人id
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private ConcurrentHashSet<Long> getApplyIds(long playerId) {
		ConcurrentHashSet<Long> ids = null;
		String idKey = this.getApplyIdCacheKey(playerId);
		ids = (ConcurrentHashSet<Long>) this.dbCachedService.getFromCommonCache(idKey);
		if (ids == null) {
			DetachedCriteria dc = DetachedCriteria.forClass(ArmyGroupApply.class)
													.add(Restrictions.eq("playerId", playerId))
													.setProjection(Projections.id());
			ids = this.dbCachedService.getCachedQueryResult(idKey, dc, -1, -1);
		}
		return ids;
	}
	
	/**
	 * 更新申请列表缓存
	 * @param playerId 申请人id
	 * @param applyId 申请id
	 * @param isAdd 是否添加
	 */
	private void updateApplyIdsCache(long playerId, Long applyId, boolean isAdd) {
		ConcurrentHashSet<Long> ids = this.getApplyIds(playerId);
		if (ids != null) {
			if (isAdd) {
				ids.add(applyId);
			} else {
				ids.remove(applyId);
			}
		} else {
			if (isAdd) {
				ids = new ConcurrentHashSet<Long>();
				ids.add(applyId);
				String idKey = this.getArmyGroupMemberIdCacheKey(playerId);
				this.dbCachedService.put2CommonCache(idKey, ids);
			}
		}
	}
	
	/**
	 * 获取军团成员人数
	 * @param id 军团id
	 * @return
	 */
	private int getArmyGroupMemberAmount(long id) {
		int result = 0;
		ConcurrentHashSet<Long> ids = this.getArmyGroupMemberIds(id);
		if (CollectionUtils.isNotEmpty(ids)) {
			result = ids.size();
		}
		return result;
	}
	
	/**
	 * 获取军团成员列表
	 * @param id 军团id
	 * @return
	 */
	private List<ArmyGroupMember> getArmyGroupMembers(long id) {
		List<ArmyGroupMember> result = null;
		ConcurrentHashSet<Long> ids = this.getArmyGroupMemberIds(id);
		if (CollectionUtils.isNotEmpty(ids)) {
			result = new ArrayList<ArmyGroupMember>();
			for (long memberId: ids) {
				ArmyGroupMember armyGroupMember = this.dbCachedService.get(
						memberId, ArmyGroupMember.class);
				if (armyGroupMember != null) {
					result.add(armyGroupMember);
				}
			}
		}
		return result;
	}
	
	/**
	 * 返回军团成员列表缓存Key
	 * @param id 军团id
	 * @return
	 */
	private String getArmyGroupMemberIdCacheKey(long id) {
		StringBuilder buf = new StringBuilder();
		buf.append(ArmyGroupCmd.MODULE_NAME).append(id);
		return buf.toString();
	}
	
	/** 返回军团成员列表缓存
	 * @param id 军团id
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private ConcurrentHashSet<Long> getArmyGroupMemberIds(long id) {
		ConcurrentHashSet<Long> ids = null;
		String idKey = this.getArmyGroupMemberIdCacheKey(id);
		ids = (ConcurrentHashSet<Long>) this.dbCachedService.getFromCommonCache(idKey);
		if (ids == null) {
			DetachedCriteria dc = DetachedCriteria.forClass(ArmyGroupMember.class)
													.add(Restrictions.eq("armyGroupId", id))
													.setProjection(Projections.id());
			ids = this.dbCachedService.getCachedQueryResult(idKey, dc, -1, -1);
		}
		return ids;
	}
	
	/**
	 * 更新军团成员列表缓存
	 * @param id 军团id
	 * @param memberId 军团成员id
	 * @param isAdd 是否添加
	 */
	private void updateArmyGroupMemberIdsCache(long id, Long memberId, boolean isAdd) {
		ConcurrentHashSet<Long> ids = this.getArmyGroupMemberIds(id);
		if (ids != null) {
			if (isAdd) {
				ids.add(memberId);
			} else {
				ids.remove(memberId);
			}
		} else {
			if (isAdd) {
				ids = new ConcurrentHashSet<Long>();
				ids.add(memberId);
				String idKey = this.getArmyGroupMemberIdCacheKey(id);
				this.dbCachedService.put2CommonCache(idKey, ids);
			}
		}
	}

	/**
	 * 根据军团名称取得缓存Key
	 * @param name 军团名称
	 * @return 缓存Key
	 */
	private String getArmyGroupKeyByName(String name) {
		return new StringBuilder().append(ArmyGroupCmd.MODULE_NAME)
				.append("_NAME_").append(name.toLowerCase()).toString();
	}
	
	@SuppressWarnings({ "unchecked" })
	@Override
	public List<ArmyGroupDto> searchArmyGroupsAction(String name) {
		List<ArmyGroupDto> result = null;
		StringBuilder tmpName = new StringBuilder();
		tmpName.append("%").append(name).append("%");
		DetachedCriteria dc = DetachedCriteria.forClass(ArmyGroup.class)
				.add(Restrictions.like("name", tmpName.toString()))
				.addOrder(Order.asc("id")).setProjection(Projections.id());
		List<Long> idList = (List<Long>) this.commonManager.getCommonQueryResult(dc, -1, -1);
		if (CollectionUtils.isNotEmpty(idList)) {
			result = new ArrayList<ArmyGroupDto>();
			for (long id : idList) {
				ArmyGroupDto armyGroupDto = this.getArmyGroupDto(id);
				if (armyGroupDto != null) {
					result.add(armyGroupDto);
				}
			}
		}
		return result;
	}
	
	/**
	 * 根据军团名称返回军团
	 * @param name 军团名称
	 * @return
	 */
	@SuppressWarnings("unchecked")
	private ArmyGroup getArmyGroup(String name) {
		// 缓存key
		String key = this.getArmyGroupKeyByName(name);
		Long id = (Long) dbCachedService.getFromCommonCache(key);
		if (id == null) {
			DetachedCriteria dc = DetachedCriteria.forClass(ArmyGroup.class)
					.add(Restrictions.eq("name", name))
					.addOrder(Order.asc("id")).setProjection(Projections.id());
			List<Long> idList = (List<Long>) this.commonManager.getCommonQueryResult(dc, -1, -1);
			if (idList == null || idList.size() == 0) {
				return null;
			}
			
			if (idList.size() > 1) {
				logger.error("军团名称 '{}'重复", name);
			}
			
			id = idList.get(0);
			dbCachedService.put2CommonCacheIfAbsent(key, id);
			id = (Long) dbCachedService.getFromCommonCache(key);
		}	
		return this.getArmyGroup(id);
	}
	
	private ArmyGroup getArmyGroup(long id) {
		return this.dbCachedService.get(id, ArmyGroup.class);
	}

	@Override
	public Set<Long> getArmyGroupMemberIdList(long armyGroupId) {
		return new HashSet<Long> (this.getArmyGroupMemberIds(armyGroupId));
	}

	@Override
	public long getArmyGroupId(long playerId) {
		long result = -1l;
		ArmyGroupMember armyGroupMember = this.dbCachedService.get(
				playerId, ArmyGroupMember.class);
		if (armyGroupMember != null && armyGroupMember.getArmyGroupId() != -1) {// 已经加入军团
			result = armyGroupMember.getArmyGroupId();
		} 
		return result;
	}
	
}
