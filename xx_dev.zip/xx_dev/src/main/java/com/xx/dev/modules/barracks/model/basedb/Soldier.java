package com.xx.dev.modules.barracks.model.basedb;

import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.xx.common.basedb.InitializeBean;
import com.xx.common.basedb.anno.Id;
import com.xx.common.basedb.anno.Index;
import com.xx.common.basedb.anno.Resource;
import com.xx.common.util.Splitable;
import com.xx.dev.constant.IndexName;

/**
 * 士兵训练表
 * 
 * @author Along
 *
 */
@Resource
public class Soldier implements InitializeBean {

	Logger logger = LoggerFactory.getLogger(this.getClass());
	
	/**
	 * id
	 */
	@Id
	private int id;
	
	/**
	 * 兵种类型id
	 */
	@Index(name = IndexName.SOLDIER_INDEX, order = 0)
	private int armType;
	
	/**
	 * 兵阶
	 */
	@Index(name = IndexName.SOLDIER_INDEX, order = 1)
	private int soldierStar;
	
	/**
	 * 需要的兵营等级
	 */
	private int barracksLevel;
	
	/**
	 * 是否需要训练(0-不需要 1-需要)
	 */
	private int wantTrain;
	
	/**
	 * 生命
	 */
	private double hp;
	
	/**
	 * 物理攻击
	 */
	private double attack;
	
	/**
	 * 物理防御
	 */
	private double defend;
	
	/**
	 * 策略攻击
	 */
	private double strategyAttack;
	
	/**
	 * 策略防御
	 */
	private double strategyDefend;
	
	/**
	 * 暴击
	 */
	private double crit;
	
	/**
	 * 格挡
	 */
	private double resist;
	
	/**
	 * 训练冷却时间
	 */
	private Long coolTime;
	
	/**
	 * 训练消耗
	 */
	private String costGoods;
	
	/**
	 * 士兵技能（技能id_技能等级）
	 */
	private String soldierSkill;
	
	/**
	 * 技能id
	 */
	private int skillId = -1;
	
	/**
	 * 技能等级
	 */
	private int skillLevel = 0;
	
	@Override
	public void afterPropertiesSet() {
		if (StringUtils.isNotBlank(this.soldierSkill)) {
			String[] temp = this.soldierSkill.split(Splitable.ATTRIBUTE_SPLIT);
			if (ArrayUtils.isEmpty(temp)) {
				logger.error("静态资源表[Soldier]的字段[soldierSkill]格式有错！");
			} else {
				if (temp.length != 2 || !StringUtils.isNumeric(temp[0]) || 
						!StringUtils.isNumeric(temp[0])) {
					logger.error("静态资源表[Soldier]的字段[soldierSkill]格式有错！");
				} else {
					this.setSkillId(Integer.parseInt(temp[0]));
					this.setSkillLevel(Integer.parseInt(temp[1]));
				}
			}
		} else {
			logger.error("静态资源表[Soldier]的字段[soldierSkill]格式有错！");
		}
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getArmType() {
		return armType;
	}

	public void setArmType(int armType) {
		this.armType = armType;
	}

	public int getSoldierStar() {
		return soldierStar;
	}

	public void setSoldierStar(int soldierStar) {
		this.soldierStar = soldierStar;
	}

	public int getBarracksLevel() {
		return barracksLevel;
	}

	public void setBarracksLevel(int barracksLevel) {
		this.barracksLevel = barracksLevel;
	}

	public int getWantTrain() {
		return wantTrain;
	}

	public void setWantTrain(int wantTrain) {
		this.wantTrain = wantTrain;
	}

	public double getHp() {
		return hp;
	}

	public void setHp(double hp) {
		this.hp = hp;
	}

	public double getAttack() {
		return attack;
	}

	public void setAttack(double attack) {
		this.attack = attack;
	}

	public double getDefend() {
		return defend;
	}

	public void setDefend(double defend) {
		this.defend = defend;
	}

	public double getStrategyAttack() {
		return strategyAttack;
	}

	public void setStrategyAttack(double strategyAttack) {
		this.strategyAttack = strategyAttack;
	}

	public double getStrategyDefend() {
		return strategyDefend;
	}

	public void setStrategyDefend(double strategyDefend) {
		this.strategyDefend = strategyDefend;
	}

	public double getCrit() {
		return crit;
	}

	public void setCrit(double crit) {
		this.crit = crit;
	}

	public double getResist() {
		return resist;
	}

	public void setResist(double resist) {
		this.resist = resist;
	}

	public Long getCoolTime() {
		return coolTime;
	}

	public void setCoolTime(Long coolTime) {
		this.coolTime = coolTime;
	}

	public String getCostGoods() {
		return costGoods;
	}

	public void setCostGoods(String costGoods) {
		this.costGoods = costGoods;
	}

	public String getSoldierSkill() {
		return soldierSkill;
	}

	public void setSoldierSkill(String soldierSkill) {
		this.soldierSkill = soldierSkill;
	}

	public int getSkillId() {
		return skillId;
	}

	public void setSkillId(int skillId) {
		this.skillId = skillId;
	}

	public int getSkillLevel() {
		return skillLevel;
	}

	public void setSkillLevel(int skillLevel) {
		this.skillLevel = skillLevel;
	}

}
