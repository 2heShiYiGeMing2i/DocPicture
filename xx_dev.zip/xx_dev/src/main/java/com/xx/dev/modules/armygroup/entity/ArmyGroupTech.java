package com.xx.dev.modules.armygroup.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.xx.common.db.model.BaseModel;
import com.xx.common.util.Splitable;

/**
 * 军团科技
 * 
 * @author Along
 *
 */
@Entity
@Table(name = "armyGroupTech")
public class ArmyGroupTech extends BaseModel<String> {

	private static final long serialVersionUID = -2517740456574127867L;

	/**
	 * 主键（玩家id_科技id)
	 */
	@Id
	@Column(columnDefinition = "varchar(50) not null comment 'id'")
	private String id;
	
	/**
	 * 玩家id
	 */
	@Column(columnDefinition = "bigint(20) not null comment '玩家id'")
	private long playerId;
	
	/**
	 * 科技id
	 */
	@Column(columnDefinition = "int(11) not null comment '科技id'")
	private int techId;
	
	/**
	 * 科技等级
	 */
	@Column(columnDefinition = "int(11) default '0' comment '科技等级'")
	private int level = 0;
	
	public ArmyGroupTech() {
		
	}
	
	public ArmyGroupTech(long playerId, int techId) {
		this.id = getKey(playerId, techId);
		this.playerId = playerId;
		this.techId = techId;
	}
	
	public static String getKey(long playerId, int techId) {
		StringBuilder buf = new StringBuilder();
		buf.append(playerId).append(Splitable.ATTRIBUTE_SPLIT).append(techId);
		return buf.toString();
	}
	
	@Override
	public String getId() {
		return this.id;
	}

	@Override
	public void setId(String id) {
		this.id = id;
	}

	public long getPlayerId() {
		return playerId;
	}

	public void setPlayerId(long playerId) {
		this.playerId = playerId;
	}

	public int getTechId() {
		return techId;
	}

	public void setTechId(int techId) {
		this.techId = techId;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

}
