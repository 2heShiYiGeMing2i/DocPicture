/**
 * @file:Buff.java
 * @author:David
 **/
package com.xx.dev.modules.battle.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.ListMultimap;


/**
 * @class:Buff
 * @description:战斗过程中相关buff
 * @author:David
 * @version:v1.0
 * @date:2013-4-25
 **/
public class Buff {
	/**
	 * 某期间buff 固定值效果值 {SkillEffect#id,BattleAttrBuff}
	 */
	private final Map<Integer, BattleAttrBuff> buffFix = new HashMap<Integer, BattleAttrBuff>();
	/**
	 * 某期间buff 成长效果值 {SkillEffect#id,BattleAttrBuff}
	 */
	private final Map<Integer, BattleAttrBuff> growBuff = new HashMap<Integer, BattleAttrBuff>();
	/**
	 * 某期间伤害加强BUFF{SkillEffect#id,EnhanceHurtBuff}
	 */
	private final Map<Integer, EnhanceHurtBuff> enhanceHurtBuff = new HashMap<Integer, EnhanceHurtBuff>();
	/**
	 * 固定伤害BUFF	
	 */
	private HurtFixupBuff hurtFixupBuff = null;
	/**
	 * 伤害反弹
	 */
	private HurtReboundBuff hurtReboundBuff = null;
	/**
	 * 暴击伤害加强或降低	{SkillEffect#id,CritEnhanceBuff}
	 */
	private final Map<Integer, CritEnhanceBuff> critEnhanceBuff = new HashMap<Integer, CritEnhanceBuff>();
	/**
	 * 暴击伤害加深或减免 	
	 */
	private final Map<Integer, CritDeepBuff> critDeepBuff = new HashMap<Integer, CritDeepBuff>();
	/**
	 * 让敌方不能行动
	 */
	private BlockBuff blockBuff = null;
	/**
	 * 免疫不能行动（免疫触发眩晕百分比）
	 */
	private final Map<Integer, BlockBuff> reduceBlockBuff = new HashMap<Integer, BlockBuff>();
	/**
	 * 攻击敌方造成吸血	
	 */
	private final Map<Integer, SuckHpBuff> suckHpBuff = new HashMap<Integer, SuckHpBuff>();
	/**
	 * 复活BUFF 	
	 */
	private ReviveBuff reviveBuff = null;
	/**
	 * 抗复活BUFF
	 */
	private final Map<Integer, ResistReviveBuff> resistReviveBuff = new HashMap<Integer, ResistReviveBuff>();
	/**
	 * 生命越低则攻击越高	
	 */
	private HpAttackBuff hpAttackBuff = null;
	/**
	 * 生命越低则防御越高	
	 */
	private HpDefendBuff hpDefendBuff = null;
	/**
	 * 中毒效果 	
	 */
	private final Map<Integer, PoisonBuff> poisonBuff = new HashMap<Integer, PoisonBuff>();
	/**
	 * 回血Buff
	 */
	private final Map<Integer, IncreaseHpBuff> increaseHpBuff = new HashMap<Integer, IncreaseHpBuff>();
	/**
	 * 加强伤害波动	
	 */
	private final Map<Integer, EnhanceWaveBuff> enhanceWaveBuff = new HashMap<Integer, EnhanceWaveBuff>();
	/**
	 * 攻击一定不暴击	
	 */
	private ResistCritBuff resistCritBuff = null;
	/**
	 * 回复加强（先算）
	 */
	private final Map<Integer, IncreaseEnhanceBuff> increaseEnhanceBuff = new HashMap<Integer, IncreaseEnhanceBuff>();
	/**
	 * 被回复加强(后算）	
	 */
	private final Map<Integer, IncreaseEnhanceBuff> byIncreaseEnhanceBuff = new HashMap<Integer, IncreaseEnhanceBuff>();
	/**
	 * 假死（HP>1时，并当受到致命伤害时，生命保留XX点）	
	 */
	private DieAwayBuff dieAwayBuff = null;
	/**
	 * 格挡伤害加强或降低 
	 */
	private final Map<Integer, ResistCritEnhanceBuff> resistCritEnhanceBuff = new HashMap<Integer, ResistCritEnhanceBuff>();
	/**
	 * 格挡伤害加深或减免
	 */
	private final Map<Integer, ResistCritDeepBuff> resistCritDeepBuff = new HashMap<Integer, ResistCritDeepBuff>(); 
	/**
	 * 连击效果 	
	 */
	private ComboBuff comboBuff = null;
	/**
	 * 连击次数
	 */
	private final Map<Integer, ComboTimeBuff> comboTimeBuff = new HashMap<Integer, ComboTimeBuff>();
	/**
	 * 反击效果	
	 */
	private BeatBackBuff beatBackBuff = null;
	/**
	 * 合击效果
	 */
	private AlliedAttackBuff alliedAttackBuff = null;
	/**
	 * 存放各时间点的状态 {SkillEffectTiming#value,SkillEffect#id}
	 */
	private ListMultimap<Integer, Integer> stateMap = ArrayListMultimap.create();
	/**
	 * 免疫物理伤害	
	 */
	private AvoidPhysicsBuff AvoidPhysicsBuff = null;
	/**
	 * 免疫魔法伤害	
	 */
	private AvoidMagicBuff avoidMagicBuff = null;
	
	public Map<Integer, BattleAttrBuff> getBuffFix() {
		return buffFix;
	}
	
	public Map<Integer, BattleAttrBuff> getGrowBuff() {
		return growBuff;
	}
	
	public Map<Integer, EnhanceHurtBuff> getEnhanceHurtBuff() {
		return enhanceHurtBuff;
	}
		
	public void setHurtFixupBuff(HurtFixupBuff hurtFixupBuff) {
		this.hurtFixupBuff = hurtFixupBuff;
	}

	public HurtFixupBuff getHurtFixupBuff() {
		return hurtFixupBuff;
	}
	
	public HurtReboundBuff getHurtReboundBuff() {
		return hurtReboundBuff;
	}

	public void setHurtReboundBuff(HurtReboundBuff hurtReboundBuff) {
		this.hurtReboundBuff = hurtReboundBuff;
	}
	
	public Map<Integer, CritEnhanceBuff> getCritEnhanceBuff() {
		return critEnhanceBuff;
	}
	
	public Map<Integer, CritDeepBuff> getCritDeepBuff() {
		return critDeepBuff;
	}
	
	public BlockBuff getBlockBuff() {
		return blockBuff;
	}

	public void setBlockBuff(BlockBuff blockBuff) {
		this.blockBuff = blockBuff;
	}

	public Map<Integer, BlockBuff> getReduceBlockBuff() {
		return reduceBlockBuff;
	}
	
	public ReviveBuff getReviveBuff() {
		return reviveBuff;
	}

	public void setReviveBuff(ReviveBuff reviveBuff) {
		this.reviveBuff = reviveBuff;
	}
	
	public Map<Integer, SuckHpBuff> getSuckHpBuff() {
		return suckHpBuff;
	}

	public Map<Integer, ResistReviveBuff> getResistReviveBuff() {
		return resistReviveBuff;
	}
	
	public HpAttackBuff getHpAttackBuff() {
		return hpAttackBuff;
	}

	public void setHpAttackBuff(HpAttackBuff hpAttackBuff) {
		this.hpAttackBuff = hpAttackBuff;
	}
	
	public HpDefendBuff getHpDefendBuff() {
		return hpDefendBuff;
	}

	public void setHpDefendBuff(HpDefendBuff hpDefendBuff) {
		this.hpDefendBuff = hpDefendBuff;
	}

	public Map<Integer, IncreaseHpBuff> getIncreaseHpBuff() {
		return increaseHpBuff;
	}

	public Map<Integer, EnhanceWaveBuff> getEnhanceWaveBuff() {
		return enhanceWaveBuff;
	}

	public ResistCritBuff getResistCritBuff() {
		return resistCritBuff;
	}

	public void setResistCritBuff(ResistCritBuff resistCritBuff) {
		this.resistCritBuff = resistCritBuff;
	}

	public Map<Integer, PoisonBuff> getPoisonBuff() {
		return poisonBuff;
	}
	
	public Map<Integer, IncreaseEnhanceBuff> getIncreaseEnhanceBuff() {
		return increaseEnhanceBuff;
	}

	public Map<Integer, IncreaseEnhanceBuff> getByIncreaseEnhanceBuff() {
		return byIncreaseEnhanceBuff;
	}

	public DieAwayBuff getDieAwayBuff() {
		return dieAwayBuff;
	}

	public void setDieAwayBuff(DieAwayBuff dieAwayBuff) {
		this.dieAwayBuff = dieAwayBuff;
	}
	
	public Map<Integer, ResistCritEnhanceBuff> getResistCritEnhanceBuff() {
		return resistCritEnhanceBuff;
	}

	public Map<Integer, ResistCritDeepBuff> getResistCritDeepBuff() {
		return resistCritDeepBuff;
	}

	public ComboBuff getComboBuff() {
		return comboBuff;
	}

	public void setComboBuff(ComboBuff comboBuff) {
		this.comboBuff = comboBuff;
	}

	public Map<Integer, ComboTimeBuff> getComboTimeBuff() {
		return comboTimeBuff;
	}
	
	public BeatBackBuff getBeatBackBuff() {
		return beatBackBuff;
	}

	public void setBeatBackBuff(BeatBackBuff beatBackBuff) {
		this.beatBackBuff = beatBackBuff;
	}
	
	public AlliedAttackBuff getAlliedAttackBuff() {
		return alliedAttackBuff;
	}

	public void setAlliedAttackBuff(AlliedAttackBuff alliedAttackBuff) {
		this.alliedAttackBuff = alliedAttackBuff;
	}
	
	public AvoidPhysicsBuff getAvoidPhysicsBuff() {
		return AvoidPhysicsBuff;
	}

	public void setAvoidPhysicsBuff(AvoidPhysicsBuff avoidPhysicsBuff) {
		AvoidPhysicsBuff = avoidPhysicsBuff;
	}

	public AvoidMagicBuff getAvoidMagicBuff() {
		return avoidMagicBuff;
	}

	public void setAvoidMagicBuff(AvoidMagicBuff avoidMagicBuff) {
		this.avoidMagicBuff = avoidMagicBuff;
	}

	/**
	 * @description:返回固定值效果值
	 * @param skillEffectType
	 * @return
	 */
	public BattleAttrBuff loadBattleAttrBuff(int skillEffectId){
		return buffFix.get(skillEffectId);
	}
	/**
	 * @description:新增固定值效果值
	 * @param skillEffectId
	 * @param battleAttrBuff
	 */
	public void addBuffFix(int skillEffectId , BattleAttrBuff battleAttrBuff){
		buffFix.put(skillEffectId, battleAttrBuff);
	}
	/**
	 * @description:返回成长值效果值
	 * @param skillEffectType
	 * @return
	 */
	public BattleAttrBuff loadBattleGrowBuff(int skillEffectId){
		return growBuff.get(skillEffectId);
	}
	/**
	 * @description:新增成长值效果值
	 * @param skillEffectId
	 * @param battleAttrBuff
	 */
	public void addGrowBuff(int skillEffectId , BattleAttrBuff battleAttrBuff){
		growBuff.put(skillEffectId, battleAttrBuff);
	}
	/**
	 * @description:返回成长值效果值
	 * @param skillEffectType
	 * @return
	 */
	public EnhanceHurtBuff loadEnhanceHurtBuff(int skillEffectId){
		return enhanceHurtBuff.get(skillEffectId);
	}
	/**
	 * @description:新增成长值效果值
	 * @param skillEffectId
	 * @param battleAttrBuff
	 */
	public void addEnhanceHurtBuff(int skillEffectId , EnhanceHurtBuff enhanceHurtBuff){
		this.enhanceHurtBuff.put(skillEffectId, enhanceHurtBuff);
	}
	/**
	 * @description:返回暴击伤害加强或降低
	 * @param skillEffectType
	 * @return
	 */
	public CritEnhanceBuff loadCritEnhanceBuff(int skillEffectId){
		return critEnhanceBuff.get(skillEffectId);
	}
	/**
	 * @description:新增暴击伤害加强或降低
	 * @param skillEffectId
	 * @param battleAttrBuff
	 */
	public void addCritEnhanceBuff(int skillEffectId , CritEnhanceBuff critEnhanceBuff){
		this.critEnhanceBuff.put(skillEffectId, critEnhanceBuff);
	}
	/**
	 * @description:返回暴击伤害加深或减免
	 * @param skillEffectType
	 * @return
	 */
	public CritDeepBuff loadCritDeepBuff(int skillEffectId){
		return critDeepBuff.get(skillEffectId);
	}
	/**
	 * @description:新增暴击伤害加深或减免
	 * @param skillEffectId
	 * @param battleAttrBuff
	 */
	public void addCritDeepBuff(int skillEffectId , CritDeepBuff critDeepBuff){
		this.critDeepBuff.put(skillEffectId, critDeepBuff);
	}
	/**
	 * @description:返回免疫不能行动（免疫触发眩晕百分比）
	 * @param skillEffectType
	 * @return
	 */
	public BlockBuff loadBlockBuff(int skillEffectId){
		return reduceBlockBuff.get(skillEffectId);
	}
	/**
	 * @description:新增免疫不能行动（免疫触发眩晕百分比）
	 * @param skillEffectId
	 * @param battleAttrBuff
	 */
	public void addBlockBuff(int skillEffectId , BlockBuff blockBuff){
		this.reduceBlockBuff.put(skillEffectId, blockBuff);
	}
	/**
	 * @description:返回攻击敌方造成 吸血Buff
	 * @param skillEffectType
	 * @return
	 */
	public SuckHpBuff loadSuckHpBuff(int skillEffectId){
		return suckHpBuff.get(skillEffectId);
	}
	/**
	 * @description:新增攻击敌方造成 吸血Buff
	 * @param skillEffectId
	 * @param battleAttrBuff
	 */
	public void addSuckHpBuff(int skillEffectId , SuckHpBuff suckHpBuff){
		this.suckHpBuff.put(skillEffectId, suckHpBuff);
	}
	/**
	 * @description:返回抗复活效果
	 * @param skillEffectType
	 * @return
	 */
	public ResistReviveBuff loadResistReviveBuff(int skillEffectId){
		return resistReviveBuff.get(skillEffectId);
	}
	/**
	 * @description:新增抗复活效果
	 * @param skillEffectId
	 * @param battleAttrBuff
	 */
	public void addResistReviveBuff(int skillEffectId , ResistReviveBuff resistReviveBuff){
		this.resistReviveBuff.put(skillEffectId, resistReviveBuff);
	}
	/**
	 * @description:返回中毒效果
	 * @param skillEffectType
	 * @return
	 */
	public PoisonBuff loadPoisonBuff(int skillEffectId){
		return poisonBuff.get(skillEffectId);
	}
	/**
	 * @description:新增中毒效果
	 * @param skillEffectId
	 * @param battleAttrBuff
	 */
	public void addPoisonBuff(int skillEffectId , PoisonBuff poisonBuff){
		this.poisonBuff.put(skillEffectId, poisonBuff);
	}
	/**
	 * @description:返回回血Buff
	 * @param skillEffectType
	 * @return
	 */
	public IncreaseHpBuff loadIncreaseHpBuff(int skillEffectId){
		return increaseHpBuff.get(skillEffectId);
	}
	/**
	 * @description:新增回血Buff
	 * @param skillEffectId
	 * @param battleAttrBuff
	 */
	public void addIncreaseHpBuff(int skillEffectId , IncreaseHpBuff increaseHpBuff){
		this.increaseHpBuff.put(skillEffectId, increaseHpBuff);
	}
	/**
	 * @description:返回加强伤害波动
	 * @param skillEffectType
	 * @return
	 */
	public EnhanceWaveBuff loadEnhanceWaveBuff(int skillEffectId){
		return enhanceWaveBuff.get(skillEffectId);
	}
	/**
	 * @description:新增加强伤害波动
	 * @param skillEffectId
	 * @param battleAttrBuff
	 */
	public void addEnhanceWaveBuff(int skillEffectId , EnhanceWaveBuff enhanceWaveBuff){
		this.enhanceWaveBuff.put(skillEffectId, enhanceWaveBuff);
	}
	/**
	 * @description:返回回复加强
	 * @param skillEffectType
	 * @return
	 */
	public IncreaseEnhanceBuff loadIncreaseEnhanceBuff(int skillEffectId){
		return increaseEnhanceBuff.get(skillEffectId);
	}
	/**
	 * @description:新增回复加强
	 * @param skillEffectId
	 * @param battleAttrBuff
	 */
	public void addIncreaseEnhanceBuff(int skillEffectId , IncreaseEnhanceBuff increaseEnhanceBuff){
		this.increaseEnhanceBuff.put(skillEffectId, increaseEnhanceBuff);
	}
	/**
	 * @description:返回被回复加强
	 * @param skillEffectType
	 * @return
	 */
	public IncreaseEnhanceBuff loadByIncreaseEnhanceBuff(int skillEffectId){
		return byIncreaseEnhanceBuff.get(skillEffectId);
	}
	/**
	 * @description:新增被回复加强
	 * @param skillEffectId
	 * @param battleAttrBuff
	 */
	public void addByIncreaseEnhanceBuff(int skillEffectId , IncreaseEnhanceBuff increaseEnhanceBuff){
		this.byIncreaseEnhanceBuff.put(skillEffectId, increaseEnhanceBuff);
	}
	/**
	 * @description:返回格挡伤害加强或降低
	 * @param skillEffectType
	 * @return
	 */
	public ResistCritEnhanceBuff loadResistCritEnhanceBuff(int skillEffectId){
		return resistCritEnhanceBuff.get(skillEffectId);
	}
	/**
	 * @description:新增格挡伤害加强或降低
	 * @param skillEffectId
	 * @param battleAttrBuff
	 */
	public void addResistCritEnhanceBuff(int skillEffectId , ResistCritEnhanceBuff resistCritEnhanceBuff){
		this.resistCritEnhanceBuff.put(skillEffectId, resistCritEnhanceBuff);
	}
	/**
	 * @description:返回格挡伤害加深或减免
	 * @param skillEffectType
	 * @return
	 */
	public ResistCritDeepBuff loadResistCritDeepBuff(int skillEffectId){
		return resistCritDeepBuff.get(skillEffectId);
	}
	/**
	 * @description:新增格挡伤害加深或减免
	 * @param skillEffectId
	 * @param battleAttrBuff
	 */
	public void addResistCritDeepBuff(int skillEffectId , ResistCritDeepBuff resistCritDeepBuff){
		this.resistCritDeepBuff.put(skillEffectId, resistCritDeepBuff);
	}
	/**
	 * @description:返回格挡伤害加深或减免
	 * @param skillEffectType
	 * @return
	 */
	public ComboTimeBuff loadComboTimeBuff(int skillEffectId){
		return comboTimeBuff.get(skillEffectId);
	}
	/**
	 * @description:新增格挡伤害加深或减免
	 * @param skillEffectId
	 * @param battleAttrBuff
	 */
	public void addComboTimeBuff(int skillEffectId , ComboTimeBuff comboTimeBuff){
		this.comboTimeBuff.put(skillEffectId, comboTimeBuff);
	}
	/**
	 * @description:添加具有时间点的状态效果	
	 * @param effectTiming
	 * @param effectId
	 */
	public void addState(Integer effectTiming, Integer effectId){
		if(!stateMap.containsEntry(effectTiming, effectId)){
			stateMap.put(effectTiming, effectId);
		}
	}

	/**
	 * @description:获得某时间点触发的状态效果	
	 * @param effectTiming
	 * @return
	 */
	public List<Integer> listTimeingState(Integer effectTiming){
		return stateMap.get(effectTiming);
	}
}

