/**
 * @file:HurtFixupBuff.java
 * @author:David
 **/
package com.xx.dev.modules.battle.model;
/**
 * @class:HurtFixupBuff
 * @description:固定伤害BUFF
 * @author:David
 * @version:v1.0
 * @date:2013-4-27
 **/
public class HurtFixupBuff extends AbstractBuff {
	
	public HurtFixupBuff(int effectBaseValueType,
			double effectBase, int effectValueType, double effect, int startRound,
			int persistRound) {
		super(effectBaseValueType, effectBase, effectValueType, effect, startRound, persistRound);
	}
	
	/**
	 * @description:固定伤害回合数修改为小回合，触发就扣减	
	 *
	 */
	public void reducePersistRound(){
		if(super.persistRound > 0){
			super.persistRound --;
		}
	}
}

