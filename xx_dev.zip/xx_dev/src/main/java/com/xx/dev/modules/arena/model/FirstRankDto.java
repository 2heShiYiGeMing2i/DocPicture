package com.xx.dev.modules.arena.model;

/**
 * 第一名挑战dto
 * 
 * @author bingshan
 */
public class FirstRankDto implements Comparable<FirstRankDto> {
	
	/**
	 * 挑战方id
	 */
	private long playerId;
	
	/**
	 * 挑战方名
	 */
	private String playerName;
	
	/**
	 * 被挑战方id
	 */
	private long rivalId;
	
	/**
	 * 被挑战方名
	 */
	private String rivalName;
	
	/**
	 * 挑战的时间(ms)
	 */
	private long challengeTime = 0;
	
	public static FirstRankDto valueOf(ChallengeDto challengeDto) {
		FirstRankDto f = new FirstRankDto();
		f.playerId = challengeDto.getPlayerId();
		f.playerName = challengeDto.getPlayerName();
		f.rivalId = challengeDto.getRivalId();
		f.rivalName = challengeDto.getRivalName();
		f.challengeTime = challengeDto.getChallengeTime();
		return f;
	}

	public long getPlayerId() {
		return playerId;
	}

	public void setPlayerId(long playerId) {
		this.playerId = playerId;
	}

	public String getPlayerName() {
		return playerName;
	}

	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}

	public long getRivalId() {
		return rivalId;
	}

	public void setRivalId(long rivalId) {
		this.rivalId = rivalId;
	}

	public String getRivalName() {
		return rivalName;
	}

	public void setRivalName(String rivalName) {
		this.rivalName = rivalName;
	}

	public long getChallengeTime() {
		return challengeTime;
	}

	public void setChallengeTime(long challengeTime) {
		this.challengeTime = challengeTime;
	}

	@Override
	public int compareTo(FirstRankDto o) {
		return this.challengeTime <= o.challengeTime ? 1 : -1;
	}
	
}
