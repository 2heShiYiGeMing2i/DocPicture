/**
 * @file:InviteCheerDto.java
 * @author:David
 **/
package com.xx.dev.modules.armageddon.model;
/**
 * @class:InviteCheerDto
 * @description:邀请人返回DTO
 * @author:David
 * @version:v1.0
 * @date:2013-5-21
 **/
public class InviteCheerDto {
	/** 成功邀请人ID **/
	private long targetUserId;

	public long getTargetUserId() {
		return targetUserId;
	}

	public void setTargetUserId(long targetUserId) {
		this.targetUserId = targetUserId;
	}
}

