package com.xx.dev.modules.activity.handler;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.ArrayUtils;
import org.apache.mina.core.session.IoSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.xx.common.socket.handler.RequestProcessor;
import com.xx.common.socket.handler.RequestProcessorAdapter;
import com.xx.common.socket.model.Request;
import com.xx.common.socket.model.Response;
import com.xx.dev.config.Module;
import com.xx.dev.model.Result;
import com.xx.dev.modules.activity.entity.PlayerActivityTask;
import com.xx.dev.modules.activity.model.PlayerActivityTaskDto;
import com.xx.dev.modules.activity.service.ActivityService;
import com.xx.dev.modules.reward.result.ValueResultSet;
import com.xx.dev.modules.server.SessionManager;
import com.xx.dev.modules.server.handler.HandlerSupport;


/**
 * 活动系统接口实现类
 * 
 * @author bingshan
 */
@Component
public class ActivityHandler extends HandlerSupport {
	
	@Autowired
	private SessionManager sessionManager;
	@Autowired
	private ActivityService activityService;
	
	/**
	 * 模块id
	 */
	private final int module = Module.ACTIVITY;

	@Override
	protected void init() {
		this.registerProcessor(getActivityTaskList);
		this.registerProcessor(receiveActivityTask);
		this.registerProcessor(getActivityTaskReward);
		this.registerProcessor(getActivitysTaskList);
	}
	
	/**
	 * 取得玩家目标章节信息列表
	 */
	private RequestProcessor getActivityTaskList = new RequestProcessorAdapter(module, ActivityCmd.GET_ACTIVITY_TASK_LIST, Map.class) {
		@Override
		public void process(IoSession session, Request request, Response response) {
			Long playerId = sessionManager.getPlayerId(session);
			
			@SuppressWarnings("unchecked")
			Map<String, Object> params = (Map<String, Object>) request.getValue();
			Integer activityId = (Integer) params.get("activityId");
			List<PlayerActivityTask> playerActivityTasks = activityService.getPlayerActivityTasks(playerId, activityId);
			
			response.setValue(PlayerActivityTaskDto.valueOf(playerActivityTasks));
			session.write(response);
		}
	};
	
	/**
	 * 接受活动任务
	 */
	private RequestProcessor receiveActivityTask = new RequestProcessorAdapter(module, ActivityCmd.RECEIVE_ACTIVITY_TASK, Map.class) {
		@Override
		@SuppressWarnings("unchecked")
		public void process(IoSession session, Request request, Response response) {
			Long playerId = sessionManager.getPlayerId(session);			
			List<Result<?>> results = null;
			
			Map<String, Object> params = (Map<String, Object>) request.getValue();
			List<Integer> taskIds = (List<Integer>) params.get("taskIds");
			if (taskIds == null || taskIds.isEmpty()) {
				results = new ArrayList<Result<?>>(0);
			} else {
				results = new ArrayList<Result<?>>(taskIds.size());
				for (int taskId: taskIds) {
					Result<PlayerActivityTaskDto> result = activityService.receiveTask(playerId, taskId);
					result.addContent("taskId", taskId);
					results.add(result);
				}
			}
			
			response.setValue(results);
			session.write(response);
		}
	};
	
	/**
	 * 领取活动任务奖励
	 */
	private RequestProcessor getActivityTaskReward = new RequestProcessorAdapter(module, ActivityCmd.GET_ACTIVITY_TASK_REWARD, Map.class) {
		@Override
		@SuppressWarnings("unchecked")
		public void process(IoSession session, Request request, Response response) {
			Long playerId = sessionManager.getPlayerId(session);			
			
			Map<String, Object> params = (Map<String, Object>) request.getValue();
			Integer taskId = (Integer) params.get("taskId");
			Result<ValueResultSet> result = activityService.getTaskReward(playerId, taskId);
			
			result.addContent("taskId", taskId);
			response.setValue(result);
			session.write(response);
		}
	};
	
	/**
	 * 取得玩家活动的任务列表
	 */
	private RequestProcessor getActivitysTaskList = new RequestProcessorAdapter(module, ActivityCmd.GET_ACTIVITYS_TASK_LIST, Number[].class) {
		@Override
		public void process(IoSession session, Request request, Response response) {
			Long playerId = sessionManager.getPlayerId(session);
			int[] activityIds = null;
			Number[] tmpActivityIds = (Number[]) request.getValue();
			if (ArrayUtils.isNotEmpty(tmpActivityIds)) {
				activityIds = new int[tmpActivityIds.length];
				for (int i = 0; i < tmpActivityIds.length; i++) {
					Number activityId = tmpActivityIds[i];
					if (activityId != null) {
						activityIds[i] = activityId.intValue();
					}
				}
			}
			
			Map<Integer, List<PlayerActivityTaskDto>> result = 
					activityService.getPlayerActivityTasks(playerId, activityIds);
			
			response.setValue(result);
			session.write(response);
		}
	};
}
