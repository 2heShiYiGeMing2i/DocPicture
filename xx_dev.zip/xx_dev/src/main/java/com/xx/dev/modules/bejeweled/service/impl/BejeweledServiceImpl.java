package com.xx.dev.modules.bejeweled.service.impl;

import com.google.common.collect.Lists;
import com.xx.common.db.cache.DbCachedService;
import com.xx.common.util.DateUtil;
import com.xx.common.utility.lock.ChainLock;
import com.xx.common.utility.lock.LockUtils;
import com.xx.dev.constant.LogSource;
import com.xx.dev.model.Result;
import com.xx.dev.modules.bejeweled.entity.PlayerBejeweled;
import com.xx.dev.modules.bejeweled.model.*;
import com.xx.dev.modules.bejeweled.model.basedb.BejeweledBox;
import com.xx.dev.modules.bejeweled.model.basedb.BejeweledCfg;
import com.xx.dev.modules.bejeweled.service.BejeweledRuleService;
import com.xx.dev.modules.bejeweled.service.BejeweledService;
import com.xx.dev.modules.drop.model.DropResult;
import com.xx.dev.modules.drop.service.DropService;
import com.xx.dev.modules.item.service.ItemService;
import com.xx.dev.modules.player.entity.Player;
import com.xx.dev.modules.reward.action.RewardActionSet;
import com.xx.dev.modules.reward.model.ItemReward;
import com.xx.dev.modules.reward.model.Reward;
import com.xx.dev.modules.reward.result.ValueResultSet;
import com.xx.dev.modules.reward.service.RewardService;
import com.xx.dev.modules.vip.service.VipService;
import com.xx.dev.utils.CommonRule;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import static com.xx.dev.constant.CommonConstant.FAILURE;
import static com.xx.dev.constant.CommonConstant.PLAYER_LEVEL_NOT_ENOUGH;
import static com.xx.dev.constant.CommonConstant.PLAYER_NOT_EXISTS;
import static com.xx.dev.modules.bejeweled.handler.BejeweledResult.*;
import static com.xx.dev.modules.bejeweled.handler.BejeweledResult.BASE_DATA_NOT_EXIST;

/**
 * Created by LiangZengle on 2014/6/21.
 */
@Component
public class BejeweledServiceImpl implements BejeweledService {
    @Autowired
    private DbCachedService dbCachedService;
    @Autowired
    private BejeweledRuleService ruleService;
    @Autowired
    private ItemService itemService;
    @Autowired
    private RewardService rewardService;
    @Autowired
    private VipService vipService;
    @Autowired
    private DropService dropService;

    @Override
    public Result<?> getBejeweledInfo(long playerId) {
        Player player = dbCachedService.get(playerId, Player.class);
        if (player == null) {
            return Result.Error(PLAYER_NOT_EXISTS);
        }
        BejeweledCfg bejeweledCfg = ruleService.getBejeweledCfg();
        if (bejeweledCfg == null) {
            return Result.Error(BASE_DATA_NOT_EXIST);
        }
        if(player.getLevel() < bejeweledCfg.getLevel()){
            return Result.Error(PLAYER_LEVEL_NOT_ENOUGH);
        }

        PlayerBejeweled playerBejeweled = getRefreshedPlayerBejeweled(playerId);
        BejeweledContext ctx = getBejeweledContext(playerId);
        BejeweledDto dto = BejeweledDto.valueOf(playerBejeweled, bejeweledCfg, ctx.takeSnapshot());
        return Result.Success(dto);
    }

    @Override
    public Result<?> swap(long playerId, int[] coordinates) {
        Player player = dbCachedService.get(playerId, Player.class);
        if (player == null) {
            return Result.Error(PLAYER_NOT_EXISTS);
        }
        BejeweledCfg bejeweledCfg = ruleService.getBejeweledCfg();
        if (bejeweledCfg == null) {
            return Result.Error(BASE_DATA_NOT_EXIST);
        }
        if(player.getLevel() < bejeweledCfg.getLevel()){
            return Result.Error(PLAYER_LEVEL_NOT_ENOUGH);
        }

        PlayerBejeweled playerBejeweled = getRefreshedPlayerBejeweled(playerId);
        if (getLeftMoves(playerBejeweled) <= 0) {
            return Result.Error(MOVES_LIMIT);
        }
        BejeweledContext ctx = getBejeweledContext(playerId);

        Collection<ClearUpDto> clearUpDtos;
        ChainLock lock = LockUtils.getLock(player);
        lock.lock();
        try {
            if (getLeftMoves(playerBejeweled) <= 0) {
                return Result.Error(MOVES_LIMIT);
            }

            clearUpDtos = ctx.swap(coordinates);
            if (clearUpDtos == null) {
                return Result.Error(ILLEGAL_MOVE);
            }
            // 更新目标完成数量
            updateGoalEliminatedCount(playerBejeweled, clearUpDtos);

            int score = calculateScore(clearUpDtos, playerBejeweled);

            playerBejeweled.setTakenMoves(playerBejeweled.getTakenMoves() + 1);
            playerBejeweled.setScore(playerBejeweled.getScore() + score);

            if (playerBejeweled.getCurGoal().isCompleted()) {// 目标达成，更换新目标
                playerBejeweled.updateGoal(ruleService.randomGoal());
            }
        } finally {
            lock.unlock();
        }
        dbCachedService.submitUpdated2Queue(playerBejeweled.getId(), playerBejeweled.getClass());

        BejeweledDto dto = BejeweledDto.valueOf(playerBejeweled, bejeweledCfg, ctx.takeSnapshot());
        Result<?> result = Result.Success(dto);
        result.addContent("clearUpDetail", clearUpDtos);
        return result;
    }

    @Override
    public Result<?> addMove(long playerId) {
        Player player = dbCachedService.get(playerId, Player.class);
        if (player == null) {
            return Result.Error(PLAYER_NOT_EXISTS);
        }
        BejeweledCfg bejeweledCfg = ruleService.getBejeweledCfg();
        if (bejeweledCfg == null) {
            return Result.Error(BASE_DATA_NOT_EXIST);
        }
        if(player.getLevel() < bejeweledCfg.getLevel()){
            return Result.Error(PLAYER_LEVEL_NOT_ENOUGH);
        }

        PlayerBejeweled playerBejeweled = getRefreshedPlayerBejeweled(playerId);
        if (playerBejeweled.getAddMoveTimes() >= bejeweledCfg.getAddMoveTimes()) {
            return Result.Error(ADD_MOVE_TIMES_LIMIT);
        }

        int goldDiscount;
        ValueResultSet valueResultSet;
        ChainLock lock = LockUtils.getLock(player);
        lock.lock();
        try {
            if (playerBejeweled.getAddMoveTimes() >= bejeweledCfg.getMaxMoves()) {
                return Result.Error(ADD_MOVE_TIMES_LIMIT);
            }
            List<Reward> costs = getAddMoveCost(playerId);
            goldDiscount = vipService.getGoldDisCountValue(player, costs);
            RewardActionSet rewardActionSet = rewardService.tryRewards(playerId, costs);
            if (rewardActionSet.isNotOK()) {
                return Result.Error(rewardActionSet.getResultCode());
            }
            valueResultSet = rewardService.executeRewards(playerId, rewardActionSet, LogSource.BEJEWELED_ADD_MOVE);

            // 增加步数相当于减少已走步数
            int nowTakenMoves = Math.max(playerBejeweled.getTakenMoves() - bejeweledCfg.getMaxMoves(), 0);
            playerBejeweled.setTakenMoves(nowTakenMoves);

            playerBejeweled.setAddMoveTimes(playerBejeweled.getAddMoveTimes() + 1);
        } finally {
            lock.unlock();
        }
        dbCachedService.submitUpdated2Queue(playerBejeweled.getId(), playerBejeweled.getClass());

        Result<?> result = Result.Success("");
        result.addContent("leftMoves", getLeftMoves(playerBejeweled));
        result.addContent("leftAddMoveTimes", Math.max(0, bejeweledCfg.getAddMoveTimes() - playerBejeweled.getAddMoveTimes()));
        result.addContent("goldDiscount", goldDiscount);
        result.addContent("valueResultSet", valueResultSet);
        return result;
    }

    @Override
    public Result<?> autoClearUp(long playerId) {
        Player player = dbCachedService.get(playerId, Player.class);
        if (player == null) {
            return Result.Error(PLAYER_NOT_EXISTS);
        }
        BejeweledCfg bejeweledCfg = ruleService.getBejeweledCfg();
        if (bejeweledCfg == null) {
            return Result.Error(BASE_DATA_NOT_EXIST);
        }
        if(player.getLevel() < bejeweledCfg.getLevel()){
            return Result.Error(PLAYER_LEVEL_NOT_ENOUGH);
        }

        PlayerBejeweled playerBejeweled = getRefreshedPlayerBejeweled(playerId);
        if (getLeftMoves(playerBejeweled) <= 0) {
            return Result.Error(MOVES_LIMIT);
        }
        BejeweledContext ctx = getBejeweledContext(playerId);

        Collection<ClearUpDto> clearUpDtos;
        ValueResultSet valueResultSet;
        int goldDiscount;

        ChainLock lock = LockUtils.getLock(player);
        lock.lock();
        try {
            if (getLeftMoves(playerBejeweled) <= 0) {
                return Result.Error(MOVES_LIMIT);
            }
            List<Reward> costs = rewardService.parseRewards(playerId, bejeweledCfg.getAutoClearUpCost(), false);
            goldDiscount = vipService.getGoldDisCountValue(player, costs);
            RewardActionSet rewardActionSet = rewardService.tryRewards(playerId, costs);
            if (rewardActionSet.isNotOK()) {
                return Result.Error(rewardActionSet.getResultCode());
            }
            valueResultSet = rewardService.executeRewards(playerId, rewardActionSet, LogSource.BEJEWELED_AUTO_CLEAR_UP);

            int autoClearUpCount = ruleService.randomAutoClearUpCount();
            clearUpDtos = ctx.autoClearUp(playerBejeweled.getCurGoal().getValue(), autoClearUpCount);

            // 更新目标完成数量
            updateGoalEliminatedCount(playerBejeweled, clearUpDtos);

            int score = calculateScore(clearUpDtos, playerBejeweled);

            playerBejeweled.setTakenMoves(playerBejeweled.getTakenMoves() + 1);
            playerBejeweled.setScore(playerBejeweled.getScore() + score);
            if (playerBejeweled.getCurGoal().isCompleted()) { // 目标达成，更换新目标
                playerBejeweled.updateGoal(ruleService.randomGoal());
            }
        } finally {
            lock.unlock();
        }
        dbCachedService.submitUpdated2Queue(playerBejeweled.getId(), playerBejeweled.getClass());

        BejeweledDto dto = BejeweledDto.valueOf(playerBejeweled, bejeweledCfg, ctx.takeSnapshot());
        Result<?> result = Result.Success(dto);
        result.addContent("clearUpDetail", clearUpDtos);
        result.addContent("valueResultSet", valueResultSet);
        result.addContent("goldDiscount", goldDiscount);
        return result;
    }

    @Override
    public Result<?> openBox(long playerId) {
        Player player = dbCachedService.get(playerId, Player.class);
        if (player == null) {
            return Result.Error(PLAYER_NOT_EXISTS);
        }
        BejeweledCfg bejeweledCfg = ruleService.getBejeweledCfg();
        if (bejeweledCfg == null) {
            return Result.Error(BASE_DATA_NOT_EXIST);
        }
        if(player.getLevel() < bejeweledCfg.getLevel()){
            return Result.Error(PLAYER_LEVEL_NOT_ENOUGH);
        }

        PlayerBejeweled playerBejeweled = getRefreshedPlayerBejeweled(playerId);
        BejeweledBox box = ruleService.getBox(playerBejeweled.getBoxLevel());
        if (box == null) {
            return Result.Error(BASE_DATA_NOT_EXIST);
        }
        if (playerBejeweled.getScore() < box.getScore()) {
            return Result.Error(SCORE_NOT_ENOUGH);
        }
        DropResult dropResult = dropService.doDrop(playerId, box.getDrop());// 掉落

        ValueResultSet valueResultSet;
        ChainLock lock = LockUtils.getLock(player);
        lock.lock();
        try {
            if (playerBejeweled.getBoxLevel() != box.getLevel()) {
                return Result.Error(FAILURE);
            }
            if (playerBejeweled.getScore() < box.getScore()) {
                return Result.Error(SCORE_NOT_ENOUGH);
            }

            List<Reward> rewards = rewardService.parseRewards(playerId, box.getReward(), false);
            if (dropResult != null) {
                rewards.addAll(dropResult.getRewardList());
            }

            RewardActionSet rewardActionSet = rewardService.tryRewards(playerId, rewards);
            if (rewardActionSet.isNotOK()) {
                return Result.Error(rewardActionSet.getResultCode());
            }
            valueResultSet = rewardService.executeRewards(playerId, rewardActionSet, LogSource.BEJEWELED_OPEN_BOX);

            playerBejeweled.setScore(playerBejeweled.getScore() - box.getScore());
            // box level up
            BejeweledBox nextBox = ruleService.getBox(playerBejeweled.getBoxLevel() + 1);
            if (nextBox != null) {
                playerBejeweled.setBoxLevel(nextBox.getLevel());
            }
        } finally {
            lock.unlock();
        }
        dbCachedService.submitUpdated2Queue(playerBejeweled.getId(), playerBejeweled.getClass());

        if (dropResult != null) {
            dropService.pushDropNotice(playerId, dropResult.getNoticeSet());
        }

        Result<?> result = Result.Success("");
        result.addContent("valueResultSet", valueResultSet);
        result.addContent("score", playerBejeweled.getScore());
        result.addContent("boxLevel", playerBejeweled.getBoxLevel());
        return result;
    }

    private PlayerBejeweled getRefreshedPlayerBejeweled(long playerId) {
        PlayerBejeweled playerBejeweled = dbCachedService.get(playerId, PlayerBejeweled.class);
        if (playerBejeweled == null) {
            playerBejeweled = PlayerBejeweled.valueOf(playerId, ruleService.randomGoal(), ruleService.randomGoal());
            playerBejeweled = dbCachedService.submitNew2Queue(playerBejeweled);
        }

        if (!CommonRule.isSameResetTime(playerBejeweled.getRefreshTime())) {
            return playerBejeweled;
        }
        Player player = dbCachedService.get(playerId, Player.class);
        ChainLock lock = LockUtils.getLock(player);
        lock.lock();
        try {
            if (!CommonRule.isSameResetTime(playerBejeweled.getRefreshTime())) {
                return playerBejeweled;
            }
            Date now = new Date();
            playerBejeweled.refreshOnCrossDay(now);// 每日重置
            if (!DateUtil.isSameWeek(playerBejeweled.getWeeklyRefreshTime(), now, Calendar.MONDAY)) {// 每周重置
                playerBejeweled.refreshOnCrossWeek(now);
            }
        } finally {
            lock.unlock();
        }
        dbCachedService.submitUpdated2Queue(playerBejeweled.getId(), playerBejeweled.getClass());
        return playerBejeweled;
    }

    private BejeweledContext getBejeweledContext(long playerId) {
        String key = "BEJEWELED_CONTEXT_" + playerId;
        BejeweledContext ctx = (BejeweledContext) dbCachedService.getFromCommonCache(key);
        if (ctx == null) {
            ctx = ruleService.newBejeweledContext(playerId);
            dbCachedService.put2CommonCacheIfAbsent(key, ctx);
            ctx = (BejeweledContext) dbCachedService.getFromCommonCache(key);
        }
        return ctx;
    }

    /**
     * 计算本次得分
     *
     * @param clearUpDtos
     * @param playerBejeweled
     * @return
     */
    private int calculateScore(Collection<ClearUpDto> clearUpDtos, PlayerBejeweled playerBejeweled) {
        int totalScore = 0;
        for (ClearUpDto clearUpDto : clearUpDtos) {
            int score = 0;
            for (Integer count : clearUpDto.getEliminatedResult()) {
                score += ruleService.getScore(count);
            }
            clearUpDto.setScore(clearUpDto.getScore() + score);
            totalScore += score;
        }
        Goal goal = playerBejeweled.getCurGoal();
        if (goal.isCompleted()) {
            totalScore += ruleService.getAchieveGoalScore(goal);
        }
        return totalScore;
    }

    /**
     * 剩余步数
     *
     * @param playerBejeweled
     * @return
     */
    private int getLeftMoves(PlayerBejeweled playerBejeweled) {
        BejeweledCfg bejeweledCfg = ruleService.getBejeweledCfg();
        return Math.max(0, bejeweledCfg.getMaxMoves() - playerBejeweled.getTakenMoves());
    }

    /**
     * 增加步数消耗，有道具扣道具，没道具扣元宝
     *
     * @param playerId
     * @return
     */
    private List<Reward> getAddMoveCost(long playerId) {
        List<Reward> rewards = Lists.newArrayListWithCapacity(1);
        BejeweledCfg bejeweledCfg = ruleService.getBejeweledCfg();
        int itemCount = itemService.getValidPlayerItemAmount(playerId, bejeweledCfg.getAddMoveItemId());
        if (itemCount > 0) {
            rewards.add(ItemReward.valueOf(bejeweledCfg.getAddMoveItemId(), -1));
        } else {
            rewards.addAll(rewardService.parseRewards(playerId, bejeweledCfg.getAddMoveGold(), false));
        }
        return rewards;
    }

    /**
     * 更新目标消除的数量
     *
     * @param playerBejeweled
     * @param clearUpDtos
     */
    private void updateGoalEliminatedCount(PlayerBejeweled playerBejeweled, Collection<ClearUpDto> clearUpDtos) {
        int targetCount = 0;
        Goal goal = playerBejeweled.getCurGoal();
        for (ClearUpDto clearUpDto : clearUpDtos) {
            for (Cell cell : clearUpDto.getCell()) {
                if (cell.getValue() == goal.getValue()) {
                    targetCount++;
                }
            }
        }
        playerBejeweled.increaseEliminatedCount(targetCount);
    }

}
