package com.xx.dev.modules.building.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.xx.common.db.model.BaseModel;

/**
 * 主城建筑
 * 
 * @author Along
 *
 */
@Entity
@Table(name = "playerBuilding")
public class PlayerBuilding extends BaseModel<String> {

	private static final long serialVersionUID = -8031293557001303757L;

	/**
	 * 主键（玩家id_建筑id）
	 */
	@Id
	@Column(columnDefinition = "varchar(50) not null comment 'id'")
	private String id;
	
	/**
	 * 玩家id
	 */
	@Column(columnDefinition = "bigint(20) not null comment '玩家id'")
	private long playerId;
	
	/**
	 * 建筑id
	 */
	@Column(columnDefinition = "int(11) not null comment '建筑id'")
	private int buildingId;
	
	/**
	 * 建筑等级
	 */
	@Column(columnDefinition = "int(11) default '1' comment '建筑等级'")
	private int level = 1;
	
	/**
	 * 建筑品质
	 */
	@Column(columnDefinition = "int(11) default '1' comment '建筑品质'")
	private int quality = 1;
	
	public PlayerBuilding() {
		
	}
	
	public PlayerBuilding(long playerId, int buildingId) {
		this.id = getKey(playerId, buildingId);
		this.playerId = playerId;
		this.buildingId = buildingId;
		this.quality = 1;
		this.level = 1;
	}
	
	public static String getKey(long playerId, int buildingId) {
		StringBuilder buf = new StringBuilder();
		buf.append(playerId).append("_").append(buildingId);
		return buf.toString();
	}
	
	@Override
	public String getId() {
		return this.id;
	}

	@Override
	public void setId(String id) {
		this.id = id;
	}

	public long getPlayerId() {
		return playerId;
	}

	public void setPlayerId(long playerId) {
		this.playerId = playerId;
	}

	public int getBuildingId() {
		return buildingId;
	}

	public void setBuildingId(int buildingId) {
		this.buildingId = buildingId;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

	public int getQuality() {
		return quality;
	}

	public void setQuality(int quality) {
		this.quality = quality;
	}

}
