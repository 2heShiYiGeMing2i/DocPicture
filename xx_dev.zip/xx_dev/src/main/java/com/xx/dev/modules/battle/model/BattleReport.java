/**
 * @file:BattleReport.java
 * @author:David
 **/
package com.xx.dev.modules.battle.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * @class:BattleReport
 * @description:战报对象
 * @author:David
 * @version:v1.0
 * @date:2013-4-19
 **/
public class BattleReport {
	/** 当前大回合数 */
	private int currRound;
	/** 军威技能释放阵营 **/
	private BattleTeam junWeiTeam;
	/** 战斗前军威技能效果信息 {Integer(战斗唯一ID), CD回合数}**/
	private Map<Long, Integer> junWeiMap;
	/** 战斗前初始技能效果信息列表 **/
	private List<SkillEffectDetail> initEffects = new ArrayList<SkillEffectDetail>();
	/** 战报内容 {Integer(战斗唯一ID), BattleDetail}**/
	private Map<Integer, BattleDetail> details = new HashMap<Integer, BattleDetail>();
	
	public BattleReport(int currRound) {
		super();
		this.currRound = currRound;
	}

	public int getCurrRound() {
		return currRound;
	}

	public void setCurrRound(int currRound) {
		this.currRound = currRound;
	}

	public Map<Integer, BattleDetail> getDetails() {
		return details;
	}

	public void setDetails(Map<Integer, BattleDetail> details) {
		this.details = details;
	}

	public List<SkillEffectDetail> getInitEffects() {
		return initEffects;
	}

	public void setInitEffects(List<SkillEffectDetail> initEffects) {
		this.initEffects = initEffects;
	}

	public Map<Long, Integer> getJunWeiMap() {
		return junWeiMap;
	}

	public void setJunWeiMap(Map<Long, Integer> junWeiMap) {
		this.junWeiMap = junWeiMap;
	}
	
	public BattleTeam getJunWeiTeam() {
		return junWeiTeam;
	}

	public void setJunWeiTeam(BattleTeam junWeiTeam) {
		this.junWeiTeam = junWeiTeam;
	}

	//一下方法在战斗过程中使用
	/**
	 * @description:增加战报内容
	 * @param battleDetail
	 */
	public void addBattleDetail(BattleDetail battleDetail) {
		this.details.put(battleDetail.getAttackerPos(), battleDetail);
	}
	/**
	 * @description:得到指定战斗对象的战报细节对象
	 * @param pos 位置
	 * @return
	 */
	public BattleDetail loadBattleDetail(int pos){
		return this.details.get(pos);
	}
}

