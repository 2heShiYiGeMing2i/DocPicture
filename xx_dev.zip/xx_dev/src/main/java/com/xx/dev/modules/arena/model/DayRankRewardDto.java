package com.xx.dev.modules.arena.model;


/**
 * 日排行奖励信息dto
 * 
 * @author bingshan
 */
public class DayRankRewardDto {
	
	/**
	 * 第几天
	 */
	private int day;
	
	/**
	 * 排名
	 */
	private int rank;
	
	/**
	 * 玩家id
	 */
	private long playerId;
	
	/**
	 * 玩家名
	 */
	private String playerName;
	
	/**
	 * 奖励状态：0-未领取 1-领取
	 */
	private int rewardStatus = 0;
	
	public static DayRankRewardDto valueOf(DayRankRewardVO v, int day, String playerName) {
		DayRankRewardDto d = new DayRankRewardDto();
		d.day = day;
		d.rank = v.getRank();
		d.playerId = v.getPlayerId();
		d.playerName = playerName;
		d.rewardStatus = v.getRewardStatus();
		return d;
	}

	public int getDay() {
		return day;
	}

	public void setDay(int day) {
		this.day = day;
	}

	public int getRank() {
		return rank;
	}

	public void setRank(int rank) {
		this.rank = rank;
	}

	public long getPlayerId() {
		return playerId;
	}

	public void setPlayerId(long playerId) {
		this.playerId = playerId;
	}

	public int getRewardStatus() {
		return rewardStatus;
	}

	public void setRewardStatus(int rewardStatus) {
		this.rewardStatus = rewardStatus;
	}

	public String getPlayerName() {
		return playerName;
	}

	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}

}
