package com.xx.dev.modules.armygroup.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

import com.xx.common.db.model.BaseModel;

/**
 * 军团申请记录
 * 
 * @author Along
 *
 */
@Entity
@Table(name = "armyGroupApply")
public class ArmyGroupApply extends BaseModel<Long> {

	private static final long serialVersionUID = 468486680258475280L;

	/**
	 * 主键
	 */
	@Id
	@Column(columnDefinition = "bigint(20) NOT NULL COMMENT '主键'")
	private Long id;
	
	/**
	 * 玩家id
	 */
	@Index(name = "armyGroup_apply_playerId_index")
	@Column(columnDefinition = "bigint(20) NOT NULL COMMENT '玩家id'")
	private long playerId;
	
	/**
	 * 军团id（-1表示暂时没有加入任何军团）
	 */
	@Index(name = "armyGroup_apply_armyGroupId_index")
	@Column(columnDefinition = "bigint(20) NOT NULL COMMENT '军团id'")
	private long armyGroupId;

	public ArmyGroupApply() {
		
	}
	
	public ArmyGroupApply(long id, long playerId) {
		this.playerId = playerId;
		this.armyGroupId = id;
	}
	
	@Override
	public Long getId() {
		return this.id;
	}

	@Override
	public void setId(Long id) {
		this.id = id;
	}

	public long getPlayerId() {
		return playerId;
	}

	public void setPlayerId(long playerId) {
		this.playerId = playerId;
	}

	public long getArmyGroupId() {
		return armyGroupId;
	}

	public void setArmyGroupId(long armyGroupId) {
		this.armyGroupId = armyGroupId;
	}
	
}
