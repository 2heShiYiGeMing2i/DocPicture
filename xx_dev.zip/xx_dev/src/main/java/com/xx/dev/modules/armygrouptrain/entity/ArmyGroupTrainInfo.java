package com.xx.dev.modules.armygrouptrain.entity;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.codehaus.jackson.type.TypeReference;

import com.xx.common.db.cache.DbLoadInitializer;
import com.xx.common.db.model.BaseModel;
import com.xx.common.util.JsonUtils;
import com.xx.common.util.StringUtils;
import com.xx.dev.modules.armygrouptrain.model.TrainPlayerRankVO;
/**
 * 軍團試煉排名信息
 * @author jy
 *
 */
@Entity
@Table(name = "armyGroupTrainInfo")
public class ArmyGroupTrainInfo extends BaseModel<Long> implements DbLoadInitializer{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2355415814973500141L;

	/**
	 * 軍團id
	 */
	@Id
	@Column(columnDefinition = "bigint(20) NOT NULL COMMENT '主键'")
	private Long id;
	
	/**
	 * 試煉日期yy-mm-dd
	 */
	@Column(columnDefinition = "varchar(50) NOT NULL COMMENT '试炼日期'")
	private String date = "";
	
	/**
	 * 該軍團試煉的排名信息
	 */
	@Lob
	@Column(columnDefinition = "longtext comment '军团试炼排名'")
	private String ranks;
	
	/**
	 * 試煉排名
	 */
	@Transient
	private final Map<Long, TrainPlayerRankVO> trainRanks = 
			new ConcurrentHashMap<Long, TrainPlayerRankVO>();
	
	@Override
	public Long getId() {
		return id;
	}

	@Override
	public void setId(Long id) {
		this.id = id;
	}

	public String getRanks() {
		return ranks;
	}

	public void setRanks(String ranks) {
		this.ranks = ranks;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public Map<Long, TrainPlayerRankVO> getTrainRanks() {
		return trainRanks;
	}

	public static ArmyGroupTrainInfo valueOf(long armyGroupId) {
		ArmyGroupTrainInfo trainInfo = new ArmyGroupTrainInfo();
		trainInfo.id = armyGroupId;
		return trainInfo;
	}

	public TrainPlayerRankVO getTrainPlayerRank(long playerId) {
		return trainRanks.get(playerId);
	}

	@Override
	public void doAfterLoad() {
		if(StringUtils.isEmpty(ranks)){
			return;
		}
		
		TypeReference<List<TrainPlayerRankVO>> typeRef = new TypeReference<List<TrainPlayerRankVO>>() {};
		List<TrainPlayerRankVO> rankList = JsonUtils.jsonString2Object(ranks, typeRef);
		if(rankList != null){
			for(TrainPlayerRankVO rank : rankList){
				if(rank != null){
					trainRanks.put(rank.getPlayerId(), rank);
				}
			}
		}
	}

	public void addTrainPlayerRank(TrainPlayerRankVO rankVO) {
		if(rankVO == null)
			return;
		trainRanks.put(rankVO.getPlayerId(), rankVO);
		
	}
}
