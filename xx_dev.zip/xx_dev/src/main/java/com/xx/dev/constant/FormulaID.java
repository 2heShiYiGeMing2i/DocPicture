/**
 * @file:FormulaID.java
 * @author:David
 **/
package com.xx.dev.constant;
/**
 * @class:FormulaID
 * @description:基础公式总表ID
 * @author:David
 * @version:v1.0
 * @date:2013-4-26
 **/
public interface FormulaID {
	
	//-----------------1主公系统----------------------
	/**
	 * 武力转物攻
	 */
	int PLAYER_POWER2ATTACK = 1001;
	/**
	 * 武力转物防
	 */
	int PLAYER_POWER2DEFEND = 1002;
	
	/**
	 * 智力转策略攻击
	 */
	int PLAYER_BRAINS2STRATEGYATTACK = 1003;
	/**
	 * 智力转策略防御
	 */
	int PLAYER_BRAINS2STRATEGYDEFEND = 1004;
	
	/**
	 * 魅力转暴击
	 */
	int PLAYER_CHARM2CRIT = 1005;
	/**
	 * 魅力转格挡
	 */
	int PLAYER_CHARM2RESIST = 1006;
	
	/**
	 * 暴击转暴击率
	 */
	int PLAYER_CRIT2CRITLV = 1007;
	/**
	 * 格挡转格挡率
	 */
	int PLAYER_RESIST2RESISTLV = 1008;
	
	/**
	 * 统率转带兵数
	 */
	int PLAYER_COMMAND2COMMONAMOUNT = 1009;
	
	/**
	 * 战斗力计算
	 */
	int PLAYER_ABILITY = 1010;
	
	//-----------------10 战斗系统 --------------------	
	/** 10001-攻击暴击 */
	int BATTLE_CRIT = 10001;
	/** 10002-物理伤害 */
	int BATTLE_PHYSICS = 10002;
	/** 10003-魔法伤害 */
	int BATTLE_MAGIC = 10003;
	/** 10004-最终反弹伤害**/
	int BATTLE_HURTREBOUND = 10004;
	/** 10005-最终中毒伤害**/
	int BATLE_POISON = 10005;
	/** 10006-最终回血量**/
	int BATTLE_INCREASE = 10006;
	/** 10007-攻击格挡 **/
	int BATTLE_RESIST = 10007;
	/** 10008-武将眩晕的回合数 **/
	int JUNWEI_CD = 10008;
	/** 10009-眩晕的武将个数 **/
	int JUNWEI_COUNT = 10009;
	//-------------------11背包系统----------------------
	int PACK_BUY_CELL = 11001;
	
	//-------------------13远征异族----------------------
	int BUY_INVADE = 13001;
	
	//--------------------14税收-------------------------
	/**
	 * 粮草税收的征收产出
	 */
	int REVENUE_FOODS_OUTPUT = 14001;
	
	/**
	 * 银元税收的征收产出
	 */
	int REVENUE_SILVER_OUTPUT = 14002;
	
	//-------------------21征战天下----------------------
	int REVIVE_JOURNEY = 21001;
	/**
	 * 征战天下困难购买消耗
	 */
	int BUY_TIME_JOURNET = 21002;
	
	// -------------------26命签-------------------------
	
	/**
	 * 命签积分
	 */
	int DIVINATION_SCORE = 26001;
	
	//-------------------27（攻城掠地）----------------------
	/** 掠夺粮食奖励 **/
	int PLUNDER_FOOD = 27001;
	/** 掠夺银两奖励 **/
	int PLUNDER_SILVER = 27002;
	/** 鼓舞银两消耗 **/
	int INSPIRE_SILVER = 27003;
	/** 攻城掠地购买掠夺次数消耗 **/
	int INSPIRE_BUY = 27004;
	
	//-----------------28 竞技场---------------------------
	
	/**
	 * 竞技场购买次数
	 */
	int ARENA_BUY_COUNT = 28001;
	
	//-----------------29军团-----------------------------
	/**
	 * 粮草福利
	 */
	int ARMY_GROUP_RECEIVE_FOODS = 29001;
	
	/**
	 * 武将经验福利
	 */
	int ARMY_GROUP_RECEIVE_HERO_SOUL= 29002;
	
	//-----------------30 群雄争霸-----------------------------
	
	/**
	 * 群雄争霸支持正确个人奖励
	 */
	int CHAMPION_SUPPORT_RIGHT_REWARD = 30002;
	
	//-----------------32 商城资源-----------------------------
	/**
	 * 商城资源兑换(银两、粮食、武将经验)
	 */
	int SHOP_RESOURCE = 32001;
	
	//-----------------36 礼包系统-----------------------------
	/**
	 * 首充3倍返还
	 */
	int FIRST_CHARGE = 36001;
	//-----------------44 一夫当关-----------------------------
	
	/**
	 * 一夫当关次数购买消耗
	 */
	int MANPASS_BUY_COUNT = 44001;
	
	//-----------------46 新精英副本-----------------------------
	/**
	 * 单次重置消耗元宝
	 */
	int MISSION_RESET = 46001;
	/**
	 * 全部重置消耗元宝
	 */
	int ALLMISSION_RESET = 46002;
	
	//-----------------50 奴隶系统-----------------------------
	
	/**
	 * 购买抓捕次数消耗
	 */
	int SLAVE_HOOK_TIME = 50001;
	/**
	 * 奴隶干活每分钟获得奖励
	 */
	int SLAVE_HOUR_REWARD = 50002;
	/**
	 * 每天可获得的最大奖励
	 */
	int MASTER_HOUR_REWARD = 50003;
	
	//--------------------------52 军团劫饷-------------------------------
	/**
	 * 每次购买消耗的功勋
	 */
	int PLUNDERFOODPOINT = 52001;
	//--------------------------54 跑环系统-------------------------------
	
	/**普通骰子的价格公式*/
	int LOOP_COMMON_DICE_PRICE =54001;
	
	/**幸运骰子的价格公式*/
	int LOOP_LUCKY_DICE_PRICE=54002;
	
	/**BOSS生命*/
	int LOOP_BOSS_HP =54003;
	
	/**BOSS战斗奖励-银两*/
	int LOOP_BOSS_FIGHT_SILVER=54004;
	
	/**BOSS战斗奖励-积分*/
	int LOOP_BOSS_FIGHT_SCORE=54005;
	
	/**每天获得银两的最大值*/
	int LOOP_BOSS_FIGHT_SILVER_MAX =54006;
	
	// -------------------------60决战长安-------------------------------
	
	/**
	 * 决战长安炸弹威力
	 */
	int DECISIVE_CHANG_AN_BOMB_HURT = 60001;
	
	/**
	 * 决战长安PVP胜利积分公式
	 */
	int DECISIVE_CHANG_AN_PVP_WIN_INTEGRAL = 60002;
	
	/**
	 * 决战长安PVP失败积分公式
	 */
	int DECISIVE_CHANG_AN_PVP_LOSE_INTEGRAL = 60003;
	
	/**
	 * 决战长安PVP胜利积分公式
	 */
	int DECISIVE_CHANG_AN_PVE_INTEGRAL = 60004;
	
	// -----------------61图腾--------------------------
	
	/**
	 * 图腾BUF增加的经验
	 */
	int TOTEM_BUF_ADDED_EXP = 61001;
	
	// -----------------70植树节 -------------------------
	
	/**
	 * 植树节活动购买种子
	 */
	int PLANT_BUY_SEED = 70001;
	
	//------------------75幸运抽奖------------------------
	
	/**
	 * 幸运抽奖消耗的道具数量
	 */
	int LUCKY_DRAW_COST = 75001;
	
	// -----------------84劳动节种植活动-----------------
	
	/**
	 * 植树节活动购买种子
	 */
	int LABOR_PLANT_BUY_FERTILIZER = 84001;
	
	
	// ---------------皇城缉盗85---------------------
	
	/**
	 * 皇城缉盗任务购买次数消耗
	 */
	int ROYAL_TASK_BUY_COUNT = 85001;
	
	// ---------------跨服掠夺 91---------------------
	
	/**
	 * 跨服掠夺 购买次数
	 */
	int KF_LOOT_BUY_COUNT = 91001;
}