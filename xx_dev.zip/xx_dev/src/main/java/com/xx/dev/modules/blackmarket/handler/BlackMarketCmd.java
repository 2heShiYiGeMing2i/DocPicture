package com.xx.dev.modules.blackmarket.handler;

import com.xx.dev.modules.blackmarket.model.PlayerBlackMarketDto;
import com.xx.dev.modules.reward.result.ValueResultSet;

/**
 * 黑市模块
 * 
 * @author Along
 *
 */
public interface BlackMarketCmd {

	/**
	 * 返回玩家黑市信息
	 * @return Map {
	 * 				"result" : {@link BlackMarketResult}
	 * 				"content" : {@link PlayerBlackMarketDto} 
	 * 				}
	 */
	int GET_BLACK_MARKET = 1;
	
	/**
	 * 购买黑市物品
	 * @param index 物品序号
	 * @return Map {
	 * 				"result" : {@link BlackMarketResult}
	 * 				"content" : {@link PlayerBlackMarketDto} 
	 * 				"valueResultSet" : {@link ValueResultSet} 更新的属性集
	 * 				}
	 */
	int BUY_GOODS = 2;
	
	/**
	 * 刷新黑市物品
	 * @return Map {
	 * 				"result" : {@link BlackMarketResult}
	 * 				"content" : {@link PlayerBlackMarketDto} 
	 * 				"valueResultSet" : {@link ValueResultSet} 更新的属性集
	 * 				"goldDiscount" : {@link Integer} VIP折扣优惠的元宝数量
	 * 				}
	 */
	int REFRESH_GOODS = 3;
	
	/**
	 * 黑市积分兑换
	 * @param id 兑换物品编号（基础数据表）
	 * @param amount 数量
	 * @return Map {
	 * 				"result" : {@link BlackMarketResult}
	 * 				"content" : {@link PlayerBlackMarketDto} 
	 * 				"valueResultSet" : {@link ValueResultSet} 更新的属性集
	 * 				}
	 */
	int INTERGAL_CHANGE = 4;
	
	/**
	 * 购买市场物品
	 * @param goodsId 物品id
	 * @param amount 购买数量
	 * @return Map {
	 * 				"result" : {@link BlackMarketResult}
	 * 				"content" : {@link valueResultSet} 更新的属性集
	 * 				}
	 */
	int CHANGE_GOODS = 5;
	
	/**
	 * 获取市场可购买商品id列表
	 * @param goodsType 商品类型
	 * @return Map {
	 * 				"result" : {@link BlackMarketResult}
	 * 				"content" : {@link List<Integer>} 可购买商品id列表
	 * 				}
	 */
	int GET_GOODS_IDS = 6;
	
}
