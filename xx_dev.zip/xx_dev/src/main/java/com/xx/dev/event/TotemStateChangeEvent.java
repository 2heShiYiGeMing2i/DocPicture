package com.xx.dev.event;

import com.xx.common.event.Event;
/**
 * 图腾属性改变事件：图腾等级或祝福值改变
 * @author jy
 *
 */
public class TotemStateChangeEvent {

	/**
	 * 图腾升级事件
	 */
	public static final String NAME = "TOTEM:STATECHANGE";
	
	private long playerId;
	
	private int grade;
	
	private long luckValue;
	
	
	
	public long getPlayerId() {
		return playerId;
	}



	public int getGrade() {
		return grade;
	}



	public long getLuckValue() {
		return luckValue;
	}



	public static Event<TotemStateChangeEvent> valueOf(long playerId, int grade, long luckValue) {
		TotemStateChangeEvent event = new TotemStateChangeEvent();
		event.playerId = playerId;
		event.grade = grade;
		event.luckValue = luckValue;
		return new Event<TotemStateChangeEvent>(NAME, event);
	}
}
