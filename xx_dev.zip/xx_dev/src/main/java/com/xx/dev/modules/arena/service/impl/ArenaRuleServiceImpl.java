package com.xx.dev.modules.arena.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.xx.common.basedb.BasedbAdapter;
import com.xx.common.util.RandomUtil;
import com.xx.dev.constant.GameRuleID;
import com.xx.dev.constant.IndexName;
import com.xx.dev.modules.arena.model.basedb.ArenaBox;
import com.xx.dev.modules.arena.model.basedb.ArenaCard;
import com.xx.dev.modules.arena.model.basedb.ArenaDayRank;
import com.xx.dev.modules.arena.model.basedb.ArenaNpc;
import com.xx.dev.modules.arena.service.ArenaRuleService;
import com.xx.dev.utils.GameRuleService;


/**
 * 竞技场系统基础数据接口实现
 * 
 * @author bingshan
 */
@Component
public class ArenaRuleServiceImpl extends BasedbAdapter implements ArenaRuleService {
	
	@Autowired
	private GameRuleService gameRuleService;
	
	
	/**
	 * 竞技场天排名奖励最大天数
	 */
	private int maxDayOfDayRankReward = 0;
	
	/**
	 * 竞技场天排名奖励最大排名
	 */
	private int maxRankOfDayRankReward = 0;

	@Override
	public Class<?>[] listenedClass() {
		return new Class<?>[] {ArenaCard.class, ArenaBox.class, ArenaNpc.class, ArenaDayRank.class};
	}

	@Override
	public void initialize() {
		initArenaDayRanks();
	}
	
	/**
	 * 初始化竞技场天排名奖励信息
	 */
	private void initArenaDayRanks() {
		List<ArenaDayRank> list = this.basedbService.listAll(ArenaDayRank.class);
		if (list == null || list.isEmpty()) {
			return;
		}
		
		int maxDay = 0;
		int maxRank = 0;
		
		for (ArenaDayRank r: list) {
			if (r.getDay() > maxDay) {
				maxDay = r.getDay();
			}
			
			if (r.getRank() > maxRank) {
				maxRank = r.getRank();
			}
		}
		
		this.maxDayOfDayRankReward = maxDay;
		this.maxRankOfDayRankReward = maxRank;
	}

	@Override
	public ArenaBox getArenaBox(int id) {
		return this.basedbService.get(ArenaBox.class, id);
	}

	@Override
	public ArenaBox getArenaBoxByRank(int rank) {
		List<ArenaBox> boxList = this.basedbService.listAll(ArenaBox.class);
		if (boxList == null || boxList.isEmpty()) {
			return null;
		}
		
		for (ArenaBox box: boxList) {
			if (rank >= box.getMinRak() && rank <= box.getMaxRank()) {
				return box;
			}
		}
		return null;
	}

	@Override
	public ArenaCard getRandomCards() {
		List<ArenaCard> cardList = this.basedbService.listAll(ArenaCard.class);
		if (cardList == null || cardList.isEmpty()) {
			return null;
		}
		
		int fullValue = cardList.get(0).getFullValue();
		int random = RandomUtil.nextInt(fullValue) + 1;
		int currValue = 0;
		for (ArenaCard card: cardList) {
			currValue += card.getRate();
			if (random < currValue) {
				return card;
			}
		}
		
		random = RandomUtil.nextInt(cardList.size());
		return cardList.get(random);
	}

	@Override
	public List<ArenaNpc> getArenaNpcList(int fetchCount) {
		if (fetchCount <= 0) {
			return null;
		}
		List<ArenaNpc> list = this.basedbService.listAll(ArenaNpc.class);
		if (list == null || list.size() <= fetchCount) {
			return list;
		}
		
		return list.subList(0, fetchCount);
	}

	@Override
	public ArenaNpc getArenaNpc(int npcId) {
		return this.basedbService.get(ArenaNpc.class, npcId);
	}

	@Override
	public int getRewardActivityMultiple() {
		return this.gameRuleService.getAmountByID(GameRuleID.ARENA_REWARD_ACTIVITY_MULTIPLE).intValue();
	}

	@Override
	public ArenaDayRank getArenaDayRank(int day, int rank) {
		List<ArenaDayRank> list = this.basedbService.listByIndex(ArenaDayRank.class, IndexName.ARENA_DAY_RANK_INDEX, day, rank);
		return list != null && list.size() > 0 ? list.get(0) : null;
	}

	@Override
	public int getMaxDayOfDayRankReward() {
		return maxDayOfDayRankReward;
	}

	@Override
	public int getMaxRankOfDayRankReward() {
		return maxRankOfDayRankReward;
	}
	
}
