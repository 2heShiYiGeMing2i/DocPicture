/**
 * @file:ArmageddonCheerInfo.java
 * @author:David
 **/
package com.xx.dev.modules.armageddon.entity;

import java.util.Set;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.apache.commons.lang.StringUtils;

import com.xx.common.db.cache.DbLoadInitializer;
import com.xx.common.db.model.BaseModel;
import com.xx.common.util.Splitable;
import com.xx.dev.modules.relation.model.RelationState;

/**
 * @class:ArmageddonCheerInfo
 * @description:玩家好友助阵信息
 * @author:David
 * @version:v1.0
 * @date:2013-5-21
 **/
@Entity
@Table(name = "armageddonCheerInfo")
public class ArmageddonCheerInfo extends BaseModel<Long> implements DbLoadInitializer{
	private static final long serialVersionUID = -1788526376585022769L;
	public static final Long INIT_VALUE = -1l;
	/** 主键玩家ID */
	@Id
	@Column(columnDefinition = "bigint(20) NOT NULL COMMENT '玩家ID'")
	private Long id;
	
	/** 当前助阵用户ID  */
	@Column(columnDefinition = "bigint(20) DEFAULT -1 COMMENT '当前助阵用户ID'")
	private Long cheerIdOne = INIT_VALUE;
	/** 当前助阵用户奖励类型   */
	@Column(columnDefinition = "int(11) DEFAULT 0 COMMENT '当前助阵用户奖励类型'")
	private int cheerOneState = RelationState.NONE.ordinal();
	
	/** 当前助阵用户ID  */
	@Column(columnDefinition = "bigint(20) DEFAULT -1 COMMENT '当前助阵用户ID'")
	private Long cheerIdTwo = INIT_VALUE;
	/** 当前助阵用户奖励类型   */
	@Column(columnDefinition = "int(11) DEFAULT 0 COMMENT '当前助阵用户奖励类型'")
	private int cheerTwoState = RelationState.NONE.ordinal();
	
	/** 当前助阵玩家列表 **/
	@Column(columnDefinition = "text comment '当前助阵玩家列表'")
	private String cheerInfo;
	
	/** 已进入CD回合玩家 **/
	@Column(columnDefinition = "text comment '已进入CD回合玩家'")
	private String cdPlayerInfo;
	
	/** 阵形 玩家ID_1|玩家ID_2|玩家ID_3**/
	@Column(columnDefinition = "varchar(255) comment '阵形'")
	private String formation;
	
	/** 以下属性初始化后赋值 **/
	/** 当前出战列表{playerId:RelationState} **/
	@Transient
	private final ConcurrentMap<Long, Integer> cheerInfoMap = new ConcurrentHashMap<Long, Integer>();
	/** 已进入CD回合玩家{round回合:List<playerId>} **/
	@Transient
	private final ConcurrentMap<Long, Integer> cdPlayerMap = new ConcurrentHashMap<Long, Integer>();
	/** 阵形 **/
	@Transient
	private final ConcurrentMap<Integer, Long> formationMap = new ConcurrentHashMap<Integer, Long>();
	
	@Override
	public Long getId() {
		return id;
	}

	@Override
	public void setId(Long id) {
		this.id = id;
	}

	public Long getCheerIdOne() {
		return cheerIdOne;
	}

	public void setCheerIdOne(Long cheerIdOne) {
		this.cheerIdOne = cheerIdOne;
	}

	public Long getCheerIdTwo() {
		return cheerIdTwo;
	}

	public void setCheerIdTwo(Long cheerIdTwo) {
		this.cheerIdTwo = cheerIdTwo;
	}

	public String getCheerInfo() {
		return cheerInfo;
	}

	public void setCheerInfo(String cheerInfo) {
		this.cheerInfo = cheerInfo;
	}

	public String getCdPlayerInfo() {
		return cdPlayerInfo;
	}

	public void setCdPlayerInfo(String cdPlayerInfo) {
		this.cdPlayerInfo = cdPlayerInfo;
	}
	
	public String getFormation() {
		return formation;
	}

	public void setFormation(String formation) {
		this.formation = formation;
	}
	
	public int getCheerOneState() {
		return cheerOneState;
	}

	public void setCheerOneState(int cheerOneState) {
		this.cheerOneState = cheerOneState;
	}

	public int getCheerTwoState() {
		return cheerTwoState;
	}

	public void setCheerTwoState(int cheerTwoState) {
		this.cheerTwoState = cheerTwoState;
	}

	@Override
	public void doAfterLoad() {
		cheerInfoMap.clear();
		if(StringUtils.isNotBlank(this.cheerInfo)) {
			String[] cheerInfos = cheerInfo.split(Splitable.ELEMENT_SPLIT);
			String[] infoArray;
			for (String info : cheerInfos) {
				infoArray = info.split(Splitable.ATTRIBUTE_SPLIT);
				cheerInfoMap.put(Long.valueOf(infoArray[0]), Integer.valueOf(infoArray[1]));
			}
		}
		cdPlayerMap.clear();
		if(StringUtils.isNotBlank(this.cdPlayerInfo)){
			String[] cdPlayerInfos = cdPlayerInfo.split(Splitable.ELEMENT_SPLIT);
			String[] infoArray;
			for (String info : cdPlayerInfos) {
				infoArray = info.split(Splitable.ATTRIBUTE_SPLIT);
				long playerId = Long.valueOf(infoArray[0]);
				int round = Integer.parseInt(infoArray[1]);
				cdPlayerMap.put(playerId, round);
			}
		}
		formationMap.clear();
		if(StringUtils.isNotBlank(this.formation)){
			String[] formationInfos = formation.split(Splitable.ELEMENT_SPLIT);
			String[] infoArray;
			for (String info : formationInfos) {
				infoArray = info.split(Splitable.ATTRIBUTE_SPLIT);
				long playerId = Long.valueOf(infoArray[0]);
				int index = Integer.parseInt(infoArray[1]);
				formationMap.put(index, playerId);
			}
		}
		
	}
	
	/**
	 * 当前出战列表转换成字符串
	 * @return String
	 */
	public String cheerInfoMap2String(){
		if(cheerInfoMap.isEmpty()){
			return null;
		}
		StringBuilder infoString = new StringBuilder();
		Set<Entry<Long, Integer>> entries = cheerInfoMap.entrySet();
		for (Entry<Long, Integer> entry : entries) {
			infoString.append(entry.getKey())
			.append(Splitable.ATTRIBUTE_SPLIT)
			.append(entry.getValue())
			.append(Splitable.ELEMENT_DELIMITER);
		}
		return infoString.toString();
	}
	
	/**
	 * @description:当前出战列表
	 * @return
	 */
	public ConcurrentMap<Long, Integer> getCheerInfoMap() {
		return cheerInfoMap;
	}
	/**
	 * @description:已进入CD回合玩家
	 * @return String
	 */
	public String cdPlayerMap2String(){
		if(cdPlayerMap.isEmpty()){
			return null;
		}
		StringBuilder infoString = new StringBuilder();
		Set<Entry<Long, Integer>> entries = cdPlayerMap.entrySet();
		for (Entry<Long, Integer> entry : entries) {
			Long playerId = entry.getKey();
			int round = entry.getValue();
			infoString.append(playerId)
			.append(Splitable.ATTRIBUTE_SPLIT)
			.append(round)
			.append(Splitable.ELEMENT_DELIMITER);
		}
		return infoString.toString();
	}
	/**
	 * @description:已进入CD回合玩家
	 * @return
	 */
	public ConcurrentMap<Long, Integer> getCdPlayerMap() {
		return cdPlayerMap;
	}
	/**
	 * @description:是否有效出战ID	
	 * @param userId
	 * @return
	 */
	public boolean containCheerId(long userId){
		return cheerInfoMap.containsKey(userId);
	}
	
	/**
	 * @description:清除邀请人信息	
	 * @param cheerId 保留的邀请人
	 */
	public void clearInfo(long cheerId){
		if(cheerInfoMap.containsKey(cheerId)){
			int relationState = cheerInfoMap.get(cheerId);
			cheerInfoMap.clear();
			cheerInfoMap.put(cheerId, relationState);
			this.cheerInfo = cheerInfoMap2String();
		}else {
			cheerInfoMap.clear();
			this.cheerInfo = null;
		}
		cdPlayerMap.clear();
		this.cdPlayerInfo = null;
	}
	
	/**
	 * @description:判断当人邀请人是否已满	
	 * @return
	 */
	@Transient
	public boolean isEnoughCheer(){
		if(this.cheerIdOne.equals(INIT_VALUE) || this.cheerIdTwo.equals(INIT_VALUE)){
			return false;
		}
		return true;
	}
	/**
	 * @description:设置邀请人	
	 * @param userId
	 */
	@Transient
	public void setCheerId(long userId){
		if(this.cheerIdOne.equals(INIT_VALUE)){
			this.cheerIdOne = userId;
		}else if(this.cheerIdTwo.equals(INIT_VALUE)){
			this.cheerIdTwo = userId;
		}

	}
	
	/**
	 * @description:清除邀请人信息	
	 *
	 */
	public void clearCheer() {
		this.cheerIdOne = INIT_VALUE;
		this.cheerOneState = RelationState.NONE.ordinal();
		this.cheerIdTwo = INIT_VALUE;
		this.cheerTwoState = RelationState.NONE.ordinal();
		this.formation = null;
		this.formationMap.clear();
	}
	/**
	 * @description:重新刷新	formationMap
	 *
	 */
	public void reflushFormationMap(){
		formationMap.clear();
		if(StringUtils.isNotBlank(this.formation)){
			String[] formationInfos = formation.split(Splitable.ELEMENT_SPLIT);
			String[] infoArray;
			for (String info : formationInfos) {
				infoArray = info.split(Splitable.ATTRIBUTE_SPLIT);
				long playerId = Long.valueOf(infoArray[0]);
				int index = Integer.parseInt(infoArray[1]);
				formationMap.put(index, playerId);
			}
		}
	}
	/**
	 * 根据位置返回对应的playerId
	 */
	public Long loadIdByIndex(int index){
		return formationMap.get(index);
	}
}

