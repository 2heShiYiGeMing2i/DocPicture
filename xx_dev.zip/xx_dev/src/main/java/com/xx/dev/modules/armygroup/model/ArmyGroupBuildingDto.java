package com.xx.dev.modules.armygroup.model;

import com.xx.dev.modules.armygroup.entity.ArmyGroupBuilding;

/**
 * 军团建筑DTO
 * 
 * @author Along
 *
 */
public class ArmyGroupBuildingDto {

	/**
	 * 建筑id
	 */
	private int id;
	
	/**
	 * 建筑等级
	 */
	private int level;
	
	/**
	 * 建筑完成度
	 */
	private int progress;
	
	public static ArmyGroupBuildingDto valueOf(ArmyGroupBuilding armyGroupBuilding) {
		ArmyGroupBuildingDto result = new ArmyGroupBuildingDto();
		result.setId(armyGroupBuilding.getBuildingId());
		result.setLevel(armyGroupBuilding.getLevel());
		result.setProgress(armyGroupBuilding.getProgress());
		return result;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

	public int getProgress() {
		return progress;
	}

	public void setProgress(int progress) {
		this.progress = progress;
	}
	
}
