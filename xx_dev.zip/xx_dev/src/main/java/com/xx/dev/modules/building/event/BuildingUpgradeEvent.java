package com.xx.dev.modules.building.event;

import com.xx.common.event.Event;

/**
 * 主城建筑升级事件
 * 
 * @author Along
 *
 */
public class BuildingUpgradeEvent {

	/**
	 * 事件名称
	 */
	public static String NAME = "Building:upgrade";
	
	/**
	 * 玩家id
	 */
	private Long id;
	
	/**
	 * 建筑id
	 */
	private int buildingId;
	
	/**
	 * 建筑等级
	 */
	private int buildingLevel;

	public static Event<BuildingUpgradeEvent> valueOf(Long id, int buildingId, int buildingLevel) {
		BuildingUpgradeEvent buildingUpgradeEvent = new BuildingUpgradeEvent();
		buildingUpgradeEvent.setId(id);
		buildingUpgradeEvent.setBuildingId(buildingId);
		buildingUpgradeEvent.setBuildingLevel(buildingLevel);
		return new Event<BuildingUpgradeEvent>(NAME, buildingUpgradeEvent);
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public int getBuildingId() {
		return buildingId;
	}

	public void setBuildingId(int buildingId) {
		this.buildingId = buildingId;
	}

	public int getBuildingLevel() {
		return buildingLevel;
	}

	public void setBuildingLevel(int buildingLevel) {
		this.buildingLevel = buildingLevel;
	}
	
}
