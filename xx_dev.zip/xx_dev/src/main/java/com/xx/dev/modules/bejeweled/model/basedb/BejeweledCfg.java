package com.xx.dev.modules.bejeweled.model.basedb;

import com.xx.common.basedb.anno.Id;
import com.xx.common.basedb.anno.Resource;

/**
 * Created by LiangZengle on 2014/6/23.
 */
@Resource
public class BejeweledCfg {
    public static final int ID = 1;
    /**
     * id=1
     */
    @Id
    private int id;

    /**
     * 自动消除消耗串
     */
    private String autoClearUpCost;

    /**
     * 每天增加步数的次数
     */
    private int addMoveTimes;

    /**
     * 最大步数
     */
    private int maxMoves;

    /**
     * 增加步数道具id
     */
    private int addMoveItemId;

    /**
     * 增加步数消耗的元宝
     */
    private String addMoveGold;

    /**
     * 开放等级
     */
    private int level;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAutoClearUpCost() {
        return autoClearUpCost;
    }

    public void setAutoClearUpCost(String autoClearUpCost) {
        this.autoClearUpCost = autoClearUpCost;
    }

    public int getAddMoveTimes() {
        return addMoveTimes;
    }

    public void setAddMoveTimes(int addMoveTimes) {
        this.addMoveTimes = addMoveTimes;
    }

    public int getMaxMoves() {
        return maxMoves;
    }

    public void setMaxMoves(int maxMoves) {
        this.maxMoves = maxMoves;
    }

    public int getAddMoveItemId() {
        return addMoveItemId;
    }

    public void setAddMoveItemId(int addMoveItemId) {
        this.addMoveItemId = addMoveItemId;
    }

    public String getAddMoveGold() {
        return addMoveGold;
    }

    public void setAddMoveGold(String addMoveGold) {
        this.addMoveGold = addMoveGold;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }
}
