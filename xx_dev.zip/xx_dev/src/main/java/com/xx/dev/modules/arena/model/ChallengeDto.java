package com.xx.dev.modules.arena.model;

/**
 * 挑战dto
 * 
 * @author bingshan
 */
public class ChallengeDto implements Comparable<ChallengeDto> {
	
	/**
	 * 挑战方id
	 */
	private long playerId;
	
	/**
	 * 挑战方名
	 */
	private String playerName;
	
	/**
	 * 被挑战方id
	 */
	private long rivalId;
	
	/**
	 * 被挑战方名
	 */
	private String rivalName;
	
	/**
	 * 挑战方是否胜利
	 */
	private boolean challengeWin = false;
	
	/**
	 * 之前挑战方名次
	 */
	private int playerRankBefore;
	
	/**
	 * 之后挑战方名次
	 */
	private int playerRankAfter;
	
	/**
	 * 之前被挑战方名次
	 */
	private int rivalRankBefore;
	
	/**
	 * 之后被挑战方名次
	 */
	private int rivalRankAfter;
	
	/**
	 * 挑战的时间(ms)
	 */
	private long challengeTime = 0;
	
	/**
	 * 是否挑战npc
	 */
	private boolean isChallengeNpc = false;

	public void set(long playerId, int playerRankBefore, long rivalId, int rivalRankBefore, long challengeTime) {
		this.playerId = playerId;
		this.rivalId = rivalId;
		this.challengeWin = false;
		this.playerRankBefore = playerRankBefore;
		this.playerRankAfter = playerRankBefore;
		this.rivalRankBefore = rivalRankBefore;
		this.rivalRankAfter = rivalRankBefore;
		this.challengeTime = challengeTime;
	}
	
	public void set(int playerRankAfter, int rivalRankAfter, boolean challengeWin) {
		this.playerRankAfter = playerRankAfter;
		this.rivalRankAfter = rivalRankAfter;
		this.challengeWin = challengeWin;
	}

	public long getPlayerId() {
		return playerId;
	}

	public void setPlayerId(long playerId) {
		this.playerId = playerId;
	}

	public String getPlayerName() {
		return playerName;
	}

	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}

	public long getRivalId() {
		return rivalId;
	}

	public void setRivalId(long rivalId) {
		this.rivalId = rivalId;
	}

	public String getRivalName() {
		return rivalName;
	}

	public void setRivalName(String rivalName) {
		this.rivalName = rivalName;
	}

	public boolean isChallengeWin() {
		return challengeWin;
	}

	public void setChallengeWin(boolean challengeWin) {
		this.challengeWin = challengeWin;
	}

	public int getPlayerRankBefore() {
		return playerRankBefore;
	}

	public void setPlayerRankBefore(int playerRankBefore) {
		this.playerRankBefore = playerRankBefore;
	}

	public int getPlayerRankAfter() {
		return playerRankAfter;
	}

	public void setPlayerRankAfter(int playerRankAfter) {
		this.playerRankAfter = playerRankAfter;
	}

	public int getRivalRankBefore() {
		return rivalRankBefore;
	}

	public void setRivalRankBefore(int rivalRankBefore) {
		this.rivalRankBefore = rivalRankBefore;
	}

	public int getRivalRankAfter() {
		return rivalRankAfter;
	}

	public void setRivalRankAfter(int rivalRankAfter) {
		this.rivalRankAfter = rivalRankAfter;
	}

	public long getChallengeTime() {
		return challengeTime;
	}

	public void setChallengeTime(long challengeTime) {
		this.challengeTime = challengeTime;
	}

	@Override
	public int compareTo(ChallengeDto o) {
		return this.challengeTime <= o.challengeTime ? 1 : -1;
	}

	public boolean isChallengeNpc() {
		return isChallengeNpc;
	}

	public void setChallengeNpc(boolean isChallengeNpc) {
		this.isChallengeNpc = isChallengeNpc;
	}
	
}
