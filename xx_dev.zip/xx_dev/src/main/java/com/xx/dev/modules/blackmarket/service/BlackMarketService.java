package com.xx.dev.modules.blackmarket.service;

import java.util.List;

import com.xx.dev.model.Result;
import com.xx.dev.modules.blackmarket.model.PlayerBlackMarketDto;
import com.xx.dev.modules.reward.result.ValueResultSet;

/**
 * 黑市服务接口
 * 
 * @author Along
 *
 */
public interface BlackMarketService {

	/**
	 * 返回玩家黑市信息
	 * @param playerId 玩家id
	 * @return
	 */
	public Result<PlayerBlackMarketDto> getBlackMarketAction(long playerId);
	
	/**
	 * 购买黑市物品
	 * @param playerId 玩家id
	 * @param index 物品序号
	 * @return
	 */
	public Result<PlayerBlackMarketDto> buyGoodsAction(long playerId, int index);
	
	/**
	 * 刷新黑市物品
	 * @param playerId 玩家id
	 * @return
	 */
	public Result<PlayerBlackMarketDto> refreshBlackMarketAction(long playerId);
	
	/**
	 * 黑市积分兑换
	 * @param playerId 玩家id
	 * @param id 物品id
	 * @param amount 数量
	 * @return
	 */
	public Result<PlayerBlackMarketDto> intergalChangeAction(long playerId, int id, int amount);

	/**
	 * 购买市场物品
	 * @param playerId 玩家id
	 * @param goodsId 物品id
	 * @param amount 数量
	 * @return
	 */
	public Result<ValueResultSet> changeGoodsAction(long playerId, int goodsId,
			int amount);

	/**
	 * 获取市场可购买商品id列表
	 * @param playerId 玩家id
	 * @param goodsType 商品类型
	 * @return
	 */
	public Result<List<Integer>> getGoodsIdsAction(long playerId, int goodsType);
	
} 
