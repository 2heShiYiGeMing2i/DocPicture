package com.xx.dev.modules.armygroup.model.basedb;

import com.xx.common.basedb.anno.Id;
import com.xx.common.basedb.anno.Resource;

/**
 * 军团建筑开放基础数据表
 * 
 * @author Along
 *
 */
@Resource
public class ArmyGroupBuildingOpen {

	/**
	 * 军团建筑id
	 */
	@Id
	private int id;
	
	/**
	 * 军团建筑名称
	 */
	private String buildingName;
	
	/**
	 * 开放等级（军团等级要求）
	 */
	private int openLevel;
	
	/**
	 * 初始等级
	 */
	private int initLevel;
	

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getBuildingName() {
		return buildingName;
	}

	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}

	public int getOpenLevel() {
		return openLevel;
	}

	public void setOpenLevel(int openLevel) {
		this.openLevel = openLevel;
	}

	public int getInitLevel() {
		return initLevel;
	}

	public void setInitLevel(int initLevel) {
		this.initLevel = initLevel;
	}
	
}
