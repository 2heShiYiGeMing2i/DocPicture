/**
 * @file:ResistCritEnhanceBuff.java
 * @author:David
 **/
package com.xx.dev.modules.battle.model;
/**
 * @class:ResistCritEnhanceBuff
 * @description:格挡伤害加强或降低
 * @author:David
 * @version:v1.0
 * @date:2013-4-30
 **/
public class ResistCritEnhanceBuff extends AbstractBuff {

	public ResistCritEnhanceBuff(int effectBaseValueType, double effectBase,
			int effectValueType, double effect, int startRound, int persistRound) {
		super(effectBaseValueType, effectBase, effectValueType, effect, startRound,
				persistRound);
	}

}

