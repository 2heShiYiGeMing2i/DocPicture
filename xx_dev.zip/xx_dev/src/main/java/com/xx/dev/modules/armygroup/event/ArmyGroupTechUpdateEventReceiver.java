package com.xx.dev.modules.armygroup.event;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xx.common.event.AbstractReceiver;
import com.xx.dev.modules.hero.model.HeroAttrSetType;
import com.xx.dev.modules.hero.service.HeroService;

/**
 * 军团科技升级事件接收器（军团科技升级的时候异步刷新所有没有上阵武将的科技属性）
 * 
 * @author Along
 *
 */
@Service
public class ArmyGroupTechUpdateEventReceiver extends AbstractReceiver<ArmyGroupTechUpdateEvent> {

	@Autowired
	private HeroService heroService;
	
	@Override
	public String[] getEventNames() {
		return new String[] {ArmyGroupTechUpdateEvent.NAME};
	}

	@Override
	public void doEvent(ArmyGroupTechUpdateEvent event) {
		// 刷新所有非上阵武将的军团武将科技属性
		this.heroService.refreshHerosAttr(event.getId(), HeroAttrSetType.ARMY_GROUP_TECH);
	}

}
