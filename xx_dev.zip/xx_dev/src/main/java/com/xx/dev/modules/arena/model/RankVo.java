package com.xx.dev.modules.arena.model;

/**
 * 排名信息
 * 
 * @author bingshan
 */
public class RankVo implements Comparable<RankVo> {

	/**
	 * 名次
	 */
	private int rank = 0;
	
	/**
	 * 玩家id
	 */
	private long playerId;
	
	/**
	 * 是否有人正在挑战此名次
	 */
	private boolean challenged = false;
	
	public static RankVo valueOf(int rank, long playerId) {
		RankVo r = new RankVo();
		r.rank = rank;
		r.playerId = playerId;
		return r;
	}

	public int getRank() {
		return rank;
	}

	public void setRank(int rank) {
		this.rank = rank;
	}

	public long getPlayerId() {
		return playerId;
	}

	public void setPlayerId(long playerId) {
		this.playerId = playerId;
	}

	public boolean isChallenged() {
		return challenged;
	}

	public void setChallenged(boolean challenged) {
		this.challenged = challenged;
	}

	@Override
	public int compareTo(RankVo o) {
		return this.getRank() <= o.getRank() ? -1 : 1;
	}
}
