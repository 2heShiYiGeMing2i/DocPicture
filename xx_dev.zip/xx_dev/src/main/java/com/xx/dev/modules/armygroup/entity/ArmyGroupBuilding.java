package com.xx.dev.modules.armygroup.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Index;

import com.xx.common.db.model.BaseModel;

/**
 * 军团建筑基础数据表
 * 
 * @author Along
 *
 */
@Entity
@Table(name = "armyGroupBuilding")
public class ArmyGroupBuilding extends BaseModel<String> {

	private static final long serialVersionUID = 3589516048807736552L;

	/**
	 * 主键（军团id_建筑id）
	 */
	@Id
	@Column(columnDefinition = "varchar(50) not null comment 'id'")
	private String id;
	
	/**
	 * 军团id
	 */
	@Column(columnDefinition = "bigint(20) not null comment '军团id'")
	private long armyGroupId;
	
	/**
	 * 建筑id
	 */
	@Index(name="armyGroupBuilding_idx_buildingId")
	@Column(columnDefinition = "int(11) not null comment '建筑id'")
	private int buildingId;
	
	/**
	 * 建筑等级
	 */
	@Column(columnDefinition = "int(11) default '0' comment '建筑等级'")
	private int level = 0;
	
	/**
	 * 完成度
	 */
	@Column(columnDefinition = "int(11) default '0' comment '完成度'")
	private int progress = 0;
	
	public ArmyGroupBuilding() {
		
	}
	
	public ArmyGroupBuilding(long armyGroupId, int buildingId, int initLevel) {
		this.id = getKey(armyGroupId, buildingId);
		this.armyGroupId = armyGroupId;
		this.buildingId = buildingId;
		this.level = initLevel;	
	}
	
	public static String getKey(long armyGroupId, int buildingId) {
		StringBuilder buf = new StringBuilder();
		buf.append(armyGroupId).append("_").append(buildingId);
		return buf.toString();
	}

	@Override
	public String getId() {
		return this.id;
	}

	@Override
	public void setId(String id) {
		this.id = id;
	}
	
	public long getArmyGroupId() {
		return armyGroupId;
	}

	public void setArmyGroupId(long armyGroupId) {
		this.armyGroupId = armyGroupId;
	}

	public int getBuildingId() {
		return buildingId;
	}

	public void setBuildingId(int buildingId) {
		this.buildingId = buildingId;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

	public int getProgress() {
		return progress;
	}

	public void setProgress(int progress) {
		this.progress = progress;
	}
	
}
