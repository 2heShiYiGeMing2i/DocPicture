package com.xx.dev.modules.blackmarket.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.xx.common.db.model.BaseModel;
import com.xx.common.util.Splitable;

/**
 * 玩家市场购买记录
 * 
 * @author Along
 *
 */
@Entity
@Table(name = "playerMarket")
public class PlayerMarket extends BaseModel<String> {

	private static final long serialVersionUID = 6761463126021788000L;

	/**
	 * 主键
	 */
	@Id
	@Column(columnDefinition = "varchar(50) NOT NULL COMMENT '主键'")
	private String id;
	
	/**
	 * 总购买数量
	 */
	@Column(columnDefinition = "bigint(20) default '0' COMMENT '总购买数量'")
	private Long totalAmount = 0l;
	
	/**
	 * 每日购买数量
	 */
	@Column(columnDefinition = "int(11) default '0' COMMENT '每日购买数量'")
	private Integer everydayAmount = 0;
	
	/**
	 * 购买物品的时间
	 */
	@Column(columnDefinition="datetime default '2013-01-01 00:00:00' comment '购买物品的时间'")
	private Date buyTime;
	
	public static PlayerMarket valueOf(int goodsId) {
		String key = String.valueOf(goodsId);
		PlayerMarket result = new PlayerMarket();
		result.setId(key);
		result.setBuyTime(new Date());
		return result;
	}
	
	public static PlayerMarket valueOf(long playerId, int goodsId) {
		String key = getKey(playerId, goodsId);
		PlayerMarket result = new PlayerMarket();
		result.setId(key);
		result.setBuyTime(new Date());
		return result;
	}
	
	public static String getKey(long playerId, int goodsId) {
		StringBuilder buf = new StringBuilder();
		buf.append(playerId).append(Splitable.ATTRIBUTE_SPLIT).append(goodsId);
		return buf.toString();
	}
	
	@Override
	public String getId() {
		return this.id;
	}

	@Override
	public void setId(String id) {
		this.id = id;
	}

	public Long getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(Long totalAmount) {
		this.totalAmount = totalAmount;
	}

	public Integer getEverydayAmount() {
		return everydayAmount;
	}

	public void setEverydayAmount(Integer everydayAmount) {
		this.everydayAmount = everydayAmount;
	}

	public Date getBuyTime() {
		return buyTime;
	}

	public void setBuyTime(Date buyTime) {
		this.buyTime = buyTime;
	}
	
}
