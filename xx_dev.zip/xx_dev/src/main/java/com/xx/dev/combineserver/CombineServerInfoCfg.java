package com.xx.dev.combineserver;

import java.util.TreeMap;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.support.PropertiesLoaderUtils;

/**
 * 合服数据库配置
 * 
 * @author Along
 *
 */
public class CombineServerInfoCfg {

	private static Logger logger = LoggerFactory.getLogger(CombineServerInfoCfg.class);

	private static final String CONFIG_FILE_NAME = "combineServerInfoCfg.properties";
	
	private static OrderedProperties properties = null;
	
	public static boolean ready = false;
	
	public static TreeMap<Integer, ServerInfo> serverInfos = new TreeMap<Integer, ServerInfo>();
	
	/**
	 * 刷新配置
	 */
	public static void init(String userName, String password){
		try {
			properties = new OrderedProperties();
			PropertiesLoaderUtils.fillProperties(properties, new ClassPathResource(CONFIG_FILE_NAME));
			int i = 1;
			for (Object keyObject : properties.keySet()) {
				String key = String.valueOf(keyObject);
				String jdbcUrl = String.valueOf(getProperty(key));
				if (StringUtils.isNotBlank(jdbcUrl)) {
					ServerInfo serverInfo = JdbcCfg.getServerCfg(jdbcUrl, userName, password);
					if (serverInfo != null) {
						serverInfos.put(i, serverInfo);
						i++;
					}
				}
			}
			ready = true;
		} catch (Exception e) {
			logger.error("加载合服数据库配置出错!", e);
		}
	}

	/**
	 * 获取属性
	 * @param key
	 * @return
	 */
	public static Object getProperty(String key){
		if(properties != null){
			return (Object) properties.get(key);
		}
		return null;
	}
	
}