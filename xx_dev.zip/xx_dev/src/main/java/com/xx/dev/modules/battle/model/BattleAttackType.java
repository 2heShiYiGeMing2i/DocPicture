/**
 * @file:BattleAttackType.java
 * @author:David
 **/
package com.xx.dev.modules.battle.model;
/**
 * @class:BattleAttackType
 * @description:战斗攻击类型
 * @author:David
 * @version:v1.0
 * @date:2013-4-22
 **/
public enum BattleAttackType {
	
	/**
	 * 0-无
	 */
	NONE,

	/**
	 * 1-普通攻击
	 */
	NORMAL_ATTACK,
	
	/**
	 * 2-技能攻击
	 */
	SKILL_ATTACK,
	
	/**
	 * 3-暴击
	 */
	CRIT
	
}

