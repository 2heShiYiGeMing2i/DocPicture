/**
 * @file:BattleType.java
 * @author:David
 **/
package com.xx.dev.constant;
/**
 * @class:BattleType
 * @description:战斗类型
 * @author:David
 * @version:v1.0
 * @date:2013-4-22
 **/
public enum BattleType {
	/**
	 * 无战斗,0
	 */
	NONE,
	
	/**
	 * 野外打怪 ,1
	 */
	PVE,

	/**
	 * 与玩家战斗,2
	 */
	PVP;
	
}

