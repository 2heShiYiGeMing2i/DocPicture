/**
 * @file:ArmageddonResult.java
 * @author:David
 **/
package com.xx.dev.modules.armageddon.handler;

import com.xx.dev.constant.CommonConstant;

/**
 * @class:ArmageddonResult
 * @description:
 * @author:David
 * @version:v1.0
 * @date:2013-5-21
 **/
public interface ArmageddonResult extends CommonConstant {
	/** 驻点未开放 **/
	int MISSION_NO_OPEN = -10001;
	/**
	 * 挂机中
	 */
	int HOOKING = -10002;
	
	/**
	 * 非顺序进入据点
	 */
	int ENTER_NOT_ORDER = -10003;
	
	/**
	 * 单人副本据点没有击破
	 */
	int SINGLE_FUBEN_NOT_BREAK = -10004;
	
	/**
	 * 小于据点开放等级不能进入据点
	 */
	int LT_OPEN_LEVEL = -10005;
	
	/**
	 * 没有接受据点开放任务
	 */
	int OPEN_TASK_NOT_RECIVED = -10006;
	
	/**
	 * 正在战斗
	 */
	int FIGHTING = -10007;
	
	/**
	 * 没有进入副本据点
	 */
	int NOT_ENTER_FUBEN = -10008;
	
	/**
	 * 非顺序打怪
	 */
	int ATTACK_ARMY_NOT_ORDER = -10009;
	
	/**
	 * 新手据点怪已经打过了
	 */
	int NEW_AREA_ARMY_ATTACKED = -10010;
	
	/**
	 * 必须领取奖励才能继续打
	 */
	int MUST_REWARD = -10011; 
	
	/**
	 * 收益次数不够
	 */
	int TIME_BUGOU = -10012;
	
	/**
	 * 前置单人副本据点未通关
	 */
	int FUBEN_NOT_BREAK = -10013;
	
	/**
	 * 战斗CD中
	 */
	int BATTLE_CD = -10014;
	
	/** 
	 * 无效出战人
	 */
	final int INVALID_CHEER = -10015;
	
	/** 已有出战人，不能重复邀请 **/
	final int HAS_INVALID_CHEER = -10016;
	
	/** 不在CD中，不能秒CD **/
	final int NOT_CD = -10017;
}

