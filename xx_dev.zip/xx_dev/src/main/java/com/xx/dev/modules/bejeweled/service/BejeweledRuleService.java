package com.xx.dev.modules.bejeweled.service;

import com.xx.dev.modules.bejeweled.model.BejeweledContext;
import com.xx.dev.modules.bejeweled.model.Goal;
import com.xx.dev.modules.bejeweled.model.basedb.BejeweledBox;
import com.xx.dev.modules.bejeweled.model.basedb.BejeweledCfg;

/**
 * Created by LiangZengle on 2014/6/21.
 */
public interface BejeweledRuleService {

    /**
     * 创建一个宝石迷阵
     *
     * @param playerId
     * @return
     */
    BejeweledContext newBejeweledContext(long playerId);

    /**
     * 根据等级获取宝箱配置
     *
     * @param boxLevel
     * @return
     */
    BejeweledBox getBox(int boxLevel);

    /**
     * 根据消除的方块数量获取对应的分数
     *
     * @param count
     * @return
     */
    int getScore(Integer count);

    /**
     * 宝箱迷阵配置
     *
     * @return
     */
    BejeweledCfg getBejeweledCfg();

    /**
     * 随机一个新目标
     *
     * @return
     */
    Goal randomGoal();

    /**
     * 随机自动消除个数
     *
     * @return
     */
    int randomAutoClearUpCount();

    /**
     * 根据目标获取得分
     *
     * @param goal
     * @return
     */
    int getAchieveGoalScore(Goal goal);
}
