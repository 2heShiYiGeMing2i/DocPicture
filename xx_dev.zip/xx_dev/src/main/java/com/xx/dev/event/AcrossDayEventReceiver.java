package com.xx.dev.event;

import org.springframework.stereotype.Component;

import com.xx.common.event.AbstractReceiver;


/**
 * 跨天事件接收器
 * 
 * @author bingshan
 */
@Component
public class AcrossDayEventReceiver extends AbstractReceiver<AcrossDayEvent> {

	@Override
	public String[] getEventNames() {
		return new String[] {AcrossDayEvent.NAME};
	}

	@Override
	public void doEvent(AcrossDayEvent event) {
		if (event == null) {
			log.error("'{}' 事件消息体为 NULL", AcrossDayEvent.NAME);
			return;
		}

	}

}
