package com.xx.dev.modules.arena.model.basedb;

import com.xx.common.basedb.anno.Id;
import com.xx.common.basedb.anno.Resource;


/**
 * 竞技场NPC
 * 
 * @author bingshan
 */
@Resource
public class ArenaNpc {

	/**
	 * 主键id
	 */
	@Id
	private int id;
	
	/**
	 * 战斗部队列表
	 */
	private String army;
	
	/**
	 * npc名称
	 */
	private String name;
	
	/**
	 * 等级
	 */
	private int level;
	
	/**
	 * 头像
	 */
	private int pic;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getArmy() {
		return army;
	}

	public void setArmy(String army) {
		this.army = army;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

	public int getPic() {
		return pic;
	}

	public void setPic(int pic) {
		this.pic = pic;
	}

	
}
