package com.xx.dev.modules.armygrouptrain.service;

import java.util.List;

import com.xx.dev.model.Result;
import com.xx.dev.modules.armygrouptrain.model.TrainDto;
import com.xx.dev.modules.armygrouptrain.model.TrainPlayerDto;
import com.xx.dev.modules.armygrouptrain.model.TrainPlayerRankDto;

public interface ArmyGroupTrainService {

	/**
	 * 攻击试炼军：不消耗兵力和體力
	 * @param playerId
	 * @param areaId
	 * @param armyId
	 * @return
	 */
	Result<TrainPlayerDto> attack(long playerId, int areaId, int armyId);

	/**
	 * 獲取本人軍團試煉信息
	 * @param playerId
	 * @return
	 */
	Result<TrainPlayerDto> getMyTrainInfo(long playerId);

	/**
	 * 獲取軍團試煉場景中的怪物和玩家信息
	 * @param playerId
	 * @return
	 */
	TrainDto getArmyGroupTrainInfo(long playerId);

	/**
	 * 離開試煉場景
	 * @param playerId
	 * @return
	 */
	void leaveTrainScene(long playerId);

	/**
	 * 獲取軍團試煉排名
	 * @param playerId
	 * @return
	 */
	Result<List<TrainPlayerRankDto>> getTrainRanks(long playerId);

	/**
	 * 移動
	 * @param playerId
	 * @param path
	 */
	void moveInTrainScene(long playerId, String path);

	/**
	 * 更新當前位置
	 * @param playerId
	 * @param curLoc
	 */
	void updateCurLocation(long playerId, String curLoc);

	/**
	 * 獲取當前位置
	 * @param playerId
	 * @return
	 */
	String getCurLocation(long playerId);

	/**
	 * 是否在軍團試煉活動時間內
	 * @param playerId
	 * @return
	 */
	boolean isArmyGroupTrain(long playerId);

	/**
	 * 刷新玩家在試煉場景中的信息
	 * @param playerId
	 */
	void updatePlayerInfo(long playerId);

	/**
	 * 將玩家從試煉場景移除
	 * @param playerId
	 */
	void playerLogin(long playerId);

	/**
	 * 當前狀態
	 * @param playerId
	 * @return
	 */
	Result<String> getCurStatus(long playerId);

}
