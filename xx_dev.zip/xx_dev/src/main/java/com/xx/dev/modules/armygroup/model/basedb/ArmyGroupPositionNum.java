package com.xx.dev.modules.armygroup.model.basedb;

import com.xx.common.basedb.anno.Id;
import com.xx.common.basedb.anno.Resource;

/**
 * 军团职位人数
 * 
 * @author Along
 *
 */
@Resource
public class ArmyGroupPositionNum {

	/**
	 * 职位id
	 */
	@Id
	private int id;
	
	/**
	 * 最大人数
	 */
	private int maxCount;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getMaxCount() {
		return maxCount;
	}

	public void setMaxCount(int maxCount) {
		this.maxCount = maxCount;
	}
	
}
