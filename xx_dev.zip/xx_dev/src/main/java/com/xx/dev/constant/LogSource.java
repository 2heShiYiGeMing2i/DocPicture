package com.xx.dev.constant;

/**
 * 日志源定义[模块号+命令，各占2位]
 * 
 * @author Along
 * 
 */
public interface LogSource {

	// ----------管理后台0-----------------
	/**
	 * 加货币
	 */
	int ADD_MONEY = 7;

	/**
	 * 减货币
	 */
	int REDUCE_MONTY = 8;

	// ----------主公模块1------------------
	/**
	 * 升官
	 */
	int PLAYER_PROMOTE = 105;

	/**
	 * 领取俸禄
	 */
	int RECEIVE_SALARY = 106;

	/**
	 * 自动增加体力
	 */
	int AUTO_ADD_ENERGY = 107;

	/**
	 * 购买体力
	 */
	int BUY_ENERGY = 108;

	/**
	 * 用道具增加体力
	 */
	int ADD_ENERTY_WITH_ITEM = 109;

	/**
	 * 用道具直接升级
	 */
	int ADD_LEVEL_WITH_ITEM = 110;
	
	/**
	 * 自动升级（修复）
	 */
	int AUTO_ADD_LEVEL = 111;

	// ------------聊天2-----------------
	/**
	 * 世界频道聊天
	 */
	int CHITCHAT_WORLD_TALK = 201;

	// ------------邮件3-----------------
	/**
	 * 发送玩家私人邮件
	 */
	int MAIL_SEND_PLAYER_MAIL = 303;

	/**
	 * 发送军团邮件
	 */
	int MAIL_SEND_ARMY_GROUP_MAIL = 309;

	/**
	 * 提取附件
	 */
	int MAIL_GET_ADDTION_FROM_PLAYERMAIL = 311;

	/**
	 * 提取所有的附件
	 */
	int MAIL_GET_ADDTIONS_FROM_PLAYERMAIL = 312;

	// ------------武将4-------------------------
	/**
	 * 武将升级
	 */
	int HERO_UPGRADE_LEVEL = 402;

	/**
	 * 武将进化
	 */
	int HERO_EVOLVE = 403;

	/**
	 * 武将觉醒
	 */
	int HERO_AWAKE = 404;

	/**
	 * 武将下野
	 */
	int HERO_DISBAND = 405;

	/**
	 * 武将升级天赋等级
	 */
	int HERO_UPGRADE_TALENT_LEVEL = 407;

	/**
	 * 重置武将天赋技能
	 */
	int HERO_RESET_TALENT = 408;

	/**
	 * 武将天赋传承
	 */
	int HERO_INHERIT_TALENT = 409;

	/**
	 * 一键补兵
	 */
	int HERO_AUTO_ADD_SOLDIERS = 411;

	/**
	 * 自定义武将改名
	 */
	int CUSTOM_HERO_RENAME = 412;
	
	/**
	 * 宝石共鸣等级升级
	 */
	int RESONATE_LEVEL_UPGRADE = 413;
	
	/**
	 * 传承宝石共鸣
	 */
	int INHERIT_JEWEL_RESONATE = 414;
	
	/**
	 * 武将传授
	 */
	int HERO_TEACH = 415;
	
	/**
	 * 武将战魄技能升级
	 */
	int HERO_SOUL_SKILL_UPGRADE = 416;
	
	// ------------兵营5-------------------
	/**
	 * 升级兵阶
	 */
	int BARRACKS_UPGRADE_SOLDIER_STAR = 503;

	/**
	 * 招募士兵
	 */
	int BARRACKS_RECRUIT_SOLDIERS = 504;

	/**
	 * 遣散士兵
	 */
	int BARRACKS_DISBAND_SOLDIERS = 505;

	// ----------冷却队列7-------------------
	/**
	 * 购买冷却队列
	 */
	int COOLQUEUE_BUY_QUEUE = 702;

	/**
	 * 清除单个队列的冷却时间
	 */
	int COOLQUEUE_CLEAR_COOLTIME = 703;

	/**
	 * 清除所有队列的冷却时间
	 */
	int COOLQUEUE_CLEAR_COOLTIMES = 704;

	// ----------主城建筑6------------------
	/**
	 * 建筑品质升级
	 */
	int BUILDING_QUALITY_UPGRADE = 602;

	/**
	 * 建筑等级升级
	 */
	int BUILDING_LEVEL_UPGRADE = 603;

	// ------------单人副本8----------------
	/**
	 * 挂机
	 */
	int CHAPTER_HOOK = 801;

	// ------------道具9---------------------
	/**
	 * 开宝箱
	 */
	int ITEM_OPEN_BOXITEM = 901;

	/**
	 * 道具合成
	 */
	int ITEM_COMBINE = 902;

	/**
	 * 宝石道具转换
	 */
	int ITEM_CONVERT = 903;

	/**
	 * 使用粮食卡
	 */
	int ITEM_USE_FOODS_CARD = 904;

	/**
	 * 使用武将经验卡
	 */
	int ITEM_USE_SOUL_CARD = 905;

	/**
	 * 使用大喇叭
	 */
	int ITEM_USE_TYPHON = 906;

	/**
	 * 使用Buff
	 */
	int ITEM_USE_BUFF = 907;

	/**
	 * 使用升级酒
	 */
	int ITEM_USE_UPGRADE_LEVEL_LIQUOR = 908;

	/**
	 * 使用体力酒
	 */
	int ITEM_USE_ENERGY_LIQUOR = 909;

	/**
	 * 使用水晶卡
	 */
	int ITEM_USE_CRYSTAL_CARD = 910;

	/**
	 * 使用贡献丹
	 */
	int ITEM_USE_CONTRIBUTION_PILL = 911;

	/**
	 * 使用改名卡
	 */
	int ITEM_USE_RENAME_CARD = 912;

	/**
	 * 使用玉玺（增加体力上限）
	 */
	int ITEM_USE_IMPERIAL_JADE_SEAL = 913;

	/**
	 * 使用扩府令
	 */
	int ITEM_USE_ADD_HERO_ORDER = 914;

	/**
	 * 使用临时VIP卡
	 */
	int ITEM_USE_TMP_VIP_CARD = 915;

	/**
	 * 使用VIP卡
	 */
	int ITEM_USE_VIP_CARD = 916;

	/**
	 * 使用VIP成长卡
	 */
	int ITEM_USE_VIP_GROW_UP_CARD = 917;

	/**
	 * 使用武将卡
	 */
	int ITEM_USE_HERO_CARD = 918;

	/**
	 * 使用银元卡
	 */
	int ITEM_USE_SILVER_CARD = 919;

	/**
	 * 开命签宝箱
	 */
	int ITEM_OPEN_DIVINATION_BOXITEM = 920;

	/**
	 * 使用战魂卡
	 */
	int ITEM_USE_DRILL_EXP_CARD = 921;

	/**
	 * 使用银两强征令
	 */
	int ITEM_USE_SILVER_IMPRESS_ORDER = 922;

	/**
	 * 使用粮食强征令
	 */
	int ITEM_USE_FOODS_IMPRESS_ORDER = 923;
	
	/**
	 * 使用普通骰子卡
	 */
	int ITEM_USE_COMMON_DICE_CARD = 924;
	
	/**
	 * 使用超级骰子卡
	 */
	int ITEM_USE_SUPPER_DICE_CARD = 925;
	
	/**
	 * 使用经验丹
	 */
	int ITEM_USE_PLAYER_EXP_PILL = 926;
	
	/**
	 * 使用主将技能书
	 */
	int ITEM_USE_CAPTRAIN_SKILL_BOOK = 927;
	
	/**
	 * 使用坐骑卡
	 */
	int ITEM_USE_HORSE_CARD = 928;

	/**
	 * 使用灵翼卡
	 */
	int ITEM_USE_NETHERWING_CARD = 929;
	
	/**
	 * 使用时装卡
	 */
	int ITEM_USE_FASHION_EQUIP_CARD = 930;
	
	// ---------------单人副本10----------------
	/**
	 * 据点通关
	 */
	int BREAK_MISSION = 1001;

	// ---------------背包11----------------
	/**
	 * 开启背包格子
	 */
	int PACK_OPEN_CELL = 1102;

	/**
	 * 购买背包格子
	 */
	int PACK_BUY_CELL = 1104;

	/**
	 * 物品出售（单个）
	 */
	int GOODS_SAIL = 1105;
	
	/**
	 * 物品出售（批量）
	 */
	int BATCH_GOODS_SAIL = 1106;

	/**
	 * 物品回购
	 */
	int GOODS_BUYBACK = 1107;

	// ---------------技能12----------------
	/**
	 * 技能升级
	 */
	int SKILL_UPGRADE = 1201;

	/**
	 * 技能传承
	 */
	int SKILL_IMPART = 1202;
	
	/**
	 * 传承主动技能
	 */
	int INHERIT_ACTIVE_SKILL = 1203;
	
	/**
	 * 龙将战魄技能升级
	 */
	int CUSTOM_HERO_SOUL_SKILL_UPGRADE = 1204;

	// ---------------远征异族13------------
	/**
	 * 远征异族
	 */
	int INVADE = 1301;
	/**
	 * 远征异族购买次数
	 */
	int INVADE_BUY = 1302;
	/**
	 * 远征异族商店兑换
	 */
	int INVADE_SHOP = 1303;
	// ----------------税收14---------------

	/**
	 * 征收取粮草税收
	 */
	int RECEIVE_FOODS_REVENUE = 1401;

	/**
	 * 征收取银元税收
	 */
	int RECEIVE_SILVER_REVENUE = 1402;

	/**
	 * 强征粮草税收
	 */
	int PRESS_RECEIVE_FOODS_REVENUE = 1403;

	/**
	 * 强征银元税收
	 */
	int PRESS_RECEIVE_SILVER_REVENUE = 1404;

	/**
	 * 清除征收粮草冷却时间
	 */
	int CLEAR_FOODS_COOLTIME = 1406;

	/**
	 * 清除征收银元冷却时间
	 */
	int CLEAR_SILVER_COOLTIME = 1407;

	// ----------------酒馆15---------------

	/**
	 * 酒馆刷将
	 */
	int PUB_REFRESH_HERO = 1501;

	/**
	 * 招募武将
	 */
	int PUB_RECRUIT_HERO = 1502;

	/**
	 * 卖出武将卡
	 */
	int PUB_SELL_HERO = 1503;

	/**
	 * 商店兑换
	 */
	int PUB_EXCHANGE = 1504;

	/**
	 * 酒馆阵营招募设定
	 */
	int PUB_CHANGE_CAMP = 1505;

	// ------------ 精英副本16 ---------------------
	/**
	 * 挂机
	 */
	int CREAM_HOOK = 1601;
	/**
	 * 精英副本通关
	 */
	int CREAM_BREAK = 1602;

	// --------------武将装备17----------

	/**
	 * 装备强化
	 */
	int HERO_EQUIP_STRENGTHEN = 1706;

	/**
	 * 装备升阶
	 */
	int HERO_EQUIP_UPGRADE = 1707;

	/**
	 * 装备进化
	 */
	int HERO_EQUIP_EVOLVE = 1708;

	/**
	 * 装备精炼
	 */
	int HERO_EQUIP_REFINE = 1709;

	/**
	 * 镶嵌宝石
	 */
	int HERO_EQUIP_INLAY_JEWEL = 1710;

	/**
	 * 装备洗炼
	 */
	int HERO_EQUIP_BAPTIZE = 1711;

	/**
	 * 装备打孔
	 */
	int HERO_EQUIP_OPEN_SLOT = 1712;

	/**
	 * 装备分解
	 */
	int HERO_EQUIP_DIV = 1713;

	/**
	 * 拆卸宝石
	 */
	int HERO_EQUIP_STRIKE_JEWEL = 1714;

	/**
	 * 装备神铸
	 */
	int HERO_EQUIP_CAST = 1715;
	
	/**
	 * 宝石升级
	 */
	int HERO_EQUIP_JEWEL_ITEM_UPGRADE = 1716;
	
	/**
	 * 购买宝石升级道具
	 */
	int HERO_EQUIP_BUY_JEWEL_UPGRADE_ITEM = 1717;
	
	/**
	 * 装备附魔
	 */
	int HERO_EQUIP_ENHANCE = 1718;

	// ----------------好友18---------------
	/**
	 * 好友鲜花
	 */
	int RELATION_FLOW = 1801;
	/**
	 * 邀请助阵
	 */
	int RELATION_CHEER = 1802;
	/**
	 * 好友祝福
	 */
	int FRIEND_BLESS = 1803;
	// ----------------科技19---------------

	/**
	 * 科技升级
	 */
	int TECH_UPGRADE = 1902;

	// -----------------军阵科技20----------

	/**
	 * 军阵科技升级
	 */
	int DRILL_TECH_UPGRADE = 2002;

	// -----------------征战天下21----------

	/**
	 * 征战天下使用道具增加次数
	 */
	int JOURNEY_USE_ITEM = 2101;

	/**
	 * 征战天下复活
	 */
	int JOURNEY_REVIVE = 2102;

	/**
	 * 征战 成就丰碑 排行榜奖励领取
	 */
	int JOURNEY_REWARD = 2103;
	/**
	 * 挂机
	 */
	int JOURNEY_HOOK = 2104;
	/**
	 * 挂机奖励
	 */
	int JOURNEY_HOOK_RWARD = 2105;

	// ---------------- 任务 22--------------
	/**
	 * 任务奖励
	 */
	int TASK_REWARD = 2201;

	/**
	 * 任务立即结束
	 */
	int TASK_DONE_FAST = 2202;

	// -----------------民心事件23------------

	/**
	 * 领取民心事件奖励
	 */
	int WISH_EVENT_RECEIVE_EVENT_REWARD = 2302;

	/**
	 * 每日民心兑换奖励
	 */
	int WISH_EVENT_STAR_CHANGE_REWARD = 2304;

	/**
	 * 刷新官府事件
	 */
	int WISH_EVENT_REFRESH_EVENT = 2303;

	/**
	 * 用5星符刷新官府事件
	 */
	int WISH_EVENT_REFRESH_EVENT_WITH_ITEM = 2305;

	// ----------------大决战 24-------------------

	/**
	 * 大决战据点通关
	 */
	int BREAK_ARMAGEDDON = 2401;
	/**
	 * 邀请助阵
	 */
	int ARMAGEDDON_CHEER = 2402;
	// ----------------黑市 25-------------------

	/**
	 * 黑市购买物品
	 */
	int BLACK_MARKET_BUY_GOODS = 2502;

	/**
	 * 黑市刷新物品
	 */
	int BLACK_MARKET_REFRESH_GOODS = 2503;

	/**
	 * 黑市积分兑换
	 */
	int BLACK_MARKET_INTERVAL_CHANGE = 2504;

	/**
	 * 市场购买物品
	 */
	int MARKET_BUY_GOODS = 2505;

	// ------------------命签26---------------------

	/**
	 * 求签（1个）
	 */
	int DIVINATION_TAKE_DIVINATION = 2601;

	/**
	 * 一键求签
	 */
	int DIVINATION_TAKE_DIVINATIONS = 2602;

	/**
	 * 出售命签（1个）
	 */
	int DIVINATION_SAIL_DIVINATION = 2603;

	/**
	 * 一键出售命签
	 */
	int DIVINATION_SAIL_DIVINATIONS = 2604;

	/**
	 * 购买命签背包格子
	 */
	int DIVINATION_BUY_CELL = 2605;
	
	/**
	 * 购买命签升级道具
	 */
	int DIVINATION_BUY_DIVINATION_UPGRADE_ITEM = 2606;
	
	/**
	 * 命签道具升级
	 */
	int DIVINATION_ITEM_UPGRADE = 2607;
	
	// -------------------27（攻城掠地）----------------------
	/**
	 * 掠夺玩法奖励
	 */
	int PLUNDER_PLAYER = 2701;
	/**
	 * 掠夺使用保护令
	 */
	int PLUNDER_PROTECT = 2702;
	/**
	 * 鼓舞
	 */
	int PLUNDER_INSPIRE = 2703;
	/**
	 * 攻城掠地购买次数
	 */
	int PLUNDER_BUY = 2704;
	/**
	 * 攻城掠地侦查
	 */
	int PLUNDER_LOOK = 2705;
	// -----------------28 竞技场---------------------------
	/**
	 * 竞技场秒CD
	 */
	int ARENA_ELIMINATE_CD = 2801;

	/**
	 * 竞技场翻牌
	 */
	int ARENA_TURN_CARD = 2802;

	/**
	 * 竞技场购买次数
	 */
	int ARENA_BUY_COUNT = 2803;

	/**
	 * 竞技场挑战
	 */
	int ARENA_CHALLENGE = 2804;

	/**
	 * 竞技场宝箱奖励
	 */
	int ARENA_BOX_REWARD = 2805;

	/**
	 * 竞技场侦查
	 */
	int ARENA_SPY = 2806;
	
	/**
	 * 竞技场日排行奖励
	 */
	int ARENA_DAY_RANK_REWARD = 2807;

	// ------------------29军团---------------------
	/**
	 * 创建军团
	 */
	int ARMY_GROUP_CREATE = 2901;

	/**
	 * 购买虎符
	 */
	int ARMY_GROUP_BUY_HUFU = 2902;

	/**
	 * 领取每日粮草福利
	 */
	int ARMY_GROUP_RECEIVE_FOODS = 2903;

	/**
	 * 领取每日武将经验福利
	 */
	int ARMY_GROUP_RECEIVE_HERO_SOUL = 2904;

	/**
	 * 购买军团商城商品
	 */
	int ARMY_GROUP_BUY_GOODS = 2905;

	/**
	 * 捐赠虎符
	 */
	int ARMY_GROUP_CONTRIBUTE_HUFU = 2906;

	/**
	 * 清除冷却时间
	 */
	int ARMY_GROUP_CLEAR_COOL_TIME = 2907;

	// -----------------30 群雄争霸-----------

	/**
	 * 群雄争霸奖励
	 */
	int CHAMPIONSHIP_REWARD = 3001;

	// ---------------新手副本31----------------
	/**
	 * 新手副本据点通关
	 */
	int NEW_BREAK_MISSION = 3101;

	// ---------------商城32----------------
	/**
	 * 商城购买
	 */
	int SHOP_BUY = 3201;

	// -----------------每日税收 33-----------
	/**
	 * 每日税收领取
	 */
	int DAY_REVENUE = 3301;
	// -------------------------------------

	// ---------------目标系统 34-------------------

	/**
	 * 目标系统章节奖励
	 */
	int GOAL_CHAPTER_REWARD = 3401;

	// ---------------礼包系统 36-------------------
	/**
	 * 在线礼包
	 */
	int ONLINE_GIFT = 3601;
	/**
	 * 连续登录礼包
	 */
	int CONTIN_GIFT = 3602;
	/**
	 * CDkey礼包
	 */
	int CDKEY_GIFT = 3603;
	/**
	 * 连续礼包
	 */
	int LEVEL_GIFT = 3604;

	/**
	 * 三天礼包领吕布
	 */
	int THREE_DAYS_GIFT = 3605;
	
	/**
	 * 一次性礼包
	 */
	int ONE_TIME_GIFT = 3606;
	
	/**
	 * 累计登陆礼包
	 */
	int LOGIN_DAYS_GIFT = 3607;

	// ---------------日行一善 37-------------------
	/**
	 * 日行一善
	 */
	int GOODNESS = 3701;
	// ---------------VIP系统 38-------------------
	/**
	 * VIP系统
	 */
	int VIP = 3801;
	/**
	 * vip特惠商店
	 */
	int VIP_SHOP = 3802;
	// ----------------每日奖励指引39--------------

	/**
	 * 每日奖励指引 获取活跃度奖励
	 */
	int DAILY_GUIDE_VITALITY_REWARD = 3901;

	// ---------------猛将录40-------------------
	/**
	 * 领取猛将录奖励
	 */
	int HERO_COLLECT_GET_REWARD = 4001;

	/**
	 * 碎片兑换武将
	 */
	int HERO_COLLECT_PIECE_CHANGE_HERO = 4002;

	// ---------------神兵活动 41-----------------
	/**
	 * 神兵活动主公等级排行榜奖励
	 */
	int MAGIC_PLAYER_LEVEL_RANK_REWARD = 4101;

	/**
	 * 神兵活动战斗力排行榜奖励
	 */
	int MAGIC_ABILITY_RANK_REWARD = 4102;

	/**
	 * 神兵活动宝石总等级排行榜奖励
	 */
	int MAGIC_JEWEL_RANK_REWARD = 4103;

	/**
	 * 神兵活动总消费排行榜奖励
	 */
	int MAGIC_CONSUME_RANK_REWARD = 4104;

	/**
	 * 神兵活动军团等级排行榜奖励
	 */
	int MAGIC_GUILD_LEVEL_RANK_REWARD = 4105;
	
	/**
	 * 神兵活动竞技场排行榜奖励
	 */
	int MAGIC_ARENA_RANK_REWARD = 4106;
	
	/**
	 * 神兵活动图腾等级排行榜奖励
	 */
	int MAGIC_TOTEM_RANK_REWARD = 4107;


	// ---------------排行榜43--------------------
	/**
	 * 领取等级排行榜奖励
	 */
	int RANK_RECEIVE_LEVEL_RANK_REWARD = 4301;

	/**
	 * 领取战斗力排行榜奖励
	 */
	int RANK_RECEIVE_ABILITY_RANK_REWARD = 4302;

	/**
	 * 领取属性目标奖励
	 */
	int RANK_RECEIVE_ATTR_REWARD = 4303;

	// ---------------一夫当关44-------------------

	/**
	 * 一夫当关积分排名奖励
	 */
	int MANPASS_RANK_REWARD = 4401;

	/**
	 * 一夫当关挑战次数奖励
	 */
	int MANPASS_TIME_REWARD = 4402;

	/**
	 * 一夫当关商城兑换s
	 */
	int MANPASS_EXCHANGE = 4403;

	/**
	 * 一夫当关挂机加速
	 */
	int MANPASS_HOOK_SPEED = 4404;
	
	/**
	 * 一夫当关购买挑战次数
	 */
	int MANPASS_BUY_COUNT = 4405;

	// --------------46 新精英副本-------------------

	/**
	 * 重置次数
	 */
	int NEWCREAM_RESET = 4601;

	/**
	 * 精英副本商店
	 */
	int NEWCREAM_SHOP = 4602;

	/**
	 * 新精英副本挂机
	 */
	int NEWCREAM_CLEAN = 4603;
	// ----------------成长基金47--------------------
	/**
	 * 购买成长基金
	 */
	int FUND_BUY_FUND = 4701;

	/**
	 * 领取返还基金
	 */
	int FUND_RECEIVE_FUND = 4702;

	/**
	 * 赠送好友基金
	 */
	int FUND_SEND_FUND = 4703;

	// ----------------临时背包49--------------------

	/**
	 * 临时背包物品入背包
	 */
	int TEMP_BAG_FETCH_GOODS = 4901;

	// ----------------奴隶系统50--------------------

	/**
	 * 奴隶系统奖励
	 */
	int SLAVE_RWARD = 5001;

	// ----------------神兵抽奖51--------------------
	/**
	 * 神兵抽奖积分商店兑换
	 */
	int EQUIP_RAFFLE_INTEGRAL_EXCHANGE = 5101;

	/**
	 * 神兵抽奖
	 */
	int EQUIP_RAFFLE = 5102;

	// ----------------军团抢粮 52--------------------

	/**
	 * 军团抢粮
	 */
	int PLUNDER_FOOD = 5201;

	// ----------------跑环玩法 54--------------------
	/**
	 * 普通骰子
	 */
	int LOOP_COMMON_DICE = 5401;
	/**
	 * 超级骰子
	 */
	int LOOP_LUCK_DICE = 5402;
	
	/**跑环商城*/
	int LOOP_SHOP = 5403;
	
	/**跑环-任务奖励*/
	int LOOP_TASK=5404;
	
	/**跑环宝箱*/
	int LOOP_BOX=5405;
	
	/**击杀boss*/
	int LOOP_KILL_BOSS=5406;
	
	/**攻击boss*/
	int LOOP_ATTACK_BOSS=5407;
	
	/**积分商城*/
	int LOOP_SCORE_SHOP = 5408;
	
	/**创建boss*/
	int LOOP_CREATE_BOSS=5409;
	
	/**
	 * 立即复活
	 */
	int LOOP_REVIVE = 5410;
	
	/**
	 * boss超时，攻击次数超过10次获得元宝奖励
	 */
	int LOOP_BOSS_TIMEOUT = 5411;
	
	//----------------摸金 55--------------------
	
	/**
	 * 摸金开启活动
	 */
	int TREASURE_OPEN_ACT = 5501;
	
	/**
	 * 摸金系统摸金
	 */
	int TREASURE_HUNT = 5502;
	
	//----------------有福同享56--------------------
	
	/**
	 * 领取全服任务奖励1
	 */
	int SERVER_TASK_RECEIVE_REWARD1 = 5601;
	
	/**
	 * 领取全服任务奖励2
	 */
	int SERVER_TASK_RECEIVE_REWARD2 = 5602;
	
	/**
	 * 领取全服任务奖励3
	 */
	int SERVER_TASK_RECEIVE_REWARD3 = 5603;
	
	/**
	 * 领取全服任务奖励4
	 */
	int SERVER_TASK_RECEIVE_REWARD4 = 5604;
	
	/**
	 * 领取VIP礼包奖励1
	 */
	int SERVER_TASK_RECEIVE_GIFT1 = 5605;
	
	/**
	 * 领取VIP礼包奖励2
	 */
	int SERVER_TASK_RECEIVE_GIFT2 = 5606;
	
	/**
	 * 领取VIP礼包奖励3
	 */
	int SERVER_TASK_RECEIVE_GIFT3 = 5607;
	
	/**
	 * 领取VIP礼包奖励4
	 */
	int SERVER_TASK_RECEIVE_GIFT4 = 5608;
	
	/**
	 * 领取摸金礼包奖励1
	 */
	int SERVER_TASK_RECEIVE_TREASURE_GIFT1 = 5609;
	
	/**
	 * 领取摸金礼包奖励2
	 */
	int SERVER_TASK_RECEIVE_TREASURE_GIFT2 = 5610;
	
	/**
	 * 领取摸金礼包奖励3
	 */
	int SERVER_TASK_RECEIVE_TREASURE_GIFT3 = 5611;
	
	/**
	 * 领取摸金礼包奖励4
	 */
	int SERVER_TASK_RECEIVE_TREASURE_GIFT4 = 5612;
	
	
	// ---------------360红钻vip 57-------------------
	
	/**
	 * 360红钻等级礼包
	 */
	int REDVIP_LEVEL_GIFT = 5701;
	
	/**
	 * 360红钻每日礼包
	 */
	int REDVIP_DAILY_GIFT = 5702;
	
	/**
	 * 360红钻年费礼包
	 */
	int REDVIP_YEAR_GIFT = 5703; 
	
	// ---------------vip副本 58-------------------
	
	/**
	 * vip副本奖励
	 */
	int VIP_FUBEN_REWARD = 5801;
	
	/**
	 * vip副本扫荡奖励
	 */
	int VIP_FUBEN_ALL_FINISH_REWARD = 5802;
	
	// ---------------360安全卫士特权礼包 59-------------------
	
	/**
	 * 360安全卫士特权礼包
	 */
	int PRIVILEGE_LEVEL_GIFT = 5901;
	
	// -----------------60决战长安---------------------
	
	/**
	 * 决战长安复活
	 */
	int DECISIVE_CHANG_AN_RELIVE = 6001;
	
	/**
	 * 领取活动奖励
	 */
	int DECISIVE_RECEIVE_ACTIVITY_REWARD = 6002;
	
	/**
	 * 领取军团奖励
	 */
	int DECISIVE_RECEIVE_ARMYGROUP_REWARD =6003;
	
	/**
	 * 领取积分奖励
	 */
	int DECISIVE_RECEIVE_INTEGRAL_REWARD = 6004;
	
	// -----------------61图腾-----------------------
	
	/**
	 * 使用灵
	 */
	int TOTEM_USE_SPIRIT = 6101;
	
	/**
	 * 使用魂
	 */
	int TOTEM_USE_SOUL = 6102;
	
	/**
	 * 图腾升阶
	 */
	int TOTEM_UPGRADE = 6103;
	
	/**
	 * 领取图腾活动奖励
	 */
	int TOTEM_RECEIVE_REWARD = 6104;
	
	/**
	 * 使用图腾卡激活图腾
	 */
	int USE_TOTEM_CARD = 6105;
	
	
	// ----------------迅雷会员礼包--------------------
	/**
	 * 迅雷会员金卡等级礼包
	 */
	int XUNLEI_MEMBER_LEVEL_GIFT = 6201;
	
	/**
	 * 迅雷会员礼包
	 */
	int XUNLEI_MEMBER_GIFT = 6202;
	
	/**
	 * 迅雷会员礼包
	 */
	int XUNLEI_MEMBER_DAILY_GIFT = 6203;
	
	
	// ----------------YY会员礼包--------------------
	/**
	 * YY等级vip每日礼包
	 */
	int YY_MEMBER_DAILY_GIFT = 6204;
	
	/**
	 * 季度YY会员礼包
	 */
	int YY_MEMBER_SEASON_GIFT = 6205;
	
	/**
	 * 年度YY会员礼包
	 */
	int YY_MEMBER_YEAR_GIFT = 6206;
		
	
	// ----------------折扣商店 63--------------------
	
	/**
	 * 折扣商店购买
	 */
	int DISCOUNT_SHOP_BUY = 6301;
	
	
	// ---------------- 理财计划 65  -----------------
	
	/**
	 * 购买周理财计划
	 */
	int MONEY_PLAN_WEEK_BUY = 6501;
	
	/**
	 * 领取周理财计划 期数奖励
	 */
	int RECEIVE_WEEK_PHASE = 6502;
	
	/**
	 * 购买月理财计划
	 */
	int MONEY_PLAN_MONTH_BUY = 6503;
	
	/**
	 * 领取月理财计划 期数奖励
	 */
	int RECEIVE_MONTH_PHASE = 6504;
	
	//----------------- 多人副本 66  -----------------
	
	/**
	 * 多人副本攻击npc奖励
	 */
	int MULTIFUBEN_ATTACK_NPC_REWARD = 6601;
	
	/**
	 * 多人副本购买锯子令
	 */
	int MULTIFUBEN_BUY_JZL = 6602;
	
	
	//----------------- 积分活动 67  -----------------
	
	/**
	 * 购买爆竹消耗元宝
	 */
	int INTEGRATION_BUY_BOMB = 6701;
	
	/**
	 * 购买爆竹获得道具
	 */
	int INTEGRATION_OBTION_REWARD = 6702;
	
	/**
	 * 积分商店购买物品
	 */
	int INTEGRATION_BUY_GOODS = 6703;

	/**
	 * 积分商店购买物品消耗元宝
	 */
	int INTEGRATION_BUY_GOODS_COST_GOLD = 6704;
	
	/**
	 * 购买爆竹
	 */
	int INTEGRATION_BUY_BOMB_REWARD = 6705;
	
	/**
	 * 攻击神兽 奖励
	 */
	int INTEGRATION_ATTACK_MONSTER = 6711;
	
	/**
	 * 祝福好友 本人获得奖励
	 */
	int INTEGRATION_BLESS_REWARD = 6712;
	
	/**
	 * 领取好友祝福礼包
	 */
	int INTEGRATION_RECEIVE_GIFT = 6713;
	
	/**
	 * 攻击年兽使用道具
	 */
	int INTEGRATION_USE_BOMB = 6714;
	
	//--------------- 元宵(特殊商店模块)69--------------------
	/**
	 * 特殊商店 购买商品
	 */
	int SPECIAL_SHOP_BUY_ITEM = 6901;
	
	/**
	 * 一元商店购买
	 */
	int ONE_YUAN_SHOP_BUY = 6902;
	
	/**
	 * 元宝商店购买
	 */
	int GOLD_SHOP_BUY = 6903;
	
	/**
	 * 积分商店购买
	 */
	int INTEGRAL_SHOP_BUY = 6904;
	
	
	//------------- 植树模块70 ---------------
	
	/**
	 * 植树节种植消耗字符串
	 */
	int PLANTING_COST_SEED = 7001;
	
	/**
	 * 植树节收获奖励
	 */
	int PLANTING_REWARD_SEED = 7002;
	
	//-----------------团购71---------------
	
	/**
	 * 团购获得的物品
	 */
	int GROUP_PURCHASE_GOODS = 7101;
	/**
	 * 团购消耗元宝
	 */
	int GROUP_PURCHASE_RMB = 7102;
	/**
	 * 团购获得的奖励
	 */
	int GROUP_PURCHASE_REWARD = 7103;
	
	//-----------------月卡72---------------
	
	/**
	 * 使用元宝购买月卡
	 */
	int PLAYER_CARD_BUY_WITH_GOLDS = 7201;
	
	/**
	 * 领取月卡体力
	 */
	int PLAYER_CARD_GET_ENERGY = 7202;
	
	//----------------练兵73------------------------
	
	/**
	 * 练兵升级
	 */
	int TRAINING_UPGRADE_TRAINGING = 7301;
	
	/**
	 * 重置练兵技能
	 */
	int TRAINING_RESET_TRAINING_SKILL = 7302;
	
	//----------------百服活动礼包74-------------------
	
	/**
	 * 百服活动购买礼包
	 */
	int HUNDRED_SERVER_ACTIVITY_BUY_GIFT = 7401;
	
	// ---------------幸运抽奖75----------------------
	
	/**
	 * 幸运抽奖
	 */
	int LUCKY_DRAW_DRAW = 7501;
	
	/**
	 * 领取排名奖励
	 */
	int LUCKY_DRAW_RECEIVE_REWARD = 7502;
	
	// -------------宝石道具转换76------------------
	
	/**
	 * 宝石道具转换
	 */
	int STONE_ITEM_CONVERT = 7601;
	
	// ----------------爬塔PVE--------------------
	/**
	 * 爬塔pve奖励
	 */
	int TOWER_PVE_REWARD = 7701;
	
	/**
	 * 爬塔pve资源奖励
	 */
	int TOWER_PVE_RESOURCE_REWARD = 7702;
	
	// -------------充值活动领奖78------------------
	
	/**
	 * 宝石道具转换
	 */
	int CHARGE_ACTIVITY_REWARD = 7801;
	
	// --------------元宝抽奖79---------------------
	
	/**
	 * 元宝抽奖
	 */
	int GOLD_DRAW_DRAW = 7901;
	
	// ---------------稀有物品抽奖80-----------------
	
	/**
	 * 稀有物品抽奖
	 */
	int RARE_ITEM_DRAW_DRAW = 8001;
	
	/**
	 * 领取稀有物品奖励
	 */
	int RARE_ITEM_DRAW_RECEIVE_REWARD = 8002;
	
	// ---------------跨服群雄争霸奖励 81-----------------
	/**
	 * 跨服争霸奖励
	 */
	int KF_CHAMPION_REWARD = 8101;
	
	// ---------------全服摸金82---------------------
	
	/**
	 * 全服摸金开启活动
	 */
	int SERVER_TREASURE_OPEN_ACT = 8201;
	
	/**
	 * 全服摸金
	 */
	int SERVER_TREASURE_HUNT = 8202;
	
	// ---------------37平台vip等级礼包 83-------------------
	/**
	 * 37平台vip等级礼包
	 */
	int CN37_VIP_LEVEL_GIFT = 8301;
	
	// -------------劳动节种植活动84---------------
	
	/**
	 * 劳动节种植消耗字符串
	 */
	int LABOR_PLANTING_COST = 8401;

	/**
	 * 劳动节种植收获奖励
	 */
	int LABOR_PLANTING_REWARD = 8402;
	
	// ---------------皇城缉盗85---------------------
	
	/**
	 * 皇城缉盗接受任务
	 */
	int ROYAL_TASK_RECEIVE_TASK = 8501;
	
	/**
	 * 皇城缉盗刷新任务
	 */
	int ROYAL_TASK_REFRESH_TASK = 8502;
	
	/**
	 * 皇城缉盗立刻完成任务
	 */
	int ROYAL_TASK_FINISH_TASK = 8503;
	
	/**
	 * 皇城缉盗购买次数
	 */
	int ROYAL_TASK_BUY_COUNT = 8504;
	
	// ---------------欢乐宝箱奖86---------------------
	
	/**
	 * 欢乐宝箱奖励
	 */
	int HAPPY_BOX_REWARD = 8601;
	
	// ------------------坐骑87------------------------
	
	/**
	 * 坐骑培养
	 */
	int HORSE_TRAIN = 8701;
	
	/**
	 * 坐骑升阶
	 */
	int HORSE_EVOLVE = 8702;

    // ------------------神秘商店88------------------------

    /**
     * 购买商品
     */
    int MYSTERY_STORE_BUY = 8801;

    /**
     * 刷新商店
     */
	int MYSTERY_STORE_REFRESH = 8802;

    // ------------------端午活动89------------------------

    /**
     * 端午节购买粽子材料
     */
    int DUAN_WU_BUY_MATERIAL = 8901;

    /**
     * 制作粽子
     */
    int DUAN_WU_MAKE = 8902;

    /**
     * 购买馅料获得赠品
     */
    int DUAN_WU_CONSUME_REWARD = 8903;

    /**
     * 端午任务奖励
     */
    int DUAN_WU_TASK_REWARD = 8904;

	// ------------------灵翼90------------------------
	/**
	 * 灵翼培养
	 */
	int NETHERWING_TRAIN = 9001;
	
	/**
	 * 入魂培养
	 */
	int NETHERWING_ATTR_TRAIN = 9002;
	
	/**
	 * 灵翼入魂预热活动
	 */
	int NETHERWING_ACTIVITY = 9003;
	// ------------------跨服掠夺91------------------------
	
	/**
	 * 跨服掠夺手动刷新掠夺对象
	 */
	int KF_LOOT_REFRESH_LOOT_TARGETS = 9101;
	
	/**
	 * 跨服掠夺 购买次数
	 */
	int KF_LOOT_BUY_COUNT = 9102;
	
	/**
	 * 跨服掠夺消除冷却CD
	 */
	int KF_LOOT_ELIMINATE_CD = 9103;
	
	/**
	 * 跨服掠夺对象掠夺奖励
	 */
	int KF_LOOT_LOOT = 9104;
	
	// ---------------世界杯92----------------------
	
	/**
	 * 世界杯卡牌兑换
	 */
	int WORLD_CUP_CARD_EXCHANGE = 9202;
	
	/**
	 * 世界杯卡牌兑换成点数
	 */
	int WORLD_CUP_CARD_TO_POINT_COUNT = 9203;
	
	/**
	 * 世界杯点数兑换成卡牌
	 */
	int WORLD_CUP_POINT_COUNT_TO_CARD = 9204;
	
	/**
	 * 宝箱抽取
	 */
	int WORLD_CUP_EXTRACT_BOX = 9205;

	/**
	 * 排行奖励领取
	 */
	int WORLD_CUP_RANK_REWARD = 9208;
	

    /**
     * 世界杯登录奖励
     */
    int WORLD_CUP_LOGIN_REWARD = 9213;

    /**
     * 世界杯支持人数奖励
     */
    int WORLD_CUP_SUPPORT_REWARD = 9214;

    /**
     * 世界杯支持的球队比赛奖励
     */
    int WORLD_CUP_MATCH_REWARD = 9215;

    /**
     * 世界杯参与竞猜奖励
     */
    int WORLD_CUP_GUESS_REWARD = 9217;

    /**
     * 世界杯猜对奖励
     */
    int WORLD_CUP_GUESS_RIGHT_REWARD = 9219;

    /**
     * 世界杯返还元宝奖励
     */
    int WORLD_CUP_FUND_GOLD_REWARD = 9222;

    /**
     * 世界杯移除换队cd
     */
    int WORLD_CUP_REMOVE_CHANGE_TEAM_CD = 9225;

    /**
     * 补签
     */
    int WORLD_CUP_MAKE_UP_LOGIN = 9226;
	
    // ---------------军团试炼93-------------------
    /**
     * 军团试炼
     */
    int ARMY_GROUP_TRAIN_REWARDS = 9301;


    // ---------------真龙宝库95-------------------
    /**
     * 真龙宝库寻宝
     */
    int TREASURE_HOUSE_HUNT = 9501;
    
    // ---------------返还元宝活动96-------------------
    /**
     * 充值返还元宝活动奖励
     */
    int CHARGE_RETURN_ACTIVITY_REWARDS = 9601;
    
    // ---------------风云争霸94-------------------
    /**
     * 风云争霸奖励兑换(皇者积分)
     */
    int FUNG_WAN_SCORE_EXCHANGE_REWARD = 9402;
    
    /**
     * 风云争霸晋级奖励领取
     */
    int FUNG_WAN_PROMOTED_REWARD = 9403;

    // ---------------宝箱迷阵97-------------------

    /**
     * 宝箱迷阵增加步数
     */
    int BEJEWELED_ADD_MOVE = 9703;

    /**
     * 宝箱迷阵自动消除
     */
    int BEJEWELED_AUTO_CLEAR_UP = 9704;

    /**
     * 宝箱迷阵开宝箱
     */
    int BEJEWELED_OPEN_BOX = 9705;

    /**
     * 风云争霸支持奖励领取
     */
    int FUNG_WAN_SUPPORT_REWARD = 9404;
    
    /**
     * 风云争霸冠军队伍全服奖励领取
     */
    int FUNG_WAN_GLOBAL_REWARD = 9405;
    
    /**
     * 风云争霸参拜消耗及奖励
     */
    int FUNG_WAN_RESPECT_COST_REWARD = 9406;
    
    /**
     * 风云争霸献花或塞蛋消耗
     */
    int FUNG_WAN_FLOWER_EGG_COST = 9407;
    
    /**
     * 风云争霸风云争霸押注消耗
     */
    int FUNG_WAN_BET_COST = 9408;
    
    /**
     * 创建战队
     */
	int FUNG_WAN_CREATE_TEAM = 9426;
    
    /**
     * 清除主动退出战队的冷却CD
     */
    int FUNG_WAN_CLEAR_QUIT_TEAM_CD = 9431;
    
    /**
     * 清除玩家更新战力数据的冷却CD
     */
    int FUNG_WAN_CLEAR_UPDATE_DATE_CD = 9436;
    
    /**
     * 风云争霸敬酒
     */
    int FUNG_WAN_TOAST = 9437;
    
    // ---------------时装 98-------------------
    
    /**
     * 衣柜升级消耗元宝
     */
    int FASHION_EQUIP_BUREAU_UPGRADE = 9801;
    
    /**
     * 时装续费
     */
    int FASHION_EQUIP_RECHARGE = 9802;
    
    // ---------------充值抽奖99----------------------
	
 	/**
 	 * 充值抽奖
 	 */
 	int CHARGE_DRAW_DRAW = 9901;
 	
 	/**
 	 * 充值抽奖领取累计奖励
 	 */
 	int CHARGE_DRAW_RECEIVE_REWARD = 9902;
    
	//-------------------跨服天梯101----------
	/**
	 * 跨服天梯挑战胜利奖励
	 */
	int KF_LADDER_CHALLENGE_REWARD = 10101;
	
	/**
	 * 跨服天梯挑购买对手
	 */
	int KF_LADDER_BUY_TARGETS = 10102;
	
	/**
	 * 跨服天梯排名奖励
	 */
	int KF_LADDER_RANK_REWARDS = 10103;
	
	/**
	 * 跨服天梯敬酒
	 */
	int KF_LADDER_TOAST = 10104;
	
	/**
	 * 跨服天梯兑换
	 */
	int KF_LADDER_EXCHANGE = 10105;
	
	/**
	 * 跨服天梯挑购买挑战次数
	 */
	int KF_LADDER_CHALLENGE_COUNT = 10106;
 	// ---------------称号102-------------------
 	
 	/**
 	 * 激活称号
 	 */
 	int HONOR_ACTIVE_HONOR = 10201;
	
	// -----------------财富乐翻天103----------------
 	
 	/**
 	 * 财富乐翻天存款
 	 */
 	int DEPOSIT_SAVE_MONEY = 10301;
 	
 	/**
 	 * 财富乐翻天取款
 	 */
 	int DEPOSIT_REMOVE_MONEY = 10302;
	
 	/**
 	 * 财富乐翻天领取幸运星奖励
 	 */
 	int DEPOSIT_RECEIVE_STAR_REWARD = 10303;
 	
 	// ---------------帝王盛宴104------------------
 	
 	/**
 	 * 帝王盛宴购买
 	 */
 	int MONARCH_FEAST_BUY = 10401;
 	
    // ---------------充值模块 1001-------------------

	/**
	 * 充值模块金币充值
	 */
	int CHARGE_GOLD = 100101;
	
	// ---------------补丁模块  1002-------------------
	
	/**
	 * 补丁模块发放的奖励
	 */
	int PATCH_REWARD = 100201;
	
}
