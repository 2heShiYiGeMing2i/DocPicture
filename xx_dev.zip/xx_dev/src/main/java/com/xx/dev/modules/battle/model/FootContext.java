/**
 * @file:FootContext.java
 * @author:David
 **/
package com.xx.dev.modules.battle.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.xx.dev.modules.skill.model.SkillEffectTiming;
import com.xx.dev.modules.skill.model.basedb.SkillEffectConfig;

/**
 * @class:FootContext
 * @description:一次结算上下文对象
 * @author:David
 * @version:v1.0
 * @date:2013-4-22
 **/
public class FootContext {
	/** 技能效果参数 **/
	private SkillEffectConfig skillEffectConfig;
	/** 当前回合 */
	private int currRound = 0;
	/** 时间点 */
	private SkillEffectTiming timing;
	/** 攻击类型 */
	private BattleAttackType attackType = BattleAttackType.NONE;
	/** 出手方 */
	private BattleCharacter attacker;
	/** 出手方所在群体 */
	private BattleGroup attackerGroup;
	/** 技能攻击范围 */
	private BattleTargetRange attackRange;
	/** 技能影响到的战斗对象位置列表（还不是技能效果影响到的战斗对象列表） */
	private List<Integer> defenders;
	/** 当前回合的战报对象  **/
	private BattleReport battleReport;
	/** 额外触发的效果列表 */
	private List<SkillEffectDetail> effectDetails = null;
	/** 实际伤害的角色列表 **/
	private List<BattleCharacter> hurtList;
	/** 是否击杀 **/
	private boolean killed = false;
	/** 团结总伤害 */
	private double unityHarm = 0;
	/** 团结效果 特殊处理（触发团结技能效果，核算完成后重新给attrChanges赋值） **/
	private SkillEffectDetail skillEffectDetail;
	/** 具体效果值 **/
	private double effectValue;
	/** 是否设置被攻击者剩余血量 **/
	private boolean hpAfterFlag = true;
	/** 被攻击者剩余血量 **/
	private double hpAfter = -1;
	/** 是否暴击 (2001效果才生效) 0-没有暴击 1-暴击 **/
	private Map<Long, Integer> isCrit = new HashMap<Long, Integer>();
	/** 是否格挡 (2001效果才生效) 0-没有格挡 1-格挡 **/
	private Map<Long, Integer> isResistCrit = new HashMap<Long, Integer>();
	/** 是否触发了免疫物理或者免疫魔法  0-没有免疫 1-免疫 **/
	private Map<Long, Integer> isAvoidBuff = new HashMap<Long, Integer>();
	/** 护盾是否生效 **/
	private boolean shields = false;			
	
	//每轮战斗后清空战斗辅助信息
	public void clearAndReset(){
		this.hpAfter = -1;
	}
	
	public FootContext(int currRound, SkillEffectTiming timing,
			BattleAttackType attackType, BattleCharacter attacker, BattleGroup attackerGroup,
			BattleTargetRange attackRange, List<Integer> defenders, BattleReport battleReport, SkillEffectConfig skillEffectConfig) {
		super();
		this.currRound = currRound;
		this.timing = timing;
		this.attackType = attackType;
		this.attacker = attacker;
		this.attackerGroup = attackerGroup;
		this.attackRange = attackRange;
		this.defenders = defenders;
		this.battleReport = battleReport;
		this.skillEffectConfig = skillEffectConfig;
	}

	public int getCurrRound() {
		return currRound;
	}

	public SkillEffectTiming getTiming() {
		return timing;
	}

	public BattleAttackType getAttackType() {
		return attackType;
	}

	public BattleCharacter getAttacker() {
		return attacker;
	}

	public List<Integer> getDefenders() {
		return defenders;
	}

	public BattleGroup getAttackerGroup() {
		return attackerGroup;
	}

	public void setAttackerGroup(BattleGroup attackerGroup) {
		this.attackerGroup = attackerGroup;
	}

	public BattleReport getBattleReport() {
		return battleReport;
	}

	public BattleTargetRange getAttackRange() {
		return attackRange;
	}

	public SkillEffectConfig getSkillEffectConfig() {
		return skillEffectConfig;
	}

	public List<SkillEffectDetail> getEffectDetails() {
		return effectDetails;
	}

	public void setEffectDetails(List<SkillEffectDetail> effectDetails) {
		this.effectDetails = effectDetails;
	}
	
	public List<BattleCharacter> getHurtList() {
		return hurtList;
	}

	public void setHurtList(List<BattleCharacter> hurtList) {
		this.hurtList = hurtList;
	}
	
	public boolean isKilled() {
		return killed;
	}

	public void setKilled(boolean killed) {
		this.killed = killed;
	}
	
	public double getUnityHarm() {
		return unityHarm;
	}

	public void setUnityHarm(double unityHarm) {
		this.unityHarm = unityHarm;
	}
	
	public SkillEffectDetail getSkillEffectDetail() {
		return skillEffectDetail;
	}

	public void setSkillEffectDetail(SkillEffectDetail skillEffectDetail) {
		this.skillEffectDetail = skillEffectDetail;
	}
	
	public double getEffectValue() {
		return effectValue;
	}

	public void setEffectValue(double effectValue) {
		this.effectValue = Double.valueOf(effectValue).intValue();
	}
	
	public void setEffectDoubleValue(double effectValue) {
		this.effectValue = effectValue;
	}
	
	public double getHpAfter() {
		return hpAfter;
	}

	public void setHpAfter(double hpAfter) {
		if(hpAfter < 0){
			hpAfter = 0;
		}
		this.hpAfter = hpAfter;
	}

	public boolean isHpAfterFlag() {
		return hpAfterFlag;
	}

	public void setHpAfterFlag(boolean hpAfterFlag) {
		this.hpAfterFlag = hpAfterFlag;
	}
	
	public void setDefenders(List<Integer> defenders) {
		this.defenders = defenders;
	}
	
	public void setAttackRange(BattleTargetRange attackRange) {
		this.attackRange = attackRange;
	}
	

	public Map<Long, Integer> getIsCrit() {
		return isCrit;
	}

	public void setIsCrit(Map<Long, Integer> isCrit) {
		this.isCrit = isCrit;
	}
	
	public void addCrit(Long playerId, int isCrit){
		this.isCrit.put(playerId, isCrit);
	}
	
	public Map<Long, Integer> getIsResistCrit() {
		return isResistCrit;
	}

	public void setIsResistCrit(Map<Long, Integer> isResistCrit) {
		this.isResistCrit = isResistCrit;
	}
	
	public void addIsResistCrit(Long playerId, int isResistCrit){
		this.isResistCrit.put(playerId, isResistCrit);
	}
	
	public void addIsAvoidBuff(Long playerId, int isAvoidBuff){
		this.isAvoidBuff.put(playerId, isAvoidBuff);
	}
	
	public boolean isShields() {
		return shields;
	}

	public void setShields(boolean shields) {
		this.shields = shields;
	}
	
	public Map<Long, Integer> getIsAvoidBuff() {
		return isAvoidBuff;
	}

	public void setIsAvoidBuff(Map<Long, Integer> isAvoidBuff) {
		this.isAvoidBuff = isAvoidBuff;
	}

	/**
	 * @description:添加额外触发的额外触发的效果
	 * @param skillEffectDetail
	 */
	public void addSkillEffectDetail(SkillEffectDetail skillEffectDetail){
		if(effectDetails == null){
			this.effectDetails = new ArrayList<SkillEffectDetail>();
		}
		this.effectDetails.add(skillEffectDetail);
	}

	/**
	 * @description:添加额外触发的额外触发的效果
	 * @param skillEffectDetail
	 */
	public void addHurtBattleCharter(BattleCharacter battleCharacter){
		if(hurtList == null){
			this.hurtList = new ArrayList<BattleCharacter>();
		}
		this.hurtList.add(battleCharacter);
	}
	
	/**
	 * 计算团结总伤害
	 */
	public void addUnityHarm(double hurt) {
		this.unityHarm += hurt;
	}
}

