/**
 * @file:EnterInfoDto.java
 * @author:David
 **/
package com.xx.dev.modules.armageddon.model;

import com.xx.dev.modules.reward.result.ValueResultSet;

/**
 * @class:EnterInfoDto
 * @description:
 * @author:David
 * @version:v1.0
 * @date:2013-5-24
 **/
public class EnterInfoDto {
	/** 通关奖励结果 **/
	private ValueResultSet valueResultSet;

	public ValueResultSet getValueResultSet() {
		return valueResultSet;
	}

	public void setValueResultSet(ValueResultSet valueResultSet) {
		this.valueResultSet = valueResultSet;
	}
}

