package com.xx.dev.modules.activity.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.xx.common.basedb.BasedbAdapter;
import com.xx.dev.constant.IndexName;
import com.xx.dev.modules.activity.model.basedb.Activity;
import com.xx.dev.modules.activity.model.basedb.ActivityTask;
import com.xx.dev.modules.activity.service.ActivityRuleService;
import com.xx.dev.modules.task.service.TaskRuleService;


/**
 * 活动系统基础数据接口实现
 * 
 * @author bingshan
 */
@Component
public class ActivityRuleServiceImpl extends BasedbAdapter implements ActivityRuleService {
	
	@Autowired
	private TaskRuleService taskRuleService;

	@Override
	public Class<?>[] listenedClass() {
		return new Class<?>[] {Activity.class, ActivityTask.class};
	}

	@Override
	public void initialize() {
		//初始化活动任务
		initActivityTasks();
	}
	
	/**
	 * 初始化活动任务
	 */
	private void initActivityTasks() {
		List<ActivityTask> tasks = this.basedbService.listAll(ActivityTask.class);
		this.taskRuleService.initTasks(tasks);
	}

	@Override
	public Activity getActivity(int id) {
		return this.basedbService.get(Activity.class, id);
	}

	@Override
	public ActivityTask getActivityTask(int taskId) {
		return this.basedbService.get(ActivityTask.class, taskId);
	}

	@Override
	public List<Activity> getActivityList() {
		return this.basedbService.listAll(Activity.class);
	}

	@Override
	public List<ActivityTask> getActivityTaskList(int activityId) {
		return this.basedbService.listByIndex(ActivityTask.class, IndexName.ACTIVITY_TASK_ACTIVITY_ID_INDEX, activityId);
	}

	@Override
	public List<Activity> getActivityListByType(int type) {
		return this.basedbService.listByIndex(Activity.class, IndexName.ACTIVITY_TYPE_INDEX, type);
	}

	@Override
	public List<Activity> getActivityListByOpen(String openId) {
		return this.basedbService.listByIndex(Activity.class, IndexName.ACTIVITY_OPEN_INDEX, openId);
	}
	
}
