/**
 * @file:CritEnhanceBuff.java
 * @author:David
 **/
package com.xx.dev.modules.battle.model;
/**
 * @class:CritEnhanceBuff
 * @description:暴击伤害加强或降低
 * @author:David
 * @version:v1.0
 * @date:2013-4-27
 **/
public class CritEnhanceBuff extends AbstractBuff {
	
	public CritEnhanceBuff(int effectBaseValueType,
			double effectBase, int effectValueType, double effect, int startRound,
			int persistRound) {
		super(effectBaseValueType, effectBase, effectValueType, effect, startRound, persistRound);
	}
}

