package com.xx.dev.combineserver;

public abstract class MyThread extends Thread {

	private boolean flag = true;

	public boolean isFlag() {
		return flag;
	}

	public void setFlag(boolean flag) {
		this.flag = flag;
	}
	
}