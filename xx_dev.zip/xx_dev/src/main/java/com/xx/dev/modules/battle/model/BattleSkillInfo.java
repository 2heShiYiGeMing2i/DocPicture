/**
 * @file:BattleSkillInfo.java
 * @author:David
 **/
package com.xx.dev.modules.battle.model;

import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

import com.xx.dev.modules.skill.model.SkillEffectTiming;
import com.xx.dev.modules.skill.model.basedb.Skill;
import com.xx.dev.modules.skill.skilleffects.Effect;


/**
 * @class:BattleSkillInfo
 * @description:战斗中所属某角色技能
 * @author:David
 * @version:v1.0
 * @date:2013-4-23
 **/
public class BattleSkillInfo {
	/** 技能信息 **/
	private Skill skill;
	/** 技能等级 **/
	private int skillLevel;
	/** 技能触发次数 **/
	private int currTriggerCount = 0;
	/** 当前剩余冷却回合 **/
	private int leftCoolRound = 0;
	/** 当武将的技能冷却回合被减为0时，B武将再给A武将一个效果减少回合冷却的冗余属性。 负数**/
	private int leftCoolRoundBefore = 0;
	/** 本次出手是否算是一个冷却回合 */
	private boolean isCoolRound = true;
	/** 技能效果Map {SkillEffectTiming：LinkedHashMap<BattleSkillEffectInfo, Effect>}*/
	private final Map<SkillEffectTiming, LinkedHashMap<BattleSkillEffectInfo, Effect>> skillEffectMap = new HashMap<SkillEffectTiming, LinkedHashMap<BattleSkillEffectInfo, Effect>>();
	
	public void reset(){
		this.leftCoolRound = skill.getInitCoolRound(skillLevel);
		this.leftCoolRoundBefore = 0;
		this.currTriggerCount = 0;
		Collection<LinkedHashMap<BattleSkillEffectInfo, Effect>> collection = this.skillEffectMap.values();
		if(collection != null && !collection.isEmpty()){
			for (LinkedHashMap<BattleSkillEffectInfo, Effect> linkedHashMap : collection) {
				Set<BattleSkillEffectInfo> set = linkedHashMap.keySet();
				for (BattleSkillEffectInfo battleSkillEffectInfo : set) {
					battleSkillEffectInfo.reset();
				}
			}
		}
	}
	
	public BattleSkillInfo(final Skill skill, int skillLevel, final Map<SkillEffectTiming, LinkedHashMap<BattleSkillEffectInfo, Effect>> skillEffectMap) {
		super();
		this.skill = skill;
		this.skillLevel = skillLevel;
		this.leftCoolRound = skill.getInitCoolRound(skillLevel);
		if (skillEffectMap != null) {
			this.skillEffectMap.putAll(skillEffectMap);
		}
	}
	@Override
	public String toString() {
		return "BattleSkillInfo [skillLevel=" + skillLevel + ", currTriggerCount=" + currTriggerCount + ", leftCoolRound=" + leftCoolRound + ", isCoolRound=" + isCoolRound +"]";
	}
	
	public Skill getSkill() {
		return skill;
	}
	public void setSkill(Skill skill) {
		this.skill = skill;
	}
	public int getSkillLevel() {
		return skillLevel;
	}
	public void setSkillLevel(int skillLevel) {
		this.skillLevel = skillLevel;
	}
	public int getCurrTriggerCount() {
		return currTriggerCount;
	}
	public void setCurrTriggerCount(int currTriggerCount) {
		this.currTriggerCount = currTriggerCount;
	}
	public int getLeftCoolRound() {
		return leftCoolRound;
	}
	public void setLeftCoolRound(int leftCoolRound) {
		this.leftCoolRound = leftCoolRound;
	}
	public boolean isCoolRound() {
		return isCoolRound;
	}
	public void setCoolRound(boolean isCoolRound) {
		this.isCoolRound = isCoolRound;
	}
	public int getLeftCoolRoundBefore() {
		return leftCoolRoundBefore;
	}

	public void setLeftCoolRoundBefore(int leftCoolRoundBefore) {
		this.leftCoolRoundBefore = leftCoolRoundBefore;
	}

	/**
	 * 取得技能效果列表
	 * @param timing SkillEffectTiming
	 * @return List<Effect>
	 */
	public Map<BattleSkillEffectInfo, Effect> getEffectList(SkillEffectTiming timing) {
		return skillEffectMap.get(timing);
	}
	/**
	 * 剩余冷却回合减一回合
	 */
	public void decrLeftCoolRound() {
		if (this.leftCoolRound > 0) {
			this.leftCoolRound --;
		}
	}
	/**
	 * 增加冷却回合	
	 */
	public void increaseLeftCoolRound(int cdRound) {
		cdRound = Math.abs(cdRound);
		if(this.leftCoolRoundBefore < 0){//当前还有剩余冷却回合递减
			int tmpCoolRoundBefore = leftCoolRoundBefore;
			this.leftCoolRoundBefore += cdRound;
			cdRound += tmpCoolRoundBefore;
		}
		if(cdRound > 0){
			this.leftCoolRound += cdRound;
		}
	}
	/**
	 * 减少冷却回合	
	 */
	public void decreaseLeftCoolRound(int cdRound){
		if (this.leftCoolRound > 0) {
			if(this.leftCoolRound >= Math.abs(cdRound)){
				this.leftCoolRound += cdRound;
			}else {
				cdRound += this.leftCoolRound;
				this.leftCoolRound = 0;
				this.leftCoolRoundBefore += cdRound;
			}
		}else {
			this.leftCoolRoundBefore += cdRound;
		}
		
	}
	
	public void incCurrTriggerCount() {
		this.currTriggerCount ++;
	}
	
}

