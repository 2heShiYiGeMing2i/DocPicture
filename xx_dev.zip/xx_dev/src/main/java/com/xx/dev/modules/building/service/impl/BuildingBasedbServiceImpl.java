package com.xx.dev.modules.building.service.impl;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Service;

import com.xx.common.basedb.BasedbAdapter;
import com.xx.dev.modules.building.model.basedb.CityElement;
import com.xx.dev.modules.building.service.BuildingBasedbService;

@Service
public class BuildingBasedbServiceImpl extends BasedbAdapter implements BuildingBasedbService {

	private List<CityElement> cityElements = null;
	
	@Override
	public List<CityElement> getCityElements() {
		return this.cityElements;
	}

	@Override
	public Class<?>[] listenedClass() {
		return new Class<?>[] {CityElement.class};
	}

	@Override
	public void initialize() {
		List<CityElement> tmpCityElements = this.basedbService.listAll(CityElement.class);
		if (CollectionUtils.isNotEmpty(tmpCityElements)) {
			Collections.sort(tmpCityElements, new Comparator<CityElement>() {
				@Override
				public int compare(CityElement o1, CityElement o2) {
					if (o1 == null && o2 == null) {
						return 0;
					} else if (o1 == null) {
						return 1;
					} else if (o2 == null) {
						return -1;
					} else if (o1.getId() == o2.getId()) {
						return 0;
					} else if (o1.getId() < o2.getId()) {
						return -1;
					} else {
						return 1;
					}
				}
			});
		}
		if (CollectionUtils.isNotEmpty(cityElements)) {
			this.cityElements.clear();
		} else {
			this.cityElements = new CopyOnWriteArrayList<CityElement>();
		}
		if (CollectionUtils.isNotEmpty(tmpCityElements)) {
			this.cityElements.addAll(tmpCityElements);
		}
	}

}
