package com.xx.dev.modules.barracks.model.basedb;

import com.xx.common.basedb.anno.Id;
import com.xx.common.basedb.anno.Resource;

/**
 * 兵营表
 * 
 * @author Along
 *
 */
@Resource
public class Barracks {

	/**
	 * id(兵营等级)
	 */
	@Id
	private Integer id;
	
	/**
	 * 士兵上限
	 */
	private Integer soldierAmount;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getSoldierAmount() {
		return soldierAmount;
	}

	public void setSoldierAmount(Integer soldierAmount) {
		this.soldierAmount = soldierAmount;
	}

}
