package com.xx.dev.modules.blackmarket.model.basedb;

import com.xx.common.basedb.anno.Id;
import com.xx.common.basedb.anno.Resource;

/**
 * 黑市基础数据表
 * 
 * @author Along
 *
 */
@Resource
public class BlackMarket {

	@Id
	private int id;
	
	/**
	 * 刷新时间间隔（秒）
	 */
	private int refreshTime;
	
	/**
	 * 刷新消耗
	 */
	private int refreshCost;
	
	/**
	 * 刷新奖励积分
	 */
	private int rewardIntegral;
	
	/**
	 * 每日免费刷新次数
	 */
	private int freeRefreshTimes;
	
	/**
	 * 最小提示品阶
	 */
	private int grade;
	
	/**
	 * 初始化商品
	 */
	private String initGoods;
	
	/**
	 * 第一次刷新的商品
	 */
	private String firstGoods;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getRefreshTime() {
		return refreshTime;
	}

	public void setRefreshTime(int refreshTime) {
		this.refreshTime = refreshTime;
	}

	public int getRefreshCost() {
		return refreshCost;
	}

	public void setRefreshCost(int refreshCost) {
		this.refreshCost = refreshCost;
	}

	public int getRewardIntegral() {
		return rewardIntegral;
	}

	public void setRewardIntegral(int rewardIntegral) {
		this.rewardIntegral = rewardIntegral;
	}

	public int getFreeRefreshTimes() {
		return freeRefreshTimes;
	}

	public void setFreeRefreshTimes(int freeRefreshTimes) {
		this.freeRefreshTimes = freeRefreshTimes;
	}

	public int getGrade() {
		return grade;
	}

	public void setGrade(int grade) {
		this.grade = grade;
	}

	public String getInitGoods() {
		return initGoods;
	}

	public void setInitGoods(String initGoods) {
		this.initGoods = initGoods;
	}

	public String getFirstGoods() {
		return firstGoods;
	}

	public void setFirstGoods(String firstGoods) {
		this.firstGoods = firstGoods;
	}
	
}
