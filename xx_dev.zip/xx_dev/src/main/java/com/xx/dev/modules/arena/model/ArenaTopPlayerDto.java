package com.xx.dev.modules.arena.model;

import com.xx.dev.constant.Sex;

/**
 * 竞技场结算第一名信息
 * 
 * @author bingshan
 */
public class ArenaTopPlayerDto {
	
	/**
	 * 玩家id
	 */
	private long playerId;

	/**
	 * 玩家名
	 */
	private String playerName;
	
	/**
	 * 性别
	 */
	private int sex = Sex.FEMALE.ordinal();
	
	public static ArenaTopPlayerDto valueOf(long playerId, String playerName, int sex) {
		ArenaTopPlayerDto d = new ArenaTopPlayerDto();
		d.playerId = playerId;
		d.playerName = playerName;
		d.sex = sex;
		return d;
	}

	public long getPlayerId() {
		return playerId;
	}

	public void setPlayerId(long playerId) {
		this.playerId = playerId;
	}

	public String getPlayerName() {
		return playerName;
	}

	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}

	public int getSex() {
		return sex;
	}

	public void setSex(int sex) {
		this.sex = sex;
	}
	
}
