package com.xx.dev.modules.activity.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.xx.common.db.model.BaseModel;


/**
 * 玩家活动信息
 * 
 * @author bingshan
 */
@Entity
@Table(name = "playerActivity")
public class PlayerActivity extends BaseModel<String> {
	private static final long serialVersionUID = -4833496203049166615L;

	/**
	 * 主键id
	 */
	@Id
	@Column(columnDefinition="varchar(255) not null comment '主键id'")
	private String id;
	
	/**
	 * 玩家id
	 */
	@Column(columnDefinition="bigint(20) not null comment '玩家id'")
	private Long playerId;
	
	/**
	 * 活动ID
	 */
	@Column(columnDefinition="int(11) not null comment '活动ID'")
	private Integer activityId = 0;
	
	/**
	 * 接受任务事件
	 */
	@Column(columnDefinition = "datetime comment '任务进度信息'")
	private Date receiveTime = new Date();
	
	/**
	 * 状态, 0-关闭  1-开启
	 */
	@Column(columnDefinition="tinyint(4) default '0' comment '状态, 0-关闭  1-开启'")
	private Integer status = 0;
	
	public static PlayerActivity valueOf(String id, long playerId, int activityId) {
		PlayerActivity playerActivity = new PlayerActivity();
		playerActivity.id = id;
		playerActivity.playerId = playerId;
		playerActivity.activityId = activityId;
		return playerActivity;
	}
	
	/**
	 * 取得玩家活动主键id
	 * @param playerId 玩家id
	 * @param activityId 活动id
	 * @return String
	 */
	public static String getPlayerActivityId(long playerId, int activityId) {
		return new StringBuffer().append(playerId).append(":").append(activityId).toString();
	}
	
	/**
	 * 活动是否开启
	 * @return boolean
	 */
	public boolean isOpened() {
		return this.status == 1;
	}

	@Override
	public String getId() {
		return this.id;
	}

	@Override
	public void setId(String id) {
		this.id = id;
	}

	public Long getPlayerId() {
		return playerId;
	}

	public void setPlayerId(Long playerId) {
		this.playerId = playerId;
	}

	public Integer getActivityId() {
		return activityId;
	}

	public void setActivityId(Integer activityId) {
		this.activityId = activityId;
	}

	public Date getReceiveTime() {
		return receiveTime;
	}

	public void setReceiveTime(Date receiveTime) {
		this.receiveTime = receiveTime;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

}
