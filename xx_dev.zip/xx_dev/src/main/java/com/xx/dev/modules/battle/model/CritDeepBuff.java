/**
 * @file:CritDeepBuff.java
 * @author:David
 **/
package com.xx.dev.modules.battle.model;
/**
 * @class:CritDeepBuff
 * @description:暴击伤害加深或减免
 * @author:David
 * @version:v1.0
 * @date:2013-4-27
 **/
public class CritDeepBuff extends AbstractBuff {
	
	public CritDeepBuff(int effectBaseValueType,
			double effectBase, int effectValueType, double effect, int startRound,
			int persistRound) {
		super(effectBaseValueType, effectBase, effectValueType, effect, startRound, persistRound);
	}
}

