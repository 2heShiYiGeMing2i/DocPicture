package com.xx.dev.modules.bejeweled.model;

import org.codehaus.jackson.annotate.JsonIgnore;

import java.util.Collection;
import java.util.List;

/**
 * 消除详细
 * Created by LiangZengle on 2014/6/18.
 */
public class ClearUpDto {
    /**
     * 消除的格子
     */
    private Collection<Cell> cell;

    /**
     * 结果 : "[[4,2,4,6,4,3],[5,4,2,2,2,1],[1,2,1,6,5,2],[3,6,3,2,3,3],[4,1,2,5,4,4],[1,6,4,3,2,6]]"
     */
    private String result;

    /**
     * 本次消除所得积分
     */
    private int score;

    /**
     * 新增的方块(y < 0)
     */
    private Collection<Cell> newCells;

    private List<Integer> eliminatedResult;

    public static ClearUpDto valueOf(Collection<Cell> cleanedCells, List<Integer> eliminatedResult, String snapshot, Collection<Cell> newCells) {
        ClearUpDto clearUpDto = new ClearUpDto();
        clearUpDto.cell = cleanedCells;
        clearUpDto.result = snapshot;
        clearUpDto.eliminatedResult = eliminatedResult;
        clearUpDto.newCells = newCells;
        return clearUpDto;
    }

    public Collection<Cell> getCell() {
        return cell;
    }

    public void setCell(Collection<Cell> cell) {
        this.cell = cell;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    @JsonIgnore
    public List<Integer> getEliminatedResult() {
        return eliminatedResult;
    }

    public void setEliminatedResult(List<Integer> eliminatedResult) {
        this.eliminatedResult = eliminatedResult;
    }

    public Collection<Cell> getNewCells() {
        return newCells;
    }

    public void setNewCells(Collection<Cell> newCells) {
        this.newCells = newCells;
    }
}
