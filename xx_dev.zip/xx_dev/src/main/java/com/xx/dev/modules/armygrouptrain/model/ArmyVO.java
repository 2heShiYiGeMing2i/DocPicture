package com.xx.dev.modules.armygrouptrain.model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;

import com.xx.dev.modules.battle.model.BattleCharacter;

public class ArmyVO {

	/**
	 * 0表示沒有人攻擊，1表示有人在攻擊
	 */
	private int isInBattle;
	
	/**
	 * 是否已經被擊殺
	 * 0-沒有、1-已經死亡
	 */
	private int killed = 0;
	
	/**
	 * 軍隊
	 */
	private List<BattleCharacter> armyFightUnits;
	
	/**
	 * 軍隊血量
	 */
	private Map<Long, Double> armyHp = new HashMap<Long, Double>();
	
	/**
	 * 當前血量
	 */
	private double curHp;
	
	/**
	 * 初始總血量
	 */
	private double totalHp;
	
	public List<BattleCharacter> getArmyFightUnits() {
		return armyFightUnits;
	}

	public void setArmyFightUnits(List<BattleCharacter> armyFightUnits) {
		this.armyFightUnits = armyFightUnits;
	}


	public Map<Long, Double> getArmyHp() {
		return armyHp;
	}

	public void setArmyHp(Map<Long, Double> armyHp) {
		this.armyHp = armyHp;
	}

	public int getKilled() {
		return killed;
	}

	public void setKilled(int killed) {
		this.killed = killed;
	}
	
	public int getIsInBattle() {
		return isInBattle;
	}

	public void setIsInBattle(int isInBattle) {
		this.isInBattle = isInBattle;
	}

	public double getTotalHp() {
		return totalHp;
	}

	public void setTotalHp(double totalHp) {
		this.totalHp = totalHp;
	}

	public double getCurHp() {
		return curHp;
	}

	public void setCurHp(double curHp) {
		this.curHp = curHp;
	}

	public double saveHp(List<BattleCharacter> fightUnits) {
		if (fightUnits == null) {
			return 0;
		}
		
		double currHp = 0;
		for (BattleCharacter character: fightUnits) {
			if (character == null) {
				continue;
			}
			
			armyHp.put(character.getPlayerId(), character.getBattleAttr().hp);
			currHp += character.getBattleAttr().hp;
		}
		this.curHp = currHp;
		return currHp;
	}

	/**
	 * 獲取血量大於0的戰鬥屬性
	 * @return
	 */
	public List<BattleCharacter> getFightUnits() {
		
		if (CollectionUtils.isEmpty(armyFightUnits)) {
			return null;
		}
		
		List<BattleCharacter> results = new ArrayList<BattleCharacter>(armyFightUnits.size());		
		for (BattleCharacter cs: armyFightUnits) {
			if (cs == null) {
				continue;
			}
			BattleCharacter cc = cs.clone();
			//当前hp
			long heroId = cc.getPlayerId();
			Double currHeroHp = armyHp.get(heroId);
			if (currHeroHp != null) {
				cc.getBattleAttr().hp = currHeroHp;
				cc.setInitHp(currHeroHp);
			}
			results.add(cc);
		}
		
		return results;
	}

	public void initArmyFightUnits(List<BattleCharacter> npcUnit) {
		if(npcUnit == null){
			return;
		}
		armyFightUnits = npcUnit;
		for(BattleCharacter battleCharacter : armyFightUnits){
			totalHp += battleCharacter.getBattleAttr().hp;
		}
		saveHp(armyFightUnits);
	}
	
}
