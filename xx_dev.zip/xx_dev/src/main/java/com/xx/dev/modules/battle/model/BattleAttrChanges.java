/**
 * @file:BattleAttrChanges.java
 * @author:David
 **/
package com.xx.dev.modules.battle.model;

import com.xx.dev.constant.CharacterType;

/**
 * @class:BattleAttrChanges
 * @description:战斗角色变化属性集合
 * @author:David
 * @version:v1.0
 * @date:2013-4-23
 **/
public class BattleAttrChanges {
	/** 战斗ID（唯一键） **/
	private long id;
	/** 玩家ID **/
	private long playerId = -1l;
	/** 影响玩家所在位置 **/
	private int pos;
	/** 具体效果值 **/
	private double effectValue;
	/**
	 * hp变化值
	 */
	private double hpChanges = 0;
	/**
	 * 变化后的HP
	 */
	private double currHp = 0;
	/** 
	 * 护盾hp变化值
	 */
	private double shieldsHpChanges = 0;
	/** 
	 * 变化后的护盾hp
	 */
	private double curShieldsHp = 0;
	/** 是否暴击  0-没有暴击 1-暴击 **/
	private int isCrit = 0;
	/** 是否格挡  0-没有格挡 1-格挡 **/
	private int isResistCrit = 0;
	/** 是否触发了免疫物理或者免疫魔法  0-没有免疫 1-免疫 **/
	private int isAvoidBuff = 0;
	/** 主动技能CD回合变化值 **/
	private int skillRoundChanges = 0;
	/** 变化后的主动技能CD回合 **/
	private int curSkillRound = 0;
	/** 当武将的技能冷却回合被减为0时，B武将再给A武将一个效果减少回合冷却的冗余属性。 的变化值**/
	private int skillRoundBeforeChanges = 0;
	/** 变化后的 当武将的技能冷却回合被减为0时，B武将再给A武将一个效果减少回合冷却的冗余属性。**/
	private int curSkillRoundBeforeChanges = 0;
	
	public BattleAttrChanges(BattleCharacter battleCharacter) {
		super();
		this.id = battleCharacter.getId();
		this.pos = battleCharacter.getTeamPosition();
		this.currHp = battleCharacter.getBattleAttr().hp;
		if(battleCharacter.getCharacterType().equals(CharacterType.PLAYER) && !battleCharacter.isCheer()){
			this.playerId = battleCharacter.getPlayerId();
		}
	}

	public BattleAttrChanges(BattleCharacter battleCharacter, double hpChanges, double currHp, double effectValue, double shieldsHpChanges, double curShieldsHp) {
		super();
		this.id = battleCharacter.getId();
		this.pos = battleCharacter.getTeamPosition();
		this.hpChanges = hpChanges;
		this.currHp = currHp;
		this.effectValue = effectValue;
		this.shieldsHpChanges = shieldsHpChanges;
		this.curShieldsHp = curShieldsHp;
		if(battleCharacter.getCharacterType().equals(CharacterType.PLAYER) && !battleCharacter.isCheer()){
			this.playerId = battleCharacter.getPlayerId();
		}
	}

	public BattleAttrChanges(BattleCharacter battleCharacter, double hpChanges, double currHp, double effectValue, double shieldsHpChanges, double curShieldsHp, int skillRoundChanges, int curSkillRound, int skillRoundBeforeChanges, int curSkillRoundBeforeChanges) {
		super();
		this.id = battleCharacter.getId();
		this.pos = battleCharacter.getTeamPosition();
		this.hpChanges = hpChanges;
		this.currHp = currHp;
		this.effectValue = effectValue;
		this.shieldsHpChanges = shieldsHpChanges;
		this.curShieldsHp = curShieldsHp;
		if(battleCharacter.getCharacterType().equals(CharacterType.PLAYER) && !battleCharacter.isCheer()){
			this.playerId = battleCharacter.getPlayerId();
		}
		this.skillRoundChanges = skillRoundChanges;
		this.curSkillRound = curSkillRound;
		this.skillRoundBeforeChanges = skillRoundBeforeChanges;
		this.curSkillRoundBeforeChanges = curSkillRoundBeforeChanges;
	}
	
	public BattleAttrChanges(long playerId, double hpChanges, double currHp) {
		super();
		this.playerId = playerId;
		this.hpChanges = hpChanges;
		this.currHp = currHp;
	}
	
	public void reflush(double hpChanges, double currHp){
		this.hpChanges = hpChanges;
		this.currHp = currHp;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public int getPos() {
		return pos;
	}
	public void setPos(int pos) {
		this.pos = pos;
	}
	public double getHpChanges() {
		return hpChanges;
	}
	public void setHpChanges(double hpChanges) {
		this.hpChanges = hpChanges;
	}
	public double getCurrHp() {
		return currHp;
	}
	public void setCurrHp(double currHp) {
		this.currHp = currHp;
	}
	public double getEffectValue() {
		return effectValue;
	}
	public void setEffectValue(double effectValue) {
		this.effectValue = effectValue;
	}

	public double getCurShieldsHp() {
		return curShieldsHp;
	}

	public void setCurShieldsHp(double curShieldsHp) {
		this.curShieldsHp = curShieldsHp;
	}

	public double getShieldsHpChanges() {
		return shieldsHpChanges;
	}

	public void setShieldsHpChanges(double shieldsHpChanges) {
		this.shieldsHpChanges = shieldsHpChanges;
	}
	public int getIsCrit() {
		return isCrit;
	}
	public void setIsCrit(int isCrit) {
		this.isCrit = isCrit;
	}
	public int getIsResistCrit() {
		return isResistCrit;
	}
	public void setIsResistCrit(int isResistCrit) {
		this.isResistCrit = isResistCrit;
	}

	public long getPlayerId() {
		return playerId;
	}

	public void setPlayerId(long playerId) {
		this.playerId = playerId;
	}

	public int getSkillRoundChanges() {
		return skillRoundChanges;
	}

	public void setSkillRoundChanges(int skillRoundChanges) {
		this.skillRoundChanges = skillRoundChanges;
	}

	public int getCurSkillRound() {
		return curSkillRound;
	}

	public void setCurSkillRound(int curSkillRound) {
		this.curSkillRound = curSkillRound;
	}

	public int getSkillRoundBeforeChanges() {
		return skillRoundBeforeChanges;
	}

	public void setSkillRoundBeforeChanges(int skillRoundBeforeChanges) {
		this.skillRoundBeforeChanges = skillRoundBeforeChanges;
	}

	public int getCurSkillRoundBeforeChanges() {
		return curSkillRoundBeforeChanges;
	}

	public void setCurSkillRoundBeforeChanges(int curSkillRoundBeforeChanges) {
		this.curSkillRoundBeforeChanges = curSkillRoundBeforeChanges;
	}

	public int getIsAvoidBuff() {
		return isAvoidBuff;
	}

	public void setIsAvoidBuff(int isAvoidBuff) {
		this.isAvoidBuff = isAvoidBuff;
	}
	

}

