package com.xx.dev.modules.bejeweled.entity;

import com.xx.common.db.cache.DbLoadInitializer;
import com.xx.common.db.model.BaseModel;
import com.xx.common.util.JsonUtils;
import com.xx.dev.modules.bejeweled.model.Goal;

import org.apache.commons.lang.StringUtils;

import javax.persistence.*;

import java.util.Date;

/**
 * 宝石迷阵
 * Created by LiangZengle on 2014/6/18.
 */
@Entity
@Table(name = "playerBejeweled")
public class PlayerBejeweled extends BaseModel<Long> implements DbLoadInitializer {

    private static final long serialVersionUID = 418041893119978952L;
    /**
     * 主键（玩家id）
     */
    @Id
    @Column(columnDefinition = "bigint(20) not null comment '玩家id'")
    private Long id;

    /**
     * 已走步数
     */
    @Column(columnDefinition = "int(11) comment '已走步数'")
    private int takenMoves;

    /**
     * 增加步数的次数
     */
    @Column(columnDefinition = "int(11) comment '增加步数的次数'")
    private int addMoveTimes;

    /**
     * 当前目标
     */
    @Column(columnDefinition = "varchar(50) comment '当前目标'")
    private String curGoalInfo;

    /**
     * 下一个目标
     */
    @Column(columnDefinition = "varchar(50) comment '下一个目标'")
    private String nextGoalInfo;

    /**
     * 分数
     */
    @Column(columnDefinition = "int(11) comment '分数'")
    private int score;

    /**
     * 宝箱品质
     */
    @Column(columnDefinition = "tinyint(4) default '1' comment '宝箱品质'")
    private int boxLevel = 1;

    /**
     * 每日刷新时间
     */
    @Column(columnDefinition = "datetime comment '每日刷新时间'")
    private Date refreshTime;

    /**
     * 每周刷新时间
     */
    @Column(columnDefinition = "datetime comment '每周刷新时间'")
    private Date weeklyRefreshTime;

    @Transient
    private Goal curGoal;
    @Transient
    private Goal nextGoal;

    public static PlayerBejeweled valueOf(long id, Goal curGoal, Goal nextGoal) {
        PlayerBejeweled playerBejeweled = new PlayerBejeweled();
        playerBejeweled.setId(id);
        playerBejeweled.updateGoal(curGoal, nextGoal);
        Date now = new Date();
        playerBejeweled.refreshTime = now;
        playerBejeweled.weeklyRefreshTime = now;
        return playerBejeweled;
    }

    @Override
    public void doAfterLoad() {
        if (StringUtils.isNotEmpty(curGoalInfo)) {
            curGoal = JsonUtils.jsonString2Object(curGoalInfo, Goal.class);
        }

        if (StringUtils.isNotEmpty(nextGoalInfo)) {
            nextGoal = JsonUtils.jsonString2Object(nextGoalInfo, Goal.class);
        }
    }

    public void refreshOnCrossDay(Date now) {
        addMoveTimes = 0;
        takenMoves = 0;
        refreshTime = now;
    }

    public void refreshOnCrossWeek(Date now) {
        boxLevel = 1;
        score = 0;
        weeklyRefreshTime = now;
    }

    /**
     * 当前目标已达成，下一目标变为当前目标，新目标为下一目标
     *
     * @param newGoal
     */
    public void updateGoal(Goal newGoal) {
        updateGoal(nextGoal, newGoal);
    }

    private void updateGoal(Goal curGoal, Goal nextGoal) {
        this.curGoal = curGoal;
        this.nextGoal = nextGoal;
        curGoalInfo = JsonUtils.object2JsonString(this.curGoal);
        nextGoalInfo = JsonUtils.object2JsonString(this.nextGoal);
    }

    public void increaseEliminatedCount(int eliminated) {
        if (eliminated < 1) {
            return;
        }
        curGoal.setEliminated(curGoal.getEliminated() + eliminated);
        curGoalInfo = JsonUtils.object2JsonString(curGoal);
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public int getTakenMoves() {
        return takenMoves;
    }

    public void setTakenMoves(int takenMoves) {
        this.takenMoves = takenMoves;
    }

    public int getAddMoveTimes() {
        return addMoveTimes;
    }

    public void setAddMoveTimes(int addMoveTimes) {
        this.addMoveTimes = addMoveTimes;
    }

    public String getCurGoalInfo() {
        return curGoalInfo;
    }

    public void setCurGoalInfo(String curGoalInfo) {
        this.curGoalInfo = curGoalInfo;
    }

    public String getNextGoalInfo() {
        return nextGoalInfo;
    }

    public void setNextGoalInfo(String nextGoalInfo) {
        this.nextGoalInfo = nextGoalInfo;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public int getBoxLevel() {
        return boxLevel;
    }

    public void setBoxLevel(int boxLevel) {
        this.boxLevel = boxLevel;
    }

    public Date getRefreshTime() {
        return refreshTime;
    }

    public void setRefreshTime(Date refreshTime) {
        this.refreshTime = refreshTime;
    }

    public Goal getCurGoal() {
        return curGoal;
    }

    public void setCurGoal(Goal curGoal) {
        this.curGoal = curGoal;
    }

    public Goal getNextGoal() {
        return nextGoal;
    }

    public void setNextGoal(Goal nextGoal) {
        this.nextGoal = nextGoal;
    }

    public Date getWeeklyRefreshTime() {
        return weeklyRefreshTime;
    }

    public void setWeeklyRefreshTime(Date weeklyRefreshTime) {
        this.weeklyRefreshTime = weeklyRefreshTime;
    }
}
