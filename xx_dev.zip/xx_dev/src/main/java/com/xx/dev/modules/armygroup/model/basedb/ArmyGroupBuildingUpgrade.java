package com.xx.dev.modules.armygroup.model.basedb;

import com.xx.common.basedb.anno.Id;
import com.xx.common.basedb.anno.Index;
import com.xx.common.basedb.anno.Resource;
import com.xx.dev.constant.IndexName;

/**
 * 军团建筑升级表
 * 
 * @author Along
 *
 */
@Resource
public class ArmyGroupBuildingUpgrade {

	/**
	 * id
	 */
	@Id
	private int id;
	
	/**
	 * 军团建筑id
	 */
	@Index(name = IndexName.ARMY_GROUP_BUILDING_UPGRADE_INDEX, order = 0)
	private int buildingId;
	
	/**
	 * 军团建筑等级
	 */
	@Index(name = IndexName.ARMY_GROUP_BUILDING_UPGRADE_INDEX, order = 1)
	private int level;
	
	/**
	 * 建筑完成度
	 */
	private int progress;
	
	/**
	 * 建筑效果
	 */
	private double value;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getBuildingId() {
		return buildingId;
	}

	public void setBuildingId(int buildingId) {
		this.buildingId = buildingId;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

	public int getProgress() {
		return progress;
	}

	public void setProgress(int progress) {
		this.progress = progress;
	}

	public double getValue() {
		return value;
	}

	public void setValue(double value) {
		this.value = value;
	}
	
}
