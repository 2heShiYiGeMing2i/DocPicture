package com.xx.dev.modules.building.model.basedb;

import com.xx.common.basedb.anno.Id;
import com.xx.common.basedb.anno.Resource;

/**
 * 主城建筑
 * 
 * @author Along
 *
 */
@Resource
public class CityElement {

	/**
	 * id
	 */
	@Id
	private Integer id;
	
	/**
	 * 建筑类型
	 */
	private int type;
	
	/**
	 * 开放等级
	 */
	private int openLevel;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public int getOpenLevel() {
		return openLevel;
	}

	public void setOpenLevel(int openLevel) {
		this.openLevel = openLevel;
	}
	
}
