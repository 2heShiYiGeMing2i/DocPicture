package com.xx.dev.modules.armygroup.model;

/**
 * 军团职位类型
 * 
 * @author Along
 *
 */
public interface ArmyGroupPositionType {

	/**
	 * 团长
	 */
	int CHIEF = 4;
	
	/**
	 * 副团长
	 */
	int DEPUTY_CHIEF = 3;
	
	/**
	 * 官员
	 */
	int OFFICIAL = 2;
	
	/**
	 * 成员
	 */
	int MEMBER = 1;
	
}
