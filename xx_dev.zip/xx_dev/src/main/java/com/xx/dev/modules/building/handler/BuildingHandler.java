package com.xx.dev.modules.building.handler;

import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xx.common.socket.handler.RequestProcessor;
import com.xx.common.socket.model.Request;
import com.xx.common.socket.model.Response;
import com.xx.dev.config.Module;
import com.xx.dev.model.Result;
import com.xx.dev.modules.building.model.PlayerBuildingDto;
import com.xx.dev.modules.building.service.BuildingService;
import com.xx.dev.modules.server.SessionManager;
import com.xx.dev.modules.server.handler.HandlerSupport;

/**
 * 主城建筑模块
 * 
 * @author Along
 *
 */
@Service
public class BuildingHandler extends HandlerSupport {

	private Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	private SessionManager sessionManager;
	
	@Autowired
	private BuildingService buildingService;
	
	@Override
	protected void init() {
		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				getPlayerBuildings(session, response);
			}
			
			@Override
			public Type getType() {
				return null;
			}
			
			@Override
			public int getModule() {
				return Module.BUILDING;
			}
			
			@Override
			public int getCmd() {
				return BuildingCmd.GET_BUILDINGS;
			}
		});
		
		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				upgradeBuildingQuality(session, request, response);
			}
			
			@Override
			public Type getType() {
				return HashMap.class;
			}
			
			@Override
			public int getModule() {
				return Module.BUILDING;
			}
			
			@Override
			public int getCmd() {
				return BuildingCmd.UPGRADE_BUILDIING_QUALITY;
			}
		});
		
		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				upgradeBuildingLevel(session, request, response);
			}
			
			@Override
			public Type getType() {
				return HashMap.class;
			}
			
			@Override
			public int getModule() {
				return Module.BUILDING;
			}
			
			@Override
			public int getCmd() {
				return BuildingCmd.UPGRADE_BUILDING_LEVEL;
			}
		});
		
		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				enterCity(session, response);
			}
			
			@Override
			public Type getType() {
				return null;
			}
			
			@Override
			public int getModule() {
				return Module.BUILDING;
			}
			
			@Override
			public int getCmd() {
				return BuildingCmd.ENTER_CITY;
			}
		});
	}
	
	protected void enterCity(IoSession session, Response response) {
		Long playerId = sessionManager.getPlayerId(session);
		int result = BuildingResult.FAILURE;
		try {
			result = buildingService.enterCityAction(playerId);
		} catch (Exception e) {
			logger.error("玩家进入主城", e);
		}		
		response.setValue(result);
		session.write(response);		
	}

	@SuppressWarnings("unchecked")
	private void upgradeBuildingLevel(IoSession session, Request request,
			Response response) {
		Long playerId = sessionManager.getPlayerId(session);
		Result<PlayerBuildingDto> result = null;
		try {
			HashMap<String, Object> params = (HashMap<String, Object>) request.getValue();
			String sBuildingId = String.valueOf(params.get("buildingId"));
			if (StringUtils.isBlank(sBuildingId) || !StringUtils.isNumeric(sBuildingId)) {
				result = Result.Error(BuildingResult.PARAM_ERROR);
			} else {
				int buildingId = Integer.parseInt(sBuildingId);
				result = buildingService.upgradeLevelAction(playerId, buildingId);
			}
		} catch (Exception e) {
			result = Result.Error(BuildingResult.FAILURE);
			logger.error("提升主城建筑等级", e);
		}		
		response.setValue(result);
		session.write(response);		
	}

	private void getPlayerBuildings(IoSession session, Response response) {
		Long playerId = sessionManager.getPlayerId(session);
		List<PlayerBuildingDto> result = null;
		try {
			result = buildingService.getBuildingsAction(playerId);
		} catch (Exception e) {
			logger.error("获取玩家主城建筑列表", e);
		}		
		response.setValue(result);
		session.write(response);
	}

	@SuppressWarnings("unchecked")
	private void upgradeBuildingQuality(IoSession session, Request request,
			Response response) {
		Long playerId = sessionManager.getPlayerId(session);
		Result<PlayerBuildingDto> result = null;
		try {
			HashMap<String, Object> params = (HashMap<String, Object>) request.getValue();
			String sBuildingId = String.valueOf(params.get("buildingId"));
			if (StringUtils.isBlank(sBuildingId) || !StringUtils.isNumeric(sBuildingId)) {
				result = Result.Error(BuildingResult.PARAM_ERROR);
			} else {
				int buildingId = Integer.parseInt(sBuildingId);
				result = buildingService.upgradeQualityAction(playerId, buildingId);
			}
		} catch (Exception e) {
			result = Result.Error(BuildingResult.FAILURE);
			logger.error("提升主城建筑品质", e);
		}		
		response.setValue(result);
		session.write(response);
	}
	
}
