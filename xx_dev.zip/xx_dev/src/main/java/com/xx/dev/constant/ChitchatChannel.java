package com.xx.dev.constant;

/**
 * 频道类型
 * 
 * @author Along
 *
 */
public interface ChitchatChannel {

	/**
	 * 世界频道
	 */
	int WORLD = 1;

	/**
	 * 军团频道
	 */
	int ARMY_GROUP = 3;
	
	/**
	 * 个人频道
	 */
	int PRIVATE = 4;
	
	/**
	 * 组队频道
	 */
	int TEAM = 5;
	
}
