/**
 * @file:BattleResult.java
 * @author:David
 **/
package com.xx.dev.modules.battle.model;

import java.util.ArrayList;
import java.util.List;

import com.xx.dev.modules.battle.core.BattleWinner;

/**
 * @class:BattleResult
 * @description:战斗结果
 * @author:David
 * @version:v1.0
 * @date:2013-4-19
 **/
public class BattleResult {
	/** 战斗胜方 BattleWinner */
	private BattleWinner winner = BattleWinner.DRAW_GAME;
	/** 服务器触发时间 **/
	private long battleTime;
	/** 回合战报集合 **/
	private List<BattleReport> battleReports = null;
	/** 大回合战报集合**/
	private List<BattleRound> battleRounds = null;
	/** 进攻方 **/
	private BattleGroupDto attackGroup;
	/** 防守方 **/
	private BattleGroupDto defendGroup;	
	/** 当前大回合 */
	private int currRound = 0;
	/**
	 * 如果是NPCHERO，奖励掉落 
	 */
	private List<String> dropResult = null;
	
	/**
	 * create a instance  BattleResult.   
	 * @param isReport 是否需要战报
	 */
	public BattleResult(boolean isReport) {
		super();
		this.battleTime = System.currentTimeMillis();
		if(isReport){
			battleReports = new ArrayList<BattleReport>();
		}
	}
	/**
	 * @description:另外生成大回合战报	
	 *
	 */
	public void createBattleRound(){
		this.battleRounds = new ArrayList<BattleRound>();
	}
	public BattleWinner getWinner() {
		return winner;
	}
	public void setWinner(BattleWinner winner) {
		this.winner = winner;
	}
	public List<BattleReport> getBattleReports() {
		return battleReports;
	}
	public void setBattleReports(List<BattleReport> battleReports) {
		this.battleReports = battleReports;
	}
	public long getBattleTime() {
		return battleTime;
	}
	public void setBattleTime(long battleTime) {
		this.battleTime = battleTime;
	}
	public BattleGroupDto getAttackGroup() {
		return attackGroup;
	}
	public void setAttackGroup(BattleGroupDto attackGroup) {
		this.attackGroup = attackGroup;
	}
	public BattleGroupDto getDefendGroup() {
		return defendGroup;
	}
	public void setDefendGroup(BattleGroupDto defendGroup) {
		this.defendGroup = defendGroup;
	}
	public int getCurrRound() {
		return currRound;
	}
	public void setCurrRound(int currRound) {
		this.currRound = currRound;
	}
	public List<String> getDropResult() {
		return dropResult;
	}
	public void setDropResult(List<String> dropResult) {
		this.dropResult = dropResult;
	}
	public List<BattleRound> getBattleRounds() {
		return battleRounds;
	}
	public void setBattleRounds(List<BattleRound> battleRounds) {
		this.battleRounds = battleRounds;
	}
	/**
	 * @description:添加战报	
	 * @param battleReport
	 */
	public void addBattleReport(BattleReport battleReport){
		if(this.battleReports != null){
			this.battleReports.add(battleReport);
		}
	}
	/**
	 * @description:添加大回合战报	
	 * @param battleReport
	 */
	public void addBattleRound(BattleRound battleRound){
		if(this.battleRounds != null){
			this.battleRounds.add(battleRound);
		}
	}
}

