package com.xx.dev.constant;

/**
 * 邮件状态
 * 
 * @author Along
 * 
 */
public enum MailStatus {

	/**
	 * 0-新邮件 
	 */
	NEW,
	
	/**
	 * 1-未读
	 */
	UN_READED,

	/**
	 * 2-已读
	 */
	READED
	
}
