/**
 * @file:ArmageddonArmy.java
 * @author:David
 **/
package com.xx.dev.modules.armageddon.model.basedb;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.xx.common.basedb.InitializeBean;
import com.xx.common.basedb.anno.Id;
import com.xx.common.basedb.anno.Resource;
import com.xx.common.util.Splitable;
import com.xx.dev.modules.chapter.model.basedb.Army;

/**
 * @class:ArmageddonArmy
 * @description:军队(怪物主公)表
 * @author:David
 * @version:v1.0
 * @date:2013-5-20
 **/
@Resource
public class ArmageddonArmy implements InitializeBean{
	private static final Logger logger = LoggerFactory.getLogger(Army.class);

	/**
	 * 技能基础数据id
	 */
	@Id
	private int id;
	/** 据点id **/
	private int areaId;
	/** 批次 **/
	private int batch;
	/** 战斗部队列表 **/
	private String army;
	/** 奖励串 **/
	private String rewards;
	/** 掉落编号 **/
	private String drops;
	/** 公告id **/
	private String noticeId;
	/** 玩家是否后手 **/
	private int armyAttack;
	/** 主公名称 **/
	private String npcName;
	/** 主公等级 **/
	private int npcLevel;
	/** 主公头像 **/
	private String npcPic;
	// 以下设置字段不用填表
	/** 战斗部队列表ID数组 **/
	private Integer[] armyIds = {};
	/** 全服首破公告ID **/
	private int serverClearNoticeId = 0;
	/** 玩家首破公告ID **/
	private int playerClearNoticeId = 0;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getAreaId() {
		return areaId;
	}
	public void setAreaId(int areaId) {
		this.areaId = areaId;
	}
	public int getBatch() {
		return batch;
	}
	public void setBatch(int batch) {
		this.batch = batch;
	}
	public String getArmy() {
		return army;
	}
	public void setArmy(String army) {
		this.army = army;
	}
	public String getRewards() {
		return rewards;
	}
	public void setRewards(String rewards) {
		this.rewards = rewards;
	}
	public String getDrops() {
		return drops;
	}
	public void setDrops(String drops) {
		this.drops = drops;
	}
	public String getNoticeId() {
		return noticeId;
	}
	public void setNoticeId(String noticeId) {
		this.noticeId = noticeId;
	}
	public int getArmyAttack() {
		return armyAttack;
	}
	public void setArmyAttack(int armyAttack) {
		this.armyAttack = armyAttack;
	}
	public int getServerClearNoticeId() {
		return serverClearNoticeId;
	}
	public void setServerClearNoticeId(int serverClearNoticeId) {
		this.serverClearNoticeId = serverClearNoticeId;
	}
	public int getPlayerClearNoticeId() {
		return playerClearNoticeId;
	}
	public void setPlayerClearNoticeId(int playerClearNoticeId) {
		this.playerClearNoticeId = playerClearNoticeId;
	}
	public String getNpcName() {
		return npcName;
	}
	public void setNpcName(String npcName) {
		this.npcName = npcName;
	}
	public int getNpcLevel() {
		return npcLevel;
	}
	public void setNpcLevel(int npcLevel) {
		this.npcLevel = npcLevel;
	}
	public String getNpcPic() {
		return npcPic;
	}
	public void setNpcPic(String npcPic) {
		this.npcPic = npcPic;
	}
	@Override
	public void afterPropertiesSet() {
		if(this.army == null || this.army.trim().length() == 0){
			trace("【军队(怪物主公)表】{} 战斗部队列表 出错", getId());
		}
		String[] armStrings = this.army.trim().split(Splitable.ELEMENT_SPLIT);
		List<Integer> armIntegers = new ArrayList<Integer>(armStrings.length);
		for (String string : armStrings) {
			armIntegers.add(Integer.valueOf(string));
		}
		this.armyIds = armIntegers.toArray(armyIds);
		if(this.noticeId == null || this.noticeId.trim().length() == 0){
			return;
		}
		armStrings = this.noticeId.trim().split(Splitable.ELEMENT_SPLIT);
		for (String string : armStrings) {
			String[] values = string.split(Splitable.ATTRIBUTE_SPLIT);
			if(Integer.valueOf(values[0]) == 1){//全服首破
				this.serverClearNoticeId = Integer.valueOf(values[1]);
			}else if(Integer.valueOf(values[0]) == 2){//玩家首破
				this.playerClearNoticeId = Integer.valueOf(values[1]);
			}
		}
	}
	public boolean isArmyAttack(){
		return this.armyAttack == 1;
	}
	/**
	 * debug日志信息
	 * @param format 格式
	 * @param param 参数
	 */
	private void trace(String format, Object... param) {
		logger.error(format, param);
	}
}

