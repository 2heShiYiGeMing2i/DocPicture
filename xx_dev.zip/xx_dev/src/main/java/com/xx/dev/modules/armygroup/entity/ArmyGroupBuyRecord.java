package com.xx.dev.modules.armygroup.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.xx.common.db.model.BaseModel;

/**
 * 军团商品购买记录
 * 
 * @author Along
 *
 */
@Entity
@Table(name = "armyGroupBuyRecord")
public class ArmyGroupBuyRecord extends BaseModel<String> {

	private static final long serialVersionUID = -6472477929596747729L;

	/**
	 * 主键（玩家id_商品id）
	 */
	@Id
	@Column(columnDefinition = "varchar(50) not null comment 'id'")
	private String id;
	
	/**
	 * 玩家id
	 */
	@Column(columnDefinition = "bigint(20) not null comment '玩家id'")
	private long playerId;
	
	/**
	 * 商品id
	 */
	@Column(columnDefinition = "int(11) not null comment '商品id'")
	private int goodsId;
	
	/**
	 * 购买数量
	 */
	@Column(columnDefinition = "int(11) default '0' comment '购买数量'")
	private int amount = 0;
	
	/**
	 * 最后购买该商品的时间
	 */
	@Column(columnDefinition="datetime default '2013-01-01 00:00:00' comment '最后购买商品的时间'")
	private Date lastBuyTime = new Date();
	
	public ArmyGroupBuyRecord() {
		
	}
	
	public ArmyGroupBuyRecord(long playerId, int goodsId) {
		this.id = getKey(playerId, goodsId);
		this.playerId = playerId;
		this.goodsId = goodsId;
		this.amount = 0;
	}
	
	public static String getKey(long playerId, int goodsId) {
		StringBuilder buf = new StringBuilder();
		buf.append(playerId).append("_").append(goodsId);
		return buf.toString();
	}

	@Override
	public String getId() {
		return this.id;
	}

	@Override
	public void setId(String id) {
		this.id = id;
	}

	public long getPlayerId() {
		return playerId;
	}

	public void setPlayerId(long playerId) {
		this.playerId = playerId;
	}

	public int getGoodsId() {
		return goodsId;
	}

	public void setGoodsId(int goodsId) {
		this.goodsId = goodsId;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public Date getLastBuyTime() {
		return lastBuyTime;
	}

	public void setLastBuyTime(Date lastBuyTime) {
		this.lastBuyTime = lastBuyTime;
	}

}
