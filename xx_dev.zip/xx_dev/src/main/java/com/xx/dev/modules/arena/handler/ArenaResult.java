package com.xx.dev.modules.arena.handler;

import com.xx.dev.constant.CommonConstant;


/**
 * 竞技场系统返回码
 * 
 * @author bingshan
 */
public interface ArenaResult extends CommonConstant {
	
	/**
	 * 不能挑战该排名
	 */
	int CANNOT_CHALLENGE_RANK = -10001;
	
	/**
	 * 挑战次数限制
	 */
	int CHALLENGE_COUNT_LIMIT = -10002;
	
	/**
	 * 挑战CD限制
	 */
	int CHALLENGE_CD_LIMIT = -10003;
	
	/**
	 * 无挑战CD
	 */
	int NO_CHALLENGE_CD = -10004;
	
	/**
	 * 没牌
	 */
	int NO_CARD = -10005;
	
	/**
	 * 已翻牌
	 */
	int CARD_REWARDED = -10006;
	
	/**
	 * 购买次数限制
	 */
	int BUY_COUNT_LIMIT = -10007;
	
	/**
	 * 没有宝箱
	 */
	int NO_BOX = -10008;
	
	/**
	 * 宝箱奖励已领取
	 */
	int BOX_REWARDED = -10009;
	
	/**
	 * 该名次不存在
	 */
	int RANK_NOT_EXISTS = -10010;
	
	/**
	 * 没有奖励
	 */
	int NO_REWARD = -10011;
	
	/**
	 * 奖励已领取
	 */
	int REWARD_GETTED = -10012;
	
}
