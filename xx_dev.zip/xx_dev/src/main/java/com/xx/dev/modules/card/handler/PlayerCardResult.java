package com.xx.dev.modules.card.handler;

import com.xx.dev.constant.CommonConstant;

public interface PlayerCardResult extends CommonConstant{

	/**
	 * 月卡没有开通
	 */
	public int PLAYER_CARD_UNOPEN = -10001;
	
	/**
	 * 月卡过期
	 */
	public int PLAYER_CARD_DUE = -10002;
	
	/**
	 * buffer已经领取过
	 */
	public int PLAYER_CARD_BUFFER_REGETED = -10003;
	
	/**
	 * 体力重复领取
	 */
	public int PLAYER_CARD_ENERGY_REGETED = -10004;
	
	/**
	 * 富甲天下已经领取完成
	 */
	public int PLAYER_CARD_FJTX_REGETED = -10005;
}
