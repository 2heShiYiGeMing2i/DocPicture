package com.xx.dev.modules.bejeweled.handler;

/**
 * Created by LiangZengle on 2014/6/21.
 */
public interface BejeweledCmd {
    /**
     * 获取宝石迷阵信息
     *
     * @return Map {
     * "content" : BejeweledDto
     * }
     */
    int GET_BEJEWELED_INFO = 1;

    /**
     * 交换方块
     *
     * @param int[] 方块坐标[x1, y1, x2, y2]
     * @return Map {
     * "content" : BejeweledDto
     * "clearUpDetail" : List<ClearUpDto>
     * }
     */
    int SWAP = 2;

    /**
     * 增加步数
     *
     * @return Map {
     * "leftMoves" : int 剩余步数
     * "leftAddMoveTimes" : int 剩余增加步数的次数
     * "goldDiscount" : int vip节省
     * "valueResultSet" : ValueResultSet
     * }
     */
    int ADD_MOVE = 3;

    /**
     * 自动消除
     *
     * @return Map {
     * "content" : BejeweledDto
     * "clearUpDetail" : List<ClearUpDto>
     * "goldDiscount" : int vip节省
     * "valueResultSet" : ValueResultSet
     * }
     */
    int AUTO_CLEAR_UP = 4;

    /**
     * 开宝箱
     *
     * @return Map {
     * "valueResultSet" : ValueResultSet
     * "boxLevel" : int 宝箱等级
     * "score" : int 分数
     * }
     */
    int OPEN_BOX = 5;
}
