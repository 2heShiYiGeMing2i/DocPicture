/**
 * @file:Cofiguration.java
 * @author:David
 **/
package com.xx.dev.config;

import java.util.Date;
import java.util.Properties;

import org.apache.commons.lang.BooleanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.support.PropertiesLoaderUtils;

import com.xx.common.profile.Profiler;
import com.xx.common.socket.ServerConfig;
import com.xx.dev.modules.server.config.FirewallCfg;
import com.xx.dev.modules.server.config.IpKeyCfg;

/**
 * @class:Cofiguration
 * @description:配置对象
 * @author:David
 * @version:v1.0
 * @date:2012-10-12
 **/
public class Cofiguration {
	
	private static final Logger logger = LoggerFactory.getLogger(Cofiguration.class);
	
	private static final String config_file_name = "ServerCfg.properties";
	
	/**
	 * 服务器启动时间
	 */
	public static Date serverStartTime = new Date();
	
	private static Properties properties = new Properties();
	
	/**
	 * 服务器信息配置
	 */
	private static ServerConfig serverConfig;
	
	/**
	 * IP/KEY 配置
	 */
	private static IpKeyCfg ipKeyCfg;
	
	/**
	 * 防火墙配置信息
	 */
	private static FirewallCfg firewallCfg;
	
	static {
		refresh();
	}
	
	/**
	 * 刷新配置
	 */
	public static void refresh(){
		try {
			properties = PropertiesLoaderUtils.loadProperties(new ClassPathResource(config_file_name));
		} catch (Exception e) {
			logger.error("加载系统配置出错!", e);
		}
		postRefresh();
	}
	
	
	/**
	 * 性能分析
	 */
	private static final String system_profile_open = "system.profile.open";
	
	
	/**
	 * 刷新后处理
	 */
	private static void postRefresh(){
		//性能分析开关
		if(!Profiler.isOpen()){
			String profileOpen = (String)properties.get(system_profile_open);
			Profiler.setOpen("1".equalsIgnoreCase(profileOpen) || BooleanUtils.toBoolean(profileOpen));
		}
		
		serverConfig = ServerConfig.valueOf(properties);
		ipKeyCfg = IpKeyCfg.valueOf(properties);
		firewallCfg = FirewallCfg.valueOf(properties);
	}
	
	/**
	 * 获取属性
	 * @param key
	 * @return
	 */
	public static String getProperty(String key){
		if(properties != null){
			return (String)properties.get(key);
		}
		return null;
	}
	
	/**
	 * 取得服务器配置信息
	 * @return ServerConfig
	 */
	public static ServerConfig getServerConfig() {
		return serverConfig;
	}

	/**
	 * 取得 IP/KEY 配置信息
	 * @return IpKeyCfg
	 */
	public static IpKeyCfg getIpKeyCfg() {
		return ipKeyCfg;
	}

	/**
	 * 取得防火墙配置信息
	 * @return FirewallCfg
	 */
	public static FirewallCfg getFirewallCfg() {
		return firewallCfg;
	}
	
}

