package com.xx.dev.modules.champion.constant;

/**
 * 群雄争霸状态
 * 
 * @author bingshan
 */
public enum ChampionStatus {
	
	/**
	 * 0-无
	 */
	NONE,
	
	/**
	 * 1-报名时间
	 */
	SIGN_UP,

	/**
	 * 2-战斗计算时间
	 */
	DO_CHAMPIONSHIP,
	
	/**
	 * 3-战报时间
	 */
	REPORTS,
	
	/**
	 * 4-支持时间
	 */
	SUPPORT
}
