/**
 * @file:HookStatus.java
 * @author:David
 **/
package com.xx.dev.constant;
/**
 * @class:HookStatus
 * @description:挂机状态
 * @author:David
 * @version:v1.0
 * @date:2013-5-6
 **/
public interface HookStatus {

	/**
	 * 0-正常状态
	 */
	int NORMAL = 0;
	
	/**
	 * 1-挂机中
	 */
	int HOOK = 1;
	
	/**
	 * 2-挂机结束
	 */
	int HOOK_FINISHED = 2;
}

