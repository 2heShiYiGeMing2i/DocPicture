package com.xx.dev.constant;

/**
 * 物质类型（背包系统用来区分不同的表）
 * 
 * @author Along
 *
 */
public interface GoodsType {
	
	/**
	 * 道具
	 */
	public final int ITEM = 1;
	
	/**
	 * 武将装备
	 */
	public final int HERO_EQUIP = 2;
	
	/**
	 * 主公装备
	 */
	public final int PLAYER_EQUIP = 3;
	
}
