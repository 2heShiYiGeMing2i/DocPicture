package com.xx.dev.modules.armygrouptrain.handler;

import com.xx.dev.modules.armygrouptrain.model.ArmyDto;
import com.xx.dev.modules.armygrouptrain.model.TrainDto;
import com.xx.dev.modules.armygrouptrain.model.TrainPlayerDetailDto;
import com.xx.dev.modules.armygrouptrain.model.TrainPlayerDto;
import com.xx.dev.modules.armygrouptrain.model.TrainPlayerRankDto;
import com.xx.dev.modules.armygrouptrain.model.TrainStatus;
import com.xx.dev.modules.reward.result.ValueResultSet;

/**
 * 军团试炼指令
 * 
 * @author jy
 * 
 */
public interface ArmyGroupTrainCmd {

	/**
	 * 進入試煉場景
	 * 
	 * 获取个人的军团试炼信息，包含冷却状态等信息，在玩家进入复活和试炼场景时需要获取
	 * 
	 * @return 
	 * Map{
	 * "result" : {@link ArmyGroupTrainResult}
	 * "content" : {@link TrainPlayerDto}參與試煉的玩家個人信息
	 * "players" : {@link List<TrainPlayerDetailDto>}場景中的玩家
	 * "startTime" : long 活动开始的时间
	 * }
	 */
	int GET_MY_TRAIN_INFO = 1;

	/**
	 * 获取军团试炼当前的战斗信息，在进入试炼场景的时候需要获取，
	 * 包括当前关卡、试炼军批次以及关卡中试炼军的死亡状态、血量等信息
	 * @return
	 * {@link TrainDto}
	 */
	int GET_ARMY_GROUP_TRAIN_INFO = 2;
	
	/**
	 * 進攻試煉軍
	 * @param
	 * "areaId" : 据点id
	 * "armyId" : 軍隊id
	 * @return
	 * Map{
	 * "result" : {@link ArmyGroupTrainResult}
	 * "valueResultSet" : {@link ValueResultSet} 獎勵
	 * "content" : {@link TrainPlayerDto} 攻擊之後的玩家信息
	 * "battleResults" : {@link List<BattleResult>} 戰報等
	 * }
	 */
	int ATTACK = 3;
	
	/**
	 * 離開軍團試煉的場景
	 * {@link ArmyGroupTrainResult}
	 */
	int LEAVE_ARMY_GROUP_TRAIN_SCENE = 4;
	
	/**
	 * 获取军团试炼排名信息
	 * Map{
	 * "result" : {@link ArmyGroupTrainResult}
	 * "content" : {@link List<TrainPlayerRankDto>}
	 * }
	 */
	int GET_ARMY_GROUP_TRAIN_RANKS = 5;
	
	/**
	 * 在試煉場景移動
	 * @param path 移动路径
	 */
	int MOVE_IN_TRAIN_SCENE = 6;
	
	/**
	 * 更新玩家當前位置
	 * @param curLoc 当前位置
	 */
	int UPDATE_CUR_LOCATION = 7;
	
	/**
	 * 取得玩家当前位置
	 * @return 当前位置
	 */
	int GET_CUR_LOCATION = 8;
	
	/**
	 * 获取当前活动状态
	 * @return Map{
	 * "status" : {@link TrainStatus}//活動狀態0/1/2三種
	 * }
	 */
	int GET_CUR_STATUS = 9;
	
	/**
	 * 推送試煉軍信息：血量或狀態等改變
	 * @return {@link ArmyDto}
	 */
	int PUSH_ARMY_GROUP_ARMY = 10001;
	
	/**
	 * 推送新的試煉軍批次
	 * @return {@link TrainDto}
	 */
	int PUSH_ARMY_GROUP_AREA = 10002;
	
	/**
	 * 推送玩家進出場景
	 * @return
	 * Map{
	 * "status" : Integer 1表示進入場景，2表示離開場景，3移動，4表示信息改變，比如坐騎切換等，5玩家死亡
	 * "playerId" : Long 玩家id，出場景時有值，入場景時沒有，2、5類型有值
	 * "player" : {@link TrainPlayerDetailDto}
	 */
	int PUSH_SCENE_CHANGE = 10003;
	
	/**
	 * 推送排名
	 * @return {@link TrainPlayerRankDto}
	 */
	int PUSH_ARMY_GROUP_TRAIN_RANK = 10004;
	
	/**
	 * 推送活動狀態改變
	 * Map{
	 * "status" : {@link TrainStatus}//活動狀態
	 * }
	 */
	int PUSH_ACTIVITY_STATUS_CHANGE = 10006;
	
	/**
	 * 活动结束的时候推送活动期间获得的奖励
	 * Map{
	 * "rewards" : String//奖励串
	 * }
	 */
	int PUSH_ACTIVITY_TOTAL_REWARDS = 10007;
	
	/**
	 * 推送通关奖励
	 * Map{
	 * "valueResultSet" : {@link ValueResultSet} 獎勵
	 * }
	 */
	int PUSH_ACTIVITY_BREAK_REWARDS = 10008;
}
