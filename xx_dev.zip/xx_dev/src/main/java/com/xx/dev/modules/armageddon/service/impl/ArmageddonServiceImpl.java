/**
 * @file:ArmageddonServiceImpl.java
 * @author:David
 **/
package com.xx.dev.modules.armageddon.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.googlecode.concurrentlinkedhashmap.ConcurrentLinkedHashMap;
import com.xx.common.basedb.BasedbService;
import com.xx.common.db.cache.DbCachedService;
import com.xx.common.util.RandomUtil;
import com.xx.common.util.TimeConstant;
import com.xx.common.utility.lock.ChainLock;
import com.xx.common.utility.lock.LockUtils;
import com.xx.dev.config.LRUConfig;
import com.xx.dev.constant.BattleType;
import com.xx.dev.constant.GameRuleID;
import com.xx.dev.constant.GoldRuleID;
import com.xx.dev.constant.HookStatus;
import com.xx.dev.constant.LogSource;
import com.xx.dev.constant.RewardType;
import com.xx.dev.model.Result;
import com.xx.dev.modules.armageddon.entity.ArmageddonCheerInfo;
import com.xx.dev.modules.armageddon.entity.PlayerArmageddonInfo;
import com.xx.dev.modules.armageddon.handler.ArmageddonResult;
import com.xx.dev.modules.armageddon.model.ArmageddonInfoDto;
import com.xx.dev.modules.armageddon.model.AttackResultDto;
import com.xx.dev.modules.armageddon.model.BuyTimeDto;
import com.xx.dev.modules.armageddon.model.CheerInfoDto;
import com.xx.dev.modules.armageddon.model.CreateRoomDto;
import com.xx.dev.modules.armageddon.model.EnterInfoDto;
import com.xx.dev.modules.armageddon.model.FlushCheerDto;
import com.xx.dev.modules.armageddon.model.MissionRewardDto;
import com.xx.dev.modules.armageddon.model.PlayerCheerDto;
import com.xx.dev.modules.armageddon.model.basedb.Armageddon;
import com.xx.dev.modules.armageddon.model.basedb.ArmageddonArmy;
import com.xx.dev.modules.armageddon.model.basedb.ArmageddonMission;
import com.xx.dev.modules.armageddon.service.ArmageddonRuleService;
import com.xx.dev.modules.armageddon.service.ArmageddonService;
import com.xx.dev.modules.battle.core.Battle;
import com.xx.dev.modules.battle.core.BattleWinner;
import com.xx.dev.modules.battle.model.BattleCharacter;
import com.xx.dev.modules.battle.model.BattleGroup;
import com.xx.dev.modules.battle.model.BattlePlayerInfo;
import com.xx.dev.modules.battle.model.BattleResult;
import com.xx.dev.modules.battle.model.BattleTeam;
import com.xx.dev.modules.chapter.entity.PlayerChapterInfo;
import com.xx.dev.modules.drop.model.DropResult;
import com.xx.dev.modules.drop.service.DropService;
import com.xx.dev.modules.hero.service.HeroService;
import com.xx.dev.modules.journey.model.HardType;
import com.xx.dev.modules.player.entity.Player;
import com.xx.dev.modules.player.model.basedb.Vip;
import com.xx.dev.modules.player.service.PlayerService;
import com.xx.dev.modules.relation.entity.PlayerRelation;
import com.xx.dev.modules.relation.model.RelationState;
import com.xx.dev.modules.relation.model.SortCheerInfo;
import com.xx.dev.modules.relation.service.RelationService;
import com.xx.dev.modules.reward.action.RewardActionSet;
import com.xx.dev.modules.reward.constant.InBagRule;
import com.xx.dev.modules.reward.model.Reward;
import com.xx.dev.modules.reward.model.SimpleReward;
import com.xx.dev.modules.reward.result.RewardResult;
import com.xx.dev.modules.reward.result.ValueResultSet;
import com.xx.dev.modules.reward.service.RewardService;
import com.xx.dev.modules.reward.support.RewardHelper;
import com.xx.dev.modules.task.constant.TaskStatus;
import com.xx.dev.modules.task.event.ArmageddonMissionEvent;
import com.xx.dev.modules.task.service.MainFeederTaskService;
import com.xx.dev.modules.task.service.TaskBus;
import com.xx.dev.modules.vip.service.VipService;
import com.xx.dev.utils.CommonRule;
import com.xx.dev.utils.GameRuleService;

/**
 * @class:ArmageddonServiceImpl
 * @description:大决战实现类
 * @author:David
 * @version:v1.0
 * @date:2013-5-20
 **/
@Service
public class ArmageddonServiceImpl implements ArmageddonService {
	
	@Autowired
	private DbCachedService dbCachedService;
	@Autowired
	protected BasedbService basedbService;
	@Autowired
	private PlayerService playerService;
	@Autowired
	private ArmageddonRuleService armageddonRuleService;
	@Autowired
	private DropService dropService;
	@Autowired
	private RewardService rewardService;
	@Autowired
	private HeroService heroService;
	@Autowired
	private GameRuleService gameRuleService;
	@Autowired
	private RelationService relationService;
	@Autowired
	private MainFeederTaskService mainFeederTaskService;
	@Autowired
	private TaskBus taskBus;
//	@Autowired
//	private PackService packService;
	@Autowired
	private VipService vipService;
	
	/** 房间id生成器 */
	private AtomicLong teamNoGenerator = null;
	/** 房间ID初始化时间 **/
	private Date teamDate = CommonRule.MIN_DATE; 
	
	
	@Override
	public Result<ArmageddonInfoDto> chapterInfo(Long playerId) {
		Player player = dbCachedService.get(playerId, Player.class);
		if(player == null){
			return Result.Error(ArmageddonResult.PLAYER_NOT_EXISTS);
		}
		PlayerArmageddonInfo playerChapterInfo = getPlayerArmageddonInfo(playerId);
		ArmageddonInfoDto chapterInfoDto = new ArmageddonInfoDto(playerChapterInfo, getRewardTimes(player));
		return Result.Success(chapterInfoDto);
	}

	@Override
	public Result<EnterInfoDto> enterChapter(long playerId, long cheerIdOne, long cheerIdTwo, String formation, int missionId, int hardType) {
		ArmageddonMission mission = basedbService.get(ArmageddonMission.class, missionId);
		if(mission == null){
			return Result.Error(ArmageddonResult.BASE_DATA_NOT_EXIST);
		}
		Armageddon chapter = basedbService.get(Armageddon.class, mission.getFubenId());
		if(chapter == null){
			return Result.Error(ArmageddonResult.BASE_DATA_NOT_EXIST);
		}
		PlayerArmageddonInfo playerChapterInfo = getPlayerArmageddonInfo(playerId);
		if(playerChapterInfo.getHookStatus() == HookStatus.HOOK){
			return Result.Error(ArmageddonResult.HOOKING);
		}else if(playerChapterInfo.isBattleCD()){
			return Result.Error(ArmageddonResult.BATTLE_CD);
		}
		Player player = dbCachedService.get(playerId, Player.class);
		if(player == null){
			return Result.Error(ArmageddonResult.PLAYER_NOT_EXISTS);
		}
		int checkResult = heroService.checkPlayerBattleAttr(playerId, false);
		if(checkResult != ArmageddonResult.SUCCESS){
			return Result.Error(checkResult);
		}
		boolean enterNewArea = false;//是否是进入了以前没有进入的新据点
		int fubenId = playerChapterInfo.getMissionId();//历史最高副本
		int cuMissionId = playerChapterInfo.getCurMissionId();//当前据点，还未打
		HardType curHardType = playerChapterInfo.getHardType();
//		ArmageddonMission currMission = basedbService.get(ArmageddonMission.class, currMissionId);
		if(fubenId == PlayerArmageddonInfo.INIT_VALUE){//当前据点是空 那么就是第一次进入据点
			/*if(missionId != armageddonRuleService.getFirstMissionId(curHardType)){
				return Result.Error(ArmageddonResult.ENTER_NOT_ORDER);
			}*/
			enterNewArea = true;
			curHardType = HardType.valueOf(hardType);
		}else if(mission.getFubenId() > fubenId){//如果进入的副本比现在的大则是新进入副本
			if(cuMissionId != PlayerArmageddonInfo.INIT_VALUE){//上一个据点还未打完
				return Result.Error(ArmageddonResult.SINGLE_FUBEN_NOT_BREAK);
			}
			
			enterNewArea = true;
		
		}
		//进攻消耗
		int status = this.doEnergyWithFuben(player, mission);
		if(status != ArmageddonResult.SUCCESS){
			return Result.Error(status);
		}
		EnterInfoDto result = new EnterInfoDto();
		if(enterNewArea){//进入更高的据点
			int openLevel = mission.getOpenLevel();
			if(player.getLevel() < openLevel){
				return Result.Error(ArmageddonResult.LT_OPEN_LEVEL);
			}
			
			int openTaskId = mission.getOpenTaskId();
			if(openTaskId > 0){
				TaskStatus taskStatus = mainFeederTaskService.getPlayerTaskStatus(playerId, openTaskId);
				if(TaskStatus.NONE.equals(taskStatus)){
					return Result.Error(ArmageddonResult.OPEN_TASK_NOT_RECIVED);
				}
			}
			
			int openMissionId = mission.getOpenMissionId();
			if(openMissionId > getPlayerChapterInfo(playerId).getMissionId()){
				return Result.Error(ArmageddonResult.FUBEN_NOT_BREAK);
			}
			
			ChainLock chainLock = LockUtils.getLock(player);
			chainLock.lock();
			try {
				if(playerChapterInfo.getMissionId() != fubenId || playerChapterInfo.getCurMissionId() != cuMissionId){//再比较一次
					return Result.Error(ArmageddonResult.FAILURE);
				}else if(getIncomeTimes(player, playerChapterInfo) <= 0){
					return Result.Error(ArmageddonResult.TIME_BUGOU);
				}else if(playerChapterInfo.isBattleCD()){
					return Result.Error(ArmageddonResult.BATTLE_CD);
				}
				status = inviteCheerInfo(playerId, cheerIdOne, cheerIdTwo, formation, result);
				if(status != ArmageddonResult.SUCCESS){
					return Result.Error(status);
				}
				if(playerChapterInfo.isRewardSameResetTime()){
					playerChapterInfo.setTimes(getRewardTimes(player));
					playerChapterInfo.setIncomeDate(new Date());
				}
				if(playerChapterInfo.isFirst()){
					playerChapterInfo.setFirst(false);
				}
				playerChapterInfo.setBattleCdTime(System.currentTimeMillis() + getCDTimes());
				playerChapterInfo.setMissionId(mission.getFubenId());
				playerChapterInfo.setHardType(curHardType);
				playerChapterInfo.setCurMissionId(missionId);
				this.dbCachedService.submitUpdated2Queue(playerChapterInfo.getId(), playerChapterInfo.getClass());
			} finally {
				chainLock.unlock();
			}
		}else {
			ChainLock chainLock = LockUtils.getLock(player);
			chainLock.lock();
			try {
				if(playerChapterInfo.getMissionId() != fubenId || playerChapterInfo.getCurMissionId() != cuMissionId){//再比较一次
					return Result.Error(ArmageddonResult.FAILURE);
				}else if(getIncomeTimes(player, playerChapterInfo) <= 0){
					return Result.Error(ArmageddonResult.TIME_BUGOU);
				}else if(playerChapterInfo.isBattleCD()){
					return Result.Error(ArmageddonResult.BATTLE_CD);
				}
				status = inviteCheerInfo(playerId, cheerIdOne, cheerIdTwo, formation, result);
				if(status != ArmageddonResult.SUCCESS){
					return Result.Error(status);
				}
				if(playerChapterInfo.isRewardSameResetTime()){
					playerChapterInfo.setTimes(getRewardTimes(player));
					playerChapterInfo.setIncomeDate(new Date());
				}
				if(cuMissionId == PlayerArmageddonInfo.INIT_VALUE ){
					playerChapterInfo.setCurMissionId(missionId);
				}

				if(playerChapterInfo.isFirst()){
					playerChapterInfo.setFirst(false);
				}
				playerChapterInfo.setBattleCdTime(System.currentTimeMillis() + getCDTimes());
				this.dbCachedService.submitUpdated2Queue(playerChapterInfo.getId(), playerChapterInfo.getClass());
			} finally {
				chainLock.unlock();
			}
		}
		
		return Result.Success(result);
	}
	@Override
	public Result<AttackResultDto> attackMonster(long playerId, int missionId) {
		PlayerArmageddonInfo playerChapterInfo = getPlayerArmageddonInfo(playerId);
		ArmageddonMission mission = basedbService.get(ArmageddonMission.class, missionId);
		if(mission == null){
			return Result.Error(ArmageddonResult.BASE_DATA_NOT_EXIST);
		}
		Player player = dbCachedService.get(playerId, Player.class);
		if(player == null){
			return Result.Error(ArmageddonResult.PLAYER_NOT_EXISTS);
		}
		int checkResult = heroService.checkPlayerBattleAttr(playerId, false);
		if(checkResult != ArmageddonResult.SUCCESS){
			return Result.Error(checkResult);
		}
		if(playerChapterInfo.getHookStatus() == HookStatus.HOOK){
			return Result.Error(ArmageddonResult.HOOKING);
		}else if(playerChapterInfo.getCurMissionId() != missionId){
			return Result.Error(ArmageddonResult.ATTACK_ARMY_NOT_ORDER);
		}else if(playerChapterInfo.isReward()){
			return Result.Error(ArmageddonResult.MUST_REWARD);
		}
		final FightContext fightContext = this.getFightContext(playerId);
		
		if(!fightContext.lockFight()){
			return Result.Error(ArmageddonResult.FIGHTING);
		}
		AttackConext attackConext = new AttackConext(player, playerChapterInfo, fightContext, mission);
		AttackResultDto attackResultDto = new AttackResultDto();
		try {
			//打怪顺序的判断
			int status = this.tryAttack(attackConext);
			if(status != ArmageddonResult.SUCCESS){
				return Result.Error(status);
			}
			
			//战斗
			this.doFightWithFuben(attackConext, attackResultDto);
		} finally {
			fightContext.unlockFight();
		}
		//-------------------------奖励 公告 日志 处理---------------------------------------------
		boolean win = attackResultDto.isWin();
		if(win){//赢了
			//实施奖励
			int status = this.doRewardsWithFuben(attackConext, attackResultDto);
			if(status != ArmageddonResult.SUCCESS){
				return Result.Error(status);
			}
			
			this.taskBus.post(ArmageddonMissionEvent.valueOf(playerId, missionId, 1));
		}
		return Result.Success(attackResultDto);
	}
	//实施奖励
	private int doRewardsWithFuben(AttackConext attackConext,
			AttackResultDto attackResultDto) {
		Player player = attackConext.player;
		PlayerArmageddonInfo playerChapterInfo = attackConext.playerArmageddonInfo;
		ArmageddonMission mission = attackConext.mission;
		
		long playerId = player.getId();
		
		boolean breakTop = attackResultDto.isBreakTop();
		
		DropResult result = null;
		if(StringUtils.isNotBlank(playerChapterInfo.getRewardResult())){
			result = dropService.parseDropResult(playerId, playerChapterInfo.getRewardResult(), playerChapterInfo.getNoticeResult());
		}else {
			result = new DropResult();
		}
		//--------------------------------------首破奖励------------------------------------------
		if(breakTop){
			if(StringUtils.isNotBlank(mission.getFirstBreakRewards())){
				List<Reward> rewards = rewardService.parseRewards(playerId, mission.getFirstBreakRewards(), false);
				result.addRewards(rewards);
			}
		}
		//奖励串
		List<Integer> armyList = mission.getArmyList();
		for (Integer armyId : armyList) {
			ArmageddonArmy army = basedbService.get(ArmageddonArmy.class, armyId);
			if(StringUtils.isNotBlank(army.getRewards())){
				List<Reward> rewards = rewardService.parseRewards(playerId, army.getRewards(), false);
				result.addRewards(rewards);
			}
			//掉落编号
			if(StringUtils.isNotBlank(army.getDrops())){
				DropResult rropResult = dropService.doDrop(playerId, army.getDrops());
				result.add(rropResult, true);
			}
		}
		//战斗掉落
		for (int i = 0; i < 3; i++) {
			List<BattleResult> battleResults = attackResultDto.getBattleResult(i);
			for (BattleResult battleResult : battleResults) {
				if(battleResult!= null){
					List<String> dropResult = battleResult.getDropResult();
					if(dropResult!=null && !dropResult.isEmpty()){
						for (String drop : dropResult) {
							DropResult rropResult = dropService.doDrop(playerId, drop);
							result.add(rropResult, true);				
						}
					}
				}
			}
		}
		//--------------------------------------执行奖励-----------------------------------------
		ChainLock lock = LockUtils.getLock(player);
		try{
			lock.lock();

			playerChapterInfo.setReward(true);
			//通关奖励
			Vip vip = basedbService.get(Vip.class, player.getVipAndTmpVipLevel());
			double buffRate = vip.getArmageddonExp();
			if(StringUtils.isNotBlank(mission.getRewards())){
				List<Reward> rewards = rewardService.parseRewards(playerId, mission.getRewards(), false);
				//VIP多人副本经验加成
				if(buffRate > 1){
					for (Reward reward : rewards) {
						if(RewardType.PLAYER_EXP.equals(reward.getType())){
							reward.increase(Double.valueOf(reward.getCount()*(buffRate - 1)).intValue());
						}
					}
				}
				result.addRewards(rewards);
			}
			//通关掉落 
			if(StringUtils.isNotBlank(mission.getDrops())){
				DropResult rropResult = dropService.doDrop(playerId, mission.getDrops());
				result.add(rropResult, true);
			}
			playerChapterInfo.setRewardResult(result.toRewardString());
			playerChapterInfo.setNoticeResult(result.toDropNoticeString());
			attackResultDto.setRewardList(RewardHelper.toRewardString(result.getRewardList()));
			dbCachedService.submitUpdated2Queue(playerChapterInfo.getId(), playerChapterInfo.getClass());
		} finally{
			lock.unlock();
		}
		return ArmageddonResult.SUCCESS;
	}
	private class ArmyUnit{
		public int key;
		public int armyId;
		public ArmyUnit(int key, int armyId) {
			super();
			this.key = key;
			this.armyId = armyId;
		}
	}
	//战斗处理
	private void doFightWithFuben(AttackConext attackConext,
			AttackResultDto attackResultDto) {
		Player player = attackConext.player;
		PlayerArmageddonInfo playerChapterInfo = attackConext.playerArmageddonInfo;
		ArmageddonMission mission = attackConext.mission;
		
		long playerId = player.getId();

		ArmageddonCheerInfo cheerInfo = getArmageddonCheerInfo(playerId);
		List<Integer> armyIdList = mission.getArmyList();
		List<ArmyUnit> armyIdOneList = new ArrayList<ArmyUnit>();
		List<ArmyUnit> armyIdTwoList = new ArrayList<ArmyUnit>();
		List<ArmyUnit> armyIdThreeList = new ArrayList<ArmyUnit>();
		Map<Integer, List<BattleCharacter>> armyMap = new HashMap<Integer, List<BattleCharacter>>();
		Map<Integer, BattlePlayerInfo> armyInfoMap = new HashMap<Integer, BattlePlayerInfo>();
		List<BattleCharacter> userOneUnit = null;
		List<BattleCharacter> userTwoUnit = null;
		List<BattleCharacter> userThreeUnit = null;
		BattlePlayerInfo userOneBpi = null;
		BattlePlayerInfo userTwoBpi = null;
		BattlePlayerInfo userThreeBpi = null;
		if(cheerInfo.loadIdByIndex(1) == null || cheerInfo.loadIdByIndex(2) == null || cheerInfo.loadIdByIndex(3) == null){
			userOneUnit = playerService.getPlayerBattleCharacter(playerId, false);
			userOneBpi = new BattlePlayerInfo(dbCachedService.get(playerId, Player.class));
			userTwoUnit = playerService.getUserBattleCharacter(cheerInfo.getCheerIdOne());
			userTwoBpi = new BattlePlayerInfo(dbCachedService.get(cheerInfo.getCheerIdOne(), Player.class));
			userThreeUnit = playerService.getUserBattleCharacter(cheerInfo.getCheerIdTwo());
			userThreeBpi = new BattlePlayerInfo(dbCachedService.get(cheerInfo.getCheerIdTwo(), Player.class));
		}else {
			Long id = cheerInfo.loadIdByIndex(1);
			if(id == playerId){
				userOneUnit = playerService.getPlayerBattleCharacter(id, false);
			}else {
				userOneUnit = playerService.getUserBattleCharacter(id);
			}
			userOneBpi = new BattlePlayerInfo(dbCachedService.get(id, Player.class));
			id = cheerInfo.loadIdByIndex(2);
			if(id == playerId){
				userTwoUnit = playerService.getPlayerBattleCharacter(id, false);
			}else {
				userTwoUnit = playerService.getUserBattleCharacter(id);
			}
			userTwoBpi = new BattlePlayerInfo(dbCachedService.get(id, Player.class));
			id = cheerInfo.loadIdByIndex(3);
			if(id == playerId){
				userThreeUnit = playerService.getPlayerBattleCharacter(id, false);
			}else {
				userThreeUnit = playerService.getUserBattleCharacter(id);
			}
			userThreeBpi = new BattlePlayerInfo(dbCachedService.get(id, Player.class));
		}

		
		int key = 0;
		for (int i = 0; i < armyIdList.size();  i = i + 3) {
			key = i;
			if(armyIdList.size() <= key){
				break;
			}
			ArmageddonArmy fubenArmy = this.basedbService.get(ArmageddonArmy.class, armyIdList.get(key));
			double ability = armageddonRuleService.getAbility(fubenArmy.getId());
			BattlePlayerInfo battlePlayerInfo = new BattlePlayerInfo(fubenArmy.getNpcName(), fubenArmy.getNpcLevel(), fubenArmy.getNpcPic(), ability);
			armyIdOneList.add(new ArmyUnit(key, armyIdList.get(key)));
			armyMap.put(key, armageddonRuleService.getFightUnit(armyIdList.get(key)));
			armyInfoMap.put(key, battlePlayerInfo);
			key = i+1;
			if(armyIdList.size() <= key){
				break;
			}
			fubenArmy = this.basedbService.get(ArmageddonArmy.class, armyIdList.get(key));
			ability = armageddonRuleService.getAbility(fubenArmy.getId());
			battlePlayerInfo = new BattlePlayerInfo(fubenArmy.getNpcName(), fubenArmy.getNpcLevel(), fubenArmy.getNpcPic(), ability);
			armyIdTwoList.add(new ArmyUnit(key, armyIdList.get(key)));
			armyMap.put(key, armageddonRuleService.getFightUnit(armyIdList.get(key)));
			armyInfoMap.put(key, battlePlayerInfo);
			key = i+2;
			if(armyIdList.size() <= key){
				break;
			}
			fubenArmy = this.basedbService.get(ArmageddonArmy.class, armyIdList.get(key));
			ability = armageddonRuleService.getAbility(fubenArmy.getId());
			battlePlayerInfo = new BattlePlayerInfo(fubenArmy.getNpcName(), fubenArmy.getNpcLevel(), fubenArmy.getNpcPic(), ability);
			armyIdThreeList.add(new ArmyUnit(key, armyIdList.get(key)));
			armyMap.put(key, armageddonRuleService.getFightUnit(armyIdList.get(key)));
			armyInfoMap.put(key, battlePlayerInfo);
		}
		List<ArmyUnit> moreArmy = new ArrayList<ArmyUnit>();
		BattleGroup offenseGroup = null;
		BattleGroup defenseGroup = null;
		//多人副本的的key，客户端需要做唯一标识
		int oneTeamKey = key+1;int twoTeamKey = key+2;int threeTeamKey = key+3;
		//2013-8-8 新增准备双方的信息用于客户端展示
		offenseGroup = new BattleGroup(BattleTeam.OFFENSE_TEAM, userOneUnit, userOneBpi, 0, oneTeamKey);
		attackResultDto.addAttackOneGroup(offenseGroup.toBattleGroupDto());
		offenseGroup = new BattleGroup(BattleTeam.OFFENSE_TEAM, userTwoUnit, userTwoBpi, 0, twoTeamKey);
		attackResultDto.addAttackTwoGroup(offenseGroup.toBattleGroupDto());
		offenseGroup = new BattleGroup(BattleTeam.OFFENSE_TEAM, userThreeUnit, userThreeBpi, 0, threeTeamKey);
		attackResultDto.addAttackThreeGroup(offenseGroup.toBattleGroupDto());
		for (ArmyUnit armyUnit : armyIdOneList) {
			List<BattleCharacter> armyList = armyMap.get(armyUnit.key);
			BattlePlayerInfo armyBpi = armyInfoMap.get(armyUnit.key);
			defenseGroup = new BattleGroup(BattleTeam.DEFENSE_TEAM, armyList, armyBpi, 0, armyUnit.key);
			attackResultDto.addDefendOneGroup(defenseGroup.toBattleGroupDto());
		}
		for (ArmyUnit armyUnit : armyIdTwoList) {
			List<BattleCharacter> armyList = armyMap.get(armyUnit.key);
			BattlePlayerInfo armyBpi = armyInfoMap.get(armyUnit.key);
			defenseGroup = new BattleGroup(BattleTeam.DEFENSE_TEAM, armyList, armyBpi, 0, armyUnit.key);
			attackResultDto.addDefendTwoGroup(defenseGroup.toBattleGroupDto());
		}
		for (ArmyUnit armyUnit : armyIdThreeList) {
			List<BattleCharacter> armyList = armyMap.get(armyUnit.key);
			BattlePlayerInfo armyBpi = armyInfoMap.get(armyUnit.key);
			defenseGroup = new BattleGroup(BattleTeam.DEFENSE_TEAM, armyList, armyBpi, 0, armyUnit.key);
			attackResultDto.addDefendThreeGroup(defenseGroup.toBattleGroupDto());
		}
		ArmyUnit armyUnit;
		boolean die1 = false;boolean die2 = false;boolean die3 = false;
		List<ArmyUnit> pointArmy = null;//指针引用列
		for (int i = 0; i < armyIdList.size(); i++) {
			//第一列战斗
			if(!die1){
				if(!armyIdOneList.isEmpty()){
					pointArmy = armyIdOneList;
				}else if(!moreArmy.isEmpty()){
					pointArmy = moreArmy;
				}else {
					pointArmy = null;
				}
				if(pointArmy != null){
					armyUnit = pointArmy.get(0);
					ArmageddonArmy army = basedbService.get(ArmageddonArmy.class, armyUnit.armyId);
					List<BattleCharacter> armyList = armyMap.get(armyUnit.key);
					BattlePlayerInfo armyBpi = armyInfoMap.get(armyUnit.key);
					if(army.isArmyAttack()){
						offenseGroup = new BattleGroup(BattleTeam.OFFENSE_TEAM, armyList, armyBpi, 0, armyUnit.key);
						defenseGroup = new BattleGroup(BattleTeam.DEFENSE_TEAM, userOneUnit, userOneBpi, 0, oneTeamKey);
					}else {
						offenseGroup = new BattleGroup(BattleTeam.OFFENSE_TEAM, userOneUnit, userOneBpi, 0, oneTeamKey);
						defenseGroup = new BattleGroup(BattleTeam.DEFENSE_TEAM, armyList, armyBpi, 0, armyUnit.key);
					}
					Battle battle = new Battle(BattleType.PVE, offenseGroup, defenseGroup, false);
					battle.createBattleRound();
					BattleResult battleResult = battle.getBattleResult();
					boolean attackWin = !army.isArmyAttack() ? battleResult.getWinner().equals(BattleWinner.OFFENSE_TEAM) : battleResult.getWinner().equals(BattleWinner.DEFENSE_TEAM);
					attackResultDto.addBattleOneResult(battleResult);
					if(attackWin){
						pointArmy.remove(armyUnit);
					}else {
						die1 = true;
						moreArmy.addAll(armyIdOneList);
					}
				}
			}
			//第二列战斗
			if(!die2){
				if(!armyIdTwoList.isEmpty()){
					pointArmy = armyIdTwoList;
				}else if(!moreArmy.isEmpty()){
					pointArmy = moreArmy;
				}else {
					pointArmy = null;
				}
				if(pointArmy != null){
					armyUnit = pointArmy.get(0);
					ArmageddonArmy army = basedbService.get(ArmageddonArmy.class, armyUnit.armyId);
					List<BattleCharacter> armyList = armyMap.get(armyUnit.key);
					BattlePlayerInfo armyBpi = armyInfoMap.get(armyUnit.key);
					if(army.isArmyAttack()){
						offenseGroup = new BattleGroup(BattleTeam.OFFENSE_TEAM, armyList, armyBpi, 0, armyUnit.key);
						defenseGroup = new BattleGroup(BattleTeam.DEFENSE_TEAM, userTwoUnit, userTwoBpi, 0, twoTeamKey);
					}else {
						offenseGroup = new BattleGroup(BattleTeam.OFFENSE_TEAM, userTwoUnit, userTwoBpi, 0, twoTeamKey);
						defenseGroup = new BattleGroup(BattleTeam.DEFENSE_TEAM, armyList, armyBpi, 0, armyUnit.key);
					}
					Battle battle = new Battle(BattleType.PVE, offenseGroup, defenseGroup, false);
					battle.createBattleRound();
					BattleResult battleResult = battle.getBattleResult();
					boolean attackWin = !army.isArmyAttack() ? battleResult.getWinner().equals(BattleWinner.OFFENSE_TEAM) : battleResult.getWinner().equals(BattleWinner.DEFENSE_TEAM);
					attackResultDto.addBattleTwoResult(battleResult);
					if(attackWin){
						pointArmy.remove(armyUnit);
					}else {
						die2 = true;
						moreArmy.addAll(armyIdTwoList);
					}
				}
			}
			//第三列战斗
			if(!die3){
				if(!armyIdThreeList.isEmpty()){
					pointArmy = armyIdThreeList;
				}else if(!moreArmy.isEmpty()){
					pointArmy = moreArmy;
				}else {
					pointArmy = null;
				}
				if(pointArmy != null){
					armyUnit = pointArmy.get(0);
					ArmageddonArmy army = basedbService.get(ArmageddonArmy.class, armyUnit.armyId);
					List<BattleCharacter> armyList = armyMap.get(armyUnit.key);
					BattlePlayerInfo armyBpi = armyInfoMap.get(armyUnit.key);
					if(army.isArmyAttack()){
						offenseGroup = new BattleGroup(BattleTeam.OFFENSE_TEAM, armyList, armyBpi, 0, armyUnit.key);
						defenseGroup = new BattleGroup(BattleTeam.DEFENSE_TEAM, userThreeUnit, userThreeBpi, 0, threeTeamKey);
					}else {
						offenseGroup = new BattleGroup(BattleTeam.OFFENSE_TEAM, userThreeUnit, userThreeBpi, 0, threeTeamKey);
						defenseGroup = new BattleGroup(BattleTeam.DEFENSE_TEAM, armyList, armyBpi, 0, armyUnit.key);
					}
					Battle battle = new Battle(BattleType.PVE, offenseGroup, defenseGroup, false);
					battle.createBattleRound();
					BattleResult battleResult = battle.getBattleResult();
					boolean attackWin = !army.isArmyAttack() ? battleResult.getWinner().equals(BattleWinner.OFFENSE_TEAM) : battleResult.getWinner().equals(BattleWinner.DEFENSE_TEAM);
					attackResultDto.addBattleThreeResult(battleResult);
					if(attackWin){
						pointArmy.remove(armyUnit);
					}else {
						die3 = true;
						moreArmy.addAll(armyIdThreeList);
					}
				}
			}
			if(pointArmy == null || (die1 && die2 && die3)){
				break;
			}
		}
		//扣减玩家兵力数量
		heroService.reduceSoldiers(playerId, userOneUnit);
		boolean attackWin = !die1 || !die2 || !die3;
		ChainLock lock = LockUtils.getLock(player);
		try{
			lock.lock();
			if(attackWin){
				boolean topArmy = false;
				if(mission.getFubenId() > playerChapterInfo.getLastMissionId()){
					playerChapterInfo.setLastMissionId(mission.getFubenId());
					topArmy = true;
				}
				if(topArmy){
					attackResultDto.setBreakTop(true);
				}
			} else {
				playerChapterInfo.setCurMissionId(PlayerArmageddonInfo.INIT_VALUE);
				playerChapterInfo.setReward(false);
				playerChapterInfo.setRewardResult("");
				playerChapterInfo.setNoticeResult("");
			}
			this.dbCachedService.submitUpdated2Queue(playerChapterInfo.getId(), playerChapterInfo.getClass());
		} finally{
			lock.unlock();
		}
		attackResultDto.setWin(attackWin);
	}

	//进攻消耗
	private int doEnergyWithFuben(Player player, ArmageddonMission mission) {
		RewardActionSet rewardActionSet = rewardService.tryRewards(player.getId(), mission.getCostExpr(), InBagRule.MAIL_IF_FULL, true);
		if (rewardActionSet != null && rewardActionSet.isNotOK()) {
			return rewardActionSet.getResultCode();
		}
		return ArmageddonResult.SUCCESS;  
	}

	/**
	 * 试图攻击单人副本部队
	 * @return
	 */
	private int tryAttack(AttackConext attackConext){
		PlayerArmageddonInfo playerChapterInfo = attackConext.playerArmageddonInfo;
		/*FightContext fightContext = attackConext.fightContext;*/
		/*ArmageddonMission mission = attackConext.mission;*/
		
		/*int attackAreaId = mission.getId();*/
		
		if(playerChapterInfo.getHookStatus() == HookStatus.HOOK){//判断挂机
			return ArmageddonResult.HOOKING;
		}
		if(playerChapterInfo.getMissionId() == PlayerArmageddonInfo.INIT_VALUE){//必须先进入据点然后才能攻击怪物
			return ArmageddonResult.NOT_ENTER_FUBEN;
		}
		/*boolean skipFightCD = false;*/
		/*if(this.isAreaBreaked(playerChapterInfo.getMissionId(), playerChapterInfo.getCurArmyId(), attackAreaId, playerChapterInfo.getHardType())){
			//如果需要判断玩家是否为VIP
//				skipFightCD = true;
		}*/
		/*if(!skipFightCD){//跳过战斗判断
			long currMillis = System.currentTimeMillis();
			long coolMillis = fightContext.fightCoolMillis;
			if(fightContext.singleAttackTime + coolMillis >= currMillis){
				return ArmageddonResult.ATTACK_COOLING;
			}
		}*/
		/*if(attackAreaId > playerChapterInfo.getMissionId()){
			return ArmageddonResult.ATTACK_ARMY_NOT_ORDER;
		}*/
//		int currAreaId = playerChapterInfo.getMissionId();
		//判断内存状态只能接着刚才的打
		/*synchronized (fightContext) {
			if(fightContext.singleAttackTime >= fightContext.abandonTime){//没有放弃过
				if(playerChapterInfo.getCurMissionId() == PlayerArmageddonInfo.INIT_VALUE){//刚才没有攻击过
					if(!this.armageddonRuleService.isArmyHeadOfArea(attackArmyId)){
						return ArmageddonResult.ATTACK_ARMY_NOT_ORDER;  
					}
				} else {
					ArmageddonArmy attackedArmy = this.basedbService.get(ArmageddonArmy.class, playerChapterInfo.getCurArmyId());
					if(attackedArmy == null){
						return ArmageddonResult.BASE_DATA_NOT_EXIST;
					}
					
					if(attackArmyId != playerChapterInfo.getCurArmyId()){
						return ArmageddonResult.ATTACK_ARMY_NOT_ORDER; 
					}
				}
				
			} else {//放弃过就必须打据点的第一支部队
				if(!this.armageddonRuleService.isArmyHeadOfArea(attackArmyId)){
					return ArmageddonResult.ATTACK_ARMY_NOT_ORDER;
				}
			}
			
			fightContext.singleAttackTime = System.currentTimeMillis();
		}*/
		return ArmageddonResult.SUCCESS;   
	}
	
	/*private boolean isAreaBreaked(int myAreaId, int myArmyId, int areaId, HardType hardType) {
		if(myArmyId == PlayerArmageddonInfo.INIT_VALUE){
			return false;
		}
		
		if(myAreaId > areaId){
			return true;
		} else if(myAreaId == areaId){
			if(this.armageddonRuleService.isArmyTailOfArea(myArmyId, hardType)){
				return true;
			}
		}
		return false;
	}*/

	private class AttackConext {
		
		private Player player;
		
		private PlayerArmageddonInfo playerArmageddonInfo;
		
		private ArmageddonMission mission;
		
		public AttackConext(Player player, PlayerArmageddonInfo playerArmageddonInfo,
				FightContext fightContext, ArmageddonMission mission) {
			super();
			this.player = player;
			this.playerArmageddonInfo = playerArmageddonInfo;
			this.mission = mission;
		}
		
	}
	//单人副本战斗内部类
	private class FightContext{
		
		/**是否正在攻击*/
		private AtomicBoolean fighting = new AtomicBoolean(false);
		
		
		private boolean lockFight(){
			return fighting.compareAndSet(false, true);
		}
		
		private void unlockFight(){
			fighting.compareAndSet(true, false);
		}
		
	}
	public PlayerArmageddonInfo getPlayerArmageddonInfo(Long playerId){
		PlayerArmageddonInfo playerChapterInfo = dbCachedService.get(playerId, PlayerArmageddonInfo.class);
		if(playerChapterInfo == null){
			playerChapterInfo = new PlayerArmageddonInfo();
			playerChapterInfo.setId(playerId);
			playerChapterInfo = dbCachedService.submitNew2Queue(playerChapterInfo);
		}
		return playerChapterInfo;
	}
	private PlayerChapterInfo getPlayerChapterInfo(Long playerId){
		PlayerChapterInfo playerChapterInfo = dbCachedService.get(playerId, PlayerChapterInfo.class);
		if(playerChapterInfo == null){
			playerChapterInfo = new PlayerChapterInfo();
			playerChapterInfo.setId(playerId);
			playerChapterInfo = dbCachedService.submitNew2Queue(playerChapterInfo);
		}
		return playerChapterInfo;
	}
	//存放战斗上下文
	private ConcurrentLinkedHashMap<Long, FightContext> USER_FIGHT_MAP = new ConcurrentLinkedHashMap.Builder<Long, FightContext>().maximumWeightedCapacity(LRUConfig.CHAPTER).build();
	/**
	 * 获取用户的战斗上下文对象(没有就创建)
	 * @param userId 用户id
	 * @return
	 */
	private FightContext getFightContext(long userId){
		FightContext fightContext = USER_FIGHT_MAP.get(userId);
		if(fightContext == null){
			fightContext = new FightContext();
			FightContext contextInMap = USER_FIGHT_MAP.putIfAbsent(userId, fightContext);
			if(contextInMap != null){
				return contextInMap;
			} 
		}
		return fightContext;
	}

	@Override
	public Result<MissionRewardDto> rewardArea(long playerId) {
		Player player = dbCachedService.get(playerId, Player.class);
		if(player == null){
			return Result.Error(ArmageddonResult.PLAYER_NOT_EXISTS);
		}
		PlayerArmageddonInfo playerChapterInfo = getPlayerArmageddonInfo(playerId);
		if(!playerChapterInfo.isReward()){
			return Result.Error(ArmageddonResult.SINGLE_FUBEN_NOT_BREAK);
		}
		ArmageddonMission mission = basedbService.get(ArmageddonMission.class, playerChapterInfo.getCurMissionId());
		ArmageddonCheerInfo playerCheerInfo = getArmageddonCheerInfo(playerId);
		MissionRewardDto missionRewardDto = new MissionRewardDto();
		ChainLock chainLock = LockUtils.getLock(player);
		chainLock.lock();
		DropResult result = null;
		try {
			//清除邀请出战人信息
			/*playerCheerInfo.clearCheer();
			dbCachedService.submitUpdated2Queue(playerCheerInfo.getId(), playerCheerInfo.getClass());*/

			RewardActionSet rewardActionSet = rewardService.tryRewards(player.getId(), mission.getCostExpr(), InBagRule.MAIL_IF_FULL, true);
			if (rewardActionSet != null && rewardActionSet.isNotOK()) {
				return Result.Error(rewardActionSet.getResultCode());
			}
			if(StringUtils.isNotBlank(playerChapterInfo.getRewardResult())){//奖励预判
				result = dropService.parseDropResult(playerId, playerChapterInfo.getRewardResult(), playerChapterInfo.getNoticeResult());
				RewardActionSet ras = rewardService.tryRewards(playerId, result.getRewardList(), InBagRule.MAIL_IF_FULL, true);
				if (ras != null && ras.isNotOK()) {
					return Result.Error(ras.getResultCode());
				}
			}
			ValueResultSet valueResultSet = this.rewardService.executeRewards(playerId, rewardActionSet, LogSource.BREAK_ARMAGEDDON);
			missionRewardDto.setValueResultSet(valueResultSet);
			if(result != null){
				valueResultSet = this.dropService.executeDropsWithoutLock(playerId, result, InBagRule.MAIL_IF_FULL, true, LogSource.BREAK_ARMAGEDDON);
				if(valueResultSet != null){
					List<RewardResult<?>> results = valueResultSet.getResults();
					for (RewardResult<?> rewardResult : results) {
						missionRewardDto.getValueResultSet().addRewardResult(rewardResult);
					}
				}
			}
			//奖励功勋
			if(playerCheerInfo.getCheerIdOne() != -1){
				int state = playerCheerInfo.getCheerOneState();
				//玩家获得功勋
				int exploit = getCheerExploit(state);
				state = playerCheerInfo.getCheerTwoState();
				exploit += getCheerExploit(state);
				SimpleReward simpleReward = new SimpleReward(RewardType.EXPLOIT, exploit);
				rewardActionSet = rewardService.tryRewards(playerId, simpleReward, InBagRule.MAIL_IF_FULL, true);
				if(rewardActionSet != null && rewardActionSet.isNotOK()){
					return Result.Error(rewardActionSet.getResultCode());
				}
				valueResultSet = this.rewardService.executeRewards(playerId, rewardActionSet, LogSource.BREAK_MISSION);
				missionRewardDto.getValueResultSet().addAllRewardResult(valueResultSet.getResults());
			}
			//清除邀请出战人信息
			playerCheerInfo.clearCheer();
			dbCachedService.submitUpdated2Queue(playerCheerInfo.getId(), playerCheerInfo.getClass());
			playerChapterInfo.setReward(false);
			playerChapterInfo.setRewardResult("");
			playerChapterInfo.setNoticeResult("");
			playerChapterInfo.setCurMissionId(PlayerArmageddonInfo.INIT_VALUE);
			playerChapterInfo.decreaseRewardTime();
			if(mission.getFubenId() > playerChapterInfo.getLastMissionId()){
				playerChapterInfo.setLastMissionId(mission.getFubenId());
			}
			dbCachedService.submitUpdated2Queue(playerChapterInfo.getId(), playerChapterInfo.getClass());
		}finally{
			chainLock.unlock();
		}
		ArmageddonInfoDto journeyInfoDto = new ArmageddonInfoDto(playerChapterInfo, getRewardTimes(player));
		missionRewardDto.setArmageddonInfoDto(journeyInfoDto);
		return Result.Success(missionRewardDto);
	}

	/**
	 * 每天收益次数
	 * @return int
	 */
	private int getRewardTimes(Player player) {
		Vip vip = basedbService.get(Vip.class, player.getVipLevel());
		return vip.getArmageddonTimes();
	}

	/**
	 * 战斗CD时间
	 * @return int
	 */
	private long getCDTimes() {
		return this.gameRuleService.getAmountByID(GameRuleID.ARMAGEDDON_CD_TIME).longValue();
	}

	/**
	 * @description:得到实际的次数	
	 * @param resistBugInfo
	 * @return
	 */
	private int getIncomeTimes(Player player, PlayerArmageddonInfo playerInvadeInfo){
		int incomeTimes = 0;
		if(playerInvadeInfo.isRewardSameResetTime()){
			incomeTimes = getRewardTimes(player);
		}else {
			incomeTimes = playerInvadeInfo.getTimes();
		}
		return incomeTimes;
	}
	@Override
	public Result<CreateRoomDto> createRoom(long playerId) {
		PlayerArmageddonInfo playerChapterInfo = getPlayerArmageddonInfo(playerId);
		if(playerChapterInfo.isBattleCD()){
			return Result.Error(ArmageddonResult.BATTLE_CD);
		}
		CreateRoomDto createRoomDto = new CreateRoomDto();
		Player player = dbCachedService.get(playerId, Player.class);
		ChainLock lock = LockUtils.getLock(player);
		try{
			lock.lock();
			long roomNo = getNewRoomNo();
			createRoomDto.setRoomNo(roomNo);
		}finally{
			lock.unlock();
		}
		return Result.Success(createRoomDto);
	}
	
	private long getNewRoomNo(){
		if(CommonRule.isSameResetTime(teamDate, CommonRule.FOUR_HOUR_RESET_TIME)){
			teamNoGenerator = new AtomicLong(1L);
			teamDate = new Date();
		}
		long teamId = teamNoGenerator.incrementAndGet();
		return teamId;
	}
	public ArmageddonCheerInfo getArmageddonCheerInfo(long userId) {
		ArmageddonCheerInfo playerCheerInfo = dbCachedService.get(userId, ArmageddonCheerInfo.class);
		if(playerCheerInfo == null){
			playerCheerInfo = new ArmageddonCheerInfo();
			playerCheerInfo.setId(userId);
			playerCheerInfo = dbCachedService.submitNew2Queue(playerCheerInfo);
		}
		return playerCheerInfo;
	}

	private void sortFriendInfos(List<SortCheerInfo> friendInfos) {
		Collections.sort(friendInfos, new Comparator<SortCheerInfo>() {
			@Override
			public int compare(SortCheerInfo o1, SortCheerInfo o2) {
				if (o1.closeValue < o2.closeValue) {
					return -1;
				}
				if (o1.closeValue > o2.closeValue) {
					return 1;
				}
				return 1;
			}
			
		});
	}
	
	@Override
	public Result<CheerInfoDto> getCheerInfo(long userId) {
		CheerInfoDto cheerInfoDto = new CheerInfoDto();
		ArmageddonCheerInfo playerCheerInfo = getArmageddonCheerInfo(userId);
		Map<Long, Integer> cheerInfoMap = playerCheerInfo.getCheerInfoMap();
		int friendCount = 0;
		Player innerPlayer;PlayerCheerDto playerCheerDto;
		//需要排除的玩家ID，当前已在助阵列表中或者已经邀请CD
		List<Long> cdPlayerIds = new ArrayList<Long>();
		cdPlayerIds.add(userId);//包括自己
		//是否需要特殊功勋豪杰，没有好友的情况下默认给一位豪杰特殊功勋
		boolean isSpecial = true;
		if(!cheerInfoMap.isEmpty()){
			Set<Entry<Long, Integer>> entries = cheerInfoMap.entrySet();
			long playerId;Integer state;
			for (Entry<Long, Integer> entry : entries) {
				playerId = entry.getKey();
				state = entry.getValue();
				if(state == RelationState.STRANGER.ordinal() && isSpecial){
					isSpecial = false;
				}
				innerPlayer = dbCachedService.get(playerId, Player.class);
				playerCheerDto = new PlayerCheerDto(state, innerPlayer);
				cheerInfoDto.addPlayerCheerDto(playerCheerDto);
				cdPlayerIds.add(playerId);
				if(state == RelationState.FRIEND.ordinal())
					friendCount ++;
			}
		}
		int cheerLimit = getCheerLimit() - cheerInfoDto.size();
		Player player = dbCachedService.get(userId, Player.class);
		Map<Long, Integer> newInIdList = new HashMap<Long, Integer>();
		int levelLimit = getCheerLevel();
		if(cheerLimit > 0){
			Map<Long, Integer> cdPlayerMap = playerCheerInfo.getCdPlayerMap();
			cdPlayerIds.addAll(cdPlayerMap.keySet());
			//优先从好友里筛选
			int friendLimit = getCheerFriendLimit();
			if(friendCount < friendLimit){//好友数量不够
				int friendNum = friendLimit - friendCount;//需要增加的好友数量
				List<PlayerRelation> list = relationService.getPlayerRelationList(userId, RelationState.FRIEND);
				List<SortCheerInfo> levelFriends = new ArrayList<SortCheerInfo>();
				for (PlayerRelation rs : list) {
					long other = rs.getUserId() == userId ? rs.getOtherUserId() : rs.getUserId();
					if(!cdPlayerIds.contains(other)){
						Player friend = dbCachedService.get(other, Player.class);
						if(friend.getLevel() < levelLimit){
							continue;
						}
						levelFriends.add(new SortCheerInfo(other, (rs.getCloseLv()+getRandomValue())));
					}
				}
				if(levelFriends.size() <= friendNum){
					for (SortCheerInfo sortCheerInfo : levelFriends) {
						innerPlayer = dbCachedService.get(sortCheerInfo.playerId, Player.class);
						playerCheerDto = new PlayerCheerDto(RelationState.FRIEND.ordinal(), innerPlayer);
						cheerInfoDto.addPlayerCheerDto(playerCheerDto);
						cdPlayerIds.add(sortCheerInfo.playerId);
						newInIdList.put(sortCheerInfo.playerId, RelationState.FRIEND.ordinal());
						friendCount ++;
					}
				}else {
					//排序
					sortFriendInfos(levelFriends);
					for (int i = 0; i < friendNum; i++) {
						if(levelFriends.size() < (i+1)){
							break;
						}
						SortCheerInfo sortCheerInfo = levelFriends.get(i);
						innerPlayer = dbCachedService.get(sortCheerInfo.playerId, Player.class);
						playerCheerDto = new PlayerCheerDto(RelationState.FRIEND.ordinal(), innerPlayer);
						cheerInfoDto.addPlayerCheerDto(playerCheerDto);
						cdPlayerIds.add(sortCheerInfo.playerId);
						newInIdList.put(sortCheerInfo.playerId, RelationState.FRIEND.ordinal());
						friendCount ++;
					}
				}
			}
		}
		if(friendCount > 0 && isSpecial){
			isSpecial = false;
		}
		cheerLimit = getCheerLimit() - cheerInfoDto.size();
		if(cheerLimit > 0){//取豪杰
			List<Long> idList = relationService.getLevelPlayer(levelLimit, cheerLimit, cdPlayerIds);
			for (Long id : idList) {
				innerPlayer = dbCachedService.get(id, Player.class);
				int state = RelationState.NONE.ordinal();
				if(isSpecial){
					state = RelationState.STRANGER.ordinal();
					isSpecial = false;
				}
				playerCheerDto = new PlayerCheerDto(state, innerPlayer);
				cheerInfoDto.addPlayerCheerDto(playerCheerDto);
				newInIdList.put(id, state);
			}
		}
		if(!newInIdList.isEmpty()){
			ChainLock lock = LockUtils.getLock(player);
			try{
				lock.lock();
				cheerInfoMap = playerCheerInfo.getCheerInfoMap();
				cheerInfoMap.putAll(newInIdList);
				playerCheerInfo.setCheerInfo(playerCheerInfo.cheerInfoMap2String());
				dbCachedService.submitUpdated2Queue(playerCheerInfo.getId(), playerCheerInfo.getClass());
			}finally{
				lock.unlock();
			}
		}
		if(!playerCheerInfo.getCheerIdOne().equals(ArmageddonCheerInfo.INIT_VALUE)){
			Player cheerPlayer = dbCachedService.get(playerCheerInfo.getCheerIdOne(), Player.class);
			if(cheerPlayer != null){
				PlayerCheerDto cheerDto = new PlayerCheerDto(0, cheerPlayer);
				cheerInfoDto.addCheerPlayers(cheerDto);
			}
		}
		if(!playerCheerInfo.getCheerIdTwo().equals(ArmageddonCheerInfo.INIT_VALUE)){
			Player cheerPlayer = dbCachedService.get(playerCheerInfo.getCheerIdTwo(), Player.class);
			if(cheerPlayer != null){
				PlayerCheerDto cheerDto = new PlayerCheerDto(0, cheerPlayer);
				cheerInfoDto.addCheerPlayers(cheerDto);
			}
		}
		return Result.Success(cheerInfoDto);
	}
	
	/**
	 * @description:获得助阵好友列表总数
	 * @return
	 */
	private int getCheerLimit(){
		return this.gameRuleService.getAmountByID(GameRuleID.ARMAGEDDONCHEER_LIMIT).intValue();
	}
	
	/**
	 * @description:获得助阵好友 好友数量
	 * @return
	 */
	private int getCheerFriendLimit(){
		int minValue = this.gameRuleService.getAmountByID(GameRuleID.ARMAGEDDONCHEER_FRIEND_LOW).intValue();
		int maxValue = this.gameRuleService.getAmountByID(GameRuleID.ARMAGEDDONCHEER_FRIEND_HIGH).intValue();
		return RandomUtil.betweenValue(minValue, maxValue);
	}
	
	/**
	 * @description:用于排序的伪随机数	
	 * @return
	 */
	private int getRandomValue(){
		return RandomUtil.betweenValue(1, 5);
	}
	
	/**
	 * @description:助阵好友筛选等级段范围
	 * @return
	 */
	private int getCheerLevel(){
		return this.gameRuleService.getAmountByID(GameRuleID.ARMAGEDDON_LV_LIMIT).intValue();
	}
	private final static Integer REMOVEKEY_INTEGER = 1;
	
	public int inviteCheerInfo(long userId, long cheerIdOne, long cheerIdTwo, String formation, EnterInfoDto result) {
		ArmageddonCheerInfo playerCheerInfo = getArmageddonCheerInfo(userId);
		if(!playerCheerInfo.containCheerId(cheerIdOne) || !playerCheerInfo.containCheerId(cheerIdTwo)){
			return ArmageddonResult.INVALID_CHEER;
		}
		
		Map<Long, Integer> cdPlayerMap = playerCheerInfo.getCdPlayerMap();
		Set<Entry<Long, Integer>> entries = cdPlayerMap.entrySet();
		if(!entries.isEmpty()){
			List<Entry<Long, Integer>> outTimeIds = new ArrayList<Entry<Long, Integer>>();
			for (Entry<Long, Integer> entry : entries) {
				int round = entry.getValue();
				if(round != REMOVEKEY_INTEGER){
					entry.setValue(round - 1);
				}else {
					outTimeIds.add(entry);
				}
			}
			entries.removeAll(outTimeIds);
		}
		Map<Long, Integer> cheerInfoMap = playerCheerInfo.getCheerInfoMap();
		int cheerOneState = cheerInfoMap.get(cheerIdOne);
		/*//玩家获得功勋
		int exploit = getCheerExploit(state);*/
		int cheerTwoState = cheerInfoMap.get(cheerIdTwo);
		/*exploit += getCheerExploit(state);*/
		/*SimpleReward simpleReward = new SimpleReward(RewardType.EXPLOIT, exploit);
		RewardActionSet rewardActionSet = rewardService.tryRewards(userId, simpleReward, true, true);
		if(rewardActionSet != null && rewardActionSet.isNotOK()){
			return rewardActionSet.getResultCode();
		}*/
		cdPlayerMap.put(cheerIdOne, getCheerCD());
		cdPlayerMap.put(cheerIdTwo, getCheerCD());
		cheerInfoMap.remove(cheerIdOne);
		cheerInfoMap.remove(cheerIdTwo);
		playerCheerInfo.setCdPlayerInfo(playerCheerInfo.cdPlayerMap2String());
		playerCheerInfo.setCheerInfo(playerCheerInfo.cheerInfoMap2String());
		playerCheerInfo.setCheerIdOne(cheerIdOne);
		playerCheerInfo.setCheerOneState(cheerOneState);
		playerCheerInfo.setCheerIdTwo(cheerIdTwo);
		playerCheerInfo.setCheerTwoState(cheerTwoState);
		playerCheerInfo.setFormation(formation);
		playerCheerInfo.reflushFormationMap();
		dbCachedService.submitUpdated2Queue(playerCheerInfo.getId(), playerCheerInfo.getClass());
		/*ValueResultSet valueResultSet = rewardService.executeRewards(userId, rewardActionSet, LogSource.ARMAGEDDON_CHEER);
		result.setValueResultSet(valueResultSet);*/
		return ArmageddonResult.SUCCESS;
	}
	/**
	 * @description:得到邀请好友CD回合
	 * @param state
	 * @return
	 */
	private int getCheerCD(){
		return this.gameRuleService.getAmountByID(GameRuleID.ARMAGEDDONCHEER_CD).intValue();
	}
	
	/**
	 * @description:得到奖励功勋	
	 * @param state
	 * @return
	 */
	private int getCheerExploit(int state){
		if(state == RelationState.NONE.ordinal()){
			return this.gameRuleService.getAmountByID(GameRuleID.EXPLOIT).intValue();
		}
		return this.gameRuleService.getAmountByID(GameRuleID.FRIEND_EXPLOIT).intValue();
	}
	
	@Override
	public Result<FlushCheerDto> costFlushCheerInfo(long userId, long cheerId) {
		ArmageddonCheerInfo playerCheerInfo = getArmageddonCheerInfo(userId);
		Player player = dbCachedService.get(userId, Player.class);
		ChainLock lock = LockUtils.getLock(player);
		FlushCheerDto flushCheerDto = new FlushCheerDto();
		try{
			lock.lock();
			int count = getCheerCost();
			int newCount = vipService.getGoldDiscountValue(player, count);
			flushCheerDto.setDiscountValue(Math.abs(count - newCount));
			SimpleReward simpleReward = SimpleReward.valueOf(RewardType.MONEY_MIX, newCount);
			RewardActionSet rewardActionSet = rewardService.tryRewards(userId, simpleReward, InBagRule.MAIL_IF_FULL, true);
			if(rewardActionSet != null && rewardActionSet.isNotOK()){
				return Result.Error(rewardActionSet.getResultCode());
			}
			ValueResultSet valueResultSet = rewardService.executeRewards(userId, rewardActionSet, LogSource.RELATION_CHEER);
			playerCheerInfo.clearInfo(cheerId);
			dbCachedService.submitUpdated2Queue(playerCheerInfo.getId(), playerCheerInfo.getClass());
			flushCheerDto.setValueResultSet(valueResultSet);
		}finally{
			lock.unlock();
		}
		Result<CheerInfoDto> rs = this.getCheerInfo(userId);
		CheerInfoDto cheerInfoDto = (CheerInfoDto)rs.get(Result.CONTENT);
		flushCheerDto.setPlayerCheerDtos(cheerInfoDto.getPlayerCheerDtos());
		return Result.Success(flushCheerDto);
	}
	
	/**
	 * @description:刷新邀请助战 消费 元宝数 
	 * @return
	 */
	private int getCheerCost(){
		return this.gameRuleService.getGoldById(GoldRuleID.ARMAGEDDONCHEER_COST);
	}
	
	/**
	 * @description:大决战 每1分钟 CD购买花费元宝数
	 * @return
	 */
	private int getBuyTimeCost(){
		return this.gameRuleService.getGoldById(GoldRuleID.ARMAGEDDONBUY_TIME);
	}
	@Override
	public Result<BuyTimeDto> buyTime(long playerId) {
		PlayerArmageddonInfo playerChapterInfo = getPlayerArmageddonInfo(playerId);
		if(!playerChapterInfo.isBattleCD()){
			return Result.Error(ArmageddonResult.NOT_CD);
		}
		Player player = dbCachedService.get(playerId, Player.class);
		Vip vip = basedbService.get(Vip.class, player.getVipAndTmpVipLevel());
		double clearCoolTime = vip.getClearArmageddonCoolTime();
		ChainLock lock = LockUtils.getLock(player);
		BuyTimeDto buyTimeDto = new BuyTimeDto();
		try{
			lock.lock();
			if(!playerChapterInfo.isBattleCD()){
				return Result.Error(ArmageddonResult.NOT_CD);
			}
			long now = System.currentTimeMillis();
			long time = Math.abs(now - playerChapterInfo.getBattleCdTime());
			long min = time/TimeConstant.ONE_MINUTE_MILLISECOND;
			if(time%TimeConstant.ONE_MINUTE_MILLISECOND > 0){//不足一分钟，按一分钟计算
				min += 1;
			}
			int cost = Long.valueOf(min*getBuyTimeCost()).intValue();
			//取得VIP实际折后的值
			int value = vipService.getVipValue(cost, clearCoolTime);
			
			buyTimeDto.setDiscountValue(cost - value);
			if(value > 0){
				SimpleReward reward = SimpleReward.valueOf(RewardType.MONEY_MIX, value);
				RewardActionSet rewardActionSet = rewardService.tryRewards(playerId, reward, InBagRule.MAIL_IF_FULL, true);
				if(rewardActionSet != null && rewardActionSet.isNotOK()){
					return Result.Error(rewardActionSet.getResultCode());
				}
				ValueResultSet valueResultSet = rewardService.executeRewards(playerId, rewardActionSet, LogSource.INVADE_BUY);
				buyTimeDto.setValueResultSet(valueResultSet);
			}
			playerChapterInfo.setBattleCdTime(-1l);
			dbCachedService.submitUpdated2Queue(playerChapterInfo.getId(), playerChapterInfo.getClass());
			
		}finally{
			lock.unlock();
		}
		ArmageddonInfoDto chapterInfoDto = new ArmageddonInfoDto(playerChapterInfo, getRewardTimes(player));
		buyTimeDto.setArmageddonInfoDto(chapterInfoDto);
		return Result.Success(buyTimeDto);
	}
}

