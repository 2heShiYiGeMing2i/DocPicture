/**
 * @file:SkillEffectTriger.java
 * @author:David
 **/
package com.xx.dev.constant;
/**
 * @class:SkillEffectTriger
 * @description:技能效果触发点
 * @author:David
 * @version:v1.0
 * @date:2013-4-19
 **/
public enum SkillEffectTriger {

	/** 0-无, 由具体效果决定 */
	NONE,
	
	/** 1-战斗初始(刚进入战斗) */
	FIGHT_INIT,
	
	/** 2-每回合开始 */
	EVERY_ROUND,
	
	/** 3-出手前 */
	BEFORE_ATTACK,
	
	/** 4-攻击时 */
	ATTACK,
	
	/** 5-队友攻击时*/
	PARTNER_ATTACK,
	
	/** 6-受击时 */
	BE_ATTACKED,
	
	/** 7-死亡时 */
	DEAD,

	/** 8-出手结束 */
	ATTACK_END,
	
	/** 9-每回合结束 */
	EVERY_ROUND_END,
	
	/** 10-暴击时 */
	CRIT,
	
	/** 11-格挡时*/
	RESIST,
	
	/** 12-击杀时：击杀敌方目标时 */
	KILL,
	
	/** 13-释放特定类型技能时*/
	SKILL;
}

