package com.xx.dev.combineserver;

import java.util.Properties;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.support.PropertiesLoaderUtils;

/**
 * JDBC配置
 * 
 * @author Along
 *
 */
public class JdbcCfg {

	private static Logger logger = LoggerFactory.getLogger(JdbcCfg.class);

	private static final String config_file_name = "jdbc.properties";
	
	private static final String JDBC_URL = "jdbc.url";
	
	private static final String JDBC_USERNAME = "jdbc.username";
	
	private static final String JDBC_PASSWORD = "jdbc.password";

	private static Properties properties = null;
	
	public static boolean ready = false;
	
	public static ServerInfo serverInfo;
	
	static {
		init();
	}
	
	/**
	 * 刷新配置
	 */
	public static void init(){
		try {
			properties = PropertiesLoaderUtils.loadProperties(new ClassPathResource(config_file_name));
			String jdbcUrl = String.valueOf(getProperty(JDBC_URL));
			String userName = String.valueOf(getProperty(JDBC_USERNAME));
			String password = String.valueOf(getProperty(JDBC_PASSWORD));
		
			serverInfo = getServerCfg(jdbcUrl, userName, password);
			if (serverInfo != null) {
				ready = true;
			}
		} catch (Exception e) {
			logger.error("加载Jdbc配置文件出错!", e);
		}
	}

	/**
	 * 获取属性
	 * @param key
	 * @return
	 */
	public static Object getProperty(String key){
		if(properties != null){
			return (Object) properties.get(key);
		}
		return null;
	}
	
	public static ServerInfo getServerCfg(String jdbcUrl, String userName, String password) {
		ServerInfo result = null;
		String a[] = jdbcUrl.split("//");
		if (StringUtils.isNotBlank(a[1])) {
			String b[] = a[1].split("/");
			if (StringUtils.isNotBlank(b[0])) {
				result = new ServerInfo();
				String c[] = b[0].split(":");
				String host = c[0];
				String port;
				if (c.length == 2) {
					port = c[1];
				} else {
					port = "3306";
				}
				String d[] = b[1].split("\\?");
				String database = d[0];
				
				result.setHost(host);
				result.setPort(port);
				result.setUserName(userName);
				result.setPassword(password);
				result.setDatabase(database);
			}
		}
		return result;
	}
	
}
