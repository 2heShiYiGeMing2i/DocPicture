/**
 * @file:BattleServiceImpl.java
 * @author:David
 **/
package com.xx.dev.modules.battle.service.impl;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.xx.common.basedb.BasedbService;
import com.xx.dev.constant.BattleType;
import com.xx.dev.constant.CharacterType;
import com.xx.dev.modules.battle.core.Battle;
import com.xx.dev.modules.battle.core.BattleWinner;
import com.xx.dev.modules.battle.model.BattleAttr;
import com.xx.dev.modules.battle.model.BattleAttrChanges;
import com.xx.dev.modules.battle.model.BattleBigRound;
import com.xx.dev.modules.battle.model.BattleCharacter;
import com.xx.dev.modules.battle.model.BattleGroup;
import com.xx.dev.modules.battle.model.BattleResult;
import com.xx.dev.modules.battle.model.BattleRound;
import com.xx.dev.modules.battle.model.BattleSkillEffectInfo;
import com.xx.dev.modules.battle.model.BattleTeam;
import com.xx.dev.modules.battle.model.Buff;
import com.xx.dev.modules.battle.model.MultiBattleResult;
import com.xx.dev.modules.battle.model.basedb.BattleWave;
import com.xx.dev.modules.battle.service.BattleService;
import com.xx.dev.modules.skill.model.SkillEffectTiming;
import com.xx.dev.modules.skill.model.SkillType;
import com.xx.dev.modules.skill.skilleffects.Effect;

/**
 * @class:BattleServiceImpl
 * @description:
 * @author:David
 * @version:v1.0
 * @date:2013-5-9
 **/
@Component
public class BattleServiceImpl implements BattleService {

	@Autowired
	protected BasedbService basedbService;
	
	@SuppressWarnings("unused")
	@Override
	public BattleCharacter getRobotPlayerBattleCharacter(long playerId, int teamPosition) {
		Long id = playerId;//玩家ID
		BattleTeam battleTeam = BattleTeam.OFFENSE_TEAM;
		CharacterType characterType = CharacterType.PLAYER;//角色类型
		int armType = 1;//兵种
		int armStar = 1;//兵阶
		int armyCount = 100;//带兵数
		int heroVocation = 1;//职业
		int level = 20;//等级
		double maxHp = 100000;//血量上限
		BattleAttr battleAttr = new BattleAttr(1000, //物理攻击 
				1000, //物理防御
				1000, //策略攻击
				100, //策略防御
				1, //暴击
				1, //格挡
				10, //技能威力
				maxHp,//进入战斗时血量
				0.0);//技能防御
		
		Map<Integer, Integer> skillLevelMap = new HashMap<Integer, Integer>();
		//玩家当前技能 技能Id-技能等级
		skillLevelMap.put(20000001, 10);
		skillLevelMap.put(21000005, 10);
		Map<Integer, Integer> lowSkillLevelMap = new HashMap<Integer, Integer>();
		//玩家低级技能 新技能Id-低级技能等级
		lowSkillLevelMap.put(21000005, 10);
		BattleCharacter attack = null/*new BattleCharacter(id, -1, characterType, armType, armStar, armyCount, heroVocation, level, battleAttr, maxHp, skillLevelMap, lowSkillLevelMap, battleTeam, teamPosition)*/;
		return attack;
	}

	@Override
	public boolean isMultiWaveBattle(int battleRuleId) {
		BattleWave battleRule = this.basedbService.get(BattleWave.class, battleRuleId);
		if(battleRule == null){
			return false;
		}
		if(battleRule.getWaveBattle() == 1){
			return true;
		}
		return false;
	}
	/**
	 * @description:刷新第二阵形的主将技能	
	 *
	 */
	private void reflushSecondSkill(List<BattleGroup> battleGroups){
		Map<Integer, BattleCharacter> characters = battleGroups.get(0).getCharacters();
		Collection<BattleCharacter> collection = characters.values();
		//提取已有主将技能
		Map<SkillEffectTiming, Map<BattleSkillEffectInfo, Effect>> generalEffectMaps = new HashMap<SkillEffectTiming, Map<BattleSkillEffectInfo,Effect>>();
		for (BattleCharacter battleCharacter : collection) {
			if(!battleCharacter.isCheer() && battleCharacter.isGeneral()){
				ConcurrentMap<SkillEffectTiming, ConcurrentMap<BattleSkillEffectInfo, Effect>> assistEffectMap = battleCharacter.loadAssistEffectMap();
				Set<Entry<SkillEffectTiming, ConcurrentMap<BattleSkillEffectInfo, Effect>>> assistEffectEntries = assistEffectMap.entrySet();
				for (Entry<SkillEffectTiming, ConcurrentMap<BattleSkillEffectInfo, Effect>> entry : assistEffectEntries) {
					Map<BattleSkillEffectInfo, Effect> skillMap = entry.getValue();
					Set<Entry<BattleSkillEffectInfo, Effect>> skillEffectMaps = skillMap.entrySet();
					for (Entry<BattleSkillEffectInfo, Effect> skillEffects : skillEffectMaps) {
						BattleSkillEffectInfo battleSkillEffectInfo = skillEffects.getKey(); 
						if(battleSkillEffectInfo.getSkill().getSkillType() == SkillType.CAPTAIN.ordinal()){
							Map<BattleSkillEffectInfo, Effect> generalEffectMap = generalEffectMaps.get(entry.getKey());
							if (generalEffectMap == null) {
								generalEffectMap = new HashMap<BattleSkillEffectInfo, Effect>();
								generalEffectMaps.put(entry.getKey(), generalEffectMap);
							}
							generalEffectMap.put(battleSkillEffectInfo.clone(), skillEffects.getValue());
						}
					}
				}
				break;
			}
		}
		//赋予新的主将技能，第二阵形一定没有主将
		if(!generalEffectMaps.isEmpty()){
			characters = battleGroups.get(1).getCharacters();
			collection = characters.values();
			for (BattleCharacter battleCharacter : collection) {
				if(!battleCharacter.isCheer()){
					ConcurrentMap<SkillEffectTiming, ConcurrentMap<BattleSkillEffectInfo, Effect>> assistEffectMap = battleCharacter.loadAssistEffectMap();
					Set<Entry<SkillEffectTiming, Map<BattleSkillEffectInfo, Effect>>> assistEffectEntries = generalEffectMaps.entrySet();
					for (Entry<SkillEffectTiming, Map<BattleSkillEffectInfo, Effect>> entry : assistEffectEntries) {
						Map<BattleSkillEffectInfo, Effect> skillMap = entry.getValue();
						Set<Entry<BattleSkillEffectInfo, Effect>> skillEffectMaps = skillMap.entrySet();
						for (Entry<BattleSkillEffectInfo, Effect> skillEffects : skillEffectMaps) {
							BattleSkillEffectInfo battleSkillEffectInfo = skillEffects.getKey(); 
							battleSkillEffectInfo.setTriggerId(battleCharacter.getId());
							battleSkillEffectInfo.setTriggerPos(battleCharacter.getTeamPosition());
							
							ConcurrentMap<BattleSkillEffectInfo, Effect> generalEffectMap = assistEffectMap.get(entry.getKey());
							if (generalEffectMap == null) {
								generalEffectMap = new ConcurrentHashMap<BattleSkillEffectInfo, Effect>();
								assistEffectMap.put(entry.getKey(), generalEffectMap);
							}
							generalEffectMap.put(battleSkillEffectInfo, skillEffects.getValue());
						}
					}
					break;
				}
			}
		}
	}
	@Override
	public MultiBattleResult multiWaveBattle(BattleType battleType,
			List<BattleGroup> attackGroups, List<BattleGroup> defendGroups,
			boolean isReport) {
		MultiBattleResult multiBattleResult = new MultiBattleResult(isReport);		
		if(attackGroups == null || defendGroups == null || attackGroups.isEmpty() || defendGroups.isEmpty()){
			return multiBattleResult;
		}
		if(attackGroups.size() == 2){
			Map<Integer, Integer> firstSkillCount = attackGroups.get(0).getGeneralSkillCount();
			Map<Integer, Integer> secondSkillCount = attackGroups.get(1).getGeneralSkillCount();
			Set<Entry<Integer, Integer>> entries = secondSkillCount.entrySet();
			for (Entry<Integer, Integer> entry : entries) {
				Integer count = firstSkillCount.get(entry.getKey());
				if(count == null){
					count = 0;
				}
				count += entry.getValue();
				firstSkillCount.put(entry.getKey(), count);
			}
			secondSkillCount.clear();
			secondSkillCount.putAll(firstSkillCount);
			
			reflushSecondSkill(attackGroups);
		}
		if(defendGroups.size() == 2){
			Map<Integer, Integer> firstSkillCount = defendGroups.get(0).getGeneralSkillCount();
			Map<Integer, Integer> secondSkillCount = defendGroups.get(1).getGeneralSkillCount();
			Set<Entry<Integer, Integer>> entries = secondSkillCount.entrySet();
			for (Entry<Integer, Integer> entry : entries) {
				Integer count = firstSkillCount.get(entry.getKey());
				if(count == null){
					count = 0;
				}
				count += entry.getValue();
				firstSkillCount.put(entry.getKey(), count);
			}
			secondSkillCount.clear();
			secondSkillCount.putAll(firstSkillCount);
			
			reflushSecondSkill(defendGroups);
		}
		for (int i = 0; i < attackGroups.size(); i++) {
			if(i == 1 ){
				attackGroups.get(i).setFirst(false);
				break;
			}
		}
		for (int i = 0; i < defendGroups.size(); i++) {
			if(i == 1 ){
				defendGroups.get(i).setFirst(false);
				break;
			}
		}
		
		int attackIndex = 0;int defendIndex = 0;
		int battleTimeLimit = attackGroups.size() + defendGroups.size();
		for (int i = 0; i < battleTimeLimit; i++) {
			if(attackIndex != 0 && (attackGroups.size() <= attackIndex || attackGroups.get(attackIndex) == null)){
				break;
			}
			if(defendIndex != 0 && (defendGroups.size() <= defendIndex || defendGroups.get(defendIndex) == null)){
				break;
			}
			if(attackGroups.size() < (attackIndex+1)){
				break;
			}
			if(defendGroups.size() < (defendIndex+1)){
				break;
			}
			BattleGroup attackGroup = attackGroups.get(attackIndex);
			List<BattleCharacter> battleCharacters = attackGroup.getAliveCharacters();
			reflushAttr(battleCharacters);
			BattleGroup defendGroup = defendGroups.get(defendIndex);
			battleCharacters = defendGroup.getAliveCharacters();
			reflushAttr(battleCharacters);
			Battle battle = new Battle(battleType, attackGroup, defendGroup, isReport);
			BattleResult battleResult = battle.getBattleResult();
			if(battleResult.getWinner().equals(BattleWinner.OFFENSE_TEAM)){
				defendIndex ++;
			}else {
				attackIndex ++;
			}
			multiBattleResult.setWinner(battleResult.getWinner());
			multiBattleResult.addBattleResult(battleResult);			
		}
		return multiBattleResult;
	}
	
	@Override
	public void reflushBattleAttr(List<BattleCharacter> battleCharacters){
		for (BattleCharacter battleCharacter : battleCharacters) {
			battleCharacter.setBuff(new Buff());
			battleCharacter.setInitHp(battleCharacter.getBattleAttr().hp);
			battleCharacter.reset();
			/*battleCharacter.loadAssistEffectMap().clear();*/
		}
	}
	/**
	 * @description:内部调用方法，不清楚技能	
	 * @param battleCharacters
	 */
	private void reflushAttr(List<BattleCharacter> battleCharacters){
		for (BattleCharacter battleCharacter : battleCharacters) {
			battleCharacter.setBuff(new Buff());
			battleCharacter.setInitHp(battleCharacter.getBattleAttr().hp);
			battleCharacter.reset();
		}
	}
	@Override
	public MultiBattleResult multiWaveBattle(BattleType battleType,
			List<BattleGroup> attackGroups, List<BattleGroup> defendGroups,
			boolean isReport, boolean isRound) {
		MultiBattleResult multiBattleResult = new MultiBattleResult(isReport, isRound);		
		if(attackGroups == null || defendGroups == null || attackGroups.isEmpty() || defendGroups.isEmpty()){
			return multiBattleResult;
		}
		if(attackGroups.size() == 2){
			Map<Integer, Integer> firstSkillCount = attackGroups.get(0).getGeneralSkillCount();
			Map<Integer, Integer> secondSkillCount = attackGroups.get(1).getGeneralSkillCount();
			Set<Entry<Integer, Integer>> entries = secondSkillCount.entrySet();
			for (Entry<Integer, Integer> entry : entries) {
				Integer count = firstSkillCount.get(entry.getKey());
				if(count == null){
					count = 0;
				}
				count += entry.getValue();
				firstSkillCount.put(entry.getKey(), count);
			}
			secondSkillCount.clear();
			secondSkillCount.putAll(firstSkillCount);
			
			reflushSecondSkill(attackGroups);
		}
		if(defendGroups.size() == 2){
			Map<Integer, Integer> firstSkillCount = defendGroups.get(0).getGeneralSkillCount();
			Map<Integer, Integer> secondSkillCount = defendGroups.get(1).getGeneralSkillCount();
			Set<Entry<Integer, Integer>> entries = secondSkillCount.entrySet();
			for (Entry<Integer, Integer> entry : entries) {
				Integer count = firstSkillCount.get(entry.getKey());
				if(count == null){
					count = 0;
				}
				count += entry.getValue();
				firstSkillCount.put(entry.getKey(), count);
			}
			secondSkillCount.clear();
			secondSkillCount.putAll(firstSkillCount);
			
			reflushSecondSkill(defendGroups);
		}
		for (int i = 0; i < attackGroups.size(); i++) {
			if(i == 1 ){
				attackGroups.get(i).setFirst(false);
				break;
			}
		}
		for (int i = 0; i < defendGroups.size(); i++) {
			if(i == 1 ){
				defendGroups.get(i).setFirst(false);
				break;
			}
		}
		
		int attackIndex = 0;int defendIndex = 0;
		int battleTimeLimit = attackGroups.size() + defendGroups.size();
		for (int i = 0; i < battleTimeLimit; i++) {
			if(attackIndex != 0 && (attackGroups.size() <= attackIndex || attackGroups.get(attackIndex) == null)){
				break;
			}
			if(defendIndex != 0 && (defendGroups.size() <= defendIndex || defendGroups.get(defendIndex) == null)){
				break;
			}
			if(attackGroups.size() < (attackIndex+1)){
				break;
			}
			if(defendGroups.size() < (defendIndex+1)){
				break;
			}
			BattleGroup attackGroup = attackGroups.get(attackIndex);
			List<BattleCharacter> battleCharacters = attackGroup.getAliveCharacters();
			reflushAttr(battleCharacters);
			BattleGroup defendGroup = defendGroups.get(defendIndex);
			battleCharacters = defendGroup.getAliveCharacters();
			reflushAttr(battleCharacters);
			Battle battle = new Battle(battleType, attackGroup, defendGroup, isReport);
			if(isRound){
				battle.createBattleRound();
			}
			BattleResult battleResult = battle.getBattleResult();
			if(battleResult.getWinner().equals(BattleWinner.OFFENSE_TEAM)){
				defendIndex ++;
			}else {
				attackIndex ++;
			}
			multiBattleResult.setWinner(battleResult.getWinner());
			multiBattleResult.addBattleResult(battleResult);			
		}
		//生成大回合战报
		if (isRound) {
			List<BattleResult> battleResults = multiBattleResult
					.getBattleResults();
			if (!battleResults.isEmpty()) {
				BattleResult battleResult = battleResults.get(0);
				List<BattleRound> battleRounds = battleResult.getBattleRounds();
				for (BattleRound battleRound : battleRounds) {
					BattleBigRound bigRound = new BattleBigRound(
							battleRound.getCurrRound());
					List<BattleAttrChanges> attackChanges = battleRound
							.getAttackChanges();
					long playerId = -1;
					double hpChanges = 0;
					double currHp = 0;
					for (BattleAttrChanges battleAttrChanges : attackChanges) {
						if (playerId == -1
								&& battleAttrChanges.getPlayerId() != -1) {
							playerId = battleAttrChanges.getPlayerId();
						}
						hpChanges += battleAttrChanges.getHpChanges();
						currHp += battleAttrChanges.getCurrHp();
					}
					BattleAttrChanges attackerChanges = new BattleAttrChanges(
							playerId, hpChanges, currHp);
					bigRound.setAttackerChanges(attackerChanges);
					playerId = -1;
					hpChanges = 0;
					currHp = 0;
					List<BattleAttrChanges> defendChanges = battleRound
							.getDefendChanges();
					for (BattleAttrChanges battleAttrChanges : defendChanges) {
						if (playerId == -1
								&& battleAttrChanges.getPlayerId() != -1) {
							playerId = battleAttrChanges.getPlayerId();
						}
						hpChanges += battleAttrChanges.getHpChanges();
						currHp += battleAttrChanges.getCurrHp();
					}
					BattleAttrChanges defenderChanges = new BattleAttrChanges(
							playerId, hpChanges, currHp);
					bigRound.setDefenderChanges(defenderChanges);
					multiBattleResult.addBigRounds(bigRound);
				}
				int currRound = battleRounds.get(battleRounds.size() - 1)
						.getCurrRound();
				if (battleResults.size() > 1) {
					BattleResult secondBattleResult = battleResults.get(1);
					battleRounds = secondBattleResult.getBattleRounds();
					for (BattleRound battleRound : battleRounds) {
						currRound += 1;
						BattleBigRound bigRound = new BattleBigRound(currRound);
						List<BattleAttrChanges> attackChanges = battleRound
								.getAttackChanges();
						long playerId = -1;
						double hpChanges = 0;
						double currHp = 0;
						for (BattleAttrChanges battleAttrChanges : attackChanges) {
							if (playerId == -1
									&& battleAttrChanges.getPlayerId() != -1) {
								playerId = battleAttrChanges.getPlayerId();
							}
							hpChanges += battleAttrChanges.getHpChanges();
							currHp += battleAttrChanges.getCurrHp();
						}
						BattleAttrChanges attackerChanges = new BattleAttrChanges(
								playerId, hpChanges, currHp);
						bigRound.setAttackerChanges(attackerChanges);
						playerId = -1;
						hpChanges = 0;
						currHp = 0;
						List<BattleAttrChanges> defendChanges = battleRound
								.getDefendChanges();
						for (BattleAttrChanges battleAttrChanges : defendChanges) {
							if (playerId == -1
									&& battleAttrChanges.getPlayerId() != -1) {
								playerId = battleAttrChanges.getPlayerId();
							}
							hpChanges += battleAttrChanges.getHpChanges();
							currHp += battleAttrChanges.getCurrHp();
						}
						BattleAttrChanges defenderChanges = new BattleAttrChanges(
								playerId, hpChanges, currHp);
						bigRound.setDefenderChanges(defenderChanges);
						multiBattleResult.addBigRounds(bigRound);
					}
				}
			}
		}
		return multiBattleResult;
	}
}

