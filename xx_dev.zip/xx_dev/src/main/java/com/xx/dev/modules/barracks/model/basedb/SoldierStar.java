package com.xx.dev.modules.barracks.model.basedb;

import com.xx.common.basedb.anno.Id;
import com.xx.common.basedb.anno.Resource;

/**
 * 兵阶表
 * 
 * @author Along
 *
 */
@Resource
public class SoldierStar {

	/**
	 * id(兵阶)
	 */
	@Id
	private int id;
	
	/**
	 * 需要的兵营等级
	 */
	private int barracksLevel;
	
	/**
	 * 招兵消耗
	 */
	private String costGoods;
	
	/**
	 * 遣散返还的招兵消耗
	 */
	private String returnCostGoods;
	
	/**
	 * 升兵阶的消耗
	 */
	private String upgradeCostGoods;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getBarracksLevel() {
		return barracksLevel;
	}

	public void setBarracksLevel(int barracksLevel) {
		this.barracksLevel = barracksLevel;
	}

	public String getCostGoods() {
		return costGoods;
	}

	public void setCostGoods(String costGoods) {
		this.costGoods = costGoods;
	}

	public String getReturnCostGoods() {
		return returnCostGoods;
	}

	public void setReturnCostGoods(String returnCostGoods) {
		this.returnCostGoods = returnCostGoods;
	}

	public String getUpgradeCostGoods() {
		return upgradeCostGoods;
	}

	public void setUpgradeCostGoods(String upgradeCostGoods) {
		this.upgradeCostGoods = upgradeCostGoods;
	}

}
