package com.xx.dev.constant;

/**
 * 邮件类型
 * 
 * @author Along
 *
 */
public interface MailType {
	
	/**
	 * 系统消息（公告，通知等）
	 */
	public final int SYSTEM_MESSAGE = 1;
	
	/**
	 * 活动奖励
	 */
	public final int ACTIVITY_REWARD = 2;
	
	/**
	 * 维护补偿
	 */
	public final int COMPENSATE = 3;
	
	/**
	 * 道具返还
	 */
	public final int RETURN = 4;
	
	/**
	 * 玩家私人
	 */
	public final int PLAYER = 5;
	
	/**
	 * 军团
	 */
	public final int ARMY_GROUP = 6;
	
}
