package com.xx.dev.modules.activity.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import com.xx.dev.modules.activity.entity.PlayerActivityTask;
import com.xx.dev.modules.task.constant.TaskStatus;
import com.xx.dev.modules.task.model.BaseTaskDto;


/**
 * 玩家活动任务信息dto
 * 
 * @author bingshan
 */
public class PlayerActivityTaskDto extends BaseTaskDto {
	
	/**
	 * 已领取奖励次数
	 */
	private int rewardedCount = 0;
	
	public PlayerActivityTaskDto() {
		super();
	}
	
	public PlayerActivityTaskDto(int taskId, TaskStatus taskStatus, String taskContent, int rewardedCount) {
		super(taskId, taskStatus, taskContent);
		this.rewardedCount = rewardedCount;
	}

	public static PlayerActivityTaskDto valueOf(PlayerActivityTask playerActivityTask) {
		return new PlayerActivityTaskDto(playerActivityTask.getTaskId(), playerActivityTask.getTaskStatus(), 
											playerActivityTask.getTaskContent(), playerActivityTask.getRewardedCount());
	}
	
	public static List<PlayerActivityTaskDto> valueOf(Collection<PlayerActivityTask> playerActivityTasks) {
		if (playerActivityTasks == null || playerActivityTasks.isEmpty()) {
			return new ArrayList<PlayerActivityTaskDto>(0);
		}
		
		List<PlayerActivityTaskDto> result = new ArrayList<PlayerActivityTaskDto>(playerActivityTasks.size());
		for (PlayerActivityTask p: playerActivityTasks) {
			PlayerActivityTaskDto d = valueOf(p);
			result.add(d);
		}
		return result;
	}

	public int getRewardedCount() {
		return rewardedCount;
	}

	public void setRewardedCount(int rewardedCount) {
		this.rewardedCount = rewardedCount;
	}
}
