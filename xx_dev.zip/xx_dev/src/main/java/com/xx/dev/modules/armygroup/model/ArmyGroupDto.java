package com.xx.dev.modules.armygroup.model;

import com.xx.dev.modules.armygroup.entity.ArmyGroup;
import com.xx.dev.modules.player.entity.Player;

/**
 * 军团DTO对象
 * 
 * @author Along
 *
 */
public class ArmyGroupDto {

	/**
	 * 军团id
	 */
	private long id;
	
	/**
	 * 军团名称
	 */
	private String name;
	
	/**
	 * 军团等级
	 */
	private int level;
	
	/**
	 * 团长id
	 */
	private long chief;
	
	/**
	 * 团长名
	 */
	private String chiefName;
	
	/**
	 * 军团成员人数
	 */
	private int memberNumber;
	
	/**
	 * 财富
	 */
	private long wealth = 0l;
	
	/**
	 * 排名
	 */
	private int ranking = -1;;
	
	/**
	 * 军团宣言
	 */
	private String declaration = "";
	
	/**
	 * 军团公告
	 */
	private String notice = "";
	
	/**
	 * 当天已经发送招贤榜的次数
	 */
	private int advertiseTimes;
	
	/**
	 * 战斗力
	 */
	private double ability;
	
	/**
	 * 是否需要改名（1-需要 0-不需要）
	 */
	private int mustRename;
	
	public static ArmyGroupDto valueOf(Player player, ArmyGroup armyGroup, 
			int level, int memberNumber) {
		ArmyGroupDto result = new ArmyGroupDto();
		result.setChief(player.getId());
		result.setChiefName(player.getPlayerName());
		result.setDeclaration(armyGroup.getDeclaration());
		result.setNotice(armyGroup.getNotice());
		result.setId(armyGroup.getId());
		result.setLevel(level);
		result.setMemberNumber(memberNumber);
		result.setName(armyGroup.getName());
		result.setRanking(armyGroup.getRanking());
		result.setWealth(armyGroup.getWealth());
		result.setAdvertiseTimes(armyGroup.getAdvertiseTimes());
		result.setMustRename(armyGroup.getMustRename());
		return result;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

	public long getChief() {
		return chief;
	}

	public void setChief(long chief) {
		this.chief = chief;
	}

	public String getChiefName() {
		return chiefName;
	}

	public void setChiefName(String chiefName) {
		this.chiefName = chiefName;
	}

	public int getMemberNumber() {
		return memberNumber;
	}

	public void setMemberNumber(int memberNumber) {
		this.memberNumber = memberNumber;
	}

	public long getWealth() {
		return wealth;
	}

	public void setWealth(long wealth) {
		this.wealth = wealth;
	}

	public int getRanking() {
		return ranking;
	}

	public void setRanking(int ranking) {
		this.ranking = ranking;
	}

	public String getDeclaration() {
		return declaration;
	}

	public void setDeclaration(String declaration) {
		this.declaration = declaration;
	}

	public String getNotice() {
		return notice;
	}

	public void setNotice(String notice) {
		this.notice = notice;
	}

	public int getAdvertiseTimes() {
		return advertiseTimes;
	}

	public void setAdvertiseTimes(int advertiseTimes) {
		this.advertiseTimes = advertiseTimes;
	}

	public double getAbility() {
		return ability;
	}

	public void setAbility(double ability) {
		this.ability = ability;
	}

	public int getMustRename() {
		return mustRename;
	}

	public void setMustRename(int mustRename) {
		this.mustRename = mustRename;
	}
	
}
