package com.xx.dev.modules.arena.model.basedb;

import com.xx.common.basedb.anno.Id;
import com.xx.common.basedb.anno.Index;
import com.xx.common.basedb.anno.Resource;
import com.xx.dev.constant.IndexName;


/**
 * 竞技场天排名奖励
 * 
 * @author bingshan
 */
@Resource
public class ArenaDayRank {
	
	/**
	 * 主键id
	 */
	@Id
	private int id;
	
	/**
	 * 第几天
	 */
	@Index(name = IndexName.ARENA_DAY_RANK_INDEX, order = 0)
	private int day;
	
	/**
	 * 排名
	 */
	@Index(name = IndexName.ARENA_DAY_RANK_INDEX, order = 1)
	private int rank;
	
	/**
	 * 奖励
	 */
	private String reward;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getDay() {
		return day;
	}

	public void setDay(int day) {
		this.day = day;
	}

	public int getRank() {
		return rank;
	}

	public void setRank(int rank) {
		this.rank = rank;
	}

	public String getReward() {
		return reward;
	}

	public void setReward(String reward) {
		this.reward = reward;
	}

}
