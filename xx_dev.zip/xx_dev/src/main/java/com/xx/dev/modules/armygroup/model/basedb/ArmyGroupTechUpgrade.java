package com.xx.dev.modules.armygroup.model.basedb;

import com.xx.common.basedb.anno.Id;
import com.xx.common.basedb.anno.Index;
import com.xx.common.basedb.anno.Resource;
import com.xx.dev.constant.IndexName;

/**
 * 军团科技升级表
 * 
 * @author Along
 *
 */
@Resource
public class ArmyGroupTechUpgrade {

	@Id
	private int id;
	
	/**
	 * 军团科技类型
	 */
	@Index(name = IndexName.ARMY_GROUP_TECH_UPGRADE_INDEX, order = 0)
	private int techType;
	
	/**
	 * 军团科技等级
	 */
	@Index(name = IndexName.ARMY_GROUP_TECH_UPGRADE_INDEX, order = 1)
	private int techLevel;
	
	/**
	 * 科技效果值
	 */
	private double value;
	
	/**
	 * 升级需要的贡献度
	 */
	private int contribute;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getTechType() {
		return techType;
	}

	public void setTechType(int techType) {
		this.techType = techType;
	}

	public int getTechLevel() {
		return techLevel;
	}

	public void setTechLevel(int techLevel) {
		this.techLevel = techLevel;
	}

	public double getValue() {
		return value;
	}

	public void setValue(double value) {
		this.value = value;
	}

	public int getContribute() {
		return contribute;
	}

	public void setContribute(int contribute) {
		this.contribute = contribute;
	}
	
}
