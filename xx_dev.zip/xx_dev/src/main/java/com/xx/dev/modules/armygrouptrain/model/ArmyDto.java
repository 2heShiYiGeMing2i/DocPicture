package com.xx.dev.modules.armygrouptrain.model;

/**
 * 試煉軍信息
 * @author jy
 *
 */
public class ArmyDto {

	/**
	 * 試煉軍id
	 */
	private int armyId;
	
	/**
	 * 是否死亡
	 */
	private int killed;
	
	/**
	 * 剩餘血量
	 */
	private double hp;
	
	/**
	 * 總血量
	 */
	private double totalHp;

	public int getArmyId() {
		return armyId;
	}

	public void setArmyId(int armyId) {
		this.armyId = armyId;
	}

	public int getKilled() {
		return killed;
	}

	public void setKilled(int killed) {
		this.killed = killed;
	}

	public double getHp() {
		return hp;
	}

	public void setHp(double hp) {
		this.hp = hp;
	}

	public double getTotalHp() {
		return totalHp;
	}

	public void setTotalHp(double totalHp) {
		this.totalHp = totalHp;
	}

	public static ArmyDto valueOf(int armyId, ArmyVO army) {
		ArmyDto dto = new ArmyDto();
		dto.armyId = armyId;
		dto.hp = army.getCurHp();
		dto.totalHp = army.getTotalHp();
		dto.killed = army.getKilled();
		return dto;
	}

}
