package com.xx.dev.modules.barracks.handler;

import com.xx.dev.modules.barracks.model.PlayerSoldierDto;
import com.xx.dev.modules.reward.result.ValueResultSet;

/**
 * 兵营模块
 * 
 * @author Along
 *
 */
public interface BarracksCmd {

	final String MODULE_NAME = "BARRACKS";
	
	/**
	 * 进入兵营
	 * @return Map {
	 * 				"result" : {@link BarracksResult}
	 * 				"content" : {@link PlayerSoldierDto} 玩家的兵
	 * 				}
	 */
	int ENTER_BARRACKS = 1;
	
	/**
	 * 升级兵阶
	 * @return Map {
	 * 				"result" : {@link BarracksResult}
	 * 				"content" : {@link ValueResultSet}
	 * 				"playerSoldierDto" : {@link PlayerSoldierDto} 玩家的兵
	 * 				}
	 */
	int UPGRADE_SOLDIER_STAR = 2;
	
	/**
	 * 招募士兵
	 * @param amount 士兵数量
	 * @return Map {
	 * 				"result" : {@link BarracksResult}
	 * 				"content" : {@link PlayerSoldierDto}
	 * 				"valueResultSet" : {@link ValueResultSet} 更新的属性集
	 * 				}
	 */
	int RECRUIT_SOLDIERS = 4;
	
	/**
	 * 遣散士兵
	 * @param amount 士兵数量
	 @return Map {
	 * 				"result" : {@link BarracksResult}
	 * 				"content" : {@link PlayerSoldierDto}
	 * 				"valueResultSet" : {@link ValueResultSet} 更新的属性集
	 * 				}
	 */
	int DISBAND_SOLDIERS = 5;
	
	//--------------------
	/**
	 * 推送开放新的兵阶
	 * @return {@link Integer}
	 */
	int HAD_NEW_SOLDIER_STAR = 1000;
	
}
