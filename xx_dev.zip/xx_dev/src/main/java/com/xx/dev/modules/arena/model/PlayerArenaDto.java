package com.xx.dev.modules.arena.model;

import com.xx.dev.modules.arena.entity.PlayerArena;

/**
 * 玩家竞技场信息dto
 * 
 * @author bingshan
 */
public class PlayerArenaDto {
	
	/**
	 * 当天已挑战次数
	 */
	private int challengeCount = 0;
	
	/**
	 * 最近一次挑战时间(ms)
	 */
	private long challengeTime = 0L;
	
	/**
	 * 自最后一次挑战以来累计cd时间(ms)
	 */
	private long cdTime = 0L;
	
	/**
	 * 下次可挑战时间(ms), 0-随时可挑战
	 */
	private long nextChallengeTime = 0L;
	
	/**
	 * 当天已购买次数
	 */
	private int buyCount = 0;
	
	/**
	 * 当前可用的已购买次数
	 */
	private int totalBuyCount = 0;
	
	/**
	 * 当前连胜
	 */
	private int wins;
	
	/**
	 * 上轮的结算排名
	 */
	private int lastRank;
	
	/**
	 * 是否还有奖励要领取
	 */
	private boolean hasReward = false;
	
	/**
	 * 历史最高排名
	 */
	private int topRank = 0;
	
	public static PlayerArenaDto valueOf(PlayerArena playerArena)  {
		PlayerArenaDto p = new PlayerArenaDto();
		p.challengeCount = playerArena.getChallengeCount();
		p.challengeTime = playerArena.getChallengeTime();
		p.cdTime = playerArena.getCdTime();
		p.nextChallengeTime = playerArena.getNextChallengeTime();
		p.buyCount = playerArena.getBuyCount();
		p.totalBuyCount = playerArena.getBuyCount() + playerArena.getPreLeftBuyCount();
		p.wins = playerArena.getWins();
		p.lastRank = playerArena.getBalanceRank();
		p.hasReward = playerArena.getBoxId() != 0 && playerArena.getBoxStatus() != 1;
		p.topRank = playerArena.getTopRank();
		return p;
	}

	public int getChallengeCount() {
		return challengeCount;
	}

	public void setChallengeCount(int challengeCount) {
		this.challengeCount = challengeCount;
	}

	public long getNextChallengeTime() {
		return nextChallengeTime;
	}

	public void setNextChallengeTime(long nextChallengeTime) {
		this.nextChallengeTime = nextChallengeTime;
	}

	public int getBuyCount() {
		return buyCount;
	}

	public void setBuyCount(int buyCount) {
		this.buyCount = buyCount;
	}

	public int getTotalBuyCount() {
		return totalBuyCount;
	}

	public void setTotalBuyCount(int totalBuyCount) {
		this.totalBuyCount = totalBuyCount;
	}

	public int getWins() {
		return wins;
	}

	public void setWins(int wins) {
		this.wins = wins;
	}

	public int getLastRank() {
		return lastRank;
	}

	public void setLastRank(int lastRank) {
		this.lastRank = lastRank;
	}

	public boolean isHasReward() {
		return hasReward;
	}

	public void setHasReward(boolean hasReward) {
		this.hasReward = hasReward;
	}

	public int getTopRank() {
		return topRank;
	}

	public void setTopRank(int topRank) {
		this.topRank = topRank;
	}

	public long getChallengeTime() {
		return challengeTime;
	}

	public void setChallengeTime(long challengeTime) {
		this.challengeTime = challengeTime;
	}

	public long getCdTime() {
		return cdTime;
	}

	public void setCdTime(long cdTime) {
		this.cdTime = cdTime;
	}
	
}
