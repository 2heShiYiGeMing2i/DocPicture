/**
 * @file:SysCfg.java
 * @author:David
 **/
package com.xx.dev.config;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.xx.common.db.cache.DbCachedService;
import com.xx.common.runtime.Lifecycle;
import com.xx.common.runtime.LifecycleMethod;
import com.xx.common.util.DatePattern;
import com.xx.common.util.DateUtil;
import com.xx.dev.constant.SysKey;
import com.xx.dev.modules.opencontrol.entity.KeyValue;

/**
 * @class:SysCfg
 * @description:系统配置
 * @author:David
 * @version:v1.0
 * @date:2013-6-21
 **/
@Component
public class SysCfg{
	
	@Autowired
	private DbCachedService dbCachedService;
	/**
	 * 注册人数
	 */
	private static volatile int registeredPlayer = 0;
	
	/**
	 * 保存键值没有就新建
	 * @param key
	 * @param value
	 */
	public synchronized void saveSysCfg(SysKey key, Object value){
		String stringValue = value != null ? String.valueOf(value) : "";
		
		if(key.isPersistence()){
			KeyValue keyValue = this.dbCachedService.get(key.getName(), KeyValue.class);
			if(keyValue == null){
				keyValue = new KeyValue();
				keyValue.setId(key.getName());
				keyValue.setValue(stringValue);
				keyValue = this.dbCachedService.submitNew2Queue(keyValue);
			} else {
				keyValue.setValue(stringValue);
				this.dbCachedService.submitUpdated2Queue(key.getName(), KeyValue.class);
			}
		}
	
		this.refreshSysCfg(key, stringValue);
	}
	
	public void refreshSysCfg(SysKey key, String value){
		if(value != null){
			value = value.replace("\r\n", "");
		} 

		if(key == SysKey.SERVER_OPEN_TIME || key == SysKey.SERVER_COMBINE_TIME){//服务器开张时间|服务器合服时间
			if(StringUtils.isNotBlank(value)){
				key.setValue(DateUtil.string2Date(value, DatePattern.PATTERN_NORMAL));
			}
		}else {
			key.setValue(value);
		}
	}
	
	public static void increaseRegisteredPlayer() {
		registeredPlayer++;
	}

	public static int getRegisteredPlayer() {
		return registeredPlayer;
	}

	public static void setRegisteredPlayer(int registeredPlayer) {
		SysCfg.registeredPlayer = registeredPlayer;
	}
	
	@LifecycleMethod(lifecycle=Lifecycle.CONFIGURATION, name="加载配置数据")
	private void init(){
		this.refresh();
	}
	
	private void refresh(){
		for(SysKey key : SysKey.values()){
			KeyValue keyValue = this.dbCachedService.get(key.getName(), KeyValue.class);
			if(keyValue != null){
				refreshSysCfg(key, keyValue.getValue());
			}
		}
	}
	
}

