package com.xx.dev.modules.armygrouptrain.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Map.Entry;

/**
 * 一個軍團的試煉信息
 * @author jy
 *
 */
public class TrainDto {

	/**
	 * 當前據點基礎數據id
	 */
	private int id;
	
	/**
	 * 關卡id
	 */
	private int areaId;
	
	/**
	 * 每個試煉軍當前的戰鬥信息，比如是否擊殺、剩餘血量等
	 */
	private List<ArmyDto> armyList;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public List<ArmyDto> getArmyList() {
		return armyList;
	}

	public void setArmyList(List<ArmyDto> armyList) {
		this.armyList = armyList;
	}

	public int getAreaId() {
		return areaId;
	}

	public void setAreaId(int areaId) {
		this.areaId = areaId;
	}

	public static TrainDto valueOf(TrainVO train) {
		TrainDto dto = new TrainDto();
		dto.areaId = train.getAreaId();
		dto.id = train.getId();
		dto.armyList = new ArrayList<ArmyDto>(train.getArmys().size());
		for(Entry<Integer, ArmyVO> entry : train.getArmys().entrySet()){
			ArmyDto armyDto = ArmyDto.valueOf(entry.getKey(), entry.getValue());
			dto.armyList.add(armyDto);
		}
		return dto;
	}

}
