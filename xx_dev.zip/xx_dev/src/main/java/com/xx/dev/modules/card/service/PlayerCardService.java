package com.xx.dev.modules.card.service;

import com.xx.dev.model.Result;
import com.xx.dev.modules.card.model.PlayerCardDto;

public interface PlayerCardService {

	/**
	 * 获取玩家月卡信息
	 * @param playerId
	 * @return
	 */
	Result<PlayerCardDto> getPlayerCardInfo(long playerId);

	/**
	 * 使用元宝开通月卡
	 * 
	 * @param playerId
	 * @param num 月卡数量
	 * @return
	 */
	Result<PlayerCardDto> openPlayerCardWithGold(long playerId, int num);

	/**
	 * 使用道具开通月卡
	 * 
	 * 在调用此方法的外部扣除道具
	 * 
	 * @param playerId 开通的玩家
	 * @param days 天数
	 */
	public Result<String> openPlayerCardWithGood(long playerId, int days);
	
	/**
	 * 领取体力
	 * @param playerId
	 * @return
	 */
	Result<PlayerCardDto> getEnergy(long playerId);

	/**
	 * 一键完成富甲天下
	 * @param playerId
	 * @return
	 */
	Result<PlayerCardDto> finishFJTX(long playerId);

	/**
	 * 领取buffer增益
	 * @param playerId
	 * @return
	 */
	Result<PlayerCardDto> getBuffer(long playerId);
	
	/**
	 * 月卡是否有效
	 * @param playerId
	 * @return
	 */
	public boolean isOpen(long playerId);

}
