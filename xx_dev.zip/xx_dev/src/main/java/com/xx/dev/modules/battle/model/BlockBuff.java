/**
 * @file:BlockBuff.java
 * @author:David
 **/
package com.xx.dev.modules.battle.model;
/**
 * @class:BlockBuff
 * @description:晕眩Buff
 * @author:David
 * @version:v1.0
 * @date:2013-4-27
 **/
public class BlockBuff extends AbstractBuff {
	public BlockBuff(int startRound, int persistRound) {
		super(0, 0, 0, 0, startRound, persistRound);
	}
	public BlockBuff(int effectBaseValueType,
			double effectBase, int effectValueType, double effect, int startRound,
			int persistRound) {
		super(effectBaseValueType, effectBase, effectValueType, effect, startRound, persistRound);
	}
	/**
	 * @description:重新赋值	
	 * @param startRound
	 * @param persistRound
	 */
	public void reflush(int startRound,			
			int persistRound) {
		this.startRound = startRound;
		this.persistRound = persistRound;
	}
}

