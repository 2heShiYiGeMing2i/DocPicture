/**
 * @file:BattleWinner.java
 * @author:David
 **/
package com.xx.dev.modules.battle.core;
/**
 * @class:BattleWinner
 * @description:战斗胜方
 * @author:David
 * @version:v1.0
 * @date:2013-4-19
 **/
public enum BattleWinner {
	/**
	 * 0-平局
	 */
	DRAW_GAME,
	/**
	 * 1-进攻方
	 */
	OFFENSE_TEAM,
	/**
	 * 2-防守方
	 */
	DEFENSE_TEAM;
}

