/**
 * @file:AvoidMagicBuff.java
 * @author:David
 **/
package com.xx.dev.modules.battle.model;
/**
 * @class:AvoidMagicBuff
 * @description:免疫魔法伤害
 * @author:David
 * @version:v1.0
 * @date:2014-4-20
 **/
public class AvoidMagicBuff extends AbstractBuff {
	public AvoidMagicBuff(int effectBaseValueType, double effectBase,
			int effectValueType, double effect, int startRound, int persistRound) {
		super(effectBaseValueType, effectBase, effectValueType, effect, startRound,
				persistRound);
	}
}

