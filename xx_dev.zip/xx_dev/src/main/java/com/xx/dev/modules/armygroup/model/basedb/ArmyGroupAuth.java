package com.xx.dev.modules.armygroup.model.basedb;

import com.xx.common.basedb.anno.Id;
import com.xx.common.basedb.anno.Resource;

/**
 * 军团权限基础数据表
 * 
 * @author Along
 *
 */
@Resource
public class ArmyGroupAuth {

	/**
	 * id
	 */
	@Id
	private int id;
	
	/**
	 * 申请团长
	 */
	private int applyChief;
	
	/**
	 * 升职
	 */
	private int promote;
	
	/**
	 * 降职
	 */
	private int demotion;
	
	/**
	 * 审批成员
	 */
	private int dispose;
	
	/**
	 * 邀请
	 */
	private int invite;
	
	/**
	 * 快速邀请
	 */
	private int quickInvite;
	
	/**
	 * 修改宣言
	 */
	private int updateDeclaration;
	
	/**
	 * 修改公告
	 */
	private int updateNotice;
	
	/**
	 * 发送军团邮件
	 */
	private int sendEmail;
	
	/**
	 * 踢出成员
	 */
	private int kickOut;
	
	/**
	 * 转让团长
	 */
	private int transfer;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getApplyChief() {
		return applyChief;
	}

	public void setApplyChief(int applyChief) {
		this.applyChief = applyChief;
	}

	public int getPromote() {
		return promote;
	}

	public void setPromote(int promote) {
		this.promote = promote;
	}

	public int getDemotion() {
		return demotion;
	}

	public void setDemotion(int demotion) {
		this.demotion = demotion;
	}

	public int getDispose() {
		return dispose;
	}

	public void setDispose(int dispose) {
		this.dispose = dispose;
	}

	public int getInvite() {
		return invite;
	}

	public void setInvite(int invite) {
		this.invite = invite;
	}

	public int getQuickInvite() {
		return quickInvite;
	}

	public void setQuickInvite(int quickInvite) {
		this.quickInvite = quickInvite;
	}

	public int getUpdateDeclaration() {
		return updateDeclaration;
	}

	public void setUpdateDeclaration(int updateDeclaration) {
		this.updateDeclaration = updateDeclaration;
	}

	public int getUpdateNotice() {
		return updateNotice;
	}

	public void setUpdateNotice(int updateNotice) {
		this.updateNotice = updateNotice;
	}

	public int getSendEmail() {
		return sendEmail;
	}

	public void setSendEmail(int sendEmail) {
		this.sendEmail = sendEmail;
	}

	public int getKickOut() {
		return kickOut;
	}

	public void setKickOut(int kickOut) {
		this.kickOut = kickOut;
	}

	public int getTransfer() {
		return transfer;
	}

	public void setTransfer(int transfer) {
		this.transfer = transfer;
	}
	
}
