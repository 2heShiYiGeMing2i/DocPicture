/**
 * @file:ReviveBuff.java
 * @author:David
 **/
package com.xx.dev.modules.battle.model;
/**
 * @class:ReviveBuff
 * @description:复活Buff
 * @author:David
 * @version:v1.0
 * @date:2013-4-28
 **/
public class ReviveBuff extends AbstractBuff {

	public ReviveBuff(int effectBaseValueType, double effectBase,
			int effectValueType, double effect, int startRound, int persistRound) {
		super(effectBaseValueType, effectBase, effectValueType, effect, startRound,
				persistRound);
	}

}

