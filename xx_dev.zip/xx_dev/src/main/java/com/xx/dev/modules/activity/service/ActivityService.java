package com.xx.dev.modules.activity.service;

import java.util.List;
import java.util.Map;

import com.xx.dev.modules.activity.entity.PlayerActivity;
import com.xx.dev.modules.activity.entity.PlayerActivityTask;
import com.xx.dev.modules.activity.model.PlayerActivityTaskDto;
import com.xx.dev.modules.activity.model.basedb.ActivityTask;
import com.xx.dev.modules.opencontrol.event.OpenControlEvent;
import com.xx.dev.modules.task.service.TaskService;


/**
 * 活动系统服务接口
 * 
 * @author bingshan
 */
public interface ActivityService extends TaskService<PlayerActivityTask, ActivityTask, PlayerActivityTaskDto> {
	
	/**
	 * 模块名
	 */
	final String MODULE_NAME = "Activity";
	
	/**
	 * 取得玩家活动信息
	 * @param playerId 玩家id
	 * @param activityId 活动id
	 * @return PlayerActivity
	 */
	PlayerActivity getPlayerActivity(long playerId, int activityId);
	
	/**
	 * 取得玩家某活动的任务列表
	 * @param playerId 玩家id
	 * @param activityId 活动id
	 * @return List<PlayerActivityTask>
	 */
	List<PlayerActivityTask> getPlayerActivityTasks(long playerId, int activityId);
	
	/**
	 * 取得玩家活动的任务列表
	 * @param playerId 玩家id
	 * @param activityIds 活动id列表
	 * @return
	 */
	Map<Integer, List<PlayerActivityTaskDto>> getPlayerActivityTasks(long playerId, 
			int[] activityIds);
	
	/**
	 * 跨天处理
	 * @param playerId 玩家id
	 */
	void doIfAcrossDay(long playerId);
	
	/**
	 * 跨天处理
	 */
	void doIfAcrossDay();
	
	/**
	 * 开关事件处理
	 * @param event OpenControlEvent
	 */
	void doOpenControlEvent(OpenControlEvent event);

}
