package com.xx.dev.modules.blackmarket.handler;

import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.xx.common.socket.handler.RequestProcessor;
import com.xx.common.socket.model.Request;
import com.xx.common.socket.model.Response;
import com.xx.dev.config.Module;
import com.xx.dev.model.Result;
import com.xx.dev.modules.blackmarket.model.PlayerBlackMarketDto;
import com.xx.dev.modules.blackmarket.service.BlackMarketService;
import com.xx.dev.modules.reward.result.ValueResultSet;
import com.xx.dev.modules.server.SessionManager;
import com.xx.dev.modules.server.handler.HandlerSupport;

/**
 * 黑市模块
 * 
 * @author Along
 *
 */
@Service
public class BlackMarketHandler extends HandlerSupport {

	private Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	private SessionManager sessionManager;
	
	@Autowired
	private BlackMarketService blackMarketService;
	
	@Override
	protected void init() {
		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				getBlackMarket(session, request, response);				
			}
			
			@Override
			public Type getType() {
				return null;
			}
			
			@Override
			public int getModule() {
				return Module.BLACK_MARKET;
			}
			
			@Override
			public int getCmd() {
				return BlackMarketCmd.GET_BLACK_MARKET;
			}
		});
		
		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				buyGoods(session, request, response);				
			}
			
			@Override
			public Type getType() {
				return HashMap.class;
			}
			
			@Override
			public int getModule() {
				return Module.BLACK_MARKET;
			}
			
			@Override
			public int getCmd() {
				return BlackMarketCmd.BUY_GOODS;
			}
		});

		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				refreshGoods(session, request, response);				
			}
			
			@Override
			public Type getType() {
				return HashMap.class;
			}
			
			@Override
			public int getModule() {
				return Module.BLACK_MARKET;
			}
			
			@Override
			public int getCmd() {
				return BlackMarketCmd.REFRESH_GOODS;
			}
		});
		
		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				intergalChange(session, request, response);				
			}
			
			@Override
			public Type getType() {
				return HashMap.class;
			}
			
			@Override
			public int getModule() {
				return Module.BLACK_MARKET;
			}
			
			@Override
			public int getCmd() {
				return BlackMarketCmd.INTERGAL_CHANGE;
			}
		});
		
		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				changeGoods(session, request, response);				
			}
			
			@Override
			public Type getType() {
				return HashMap.class;
			}
			
			@Override
			public int getModule() {
				return Module.BLACK_MARKET;
			}
			
			@Override
			public int getCmd() {
				return BlackMarketCmd.CHANGE_GOODS;
			}
		});
		
		this.registerProcessor(new RequestProcessor() {
			@Override
			public void process(IoSession session, Request request, Response response) {
				getGoodsIds(session, request, response);				
			}
			
			@Override
			public Type getType() {
				return HashMap.class;
			}
			
			@Override
			public int getModule() {
				return Module.BLACK_MARKET;
			}
			
			@Override
			public int getCmd() {
				return BlackMarketCmd.GET_GOODS_IDS;
			}
		});
	}

	@SuppressWarnings("unchecked")
	protected void getGoodsIds(IoSession session, Request request,
			Response response) {
		Long playerId = sessionManager.getPlayerId(session);
		Result<List<Integer>> result = null;
		try {
			HashMap<String, Object> params = (HashMap<String, Object>) request.getValue();
			if (params.get("goodsType") == null) {
				result = Result.Error(BlackMarketResult.PARAM_ERROR);
			}
			String sGoodsType = String.valueOf(params.get("goodsType"));
			if (StringUtils.isBlank(sGoodsType) || !StringUtils.isNumeric(sGoodsType)) {
				result = Result.Error(BlackMarketResult.PARAM_ERROR);
			} else {
				int goodsType = Integer.parseInt(sGoodsType);
				result = blackMarketService.getGoodsIdsAction(playerId, goodsType);
			}
		} catch (Exception e) {
			result = Result.Error(BlackMarketResult.FAILURE);
			logger.error("返回市场可购买物品id列表", e);
		}
		response.setValue(result);
		session.write(response);		
	}

	@SuppressWarnings("unchecked")
	protected void changeGoods(IoSession session, Request request,
			Response response) {
		Long playerId = sessionManager.getPlayerId(session);
		Result<ValueResultSet> result = null;
		try {
			HashMap<String, Object> params = (HashMap<String, Object>) request.getValue();
			if (params.get("goodsId") == null) {
				result = Result.Error(BlackMarketResult.PARAM_ERROR);
			}
			if (params.get("amount") == null) {
				result = Result.Error(BlackMarketResult.PARAM_ERROR);
			}
			String sGoodsId = String.valueOf(params.get("goodsId"));
			String sAmount = String.valueOf(params.get("amount"));
			if (StringUtils.isBlank(sGoodsId) || !StringUtils.isNumeric(sGoodsId) || 
					StringUtils.isBlank(sAmount) || !StringUtils.isNumeric(sAmount)) {
				result = Result.Error(BlackMarketResult.PARAM_ERROR);
			} else {
				int goodsId = Integer.parseInt(sGoodsId);
				int amount = Integer.parseInt(sAmount);
				result = blackMarketService.changeGoodsAction(playerId, goodsId, amount);
			}
		} catch (Exception e) {
			result = Result.Error(BlackMarketResult.FAILURE);
			logger.error("购买市场物品", e);
		}
		response.setValue(result);
		session.write(response);		
	}

	@SuppressWarnings("unchecked")
	protected void intergalChange(IoSession session, Request request,
			Response response) {
		Long playerId = sessionManager.getPlayerId(session);
		Result<PlayerBlackMarketDto> result = null;
		try {
			HashMap<String, Object> params = (HashMap<String, Object>) request.getValue();
			if (params.get("id") == null) {
				result = Result.Error(BlackMarketResult.PARAM_ERROR);
			}
			String sId = String.valueOf(params.get("id"));
			if (StringUtils.isBlank(sId) || !StringUtils.isNumeric(sId)) {
				result = Result.Error(BlackMarketResult.PARAM_ERROR);
			} else {
				int id = Integer.parseInt(sId);
				int amount = 1;
				if (params.get("amount") != null) {
					String sAmount = String.valueOf(params.get("amount"));
					if (StringUtils.isNotBlank(sAmount) && StringUtils.isNumeric(sAmount)) {
						amount = Integer.parseInt(sAmount);
					}
				}
				result = blackMarketService.intergalChangeAction(playerId, id, amount);
			}
		} catch (Exception e) {
			result = Result.Error(BlackMarketResult.FAILURE);
			logger.error("积分兑换黑市物品", e);
		}
		response.setValue(result);
		session.write(response);		
	}

	protected void refreshGoods(IoSession session, Request request,
			Response response) {
		Long playerId = sessionManager.getPlayerId(session);
		Result<PlayerBlackMarketDto> result = null;
		try {
			result = blackMarketService.refreshBlackMarketAction(playerId);
		} catch (Exception e) {
			result = Result.Error(BlackMarketResult.FAILURE);
			logger.error("刷新玩家黑市物品", e);
		}
		response.setValue(result);
		session.write(response);		
	}

	@SuppressWarnings("unchecked")
	protected void buyGoods(IoSession session, Request request,
			Response response) {
		Long playerId = sessionManager.getPlayerId(session);
		Result<PlayerBlackMarketDto> result = null;
		try {
			HashMap<String, Object> params = (HashMap<String, Object>) request.getValue();
			if (params.get("index") == null) {
				result = Result.Error(BlackMarketResult.PARAM_ERROR);
			}
			String sIndex = String.valueOf(params.get("index"));
			if (StringUtils.isBlank(sIndex) || !StringUtils.isNumeric(sIndex)) {
				result = Result.Error(BlackMarketResult.PARAM_ERROR);
			} else {
				int index = Integer.parseInt(sIndex);
				result = blackMarketService.buyGoodsAction(playerId, index);
			}
		} catch (Exception e) {
			result = Result.Error(BlackMarketResult.FAILURE);
			logger.error("购买黑市物品", e);
		}
		response.setValue(result);
		session.write(response);
	}

	protected void getBlackMarket(IoSession session, Request request,
			Response response) {
		Long playerId = sessionManager.getPlayerId(session);
		Result<PlayerBlackMarketDto> result = null;
		try {
			result = blackMarketService.getBlackMarketAction(playerId);
		} catch (Exception e) {
			result = Result.Error(BlackMarketResult.FAILURE);
			logger.error("获取玩家黑市信息", e);
		}
		response.setValue(result);
		session.write(response);
	}

}
