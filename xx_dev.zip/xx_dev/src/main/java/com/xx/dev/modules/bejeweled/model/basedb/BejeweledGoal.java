package com.xx.dev.modules.bejeweled.model.basedb;

import com.xx.common.basedb.anno.Id;
import com.xx.common.basedb.anno.Resource;

/**
 * 宝箱迷阵目标
 * Created by LiangZengle on 2014/6/25.
 */
@Resource
public class BejeweledGoal {

    /**
     * 个数
     */
    @Id
    private int id;

    /**
     * 得分
     */
    private int score;

    /**
     * 几率
     */
    private int rate;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getRate() {
        return rate;
    }

    public void setRate(int rate) {
        this.rate = rate;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }
}
