package com.xx.dev.modules.bejeweled.handler;

import com.xx.common.socket.handler.RequestProcessor;
import com.xx.common.socket.handler.RequestProcessorAdapter;
import com.xx.common.socket.model.Request;
import com.xx.common.socket.model.Response;
import com.xx.dev.config.Module;
import com.xx.dev.constant.CommonConstant;
import com.xx.dev.model.Result;
import com.xx.dev.modules.bejeweled.service.BejeweledService;
import com.xx.dev.modules.server.SessionManager;
import com.xx.dev.modules.server.handler.HandlerSupport;

import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * Created by LiangZengle on 2014/6/21.
 */
@Service
public class BejeweledHandler extends HandlerSupport {
    private Logger logger = LoggerFactory.getLogger(getClass());

    @Autowired
    private SessionManager sessionManager;
    @Autowired
    private BejeweledService bejeweledService;

    @Override
    protected void init() {
        registerProcessor(getBejeweledInfo);
        registerProcessor(move);
        registerProcessor(addMove);
        registerProcessor(autoClean);
        registerProcessor(openBox);
    }

    private RequestProcessor openBox = new RequestProcessorAdapter(Module.BEJEWELED, BejeweledCmd.OPEN_BOX) {

        @Override
        public void process(IoSession session, Request request, Response response) {
            Result<?> result;
            try {
                long playerId = sessionManager.getPlayerId(session);
                result = bejeweledService.openBox(playerId);
            } catch (Exception e) {
                result = Result.Error(CommonConstant.FAILURE);
                logger.error(e.getMessage(), e);
            }
            response.setValue(result);
            session.write(response);
        }
    };

    private RequestProcessor autoClean = new RequestProcessorAdapter(Module.BEJEWELED, BejeweledCmd.AUTO_CLEAR_UP) {

        @Override
        public void process(IoSession session, Request request, Response response) {
            Result<?> result;
            try {
                long playerId = sessionManager.getPlayerId(session);
                result = bejeweledService.autoClearUp(playerId);
            } catch (Exception e) {
                result = Result.Error(CommonConstant.FAILURE);
                logger.error(e.getMessage(), e);
            }
            response.setValue(result);
            session.write(response);
        }
    };

    private RequestProcessor addMove = new RequestProcessorAdapter(Module.BEJEWELED, BejeweledCmd.ADD_MOVE) {

        @Override
        public void process(IoSession session, Request request, Response response) {
            Result<?> result;
            try {
                long playerId = sessionManager.getPlayerId(session);
                result = bejeweledService.addMove(playerId);
            } catch (Exception e) {
                result = Result.Error(CommonConstant.FAILURE);
                logger.error(e.getMessage(), e);
            }
            response.setValue(result);
            session.write(response);
        }
    };

    private RequestProcessor move = new RequestProcessorAdapter(Module.BEJEWELED, BejeweledCmd.SWAP, int[].class) {

        @SuppressWarnings("unchecked")
        @Override
        public void process(IoSession session, Request request, Response response) {
            Result<?> result;
            try {
                long playerId = sessionManager.getPlayerId(session);
                int[] coordinates = (int[]) request.getValue();
                result = bejeweledService.swap(playerId, coordinates);
            } catch (Exception e) {
                result = Result.Error(CommonConstant.FAILURE);
                logger.error(e.getMessage(), e);
            }
            response.setValue(result);
            session.write(response);
        }
    };

    private RequestProcessor getBejeweledInfo = new RequestProcessorAdapter(Module.BEJEWELED, BejeweledCmd.GET_BEJEWELED_INFO) {

        @Override
        public void process(IoSession session, Request request, Response response) {
            Result<?> result;
            try {
                long playerId = sessionManager.getPlayerId(session);
                result = bejeweledService.getBejeweledInfo(playerId);
            } catch (Exception e) {
                result = Result.Error(CommonConstant.FAILURE);
                logger.error(e.getMessage(), e);
            }
            response.setValue(result);
            session.write(response);
        }
    };

}
