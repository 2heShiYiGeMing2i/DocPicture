/**
 * @file:BattleAttrType.java
 * @author:David
 **/
package com.xx.dev.modules.battle.model;
/**
 * @class:BattleAttrType
 * @description:战斗属性类型
 * @author:David
 * @version:v1.0
 * @date:2013-4-22
 **/
public interface BattleAttrType {

	/** 0-无 */
	final int NONE = 0;
	
	/** 1-物理攻击 */
	final int  ATTACK = 1;
	
	/** 2-物理防御 */
	final int  DEFEND = 2;
	
	/** 3-策略攻击 */
	final int  STRATEGYATTACK = 3;
	
	/** 4-策略防御 */
	final int  STRATEGYDEFEND = 4;
	
	/** 5-暴击率 */
	final int  CRIT = 5;
	
	/** 6-格挡率 */
	final int  RESIST = 6;
	
	/** 7-技能威力 */
	final int  SKILLPOWER = 7;
	
	/** 8-生命 HP */
	final int  HP = 8;
	
	/** 9-怒气 */
	final int  DANDER = 9;
	
	/** 10-技能防御 */
	final int SKILLDEFEND = 10;
	
}

