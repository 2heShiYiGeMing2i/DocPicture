package com.xx.dev.modules.armygroup.model.basedb;

import com.xx.common.basedb.anno.Id;
import com.xx.common.basedb.anno.Resource;

/**
 * 军团捐赠事件
 * 
 * @author Along
 *
 */
@Resource
public class ArmyGroupContributeEvent {

	/**
	 * id
	 */
	@Id
	private int id;
	
	/**
	 * 贡献最小值
	 */
	private int minContribute;
	
	/**
	 * 贡献最大值
	 */
	private int maxContribute;
	
	/**
	 * 建筑完成度最小值
	 */
	private int minProgress;
	
	/**
	 * 建筑完成度最大值
	 */
	private int maxProgress;
	
	/**
	 * 粮食奖励最小值
	 */
	private int minFoods;
	
	/**
	 * 粮食奖励最大值
	 */
	private int maxFoods;
	
	/**
	 * 掉落串
	 */
	private String drops;
	
	/**
	 * 概率
	 */
	private int rate;
	
	/**
	 * 总概率
	 */
	private int totalRate;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getMinContribute() {
		return minContribute;
	}

	public void setMinContribute(int minContribute) {
		this.minContribute = minContribute;
	}

	public int getMaxContribute() {
		return maxContribute;
	}

	public void setMaxContribute(int maxContribute) {
		this.maxContribute = maxContribute;
	}

	public int getMinProgress() {
		return minProgress;
	}

	public void setMinProgress(int minProgress) {
		this.minProgress = minProgress;
	}

	public int getMaxProgress() {
		return maxProgress;
	}

	public void setMaxProgress(int maxProgress) {
		this.maxProgress = maxProgress;
	}

	public int getMinFoods() {
		return minFoods;
	}

	public void setMinFoods(int minFoods) {
		this.minFoods = minFoods;
	}

	public int getMaxFoods() {
		return maxFoods;
	}

	public void setMaxFoods(int maxFoods) {
		this.maxFoods = maxFoods;
	}

	public String getDrops() {
		return drops;
	}

	public void setDrops(String drops) {
		this.drops = drops;
	}

	public int getRate() {
		return rate;
	}

	public void setRate(int rate) {
		this.rate = rate;
	}

	public int getTotalRate() {
		return totalRate;
	}

	public void setTotalRate(int totalRate) {
		this.totalRate = totalRate;
	}
	
}
