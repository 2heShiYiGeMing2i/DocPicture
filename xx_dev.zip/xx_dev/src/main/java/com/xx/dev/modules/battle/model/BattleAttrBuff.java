/**
 * @file:BattleAttrBuff.java
 * @author:David
 **/
package com.xx.dev.modules.battle.model;

/**
 * @class:BattleAttrBuff
 * @description:持续性buff 战斗属性
 * @author:David
 * @version:v1.0
 * @date:2013-4-25
 **/
public class BattleAttrBuff extends AbstractBuff {
	/**
	 * 固定值效果值
	 */
	private int attrType;
	
	public BattleAttrBuff(int attrType, int effectBaseValueType,
			double effectBase, int effectValueType, double effect, int startRound,
			int persistRound) {
		super(effectBaseValueType, effectBase, effectValueType, effect, startRound, persistRound);
		this.attrType = attrType;
	}

	
	public int getAttrType() {
		return attrType;
	}


	public void setAttrType(int attrType) {
		this.attrType = attrType;
	}

	/**
	 * @description:重新赋值	
	 * @param attrType
	 * @param value
	 * @param persistRound
	 */
	public void reflush(int attrType, int effectBaseValueType,
			double effectBase, int effectValueType, double effect, int startRound,
			int persistRound) {
		this.attrType = attrType;
		super.reflush(effectBaseValueType, effectBase, effectValueType, effect, startRound, persistRound);
	}
}

