/**
 * @file:HarmType.java
 * @author:David
 **/
package com.xx.dev.modules.battle.model;
/**
 * @class:HarmType
 * @description:技能伤害类型
 * @author:David
 * @version:v1.0
 * @date:2013-4-25
 **/
public interface HarmType {
	/** 0-无 */
	final int NONE = 0;
	
	/** 1-物理伤害 */
	final int  PHYSICS = 1;
	
	/** 2-魔法伤害  */
	final int  MAGIC = 2;
}

