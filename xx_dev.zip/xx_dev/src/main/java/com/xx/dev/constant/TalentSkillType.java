package com.xx.dev.constant;

/**
 * 天赋技能类型
 * 
 * @author Along
 *
 */
public enum TalentSkillType {

	/**
	 * 0-无
	 */
	NONE,
	
	/**
	 * 1-手动获得
	 */
	HAND,
	
	/**
	 * 2-自动获得
	 */
	AUTO
	
}
