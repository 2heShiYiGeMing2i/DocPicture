/**
 * @file:BattleTargetRange.java
 * @author:David
 **/
package com.xx.dev.modules.battle.model;
/**
 * @class:BattleTargetRange
 * @description:战斗攻击目标范围
 * @author:David
 * @version:v1.0
 * @date:2013-4-19
 **/
public enum BattleTargetRange {
	/** 0-默认目标 */
	DEFAULT,
	
	/** 1-前排：攻击前排所有部队（前排无部队，技能不再触发，变为普通攻击）  */
	FRONT,
	
	/** 2-后排：攻击后排所有部队（后排无部队，技能不再触发，变为普通攻击）*/
	BACK,
	
	/** 3-全体：攻击敌方全体部队*/
	ALL,
	
	/** 4-十字：攻击一个“+”字的范围，攻击的为中心点。上下左右的格子部队都会受到伤害。 */
	CROSS,

	/** 5-随机2人：在敌方的所有部队中，随机攻击3个部队 */
	RANDOM2,
	
	/** 6-随机3人：在敌方的所有部队中，随机攻击3个部队 */
	RANDOM3,
	
	/** 7-一列（多体）：攻击一整列的敌方所有部队（对位的一整列，没有单位的时候，技能不再触发，变为普通攻击） */
	LINE,
	
	/** 8-我方全体：作用我方所有的部队 */
	SELF_ALL,
	
	/** 9-我方全体： 我方血量最低的N个单位（绝对血量） exp:SS|1 最低血量的1个人*/
	SELF_SOME,
	
	/** 10-我方单体：我方血量最低的一个单位（绝对血量） */
	SELF_ONE,
	
	/** 11-对敌方特定职业生效 exp:TV|1|2 敌方特定1、2的职业 */
	TARGET_VOCATION,
	
	/** 12-对我方特定职业生效  exp:SV|1|2 我方特定1、2的职业*/
	SELF_VOCATION,
	
	/** 13-对敌方特定兵种 exp:TA|1|2 敌方特定1、2的职业**/
	TARGET_ARMY,
	
	/** 14-对我方特定兵种 exp:SA|1|2 敌方特定1、2的职业 **/
	SELF_ARMY,
	
	/** 15-对敌方血量最低的N个单位 exp:TSA|2 敌方血量最低的2个单位 **/
	TARGET_SOME_ARMY,
	
	/** 16-对敌方血量最高的N个单位 exp:TTA|2 敌方血量最高的2个单位 **/
	TARGET_TOP_ARMY,
	
	/** 17-先打前排，前排没人打后排 **/
	FRONT_BACK,
	
	/** 18-一列（多体）：攻击一整列的敌方所有部队，优先本列，否则从上至下直到找到为止 */
	TARGET_LINE,
	
	/** 19-优先攻击后排 单体 exp:BS**/
	BACK_SINGLE,
	
	/** 20-己方随机N个单位 单体 exp:SR|2 己方随机2个单位**/
	SELF_RANDOM;
}

