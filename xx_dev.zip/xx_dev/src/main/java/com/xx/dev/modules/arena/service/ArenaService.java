package com.xx.dev.modules.arena.service;

import java.util.List;

import com.xx.dev.model.Result;
import com.xx.dev.modules.arena.entity.ArenaInfo;
import com.xx.dev.modules.arena.entity.PlayerArena;
import com.xx.dev.modules.arena.model.PlayerRankDto;
import com.xx.dev.modules.player.model.PlayerDto;

/**
 * 竞技场系统接口
 * 
 * @author bingshan
 */
public interface ArenaService {
	
	/**
	 * 取得玩家竞技场信息
	 * @param playerId 玩家id
	 * @return PlayerArena
	 */
	PlayerArena getPlayerArena(long playerId);
	
	/**
	 * 取得玩家可挑战的玩家信息列表
	 * @param playerId 玩家id
	 * @return List<PlayerRankDto>
	 */
	List<PlayerRankDto> getChallengeList(long playerId);
	
	/**
	 * 发起挑战
	 * @param playerId 玩家id
	 * @param rank 挑战名次
	 * @return Result<String>
	 */
	Result<String> challenge(long playerId, int rank);
	
	/**
	 * 挑战NPC
	 * @param playerId 玩家id
	 * @param npcId NPC ID
	 * @return Result<String>
	 */
	Result<String> challengeNpc(long playerId, int npcId);
	
	/**
	 * 翻牌
	 * @param playerId 玩家id
	 * @param useGold 是否使用元宝领取
	 * @return Result<String>
	 */
	Result<String> turnCard(long playerId, boolean useGold);
	
	/**
	 * 消除冷却CD
	 * @param playerId 玩家id
	 * @return Result<String>
	 */
	Result<String> eliminateCd(long playerId);
	
	/**
	 * 购买次数
	 * @param playerId 玩家id
	 * @param count 次数
	 * @return Result<String>
	 */
	Result<String> buyCount(long playerId, int count);
	
	/**
	 * 领取宝箱奖励
	 * @param playerId 玩家id
	 * @return Result<String>
	 */
	Result<String> fetchBoxReward(long playerId);
	
	/**
	 * 侦查玩家阵型
	 * @param playerId 玩家id
	 * @param spyPlayerId 被侦查玩家id
	 * @return Result<PlayerDto>
	 */
	Result<PlayerDto> spy(long playerId, long spyPlayerId);
	
	/**
	 * 取得排行榜
	 * @return List<PlayerRankDto>
	 */
	List<PlayerRankDto> getRankList();
	
	/**
	 * 竞技场第一名挑战胜利记录
	 * @return ArenaInfo
	 */
	ArenaInfo getArenaFirstRankInfo();
	
	/**
	 * 玩家登出处理
	 * @param playerId 玩家id
	 */
	void playerLogout(long playerId);
	
	/**
	 * 手动刷新竞技场排名
	 */
	void refreshArenaRanks();
	
	/**
	 * 取得日排行榜奖励
	 * @param playerId 玩家id
	 * @param day 第几天
	 * @param rank 第几名
	 * @return Result
	 */
	Result<String> getDayRankReward(long playerId, int day, int rank);
	
	/**
	 * 取得结算第一名玩家id
	 * @return long
	 */
	long getBalanceTopPlayerId();
}
