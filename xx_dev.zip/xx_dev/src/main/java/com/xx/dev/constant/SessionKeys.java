package com.xx.dev.constant;

import org.apache.mina.core.session.AttributeKey;

/**
 * SessionKeys
 * 
 * @author Along
 *
 */
public interface SessionKeys {
	
	/**
	 * 防沉迷状态  {@link FcmStatus}
	 */
	AttributeKey FCM_STATUS =  new AttributeKey(SessionKeys.class, "FCM_STATUS");
	
	/**
	 * 成年状态 {@see AdultStatus}
	 */
	AttributeKey ADULT_STATUS =  new AttributeKey(SessionKeys.class, "ADULT_STATUS");
	
	/**
	 * session的登录时间
	 */
	AttributeKey LOGIN_TIME =  new AttributeKey(SessionKeys.class, "LOGIN_TIME");
	
	/**
	 * 登录流水号
	 */
	AttributeKey LOGIN_SN = new AttributeKey(SessionKeys.class, "LOGIN_SN");
	
	/**
	 * 登录方式
	 */
	AttributeKey LOGIN_WAY = new AttributeKey(SessionKeys.class, "LOGIN_WAY");
	
	/**
	 * 腾讯平台的参数
	 */
	AttributeKey TENCENT_PARAMETER = new AttributeKey(SessionKeys.class, "TENCENT_PARAMETER");
	
	/**
	 * 类似通行证
	 */
	AttributeKey PASSPORT = new AttributeKey(SessionKeys.class, "PASSPORT");
	
	/**
	 * session关闭模式    {@See SessionCloseMode}
	 */
	AttributeKey CLOSE_MODE = new AttributeKey(SessionKeys.class, "CLOSE_MODE");

	/**
	 * session关闭是否已经处理过了
	 */
	AttributeKey CLOSE_FLAG = new AttributeKey(SessionKeys.class, "CLOSE_FLAG");

}

