package com.xx.dev.modules.card.service.impl;

import org.springframework.stereotype.Component;

import com.xx.common.basedb.BasedbAdapter;
import com.xx.dev.modules.card.model.basedb.PlayerCardConfig;
import com.xx.dev.modules.card.service.PlayerCardRuleService;
/**
 * 玩家月卡基础数据服务
 * @author jy
 *
 */
@Component
public class PlayerCardRuleServiceImpl extends BasedbAdapter implements PlayerCardRuleService{

	@Override
	public PlayerCardConfig getPlayerCardConfig() {
		return basedbService.get(PlayerCardConfig.class, PlayerCardConfig.PLAYER_CARD_ID);
	}

	@Override
	public Class<?>[] listenedClass() {
		return null;
	}

	@Override
	public void initialize() {
	}
}
