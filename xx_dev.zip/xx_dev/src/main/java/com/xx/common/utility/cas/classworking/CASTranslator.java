/**
 * 
 */
package com.xx.common.utility.cas.classworking;


import java.lang.reflect.Method;

import javassist.CannotCompileException;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.CtMethod;
import javassist.CtNewMethod;
import javassist.NotFoundException;
import javassist.Translator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.xx.common.utility.cas.CAS;
import com.xx.common.utility.cas.CASTransactionManager;
import com.xx.common.utility.cas.CASTransactional;
import com.xx.common.utility.cas.CASVersionConflictException;
import com.xx.common.utility.cas.NonCAS;

/**
 * 实体类字节码增强
 * @author fansth
 *
 */
public class CASTranslator implements Translator {
	
	private static final Logger logger = LoggerFactory.getLogger(CASTranslator.class);
	
	
	public void start(ClassPool pool) throws NotFoundException, CannotCompileException {
		// TODO Auto-generated method stub

	}
	
	public void onLoad(ClassPool pool, String classname)throws NotFoundException, CannotCompileException {
		try {
			CtClass clas = pool.get(classname);
			if(clas.hasAnnotation(CAS.class)){//有CAS注解
				
				CtMethod[] methods = clas.getDeclaredMethods();
				for(CtMethod method : methods){
					 if(!method.isEmpty() && method.getName().startsWith("set") && "setId".equals(method.getName()) && !method.hasAnnotation(NonCAS.class)){
//						 method.insertAfter("if(this.id != null) { " + StaticDbCache.class.getName() + ".update(this.id, this.getClass());}\n");
						 method.insertBefore("if(this.id != null) { assert " + CASTransactionManager.class.getName() + ".hasTransaction();}\n");//set方法一定要在事务环境中
					 }
				 }
			}
			
			if(clas.hasAnnotation(CASTransactional.class)){
				try {
					CtMethod[] methods = clas.getDeclaredMethods();
					for(CtMethod method : methods){
						if(!method.isEmpty()){
							Object annotation = method.getAnnotation(CASTransactional.class);
							if(annotation != null){
								
								Method retryMethod = annotation.getClass().getDeclaredMethod("retry");
								int retry = (Integer)retryMethod.invoke(annotation);
								if(retry > 0){
									
									String srcName = method.getName();//原来的方法名
									String newName = srcName+"$impl";
									method.setName(newName);//将方法重命名
									
									CtMethod newMethod = CtNewMethod.copy(method, srcName, clas, null);
									
									StringBuilder body = new StringBuilder();
									body.append("java.util.concurrent.atomic.AtomicInteger retry = new java.util.concurrent.atomic.AtomicInteger(0);\n");
									body.append("while(retry.get() < " + retry + "){\n");
									body.append("try { \n");
									body.append("return " + newName + "($$);\n");
									body.append("} catch(" + CASVersionConflictException.class.getName() + " e){\n");
									body.append("retry.incrementAndGet();\n");
									body.append("if(retry.get() >= " + retry + ") {\n");//
									body.append("throw e;}\n");//超过重试次数抛出异常
									body.append("}\n");
									body.append("}\n");
									
									newMethod.setBody("{ \n" + body.toString() + "}\n");
									clas.addMethod(newMethod);
									
								}
							}
						}
					 }
				} catch (Exception e) {
					logger.error("javassist 处理 CASTransactional 时出错!", e);
				}
			}
			
			 clas.writeFile();
			
		} catch (Exception e) {
			logger.error("javassist not found : " + classname);
		}
	}
	
	
	

}
