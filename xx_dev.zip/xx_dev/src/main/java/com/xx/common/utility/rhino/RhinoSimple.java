package com.xx.common.utility.rhino;

import java.util.Map;
import java.util.Map.Entry;

import org.mozilla.javascript.Context;
import org.mozilla.javascript.ContextFactory;
import org.mozilla.javascript.Script;
import org.mozilla.javascript.Scriptable;

import com.googlecode.concurrentlinkedhashmap.ConcurrentLinkedHashMap;

/**
 * Mozilla Rhino 公式解析器
 * 
 * @author Hyint
 */
public class RhinoSimple {
	
	/** Scope */
	private static transient Scriptable SCRIPTABLE = null;
	/** 公式缓存 */
	private static final ConcurrentLinkedHashMap<String, Script> SCRIPT_CACHE = new ConcurrentLinkedHashMap.Builder<String, Script>().maximumWeightedCapacity(10000).build();
	 
	/**
	 * 获得Singleton的Scope
	 * @return
	 */
	private static Scriptable getSingletonScopes() {
		if(SCRIPTABLE == null) {
			synchronized (RhinoSimple.class) {
				if(SCRIPTABLE == null) {
					ContextFactory global = ContextFactory.getGlobal();
					Context context = global.enterContext();
					context.setWrapFactory(new MapWarperFactory());
					SCRIPTABLE = context.initStandardObjects();
				}
			}
		}
		return SCRIPTABLE;
	}

	/**
	 * 计算公式获得计算结果
	 * 
	 * @param  expression		公式
	 * @param  ctx				上下文
	 * @return {@link Object}	返回值
	 */
	public static Object invoke(String expression, Map<String, ?> ctx) {
		Script exp = SCRIPT_CACHE.get(expression);
		Context context = Context.enter();
		try {
			if (exp == null) {
				exp = context.compileString(expression, "<expr>", -1, null);
				SCRIPT_CACHE.putIfAbsent(expression, exp);
			}

			exp = SCRIPT_CACHE.get(expression);
			Scriptable args = context.newObject(getSingletonScopes());
			if (ctx != null && !ctx.isEmpty()) {
				for (Entry<String, ?> e : ctx.entrySet()) {
					args.put(e.getKey(), args, e.getValue());
				}
			}
			return exp.exec(context, args);
		} finally {
			Context.exit();
		}
	}
}
