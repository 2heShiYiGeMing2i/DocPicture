package com.xx.common.basedb.anno;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 静态资源数据索引声明
 * @author frank
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.FIELD, ElementType.METHOD})
public @interface Index {
	
	/** 索引名，同一资源的索引名必须唯一 */
	String name();

	/** 索引值序号(越小越靠前)*/
	int order() default 0;
	
	/** 表达式  满足表达式才建索引  如果 : level == 5 */
	String expression() default "";
	
}
