package com.xx.common.util;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;



/**
 * 日志记录
 *
 */
public class TraceLog {

	
	
	/**
	 * 记录日志
	 * @param loggerName Logger Name
	 * @param message 
	 */
	public static void log(String loggerName, String message) {
		Log log = LogFactory.getLog(loggerName);
		
		if (log.isInfoEnabled()) {
			log.info(message);
		}
		
	}
	
	
	

	
	
	
}
