package com.xx.common.basedb;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.helpers.FormattingTuple;
import org.slf4j.helpers.MessageFormatter;
import org.springframework.util.ReflectionUtils;

import com.xx.common.basedb.anno.Id;
import com.xx.common.basedb.anno.MinMax;
import com.xx.common.utility.ReflectionUtility;

/**
 * 唯一标示获取实例创建器
 * @author frank
 */
public class GetterBuilder {
	
	private static final Logger logger = LoggerFactory.getLogger(GetterBuilder.class);

	/** 属性识别器 */
	private static class FieldGetter implements Getter {
		
		private final Field field;
		
		public FieldGetter(Field field) {
			ReflectionUtils.makeAccessible(field);
			this.field = field;
		}
		
		@Override
		public Object getValue(Object object) {
			Object value = null;
			try {
				value = field.get(object);
			} catch (Exception e) {
				FormattingTuple message = MessageFormatter.format("标识符属性访问异常", e);
				logger.error(message.getMessage());
				throw new RuntimeException(message.getMessage());
			}
			return value;
		}
	}
	
	/** 方法识别器 */
	@SuppressWarnings("unused")
	private static class MethodGetter implements Getter {
		
		private final Method method;
		
		public MethodGetter(Method method) {
			ReflectionUtils.makeAccessible(method);
			this.method = method;
		}
		
		@Override
		public Object getValue(Object object) {
			Object value = null;
			try {
				value = method.invoke(object);
			} catch (Exception e) {
				FormattingTuple message = MessageFormatter.format("标识方法访问异常", e);
				logger.error(message.getMessage());
				throw new RuntimeException(message.getMessage());
			}
			return value;
		}
	}

	/**
	 * 创建指定资源类的唯一标示获取实例
	 * @param clz 资源类
	 * @return
	 */
	public static Getter createIdGetter(Class<?> clz) {
		Field[] fields = ReflectionUtility.getDeclaredFieldsWith(clz, Id.class);
		if(fields == null){
			FormattingTuple message = MessageFormatter.format("类 [{}] 缺少唯一标识声明", clz);
			logger.error(message.getMessage());
			throw new RuntimeException(message.getMessage());
		}
		if(fields.length > 1){
			FormattingTuple message = MessageFormatter.format("类 [{}] 有多个唯一标识声明", clz);
			logger.error(message.getMessage());
			throw new RuntimeException(message.getMessage());
		}
		
		return new FieldGetter(fields[0]);
	}
	
	

	/**
	 * 创建指定资源类的minmax获取者
	 * @param clz 资源类
	 * @return
	 */
	public static Map<String, Getter> createMinMaxGetter(Class<?> clz) {
		Map<String, Getter> getterMap = new HashMap<String, Getter>();
		Field[] fields = ReflectionUtility.getDeclaredFieldsWith(clz, MinMax.class);
		if(fields != null && fields.length > 0){
			for(Field field : fields){
				field.setAccessible(true);
				if(Number.class.isAssignableFrom(field.getType())){
					FormattingTuple message = MessageFormatter.format("类 [{}] 属性 [{}] 带有  @MinMax 标注但是不是 Number 类型!", clz.getName(), field.getName());
					logger.error(message.getMessage());
					throw new RuntimeException(message.getMessage());
				}
				MinMax minMax = field.getAnnotation(MinMax.class);
				String name = minMax.name();
				if(StringUtils.isBlank(name)){
					name = field.getName();
				}
				getterMap.put(name, new FieldGetter(field));
			}
		}
		return getterMap;
	}
	
	
}
