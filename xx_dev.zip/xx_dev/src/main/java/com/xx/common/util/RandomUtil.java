package com.xx.common.util;


import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Random;

public class RandomUtil{
	private static ThreadLocal<Random> threadLocal = new ThreadLocal<Random>();
	
	public static void setRandomProvider(Random random) {
		threadLocal.set(random);
	}
	
	private static Random getRandomProvider() {
		Random random = threadLocal.get();
		if(random == null) {
			String algorithm = "SHA-256";
			try {
				random = SecureRandom.getInstance(algorithm);
			} catch (NoSuchAlgorithmException e) {
				random = new SecureRandom();
			}
			threadLocal.set(random);
		}
		return random;
	}
	
	public static boolean nextBoolean() {
		return getRandomProvider().nextBoolean();	
	}
	
	public static double nextDouble() {
		return getRandomProvider().nextDouble();
	}
	
	public static float nextFloat() {
		return getRandomProvider().nextFloat();
	}
	
	public static int nextInt() {
		return getRandomProvider().nextInt();
	}
	
	public static int nextInt(int n) {
		return getRandomProvider().nextInt(n);
	}
	
	public static long nextLong() {
		return getRandomProvider().nextLong();
	}
	
	/**
	 * 在指定的两个值之间生成一个随机数(包括边界值)
	 * @param minValue 
	 * @param maxValue
	 * @return
	 */
	public static int betweenValue(int minValue, int maxValue){
		if(minValue >= maxValue){
			return minValue;
		}
		
		return nextInt(maxValue - minValue + 1) + minValue;
	}
	
	/**
	 * 在指定的两个值之间生成一个随机数(包括边界值)
	 * @param minValue 
	 * @param maxValue
	 * @param excludes 生成出来的值不能在这个集合里面
	 * @return
	 */
	public static int betweenValue(int minValue, int maxValue, Collection<Integer> excludes){
		if(minValue >= maxValue){
			return minValue;
		}
		
		int hit = nextInt(maxValue - minValue + 1) + minValue;
		
		if(excludes == null || excludes.isEmpty()){
			return hit;
		}
		
		int dis = maxValue - minValue + 1;
		
		if(dis >= 20){//距离>= 20 采用循环方式
			
			while(excludes.contains(hit)){
				hit = nextInt(maxValue - minValue + 1) + minValue;
			}
			
			return hit;
			
		} else {//距离短采用集合排除方式
			
			List<Integer> seed = new ArrayList<Integer>();
			for(int i = minValue; i <= maxValue; i++){
				if(!excludes.contains(i)){
					seed.add(i);
				}
			}
			
			if(seed.isEmpty()){
				return nextInt(maxValue - minValue + 1) + minValue;
			}
			
			return seed.get(Tools.getRandomInteger(seed.size()));
		}
	}
}
