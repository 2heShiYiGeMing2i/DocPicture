/**
 * 
 */
package com.xx.common.utility.throttle;

/**
 * 流动许可
 * @author fansth
 *
 */
public enum FlowLicense {

	/**
	 * 正常流动 
	 */
	OK,
	
	/**
	 * 异常流动警告
	 */
	WARN,
	
	/**
	 * 多次异常黑名单
	 */
	BLACK
	
}
