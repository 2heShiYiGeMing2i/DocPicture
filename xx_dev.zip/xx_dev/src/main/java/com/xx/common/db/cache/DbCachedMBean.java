/**
 * 
 */
package com.xx.common.db.cache;

import javax.management.MXBean;

/**
 * dbcache的jmx接口
 * @author fansth
 *
 */
@MXBean
public interface DbCachedMBean {

	/**
	 * 获取入库线程池队列上排队的任务数量
	 * @return
	 */
	int getQueuedTaskSize();
	
	/**
	 * 获取入库线程池池内线程数量
	 * @return
	 */
	int getPoolSize();
	
	/**
	 * 获取正在执行任务的线程大小
	 * @return
	 */
	int getActiveThreadSize();
	
	/**
	 * 获取线程池执行过和待执行的任务数量
	 * @return
	 */
	long getTaskCount();
	
	/**
	 * 获取线程池执行过的任务数量
	 * @return
	 */
	long getCompletedTaskCount();
	
	/**
	 * 获取实体缓存的大小
	 * @return
	 */
	int getEntityCacheSize();
	
	/**
	 * 获取通用缓存的大小
	 * @return
	 */
	int getCommonCacheSize();
	
	/**
	 * 调整线程池大小
	 * @param coreSize
	 */
//	void setCorePoolSize(int coreSize);
	
	/**
	 * 获取线程池核心大小
	 * @return
	 */
	int getCorePoolSize();
	
	/**
	 * 调整线程池最大线程数
	 * @param maxSize
	 */
//	void setMaxPoolSize(int maxSize);
	
	/**
	 * 获取线程池最大线程数量
	 * @return
	 */
	int getMaxPoolSize();
	
	/**
	 * 获取入库线程池池内最大峰值线程数量
	 * @return
	 */
	int getLargestPoolSize();
}
