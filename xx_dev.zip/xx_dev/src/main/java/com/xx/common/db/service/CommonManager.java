package com.xx.common.db.service;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import org.hibernate.criterion.DetachedCriteria;




/**
 * 通用数据库管理器接口
 */
public interface CommonManager {
	
	/**
	 * 根据主键id取得实体对象
	 * @param entityClazz 实体类
	 * @param id 主键id
	 * @return 实体对象
	 */
	<T> T get(Class<T> entityClazz, Serializable id);
	
	
	/**
	 * 保存实体对象
	 * @param entity 实体对象
	 */
	<T> void save(T entity);
	
	
	/**
	 * 更新实体对象
	 * @param entity 实体对象
	 */
	<T> void update(T entity);
	
	
	/**
	 * 删除实体
	 * @param entityClazz 实体对象
	 * @param id 主键id
	 */
	<T> void delete(Class<T> entityClazz, Serializable id);
	
	
	/**
	 * 取得最大主键值(主键为Integer/Long类型)
	 * @param entityClazz 实体对象
	 * @return Object
	 */
	Object getMaxIdValues(Class<?> entityClazz);
	
	/**
	 * 取得指定条件，位置，大小的集合列表
	 * 
	 * @param criteria		查询条件
	 * @param fromIdx		开始索引（从0开始）
	 * @param fetchCount	列表大小
	 */
	@SuppressWarnings("rawtypes")
	public List getCommonQueryResult(DetachedCriteria paramDetachedCriteria, int firstResult, int fecthCount);
	
	/**
	 * Execute the update or delete statement. 
	 * @param queryString a HQL query
	 * @param paramMap Bind a value to a named query parameter
	 * @return The number of entities updated or deleted.
	 */
	int executeUpdate(String queryString, Map<String, Object> paramMap);
}
