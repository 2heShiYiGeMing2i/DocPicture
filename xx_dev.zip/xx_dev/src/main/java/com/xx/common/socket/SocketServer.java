package com.xx.common.socket;

import java.net.InetSocketAddress;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.TimeUnit;

import org.apache.mina.core.filterchain.DefaultIoFilterChainBuilder;
import org.apache.mina.core.filterchain.IoFilter;
import org.apache.mina.core.service.IoHandler;
import org.apache.mina.core.session.IdleStatus;
import org.apache.mina.filter.codec.ProtocolCodecFactory;
import org.apache.mina.filter.codec.ProtocolCodecFilter;
import org.apache.mina.filter.codec.ProtocolDecoder;
import org.apache.mina.filter.codec.ProtocolEncoder;
import org.apache.mina.filter.executor.ExecutorFilter;
import org.apache.mina.transport.socket.SocketAcceptor;
import org.apache.mina.transport.socket.SocketSessionConfig;
import org.apache.mina.transport.socket.nio.NioSocketAcceptor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.xx.common.socket.codec.CodecFactory;
import com.xx.common.socket.codec.RequestDecoder;
import com.xx.common.socket.codec.ResponseEncoder;
import com.xx.common.socket.converter.ObjectConverters;
import com.xx.common.utility.thread.NamedThreadFactory;


/**
 * 服务器类
 * 
 * @author bingshan
 */
public class SocketServer {
	private static final Logger logger = LoggerFactory.getLogger(SocketServer.class);
	
	/**
	 * SocketAcceptor
	 */
	private SocketAcceptor acceptor;
    
    /**
     * IoHandler
     */
    private IoHandler ioHandler;
    
    /**
     * 配置信息
     */
    private ServerConfig config;
    
    /**
     * processors available 
     */
    private int processorCount = Runtime.getRuntime().availableProcessors();
    
    /**
     * 编解码前的过滤器集合
     */
    private Map<String, IoFilter> filtersBeforeCodec;
    
    /**
     * 编解码后的过滤器集合
     */
    private Map<String, IoFilter> filtersAfterCodec;
    
    /**
     * ExecutorFilter
     */
    private ExecutorFilter executorFilter;
    
    /**
	 * 对象转换器集合
	 */
	private ObjectConverters objectConverters;
    
	
	public SocketServer() {
		
	}	

	/**
	 * 开启服务器
	 */
	public void start() throws Exception {
		if (config == null) {
			//默认配置
			config = new ServerConfig();
		}		
		
		acceptor = new NioSocketAcceptor(processorCount);
		
		//Session配置
		SocketSessionConfig sessionConfig = acceptor.getSessionConfig();
		sessionConfig.setReadBufferSize(config.getSessionReadBuffer());
		sessionConfig.setSendBufferSize(config.getSessionSendBuffer());
		sessionConfig.setIdleTime(IdleStatus.BOTH_IDLE, config.getSessionIdleTime());
		
		//过滤器配置
		DefaultIoFilterChainBuilder filterChain = acceptor.getFilterChain();
		addFilters(filterChain, filtersBeforeCodec);
		
		ProtocolCodecFactory codecFactory = createCodecFactory();
		filterChain.addLast("codec", new ProtocolCodecFilter(codecFactory));
		
		executorFilter = createExecutorFilter(config.getPoolCoreSize(), config.getPoolMaxSize(), config.getPoolKeepAliveTime());
		filterChain.addLast("threadPool", executorFilter);
		
		addFilters(filterChain, filtersAfterCodec);
		
		//Handler
		acceptor.setHandler(ioHandler);
		
		acceptor.setReuseAddress(true);		
		InetSocketAddress localAddress = new InetSocketAddress(config.getPort());		
		acceptor.bind(localAddress);		
		logger.info("绑定服务地址和端口到[{}:{}]", localAddress.getHostName(), localAddress.getPort());
	}
	
	/**
	 * 关闭服务器
	 */
	public void close() throws Exception {
		if (acceptor != null) {
			acceptor.unbind();
			acceptor.dispose();
			acceptor = null;
		}
		
		if (executorFilter != null) {
			executorFilter.destroy();
		}
	}
	
	/**
	 * 添加过滤器
	 * @param filterChain DefaultIoFilterChainBuilder
	 * @param filters Map<String, IoFilter>
	 */
	private void addFilters(DefaultIoFilterChainBuilder filterChain, Map<String, IoFilter> filters) {
		if (filters == null) {
			return;
		}
		
		for (Entry<String, IoFilter> entry: filters.entrySet()) {
			String name = entry.getKey();
			IoFilter filter = entry.getValue();
			filterChain.addLast(name, filter);
		}
	}
	
	/**
	 * 创建ExecutorFilter
	 * @param corePoolSize
	 * @param maximumPoolSize
	 * @param keepAliveTime
	 * @return ExecutorFilter
	 */
	private ExecutorFilter createExecutorFilter(int corePoolSize, int maximumPoolSize, long keepAliveTime) {
		ThreadGroup group = new ThreadGroup("通信模块");
		NamedThreadFactory threadFactory = new NamedThreadFactory(group, "通信线程");
		return new ExecutorFilter(corePoolSize, maximumPoolSize, keepAliveTime, TimeUnit.MILLISECONDS, threadFactory);
	}
	
	/**
	 * 创建ProtocolCodecFactory
	 * @return ProtocolCodecFactory
	 */
	private ProtocolCodecFactory createCodecFactory() {
		ProtocolEncoder encoder = new ResponseEncoder(objectConverters);
		ProtocolDecoder decoder = new RequestDecoder();
		return new CodecFactory(encoder, decoder);
	}
	
	/**
	 * 取得服务器配置信息
	 * @return ServerConfig
	 */
	public ServerConfig getConfig() {
		return config;
	}

	/**
	 * 设置服务器配置信息
	 * @param config ServerConfig
	 */
	public void setConfig(ServerConfig config) {
		this.config = config;
	}

	public int getProcessorCount() {
		return processorCount;
	}

	public void setProcessorCount(int processorCount) {
		this.processorCount = processorCount;
	}

	/**
	 * 取得编解码前的过滤器集合
	 * @return Map<String, IoFilter>
	 */
	public Map<String, IoFilter> getFiltersBeforeCodec() {
		return filtersBeforeCodec;
	}

	/**
	 * 设置编解码前的过滤器集合
	 * @param filtersBeforeCodec Map<String, IoFilter>
	 */
	public void setFiltersBeforeCodec(Map<String, IoFilter> filtersBeforeCodec) {
		this.filtersBeforeCodec = filtersBeforeCodec;
	}

	/**
	 * 取得解码后的过滤器集合
	 * @return Map<String, IoFilter>
	 */
	public Map<String, IoFilter> getFiltersAfterCodec() {
		return filtersAfterCodec;
	}

	/**
	 * 设置解码后的过滤器集合
	 * @param filtersAfterCodec Map<String, IoFilter>
	 */
	public void setFiltersAfterCodec(Map<String, IoFilter> filtersAfterCodec) {
		this.filtersAfterCodec = filtersAfterCodec;
	}

	/**
	 * 取得 IoHandler
	 * @return IoHandler
	 */
	public IoHandler getIoHandler() {
		return ioHandler;
	}

	/**
	 * 设置 IoHandler
	 * @param ioHandler IoHandler
	 */
	public void setIoHandler(IoHandler ioHandler) {
		this.ioHandler = ioHandler;
	}
	
	/**
	 * 取得对象转换器集合
	 * @return ObjectConverters
	 */
	public ObjectConverters getObjectConverters() {
		return objectConverters;
	}

	/**
	 * 设置对象转换器集合
	 * @param objectConverters ObjectConverters
	 */
	public void setObjectConverters(ObjectConverters objectConverters) {
		this.objectConverters = objectConverters;
	}
}
