package com.xx.common.socket.handler;

import org.apache.mina.core.service.IoHandler;
import org.apache.mina.core.service.IoHandlerAdapter;
import org.apache.mina.core.session.IoSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.xx.common.socket.converter.ObjectConverters;
import com.xx.common.socket.model.Request;
import com.xx.common.socket.model.Response;

/**
 * 服务器 {@link IoHandler}
 * 
 * @author bingshan
 */
public class ServerHandler extends IoHandlerAdapter {
	
	/**
	 * logger
	 */
	private static final Logger logger = LoggerFactory.getLogger(ServerHandler.class);
	
	@Override
	public void messageReceived(IoSession session, Object message) throws Exception {
		if (message == null) {
			return;
		}
		
		if (message instanceof Request) {
			Request request = (Request) message;
			if (this.requestProcessors == null) {
				logger.error("请求处理器集合为空！");
				return;
			}
			
			RequestProcessor processor = this.requestProcessors.getProcessor(request.getModule(), request.getCmd());
			if (processor == null) {
				logger.error("没有对应的请求处理器[module:{}, cmd:{}]！", new Object[] {request.getModule(), request.getCmd()});
				return;
			}
			
			if (request.isCompressed()) {
				//TODO 解压
			}			
			
			//对象转换
			if (processor.getType() != null) {
				Object obj = this.objectConverters.decode(request.getFormat(), request.getValueBytes(), processor.getType());
				request.setValue(obj);
			}
			
			//业务处理
			Response response = Response.wrap(request);
			processor.process(session, request, response);
			
		} else {
			logger.error("无效的请求消息类型！");
		}
	}

	

	/**
	 * 请求处理器集合
	 */
	private RequestProcessors requestProcessors;
	
	/**
	 * 对象转换器集合
	 */
	private ObjectConverters objectConverters;
	
	
	/**
	 * 取得请求处理器集合
	 * @return RequestProcessors
	 */
	public RequestProcessors getRequestProcessors() {
		return requestProcessors;
	}

	/**
	 * 设置请求处理器集合
	 * @param requestProcessors RequestProcessors
	 */
	public void setRequestProcessors(RequestProcessors requestProcessors) {
		this.requestProcessors = requestProcessors;
	}

	/**
	 * 取得对象转换器集合
	 * @return ObjectConverters
	 */
	public ObjectConverters getObjectConverters() {
		return objectConverters;
	}

	/**
	 * 设置对象转换器集合
	 * @param objectConverters ObjectConverters
	 */
	public void setObjectConverters(ObjectConverters objectConverters) {
		this.objectConverters = objectConverters;
	}

}
