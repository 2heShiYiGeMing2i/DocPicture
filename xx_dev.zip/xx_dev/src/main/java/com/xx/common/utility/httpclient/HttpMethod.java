/**
 * 
 */
package com.xx.common.utility.httpclient;

/**
 * 
 * @author fansth
 *
 */
public enum HttpMethod {

	/**
	 * post请求
	 */
	POST,
	
	/**
	 * get请求
	 */
	GET;
	
}
