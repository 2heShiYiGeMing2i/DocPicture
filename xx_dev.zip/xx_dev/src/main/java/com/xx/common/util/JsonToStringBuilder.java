/**
 * 
 */
package com.xx.common.util;

import java.util.HashMap;
import java.util.Map;

/**
 * @author fansth
 *
 */
public class JsonToStringBuilder {

	private Map<String, Object> map = new HashMap<String, Object>();
	
	
	public JsonToStringBuilder append(String fieldName, Object fieldValue){
		this.map.put(fieldName, fieldValue);
		return this;
	}
	
	@SuppressWarnings("unchecked")
	public JsonToStringBuilder append(Object bean){
		this.map.putAll(BeanUtil.buildMap(bean));
		return this;
	}
	
	public String toString(){
		return JsonUtil.toJson(this.map);
	}
	
	
}
