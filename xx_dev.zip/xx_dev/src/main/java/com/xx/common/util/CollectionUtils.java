package com.xx.common.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * 集合工具类
 */
public abstract class CollectionUtils {
	
	/**
	 * 获取列表的子集的拷贝
	 * 
	 * @param <T>
	 * @param source 			源列表
	 * @param start 			开始位置
	 * @param count 			获取记录数量
	 * @return {@link List}		返回结果是另一个 ArrayList 实例
	 */
	public static <T> List<T> subListCopy(List<T> source, int start, int count) {
		if (source == null || source.size() == 0) {
			return new ArrayList<T>(0);
		}
		
		int fromIndex = start <= 0 ? 0 : start;
		if (start > source.size()) {
			fromIndex = source.size();
		}
		
		count = count <= 0 ? 0 : count;	//增加了边界处理
		int endIndex = fromIndex + count;
		if (endIndex > source.size()) {
			endIndex = source.size();
		}
		return new ArrayList<T>(source.subList(fromIndex, endIndex));
	}
	
	/**
	 * 获取列表的子集的拷贝
	 * 
	 * @param <T>
	 * @param  source 			源列表
	 * @param  startIndex 		开始位置
	 * @param  stopIndex 		结束位置
	 * @return {@link List}		返回结果是另一个 ArrayList 实例
	 */
	public static <T> List<T> subList(List<T> source, int startIndex, int stopIndex) {
		if (source == null || source.size() == 0) {
			return new ArrayList<T>(0);
		}
		
		int fromIndex = startIndex <= 0 ? 0 : startIndex;
		if (startIndex > source.size()) {
			fromIndex = source.size();
		}
		
		stopIndex = stopIndex <= 0 ? 0 : stopIndex;//增加了边界处理
		stopIndex = stopIndex <= startIndex ? startIndex : stopIndex;
		if (stopIndex > source.size()) {
			stopIndex = source.size();
		}
		return new ArrayList<T>(source.subList(fromIndex, stopIndex));
	}
	
	/**
	 * 当列表元素不存在时，进行添加
	 * 
	 * @param list 		列表
	 * @param idx 		插入位置
	 * @param element 	插入的元素
	 */
	public static <T> void addNotExist(List<T> list, int idx, T element) {
		if (!list.contains(element)) {
			list.add(idx, element);
		}
	}
	
	/**
	 * 合并两个集合
	 * @param <T>
	 * @param collection1
	 * @param collection2
	 * @return 一个不为null的集合,这个集合就是 collection1和collection2的并集
	 */
	public static <T> Set<T> union(Collection<T> collection1, Collection<T> collection2){
		Set<T> set = new HashSet<T>();
		if(collection1 != null){
			set.addAll(collection1);
		}
		if(collection2 != null){
			set.addAll(collection2);
		}
		return set;
	}
	
	
	/**
	 * 将数组转换为指定的列表
	 * @param <T>
	 * @param arrays
	 * @param typeClass
	 * @return
	 */
	public static <T> List<T> arrayAsList(Object[] arrays, Class<T> typeClass){
		if(arrays == null){
			return Collections.<T>emptyList();
		}
		
		List<T> list = new ArrayList<T>(arrays.length);
		for(Object e : arrays){
			list.add((T)e);
		}
		return list;
	}
	
	
	/**
	 * 从collection中随机一个元素
	 * @param <T>
	 * @param collection
	 * @param typeClass
	 * @return
	 */
	public static <T> T randomElement(Collection<T> collection,  Class<T> typeClass){
		if(collection != null && !collection.isEmpty()){
			List<T> list = new ArrayList<T>(collection);
			return list.get(Tools.getRandomInteger(list.size()));
		}
		return null;
	}

}
