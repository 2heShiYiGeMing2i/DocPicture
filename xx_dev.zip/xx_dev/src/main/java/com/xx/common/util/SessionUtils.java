/**
 * 
 */
package com.xx.common.util;

import java.net.InetSocketAddress;

import org.apache.mina.core.session.IoSession;

/**
 * @author fansth
 *
 */
public class SessionUtils {

	/**
	 * 获取session的ip
	 * @param session
	 * @return
	 */
	public static String getIp(IoSession session){
		InetSocketAddress addr = (InetSocketAddress)session.getRemoteAddress();
		return addr != null ? addr.getAddress().getHostAddress() : null;
	}
	
}
