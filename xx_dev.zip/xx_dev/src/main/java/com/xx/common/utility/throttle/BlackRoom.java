/**
 * 
 */
package com.xx.common.utility.throttle;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.DelayQueue;
import java.util.concurrent.Delayed;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 黑屋子
 * @author fansth
 *
 */
public class BlackRoom {
	
	private final Logger logger = LoggerFactory.getLogger(BlackRoom.class);
	
	private final ConcurrentHashMap<Long, Black> blackHolder = new ConcurrentHashMap<Long, Black>();
	
	private final DelayQueue<Black> delayQueue = new DelayQueue<BlackRoom.Black>();
	
	//最大被黑时间  默认 24小时 单位：ms
	private long maxBlackMillis = 24 * 3600 * 1000;
	
	public long getMaxBlackMillis() {
		return maxBlackMillis;
	}

	public void setMaxBlackMillis(long maxBlackMillis) {
		this.maxBlackMillis = maxBlackMillis;
	}
	
	public BlackRoom(){}
	
	public BlackRoom(long maxBlackMillis){
		this.maxBlackMillis = maxBlackMillis;
	}
	

	/**
	 * 加入黑名单
	 * @param id
	 * @param nowMilis
	 * @param relaxMillis
	 */
	public void black(long id, long nowMilis, long relaxMillis){
		if(relaxMillis <= 0 || relaxMillis > maxBlackMillis){
			relaxMillis = maxBlackMillis;
		}
		
		this.pollOverdue();
		
		Black black = blackHolder.get(id);
		if(black == null){
			black = new Black(id, nowMilis, relaxMillis);
			blackHolder.putIfAbsent(id, black);
			black = blackHolder.get(id);
		}
		delayQueue.remove(black);
		delayQueue.offer(black);
	}
	
	/**
	 * 解除黑名单
	 * @param id
	 */
	public void white(long id){
		this.pollOverdue();
		Black black = blackHolder.remove(id);
		if(black != null){
			delayQueue.remove(black);
		}
	}
	
	
	/**
	 * 是否在黑名单
	 * @param id
	 * @param nowMillis
	 * @return true-黑名单中
	 */
	public boolean blacked(long id){
		Black black = blackHolder.get(id);
		if(black != null){
			if(black.getDelay(TimeUnit.MILLISECONDS) > 0){
				return true;
			} else {
				blackHolder.remove(id);
				delayQueue.remove(black);
			}
		}
		return false;
	}
	
	/**
	 * 移除掉过期元素
	 */
	private void pollOverdue(){
		try {
			while(true){
				Black overdue = delayQueue.poll();
				if(overdue != null){
					blackHolder.remove(overdue.id);
				} else {
					break;
				}
			}
		} catch (Exception e) {
			logger.error("黑屋子移除过期元素出错!", e);
		}
	}
	
	
	private class Black implements Delayed{
		
		private long id;
		
		private long blackTime = System.currentTimeMillis();
		
		private long relaxMillis = 15 * 60 * 1000;
		
		private Black(long id, long blackTime, long relaxMillis){
			this.id = id;
			this.blackTime = blackTime;
			this.relaxMillis = relaxMillis;
		}
		
		private Black(long id){
			this.id = id;
		}
		

		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + getOuterType().hashCode();
			result = prime * result + (int) (id ^ (id >>> 32));
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			Black other = (Black) obj;
			if (!getOuterType().equals(other.getOuterType()))
				return false;
			if (id != other.id)
				return false;
			return true;
		}

		private BlackRoom getOuterType() {
			return BlackRoom.this;
		}

		@Override
		public int compareTo(Delayed o) {
			if(this == o){
				return 0;
			}
			
			long diff = 0;
			
			if(o instanceof Black){
				Black other = (Black)o;
				diff = this.blackTime + this.relaxMillis - (other.blackTime + other.relaxMillis);
			} else {
				diff = (getDelay(TimeUnit.MILLISECONDS) - o.getDelay(TimeUnit.MILLISECONDS));
			}
			
		    return (diff == 0) ? 0 : ((diff < 0) ? -1 : 1);
		}

		@Override
		public long getDelay(TimeUnit unit) {
			return unit.convert(this.blackTime + this.relaxMillis - System.currentTimeMillis(), TimeUnit.MILLISECONDS);
		}
		
	}
	
	
	public static void main(String[] args) {
		BlackRoom room = new BlackRoom();
		room.black(1, System.currentTimeMillis(), 10000000);
		room.black(2, System.currentTimeMillis(), 10000000);
		
	}
}
