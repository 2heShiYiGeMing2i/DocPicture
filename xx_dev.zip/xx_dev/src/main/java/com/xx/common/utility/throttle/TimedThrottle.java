/**
 * 
 */
package com.xx.common.utility.throttle;

/**
 * 基于时间的节流阀
 * @author fansth
 *
 */
public class TimedThrottle implements Throttle{
	
	/**
	 * 最后一次流动时间
	 */
	private long lastFlowTime = 0L;
	
	/**
	 * 最后一次警告时间
	 */
	private long lastWarnTime = 0L;
	
	/**
	 * 已警告次数
	 */
	private long warnCount = 0;
	
	/**
	 * lastFlowTime + warnIntervals 时间之后流过视为正常否则就警告一次
	 */
	private long warnIntervals = 1000;
	
	/**
	 * lastWarnTime + relaxPeriodMillis 时间之后警告 warnCount重新计数, 否则 warnCount++;
	 */
	private long resetPeriodMillis = 60 * 1000;

	/**
	 * warnCount > maxWarnInPeriod 那么就确定是恶意刷需要给予处分了
	 */
	private int maxWarnInPeriod = 50;
	
	
	public TimedThrottle(){}
	
	public TimedThrottle(long warnIntervals, long resetPeriodMillis, int maxWarnInPeriod) {
		this.warnIntervals = warnIntervals;
		this.resetPeriodMillis = resetPeriodMillis;
		this.maxWarnInPeriod = maxWarnInPeriod;
	}
	

	/**
	 * 流过一次
	 * @return true-正常流过  false-异常流过需要给予处分
	 */
	@Override
	public synchronized FlowLicense flow(double weight) {
		long nowMillis = System.currentTimeMillis();
		long currFlowTime = this.lastFlowTime;
		this.lastFlowTime = nowMillis;
		FlowLicense license = FlowLicense.OK;
		if(nowMillis - currFlowTime <= warnIntervals){//当前时间距离上次流过时间太短给予警告一次
			if(nowMillis - lastWarnTime <= resetPeriodMillis){//当前时间距离上次警告时间太短警告次数累加
				warnCount++;
			} else {//当前时间距离上次警告时间有些时候了忘记了,重新记录警告次数
				warnCount = 1;
			}
			license = FlowLicense.WARN;
			lastWarnTime = nowMillis;
			if(warnCount >= maxWarnInPeriod){//警告次数太多了处罚
				license = FlowLicense.BLACK;
				this.reset();
			}
		} 
		return license;
	} 
	
	private void reset(){
		this.lastFlowTime = 0;
		this.lastWarnTime = 0;
		this.warnCount = 0;
	}
	
	
	
	public long getResetPeriodMillis() {
		return resetPeriodMillis;
	}

	public void setResetPeriodMillis(long resetPeriodMillis) {
		this.resetPeriodMillis = resetPeriodMillis;
	}

	public long getWarnIntervals() {
		return warnIntervals;
	}

	public void setWarnIntervals(long warnIntervals) {
		this.warnIntervals = warnIntervals;
	}

	public int getMaxWarnInPeriod() {
		return maxWarnInPeriod;
	}

	public void setMaxWarnInPeriod(int maxWarnInPeriod) {
		this.maxWarnInPeriod = maxWarnInPeriod;
	}

}
