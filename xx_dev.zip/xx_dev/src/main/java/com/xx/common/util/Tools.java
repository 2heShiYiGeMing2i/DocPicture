package com.xx.common.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.lang.reflect.Array;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import org.apache.commons.beanutils.ConvertUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.xx.common.db.model.BaseModel;
import com.xx.common.utility.rhino.RhinoHelper;

public class Tools {
	private static final Log log = LogFactory.getLog(Tools.class);

	private Tools() {

	}

	public static final String DELIMITER_INNER_ITEM = "_";
	public static final String DELIMITER_INNER_ITEM1 = ":";
	public static final String DELIMITER_INNER_ITEM2 = ",";
	public static final String DELIMITER_BETWEEN_ITEMS = "|";
	public static final String DELIMITER_BETWEEN_ITEMS2 = "#";
	public static final String ARGS_DELIMITER = " ";
	public static final String ARGS_ITEMS_DELIMITER = "\\|";

	/**
	 * 对象转换成字节数组
	 * 
	 * @param obj
	 *            对象
	 * @return byte[]
	 */
	public static byte[] object2ByteArray(Object obj) {
		if (obj == null) {
			return null;
		}

		try {
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			(new ObjectOutputStream(bos)).writeObject(obj);

			return bos.toByteArray();
		} catch (IOException ex) {
			log.error("failed to serialize obj", ex);

			return null;
		}

	}

	/**
	 * 字节数组转换成对象
	 * 
	 * @param buffer
	 * @return Object
	 */
	public static Object byteArray2Object(byte[] buffer) {
		if (buffer == null || buffer.length == 0) {
			return null;
		}

		ByteArrayInputStream bais = new ByteArrayInputStream(buffer);
		ObjectInputStream ois = null;
		try {
			ois = new ObjectInputStream(bais);
			return ois.readObject();
		} catch (Exception ex) {
			log.error("failed to deserialize obj", ex);
			return null;
		} finally{
			try{
				if(ois != null){
					ois.close();
				}
			} catch (Exception e){
			}
			try {
				bais.close();
			} catch (Exception e) {
			}
		}
	}

	/**
	 * 取得随机数
	 * 
	 * @param maxValue
	 *            随机的最大值
	 * @return 随机的值
	 */
	public static int getRandomInteger(int maxValue) {
		if (maxValue <= 0) {
			return 0;
		}

		return RandomUtil.nextInt(maxValue);
	}

	/**
	 * 把以|_分割的字符串分解成数组
	 * 
	 * @param delimiterString
	 * @return List<String[]>
	 */
	public static List<String[]> delimiterString2Array(String delimiterString) {
		if (delimiterString == null || delimiterString.trim().length() == 0) {
			return null;
		}

		String[] ss = delimiterString.trim().split(Tools.ARGS_ITEMS_DELIMITER);
		if (ss != null && ss.length > 0) {
			List<String[]> list = new ArrayList<String[]>();
			for (int i = 0; i < ss.length; i++) {
				list.add(ss[i].split(Tools.DELIMITER_INNER_ITEM));
			}

			return list;
		}
		return null;
	}
	
	/**
	 * 把以|_分割的字符串分解成数组
	 * 
	 * @param delimiterString
	 * @return List<String[]>
	 */
	public static List<String[]> delimiterString2Array(String delimiterString, String delimiter1, String delimiter2) {
		if (StringUtils.isBlank(delimiterString)) {
			return null;
		}
		
		

		String[] ss = delimiterString.trim().split(Tools.ARGS_ITEMS_DELIMITER);
		if (ss != null && ss.length > 0) {
			List<String[]> list = new ArrayList<String[]>();
			for (int i = 0; i < ss.length; i++) {
				list.add(ss[i].split(Tools.DELIMITER_INNER_ITEM));
			}

			return list;
		}
		return null;
	}

	/**
	 * 把以|_分割的字符串分解成HashMap,键位为字符串的0下标数值
	 * 
	 * @param delimiterString
	 * @return Map<String,String[]>
	 */
	public static Map<String, String[]> delimiterString2Map(
			String delimiterString) {
		Map<String, String[]> map = new HashMap<String, String[]>();
		if (delimiterString == null || delimiterString.trim().length() == 0) {
			return map;
		}

		String[] ss = delimiterString.trim().split(Tools.ARGS_ITEMS_DELIMITER);
		if (ss != null && ss.length > 0) {

			for (int i = 0; i < ss.length; i++) {
				String[] str = ss[i].split(Tools.DELIMITER_INNER_ITEM);
				if (str.length > 0) {
					map.put(str[0], str);
				}
			}
			return map;
		}
		return map;
	}

	/**
	 * 把子项集合转换成以|_分割的字符串
	 * 
	 * @param delimiterString
	 * @return Map<String,String[]>
	 */
	public static String delimiterCollection2String(Collection<String[]> collection) {
		if (collection == null || collection.isEmpty()) {
			return "";
		}

		StringBuffer subContent = new StringBuffer();
		for (String[] strings : collection) {
			if (strings == null || strings.length == 0) {
				continue;
			}

			for (int i = 0; i < strings.length; i++) {
				if (i == strings.length - 1) {
					subContent.append(strings[i]).append(
							Tools.DELIMITER_BETWEEN_ITEMS);
					continue;
				}

				subContent.append(strings[i])
						.append(Tools.DELIMITER_INNER_ITEM);
			}
		}
		return subContent.toString();
	}
	
	/**
	 * 将map转换成以|_分割的字符串
	 * @param map
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public static String map2String(Map map){
		StringBuilder str = new StringBuilder();
		for(Object key : map.keySet()){
			str.append( key ).append(Tools.DELIMITER_INNER_ITEM).append( map.get(key) ).append(Tools.DELIMITER_BETWEEN_ITEMS);
		}
		if(str.length() > 0){
			str.deleteCharAt( str.length() - 1 );
		}
		return str.toString();
	}
	
	/**
	 * 把子项数组转换成以|_分割的字符串
	 * 
	 * @param subArray
	 *            子项数组
	 * @return String
	 */
	public static String array2DelimiterString(String[] subArray) {
		if (subArray == null || subArray.length == 0) {
			return "";
		}

		StringBuffer subContent = new StringBuffer();

		for (int i = 0; i < subArray.length; i++) {
			subContent.append(subArray[i]).append(Tools.DELIMITER_INNER_ITEM);
		}

		String tmp = subContent.toString().substring(0,
				subContent.lastIndexOf(Tools.DELIMITER_INNER_ITEM));

		return tmp + Tools.DELIMITER_BETWEEN_ITEMS;
	}

	/**
	 * 把List中的子项数组转换成以|_分割的字符串
	 * 
	 * @param subArrayList
	 *            , 子项数组集合
	 * @return String
	 */
	public static String listArray2DelimiterString(List<String[]> subArrayList) {
		if (subArrayList == null || subArrayList.isEmpty()) {
			return "";
		}

		StringBuffer subContent = new StringBuffer();
		for (String[] strings : subArrayList) {
			if (strings == null || strings.length == 0) {
				continue;
			}

			for (int i = 0; i < strings.length; i++) {
				if (i == strings.length - 1) {
					subContent.append(strings[i]).append(
							Tools.DELIMITER_BETWEEN_ITEMS);
					continue;
				}

				subContent.append(strings[i])
						.append(Tools.DELIMITER_INNER_ITEM);
			}
		}
		return subContent.toString();
	}

	/**
	 * 提供精确的小数位四舍五入处理。
	 * 
	 * @param v
	 *            需要四舍五入的数字
	 * @param scale
	 *            小数点后保留几位
	 * @return 四舍五入后的结果
	 */
	public static double round(double v, int scale) {
		if (scale < 0) {
			throw new IllegalArgumentException(
					"The scale must be a positive integer or zero");
		}
		BigDecimal b = new BigDecimal(Double.toString(v));
		BigDecimal one = new BigDecimal("1");
		return b.divide(one, scale, BigDecimal.ROUND_HALF_UP).doubleValue();
	}

	public static double roundDown(double v, int scale) {
		if (scale < 0) {
			throw new IllegalArgumentException(
					"The scale must be a positive integer or zero");
		}
		BigDecimal b = new BigDecimal(Double.toString(v));
		BigDecimal one = new BigDecimal("1");
		return b.divide(one, scale, BigDecimal.ROUND_DOWN).doubleValue();
	}

	public static double roundUp(double v, int scale) {
		if (scale < 0) {
			throw new IllegalArgumentException(
					"The scale must be a positive integer or zero");
		}
		BigDecimal b = new BigDecimal(Double.toString(v));
		BigDecimal one = new BigDecimal("1");
		return b.divide(one, scale, BigDecimal.ROUND_UP).doubleValue();
	}

	public static double divideAndRoundUp(double v1, double v2, int scale) {
		if (scale < 0) {
			throw new IllegalArgumentException(
					"The scale must be a positive integer or zero");
		}

		BigDecimal bd1 = new BigDecimal(v1);
		BigDecimal bd2 = new BigDecimal(v2);

		return bd1.divide(bd2, scale, BigDecimal.ROUND_UP).doubleValue();
	}

	public static double divideAndRoundDown(double v1, double v2, int scale) {
		if (scale < 0) {
			throw new IllegalArgumentException(
					"The scale must be a positive integer or zero");
		}

		BigDecimal bd1 = new BigDecimal(v1);
		BigDecimal bd2 = new BigDecimal(v2);

		return bd1.divide(bd2, scale, BigDecimal.ROUND_DOWN).doubleValue();
	}

	/**
	 * 计算time2距离time1时间
	 * 
	 * @param time1
	 * @param time2
	 * @return 差距
	 */
	public static long getQuot(String time1, String time2) {
		long quot = 0;
		SimpleDateFormat ft = new SimpleDateFormat("yyyy-MM-dd");
		try {
			Date date1 = ft.parse(time1);
			Date date2 = ft.parse(time2);
			quot = date1.getTime() - date2.getTime();
			quot = quot / 1000 / 60 / 60 / 24;
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return quot;
	}
	
	/**
	 * 内存列表分页
	 * @param <T>
	 * @param list
	 * @param startIndex
	 * @param fetchCount
	 * @return
	 */
	public static <T> List<T> pageResult(List<T> list, int startIndex, int fetchCount){
		if(list != null && list.size() > 0){
			if(startIndex >= list.size()){
				return null;
			}
			startIndex = startIndex < 0?0:startIndex;
			if(fetchCount <= 0){
				return list.subList(startIndex, list.size());
			}
			int toIndex = Math.min(startIndex + fetchCount, list.size());
			return list.subList(startIndex, toIndex);
		}
		
		return null;
	}
	
	
	/**
	 * 将制定的键值放入map (其中 Map<?, List<?>>)
	 * @param map  Map<?, List<?>>
	 * @param key
	 * @param value
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static void add2MapList(Map map, Object key, Object value){
		if(map != null && key != null){
			List list = (List)map.get(key);
			if(list == null){
				list = new ArrayList();
				map.put(key, list);
			}
			list.add(value);
		}
	}
	
	
	/**
	 * tokenedString 包含了token就直接返回 没有token就卷入token
	 * 假如以,分隔  tokenedString = 1,2,3 如果 token = 1 则结果为 1,2,3 如果 token = 4 则结果为 1,2,3,4(判断一下tokenedString和结果就知道有没有卷入了)
	 * @param tokenedString 带有分隔符的字符串
	 * @param delimiter 分隔符
	 * @param token 需要卷入的分隔项
	 * @return
	 */
	public static String involveToken(String tokenedString, String delimiter, Object token){
		if(tokenedString == null){
			tokenedString = "";
		}
		if(token == null){
			return tokenedString;
		}
		String tokens = String.valueOf(token);
		tokens = tokens.trim();
		if(StringUtils.isBlank(tokenedString)){
			return tokens;
		}
		tokenedString = tokenedString.trim();
		
		StringTokenizer tokenizer = new StringTokenizer(tokenedString, delimiter);
		while(tokenizer.hasMoreTokens()){
			if(tokens.equals(tokenizer.nextToken())){//包含了token就直接返回 没有token加假如token
				return tokenedString;
			}
		}
		return new StringBuilder(tokenedString).append(delimiter).append(tokens).toString();
	}
	
	
	/**
	 * 增加map中的值
	 * @param map
	 * @param key
	 * @param value
	 */
	public static void increaseMapValue(Map<String, Object> map, String key, Number value){
		if(map != null && value != null){
			Number mapValue = (Number)map.get(key);
			if(mapValue == null){
				mapValue = 0;
			}
			map.put(key, mapValue.doubleValue() + value.doubleValue());
		}
	}
	
	/**
	 * 减少map中的值
	 * @param map
	 * @param key
	 * @param value
	 */
	public static void decreaseMapValue(Map<String, Object> map, String key, Number value){
		if(map != null && value != null){
			Number mapValue = (Number)map.get(key);
			if(mapValue == null){
				mapValue = 0;
			}
			map.put(key, mapValue.doubleValue() - value.doubleValue());
		}
	}
	
	
	
	/**
	 * 简单的类型转换
	 * @param <T>
	 * @param list
	 * @param clazz
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static <T> List<T> typedList(List<?> list, Class<T> clazz){
		if(list == null){
			return null;
		}
		List<T> resultList = new ArrayList<T>();
		for(Object obj : list){
			T t = null;
			if(obj != null){
				if(Number.class.isAssignableFrom(clazz)){
					if(Long.class.equals(clazz)){
						long longValue = ((Number)obj).longValue();
						t = (T)Long.valueOf(longValue);
					} else if(Double.class.equals(clazz)){
						double doubleValue = ((Number)obj).doubleValue();
						t = (T)Double.valueOf(doubleValue);
					} else if(Integer.class.equals(clazz)){
						int intValue = ((Number)obj).intValue();
						t = (T)Integer.valueOf(intValue);
					} else if(Float.class.equals(clazz)){
						 float floatValue = ((Number)obj).floatValue();
						 t = (T)Float.valueOf(floatValue);
					} else if(Short.class.equals(clazz)){
						short shortValue = ((Number)obj).shortValue();
						 t = (T)Short.valueOf(shortValue);
					} else if(Byte.class.equals(clazz)){
						byte byteValue = ((Number)obj).byteValue();
						 t = (T)Byte.valueOf(byteValue);
					}
				} else {
					t = (T)obj;
				}
			}
			resultList.add(t);
		}
		return resultList;
		
	}
	
	/**
	 * 将数组转换为列表
	 * @param <T>
	 * @param array
	 * @param clazz
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static <T> List<T> typedArray(Object array, Class<T> clazz){
		
		if(array == null){
			return null;
		}
		
		List<T> list = new ArrayList<T>();
		
		for(int i = 0; i < Array.getLength(array); i++){
			Object item = Array.get(array, i);
			T t = (T)ConvertUtils.convert(item, clazz);
			if(t != null){
				list.add(t);
			}
		}
		
		return list;
		
	}
	
	
	
	/**
	 * 从实体列表抽取出id列表
	 * @param <PK>
	 * @param entityList
	 * @return
	 */
	public static <PK extends Comparable<PK> & Serializable, T extends BaseModel<PK>> List<PK> extractIdList(List<T> entityList) {
		if(entityList != null && !entityList.isEmpty()){
			List<PK> pkList = new ArrayList<PK>(entityList.size());
			for(BaseModel<PK> model : entityList){
				if(model != null && model.getId() != null){
					pkList.add(model.getId());
				}
			}
			return pkList;
		}
		return null;
	}
	
	/**
	 * 将 形如 1_-1_(3*n)| 的字符串中(3*n)计算后并得到结果 1_-1_3|(假如n=1)
	 * @param delimiterString 1_-1_(3*n)|格式字符串
	 * @param paramMap 公式中的参数
	 * @return 结果字符串
	 */
	public static String  replaceDelimiterFormula(String delimiterString, Map<String, Object> paramMap){
		return replaceDelimiterFormula(delimiterString, "|", "_", paramMap);
	}
	
	/**
	 * 假如 delimiterString 是  1_2|3_(n1) 则 delimieter1为 | ,delimieter2为  _ , map里面放一个 {n1 : 3} 最后的结果就是  1_2|3_3
	 * @param delimiterString
	 * @param delimieter1 一级分隔符
	 * @param delimieter2 二级分隔符
	 * @param paramMap 
	 * @return
	 */
	public static String  replaceDelimiterFormula(String delimiterString, String delimiter1, String delimiter2, Map<String, Object> paramMap){
		if(StringUtils.isNotBlank(delimiterString)){
			//计算公式并替换计算后的结果
			StringBuilder builder = new StringBuilder();
			StringTokenizer stringTokenizer = new StringTokenizer(delimiterString, delimiter1);
			while(stringTokenizer.hasMoreTokens()){
				String token = stringTokenizer.nextToken();
				if(StringUtils.isNotBlank(token)){
					StringTokenizer tokenizer = new StringTokenizer(token, delimiter2);
					while(tokenizer.hasMoreTokens()){
						String subToken = tokenizer.nextToken();
						builder.append(relaceFormula(subToken, paramMap)).append(delimiter2);
					}
					if(builder.length() > 0){
						builder.deleteCharAt(builder.length() - 1);
						builder.append(delimiter1);
					}
				}
			}
			
			return builder.toString();
		}
		return delimiterString;
	}
	
	
	/**
	 * (3*n)计算后并得到结果 3 (假如n=1)
	 * @param stringToken
	 * @param paramMap
	 * @return
	 */
	public static String relaceFormula(String stringToken, Map<String, Object> paramMap){
		if(StringUtils.isBlank(stringToken)){
			return stringToken;
		}
		if(stringToken.matches("^\\(.+\\)$")){//公式需要计算
			Number value = (Number)RhinoHelper.invoke(stringToken, paramMap);
			return String.valueOf(value).replaceAll("\\.0*0$", "");//去掉没用的尾0
		} else if(stringToken.matches("^\\[.+(\\,.+)*\\]$")){//[1,2,3] n个中选一个
			stringToken = stringToken.replaceAll("\\[|\\]", "");//去掉[]
			String[] strs = stringToken.split(",");
			return strs[Tools.getRandomInteger(strs.length)];
			
		} else if(stringToken.matches("^[a-zA-Z]\\d*")){// 像X1,X2或 N1 这样的 需要替换   1_X1| -> 1_3| X1的值存在paramMap中
			return String.valueOf(paramMap.get(stringToken)).replaceAll("\\.0*0$", "");
		}
		return stringToken;
	}
	
	
	static Logger logger = LoggerFactory.getLogger(Tools.class);
	public static void main(String[] args) throws Exception {
		System.out.println(involveToken("1,2,3", ",", 1));
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("n1", 3);
		System.out.println(replaceDelimiterFormula("1_2_3|2_(n1*4)", "|", "_", map));
		
		Object[] a = new Object[]{1,2,3};
		
		List<Integer> list = typedArray(a, Integer.class);
		System.out.println(list);
		
		
	}

}
