package com.xx.common.socket.constant;


/**
 * 服务器配置信息常量
 * 
 * @author bingshan
 */
public interface ServerConfigConstant {
	
	/**
	 * 端口号
	 */
	final String SERVER_PORT = "server.socket.port";
	
	/**
	 * session读缓存大小
	 */
	final String SESSION_READ_BUFF = "server.socket.buffer.read";
	
	/**
	 * session写缓存大小
	 */
	final String SESSION_SEND_BUFF = "server.socket.buffer.write";
	
	/**
	 * session IdleTime
	 */
	final String SESSION_IDLE_TIME = "server.socket.idle.time";
	
	/**
	 * 最小线程数
	 */
	final String POOL_CORE_SIZE = "server.socket.pool.min";
	
	/**
	 * 最大线程数
	 */
	final String POOL_MAX_SIZE = "server.socket.pool.max";
	
	/**
	 * KeepAliveTime
	 */
	final String POOL_KEEP_ALIVE_TIME = "server.socket.pool.alive.time";

}
