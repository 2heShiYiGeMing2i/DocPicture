package com.xx.common.basedb.version;

import java.util.Date;


/**
 * 基础数据区分版本接口
 * 
 * @author bingshan
 */
public interface VersionBean {
	
	/**
	 * 基础数据是否生效
	 * @param versionTime 版本时间
	 * @return boolean
	 */
	boolean isBasicDataActived(Date versionTime);

}
