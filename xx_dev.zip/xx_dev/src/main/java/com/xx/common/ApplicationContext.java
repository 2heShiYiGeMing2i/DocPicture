package com.xx.common;


import java.lang.reflect.Field;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.util.ReflectionUtils;
import org.springframework.util.ReflectionUtils.FieldCallback;

public class ApplicationContext {
	private final Logger log = LoggerFactory.getLogger(getClass());

	private org.springframework.context.ApplicationContext springContext;

	public org.springframework.context.ApplicationContext getSpringContext() {
		if (springContext != null) {
			return springContext;
		}
		throw new RuntimeException("ServerContext did not initialized!!");
	}

	public void initialize() {
		springContext = new ClassPathXmlApplicationContext(
				new String[] { "applicationContext*.xml"});
		
	}

	public Object getBean(String name) {
		return getSpringContext().getBean(name);
	}

	public <T> T getBean(Class<T> beanClazz) {
		String[] names = getSpringContext().getBeanNamesForType(beanClazz);
		if (names != null && names.length > 0) {
			if (names.length == 1) {
				@SuppressWarnings("unchecked")
				T bean = (T) getBean(names[0]);
				return bean;
			} else {
				log.error("interface class[{}] too many implements bound !!",
						beanClazz);
			}
		} else {
			log.error("bean or interface class[{}] NOT bound !!", beanClazz);
		}
		return null;
	}
	
	/**
	 * 往容器中添加一个不存在的bean
	 * @param bean
	 */
	public void addSingletonBean(final Object bean){
		AbstractApplicationContext abstractContext = (AbstractApplicationContext)springContext;
		ConfigurableListableBeanFactory beanFactory = abstractContext.getBeanFactory();
		
		String beanName = getBeanName(bean);
		beanFactory.registerSingleton(beanName, bean);
		beanFactory.autowireBean(bean);
		
		String[] allBeanNames = beanFactory.getBeanDefinitionNames();
		if(allBeanNames != null && allBeanNames.length > 0){
			for(String inspectBeanName : allBeanNames){
				final Object beanInContext = beanFactory.getBean(inspectBeanName);
				if(beanInContext != null){
					ReflectionUtils.doWithFields(beanInContext.getClass(), new FieldCallback() {
						
						@Override
						public void doWith(Field field) throws IllegalArgumentException,
								IllegalAccessException {
							field.setAccessible(true);
							if(field.getType() != Object.class && field.getType().isAssignableFrom(bean.getClass())){
								if(field.getAnnotation(Autowired.class) != null && field.get(beanInContext) == null){
									field.set(beanInContext, bean);
								}
							}
						}
					});
				}
			}
		}
	}
	private String getBeanName(Object bean){
		String className = bean.getClass().getSimpleName();
		String firstChar = className.substring(0, 1);
		firstChar = firstChar.toLowerCase();
		String beanName = firstChar + className.substring(1);
		return beanName;
	}
}
