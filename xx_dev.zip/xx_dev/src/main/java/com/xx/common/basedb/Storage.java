package com.xx.common.basedb;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.helpers.FormattingTuple;
import org.slf4j.helpers.MessageFormatter;
import org.springframework.context.ApplicationContext;

import com.xx.common.basedb.BasedbServiceBean.KeyBuilder;
import com.xx.common.basedb.IndexBuilder.IndexVisitor;
import com.xx.common.basedb.version.VersionBean;


/**
 * 存储空间对象
 * @author fansth
 */
public class Storage<V> {
	
	private static final Logger logger = LoggerFactory.getLogger(Storage.class);
	
	/** 静态资源类 */
	private Class<V> clz;
	/** 静态资源路径 */
	private String location;
	/** 资源读取器 */
	private ResourceReader reader;
	/** 标识获取器 */
	private Getter identifier;
	/** 索引获取器集合 */
	private Map<String, IndexVisitor> indexVisitors;
	/** minmax获取器集合 */
	private Map<String, Getter> minmaxGetters;
	/** 主存储空间 */
	private Map<Object, V> dataTable = new ConcurrentHashMap<Object, V>();
	/** 索引存储空间 */
	private Map<String, Object> indexTable = new ConcurrentHashMap<String, Object>();
	/** 字段最大最小存储空间  */
	private Map<String, Number[]> minmaxTable = new ConcurrentHashMap<String, Number[]>();
	/**排好序的id列表*/
	private List<Object> idList = new CopyOnWriteArrayList<Object>();
	/** 数据文件地址 */
	private String resourceLocation = "xml_db" + File.separator;
	
	private ApplicationContext applicationContext;
	public Storage(Class<V> clazz, String resourceLocation, ApplicationContext applicationContext){
		this.applicationContext = applicationContext;
		this.resourceLocation = resourceLocation;
		this.clz = clazz;
		this.initialize(clazz);
	}
	
	/**
	 * 初始化并加载基础
	 * @param clazz 实体类对象
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private void initialize(Class clazz) {
		com.xx.common.basedb.anno.Resource resource = (com.xx.common.basedb.anno.Resource)clazz.getAnnotation(com.xx.common.basedb.anno.Resource.class);

		// 获取资源信息
		this.clz = clazz;
		this.location = resourceLocation + clazz.getSimpleName() + "." + resource.suffix();
		
		ResourceReader reader = this.applicationContext.getBean(resource.type() + "Reader", ResourceReader.class);
		this.reader = reader;
		
		this.identifier = GetterBuilder.createIdGetter(clz);
		this.indexVisitors = IndexBuilder.createIndexVisitors(clz);
		this.minmaxGetters = GetterBuilder.createMinMaxGetter(clz);
	}
	

	
	
	public Map<Object, V> getDataTable() {
		return dataTable;
	}

	public Map<String, Object> getIndexTable() {
		return indexTable;
	}

	/**
	 * 根据索引获取列表
	 * @param indexName 索引名
	 * @param indexValues 索引值
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public List<V> getIndex(String indexName, Object... indexValues) {
		String indexkey = this.getIndexKey(indexName, indexValues);
		List idList = (List)indexTable.get(indexkey);
		return this.list(idList);
	}
	
	public V get(Object key){
		return this.dataTable.get(key);
	}
	
	/**
	 * 获取最小最大值
	 * @param name
	 * @return
	 */
	public Number[] getMinMax(String name){
		return this.minmaxTable.get(name);
	}
	
	@SuppressWarnings("rawtypes")
	private List<V> list(List idList){
		if(idList != null && !idList.isEmpty()){
			List<V> resultList = new ArrayList<V>(idList.size());
			for(Object id : idList){
				V entity = this.get(id);
				if(entity != null){
					resultList.add(entity);
				}
			}
			return resultList;
		}
		return null;
	}
	
	
	public List<V> listAll(){
		return this.list(idList);
	}
	
	public List<Object> listId(){
		return new ArrayList<Object>(idList);
	}
	
	
	/**
	 * 重新加载静态资源
	 * @param versionTime 版本时间
	 */
	public synchronized void reload(Date versionTime) {
		try {
			URL resource = this.getClass().getClassLoader().getResource(location);
			
			if(resource == null){
				FormattingTuple message = MessageFormatter.format("基础数据[{}]所对应的资源文件[{}]不存在!", clz.getName(), location);
				logger.error(message.getMessage());
				return;
			}
			
			InputStream input = resource.openStream();
			Iterator<V> it = reader.read(input, clz);
			
			final Map<Object, V> dataTable_copy = new ConcurrentHashMap<Object, V>();
			final Map<String, Object> indexTable_copy = new ConcurrentHashMap<String, Object>();
			final Map<String, Number[]> minmaxTable_copy = new ConcurrentHashMap<String, Number[]>();
			final List<Object> idList_copy = new ArrayList<Object>();
			
			while (it.hasNext()) {
				V obj = it.next();
				
				if (obj instanceof VersionBean) {
					//不生效
					if (!((VersionBean) obj).isBasicDataActived(versionTime)) {
						continue;
					}
				}
				
				if(obj instanceof InitializeBean){
					try {
						((InitializeBean) obj).afterPropertiesSet(); 
					} catch (Exception e) {
						FormattingTuple message = MessageFormatter.format("基础数据[{}] 属性设置后处理出错!", clz.getName());
						logger.error(message.getMessage() , e);
					}
				}
				
				this.offer(obj, dataTable_copy);
				this.index(obj, indexTable_copy);
				this.minmax(obj, minmaxTable_copy);
				idList_copy.add(this.identifier.getValue(obj));
			}
			
			this.sort(idList_copy, indexTable_copy, dataTable_copy);
			
			this.idList.clear();
			this.indexTable.clear();
			this.dataTable.clear();
			this.minmaxTable.clear();
			
			this.dataTable.putAll(dataTable_copy);
			this.indexTable.putAll(indexTable_copy);
			this.minmaxTable.putAll(minmaxTable_copy);
			this.idList.addAll(idList_copy);
			
			logger.error("完成加载  {} 基础数据...", this.clz.getName());
			
		} catch (IOException e) {
			FormattingTuple message = MessageFormatter.format("基础数据[{}]所对应的资源文件[{}]不存在!", clz.getName(), location);
			logger.error(message.getMessage());
		} 
	}

	
	//构建索引键
	private String getIndexKey(String name, Object... value){
		return KeyBuilder.buildIndexKey(clz, name, value);
	}
	
	//加入主存储
	private V offer(V value, Map<Object, V> dataTable) {
		Object key =  identifier.getValue(value);
		if(dataTable.containsKey(key)){
			logger.error("基础数据 [{}] 存在重复的 主键 [{}]!", value.getClass().getName(), key);
		}
		V result = dataTable.put(key, value);
		return result;
	}
	
	// 索引处理
	private void index(V value, Map<String, Object> indexTable){
		for (IndexVisitor indexVisitor : indexVisitors.values()) {
			if(indexVisitor.indexable(value)){
				String indexKey = indexVisitor.getIndexKey(value);
				this.addToIndexList(indexKey, value, indexTable);
			}
		}
	}
	
	//最大最小处理
	private void minmax(V value, Map<String, Number[]> minMaxTable){
		for(Entry<String, Getter> entry : minmaxGetters.entrySet()){
			Number fieldValue = (Number)entry.getValue().getValue(value);
			if(fieldValue != null){
				Number[] minmaxValue = minMaxTable.get(entry.getKey());
				if(minmaxValue == null){
					minmaxValue = new Number[]{fieldValue, fieldValue};
					minMaxTable.put(entry.getKey(), minmaxValue);
				}
				Number minValue = minmaxValue[0];
				Number maxValue = minmaxValue[1];
				if(fieldValue.doubleValue() < minValue.doubleValue()){
					minmaxValue[0] = fieldValue;
				}
				if(fieldValue.doubleValue() > maxValue.doubleValue()){
					minmaxValue[1] = fieldValue;
				}
			}
		}
	}
	
	//排序
	private void sort(List<Object> idList, Map<String, Object> indexTable,  final Map<Object, V> dataTable){
		
		Comparator<Object> comparator = null;
		if(Comparable.class.isAssignableFrom(this.clz)){//有实现 Comparable
			comparator = new Comparator<Object>() {

				@SuppressWarnings({ "rawtypes", "unchecked" })
				@Override
				public int compare(Object o1, Object o2) {
					Comparable entity1  = (Comparable)dataTable.get(o1);
					Comparable entity2  = (Comparable)dataTable.get(o2);
					return entity1.compareTo(entity2);
				}
				
			};
		} else {//没有实现则直接按id排
			comparator = new Comparator<Object>() {

				@SuppressWarnings({ "rawtypes", "unchecked" })
				@Override
				public int compare(Object o1, Object o2) {
					if(o1 instanceof Comparable && o2 instanceof Comparable){
						Comparable co1  = (Comparable)o1;
						Comparable co2  = (Comparable)o2;
						return co1.compareTo(co2);
					}
					return -1;
				}
				
			};
		}
		
		//索引排序
		for(Object indexObj : indexTable.values()){
			if(indexObj instanceof List){
				List<?> indexedIdList = (List<?>)indexObj;
				if(indexedIdList != null && indexedIdList.size() > 1){
					Collections.sort(indexedIdList, comparator);
				}
			}
		}
		
		//id排序
		Collections.sort(idList, comparator);
	}
	
	//加入索引表
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void addToIndexList(String indexKey , V value, Map<String, Object> indexTable){
		List idList = (List)indexTable.get(indexKey);
		if(idList == null){
			idList = new ArrayList();
			indexTable.put(indexKey, idList);
		}
		Object id = this.identifier.getValue(value);
		idList.add(id);
	}


}
