/**
 * 
 */
package com.xx.common.basedb;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * 基础数据加载适配器
 * @author fansth
 *
 */
public abstract class BasedbAdapter implements BasedbListener{
	
	//索引表
	protected final Map<String, Object> indexTable = new ConcurrentHashMap<String, Object>();
	
	@Autowired
	protected BasedbService basedbService;

	@Override
	public void onBasedbReload(Class<?>... reloadedClass) {
		//reloadedClass与listenedClass有交集就视为匹配
		if(this.listenedClass() != null){
			if(CollectionUtils.containsAny(Arrays.asList(reloadedClass), Arrays.asList(this.listenedClass()))){
				this.indexTable.clear();
				this.initialize();
			}
		}
	}
	
	/**
	 * 监听这些class加载
	 * @return
	 */
	public abstract Class<?>[] listenedClass();
	
	
	
	protected <T> List<T> getFromIdList(Class<T> clazz, Collection<?> idList){
		if(idList != null && !idList.isEmpty()){
			List<T> entityList = new ArrayList<T>();
			for(Object id : idList){
				T entity = basedbService.get(clazz, id);
				if(entity != null){
					entityList.add(entity);
				}
			}
			return entityList;
		}
		return null;
	}
 	
	public abstract void initialize();

}
