/**
 * 
 */
package com.xx.common.executor;

import org.springframework.stereotype.Component;

import com.xx.common.profile.Profileable;

/**
 * jacket任务执行者
 * @author fansth
 *
 */
@Component("jacketTaskExecutor")
public class JackectTaskExecutor extends AbstractTaskExecutor implements Profileable {
	
	@Override
	public String getName() {
		return "jackect任务线程池";
	}

	@Override
	public void overrideProperties() {
	}
	
}
