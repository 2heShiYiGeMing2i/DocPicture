package com.xx.common.util;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;

/**
 * 字符串工具集合
 */
public class StringUtils {

	private static final String PASSWORD_CRYPT_KEY = "__jDlog_";
	private final static String DES = "DES";

	/**
	 * MD5 摘要计算(byte[]).
	 * 
	 * @param src
	 *            byte[]
	 * @throws Exception
	 * @return byte[] 16 bit digest
	 */
	public static byte[] md5(byte[] src) throws Exception {
		MessageDigest alg = MessageDigest.getInstance("MD5");
		return alg.digest(src);
	}

	/**
	 * MD5 摘要计算(String).
	 * 
	 * @param src
	 *            String
	 * @throws Exception
	 * @return String
	 */
	public static String md5(String src) {
		try {
			return byte2hex(md5(src.getBytes()));
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * 判断是不是一个合法的电子邮件地址
	 * 
	 * @param email
	 * @return
	 */
	public static boolean isEmail(String email) {
		if (email == null)
			return false;
		email = email.trim();
		if (email.indexOf(' ') != -1)
			return false;

		int idx = email.indexOf('@');
		if (idx == -1 || idx == 0 || (idx + 1) == email.length())
			return false;
		if (email.indexOf('@', idx + 1) != -1)
			return false;
		if (email.indexOf('.') == -1)
			return false;
		return true;

	}

	/**
	 * 加密
	 * 
	 * @param src
	 *            数据源
	 * @param key
	 *            密钥，长度必须是8的倍数
	 * @return 返回加密后的数据
	 * @throws Exception
	 */
	public static byte[] encrypt(byte[] src, byte[] key) throws Exception {
		// DES算法要求有一个可信任的随机数源
		SecureRandom sr = new SecureRandom();
		// 从原始密匙数据创建DESKeySpec对象
		DESKeySpec dks = new DESKeySpec(key);
		// 创建一个密匙工厂，然后用它把DESKeySpec转换成
		// 一个SecretKey对象
		SecretKeyFactory keyFactory = SecretKeyFactory.getInstance(DES);
		SecretKey securekey = keyFactory.generateSecret(dks);
		// Cipher对象实际完成加密操作
		Cipher cipher = Cipher.getInstance(DES);
		// 用密匙初始化Cipher对象
		cipher.init(Cipher.ENCRYPT_MODE, securekey, sr);
		// 现在，获取数据并加密
		// 正式执行加密操作
		return cipher.doFinal(src);
	}

	public static byte[] hex2byte(byte[] b) {
		if ((b.length % 2) != 0)
			throw new IllegalArgumentException("长度不是偶数");
		byte[] b2 = new byte[b.length / 2];
		for (int n = 0; n < b.length; n += 2) {
			String item = new String(b, n, 2);
			b2[n / 2] = (byte) Integer.parseInt(item, 16);
		}
		return b2;
	}

	/**
	 * 解密
	 * 
	 * @param src
	 *            数据源
	 * @param key
	 *            密钥，长度必须是8的倍数
	 * @return 返回解密后的原始数据
	 * @throws Exception
	 */
	public static byte[] decrypt(byte[] src, byte[] key) throws Exception {
		// DES算法要求有一个可信任的随机数源
		SecureRandom sr = new SecureRandom();
		// 从原始密匙数据创建一个DESKeySpec对象
		DESKeySpec dks = new DESKeySpec(key);
		// 创建一个密匙工厂，然后用它把DESKeySpec对象转换成
		// 一个SecretKey对象
		SecretKeyFactory keyFactory = SecretKeyFactory.getInstance(DES);
		SecretKey securekey = keyFactory.generateSecret(dks);
		// Cipher对象实际完成解密操作
		Cipher cipher = Cipher.getInstance(DES);
		// 用密匙初始化Cipher对象
		cipher.init(Cipher.DECRYPT_MODE, securekey, sr);
		// 现在，获取数据并解密
		// 正式执行解密操作
		return cipher.doFinal(src);
	}

	/**
	 * 密码解密
	 * 
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public final static String decryptPassword(String data) {
		if (data != null)
			try {
				return new String(decrypt(hex2byte(data.getBytes()),
						PASSWORD_CRYPT_KEY.getBytes()));
			} catch (Exception e) {
				e.printStackTrace();
			}
		return null;
	}

	/**
	 * 密码加密
	 * 
	 * @param password
	 * @return
	 * @throws Exception
	 */
	public final static String encryptPassword(String password) {
		if (password != null)
			try {
				return byte2hex(encrypt(password.getBytes(), PASSWORD_CRYPT_KEY
						.getBytes()));
			} catch (Exception e) {
				e.printStackTrace();
			}
		return null;
	}

	/**
	 * 二行制转字符串
	 * 
	 * @param b
	 * @return
	 */
	public static String byte2hex(byte[] b) {
		String hs = "";
		String stmp = "";
		for (int n = 0; b != null && n < b.length; n++) {
			stmp = (java.lang.Integer.toHexString(b[n] & 0XFF));
			if (stmp.length() == 1)
				hs = hs + "0" + stmp;
			else
				hs = hs + stmp;
		}
		return hs.toUpperCase();
	}

	/**
	 * 二行制转页面字符串
	 * 
	 * @param b
	 * @return
	 */
	public static String byte2webhex(byte[] b) {
		return byte2hex(b, "%");
	}

	/**
	 * 二行制转字符串
	 * 
	 * @param b
	 * @param elide
	 *            分隔符
	 * @return
	 */
	public static String byte2hex(byte[] b, String elide) {
		String hs = "";
		String stmp = "";
		elide = elide == null ? "" : elide;
		for (int n = 0; b != null && n < b.length; n++) {
			stmp = (java.lang.Integer.toHexString(b[n] & 0XFF));
			if (stmp.length() == 1)
				hs = hs + elide + "0" + stmp;
			else
				hs = hs + elide + stmp;
		}
		return hs.toUpperCase();
	}

	/**
	 * 用户名必须是数字或者字母的结合
	 * 
	 * @param username
	 * @return
	 */
	// public static boolean isLegalUsername(String username) {
	// for(int i=0;i<username.length();i++){
	// char ch = username.charAt(i);
	// if(!isAscii(ch)&&
	// ch != '.' &&
	// // ch != '_' &&
	// // ch != '-' &&
	// ch != '+' &&
	// ch != '(' &&
	// ch != ')' &&
	// ch != '*' &&
	// ch != '^' &&
	// ch != '@' &&
	// ch != '%' &&
	// ch != '$' &&
	// ch != '#' &&
	// ch != '~' )
	// return false;
	// }
	// return true;
	// }
	/**
	 * 处理空字符串
	 * 
	 * @param strIn
	 * @return
	 */
	public static String delNull(String strIn) {
		return strIn == null ? "" : strIn.trim();
	}

	/**
	 * 判断是否是字母和数字的结合
	 * 
	 * @param name
	 * @return
	 */
	// public static boolean isAsciiOrDigit(String name){
	// for(int i=0;i<name.length();i++){
	// char ch = name.charAt(i);
	// if(!isAscii(ch))
	// return false;
	// }
	// return true;
	// }
	// public static boolean isAscii(char ch){
	// return (ch >='a' && ch <='z') || (ch >='A' && ch <='Z') || (ch >='0' &&
	// ch <='9') || ch=='-' || ch=='_';
	// }
	//    
	/**
	 * 产生随机字数串 add at 2007.6.11
	 * 
	 * @param length
	 * @return
	 */
	public static String getRandomString(int length) {
		StringBuffer buffer = new StringBuffer(
				"0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ");
		StringBuffer sb = new StringBuffer();
		Random r = new Random();
		int range = buffer.length();
		for (int i = 0; i < length; i++) {
			sb.append(buffer.charAt(r.nextInt(range)));
		}
		return sb.toString();
	}

	/**
	 * 产生随机字数串 add at 2007.6.11
	 * 
	 * @param length
	 * @return
	 */
	public static String getRandomNumber(int length) {
		StringBuffer buffer = new StringBuffer("0123456789");
		StringBuffer sb = new StringBuffer();
		Random r = new Random();
		int range = buffer.length();
		for (int i = 0; i < length; i++) {
			sb.append(buffer.charAt(r.nextInt(range)));
		}
		return sb.toString();
	}

	/**
	 * 判断页面输入特殊字符
	 * 
	 * @param str
	 * @return
	 */
	// public static String filterSpecialChar(String str)
	// {
	// if(str==null)
	// return "";
	// String[] specialChar = {"‘", "=", "<", ">", "@", "#", "%", "^"," ",
	// "&", "!", "~"};
	// String s;
	// s = str;
	// for (int i = 0; i < specialChar.length; i++)
	// {
	// s = (s.indexOf(specialChar[i]) == -1) ? s : s.replaceAll(
	// specialChar[i], "");
	// }
	// return (s);
	//
	// }
	/**
	 * 判断页面输入全角逗号字符时替换成半角逗号
	 * 
	 * @param str
	 * @return
	 */
	public static String filterchSpecialChar(String str) {
		String[] specialChar = { "，" };
		String s;
		s = str;
		for (int i = 0; i < specialChar.length; i++) {
			s = (s.indexOf(specialChar[i]) == -1) ? s : s.replaceAll(
					specialChar[i], ",");
		}
		return (s);

	}

	/**
	 * 判断页面输入特殊字符
	 * 
	 * @param str
	 * @return
	 */
	// public static String filterSpecialCharForSearch(String str)
	// {
	// if(str==null)
	// return "";
	// char[] specialChar = {'‘','=','<','>','@','#','%','^','"',
	// '&', '!', '~' ,'-' ,'\'','*','{','}','[',']','(',')',
	// '+','\\',':'};
	// String s;
	// s = str;
	// for (int i = 0; i < specialChar.length; i++)
	// {
	// s = (s.indexOf(specialChar[i]) == -1) ? s : s.replace(specialChar[i], '
	// ');
	// }
	// return s.trim();
	//
	// }
	/**
	 * 替换
	 * 
	 * @param str
	 * @return
	 */
	// public static String filterSpecialChar(String str,String elide)
	// {
	// if(str==null)
	// return "";
	// char c_elide = elide == null || elide.length() == 0 ? ' ' :
	// elide.charAt(0);
	//		
	// char[] specialChar = {'‘','=','<','>','@','#','%','^','"',
	// '&', '!', '~' ,'-' ,'\'','*','{','}','[',']','(',')',
	// '+','\\',':'};
	// String s;
	// s = str;
	// for (int i = 0; i < specialChar.length; i++)
	// {
	// s = (s.indexOf(specialChar[i]) == -1) ? s : s.replace(specialChar[i],
	// c_elide);
	// }
	// return s.trim();
	//
	// }
	/**
	 * 处理空字符串
	 * 
	 * @param strIn
	 * @return
	 */
	public static String filterNull(String strIn) {
		return strIn == null ? "" : strIn;
	}

	/**
	 * 判断一个字符串是否是null或者空字符串或者空格
	 * 
	 * @param strIn
	 * @return
	 */
	public static boolean isEmpty(String strIn) {
		return strIn == null || "".equals(strIn.trim()) ? true : false;
	}

	public static String getMD5(byte[] source) {
		String s = null;
		char hexDigits[] = { // 用来将字节转换成 16 进制表示的字符
		'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd',
				'e', 'f' };
		try {
			java.security.MessageDigest md = java.security.MessageDigest.getInstance("MD5");
			md.update(source);
			byte tmp[] = md.digest(); // MD5 的计算结果是一个 128 位的长整数，用字节表示就是 16 个字节
			char str[] = new char[16 * 2]; // 每个字节用 16 进制表示的话，使用两个字符，所以表示成 16 进制需要 32 个字符
			int k = 0; // 表示转换结果中对应的字符位置
			for (int i = 0; i < 16; i++) { // 从第一个字节开始，对 MD5 的每一个字节转换成 16 进制字符的转换
				byte byte0 = tmp[i]; // 取第 i 个字节
				str[k++] = hexDigits[byte0 >>> 4 & 0xf]; 
				str[k++] = hexDigits[byte0 & 0xf]; // 取字节中低 4 位的数字转换
			}
			s = new String(str); // 换后的结果转换为字符串

		} catch (Exception e) {
			e.printStackTrace();
		}
		return s;
	}
	
	
	
	
	
	/**
	 * 将数组各项用指定的分隔符连起来 
	 * @param arr 数组
	 * @param delim 分隔服
	 * @return ["1", "2", "3"] --> 1_2_3
	 */
	public static String arrayToDelimitedString(Object[] arr, String delim){
		return org.springframework.util.StringUtils.arrayToDelimitedString(arr, delim);
	}
	
	
	
	/**
	 * 生成N个序列号
	 * @param n  序列号数量
	 * @param length  序列号长度
	 * @return
	 */
	public static List<String> createSequence(int length, int count, boolean upperCase) {
		if (count <= 0){
			return null;
		}
		String[] source = upperCase ? UPPERCASE : LOWERCASE;
		
		List<String> result = new ArrayList<String>(count);
		Random random = new Random(System.currentTimeMillis());
		
		
		for (int i = 0; i < count; i++) {
			StringBuffer sb = new StringBuffer();
			for (int j = 0; j < length; j++) {
				int index = random.nextInt(source.length);
				sb.append(source[index]);
			}
			result.add(sb.toString());
		}
		return result;
	}

	/**
	 * 生成唯一的序列号
	 * @param length 序列号长度
	 * @return
	 */
	public static String createSequence(int length, boolean upperCase) {
		String[] source = upperCase ? UPPERCASE : LOWERCASE;
		Random random = new Random(System.currentTimeMillis());
		StringBuffer sb = new StringBuffer();
		for (int j = 0; j < length; j++) {
			int index = random.nextInt(source.length);
			sb.append(source[index]);
		}
		return sb.toString();
	}

	
	/**
	 * 按中文2字节英文1字节计算字符串占用的字节数
	 * @param str
	 * @return
	 */
	public static int getByteLen(String str) {
		if(str == null){
			return 0;
		}
		try {
			return str.getBytes("GBK").length;
		} catch (UnsupportedEncodingException e) {
			return str.length();
		}
	}
	
	/**
	 * 随机数据来源
	 */
	private final static String[] UPPERCASE = { "1", "2", "3", "4", "5", "6",
			"7", "8", "9", "0", "Q", "W", "E", "R", "T", "Y", "U", "I", "O",
			"P", "A", "S", "D", "F", "G", "H", "J", "K", "L", "Z", "X", "C",
			"V", "B", "N", "M" };
	
	/**
	 * 随机数据来源
	 */
	private final static String[] LOWERCASE = { "1", "2", "3", "4", "5", "6",
		"7", "8", "9", "0", "q", "w", "e", "r", "t", "y", "u", "i", "o",
		"p", "a", "s", "d", "f", "g", "h", "j", "k", "l", "z", "x", "c",
		"v", "b", "n", "m" };

	
	public static void main(String[] args) throws Exception {
		List<String> list =createSequence(40000, 10, true);
		OutputStream os = new FileOutputStream("D:/1.txt");
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(os));
		for(String str:list){
			bw.write(str);
			bw.newLine();
		}
		os.close();

		System.out.println("over");
	}

}
