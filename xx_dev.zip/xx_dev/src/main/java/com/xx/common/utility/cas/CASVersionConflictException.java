/**
 * 
 */
package com.xx.common.utility.cas;

/**
 * @author fansth
 *
 */
public class CASVersionConflictException extends RuntimeException {

	private static final long serialVersionUID = -1150025536098946836L;

	public CASVersionConflictException(String message, Throwable e){
		super(message, e);
	}
	
	public CASVersionConflictException(String message){
		super(message);
	}
	
	public CASVersionConflictException(){
		
	}
}
