package com.xx.common.utility.collection;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantReadWriteLock;


/**
 * 线程安全的列表
 * @author fansth
 * @param <E>
 */
public class ConcurrentArrayList<E> {

	/**内置列表*/
	private List<E> list;
	
	/**锁对象*/
	private final ReentrantReadWriteLock lock = new ReentrantReadWriteLock();
	/**读锁对象*/
	private final Lock readLock = lock.readLock();
	/**写锁对象*/
	private final Lock writeLock = lock.writeLock();
	
	public ConcurrentArrayList() {
		this.list = new ArrayList<E>();
	}
	
	public ConcurrentArrayList(int initialCapacity) {
		this.list = new ArrayList<E>(initialCapacity);
	}
	
	public ConcurrentArrayList(Collection<E> list) {
		if(list != null){
			List<E> copyOfList = new ArrayList<E>(list);
			this.list = copyOfList;
		} else {
			this.list = new ArrayList<E>();
		}
	}
	
	/**
	 * 清空列表
	 */
	public void clear(){
		this.writeLock.lock();
		try {
			this.list.clear();
		} finally {
			this.writeLock.unlock();
		}
	}
	
	/**
	 * 判断列表是否为空
	 * @return
	 */
	public boolean isEmpty(){
		this.readLock.lock();
		try {
			return this.list.isEmpty();
		} finally {
			this.readLock.unlock();
		}
	}
	
	/**
	 * 将集合添加到列表
	 * @param colletion
	 * @return
	 */
	public boolean addAll(Collection<E> colletion){
		this.writeLock.lock();
		try {
			return this.list.addAll(colletion);
		} finally {
			this.writeLock.unlock();
		}
	}
	
	/**
	 * 将集合添加到列表(不在列表中的元素才添加)
	 * @param colletion
	 * @return
	 */
	public void addAllIfAbsent(Collection<E> colletion){
		this.writeLock.lock();
		try {
			if(colletion != null){
				for(E e : colletion){
					if(!this.list.contains(e)){
						this.list.add(e);
					}
				}
			}
		} finally {
			this.writeLock.unlock();
		}
	}
	
	/**
	 * 将元素添加到列表
	 * @param e
	 * @return
	 */
	public boolean add(E e){
		this.writeLock.lock();
		try {
			return this.list.add(e);
		} finally {
			this.writeLock.unlock();
		}
	}
	
	/**
	 * 将元素添加到列表头部
	 * @param e
	 * @return
	 */
	public void addFirst(E e){
		this.writeLock.lock();
		try {
			this.list.add(0, e);
		} finally {
			this.writeLock.unlock();
		}
	}
	
	
	/**
	 * 获取头部元素
	 * @return
	 */
	public E getFirst(){
		this.readLock.lock();
		try {
			if(this.list.size() > 0){
				return this.list.get(0);
			}
			return null;
		} finally {
			this.readLock.unlock();
		}
	}
	
	/**
	 * 获取最后一个元素
	 * @return
	 */
	public E getLast(){
		this.readLock.lock();
		try {
			if(this.list.size() > 0){
				return this.list.get(this.list.size() - 1);
			}
			return null;
		} finally {
			this.readLock.unlock();
		}
	}
	
	
	/**
	 * 移除头部元素
	 * @return
	 */
	public E removeFirst(){
		this.writeLock.lock();
		try {
			if(this.list.size() > 0){
				return this.list.remove(0);
			}
			return null;
		} finally {
			this.writeLock.unlock();
		}
	}
	
	/**
	 * 移除尾部元素
	 * @return
	 */
	public E removeLast(){
		this.writeLock.lock();
		try {
			if(this.list.size() > 0){
				return this.list.remove(this.list.size() - 1);
			}
			return null;
		} finally {
			this.writeLock.unlock();
		}
	}
	
	
	
	/**
	 * 获取列表大小
	 * @return
	 */
	public int size(){
		this.readLock.lock();
		try {
			return this.list.size();
		} finally {
			this.readLock.unlock();
		}
	}
	
	/**
	 * 移除元素
	 * @param e
	 * @return true-移除成功  false-移除失败
	 */
	public boolean remove(E e){
		this.writeLock.lock();
		try {
			return this.list.remove(e);
		} finally {
			this.writeLock.unlock();
		}
	}
	
	/**
	 * 判断列表是否包含指定元素
	 * @param e
	 * @return
	 */
	public boolean contains(E e){
		this.readLock.lock();
		try {
			return this.list.contains(e);
		} finally {
			this.readLock.unlock();
		}
	}
	
	/**
	 * 如果列表没有指定的元素就添加
	 * @param e
	 * @return
	 */
	public boolean addIfAbsent(E e){
		this.writeLock.lock();
		try {
			if(this.list.contains(e)){
				return false;
			}
			return this.list.add(e);
		} finally {
			this.writeLock.unlock();
		}
	}
	
	/**
	 * 替换指定的元素
	 * @param expectElement 需要替换掉的元素
	 * @param replacement    用这个元素去替换
	 * @param addIfNotExists true-没有就添加  false-没有也不添加
	 * @return true-以替换方式替换元素  false-没有发生替换
	 */
	public boolean replace(E expectElement, E replacement, boolean addIfNotExists){
		this.writeLock.lock();
		try {
			int index = this.list.indexOf(expectElement);
			if(index >= 0){
				this.list.set(index, replacement);
				return true;
			} else if(addIfNotExists){//不存在就添加
				this.list.add(replacement);
			}
			return false;
		} finally {
			this.writeLock.unlock();
		}
	}
	
	
	/**
	 * 替换列表(直接将replacement替换内置的列表)
	 * @param replacement 
	 */
	public void replaceList(List<E> replacement){
		this.writeLock.lock();
		try {
			this.list.clear();
			if(replacement != null){
				this.list.addAll(replacement);
			}
		} finally {
			this.writeLock.unlock();
		}
	}
	
	/**
	 * 特许读访问(可在此遍历访问)
	 * @param accessor 特权访问者
	 */
	public Object privilegedRead(PrivilegedAccessor<E> accessor){
		this.readLock.lock();
		try {
			return accessor.doPrivileged(this.list);
		} finally {
			this.readLock.unlock();
		}
	}
	
	/**
	 * 特许写访问
	 * @param accessor 特权访问者
	 */
	public Object privilegedWrite(PrivilegedAccessor<E> accessor){
		this.writeLock.lock();
		try {
			return accessor.doPrivileged(this.list);//很不想暴露list但又想提供比CopyOnWriteArrayList更好的实现所以也不想copy一份list作为入参,想引入真实的权限访问机制因开销同样较大也放弃了.new PrivilegedAccessor 对象实际开销很小因他没有属性域
		} finally {
			this.writeLock.unlock();
		}
	}
	
	/**
	 * 获取列表的副本
	 * @return
	 */
	public List<E> toList(){
		this.readLock.lock();
		try {
			return new ArrayList<E>(this.list);
		} finally {
			this.readLock.unlock();
		}
	}
	
	//特权访问者接口
	public static interface PrivilegedAccessor<E>{
		/**
		 * 实施特权方法
		 * @param innerList 内置的列表(不是拷贝)
		 */
		Object doPrivileged(List<E> innerList);
	}
	
}
