/**
 * 
 */
package com.xx.common.utility.throttle;

/**
 * 节流阀接口
 * @author fansth
 *
 */
public interface Throttle {

	/**
	 * 流过一次
	 * @param weight 流过的权重值
	 * @return true-正常流过 false-异常流过请进黑屋子
	 */
	FlowLicense flow(double weight);
	
}
