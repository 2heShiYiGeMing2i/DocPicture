package com.xx.common.db.cache;

/**
 * 实体对象入库前后的回调
 */
public interface DbCallback {
	
	/**
	 * 入库前回调
	 */
	void doBefore();
	
	/**
	 * 入库后回调
	 */
	void doAfter();
	
	
}
