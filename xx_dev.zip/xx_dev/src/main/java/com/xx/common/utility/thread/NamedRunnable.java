/**
 * 
 */
package com.xx.common.utility.thread;

/**
 * 可命名的runnable
 * @author fansth
 *
 */
public interface NamedRunnable extends Runnable{

	/**
	 * 执行的名称
	 * @return
	 */
	String getName();
	
}
