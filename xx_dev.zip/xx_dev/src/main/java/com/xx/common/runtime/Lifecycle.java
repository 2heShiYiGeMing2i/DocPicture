/**
 * 
 */
package com.xx.common.runtime;

/**
 * 服务器生命周期定义
 * @author fansth
 *
 */
public enum Lifecycle {
	
	/**
	 * 读取配置文件配置信息
	 */
	CONFIGURATION,
	
	/**
	 * 加载基础数据表阶段(加载初始化基础数据服务)
	 */
	BASE_DB_LOAD,
	
	/**
	 * 容器构建阶段(构建基础服务对象,如dbcache,事件等这个阶段完成后所有的基础设施构建完毕)
	 */
	CONTEXT_CONSTRUCT,
	
	/**
	 * 容器初始化(容器级别的一些处理,如扫描定时器自动提交)
	 */
	CONTEXT_INITIALIZE,
	
	/**
	 * 开关配置初始化
	 */
	OPEN_CONTROL_INITIALIZE,
	
	/**
	 * 版本定制
	 */
	VERSION_CUSTOM,
	
	/**
	 * 补丁加载
	 */
	PATCH_INSTALL,
	
	/**
	 * 业务起服处理阶段(业务在起服时需要做的一些处理, 如工会战、竞技场的初始化工作)
	 */
	BUSSINESS_INITIALIZE,
	
	/**
	 * 业务起服处理阶段2
	 */
	BUSSINESS_INITIALIZE_2,
	
	/**
	 * 启动socket服务器
	 */
	START_SOCKET_SERVER,
	
	/**
	 * 关闭socket服务器(停止接收请求，停止建立连接，但是确保现有的请求处理完毕)
	 */
	STOP_SOCKET_SERVER,
	
	/**
	 * 业务关服前处理阶段(业务在关服前需要做的一些处理)
	 */
	BUSSINESS_ON_CLOSING,
	
	/**
	 * 容器关闭阶段(基础服务对象的善后处理,如线程池关闭)
	 */
	CONTEXT_CLOSEING,
	
	/**
	 * 销毁socket服务器
	 */
	DISPOSE_SOCKET_SERVER;
	
}
