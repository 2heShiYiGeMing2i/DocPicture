/**
 * @file:String2PropertiesUserType.java
 * @author:David
 **/
package com.xx.common.db.model.usertype;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Properties;
import java.util.Map.Entry;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Hibernate;
import org.hibernate.HibernateException;

/**
 * @class:String2PropertiesUserType
 * @description:
 * @author:David
 * @version:v1.0
 * @date:2012-10-11
 **/
public class String2PropertiesUserType extends ObjectUserType<Properties> {


	@Override
	public boolean equals(Object x, Object y) throws HibernateException {
		try {
			Properties pro1 = (Properties) x;
			Properties pro2 = (Properties) y;
			if (pro1 == null && pro2 == null)
				return true;
			if (pro1 == null && pro2 != null)
				return false;
			if (pro1 != null && pro2 == null)
				return false;

			if (pro1.size() != pro2.size()) {
				return false;
			}
			Iterator<Entry<Object, Object>> i = pro1.entrySet().iterator();
			while (i.hasNext()) {
				Entry<Object, Object> e = i.next();
				Object key = e.getKey();
				Object value = e.getValue();
				if (value == null) {
					if (!(pro2.get(key) == null && pro2.containsKey(key))) {
						return false;
					}
				} else {
					if (!value.equals(pro2.get(key))) {
						return false;
					}
				}
			}
		} catch (Exception e) {
			return false;
		}

		return true;
	}

	@Override
	public Object deepCopy(Object value) throws HibernateException {
		if (value == null) {
			return null;
		}
		Properties pro = (Properties) value;
		return pro.clone();
	}

	@Override
	public Properties nullSafeGet(final ResultSet rs, final String[] names, final Object owner)
			throws HibernateException, SQLException {
		String attributes = (String) Hibernate.STRING.get(rs, names[0]);
		if (StringUtils.isEmpty(attributes)) {
			return null;
		} else {
			Properties attributeProperties = new Properties();
			String[] splitAttribute = attributes.split("\\|");
			for (String a : splitAttribute) {
				if (a != null) {
					String[] kv = a.split("=");
					if (kv.length == 2) {
						attributeProperties.setProperty(kv[0], kv[1]);
					}
				}
			}
			return attributeProperties;
		}

	}

	@Override
	public void nullSafeSet(final PreparedStatement st, final Object value, final int index) throws HibernateException,
			SQLException {
		if (value == null) {
			Hibernate.STRING.set(st, "", index);
		} else {
			Properties attributes = (Properties) value;
			StringBuilder builder = new StringBuilder();
			for (Entry<Object, Object> entry : attributes.entrySet()) {
				builder.append(entry.getKey() + "=" + entry.getValue() + "|");
			}
			Hibernate.STRING.set(st, builder.toString(), index);
		}
	}

	@Override
	public Class<?> returnedClass() {
		return Properties.class;
	}
}

