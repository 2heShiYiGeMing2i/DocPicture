/**
 * 
 */
package com.xx.common.profile;

/**
 * 性能分析标的接口
 * @author fansth
 *
 */
public interface Profileable {

	/**
	 * 输出性能情况
	 */
	void profile();
	
}
