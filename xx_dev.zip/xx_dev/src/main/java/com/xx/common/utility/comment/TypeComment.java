/**
 * 
 */
package com.xx.common.utility.comment;

/**
 * 一个对类型的注释性描述
 * TypeComment<T> 中 T 类型即需要描述的类型
 * @author fansth
 *
 */
public class TypeComment<T> {
	
	private T value;
	

	public TypeComment(String comment, Object...others){
		
	}
	
	public TypeComment(T value, String comment, Object...others){
		this.value = value;
	}

	public T getValue() {
		return value;
	}

	public void setValue(T value) {
		this.value = value;
	}
	
	
}
