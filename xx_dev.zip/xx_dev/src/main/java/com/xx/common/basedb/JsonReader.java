package com.xx.common.basedb;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.codehaus.jackson.map.DeserializationConfig;
import org.codehaus.jackson.map.DeserializationConfig.Feature;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.type.TypeFactory;
import org.codehaus.jackson.type.JavaType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * JSON 资源读取器
 * @author frank
 */
@Component("jsonReader")
public class JsonReader implements ResourceReader {
	
	private final static Logger logger = LoggerFactory.getLogger(ExcelReader.class);
	
	private static final ObjectMapper mapper = new ObjectMapper();
	
	private static final TypeFactory typeFactory = TypeFactory.defaultInstance();

	@SuppressWarnings("deprecation")
	public <E> Iterator<E> read(InputStream input, Class<E> clz) {
		try {
			JavaType type = typeFactory.constructCollectionType(ArrayList.class, clz);
			// JavaType type = TypeFactory.collectionType(ArrayList.class, clz);
//			List<E> list = mapper.readValue(input, type);
			
			DeserializationConfig config = mapper.getDeserializationConfig();
			config.set(Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
//			DeserializationConfig newConfig = config.without(Feature.FAIL_ON_UNKNOWN_PROPERTIES);
//			mapper.setDeserializationConfig(newConfig);
			
			List<E> list = mapper.readValue(input, type);
			return list.iterator();
		} catch (Exception e) {
			logger.error("JsonReader读取基础数据文件异常!", e);
			throw new RuntimeException(e);
		}
	}

	@Override
	public String getFormat() {
		return "json";
	}

}
