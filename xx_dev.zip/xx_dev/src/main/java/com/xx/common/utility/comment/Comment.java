/**
 * 
 */
package com.xx.common.utility.comment;

/**
 * 一个注释性描述对象
 * @author fansth
 *
 */
public class Comment {

	public Comment(String comment, Object...others){
		
	}
	
	
}
