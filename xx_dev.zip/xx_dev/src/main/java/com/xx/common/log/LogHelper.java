package com.xx.common.log;

import java.util.Date;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.time.DateFormatUtils;
import org.apache.commons.lang.time.DateUtils;
import org.apache.mina.core.session.IoSession;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.xx.common.basedb.BasedbService;
import com.xx.common.db.cache.DbCachedService;
import com.xx.common.db.service.CommonManager;
import com.xx.common.scheduling.Scheduled;
import com.xx.common.scheduling.ValueType;
import com.xx.common.util.JsonUtils;
import com.xx.common.util.Splitable;
import com.xx.common.utility.thread.NamedThreadFactory;
import com.xx.dev.constant.IntBoolean;
import com.xx.dev.constant.RewardType;
import com.xx.dev.modules.equip.entity.PlayerEquip;
import com.xx.dev.modules.heroequip.entity.PlayerHeroEquip;
import com.xx.dev.modules.heroequip.service.impl.HeroEquipServiceImpl;
import com.xx.dev.modules.mis.entity.ConsumeRecord;
import com.xx.dev.modules.player.entity.Player;
import com.xx.dev.modules.reward.result.ValueResultSet;

/**
 * 日志帮助类
 * 
 * @author Along
 *
 */
@Service
public class LogHelper {

	private Logger logger = LoggerFactory.getLogger(this.getClass());
	
	/**
	 * 分隔符
	 */
	final char BETWEEN_ITEMS = '|';
	
	/**
	 * 日期格式
	 */
	final String PATTERN = "yyyy-MM-dd HH:mm:ss";
	
	@Autowired
	private DbCachedService dbcachedService;
	
	@Autowired 
	private BasedbService basedbService;
	
	/**
	 * 数据管理接口
	 */
	@Autowired
	@Qualifier("commonManagerImpl")
	private CommonManager commonManager;
	
	/**
	 * 缓存服务接口
	 */
	@Autowired
	private DbCachedService dbCachedService;
	
	final ExecutorService logExecutor = Executors.newSingleThreadExecutor(new NamedThreadFactory(new ThreadGroup("日志线程组"), "日志线程")); 
	
	@Scheduled(name = "跨天刷新日志", value = "REFRESH_LOG", type = ValueType.BEANNAME)
	public void refreshLog() {
		this.doLogger(LogType.CREATER_USER, "");
		this.doLogger(LogType.CREDIT, "");
		this.doLogger(LogType.CRYSTAL, "");
		this.doLogger(LogType.DIVINATION, "");
		this.doLogger(LogType.DRILL_EXP, "");
		this.doLogger(LogType.ENERGY, "");
		this.doLogger(LogType.ENERGY_BUFF, "");
		this.doLogger(LogType.EXP, "");
		this.doLogger(LogType.EXPLOIT, "");
		this.doLogger(LogType.FAME, "");
		this.doLogger(LogType.FOODS, "");
		this.doLogger(LogType.HERO_COST, "");
		this.doLogger(LogType.HERO_EQUIP, "");
		this.doLogger(LogType.ITEM, "");
		this.doLogger(LogType.LOGIN, "");
		this.doLogger(LogType.MONEY, "");
		this.doLogger(LogType.OPEN_VIP, "");
		this.doLogger(LogType.SELL_HERO_EQUIP, "");
		this.doLogger(LogType.SHOP_BUY, "");
		this.doLogger(LogType.SLIVER, "");
		this.doLogger(LogType.SOUL, "");
		this.doLogger(LogType.SELL_TOWER_RESOURCE, "");
		
		this.rankingByTotalGold();
	}
	
	/**
	 * 记录个人充值排行榜（前100）
	 */
	@SuppressWarnings("unchecked")
	private void rankingByTotalGold() {		
		final int MAX_RANKING = 100;
		DetachedCriteria dc = DetachedCriteria.forClass(Player.class)
				.addOrder(Order.desc("totalGold"));
		
		List<Player> userList = this.commonManager.getCommonQueryResult(dc, 0, MAX_RANKING);
		if (CollectionUtils.isNotEmpty(userList)) {
			Date time = new Date();
			for (Player user : userList) {
				this.logChargePlayerInfo(time, user);
			}
		}
	}
	
	@Scheduled(name = "删除过期每日消费数据", value = "LOG_CLEAR_OVERTIME_CONSUMERECORD", type = ValueType.BEANNAME)
	public void scheduledCleanMail() {
		// 删除过期的每日消费数据，从库中删除并从缓存中删除(100天）
		Date overTime = DateUtils.addDays(new Date(), -100);
		DetachedCriteria criteria = DetachedCriteria.forClass(ConsumeRecord.class)
				.add(Restrictions.le("addTime", overTime))
				.setProjection(Projections.id());
		@SuppressWarnings("unchecked")
		List<String> ids = this.commonManager.getCommonQueryResult(criteria, -1, -1);
		if(CollectionUtils.isNotEmpty(ids)){
			for(String id: ids){
				dbCachedService.submitDeleted2Queue(id, ConsumeRecord.class);
			}
		}
	}
	
	/**
	 * 记录物资日志
	 * @param time 时间
	 * @param userId 玩家id
	 * @param logSource 日志编号
	 * @param orient 收入|支出
	 * @param rewardType 奖励类型
	 * @param id 道具|装备id
	 * @param curValue 执行以后的当前值
	 * @param value 变化值
	 */
	public void logReward(Date time, long userId, int logSource, Orient orient, 
			RewardType rewardType, int id, long curValue, int value) {
		StringBuilder content = new StringBuilder();
		this.appendCommonLog(content, time, userId);
		content.append(logSource).append(BETWEEN_ITEMS);
		content.append(orient.ordinal()).append(BETWEEN_ITEMS).append(rewardType.ordinal()).append(BETWEEN_ITEMS);
		content.append(curValue).append(BETWEEN_ITEMS).append(value);
		switch (rewardType) {
		case GOLD:
		case FUND_GOLD:
		case RMB:
			this.doLogger(LogType.MONEY, content.toString());
			break;

		case SILVER:
			this.doLogger(LogType.SLIVER, content.toString());
			break;
			
		case FOODS:
			this.doLogger(LogType.FOODS, content.toString());
			break;
			
		case ENERGY:
			this.doLogger(LogType.ENERGY, content.toString());
			break;
			
		case ENERGY_BUFF:
			this.doLogger(LogType.ENERGY_BUFF, content.toString());
			break;
			
		case PLAYER_EXP:
			this.doLogger(LogType.EXP, content.toString());
			break;
			
		case SOUL:
			this.doLogger(LogType.SOUL, content.toString());
			break;
			
		case CRYSTAL:
			this.doLogger(LogType.CRYSTAL, content.toString());
			break;
			
		case FAME:
			this.doLogger(LogType.FAME, content.toString());
			break;
			
		case EXPLOIT:
			this.doLogger(LogType.EXPLOIT, content.toString());
			break;
			
		case CREDIT:
			this.doLogger(LogType.CREDIT, content.toString());
			break;
			
		case DRILL_EXP:
			this.doLogger(LogType.DRILL_EXP, content.toString());
			break;
			
		case ITEM:
			content.append(BETWEEN_ITEMS).append(id).append(BETWEEN_ITEMS);
			this.doLogger(LogType.ITEM, content.toString());
			break;
			
		case HERO_EQUIP:
			content.append(BETWEEN_ITEMS).append(id).append(BETWEEN_ITEMS);
			this.doLogger(LogType.HERO_EQUIP, content.toString());
			break;
			
		default:
			break;
		}
	}
	
	/**
	 * 记录登陆日志
	 * @param time 时间
	 * @param userId 玩家id
	 * @param ip 登陆ip
	 * @param type 登陆类型
	 * @param loginSn 登陆流水号
	 */
	public void logLogin(Date time, long userId, String ip, int type, long loginSn) {
		Player user = this.dbcachedService.get(userId, Player.class);
		if (user != null) {
			StringBuilder content = new StringBuilder();
			this.appendCommonLog(content, time, userId);
			content.append(user.getExperience()).append(BETWEEN_ITEMS);
			content.append(user.getGold()).append(BETWEEN_ITEMS);
			content.append(ip).append(BETWEEN_ITEMS);
			content.append(type).append(BETWEEN_ITEMS);
			content.append(loginSn);
			this.doLogger(LogType.LOGIN, content.toString());
		}
	}
	
	/**
	 * 记录注册日志
	 * @param time 时间
	 * @param user 玩家
	 * @param session session
	 */
	public void logCreateUser(Date time, Player user, IoSession session) {
		StringBuilder content = new StringBuilder();
		this.appendCommonLog(content, time, user.getId());
		content.append(user.getUserName()).append(BETWEEN_ITEMS);
		content.append(user.getPlayerName());
		this.doLogger(LogType.CREATER_USER, content.toString());
	}
	
	/**
	 * 记录开通VIP日志
	 * @param time 时间
	 * @param user 玩家
	 */
	public void logOpenVIP(Date time, Player user) {
		StringBuilder content = new StringBuilder();
		this.appendCommonLog(content, time, user.getId());
		content.append(user.getUserName()).append(BETWEEN_ITEMS);
		content.append(user.getPlayerName()).append(BETWEEN_ITEMS);
		content.append(user.getVipLevel());
		this.doLogger(LogType.OPEN_VIP, content.toString());
	}
	
	/**
	 * 记录商城购买日志
	 * @param time 时间
	 * @param userId 玩家id
	 * @param rewardType 奖励类型
	 * @param id 获得的物品id（道具跟装备有，其他为-1）
	 * @param amount 获得的物品数量
	 * @param gold 消耗的元宝
	 * @param fundGold 消耗的返还金币
	 */
	public void logShopBuyRecord(Date time, long userId, RewardType rewardType, 
			int id, int amount, int gold, int fundGold) {
		StringBuilder content = new StringBuilder();
		this.appendCommonLog(content, time, userId);
		content.append(rewardType.ordinal()).append(BETWEEN_ITEMS);
		content.append(id).append(BETWEEN_ITEMS).append(amount).append(BETWEEN_ITEMS);
		content.append(gold).append(BETWEEN_ITEMS).append(fundGold);
		this.doLogger(LogType.SHOP_BUY, content.toString());
	}
	
	/**
	 * 记录武将下野|被吞并日志
	 * @param time 时间
	 * @param userId 玩家id
	 * @param logSource 日志类型
	 * @param heroType 武将类型
	 * @param star 武将星级
	 * @param level 武将等级
	 * @param awake 是否觉醒
	 */
	public void logHeroCostRecord(Date time, long userId, int logSource,
			int heroType, int star, int level, int awake) {
		StringBuilder content = new StringBuilder();
		this.appendCommonLog(content, time, userId);
		content.append(logSource).append(BETWEEN_ITEMS);
		content.append(heroType).append(BETWEEN_ITEMS).append(star).append(BETWEEN_ITEMS);
		content.append(level).append(BETWEEN_ITEMS).append(awake);
		this.doLogger(LogType.HERO_COST, content.toString());
	}
	
	/**
	 * 记录武将装备出售日志
	 * @param time 时间
	 * @param userId 玩家id
	 * @param logSource 日志类型
	 * @param playerHeroEquip 武将装备
	 */
	public void logHeroEquipSellRecord(Date time, long userId, int logSource,
			PlayerHeroEquip playerHeroEquip) {
		StringBuilder content = new StringBuilder();
		this.appendCommonLog(content, time, userId);
		content.append(logSource).append(BETWEEN_ITEMS);
		content.append(playerHeroEquip.getEquipId()).append(BETWEEN_ITEMS);
		if (playerHeroEquip.getBind()) {
			content.append(IntBoolean.TRUE).append(BETWEEN_ITEMS);
		} else {
			content.append(IntBoolean.FALSE).append(BETWEEN_ITEMS);
		}
		content.append(playerHeroEquip.getStrengthenLevel()).append(BETWEEN_ITEMS);
		content.append(playerHeroEquip.getRefineTimes()).append(BETWEEN_ITEMS);
		StringBuilder slots = new StringBuilder();
		StringBuilder slotItems = new StringBuilder();
		for (int i = HeroEquipServiceImpl.MIN_SLOTID; i <= HeroEquipServiceImpl.MAX_SLOTID; i++) {
			int itemId = playerHeroEquip.getSlotItemId(i);
			slotItems.append(i).append("-").append(itemId).append(Splitable.BETWEEN_ITEMS);
			if (playerHeroEquip.isOpenSlot(i)) {
				slots.append(i).append("-").append(IntBoolean.TRUE).append(Splitable.BETWEEN_ITEMS);
			} else {
				slots.append(i).append("-").append(IntBoolean.FALSE).append(Splitable.BETWEEN_ITEMS);
			}
		}
		content.append(slots.toString()).append(BETWEEN_ITEMS).append(slotItems.toString()).append(BETWEEN_ITEMS);
		StringBuilder addAttrs = new StringBuilder();
		for (int i = 1; i <= HeroEquipServiceImpl.MAX_ADD_ATTR_AMOUNT; i++) {
			int addAttrType = playerHeroEquip.getAddAttrType(i);
			if (addAttrType > 0) {
				int addAttrStar = playerHeroEquip.getAddAttrStar(i);
				addAttrs.append(addAttrType).append("-").append(addAttrStar).append(Splitable.BETWEEN_ITEMS);
			} else {
				addAttrs.append(addAttrType).append("-").append(0).append(Splitable.BETWEEN_ITEMS);
			}
		}
		content.append(addAttrs.toString()).append(BETWEEN_ITEMS);
		this.doLogger(LogType.SELL_HERO_EQUIP, content.toString());
	}
	
	/**
	 * 记录主公装备出售日志
	 * @param time 时间
	 * @param userId 玩家id
	 * @param logSource 日志类型
	 * @param playerEquip 主公装备
	 */
	public void logEquipSellRecord(Date time, long userId, int logSource,
			PlayerEquip playerEquip) {
		StringBuilder content = new StringBuilder();
		this.appendCommonLog(content, time, userId);
		content.append(logSource).append(BETWEEN_ITEMS);
		content.append(playerEquip.getEquipId()).append(BETWEEN_ITEMS);
		if (playerEquip.getBind()) {
			content.append(IntBoolean.TRUE).append(BETWEEN_ITEMS);
		} else {
			content.append(IntBoolean.FALSE).append(BETWEEN_ITEMS);
		}
		this.doLogger(LogType.SELL_EQUIP, content.toString());
	}
	
	/**
	 * 记录领取全服任务奖励日志
	 * @param time 时间
	 * @param user 玩家
	 * @param taskId 任务id
	 * @param rewardId 奖励id
	 */
	public void logReceiveServerTaskReward(Date time, Player user, int taskId, int rewardId) {
		StringBuilder content = new StringBuilder();
		this.appendCommonLog(content, time, user.getId());
		content.append(taskId).append(BETWEEN_ITEMS);
		content.append(rewardId);
		this.doLogger(LogType.RECEIVE_SERVER_TASK_REWARD, content.toString());
	}
	
	/**
	 * 记录重置全服任务奖励日志
	 * @param time 时间
	 * @param user 玩家
	 * @param taskId 任务id
	 * @param oldTime 旧任务时间
	 * @param newTime 新任务时间
	 */
	public void logResetServerTask(Date time, Player user, int taskId, long oldTime, long newTime) {
		StringBuilder content = new StringBuilder();
		this.appendCommonLog(content, time, user.getId());
		content.append(taskId).append(BETWEEN_ITEMS);
		content.append(oldTime).append(BETWEEN_ITEMS);
		content.append(newTime);
		this.doLogger(LogType.RESET_SERVER_TASK, content.toString());
	}
	
	/**
	 * @description:跑环日志监控
	 * @param time
	 * @param playerId
	 * @param nextLoopId 跑环轨迹
	 * @param reduceCommonDiceSum 扣减骰子数
	 * @param afterCommonDiceSum 当前骰子数
	 * @param addCoupon 增加点卷数
	 * @param afterCoupon 当前点卷数
	 */
	public void logLoopFix(Date time, long playerId, String nextLoopId, int reduceCommonDiceSum, int afterCommonDiceSum, int addCoupon, int afterCoupon){
		StringBuilder content = new StringBuilder();
		this.appendCommonLog(content, time, playerId);
		content.append(nextLoopId).append(BETWEEN_ITEMS);
		content.append(reduceCommonDiceSum).append(BETWEEN_ITEMS);
		content.append(afterCommonDiceSum).append(BETWEEN_ITEMS);
		content.append(addCoupon).append(BETWEEN_ITEMS);
		content.append(afterCoupon);		
		this.doLogger(LogType.LOOPFIX, content.toString());
	}
	
	/**
	 * @description:酒馆日志监控
	 * @param time
	 * @param playerId
	 * @param rewardString
	 */
	public void plunderFoodLog(Date time, long playerId, String rewardString){
		StringBuilder content = new StringBuilder();
		this.appendCommonLog(content, time, playerId);
		content.append(rewardString);	
		this.doLogger(LogType.PLUNDERFOOD, content.toString());	
	}
	
	/**
	 * @description:全服礼包奖励领取日志记录	
	 * @param time
	 * @param playerId
	 * @param playerGiftInfoId
	 * @param rewardString
	 * @param valueResultSet
	 */
	public void serverGiftLog(Date time, long playerId, long playerGiftInfoId, String rewardString, ValueResultSet valueResultSet){
		StringBuilder content = new StringBuilder();
		this.appendCommonLog(content, time, playerId);
		content.append(playerGiftInfoId).append(BETWEEN_ITEMS);
		content.append(rewardString).append(BETWEEN_ITEMS);	
		content.append(JsonUtils.object2JsonString(valueResultSet));	
		this.doLogger(LogType.SERVER_GIFT, content.toString());	
	
	}
	
	/**
	 * 购买资源据点
	 * @param user 玩家
	 * @param time 购买时间
	 * @param areaId 据点id
	 * @param id 资源据点id
	 * @param buyCount 购买次数
	 * @param cost 花费
	 * @param goldDiscount 折扣
	 */
	public void logTowerResource(Player user, Date time, int areaId, int id, int buyCount, int cost, int goldDiscount) {
		StringBuilder content = new StringBuilder();
		this.appendCommonLog(content, time, user.getId());
		content.append(user.getUserName()).append(BETWEEN_ITEMS);
		content.append(user.getPlayerName()).append(BETWEEN_ITEMS);
		content.append(areaId).append(BETWEEN_ITEMS);
		content.append(id).append(BETWEEN_ITEMS);
		content.append(buyCount).append(BETWEEN_ITEMS);
		content.append(cost).append(BETWEEN_ITEMS);
		content.append(goldDiscount);
		this.doLogger(LogType.SELL_TOWER_RESOURCE, content.toString());
	}
	
	/**
	 * 记录登出日志
	 * @param time 时间
	 * @param userId 玩家id
	 * @param level 等级
	 * @param vipLevel VIP等级
	 * @param registerTime 注册时间
	 * @param ip 登出IP
	 * @param loginSn 登陆流水号
	 */
	public void logLogout(Date time, long userId, String ip, long loginSn) {
		Player user = this.dbcachedService.get(userId, Player.class);
		if (user != null) {
			StringBuilder content = new StringBuilder();
			this.appendCommonLog(content, time, userId);
			content.append(ip).append(BETWEEN_ITEMS);
			content.append(loginSn);
			this.doLogger(LogType.LOGOUT, content.toString());
		}
	}
	
	/**
	 * 记录充值前100玩家信息日志
	 * @param time 时间
	 * @param userId 玩家id
	 * @param level 等级
	 * @param vipLevel VIP等级
	 * @param registerTime 注册时间
	 * @param userName 玩家帐号
	 * @param playerName 角色名
	 * @param loginTime 最后登录时间
	 * @param totalLoginDays 总登录天数
	 * @param totalOnlineTime 总在线时长（毫秒）
	 * @param totalGold 总充值元宝
	 * @param gold 剩余充值元宝
	 * @param totalConsume 总累计消费
	 * @param ipAddress 最后登录IP地址
	 */
	public void logChargePlayerInfo(Date time, Player user) {
		StringBuilder content = new StringBuilder();
		this.appendCommonLog(content, time, user.getId());
		content.append(user.getUserName()).append(BETWEEN_ITEMS);
		content.append(user.getPlayerName()).append(BETWEEN_ITEMS);
		content.append(DateFormatUtils.format(user.getLoginTime(), this.PATTERN)).append(BETWEEN_ITEMS);
		content.append(user.getTotalLoginDays()).append(BETWEEN_ITEMS);
		content.append(user.getTotalOnlineTime()).append(BETWEEN_ITEMS);
		content.append(user.getTotalGold()).append(BETWEEN_ITEMS);
		content.append(user.getGold()).append(BETWEEN_ITEMS);
		content.append(user.getTotalConsume()).append(BETWEEN_ITEMS);
		content.append(user.getIpAddress());
		this.doLogger(LogType.CHARGE_PLAYER, content.toString());
	}
	
	/**
	 * 附加通用日志字段
	 * @param content 内容
	 * @param time 时间
	 * @param userId 玩家id
	 */
	private void appendCommonLog(StringBuilder content, Date time, long userId) {
		content.append(DateFormatUtils.format(time, this.PATTERN)).append(BETWEEN_ITEMS);
		content.append(userId).append(BETWEEN_ITEMS);
		Player user = this.dbcachedService.get(userId, Player.class);
		if (user != null) {
			content.append(user.getLevel()).append(BETWEEN_ITEMS).append(user.getVipLevel()).append(BETWEEN_ITEMS);
			if (user.getRegisterTime() == null) {
				content.append("").append(BETWEEN_ITEMS);
			} else {
				content.append(DateFormatUtils.format(user.getRegisterTime(), this.PATTERN)).append(BETWEEN_ITEMS);
			}
		}
	}
	
	/**
	 * 记录日志
	 * @param logType 日志类型
	 * @param message 日志内容
	 */
	public void doLogger(final LogType logType, final String message){
		try {
			logExecutor.submit(new Runnable() {
				@Override
				public void run() {
					info(logType, message);
				}
			});
		} catch (RejectedExecutionException e) {
			logger.error("日志线程池提交日志任务异常" , e);
		}
	}
	
	/**
	 * 记录日志
	 * @param logType 日志的类型
	 * @param message 需要记录的日志信息
	 */
	private void info(LogType logType, String message) {
		Logger log = LoggerFactory.getLogger(logType.getLogName());
		if (log.isInfoEnabled()) {
			log.info(message);
		}
	}
	
}
