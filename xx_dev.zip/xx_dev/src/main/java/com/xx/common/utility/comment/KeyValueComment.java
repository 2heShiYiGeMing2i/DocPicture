/**
 * 
 */
package com.xx.common.utility.comment;

/**
 * @author fansth
 *
 */
public class KeyValueComment<K, V> {
	
	/**
	 * key的值
	 */
	private K key;
	
	/**
	 * value的值
	 */
	private V value;

	public KeyValueComment(TypeComment<K> keyComment, TypeComment<V> valueComment){
		this.key = keyComment.getValue();
		this.value = valueComment.getValue();
	}
	
	public KeyValueComment(K key, Comment... comments){
		this.key = key;
	}
	
	public KeyValueComment(K key, V value, Comment... comments){
		this.key = key;
		this.value = value;
	}

	public K getKey() {
		return key;
	}

	public void setKey(K key) {
		this.key = key;
	}

	public V getValue() {
		return value;
	}

	public void setValue(V value) {
		this.value = value;
	}
	
}
