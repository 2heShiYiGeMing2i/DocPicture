/**
 * 
 */
package com.xx.common.utility.httpclient;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * http工具类
 * @author fansth
 *
 */
public class HttpUtils {

	private static final Logger logger = LoggerFactory.getLogger(HttpUtils.class);
	
	
	/**
	 * 请求url返回String
	 * @param url
	 * @param httpMethod
	 * @return
	 */
	public static String requestForString(String url, HttpMethod httpMethod){
		SingleHttpClient httpClient = new SingleHttpClient();
		String response = "";
		try {
			response = httpClient.requestForString(url, httpMethod);
		} finally {
			httpClient.close();
		}
		return response;
	}
	
	/**
	 * 请求url返回String
	 * @param url
	 * @param httpMethod
	 * @param parameters 参数
	 * @param headers http头
	 * @return
	 */
	public static String requestForString(String url, HttpMethod httpMethod, Map<String, Object> parameters, Map<String, Object> headers){
		SingleHttpClient httpClient = new SingleHttpClient();
		String response = "";
		try {
			response = httpClient.requestForString(url, httpMethod, parameters, headers);
		} finally {
			httpClient.close();
		}
		return response;
	}
	
	/**
	 * 请求url返回String(HttpMethod.POST)
	 * @param url URL
	 * @param parameters 参数
	 * @return String
	 */
	public static String postRequestForString(String url, Map<String, String> parameters){
		SingleHttpClient httpClient = new SingleHttpClient();
		String response = "";
		try {
			response = httpClient.postRequestForString(url, parameters);
		} finally {
			httpClient.close();
		}
		return response;
	}
	
	/**
	 * 构建请求url(就是将参数加到uri的后面)
	 * @param url
	 * @param params
	 * @return
	 */
	public static String buildUrl(String uri, Map<String, Object> params){
		StringBuilder urlBuilder = new StringBuilder(uri);
		urlBuilder.append("?");
		if(params != null && !params.isEmpty()){
			for(Entry<String, Object> entry : params.entrySet()){
				urlBuilder.append(entry.getKey()).append("=").append(String.valueOf(entry.getValue())).append("&");
			}
		}
		
		if(urlBuilder.charAt(urlBuilder.length() - 1) == '&'){
			urlBuilder.deleteCharAt(urlBuilder.length() - 1);
		}
		
		return urlBuilder.toString();
	}
	
	/**
	 *  URL编码
	 * @param input
	 * @param charset 字符集  null-默认为UTF-8
	 * @return
	 */
	public static String encodeUrl(String input, String charset) {
		if(StringUtils.isBlank(charset)){
			charset = "UTF-8";
		}
		try {
			return URLEncoder.encode(input, charset).replace("+", "%20").replace("*", "%2A");
		} catch (UnsupportedEncodingException e) {
			logger.error("url编码错误!", e);
		}
		return "";
	}
	
}
