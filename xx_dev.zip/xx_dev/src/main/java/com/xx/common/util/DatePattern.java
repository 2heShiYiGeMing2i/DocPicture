package com.xx.common.util;

/**
 * 时间格式定义
 * 
 * @author Hyint
 */
public interface DatePattern {

	/** 
	 * HH:mm 格式
	 */
	String PATTERN_HH_MM = "HH:mm";

	/** 
	 * yyyyMMdd 格式
	 */
	String PATTERN_YYYYMMDD = "yyyyMMdd";

	/** 
	 * yyyy-MM-dd 格式
	 */
	String PATTERN_YYYY_MM_DD = "yyyy-MM-dd";

	/** 
	 * yyyyMMddHHmm 格式
	 */
	String PATTERN_YYYYMMDDHHMM = "yyyyMMddHHmm";

	/** 
	 * yyyy-MM-dd HH:mm:ss 格式
	 */
	String PATTERN_NORMAL = "yyyy-MM-dd HH:mm:ss";

	/** 
	 * yyyyMMddHHmmss 格式
	 */
	String PATTERN_YYYYMMDDHHMMSS = "yyyyMMddHHmmss";
	
	/**
	 * HH:mm:ss 格式
	 */
	String PATTERN_HH_MM_SS = "HH:mm:ss";
	
}
