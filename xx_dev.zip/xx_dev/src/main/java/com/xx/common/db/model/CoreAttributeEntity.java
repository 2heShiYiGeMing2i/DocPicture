/**
 * @file:CoreAttributeEntity.java
 * @author:David
 **/
package com.xx.common.db.model;

import java.io.Serializable;
import java.util.Properties;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;

import org.hibernate.annotations.Type;

/**
 * @class:CoreAttributeEntity
 * @description:
 * @author:David
 * @version:v1.0
 * @date:2012-10-11
 **/
@MappedSuperclass
public abstract class CoreAttributeEntity<PK extends Comparable<PK> & Serializable> extends BaseModel<PK> {

	private static final long serialVersionUID = -2994715295652692950L;
	
	@Type(type = "com.my9yu.common.db.model.usertype.String2PropertiesUserType")
	@Column(columnDefinition = "text comment '自定义属性'")
	private Properties simpleAttributes;

	/**
	 * 属性集合，可存放一些自定义、自解释的属性
	 * 
	 * @return the simpleAttributes
	 */
	public Properties getSimpleAttributes() {
		return simpleAttributes;
	}

	/**
	 * @param simpleAttributes
	 *            the simpleAttributes to set
	 */
	public void setSimpleAttributes(Properties attributes) {
		this.simpleAttributes = attributes;
	}

	/**
	 * 通过键值获得属性值
	 * 
	 * @param key
	 * @return
	 */
	public String findAttribute(String key) {
		if (this.getSimpleAttributes() == null) {
			return null;
		}
		return simpleAttributes.getProperty(key);
	}

	/**
	 * 增加或者更新属性
	 * 
	 * @param key
	 * @param value
	 */
	// TODO 检查key、value是否包含分隔符号 '|'
	public void setAttribute(String key, String value) {
		if (key == null || value == null) {
			return;
		}
		if (simpleAttributes == null) {
			simpleAttributes = new Properties();
		}
		simpleAttributes.setProperty(key, value);
	}

	/**
	 * 删除属性
	 * 
	 * @param key
	 * @param value
	 */
	// TODO 检查key、value是否包含分隔符号 '|'
	public void removeAttribute(String key) {
		if (key == null) {
			return;
		}
		if (simpleAttributes == null) {
			return;
		}
		simpleAttributes.remove(key);
	}

	public String findConfig(String key) {
		return findAttribute(key);
	}

	public long findConfigAsLong(String key, long def) {
		String value = findAttribute(key);
		try {
			return Long.parseLong(value);
		} catch (Exception e) {
			return def;
		}
	}

	public int findConfigAsInteger(String key, int def) {
		String value = findAttribute(key);
		try {
			return Integer.parseInt(value);
		} catch (Exception e) {
			return def;
		}
	}

	public float findConfigAsFloat(String key, float def) {
		String value = findAttribute(key);
		try {
			return Float.parseFloat(value);
		} catch (Exception e) {
			return def;
		}
	}

	public void setConfig(String key, Object value) {
		setAttribute(key, value.toString());
	}
}

