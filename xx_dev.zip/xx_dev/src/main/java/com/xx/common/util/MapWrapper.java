/**
 * 
 */
package com.xx.common.util;

import java.util.Collection;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;


/**
 * @author fansth
 *
 */
public class MapWrapper implements Iterable<Entry<String, Object>>{
	
	private Map<String, Object> map = new ConcurrentHashMap<String, Object>();
	
	public MapWrapper(Map<String, Object> map){
		if(map != null){
			this.map.putAll(map);
		}
	}
	
	public void increase(String key, Object value){
		if(value == null || !(value instanceof Number)){
			return;
		}
		Number numValue = (Number) value;
		Number n = (Number)this.map.get(key);
		if(n == null){
			n = 0;
		}
		this.map.put(key, n.doubleValue() + numValue.doubleValue());
	}
	
	public void decrease(String key, Object value){
		if(value == null || !(value instanceof Number)){
			return;
		}
		Number numValue = (Number) value;
		Number n = (Number)this.map.get(key);
		if(n == null){
			n = 0;
		}
		this.map.put(key, n.doubleValue() - numValue.doubleValue());
	}
	
	public void put(String key, Object value){
		this.map.put(key, value);
	}
	
	public Object get(String key){
		return this.map.get(key);
	}
	
	public Number getNumberValue(String key){
		Number value = (Number)this.map.get(key);
		return value;
	}
	
	public Number getNumberValue(String key, double defaultValue){
		Number value = (Number)this.map.get(key);
		return value != null ? value : defaultValue;
	}
	
	public Date getDateValue(String key){
		return (Date)map.get(key);
	}
	
	public boolean containsKey(String key){
		return this.map.containsKey(key);
	}
	
	public boolean containsValue(Object value){
		return this.map.containsValue(value);
	}
	
	public Set<String> keySet(){
		return this.map.keySet();
	}

	public Collection<Object> values(){
		return this.map.values();
	}
	
	public Map<String, Object> getMap(){
		return this.map;
	}

	@Override
	public Iterator<Entry<String, Object>> iterator() {
		return this.map.entrySet().iterator();
	}
}
