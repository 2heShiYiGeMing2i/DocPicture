/**
 * 
 */
package com.xx.common.utility.cas;

/**
 * @author fansth
 *
 */
public class CASActionException extends RuntimeException {

	private static final long serialVersionUID = 3999189094562188528L;

	public CASActionException(String message, Throwable e){
		super(message, e);
	}
	
	public CASActionException(){
		
	}
	
}
