package com.xx.common.db.cache.impl;

import static com.xx.common.db.cache.DbCachedCfgConstant.KEY_DB_POOL_CAPACITY;
import static com.xx.common.db.cache.DbCachedCfgConstant.KEY_MAX_CAPACITY_OF_COMMON_CACHE;
import static com.xx.common.db.cache.DbCachedCfgConstant.KEY_MAX_CAPACITY_OF_ENTITY_CACHE;
import static com.xx.common.db.cache.DbCachedCfgConstant.KEY_SERVER_ID_SET;
import static com.xx.common.db.cache.DbCachedCfgConstant.SPLIT;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import javax.annotation.PostConstruct;
import javax.persistence.Entity;

import org.apache.mina.util.ConcurrentHashSet;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.helpers.FormattingTuple;
import org.slf4j.helpers.MessageFormatter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;

import com.googlecode.concurrentlinkedhashmap.ConcurrentLinkedHashMap;
import com.xx.common.db.cache.DbCachedMBean;
import com.xx.common.db.cache.DbCachedService;
import com.xx.common.db.cache.DbCallback;
import com.xx.common.db.cache.DbLoadInitializer;
import com.xx.common.db.model.BaseModel;
import com.xx.common.db.pk.IdGenerator;
import com.xx.common.db.pk.LongGenerator;
import com.xx.common.db.pk.ServerEntityIdRule;
import com.xx.common.db.service.CommonManager;
import com.xx.common.profile.Profileable;
import com.xx.common.profile.Profiler;
import com.xx.common.runtime.Lifecycle;
import com.xx.common.runtime.LifecycleMethod;
import com.xx.common.util.GenericsUtils;
import com.xx.common.util.RandomUtil;
import com.xx.common.util.ThreadUtils;
import com.xx.common.utility.PackageScanner;
import com.xx.common.utility.lock.LockUtils;
import com.xx.common.utility.thread.NamedThreadFactory;

/**
 * 数据缓存服务实现类
 */
@Component("dbCachedServiceImpl")
public class DbCachedServiceImpl implements DbCachedService, DbCachedMBean, Profileable {
	
	/**
	 * logger
	 */
	private static final Logger logger = LoggerFactory.getLogger(DbCachedServiceImpl.class);
	
	/**
	 * 缺省实体缓存最大容量
	 */
	private static final int DEFAULT_MAX_CAPACITY_OF_ENTITY_CACHE = 1000000;
	
	/**
	 * 缺省通用缓存最大容量
	 */
	private static final int DEFAULT_MAX_CAPACITY_OF_COMMON_CACHE = DEFAULT_MAX_CAPACITY_OF_ENTITY_CACHE;	
	
	/**
	 * 缺省入库线程池容量
	 */
	private static final int DEFAULT_DB_POOL_CAPACITY = Runtime.getRuntime().availableProcessors();
	
	/**
	 * 入库失败重试次数
	 */
	private static final int DB_ERROR_RETRY_COUNT = 10;
	
	/**
	 * 实体缓存
	 */
	private ConcurrentMap<String, EntityCacheObject> ENTITY_CACHE;
	
	/**
	 * 通用缓存
	 */
	private ConcurrentMap<String, Object> COMMON_CACHE;
	
	/**
	 * 实体主键ID生成map {服ID ： {实体类： 主键id生成器} }
	 */
	private final ConcurrentMap<Integer, ConcurrentMap<Class<?>, IdGenerator<?>>>  SERVER_ENTITY_IDGENERATOR_MAP = new ConcurrentHashMap<Integer, ConcurrentMap<Class<?>, IdGenerator<?>>> ();
	
	/**
	 * 入库线程池
	 */
	private ExecutorService DB_POOL_SERVICE;
	
	/**
	 * 等待锁map {key:lock}
	 */
	private final ConcurrentMap<String, Lock> WAITING_LOCK_MAP = new ConcurrentHashMap<String, Lock>();
	
	@Autowired 
	@Qualifier("commonManagerImpl")
	private CommonManager commonManager;
	@Autowired 
	private ApplicationContext applicationContext;
	
	/**
	 * 配置文件位置
	 */
	@Autowired(required = false)
	@Qualifier("dbCachedCfgLocation")
	private String location = "classpath:ServerCfg.properties";
	
	/**
	 * 配置文件属性
	 */
	private Properties properties;
	
	/**
	 * 服标识ID列表
	 */
	private List<Integer> serverIdList;
	
	/**
	 * 实体包
	 */
	@Autowired(required = false)
	@Qualifier("entityPackages")
	private String entityPackages = "com.my9yu.**.model";
	
	
	/**
	 * 根据主键id取得实体
	 * @param id 主键id
	 * @param entityClazz 实体类型
	 * @return 实体对象
	 */
	@Override
	@SuppressWarnings("unchecked")
	public <T> T get(Serializable id, Class<T> entityClazz) {
		String key = this.getEntityIdKey(id, entityClazz);
		EntityCacheObject cacheObj = ENTITY_CACHE.get(key);
		if (cacheObj == null) {
			Lock lock = new ReentrantLock();
			Lock prevLock = WAITING_LOCK_MAP.putIfAbsent(key, lock);
			lock = prevLock != null ? prevLock : lock;
			
			lock.lock();
			try {
				cacheObj = ENTITY_CACHE.get(key);
				if (cacheObj == null) {
					T entity = commonManager.get(entityClazz, id);
					if (entity != null) {						
						if(entity instanceof DbLoadInitializer){
							DbLoadInitializer dbLoadInitializer = (DbLoadInitializer)entity;
							dbLoadInitializer.doAfterLoad();
						}
						
						cacheObj = new EntityCacheObject(entity, id, entityClazz);						
						EntityCacheObject prevCo = ENTITY_CACHE.putIfAbsent(key, cacheObj);
						if (prevCo != null) {
							cacheObj = prevCo;
						}
					}
				}
			} finally {
				WAITING_LOCK_MAP.remove(key);
				lock.unlock();
			}
		}
		
		if (cacheObj != null && cacheObj.updateStatus != UpdateStatus.DELETE) {
			return (T) cacheObj.entity;
		}
		
		return null;
	}
	
	/**
	 * 取得(缓存的)查询结果集(一般是id列表, 由业务维护缓存的生命周期)
	 * @param cachedKey 缓存key
	 * @param criteria DetachedCriteria
	 * @param fromIdx 开始索引
	 * @param fetchCount 获取数量
	 * @return ConcurrentHashSet<T>
	 */
	@SuppressWarnings("unchecked")
	public <T> ConcurrentHashSet<T> getCachedQueryResult(String cachedKey, DetachedCriteria criteria, int fromIdx, int fetchCount) {
		ConcurrentHashSet<T> cachedObj = (ConcurrentHashSet<T>) this.getFromCommonCache(cachedKey);
		if (cachedObj != null) {
			return cachedObj;
		}
		
		Lock lock = new ReentrantLock();
		Lock prevLock = WAITING_LOCK_MAP.putIfAbsent(cachedKey, lock);
		lock = prevLock != null ? prevLock : lock;
		
		lock.lock();
		try {
			cachedObj = (ConcurrentHashSet<T>) this.getFromCommonCache(cachedKey);
			if (cachedObj != null) {
				return cachedObj;
			}
	
			List<T> list = this.commonManager.getCommonQueryResult(criteria, fromIdx, fetchCount);
			if (list != null && list.size() > 0) {
				cachedObj = new ConcurrentHashSet<T>(list);
			} else {
				cachedObj = new ConcurrentHashSet<T>();
			}
			
			this.put2CommonCacheIfAbsent(cachedKey, cachedObj);
			return (ConcurrentHashSet<T>) this.getFromCommonCache(cachedKey);
			
		} finally {
			WAITING_LOCK_MAP.remove(cachedKey);
			lock.unlock();
		}		
	}
	
	/**
	 * 根据主键id列表取得实体列表
	 * @param idList 主键id列表
	 * @param entityClazz 实体类型
	 * @return 实体对象列表
	 */
	@Override
	public <T, PK extends Serializable> List<T> getEntityFromIdList(Collection<PK> idList, Class<T> entityClazz) {
		if (idList == null || idList.size() == 0) {
			return null;
		}
		
		List<T> list = new ArrayList<T> (idList.size());
		
		for (Serializable id : idList) {
			T entity = this.get(id, entityClazz);
			if (entity != null) {
				list.add(entity);
			}
		}
		
		return list;
	}
	
	/**
	 * 提交实体修改任务到更新队列
	 * @param id 主键id
	 * @param entityClazz 实体类型
	 */
	@Override
	public void submitUpdated2Queue(Serializable id, Class<?> entityClazz) {
		this.submitUpdated2Queue(id, entityClazz, null);
	}
	
	/**
	 * 提交实体修改任务到更新队列
	 * @param id 主键id
	 * @param entityClazz 实体类型
	 * @param callback 回调
	 */
	@Override
	public void submitUpdated2Queue(Serializable id, Class<?> entityClazz, DbCallback callback) {
		String key = this.getEntityIdKey(id, entityClazz);
		EntityCacheObject cacheObj = ENTITY_CACHE.get(key);
		
		if (cacheObj == null) {//缓存不存在, 不需要更新
			if (callback != null) {
				callback.doBefore();
				callback.doAfter();
			}
			
		} else {
			//更新版本号
			cacheObj.updateEditVersion();
			submitTask(cacheObj, callback);
		}
	}
	
	/**
	 * 实时更新实体
	 * @param id 主键id
	 * @param entityClazz 实体类型
	 */
	@Override
	public void updateEntityIntime(Serializable id, Class<?> entityClazz) {
		String key = this.getEntityIdKey(id, entityClazz);
		EntityCacheObject cacheObj = ENTITY_CACHE.get(key);
		
		if (cacheObj != null) {
			//更新版本号
			cacheObj.updateEditVersion();
			this.handleTask(cacheObj, null);
		}
	}	
	
	/**
	 * 提交实体删除任务到更新队列
	 * @param id 主键id
	 * @param entityClazz 实体类型
	 */
	@Override
	public void submitDeleted2Queue(Serializable id, Class<?> entityClazz) {
		this.submitDeleted2Queue(id, entityClazz, null);
	}
	
	/**
	 * 提交实体删除任务到更新队列
	 * @param id 主键id
	 * @param entityClazz 实体类型
	 * @param callback 回调
	 */
	@Override
	public void submitDeleted2Queue(Serializable id, Class<?> entityClazz, DbCallback callback) {
		this.deleteEntityTask(id, entityClazz, callback, false);
	}
	
	/**
	 * 实时删除实体对象
	 * @param id 主键id
	 * @param entityClazz 实体类型
	 */
	@Override
	public void deleteEntityIntime(Serializable id, Class<?> entityClazz) {
		this.deleteEntityTask(id, entityClazz, null, true);
	}
		
	/**
	 * 提交实体删除任务到更新队列
	 * @param id 主键id
	 * @param entityClazz 实体类型
	 * @param callback 回调
	 * @param justIntime 是否实时入库
	 */
	private void deleteEntityTask(Serializable id, Class<?> entityClazz, DbCallback callback, boolean justIntime) {
		String key = this.getEntityIdKey(id, entityClazz);
		EntityCacheObject cacheObj = ENTITY_CACHE.get(key);
		
		if (cacheObj == null) {
			Object entity = this.get(id, entityClazz);
			if (entity == null) {//没有此对象
				return;
			}
			
			cacheObj = ENTITY_CACHE.get(key);
		}
		
		if (cacheObj == null) {
			return;
		}
		
		cacheObj.setUpdateStatus(UpdateStatus.DELETE);
		
//		if (cacheObj == null) {
//			cacheObj = new EntityCacheObject(null, id, entityClazz, UpdateStatus.DELETE);
//			EntityCacheObject prevCo = ENTITY_CACHE.putIfAbsent(key, cacheObj);
//			if (prevCo != null) {
//				cacheObj = prevCo;
//				cacheObj.setUpdateStatus(UpdateStatus.DELETE);
//			}
//			
//		} else {
//			cacheObj.setUpdateStatus(UpdateStatus.DELETE);
//		}
		
		//更新版本
		cacheObj.updateEditVersion();
		
		if (justIntime) {
			this.handleTask(cacheObj, callback);
		} else {
			submitTask(cacheObj, callback);
		}
	}
	
	/**
	 * 提交任务
	 * @param cacheObj EntityCacheObject
	 * @param callback DbCallback
	 */
	private void submitTask(EntityCacheObject cacheObj, DbCallback callback) {
		Runnable task = this.createTask(cacheObj, callback);
		
		try {
			DB_POOL_SERVICE.submit(task);
		} catch (RejectedExecutionException ex) {
			logger.error("提交任务到更新队列产生异常", ex);
			
			this.handleTask(cacheObj, callback);
			
		} catch (Exception ex) {
			logger.error("提交任务到更新队列产生异常", ex);
		}
	}
	
	@Override
	public <T extends BaseModel<PK>, PK extends Comparable<PK> & Serializable> T submitNew2Queue(T entity) {
		return this.saveEntityTask(entity, null, false, null);
	}
	
	@Override
	public <T extends BaseModel<PK>, PK extends Comparable<PK> & Serializable> T submitNew2Queue(T entity, int serverId) {
		return this.saveEntityTask(entity, null, false, serverId);
	}

	@Override
	public <T extends BaseModel<PK>, PK extends Comparable<PK> & Serializable> T submitNew2Queue(T entity, int serverId, DbCallback callback) {
		return this.saveEntityTask(entity, callback, false, serverId);
	}
	
	@Override
	public <T extends BaseModel<PK>, PK extends Comparable<PK> & Serializable> T saveEntityIntime(T entity) {
		return this.saveEntityTask(entity, null, true, null);
	}
	
	@Override
	public <T extends BaseModel<PK>, PK extends Comparable<PK> & Serializable> T saveEntityIntime(T entity, int serverId) {
		return this.saveEntityTask(entity, null, true, serverId);
	}
	
	/**
	 * 提交新建实体到更新队列(id==null时根据主键id生成器接口生成id)
	 * @param entity 新建实体对象
	 * @param callback 回调
	 * @param justIntime 是否实时入库
	 * @param serverId 服标识
	 * @return 返回保存的实体对象(可能与entity不是同一个实例)
	 * @throws IllegalArgumentException 如果主键id==null且没有定义主键id生成器接口
	 */
	@SuppressWarnings("unchecked")
	private <T extends BaseModel<PK>, PK extends Comparable<PK> & Serializable> T saveEntityTask(T entity, DbCallback callback, boolean justIntime, Integer serverId) {
		if (entity == null) {
			if (callback != null) {
				callback.doBefore();
				callback.doAfter();
			}			
			return null;
		}
		
		if (entity.getId() == null) {
			if (serverId == null) {
				serverId = this.getRandomServerId();
			}
			
			Object id = serverId != null ?  this.getIdAutoGenerateValue(serverId, entity.getClass()) : null;
			if (id == null) {
				String msg = "提交新建实体到更新队列参数错：未能识别主键类型";
				logger.error(msg);
				throw new IllegalArgumentException(msg);
			}
			
			entity.setId( (PK) id);
		}
		
		String key = this.getEntityIdKey(entity.getId(), entity.getClass());
		EntityCacheObject cacheObj = ENTITY_CACHE.get(key);
		if (cacheObj == null) {//缓存还不存在
			cacheObj = new EntityCacheObject(entity, entity.getId(), entity.getClass(), UpdateStatus.INSERT);
			ENTITY_CACHE.putIfAbsent(key, cacheObj);
			
		} else if (cacheObj.updateStatus == UpdateStatus.DELETE) {//已被删除
			//删除再保存，实际上很少出现这种情况
			cacheObj.setUpdateStatus(UpdateStatus.INSERT);
			ENTITY_CACHE.putIfAbsent(key, cacheObj);				
		}
		
		if (justIntime) {
			this.updateEntityIntime(entity.getId(),  entity.getClass());
		} else {
			this.submitUpdated2Queue(entity.getId(), entity.getClass(), callback);
		}
		
		Object obj = this.get(entity.getId(),  entity.getClass());
		return (T) obj;
	}

	/**
	 * 取得实体key
	 * @param id 主键id
	 * @param entityClazz 实体类型
	 * @return String
	 */
	private String getEntityIdKey(Serializable id, Class<?> entityClazz) {
		return new StringBuffer().append(entityClazz.getName())
									.append("_")
									.append(id).toString();
	}
	
	/**
	 * 创建入库任务
	 * @param cacheObj 实体缓存
	 * @param callback 入库回调
	 * @return Runnable
	 */
	private Runnable createTask(final EntityCacheObject cacheObj, final DbCallback callback) {
		return new Runnable() {			
			@Override
			public void run() {
				handleTask(cacheObj, callback);
			}			
		};
	}
	
	/**
	 * 处理入库及回调事宜
	 * @param cacheObj 实体缓存
	 * @param callback 入库回调
	 */
	private void handleTask(final EntityCacheObject cacheObj, final DbCallback callback) {
		if (callback != null) {
			try {
				callback.doBefore();
				
			} catch (Exception ex) {
				logger.error("执行入库前回调时产生异常", ex);
			}
		}
		
		//执行入库
		doSyncDb(cacheObj);
		
		if (callback != null) {
			try {
				callback.doAfter();
				
			} catch (Exception ex) {
				logger.error("执行入库后回调时产生异常", ex);
			}
		}
	}
	
	/**
	 * 同步到db
	 * @param cacheObj 实体缓存
	 */
	private void doSyncDb(final EntityCacheObject cacheObj) {
		if (cacheObj == null) {
			return;
		}
		
		//已经同步了
		if (cacheObj.isDbSync()) {
			return;
		}
		
		cacheObj.lock();
		try {
			if (cacheObj.isDbSync()) {
				return;
			}
			
			cacheObj.updateDbVersion();
			
			try {
				if (cacheObj.updateStatus == UpdateStatus.DELETE) {
					commonManager.delete(cacheObj.clazz, cacheObj.id);
					
					String key = this.getEntityIdKey(cacheObj.id, cacheObj.clazz);
					ENTITY_CACHE.remove(key);
					
				} else if (cacheObj.updateStatus == UpdateStatus.INSERT) {
					commonManager.save(cacheObj.entity);
					cacheObj.updateStatus = UpdateStatus.UPDATE;
					
				} else {
					commonManager.update(cacheObj.entity);
				}
				
				//操作成功， 重置重试次数
				if (cacheObj.retryCount > 0) {
					cacheObj.retryCount = 0;
				}
				
			} catch (Exception ex) {
				logger.error("执行入库时产生异常! 如果是主键冲突异常可忽略!", ex);
				
				if (++ cacheObj.retryCount < DB_ERROR_RETRY_COUNT) {
					this.submitUpdated2Queue(cacheObj.id, cacheObj.clazz);
				}
			}
			
		} finally {
			cacheObj.unlock();
		}
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public Object put2CommonCacheIfAbsent(String key, Object obj) {
		if (obj == null) {			
			throw new NullPointerException();
		}
		
		CacheObject newObj = new CacheObject(obj, -1L);	
		
		Object oldObject = COMMON_CACHE.putIfAbsent(key, newObj);
		if (oldObject != null && oldObject instanceof CacheObject) {
			CacheObject co = (CacheObject) oldObject;
			if (co.isValid()) {
				return co.cacheObj;
				
			} else {//已经过期
				boolean success = COMMON_CACHE.replace(key, oldObject, newObj);
				if (success) {//替换成功
					return null;
				} else {
					this.getFromCommonCache(key);
				}
			}
		}
		
		return oldObject;
	}
	
	
	/**
	 * 放入通用缓存 
	 * @param key  Key
	 * @param obj 缓存对象
	 */
	public void put2CommonCache(String key, Object obj) {
		this.put2CommonCache(key, obj, -1L);
	}
	
	
	/**
	 * 放入通用缓存 
	 * @param key Key
	 * @param obj 缓存对象
	 * @param timeToLive  存活时间(ms)
	 */
	public void put2CommonCache(String key, Object obj, long timeToLive) {
		this.put2CommonCache(key, null, obj, timeToLive);
	}
	
	
	/**
	 * 放入通用缓存
	 * @param hashKey Hash key
	 * @param subKey 子key
	 * @param obj 缓存对象
	 */
	public void put2CommonCache(String hashKey, String subKey, Object obj) {
		this.put2CommonCache(hashKey, subKey, obj, -1L);
	}
	
	
	/**
	 * 放入通用缓存
	 * @param hashKey Hash key
	 * @param subKey 子key
	 * @param obj    缓存对象
	 * @param timeToLive 存活时间(ms)
	 */
	@SuppressWarnings("unchecked")
	public void put2CommonCache(String hashKey, String subKey, Object obj, long timeToLive) {
		if (obj == null) {
			return;
		}
		
		CacheObject co = new CacheObject(obj, timeToLive);
		if (subKey == null) {
			COMMON_CACHE.put(hashKey, co);
			
		} else {
			Map<String, Object> cache = null;
			
			Object currCache = COMMON_CACHE.get(hashKey);
			if (currCache != null && currCache instanceof Map) {				
				cache = (Map<String, Object>) currCache;
			}
			
			if (cache == null) {
				cache = new ConcurrentHashMap<String, Object> ();
				COMMON_CACHE.put(hashKey, cache);
			}
			
			cache.put(subKey, co);
		}	
	}
		
	/**
	 * 从通用缓存取得对象
	 * @param key KEY
	 * @return Object
	 */
	public Object getFromCommonCache(String key) {
		return this.getFromCommonCache(key, null);
	}
	
	/**
	 * 从通用缓存取得对象
	 * @param hashKey Hash Key
	 * @param subKey  子key
	 * @return Object
	 */
	@SuppressWarnings("rawtypes")
	public Object getFromCommonCache(String hashKey, String subKey) {
		Object obj = getFromCommonCacheInner(hashKey, subKey);
		
		if(obj != null && Profiler.isOpen()){
			int size = 0;
			if (obj instanceof Collection) {
				size = ((Collection) obj).size();
			} else if (obj instanceof Map) {
				size = ((Map) obj).size();
			}
			
			if (size >= 3000) {
				logger.error("DbCached 通用缓存集合过大 [hashKey: {}, subKey: {}, size: {}]", new Object[] {hashKey, subKey, size});
			} else if (size >= 200) {
				Profiler.trace("DbCached 通用缓存集合过大 [hashKey: {}, subKey: {}, size: {}]", hashKey, subKey, size);
			} 
		}
		return obj;
	}
	
	@SuppressWarnings("unchecked")
	private Object getFromCommonCacheInner(String hashKey, String subKey) {
		Object value = COMMON_CACHE.get(hashKey);
		if (value != null) {
			//最终缓存对象
			Object cacheObj = null;
			Map<String, Object> cache = null;
			
			if (subKey == null) {
				cacheObj = value;
				
			} else {
				if (value instanceof Map) {
					cache = (Map<String, Object>) value;
					cacheObj = cache.get(subKey);
				}
			}
			
			if (cacheObj != null) {
				if (cacheObj instanceof CacheObject) {
					CacheObject co = (CacheObject) cacheObj;
					if (co.isValid()) {
						return co.getCacheObj();
						
					} else {
						if (subKey == null) {
							COMMON_CACHE.remove(hashKey);
						} else {
							if (cache != null) {
								cache.remove(subKey);
							}
						}
					}					
				} else {
					return cacheObj;
				}			
			}
		}
		
		return null;
	}
	
	
	/**
	 * 从通用缓存删除
	 * @param key KEY
	 */
	public void removeFromCommonCache(String key) {
		COMMON_CACHE.remove(key);
	}
	

//	@Override
//	public void onApplicationEvent(ApplicationEvent event) {
//		if (event instanceof ContextRefreshedEvent) {
//			initEntityIdAutoIncrMap();
//		}
//		
//		if(event instanceof ContextClosedEvent){
//			if (DB_POOL_SERVICE != null && !DB_POOL_SERVICE.isShutdown()) {
//				DB_POOL_SERVICE.shutdown();
//			}
//		}
//		
//	}
	
	@SuppressWarnings("unused")
	@LifecycleMethod(lifecycle=Lifecycle.CONTEXT_CLOSEING, name="关闭dbcache")
	private void shutdown(){
		if (DB_POOL_SERVICE != null) {
			ThreadUtils.shundownThreadPool(DB_POOL_SERVICE, false);
		}
	}
	
	/**
	 * dbCache 初始化
	 */
	@SuppressWarnings("unused")
//	@LifecycleMethod(lifecycle=Lifecycle.CONFIGURATION, name="初始化dbcache")
	@PostConstruct
	private void init() {
		//初始化配置
		initCfg();
		
		//初始化实体id生成器
		initServerEntityIdGeneratorMap();
	}
	
	/**
	 * 初始化各个服ID下的各个实体所对应的主键ID最大值 (只初始化主键类型为Long的, 其他的业务自己处理)
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void initServerEntityIdGeneratorMap() {
		if (this.serverIdList == null || this.serverIdList.size() == 0) {
			return;
		}
		
		Collection<Class<?>> clzList = PackageScanner.scanPackages(entityPackages);
		if (clzList == null || clzList.size() <= 0) {
			return;
		}
		
		for (Class<?> clz: clzList) {
			//非实体
			if (!clz.isAnnotationPresent(Entity.class)) {
				continue;
			}
			
			Class idType = GenericsUtils.getSuperClassGenricType(clz, 0);
			if (idType == null) {
				continue;
			}
			
			if (idType != Long.class) {
				continue;
			}
			
			//配置的服
			for (int serverId: serverIdList) {
				ConcurrentMap<Class<?>, IdGenerator<?>> classIdGeneratorMap = getClassIdGeneratorMap(serverId);
				
				//已经注册了主键id生成器
				if (classIdGeneratorMap.containsKey(clz)) {
					continue;
				}
				
				long minValue = ServerEntityIdRule.getMinValueOfEntityId(serverId);
				long maxValue = ServerEntityIdRule.getMaxValueOfEntityId(serverId);
				
				//当前最大id
				long currMaxId = minValue;
				
				DetachedCriteria dc = DetachedCriteria.forClass(clz)
														.add(Restrictions.between(Projections.id().toString(), minValue, maxValue))
														.setProjection(Projections.max(Projections.id().toString()));
				
				List<Long> resultList = commonManager.getCommonQueryResult(dc, 0, 1);
				if (resultList != null && resultList.size() > 0) {
					Long result = resultList.get(0);
					if (result != null) {
						currMaxId = result;
					}
				} 
				
				LongGenerator idGenerator = new LongGenerator(currMaxId);
				classIdGeneratorMap.putIfAbsent(clz, idGenerator);
				
				if (logger.isInfoEnabled()) {
					logger.info("服{}： {} 的当前自动增值ID：{}", new Object[] {serverId, clz.getName(), currMaxId});
				}
			}			
		}
	}
	
	
	/**
	 * 根据实体类型自动生成主键id值
	 * @param serverId 服标识
	 * @param clazz 实体类型
	 * @return 主键id值
	 */
	private Object getIdAutoGenerateValue(int serverId, Class<?> clazz) {
		if (!containsServerId(serverId)) {
			return null;
		}
		
		ConcurrentMap<Class<?>, IdGenerator<?>> classIdGeneratorMap = getClassIdGeneratorMap(serverId);		
		IdGenerator<?> idGenerator = classIdGeneratorMap.get(clazz);
		if (idGenerator != null) {
			return idGenerator.generateId();
		}
		
		return null;
	}
	
	/**
	 * 取得服所对应的实体主键id生成器Map(不存在就创建)
	 * @param serverId 服标识
	 * @return ConcurrentMap<Class<?>, IdGenerator<?>>
	 */
	private ConcurrentMap<Class<?>, IdGenerator<?>> getClassIdGeneratorMap(int serverId) {
		ConcurrentMap<Class<?>, IdGenerator<?>> classIdGeneratorMap = SERVER_ENTITY_IDGENERATOR_MAP.get(serverId);
		if (classIdGeneratorMap == null) {
			classIdGeneratorMap = new ConcurrentHashMap<Class<?>, IdGenerator<?>>();
			SERVER_ENTITY_IDGENERATOR_MAP.putIfAbsent(serverId, classIdGeneratorMap);
		}
		
		return SERVER_ENTITY_IDGENERATOR_MAP.get(serverId);
	}
	
	
	@Override
	public void registerEntityIdGenerator(int serverId, Class<?> clazz, IdGenerator<?> idGenerator) {
		ConcurrentMap<Class<?>, IdGenerator<?>> classIdGeneratorMap = getClassIdGeneratorMap(serverId);
		
		if (idGenerator == null) {
			classIdGeneratorMap.remove(clazz);
		} else {
			classIdGeneratorMap.put(clazz, idGenerator);
		}		
	}
	
	/**
	 * 初始化配置
	 */
	private void initCfg() {
		// 加载配置文件
		Resource resource = this.applicationContext.getResource(location);		
		properties = new Properties();
		try {
			properties.load(resource.getInputStream());
		} catch (IOException e) {
			FormattingTuple message = MessageFormatter.format("DbCached 资源[{}]加载失败!", location);
			logger.error(message.getMessage(), e);
			throw new RuntimeException(message.getMessage(), e);
		}
		
		if (properties.containsKey(KEY_SERVER_ID_SET)) {
			String serverIdSet = properties.getProperty(KEY_SERVER_ID_SET);
			if (serverIdSet != null && serverIdSet.trim().length() > 0) {
				String[] serverIdArray = serverIdSet.trim().split(SPLIT);
				if (serverIdArray != null && serverIdArray.length > 0) {
					this.serverIdList = new ArrayList<Integer>(serverIdArray.length);
					
					try {
						for (String sid: serverIdArray) {
							int serverId = Integer.parseInt(sid.trim());
							//非法的服标识
							if (!ServerEntityIdRule.isLegalServerId(serverId)) {
								this.serverIdList = null;
								logger.error("服务器ID标识超出范围：{}", serverId);
								
								break;
							}
							
							if (!serverIdList.contains(serverId)) {
								serverIdList.add(serverId);
							}							
						}
						
					} catch (Exception ex) {
						this.serverIdList = null;
						logger.error("DbCached 转换服务器ID标识集合错误： {}", ex.getMessage());
					}
				}
			}
		}
		
		if (this.serverIdList == null || this.serverIdList.size() < 1) {
			FormattingTuple message = MessageFormatter.format("DbCached [{}] 配置项 '服务器ID标识集合[{}]' 配置错误!", location, KEY_SERVER_ID_SET);
			logger.error(message.getMessage());
			throw new IllegalArgumentException(message.getMessage());
		}
		
		//实体缓存最大容量
		int entityCacheSize = DEFAULT_MAX_CAPACITY_OF_ENTITY_CACHE;
		//通用缓存最大容量
		int commonCacheSize = DEFAULT_MAX_CAPACITY_OF_COMMON_CACHE;
		//入库线程池容量
		int dbPoolSize = DEFAULT_DB_POOL_CAPACITY;
		
		try {
			entityCacheSize = Integer.parseInt(properties.getProperty(KEY_MAX_CAPACITY_OF_ENTITY_CACHE));
		} catch (Exception ex) {
			logger.error("转换'{}'失败， 使用缺省值", KEY_MAX_CAPACITY_OF_ENTITY_CACHE);
		}
		
		try {
			commonCacheSize = Integer.parseInt(properties.getProperty(KEY_MAX_CAPACITY_OF_COMMON_CACHE));
		} catch (Exception ex) {
			logger.error("转换'{}'失败， 使用缺省值", KEY_MAX_CAPACITY_OF_COMMON_CACHE);
		}
		
		try {
			dbPoolSize = Integer.parseInt(properties.getProperty(KEY_DB_POOL_CAPACITY));
		} catch (Exception ex) {
			logger.error("转换'{}'失败， 使用缺省值", KEY_DB_POOL_CAPACITY);
		}
		
		entityCacheSize = entityCacheSize > 0 ? entityCacheSize: DEFAULT_MAX_CAPACITY_OF_ENTITY_CACHE;
		commonCacheSize = commonCacheSize > 0 ? commonCacheSize : DEFAULT_MAX_CAPACITY_OF_COMMON_CACHE;
		dbPoolSize = dbPoolSize > 0 ? dbPoolSize : DEFAULT_DB_POOL_CAPACITY;
		
		if (logger.isInfoEnabled()) {
			logger.info("实体缓存最大容量: {}, 通用缓存最大容量: {}, 入库线程池容量: {}", new Object[] {entityCacheSize, commonCacheSize, dbPoolSize});
		}
		
		ENTITY_CACHE = new ConcurrentLinkedHashMap.Builder<String, EntityCacheObject>().maximumWeightedCapacity(entityCacheSize).build();
		COMMON_CACHE = new ConcurrentLinkedHashMap.Builder<String, Object>().maximumWeightedCapacity(commonCacheSize).build();
		
		ThreadGroup threadGroup = new ThreadGroup("缓存模块");
		NamedThreadFactory threadFactory = new NamedThreadFactory(threadGroup, "入库线程池");
		DB_POOL_SERVICE = Executors.newFixedThreadPool(dbPoolSize, threadFactory);
	}
	
	/**
	 * 从配置的服标识ID列表中随机选择一个
	 * @return Integer
	 */
	private Integer getRandomServerId() {
		List<Integer> sidList = this.getServerIdList();
		if (sidList.isEmpty()) {
			return null;
		}
		
		int idx = 0;
		
		if (sidList.size() > 1) {
			idx = RandomUtil.nextInt(sidList.size());
		}
		
		return sidList.get(idx);
	}

	
	/**
	 * 取得服标识ID列表
	 * @return List<Integer>
	 */
	@Override
	public List<Integer> getServerIdList() {
		if (this.serverIdList == null) {
			return Collections.emptyList();
		}
		
		return Collections.unmodifiableList(serverIdList);
	}

	@Override
	public boolean isServerMerged() {
		return this.serverIdList != null && this.serverIdList.size() > 1 ? true : false;
	}

	@Override
	public boolean containsServerId(int serverId) {
		return this.serverIdList != null && this.serverIdList.contains(serverId);
	}


	/**
	 * 实体缓存辅助类
	 */
	private class EntityCacheObject {
		/**
		 * 缓存对象
		 */
		private final Object entity;
		
		/**
		 * 主键id
		 */
		private final Serializable id;
		
		/**
		 * 实体类
		 */
		private final Class<?> clazz;
		
		/**
		 * 修改版本号
		 */
		private final AtomicLong editVersion = new AtomicLong(0L);
		
		/**
		 * 入库版本号
		 */
		private long dbVersion = editVersion.get();	
		
		/**
		 * 实体更新状态
		 */
		private UpdateStatus updateStatus = UpdateStatus.UPDATE;
		
		/**
		 * 入库失败重试次数
		 */
		private int retryCount = 0;
		
		/**
		 * 内部锁
		 */
		private final Lock lock = new ReentrantLock(); 
		
		public EntityCacheObject(Object entity, Serializable id, Class<?> clazz) {
			this(entity, id, clazz, UpdateStatus.UPDATE);
		}
		
		public EntityCacheObject(Object entity, Serializable id, Class<?> clazz, UpdateStatus updateStatus) {
			this.entity = entity;
			this.id = id;
			this.clazz = clazz;
			this.updateStatus = updateStatus;
		}
		
		public void lock() {
			this.lock.lock();
		}
		
		public void unlock() {
			this.lock.unlock();
		}
		
		/**
		 * 是否同步到数据库
		 * @return true/false
		 */
		public boolean isDbSync() {
			return this.dbVersion >= this.editVersion.get();
		}
		
		/**
		 * 更新入库版本号
		 */
		public void updateDbVersion() {
			this.dbVersion = this.editVersion.get();
		}
		
		/**
		 * 更新修改版本号
		 */
		public void updateEditVersion() {
			this.editVersion.incrementAndGet();
		}
		
		/**
		 * 设置状态
		 * @param newStatus 新状态
		 */
		public void setUpdateStatus(UpdateStatus newStatus) {
			lock();
			try {
				this.updateStatus = newStatus;				
			} finally {
				unlock();
			}
		}
	}
	
	
	/**
	 * 实体更新状态
	 */
	private enum UpdateStatus {
		/**
		 * 添加
		 */
		INSERT,
		
		/**
		 * 修改
		 */
		UPDATE,
		
		/**
		 * 删除
		 */
		DELETE
	}
	
	
	/**
	 * 普通对象缓存辅助类
	 */
	private class CacheObject {
		/**
		 * 放入缓存时间
		 */
		private long createTime = System.currentTimeMillis();
		
		/**
		 * 存活时间
		 */
		private long ttl = Long.MAX_VALUE;
		
		/**
		 * 过期时间
		 */
		private long expireTime = Long.MAX_VALUE;
		
		/**
		 * 缓存对象
		 */
		private Object cacheObj;
		
		
		public CacheObject(Object cacheObj, long timeToLive) {
			this.cacheObj = cacheObj;
			if (timeToLive > 0) {
				this.ttl = timeToLive;
				this.expireTime = this.createTime + this.ttl;
			}
			
			if (this.expireTime <= 0) {
				this.expireTime = Long.MAX_VALUE;
			}
		}
		
		
		public boolean isValid() {
			return expireTime >= System.currentTimeMillis();
		}

		public Object getCacheObj() {
			return cacheObj;
		}
		
	}


	
	
	
	
	
	//-----------------------jmx------------------------------
	@Override
	public int getQueuedTaskSize() {
		return ((ThreadPoolExecutor)DB_POOL_SERVICE).getQueue().size();
	}


	@Override
	public int getPoolSize() {
		return ((ThreadPoolExecutor)DB_POOL_SERVICE).getPoolSize();
	}


	@Override
	public int getActiveThreadSize() {
		return ((ThreadPoolExecutor)DB_POOL_SERVICE).getActiveCount();
	}


	@Override
	public long getTaskCount() {
		return ((ThreadPoolExecutor)DB_POOL_SERVICE).getTaskCount();
	}


	@Override
	public long getCompletedTaskCount() {
		return ((ThreadPoolExecutor)DB_POOL_SERVICE).getCompletedTaskCount();
	}


	@Override
	public int getEntityCacheSize() {
		return ENTITY_CACHE.size();
	}


	@Override
	public int getCommonCacheSize() {
		return COMMON_CACHE.size();
	}


//	@Override
//	public void setCorePoolSize(int coreSize) {
//		((ThreadPoolExecutor)DB_POOL_SERVICE).setCorePoolSize(coreSize);
//	}
//
//
//	@Override
//	public void setMaxPoolSize(int maxSize) {
//		((ThreadPoolExecutor)DB_POOL_SERVICE).setMaximumPoolSize(maxSize);
//	}


	@Override
	public int getCorePoolSize() {
		return ((ThreadPoolExecutor)DB_POOL_SERVICE).getCorePoolSize();
	}


	@Override
	public int getMaxPoolSize() {
		return ((ThreadPoolExecutor)DB_POOL_SERVICE).getMaximumPoolSize();
	}


	@Override
	public int getLargestPoolSize() {
		return ((ThreadPoolExecutor)DB_POOL_SERVICE).getLargestPoolSize();
	}

	@Override
	public void profile() {
		String dump = ThreadUtils.dumpThreadPool("入库线程池", DB_POOL_SERVICE);
		Profiler.trace("入库线程池情况 : [{}]", dump);
		
		Profiler.trace("实体缓存大小：{}", ENTITY_CACHE.size());
		Profiler.trace("通用缓存大小：{}", COMMON_CACHE.size());
		
		Profiler.trace("锁链WeakHashMap大小： {}", LockUtils.getLockObjectCount());
	}

}
