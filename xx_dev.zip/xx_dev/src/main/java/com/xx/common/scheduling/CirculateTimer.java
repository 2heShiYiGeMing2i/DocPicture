/**
 * 
 */
package com.xx.common.scheduling;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Delayed;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.xx.common.runtime.Lifecycle;
import com.xx.common.runtime.LifecycleManager;
import com.xx.common.scheduling.impl.FixTimeDelayQueue;
import com.xx.common.scheduling.impl.NamedThreadFactory;
import com.xx.common.utility.thread.NamedRunnable;



/**
 * 
 * 循环计时器(用于每天在一些特定的时间点做一些比较简单的事情)
 * @author fansth
 *
 */
public class CirculateTimer {
	
	private final Logger log = LoggerFactory.getLogger(CirculateTimer.class);
	
	//是否已经启动运行
	private final AtomicBoolean running = new AtomicBoolean(false);
	
	//计时器线程池
	private ExecutorService executor;
	
	//主工作线程
	private Thread worker = null;
	
	//key:相对于0点的秒数  
	private ConcurrentHashMap<Integer, Set<Runnable>> timeMap = new ConcurrentHashMap<Integer, Set<Runnable>>();
	
	//延时队列
	private final FixTimeDelayQueue<Delayed> delayQueue = new FixTimeDelayQueue<Delayed>(60000L);
	
	//一天的毫秒数
	private static final long ONE_DAY_MILLIS = 24 * 3600 * 1000L;
	
	//计时器号码
	private static final AtomicInteger SN = new AtomicInteger(0);
	
	public CirculateTimer(){}
	
	public CirculateTimer(ExecutorService executor){
		this.executor = executor;
	}
	
	/**
	 * 加入时间点任务
	 * @param hour  小时数
	 * @param minute 分钟数
	 * @param second 秒数
	 * @param task 执行的任务
	 * @return
	 */
	public synchronized boolean addTimePoint(int hour, int minute, int second, CirculateTask task){
		
		boolean newTimePoint = false;
		
		int key = 3600 * hour + 60 * minute + second;
		
		Set<Runnable> taskSet = timeMap.get(key);
		if(taskSet == null){
			taskSet = new HashSet<Runnable>();
			newTimePoint = (timeMap.putIfAbsent(key, taskSet) == null);
			taskSet = timeMap.get(key);
		} 
		
		if(taskSet != null){
			taskSet.add(task);
		}
		
		//已经开始运行了并且是新加的时间点 就加入延时队列
		if(running.get() && newTimePoint){
			Date nowTime = new Date();
			Date today0AM = getToday0AM(nowTime);
			int offset0AM = (int)((nowTime.getTime() - today0AM.getTime()) / 1000);
			
			Date nexyTime = null;
			if(key > offset0AM){//还没到时间就就直接计算当天的时间
				nexyTime = new Date(today0AM.getTime() +  key * 1000);
			} else {//过了时间就+1天
				nexyTime = new Date(today0AM.getTime() +  key * 1000 + ONE_DAY_MILLIS);
			}
			DelayedEntry delayedEntry = new DelayedEntry(nexyTime, taskSet);
			delayQueue.offer(delayedEntry);
		}
		
		log.info("循环计时器加入时间点  {}:{}:{}", new Object[]{hour, minute, second});
		
		return newTimePoint;
		
	}
	
	/**
	 * 清掉循环计时任务(先中断当前执行然后清空任务再重启(如果之前就是运行状态))
	 */
	public synchronized void clear(){
		boolean run = running.compareAndSet(true, false);
		delayQueue.clear();
		timeMap.clear();
		if(worker != null){
			try {
				worker.interrupt();
			} catch (Exception e) {
				log.error("循环计时器clear异常!", e);
			} finally {
				worker = null;
			}
		}
		if(this.executor != null){
			try {
				this.executor.shutdown();
			} finally {
				this.executor = null;
			}
		}
		if(run){
			this.start();
		}
	}
	
	/**
	 * 是否为空
	 * @return
	 */
	public synchronized boolean isEmpty(){
		return timeMap.isEmpty();
	}
	
	/**
	 * 获取上一个时间点的时间
	 * @return
	 */
	public synchronized Date getLastTimePoint(Date nowTime){
		
		if(!timeMap.isEmpty()){
			
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(nowTime);
			
			calendar.set(Calendar.MILLISECOND, 0);
			
			int hour = calendar.get(Calendar.HOUR_OF_DAY);
			int minute = calendar.get(Calendar.MINUTE);
			int second = calendar.get(Calendar.SECOND);
			
			int key = hour * 3600 + 60 * minute + second;
			
			List<Integer> keyList = new ArrayList<Integer>(timeMap.keySet());
			Collections.sort(keyList);
			
			int index = 0;
			while(index < keyList.size()){
				int moveKey = keyList.get(index);
				if(key < moveKey){
					break;
				}
				index++;
			}
			
			if(index <= 0){
				int lastKey = keyList.get(keyList.size() - 1);
				calendar.add(Calendar.DAY_OF_YEAR, -1);
				calendar.set(Calendar.HOUR_OF_DAY, 0);
				calendar.set(Calendar.MINUTE, 0);
				calendar.set(Calendar.SECOND, 0);
				calendar.set(Calendar.MILLISECOND, 0);
				calendar.add(Calendar.SECOND, lastKey);
			} else {
				int lastKey =  keyList.get(index - 1);
				calendar.set(Calendar.HOUR_OF_DAY, 0);
				calendar.set(Calendar.MINUTE, 0);
				calendar.set(Calendar.SECOND, 0);
				calendar.set(Calendar.MILLISECOND, 0);
				calendar.add(Calendar.SECOND, lastKey);
			}
			return calendar.getTime();
		}
		
		return nowTime;
	}
	
	
	/**
	 * 获取上一个的时间点的 小时、分钟、秒
	 * @param nowTime
	 * @return [小时,分钟,秒]
	 */
	public synchronized int[] getLastTimePointArray(Date nowTime){
		
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(nowTime);
		
		calendar.set(Calendar.MILLISECOND, 0);
		int hour = calendar.get(Calendar.HOUR_OF_DAY);
		int minute = calendar.get(Calendar.MINUTE);
		int second = calendar.get(Calendar.SECOND);
		
		int[] array = new int[]{hour, minute, second};
		
		if(!timeMap.isEmpty()){
			
			int key = hour * 3600 + 60 * minute + second;
			
			List<Integer> keyList = new ArrayList<Integer>(timeMap.keySet());
			Collections.sort(keyList);
			
			int index = 0;
			while(index < keyList.size()){
				int moveKey = keyList.get(index);
				if(key < moveKey){
					break;
				}
				index++;
			}
			
			int lastKey = 0;
			
			if(index <= 0){
				lastKey = keyList.get(keyList.size() - 1);
			} else {
				lastKey =  keyList.get(index - 1);
			}
			
			int lastHour = lastKey / 3600;
			lastKey -= lastHour * 3600;
			
			int lastMinutes = (lastKey) / 60;
			lastKey -= lastMinutes * 60;
			
			int lastSecond = lastKey;
			
			array[0] = lastHour;
			array[1] = lastMinutes;
			array[2] = lastSecond;
			
			return array;
		}
		
		return array;
	}
	
	
	/**
	 * 获取下一个时间点的时间
	 * @return
	 */
	public synchronized Date getNextTimePoint(Date nowTime){
		if(!timeMap.isEmpty()){
			
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(nowTime);
			
			calendar.set(Calendar.MILLISECOND, 0);
			int hour = calendar.get(Calendar.HOUR_OF_DAY);
			int minute = calendar.get(Calendar.MINUTE);
			int second = calendar.get(Calendar.SECOND);
			
			int key = hour * 3600 + 60 * minute + second;
			
			List<Integer> keyList = new ArrayList<Integer>(timeMap.keySet());
			Collections.sort(keyList);
			
			int index = 0;
			while(index < keyList.size()){
				int moveKey = keyList.get(index);
				if(key < moveKey){
					break;
				}
				index++;
			}
			
			if(index >= keyList.size()){
				int lastKey = keyList.get(0);
				calendar.add(Calendar.DAY_OF_YEAR, 1);
				calendar.set(Calendar.HOUR_OF_DAY, 0);
				calendar.set(Calendar.MINUTE, 0);
				calendar.set(Calendar.SECOND, 0);
				calendar.set(Calendar.MILLISECOND, 0);
				calendar.add(Calendar.SECOND, lastKey);
			} else {
				int lastKey =  keyList.get(index);
				calendar.set(Calendar.HOUR_OF_DAY, 0);
				calendar.set(Calendar.MINUTE, 0);
				calendar.set(Calendar.SECOND, 0);
				calendar.set(Calendar.MILLISECOND, 0);
				calendar.add(Calendar.SECOND, lastKey);
			}
			return calendar.getTime();
		} 
		
		return nowTime;
	}
	
	
	
	/**
	 * 获取下一个的时间点的 小时、分钟、秒
	 * @param nowTime
	 * @return [小时,分钟,秒]
	 */
	public synchronized int[] getNextTimePointArray(Date nowTime){
		
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(nowTime);
		
		calendar.set(Calendar.MILLISECOND, 0);
		int hour = calendar.get(Calendar.HOUR_OF_DAY);
		int minute = calendar.get(Calendar.MINUTE);
		int second = calendar.get(Calendar.SECOND);
		
		int[] array = new int[]{hour, minute, second};
		
		if(!timeMap.isEmpty()){
			
			int key = hour * 3600 + 60 * minute + second;
			
			List<Integer> keyList = new ArrayList<Integer>(timeMap.keySet());
			Collections.sort(keyList);
			
			int index = 0;
			while(index < keyList.size()){
				int moveKey = keyList.get(index);
				if(key < moveKey){
					break;
				}
				index++;
			}
			
			int nextKey = 0;
			
			if(index >= keyList.size()){
				nextKey = keyList.get(0);
			} else {
				nextKey =  keyList.get(index);
			}
			
			int nextHour = nextKey / 3600;
			nextKey -= nextHour * 3600;
			
			int nextMinutes = (nextKey) / 60;
			nextKey -= nextMinutes * 60;
			
			int nextSecond = nextKey;
			
			array[0] = nextHour;
			array[1] = nextMinutes;
			array[2] = nextSecond;
			
			return array;
		} 
		
		return array;
	}
	
	
	
	/**
	 * 获取当天的0点时间
	 * @param nowTime 当前时间
	 * @return
	 */
	private static Date getToday0AM(Date nowTime){
		Calendar cal = Calendar.getInstance();
		cal.setTime(nowTime);
		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		cal.set(Calendar.MILLISECOND, 0);
		return cal.getTime();
	}
	
	//启动循环计时器
	public synchronized void start(){
		
		if(running.get()){
			log.info("循环计数器已经运行!");
			return;
		}
		
		delayQueue.clear();
		
		if(timeMap != null){
			
			Date nowTime = new Date();
			
			Date today0AM = getToday0AM(nowTime);
			
			int offset0AM = (int)((nowTime.getTime() - today0AM.getTime()) / 1000);
			
			for(Entry<Integer, Set<Runnable>> entry : timeMap.entrySet()){
				Date nexyTime = null;
				if(entry.getKey() > offset0AM){
					nexyTime = new Date(today0AM.getTime() +  entry.getKey() * 1000);
				} else {
					nexyTime = new Date(today0AM.getTime() +  entry.getKey() * 1000 + ONE_DAY_MILLIS);
				}
				DelayedEntry delayedEntry = new DelayedEntry(nexyTime, entry.getValue());
				delayQueue.offer(delayedEntry);
			}
			
			if(this.executor == null){
//				this.executor = new ThreadPoolExecutor(1, 10, 0L, TimeUnit.MILLISECONDS, new LinkedBlockingQueue<Runnable>(10), new NamedThreadFactory(new ThreadGroup("循环任务线程池"), "循环任务线程"));
				this.executor = Executors.newFixedThreadPool(1, new NamedThreadFactory(new ThreadGroup("循环任务线程池  " + SN.incrementAndGet()), "循环任务线程"));
			}
			
			running.set(true);
			
			if(worker == null){
				
				worker = new Thread(new Runnable() {
					
					@Override
					public void run() {
						
						while(running.get()){
							
							Delayed delayed = null;
							
							try {
								delayed = delayQueue.take();
								
								if(delayed != null){
									DelayedEntry delayedEntry = (DelayedEntry)delayed;
									
									//推迟一天
									delayedEntry.setNextTime(new Date(delayedEntry.getNextTime().getTime() + ONE_DAY_MILLIS));
									delayQueue.offer(delayedEntry);
									
									Set<Runnable> taskSet = delayedEntry.getTaskSet();

									for(Runnable task : taskSet){
										CirculateTask circulateTask = (CirculateTask)task;
										executor.submit(task);
										log.error("时间点任务 {} 运行...", circulateTask.getName());
									}
								
								}
								
							} catch (Exception e) {
								if(!(e instanceof InterruptedException)){
									log.error("循环计时器工作者线程出错!",e);
								}
								continue;
							}
						}
					}
					
				}, "循环计时器工作线程");
				
			}//if(worker == null)
			
			worker.start();
			
			LifecycleManager.registerLifecycle(Lifecycle.CONTEXT_CLOSEING, new NamedRunnable() {
				
				@Override
				public void run() {
					CirculateTimer.this.stop();
				}
				
				@Override
				public String getName() {
					return "关闭循环计时器";
				}
			});
			
			log.error("启动循环计时器工作线程...");
			
		} else {
			log.info("没有时间序列!");
		}
	}
	
	
	//停止循环计时器
	public synchronized void stop(){
		running.set(false);
		if(worker != null){
			try {
				worker.interrupt();
			} catch (Exception e) {
				log.error("循环计时器clear异常!", e);
			} finally {
				worker = null;
			}
		}
		if(this.executor != null){
			try {
				this.executor.shutdownNow();
			} finally {
				this.executor = null;
			}
		}
		log.error("循环计时器停止运行...");
	}
	
	
	//延时元素
	private class DelayedEntry implements Delayed {
		
		//下次时间
		private Date nextTime;
		
		//时间点上的任务
		private Set<Runnable> taskSet;
		
		public Date getNextTime() {
			return nextTime;
		}


		public void setNextTime(Date nextTime) {
			this.nextTime = nextTime;
		}


		public Set<Runnable> getTaskSet() {
			return taskSet;
		}

		@SuppressWarnings("unused")
		public void setTaskSet(Set<Runnable> taskSet) {
			this.taskSet = taskSet;
		}

		public DelayedEntry(Date nextTime, Set<Runnable> taskSet){
			this.nextTime = nextTime;
			this.taskSet = taskSet;
		}
		
		
		@Override
		public int compareTo(Delayed o) {
			if(this == o){
				return 0;
			}
			
			long diff = 0;
			
			if(o instanceof DelayedEntry){
				DelayedEntry other = (DelayedEntry)o;
				diff = this.nextTime.getTime() - other.nextTime.getTime();
			} else {
				diff = (getDelay(TimeUnit.MILLISECONDS) - o.getDelay(TimeUnit.MILLISECONDS));
			}
			
		    return (diff == 0) ? 0 : ((diff < 0) ? -1 : 1);
		}

		@Override
		public long getDelay(TimeUnit unit) {
			return unit.convert(this.nextTime.getTime() - System.currentTimeMillis(), TimeUnit.MILLISECONDS);
		}
	}
	
	
	//循环任务
	public static interface CirculateTask extends Runnable{
		public  String getName();
	}
	
	public static void main(String[] args) throws InterruptedException {
		
		CirculateTimer circulateTimer = new CirculateTimer();
		
		circulateTimer.addTimePoint(12, 35, 30, new CirculateTask() {
			
			@Override
			public void run() {
				System.out.println("1530");
			}
			
			@Override
			public String getName() {
				return "test1";
			}
		});
		
		
		circulateTimer.addTimePoint(13, 35, 30, new CirculateTask() {
			
			@Override
			public void run() {
				System.out.println("1530");
			}
			
			@Override
			public String getName() {
				return "test1";
			}
		});
		
		System.out.println(Arrays.toString(circulateTimer.getNextTimePointArray(new Date())));
		System.out.println(Arrays.toString(circulateTimer.getLastTimePointArray(new Date())));
		
//		circulateTimer.addTimePoint(11, 20, 0, new CirculateTask<Map<String, Object>>() {
//			
//			@Override
//			public void run() {
//				System.out.println("1500");
//			}
//			
//			@Override
//			public String getName() {
//				return "test2";
//			}
//		});
		
		circulateTimer.start();
		
		circulateTimer.stop();
		
	}

}
