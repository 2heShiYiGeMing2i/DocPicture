/**
 * 
 */
package com.xx.common.basedb;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.xx.common.basedb.BasedbServiceBean.KeyBuilder;
import com.xx.common.basedb.anno.Index;
import com.xx.common.util.BeanUtil;
import com.xx.common.utility.ReflectionUtility;
import com.xx.common.utility.rhino.RhinoHelper;

/**
 * @author fasnth
 *
 */
public class IndexBuilder {
	
	private static final Logger logger = LoggerFactory.getLogger(IndexBuilder.class);
	
	/**
	 * 索引访问者
	 */
	public static class IndexVisitor{

		
		private final String name;
		private final List<Field> fields = new ArrayList<Field>();
		private final List<String> expressions = new ArrayList<String>();
		
		public IndexVisitor(String indexName) {
			this.name = indexName;
		}
		
		/**
		 * 加入索引字段
		 * @param fieldList
		 */
		public void attachField(Field... fieldList){
			if(fieldList != null && fieldList.length > 0){
				for(Field field : fieldList){
					fields.add(field);
					Index index = field.getAnnotation(Index.class);
					if(index != null && index.expression() != null && index.expression().trim().length() > 0){
						expressions.add(index.expression().trim());
					}
				}
				
			}
		}
		
		public String getName() {
			return name;
		}

		/**
		 * 获取索引键
		 * @param obj
		 * @return
		 */
		public String getIndexKey(Object obj) {
			if(obj != null){
				
				Object[] fieldValues = null;
				if(this.fields != null && !this.fields.isEmpty()){
					fieldValues = new String[fields.size()];
					
					for(int i = 0; i < fields.size(); i ++){
						Field field = fields.get(i);
						field.setAccessible(true);
						Object fieldValue = ReflectionUtility.getField(field, obj);
						
						if(fieldValue != null){
							fieldValues[i] = String.valueOf(fieldValue);
						} else {
							fieldValues[i] = "";
						}
							
					}
					
				}
				
				return KeyBuilder.buildIndexKey(obj.getClass(), name, fieldValues);
			}
			
			return null;
		}
		
		/**
		 * 判断对象是否可索引
		 * @param obj
		 * @return true-可以索引  false-不可以索引
		 */
		@SuppressWarnings("unchecked")
		public boolean indexable(Object obj){
			if(obj != null){
				if(this.expressions != null && !this.expressions.isEmpty()){
					Map<String, Object> ctx = BeanUtil.buildMap(obj);
					for(String expression : this.expressions){
						if(!RhinoHelper.invoke(expression, ctx, Boolean.class)){
							return false;
						}
					}
				}
				return true;
			}
			return false;
		}
		
		
		
		@Override
		public int hashCode(){
			return name != null ? name.hashCode() : 0;
		}
		
		@Override
		public boolean equals(Object o) {
			if (o == this) {
				return true;
			}
			
			if (!(o instanceof IndexVisitor)) {
	            return false;
			}
			
			IndexVisitor rhs = (IndexVisitor)o;
			return new EqualsBuilder().append(this.name, rhs.name).isEquals();
		}
		
		public List<Field> getFields() {
			return fields;
		}
		
	
	}
	
	
	
	

	/**
	 * 创建索引
	 * @param clz
	 * @return
	 */
	public static Map<String, IndexVisitor> createIndexVisitors(Class<?> clz) {
		Field[] fields = ReflectionUtility.getDeclaredFieldsWith(clz, Index.class);
		
		Map<String, IndexVisitor> indexMap = new HashMap<String, IndexVisitor>();
		for (Field field : fields) {
			Index index = field.getAnnotation(Index.class);
			if(index != null){
				IndexVisitor indexVisitor = (IndexVisitor)indexMap.get(index.name());
				if(indexVisitor == null){
					indexVisitor = new IndexVisitor(index.name());
					indexMap.put(index.name(), indexVisitor);
				}
				indexVisitor.attachField(field);
			}
		}
		
		if(!indexMap.isEmpty()){
			for(IndexVisitor indexVisitor : indexMap.values()){
				List<Field> fieldList = indexVisitor.getFields();
				if(fieldList != null && fieldList.size() > 1){
					Collections.sort(fieldList, new Comparator<Field>(){

						@Override
						public int compare(Field f1, Field f2) {
							Index index1 = f1.getAnnotation(Index.class);
							Index index2 = f2.getAnnotation(Index.class);
							return index1.order() < index2.order() ? -1 : 1;
						}
					});
					
				}
			}
		}
		
		return indexMap;
	}
	
}
