/**
 * 
 */
package com.xx.common.utility.cas;

import java.util.concurrent.atomic.AtomicLong;

import javax.persistence.Transient;



/**
 * 抽象的受{@link CASTransaction}管理的类
 * @author fansth
 *
 */
public abstract class CASAble{
	
	/**
	 * 版本号
	 */
	@Transient
	private transient AtomicLong revision = new AtomicLong(0);

	/**
	 * 获取版本号
	 * @return
	 */
	public long getRevision(){
		return this.revision.get();
	}
	
	/**
	 * 变更版本号
	 */
	public final void increaseRevision(){
		this.revision.incrementAndGet();
	}
	
	
}
