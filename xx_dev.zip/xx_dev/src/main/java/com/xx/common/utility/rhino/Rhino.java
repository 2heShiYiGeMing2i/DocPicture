package com.xx.common.utility.rhino;

import java.util.Map;
import java.util.Map.Entry;

import org.mozilla.javascript.Context;
import org.mozilla.javascript.ContextFactory;
import org.mozilla.javascript.Script;
import org.mozilla.javascript.Scriptable;

import com.googlecode.concurrentlinkedhashmap.ConcurrentLinkedHashMap;

/**
 * Mozilla Rhino 公式解析器
 * 
 * @author Hyint
 */
public class Rhino {

	/** ThreadLocal */
	private static final ThreadLocal<Scriptable> THREAD_LOCALS = new ThreadLocal<Scriptable>();
	/** 公式缓存 */
	private static final ConcurrentLinkedHashMap<String, Script> SCRIPT_CACHE = new ConcurrentLinkedHashMap.Builder<String, Script>().maximumWeightedCapacity(10000).build();
	
	/**
	 * 获得脚本的作用域
	 * 
	 * @return {@link Scriptable}
	 */
	protected static Scriptable getScope() {
		Scriptable scope = THREAD_LOCALS.get();
		if (scope == null) {
			ContextFactory global = ContextFactory.getGlobal();
			Context context = global.enterContext();
			context.setWrapFactory(new MapWarperFactory());

			scope = context.initStandardObjects();
			THREAD_LOCALS.set(scope);
		}
		return scope;
	}

	/**
	 * 计算公式获得计算结果
	 * 
	 * @param  expression		公式
	 * @param  ctx				上下文
	 * @return {@link Object}	返回值
	 */
	public static Object invoke(String expression, Map<String, ?> ctx) {
		Script exp = SCRIPT_CACHE.get(expression);
		Context context = Context.enter();
		try {
			if (exp == null) {
				exp = context.compileString(expression, "<expr>", -1, null);
				SCRIPT_CACHE.putIfAbsent(expression, exp);
			}

			exp = SCRIPT_CACHE.get(expression);
			Scriptable args = context.newObject(getScope());
			if (ctx != null && !ctx.isEmpty()) {
				for (Entry<String, ?> e : ctx.entrySet()) {
					args.put(e.getKey(), args, e.getValue());
				}
			}
			return exp.exec(context, args);
		} finally {
			Context.exit();
		}
	}
}
