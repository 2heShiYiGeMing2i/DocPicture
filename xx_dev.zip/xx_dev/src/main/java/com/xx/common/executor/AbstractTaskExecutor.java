/**
 * 
 */
package com.xx.common.executor;

import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.xx.common.profile.Profileable;
import com.xx.common.profile.Profiler;
import com.xx.common.runtime.Lifecycle;
import com.xx.common.runtime.LifecycleMethod;
import com.xx.common.util.ThreadUtils;
import com.xx.common.utility.thread.NamedThreadFactory;

/**
 * 抽象任务执行者
 * @author fansth
 *
 */
public abstract class AbstractTaskExecutor implements TaskExecutor, InitializingBean, Profileable {
	
	
	protected final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	
	protected ThreadPoolExecutor executor;
	
	/**
	 * 任务线程池名称
	 * @return
	 */
	public abstract String getName();

	/**
	 * 核心大小
	 */
	@Autowired(required = false)
	@Qualifier("default_executor_core_size")
	protected int corePoolSize = 5;
	
	/**
	 * 最大大小
	 */
	@Autowired(required = false)
	@Qualifier("default_executor_max_size")
	protected int maxPoolSize = 20;
	
	/**
	 * 空闲毫秒数
	 */
	@Autowired(required = false)
	@Qualifier("default_executor_keep_alive_millis")
	protected long keepAliveMillis = 1000L;
	
	@Override
	public void execute(Runnable command) {
		this.executor.execute(command);
	}
	
	private void construct(){
		ThreadGroup group = new ThreadGroup(this.getName());
		NamedThreadFactory threadFactory = new NamedThreadFactory(group, "处理");
		executor = new ThreadPoolExecutor(this.corePoolSize, 
										  this.maxPoolSize, 
										  this.keepAliveMillis, 
										  TimeUnit.MILLISECONDS, 
										  new LinkedBlockingQueue<Runnable>(), 
										  threadFactory, 
										  new RejectedExecutionHandler(){

											@Override
											public void rejectedExecution(Runnable r, ThreadPoolExecutor executor) {
												logger.error(getName() + "线程已满,拒绝接收提交任务,改为同步执行");
												try {
													r.run();
												} catch (Exception e) {
													logger.error(getName() + "任务执行异常!", e);
												};
										}});
	
	}
	
	
	@LifecycleMethod(lifecycle=Lifecycle.CONTEXT_CLOSEING, name="关闭任务执行者")
	protected void destory() {
		if (executor != null) {
			ThreadUtils.shundownThreadPool(this.executor, false);
		}
	}
	
	
	public int getCorePoolSize() {
		return corePoolSize;
	}

	public void setCorePoolSize(int corePoolSize) {
		this.corePoolSize = corePoolSize;
	}
	
	public int getMaxPoolSize() {
		return maxPoolSize;
	}

	public void setMaxPoolSize(int maxPoolSize) {
		this.maxPoolSize = maxPoolSize;
	}

	public long getKeepAliveMillis() {
		return keepAliveMillis;
	}
	
	public void setKeepAliveMillis(long keepAliveMillis) {
		this.keepAliveMillis = keepAliveMillis;
	}
	
	@Override
	public void profile() {
		String dump = ThreadUtils.dumpThreadPool(this.getName(), executor);
		Profiler.trace("{} 情况 : [{}]", this.getName(), dump);
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		this.overrideProperties();
		this.construct();
	}
	
	
	/**
	 * 覆盖属性
	 */
	public abstract void overrideProperties();
	

}
