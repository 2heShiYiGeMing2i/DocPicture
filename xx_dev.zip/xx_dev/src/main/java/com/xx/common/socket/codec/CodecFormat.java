package com.xx.common.socket.codec;

/**
 * 编解码格式
 * 
 * @author bingshan
 */
public enum CodecFormat {
	
	/**
	 * 0-JSON
	 */
	JSON

}
