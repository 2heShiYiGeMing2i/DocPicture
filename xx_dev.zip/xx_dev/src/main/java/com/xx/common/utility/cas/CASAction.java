/**
 * 
 */
package com.xx.common.utility.cas;

/**
 * CAS行为接口
 * @author fansth
 *
 */
public interface CASAction {

	/**
	 * 需要在事务内做的工作(确保只有纯内存操作)
	 * @return
	 */
	Object doAction();
	
}
