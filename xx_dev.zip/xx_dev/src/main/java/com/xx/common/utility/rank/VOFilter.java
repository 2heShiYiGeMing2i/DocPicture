/**
 * 
 */
package com.xx.common.utility.rank;

/**
 * vo过滤器
 * @author fansth
 *
 */
public interface VOFilter<VO> {

	/**
	 * 过滤方法
	 * @param vo
	 * @return true-过滤掉  false-留下来不过滤掉
	 */
	boolean filter(VO vo);
	
}
