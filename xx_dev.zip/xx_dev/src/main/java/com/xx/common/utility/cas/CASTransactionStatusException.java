/**
 * 
 */
package com.xx.common.utility.cas;

/**
 * @author fansth
 *
 */
public class CASTransactionStatusException extends RuntimeException {
	
	private static final long serialVersionUID = 4006770451905099841L;

	public CASTransactionStatusException(String message){
		super(message);
	}

}
