/**
 * 
 */
package com.xx.common.utility.upgrade;

/**
 * 升级结果
 * @author fansth
 *
 */
public class UpgradeResult {
	
	/**
	 * 是否发生了升级
	 */
	private boolean upgrade;
	
	/**
	 * 升级后当前的等级
	 */
	private int currentLevel;
	
	/**
	 * 升级后当前的成长值
	 */
	private long upgradeValue;
	
	
	public UpgradeResult(boolean upgrade, int currentLevel, long upgradeValue){
		this.upgrade = upgrade;
		this.currentLevel = currentLevel;
		this.upgradeValue = upgradeValue;
	}
	

	public boolean isUpgrade() {
		return upgrade;
	}

	public void setUpgrade(boolean upgrade) {
		this.upgrade = upgrade;
	}

	public int getCurrentLevel() {
		return currentLevel;
	}

	public void setCurrentLevel(int currentLevel) {
		this.currentLevel = currentLevel;
	}

	public long getUpgradeValue() {
		return upgradeValue;
	}

	public void setUpgradeValue(long upgradeValue) {
		this.upgradeValue = upgradeValue;
	}

	
}
