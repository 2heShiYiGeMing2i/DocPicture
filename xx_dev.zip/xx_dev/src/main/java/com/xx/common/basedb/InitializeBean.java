/**
 * 
 */
package com.xx.common.basedb;

/**
 * 初始化基础数据接口
 * @author fansth
 *
 */
public interface InitializeBean {

	/**
	 * 在属性被设置完后(索引数据前)做一些处理
	 */
	void afterPropertiesSet();
	
}
