/**
 * 
 */
package com.xx.common.basedb;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.junit.Assert;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.helpers.FormattingTuple;
import org.slf4j.helpers.MessageFormatter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.xx.common.basedb.anno.Resource;
import com.xx.common.runtime.Lifecycle;
import com.xx.common.runtime.LifecycleMethod;
import com.xx.common.utility.PackageScanner;
import com.xx.dev.constant.SysKey;

/**
 * 基础数据服务类实现
 * @author fansth
 *
 */
@Component
public class BasedbServiceBean implements BasedbService{
	
	private static final Logger log = LoggerFactory.getLogger(BasedbServiceBean.class);
	
	@SuppressWarnings("rawtypes")
	private ConcurrentHashMap<Class, Storage>  storages = new ConcurrentHashMap<Class, Storage>(50);
	
	//监听器列表
	private List<BasedbListener> listeners = new ArrayList<BasedbListener>();
	
	//基础数据表所在的目录
	@Autowired(required = false)
	@Qualifier("basedb_location")
	private String resourceLocation = "xml_db" + File.separator; 
	
	//基础数据实体类所在的包
	@Autowired(required = false)
	@Qualifier("basedb_package")
	//private String resourcePackage = "com.my9yu.**.basedb.model";
	private String resourcePackage = "com.my9yu.**.model";
	
	@Autowired
	private ApplicationContext applicationContext;
	
	
	@SuppressWarnings("unused")
	@LifecycleMethod(lifecycle=Lifecycle.BASE_DB_LOAD, name="加载基础数据")
	private void initialize(){
		
		Date openServerTime = SysKey.SERVER_OPEN_TIME.getDate();
		if (openServerTime == null) {
			openServerTime = new Date();
		}
		
		//注册监听器
		this.registerListener();
		
		Collection<Class<?>> clazzCollection = PackageScanner.scanPackages(resourcePackage);
		
		if(clazzCollection != null && !clazzCollection.isEmpty()){
			for(Class<?> clazz : clazzCollection){
				try {
					if(clazz.isAnnotationPresent(Resource.class)){
						this.initializeStorage(clazz, openServerTime);
					}
				} catch (Exception e) {
					FormattingTuple message = MessageFormatter.format("加载  {} 基础数据时出错!", clazz.getName());
					log.error(message.getMessage(), e);
				}
			}
			
		} else {
			FormattingTuple message = MessageFormatter.format("在 {} 包下没有扫描到实体类!", resourcePackage);
			log.error(message.getMessage());
		}
		
		Class<?>[] classArray = new Class<?>[storages.size()];
		storages.keySet().toArray(classArray);
		
		this.fireBasedbReload(classArray);
		
		log.error("基础数据加载完毕...");
	}
	
	
	//激活全部数据已加载事件
	private void fireBasedbReload(Class<?>...classes){
		if(this.listeners != null && !this.listeners.isEmpty()){
			for(BasedbListener listener : this.listeners){
				try {
					listener.onBasedbReload(classes);
				} catch (Exception e) {
					log.error("BasedbListener 出错!", e);
				}
			}
		}
	}
	
	
	//注册监听器
	private void registerListener(){
		Map<String, BasedbListener> listenerMap = this.applicationContext.getBeansOfType(BasedbListener.class);
		if(listenerMap != null){
			for(BasedbListener listener : listenerMap.values()){
				this.listeners.add(listener);
			}
		}
	};
	
	
	/**
	 * 初始化实体类
	 * @param clazz
	 * @param versionTime 版本时间
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void initializeStorage(Class clazz, Date versionTime){
		Storage storage = storages.get(clazz);
		if(storage == null){
			storage = new Storage(clazz, this.resourceLocation, this.applicationContext);
			storages.putIfAbsent(clazz, storage);
			storage = storages.get(clazz);
		}
		storage.reload(versionTime);
	}
	
	@SuppressWarnings("rawtypes")
	private Storage getStorage(Class clazz){
		return storages.get(clazz);
	}
	
	
	//------------------------------------------接口方法---------------------------------------

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public <T> T get(Class<T> clazz, Object id) {
		Storage storage = this.getStorage(clazz);
		if(storage != null){
			return (T)storage.get(id);
		}
		return null;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public <T> List<T> listByIndex(Class<T> clazz, String indexName, Object... indexValues) {
		Storage storage = this.getStorage(clazz);
		if(storage != null){
			List list = storage.getIndex(indexName, indexValues);
			return list;
		}
		return null;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public <T> T getByUnique(Class<T> clazz, String indexName, Object... indexValues) {
		Storage storage = this.getStorage(clazz);
		if(storage != null){
			List list = storage.getIndex(indexName, indexValues);
			return list != null && !list.isEmpty() ? (T)list.get(0) : null;
		}
		return null;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public <T> List<T> listAll(Class<T> clazz) {
		Storage storage = this.getStorage(clazz);
		if(storage != null){
			return storage.listAll();
		}
		return null;
	}


	@Override
	public void reloadAll() {
		Class<?>[] classArray = new Class<?>[storages.size()];
		storages.keySet().toArray(classArray);
		this.reload(classArray);
	}
	
	/**
	 * 内部辅助类用于构建索引键
	 * <p>
	 * 通用key构建规则： className&indexName#indexValue[0]^indexValue[1]
	 * <li>className : 类的全限定名  如:com.my9yu.BaseModel </li>
	 * <li>indexName : 索引名  如: level </li>
	 * <li>indexValue : 索引值数组  如: [1,2,3] </li>
	 * </p>
	 */
	public static class KeyBuilder {
		
		public static String buildIndexKey(Class<?> clazz, String indexName, Object... indexValues){
			StringBuilder builder = new StringBuilder();
			if(clazz != null){
				builder.append(clazz.getName()).append("&");
			}
			if(indexName != null){
				builder.append(indexName).append("#");
			}
			if(indexValues != null && indexValues.length > 0){
				return builder.append(StringUtils.arrayToDelimitedString(indexValues, "^")).toString();
			}
			return builder.toString();
		}
	}


	@Override
	public void reload(Class<?>... classes) {
		
		Date openServerTime = SysKey.SERVER_OPEN_TIME.getDate();
		if (openServerTime == null) {
			openServerTime = new Date();
		}
		
		//过滤掉不可以重新加载的表
		List<Class<?>> selectedClasses = new ArrayList<Class<?>>();
		for(Class<?> clazz : classes){
			Resource resource = clazz.getAnnotation(Resource.class);
			Assert.assertNotNull(resource);
			if(resource.reloadable()){
				selectedClasses.add(clazz);
			}
		}
		Class<?>[] classArray = new Class<?>[selectedClasses.size()];
		selectedClasses.toArray(classArray);
		
		for(Class<?> clazz : classArray){
			try {
				this.initializeStorage(clazz, openServerTime);
			} catch (Exception e) {
				FormattingTuple message = MessageFormatter.format("加载 {} 类时出错!", clazz.getName());
				log.error(message.getMessage(), e);
			}
		}
		this.fireBasedbReload(classArray);
	}


	@SuppressWarnings("rawtypes")
	@Override
	public Number getMinValue(Class<?> clazz, String minmaxName) {
		Storage storage = this.getStorage(clazz);
		if(storage != null){
			Number[] minmax = storage.getMinMax(minmaxName);
			if(minmax != null && minmax.length > 0){
				Number min = minmax[0];
				if(min != null){
					return min;
				}
			}
		}
		return 0;
	}


	@SuppressWarnings("rawtypes")
	@Override
	public Number getMaxValue(Class<?> clazz, String minmaxName) {
		Storage storage = this.getStorage(clazz);
		if(storage != null){
			Number[] minmax = storage.getMinMax(minmaxName);
			if(minmax != null && minmax.length > 1){
				Number max = minmax[1];
				if(max != null){
					return max;
				}
			}
		}
		return 0;
	}


	@Override
	public List<?> listId(Class<?> clazz) {
		Storage<?> storage = this.getStorage(clazz);
		if(storage != null){
			return storage.listId();
		}
		return null;
	}

}
