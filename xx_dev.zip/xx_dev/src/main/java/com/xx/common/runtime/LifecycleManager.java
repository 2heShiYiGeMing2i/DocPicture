/**
 * 
 */
package com.xx.common.runtime;

import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import org.apache.mina.util.ConcurrentHashSet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.xx.common.utility.thread.NamedRunnable;

/**
 * 进程生命周期管理者
 * @author fansth
 *
 */
public abstract class LifecycleManager{
	
	private static Logger logger = LoggerFactory.getLogger(LifecycleManager.class);
	
	private static final ConcurrentMap<Lifecycle, Set<NamedRunnable>> lifecycle_map = new ConcurrentHashMap<Lifecycle, Set<NamedRunnable>>();
	
	/**
	 * 变换生命周期进入指定的生命期
	 * @param lifecycle
	 */
	public static void transferLifecycle(Lifecycle lifecycle){
		logger.error("服务器进入 [{}] 阶段处理...", lifecycle);
		Set<NamedRunnable> set = lifecycle_map.get(lifecycle);
		if(set != null){
			for(NamedRunnable runnable : set){
				try {
					logger.error("开始执行 [{}] 阶段 [{}] 任务", lifecycle, runnable.getName());
					runnable.run();
					logger.error("完成执行 [{}] 阶段 [{}] 任务", lifecycle, runnable.getName());
				} catch (Exception e) {
					logger.error("执行 [{}] 阶段 [{}] 任务出错!", lifecycle, runnable.getName());
				} 
			}
		}
		logger.error("服务器完成[{}] 阶段处理...", lifecycle);
	} 
	
	
	/**
	 * 注册生命周期方法
	 * @param lifecycle
	 * @param runnable
	 */
	public static void registerLifecycle(Lifecycle lifecycle, NamedRunnable runnable){
		Set<NamedRunnable> set = lifecycle_map.get(lifecycle);
		if(set == null){
			set = new ConcurrentHashSet<NamedRunnable>();
			lifecycle_map.putIfAbsent(lifecycle, set);
			set = lifecycle_map.get(lifecycle);
		}
		set.add(runnable);
	}
	

}
