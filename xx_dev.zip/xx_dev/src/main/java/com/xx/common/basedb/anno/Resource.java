package com.xx.common.basedb.anno;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 资源数据对象声明注释
 * @author frank
 */
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
public @interface Resource {
	
	/** 资源后缀*/
	String suffix() default "xml";
	
	/** 资源类型*/
	String type() default "json";
	
	/** 是否可以重新加载*/
	boolean reloadable() default true;
	
}
