/**
 * 
 */
package com.xx.common.utility.rank;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.xx.common.util.BeanUtil;
import com.xx.common.utility.Page;
import com.xx.common.utility.conversion.ConverterService;

/**
 * 精巧又可爱的排序对象
 * @author fansth
 *
 */
public class SmartRank<T extends Rankable> {
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	/**
	 * 列表最大排名数(比如前30名参与排名这里就是30)
	 */
	private int maxSize = Integer.MAX_VALUE;
	
	/**
	 * 标识排名是否有脏数据了
	 */
	private volatile boolean dirty = false;
	
	/**
	 * key: 主键 value:可排名对象
	 */
	private final ConcurrentMap<Long, T> rank_map = new ConcurrentHashMap<Long, T>();
	
	/**
	 * 排名锁
	 */
	private final ReadWriteLock lock = new ReentrantReadWriteLock();
	
	/**
	 * 排名列表
	 */
	private final List<Long> rankList = new ArrayList<Long>();
	
	/**
	 * vo转换器
	 */
	private ConverterService converterService;
	
	/**
	 * 进入排名的门槛(当排名大小达到maxSize时出现排名门槛)
	 */
	private T threshold;

	public SmartRank(List<T> orderList){
		this.initialize(orderList);
	}
	
	public SmartRank(List<T> orderList, int maxSize){
		this(orderList);
		this.maxSize = maxSize;
	}
	
	
	public SmartRank(int maxSize){
		this.maxSize = maxSize;
	}
	
	public SmartRank(){
	}
	
	/**
	 * 将指定的列表作为当前排序列表
	 * @param orderList
	 */
	public void initialize(List<T> orderList){
		this.rankList.clear();
		this.rank_map.clear();
		int rank = 0;
		for(T t : orderList){
			this.rankList.add(t.getOwnerId());
			rank_map.put(t.getOwnerId(), t);
			t.setRank(++rank);
		}
		this.threshold = this.getLastOne();
	}
	
	public int getMaxSize() {
		return maxSize;
	}

	public void setMaxSize(int maxSize) {
		this.maxSize = maxSize;
	}

	/**
	 * 将当前的排名与rankable比较,如果发现rankable将导致排名列表能会变化则将reorder=true
	 * @param rankable
	 * @return true-影响了排名 false-没有影响排名
	 */
	public boolean compareAndRefresh(T rankable){
		lock.writeLock().lock();
		try {
			boolean rankChanged = false;
			
			if(dirty){//首先发现是脏的就先重新排一下
				this.reorder();
				this.dirty = false;
				this.threshold = this.getLastOne();
				rankChanged = true;
			} 
			
			if(rank_map.containsKey(rankable.getOwnerId())){//原来就在排名中
				T existsOne = rank_map.get(rankable.getOwnerId());
				BeanUtil.copyProperties(rankable, existsOne, "rank");
				if(existsOne.getRank() > 1){
					T refer = this.getByRank(existsOne.getRank() - 1);//前一名
					if(refer == null || !this.compareBefore(refer, existsOne)){//修改后如果自己前面的不再在自己前面则需要重新排名
						this.dirty = true;
						rankChanged = true;
					}
				}
				
			} else {
				if(this.rankList.size() >= this.maxSize){//排名列表已满则与最后一个比较看是否比他大如果比他大那么就将他挤出来并重新排名
					if(threshold != null){
						
						if(!dirty){//如果不需要重新排名就先与最后一名比较看是否直接替换最后一名就可以了
							
							if(this.compareBefore(rankable, threshold)){//endOne应该排在rankable后面了
								this.dirty = true;
								rankChanged = true;
							} else {//没有超越门槛直接返回
								return false;
							}
							
						}
						
						if(dirty){//需要重新排名一下刷新threshold
							this.rankList.add(rankable.getOwnerId());//先加入进去排序
							rank_map.put(rankable.getOwnerId(), rankable);
							rankable.setRank(this.rankList.size());
							
							this.reorder();
							this.dirty = false;
							
							Long lastOneId = this.rankList.remove(this.rankList.size() - 1);//将最后一名移除
							this.rank_map.remove(lastOneId);
							
							this.threshold = this.getLastOne();//将门槛设置为最后一名
						}
					
						
					} else {
						logger.error("排名对象大小达到最大上限但是门槛对象为空!");
						this.reorder();
						this.dirty = false;
						this.threshold = this.getLastOne();
					}
					
				} else {//排名还没有满则直接放入列表
					
					this.rankList.add(rankable.getOwnerId());
					rankable.setRank(this.rankList.size());
					rank_map.put(rankable.getOwnerId(), rankable);
					
					if(threshold != null){//与最后一名比较
						if(this.compareBefore(rankable, threshold)){//新加入的在组后的前面那么就设置为脏数据
							dirty = true;
						} 
					}
					
					if(dirty){
						this.reorder();
						this.dirty = false;
						this.threshold = this.getLastOne();
					} else {
						this.threshold = rankable;
					}
					
					if(this.rankList.size() == 1){
						this.threshold = rankable;
					}
					
					rankChanged = true;
				}
			}
			return rankChanged;
		} finally {
			lock.writeLock().unlock();
		}
	}
	
	/**
	 * 获取指定排名的排名对象
	 * @param rank
	 * @return
	 */
	private T getByRank(int rank){
		if(rank > 0 && rank <= this.rankList.size()){
			long ownerId = this.rankList.get(rank - 1);
			return this.rank_map.get(ownerId);
		}
		return null;
	}
	
	/**
	 * 获取最后一名
	 * @return
	 */
	private T getLastOne(){
		return this.getByRank(this.rankList.size());
	}
	
	/**
	 * rankable1应该在rankable2前面吗
	 * @param rankable1
	 * @param rankable2
	 * @return true - rankable1应该在rankable2前面
	 */
	private boolean compareBefore(T rankable1, T rankable2){
		return rankable1.compareTo(rankable2) < 0;
	}
	
	/**
	 * 删除并刷新
	 * @param ownerId
	 */
	public void removeAndRefresh(long ownerId){
		lock.writeLock().lock();
		try {
			T existsRankable = rank_map.remove(ownerId);
			if(existsRankable != null){
				this.dirty = existsRankable.getRank() < this.rankList.size();
				this.rankList.remove(Long.valueOf(ownerId));
			}
			if(this.threshold != null && this.threshold.ownerId == ownerId){//如果移除的是门槛则刷新
				this.reorder();
				this.dirty = false;
				this.threshold = this.getLastOne();
			}
		} finally {
			lock.writeLock().unlock();
		}
	}
	
	
	
	/**
	 * 查询指定id对应的排名(用于获取一个名次的快照)
	 * @param ownerId
	 * @return
	 */
	public int getOwnerRank(long ownerId){
		if(!this.rank_map.containsKey(ownerId)){
			return 0;
		}
		boolean refreshAndGet = false;
		lock.readLock().lock();
		try {
			if(!this.dirty){
				Rankable rankable = this.rank_map.get(ownerId);
				if(rankable != null){
					return rankable.getRank();
				}
				return 0;
			} else {
				refreshAndGet = true;
			}
		} finally {
			lock.readLock().unlock();
		}
		
		if(refreshAndGet){
			lock.writeLock().lock();
			try {
				if(dirty){
					this.reorder();
					this.dirty = false;
					this.threshold = this.getLastOne();
				}
				
				Rankable rankable = this.rank_map.get(ownerId);
				if(rankable != null){
					return rankable.getRank();
				}
				
			} finally {
				lock.writeLock().unlock();
			}
		}
		
		return 0;
	}
	
	
	/**
	 * 分页获取排名(主要是面向客户端的)
	 * @param <VO>
	 * @param ownerId 如果不null则获取ownerId的排名
	 * @param startIndex 从列表的这个下标开始获取(>=0)
	 * @param fetchCount 从startIndex处开始获取这么多个元素(<0表示一直获取到最后一个元素)
	 * @param voFilter 过滤器
	 * @param voClass 给客户端显示的vo对象
	 * @return
	 */
	public <VO> RankResult<VO> pageRankListForView(Long ownerId, int startIndex, int fetchCount, VOFilter<VO> voFilter, Class<VO> voClass){
		
		if(startIndex < 0){
			startIndex = 0;
		}
		if(fetchCount <= 0){
			fetchCount = this.maxSize;
		}
		
		int ownerRank = 0;
		int totalSize = 0;
		
		List<VO> voList = new ArrayList<VO>();
		
		boolean refreshAndGet = false;
		lock.readLock().lock();
		try {
			if(!this.dirty){
				
				int ignoreCount = 0;
				
				for(int index = startIndex; index < Math.min(this.rankList.size(), startIndex + fetchCount + ignoreCount); index++){
					T rankable = this.rank_map.get(this.rankList.get(index));
					VO vo = this.converterService.convert(rankable, voClass);
					if(vo != null){
						if(voFilter == null || !voFilter.filter(vo)){//过滤
							voList.add(vo);
						} else {
							ignoreCount ++;
						}
						
					}
				}
				if(ownerId != null){
					T rankable = rank_map.get(ownerId);
					if(rankable != null){
						ownerRank = rankable.getRank();
					}
				}
				totalSize = this.rankList.size();
				
			} else {
				refreshAndGet = true;
			}
		} finally {
			lock.readLock().unlock();
		}
		
		if(refreshAndGet){
			lock.writeLock().lock();
			try {
				
				if(dirty){
					this.reorder();
					this.dirty = false;
					this.threshold = this.getLastOne();
				}
				
				int ignoreCount = 0;
				
				for(int index = startIndex; index < Math.min(this.rankList.size(), startIndex + fetchCount + ignoreCount); index++){
					T rankable = this.rank_map.get(this.rankList.get(index));
					VO vo = this.converterService.convert(rankable, voClass);
					if(voFilter == null || !voFilter.filter(vo)){//过滤
						voList.add(vo);
					} else {
						ignoreCount ++;
					}
				}
				if(ownerId != null){
					T rankable = rank_map.get(ownerId);
					if(rankable != null){
						ownerRank = rankable.getRank();
					}
				}
				totalSize = this.rankList.size();
			} finally {
				lock.writeLock().unlock();
			}
		}
		
		RankResult<VO> result = new RankResult<VO>();
		Page<VO> page = Page.valueOf(totalSize, startIndex, fetchCount, voList);
		result.setPage(page);
		result.setOwnerRank(ownerRank);
		return result;
	}
	
	
	
	
	/**
	 * 分页获取排名(主要是面向客户端的)
	 * @param <VO>
	 * @param ownerId 如果不null则获取ownerId的排名
	 * @param startIndex 从列表的这个下标开始获取(>=0)
	 * @param fetchCount 从startIndex处开始获取这么多个元素(<0表示一直获取到最后一个元素)
	 * @param voClass 给客户端显示的vo对象
	 * @return
	 */
	public <VO> RankResult<VO> pageRankListForView(Long ownerId, int startIndex, int fetchCount, Class<VO> voClass){
		return this.pageRankListForView(ownerId, startIndex, fetchCount, null, voClass);
	}
	
	
	/**
	 * 获取排名列表的id列表
	 * @param startIndex
	 * @param fetchCount
	 * @return
	 */
	public List<Long> getRankList(int startIndex, int fetchCount){
		if(startIndex < 0){
			startIndex = 0;
		}
		if(fetchCount <= 0){
			fetchCount = this.maxSize;
		}
		
		boolean refreshAndGet = false;
		lock.readLock().lock();
		try {
			if(!this.dirty){
				int toIndex =  Math.min(this.rankList.size(), startIndex + fetchCount);
				return this.rankList.subList(startIndex, toIndex);
			} else {
				refreshAndGet = true;
			}
		} finally {
			lock.readLock().unlock();
		}
		
		if(refreshAndGet){
			lock.writeLock().lock();
			try {
				
				if(dirty){
					this.reorder();
					this.dirty = false;
					this.threshold = this.getLastOne();
				}
				
				int toIndex =  Math.min(this.rankList.size(), startIndex + fetchCount);
				return this.rankList.subList(startIndex, toIndex);
			} finally {
				lock.writeLock().unlock();
			}
		}
		
		return null;
	}
	
	/**
	 * 重新排名列表
	 */
	private void reorder(){
		Collections.sort(this.rankList, new Comparator<Long>(){
			
			@Override
			public int compare(Long id1, Long id2) {
				T rankable1 = rank_map.get(id1);
				T rankable2 = rank_map.get(id2);
				return rankable1.compareTo(rankable2);
			}
		});
		int rank = 0;
		for(Long id : this.rankList){
			T rankable = rank_map.get(id);
			rankable.setRank(++rank);
		}
	}
	
	
	public ConverterService getConverterService() {
		return converterService;
	}

	public void setConverterService(ConverterService converterService) {
		this.converterService = converterService;
	}
	
	/**
	 * 清空排名
	 */
	public void clear(){
		lock.writeLock().lock();
		try {
			this.rank_map.clear();
			this.rankList.clear();
			this.dirty = false;
			this.threshold = null;
		} finally {
			lock.writeLock().unlock();
		}
	}
	
	
	
	
}
