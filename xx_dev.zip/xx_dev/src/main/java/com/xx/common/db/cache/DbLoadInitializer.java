/**
 * 
 */
package com.xx.common.db.cache;

/**
 * @author fansth
 *
 */
public interface DbLoadInitializer {
	
	void doAfterLoad();

}
