package com.xx.common.db.service.impl;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Projections;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;
import org.springframework.stereotype.Service;

import com.xx.common.db.service.CommonManager;



/**
 * 通用数据库管理器
 */
@Service
public class CommonManagerImpl extends HibernateDaoSupport implements CommonManager {
	
	@Autowired  
    public void setSessionFactory0(SessionFactory sessionFactory){   
    	super.setSessionFactory(sessionFactory);   
    }
	
	
	/**
	 * 根据主键id取得实体对象
	 * @param entityClazz 实体类
	 * @param id 主键id
	 * @return 实体对象
	 */
	public <T> T get(Class<T> entityClazz, Serializable id) {
		return super.getHibernateTemplate().get(entityClazz, id);
	}
	
	
	/**
	 * 保存实体对象
	 * @param entity 实体对象
	 */
	public <T> void save(T entity) {
		super.getHibernateTemplate().saveOrUpdate(entity);
	}
	
	
	/**
	 * 更新实体对象
	 * @param entity 实体对象
	 */
	public <T> void update(T entity) {
		super.getHibernateTemplate().update(entity);
	}
	
	
	/**
	 * 删除实体
	 * @param entityClazz 实体对象
	 * @param id 主键id
	 */
	public <T> void delete(Class<T> entityClazz, Serializable id) {
		T entity = this.get(entityClazz, id);
		if (entity != null) {
			super.getHibernateTemplate().delete(entity);
		}
	}
	
	
	/**
	 * 取得最大主键值(主键为Integer/Long类型)
	 * @param entityClazz 实体对象
	 * @return Object
	 */
	public Object getMaxIdValues(Class<?> entityClazz) {
		return getSession().createCriteria(entityClazz)
						.setProjection(Projections.max(Projections.id().toString()))
						.uniqueResult();
	}


	/**
	 * 取得指定条件，位置，大小的集合列表
	 * 
	 * @param criteria		查询条件
	 * @param fromIdx		开始索引（从0开始）
	 * @param fetchCount	列表大小
	 */
	@SuppressWarnings({ "rawtypes" })
	@Override
	public List getCommonQueryResult(DetachedCriteria criteria, int fromIdx, int fetchCount) {
		if (criteria != null) {
			Criteria c = criteria.getExecutableCriteria(getSession());
			if (fromIdx > 0) {
				c.setFirstResult(fromIdx);
			}
			if (fetchCount > 0) {
				c.setMaxResults(fetchCount);
			}
			return c.list();
		}

		return null;
	}
	
	@Override
	public int executeUpdate(String queryString, Map<String, Object> paramMap) {
		Query query = getSession().createQuery(queryString);
		
		if (paramMap != null && !paramMap.isEmpty()) {
			for (Entry<String, Object> entry: paramMap.entrySet()) {
				String key = entry.getKey();
				Object val = entry.getValue();
				
				query.setParameter(key, val);
			}
		}
		
		return query.executeUpdate();
	}

}
