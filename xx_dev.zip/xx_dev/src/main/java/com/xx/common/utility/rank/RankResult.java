/**
 * 
 */
package com.xx.common.utility.rank;

import com.xx.common.utility.Page;

/**
 * 排名结果对象
 * @author fansth
 *
 */
public class RankResult<VO> {

	/**
	 * 分页对象
	 */
	private Page<VO> page = new Page<VO>();
	
	/**
	 * 我的排名
	 */
	private int ownerRank = 0;

	public Page<VO> getPage() {
		return page;
	}

	public void setPage(Page<VO> page) {
		this.page = page;
	}

	public int getOwnerRank() {
		return ownerRank;
	}

	public void setOwnerRank(int ownerRank) {
		this.ownerRank = ownerRank;
	}
	
	
	
}
