/**
 * @file:SpringUtils.java
 * @author:David
 **/
package com.xx.common.util;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

/**
 * @class:SpringUtils
 * @description:可以获得所有用srping配置的类
 * @author:David
 * @version:v1.0
 * @date:2013-4-23
 **/
public class SpringUtils implements ApplicationContextAware{

	private static ApplicationContext applicationContext; // Spring应用上下文环境

	@Override
	public void setApplicationContext(final ApplicationContext applicationContext){
		SpringUtils.applicationContext = applicationContext;
	}
	
	/**
	 * @return ApplicationContext
	 */
	public static ApplicationContext getApplicationContext() {
		return applicationContext;
	}

	/**
	 * 获取对象
	 * 
	 * @param name
	 * @return Object 一个在spring以所给名字注册的bean的实例
	 */
	public static Object getBean(final String name) {
		if (applicationContext == null) {
			return null;
		}
		return applicationContext.getBean(name);
	}
	
	/**
	 * 获取类型为requiredType的对象
	 * 如果bean不能被类型转换，相应的异常将会被抛出（BeanNotOfRequiredTypeException）
	 * 
	 * @param name
	 *            bean注册名
	 * @param requiredType
	 *            返回对象类型
	 * @return Object 一个在spring以所给名字注册的bean的实例，返回必须是requiredType类型对象
	 */
	public static <T> T getBean(final String name, final Class<T> requiredType) {
		if (applicationContext == null) {
			return null;
		}
		return (T) applicationContext.getBean(name, requiredType);
	}
}

