/**
 * 
 */
package com.xx.common.executor;

import java.util.concurrent.Executor;

/**
 * 任务执行者接口(主要是方便spring注入)
 * @author fansth
 *
 */
public interface TaskExecutor extends Executor {

}
