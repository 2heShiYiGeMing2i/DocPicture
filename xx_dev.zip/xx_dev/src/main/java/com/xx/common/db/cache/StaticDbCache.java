/**
 * 
 */
package com.xx.common.db.cache;

import java.io.Serializable;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.xx.common.db.model.BaseModel;

/**
 * 静态dbcache
 * @author fansth
 *
 */
@Component
public class StaticDbCache {
	
	@Autowired
	private DbCachedService dbCachedService0;
	
	private static DbCachedService dbCachedService;
	
	@SuppressWarnings("unused")
	@PostConstruct
	private void init(){
		StaticDbCache.dbCachedService = this.dbCachedService0;
	}
	
	
	/**
	 * 更新实体
	 * @param id
	 * @param entityClazz
	 */
	public static void update(Serializable id, Class<?> entityClazz){
		if(dbCachedService != null){
			dbCachedService.submitUpdated2Queue(id, entityClazz);
		}
	}
	
	/**
	 * 保存实体
	 * @param id
	 * @param entityClazz
	 */
	public <T extends BaseModel<PK>, PK extends Comparable<PK> & Serializable> T save(T entity){
		if(dbCachedService != null){
			if(entity != null){
				return dbCachedService.submitNew2Queue(entity);
			}
		}
		return null;
	}

}
