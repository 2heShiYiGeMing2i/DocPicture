/**
 * 
 */
package com.xx.common.utility.cas;

import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.locks.ReentrantLock;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;



/**
 * CAS事务
 * @author fansth
 *
 */
public class CASTransaction {
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	private static final ReentrantLock lock = new ReentrantLock();
	
	private Set<CASEntry> beanSet = new HashSet<CASEntry>();
	
	protected CASTransaction(CASAble...beans){
		this.takeBean(beans);
	}
	
	/**
	 * 托管指定的bean
	 * @param beans
	 */
	public void takeBean(CASAble... beans){
		if(beans != null){
			for(CASAble bean : beans){
				beanSet.add(new CASEntry(bean));
			}
		}
	}
	
	/**
	 * 开始事务
	 */
	public void begin(){
		for(CASEntry entry : beanSet){
			CASAble bean = entry.target;
			entry.revision = bean.getRevision();
		}
	}
	
	/**
	 * 提交事务
	 * @param casAction 事务需要执行的操作
	 * @return
	 */
	public void commit(CASAction casAction){
		
		for(CASEntry entry : beanSet){//锁外比较一次
			CASAble bean = entry.target;
			if(entry.revision != bean.getRevision()){
				logger.error("CASTransaction version  conflict!");
				throw new CASVersionConflictException("CASTransaction version  conflict!");
			}
		}
		
		CASTransactionManager.markTransaction();//标记当前线程已经进入事务状态
		
		try {
			
			lock.lock();
			try {
				for(CASEntry entry : beanSet){//锁内再次比较
					CASAble bean = entry.target;
					if(entry.revision != bean.getRevision()){
						logger.error("CASTransaction version  conflict!");
						throw new CASVersionConflictException("CASTransaction version  conflict!");
					}
				}
				
				try {
					casAction.doAction();
				} catch (Exception e) {
					logger.error("CASAction fail!", e);
					throw new CASActionException("CASAction fail!", e);
				}
				
				for(CASEntry entry : beanSet){
					CASAble bean = entry.target;
					bean.increaseRevision();
//					StaticDbCache.update(bean.id, bean.class);  //提交更新到dbcache
				}
			
			} finally {
				lock.unlock();
			}
			
		} finally {
			CASTransactionManager.clearTransaction();//取消当前线程已经进入事务状态
		}
	}
	
	
	private final class CASEntry {
		
		private CASAble target;
		
		private long revision;
		
		public CASEntry(CASAble target){
			this.target = target;
		}
		
	}
	
}
