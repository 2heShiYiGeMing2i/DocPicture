/**
 * 
 */
package com.xx.common.utility.cas;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * cas事务注解
 * @author fansth
 */
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.METHOD, ElementType.TYPE})
public @interface CASTransactional {
	
	/**版本冲突后重试次数*/
	int retry() default 5;

}
