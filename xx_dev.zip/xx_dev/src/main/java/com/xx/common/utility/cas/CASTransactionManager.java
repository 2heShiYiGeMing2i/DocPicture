/**
 * 
 */
package com.xx.common.utility.cas;


/**
 * cas事务管理者
 * @author fansth
 *
 */
public abstract class CASTransactionManager {
	
	private static final ThreadLocal<Object> TRANSACTION_HOLDER = new ThreadLocal<Object>();
	
	private static final Object TX_MARK = new Object();
	
	/**
	 * 获取一个事务
	 * @param beans 需要托管的对象
	 * @return
	 */
	public static CASTransaction getTransaction(CASAble...beans){
		return new CASTransaction(beans);
	}
	
	
	/**
	 * 直接开始一个事务
	 * @param beans 需要托管的对象
	 * @return
	 */
	public static CASTransaction beginTransaction(CASAble...beans){
		CASTransaction casTransaction = new CASTransaction(beans);
		casTransaction.begin();
		return casTransaction;
	}
	
	
	/**
	 * 判断当前线程时候在事务环境中
	 * @return
	 */
	public static boolean hasTransaction(){
		return TRANSACTION_HOLDER.get() != null;
	}
	
	/**
	 * 标记当前线程进入事务状态
	 */
	public static void markTransaction(){
		if(TRANSACTION_HOLDER.get() != null){
			throw new CASTransactionStatusException("CASTrasnaction status error, there may be duplicate transaction!");
		}
		TRANSACTION_HOLDER.set(TX_MARK);
	}
	
	/**
	 * 清除当前线程的事务状态
	 */
	public static void clearTransaction(){
		TRANSACTION_HOLDER.remove();
	}

}
