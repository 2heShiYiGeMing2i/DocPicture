package com.xx.common.log;

import static com.xx.common.util.DatePattern.PATTERN_YYYYMMDDHHMMSS;
import static com.xx.common.util.Splitable.ATTRIBUTE_SPLIT;
import static com.xx.common.util.Splitable.BETWEEN_ITEMS;
import static com.xx.common.util.Splitable.DELIMITER_ARGS;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.xx.common.util.DateUtil;


/**
 * 日志记录
 *
 * @author Hyint
 */
public class TraceLog {

	/**
	 * 记录日志
	 * 
	 * @param logType 			日志的类型
	 * @param message 			需要记录的日志信息
	 */
	public static void doLogger(LogType logType, String message) {
		Logger log = LoggerFactory.getLogger(logType.getLogName());
		if (log.isInfoEnabled()) {
			log.info(message);
		}
	}
	
	
	/**
	 * 判断日志是否打开
	 * @param logType
	 * @return
	 */
	public static boolean isLoggerInfoEnable(LogType logType){
		Logger log = LoggerFactory.getLogger(logType.getLogName());
		return log != null && log.isInfoEnabled();
	}
	
	
	
	
	/**
	 * 记录日志
	 * 
	 * @param logType 			日志的类型
	 * @param terms 			日志条目 
	 */
	public static void log(LogType logType, LogTerm... terms) {
		String message = "";
		if(terms.length > 0) {
			message = new StringBuilder().append(getTimeTerm()).append(BETWEEN_ITEMS).append(LogTerm.toString(terms)).toString();
		}
		doLogger(logType, message);
	}
	
	
	/**
	 * 记录日志
	 * 
	 * @param logType 		日志类型
	 * @param terms 		日志条目 
	 */
	public static void log(LogType logType, Object[] infos, LogTerm... terms) {
		StringBuilder builder = new StringBuilder();
		builder.append(getTimeTerm()).append(BETWEEN_ITEMS).append(LogTerm.toString(terms));
		if(infos != null && infos.length > 0) {
			builder.append(BETWEEN_ITEMS);
			builder.append("info").append(DELIMITER_ARGS);
			for(Object obj : infos) {
				builder.append(obj).append(ATTRIBUTE_SPLIT);
			}
			builder.deleteCharAt(builder.length() - 1);
		}
		doLogger(logType, builder.toString());
	}
	
	/**
	 * 获得时间的日志断
	 * 
	 * @return {@link LogTerm}	日子子类
	 */
	private static LogTerm getTimeTerm() {
		return LogTerm.valueOf("time", DateUtil.date2String(new Date(), PATTERN_YYYYMMDDHHMMSS));
	}
}
