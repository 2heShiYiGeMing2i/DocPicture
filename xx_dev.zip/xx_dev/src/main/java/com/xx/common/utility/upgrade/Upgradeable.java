/**
 * 
 */
package com.xx.common.utility.upgrade;

/**
 * 可升级的抽象类
 * @author fansth
 *
 */
public interface Upgradeable {
	
	/**
	 * 等级
	 * @return
	 */
	public int getLevel();


	/**
	 * 该等级下的最大成长 (假如 upgradeValue = 100, 99时不升级 100时变成下一级成长值变0)
	 * @return
	 */
	public long getUpgradeValue();


}
