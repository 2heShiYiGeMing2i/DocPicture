package com.xx.common.db.cache;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

import org.apache.mina.util.ConcurrentHashSet;
import org.hibernate.criterion.DetachedCriteria;

import com.xx.common.db.model.BaseModel;
import com.xx.common.db.pk.IdGenerator;



/**
 * 数据缓存服务接口
 */
public interface DbCachedService {
	
	/**
	 * 根据主键id取得实体
	 * @param id 主键id
	 * @param entityClazz 实体类型
	 * @return 实体对象
	 */
	<T> T get(Serializable id, Class<T> entityClazz);
	
	/**
	 * 根据主键id列表取得实体列表
	 * @param idList 主键id列表
	 * @param entityClazz 实体类型
	 * @return 实体对象列表
	 */
	<T, PK extends Serializable> List<T> getEntityFromIdList(Collection<PK> idList, Class<T> entityClazz);
	
	
	/**
	 * 提交实体修改任务到更新队列
	 * @param id 主键id
	 * @param entityClazz 实体类型
	 */
	void submitUpdated2Queue(Serializable id, Class<?> entityClazz);
	
	
	/**
	 * 提交实体修改任务到更新队列
	 * @param id 主键id
	 * @param entityClazz 实体类型
	 * @param callback 回调
	 */
	void submitUpdated2Queue(Serializable id, Class<?> entityClazz, DbCallback callback);
	
	
	/**
	 * 实时更新实体
	 * @param id 主键id
	 * @param entityClazz 实体类型
	 */
	void updateEntityIntime(Serializable id, Class<?> entityClazz);
	
	
	/**
	 * 提交实体删除任务到更新队列
	 * @param id 主键id
	 * @param entityClazz 实体类型
	 */
	void submitDeleted2Queue(Serializable id, Class<?> entityClazz);
	
	
	/**
	 * 提交实体删除任务到更新队列
	 * @param id 主键id
	 * @param entityClazz 实体类型
	 * @param callback 回调
	 */
	void submitDeleted2Queue(Serializable id, Class<?> entityClazz, DbCallback callback);
	
	
	/**
	 * 实时删除实体对象
	 * @param id 主键id
	 * @param entityClazz 实体类型
	 */
	void deleteEntityIntime(Serializable id, Class<?> entityClazz);
	
	
	/**
	 * 提交新建实体到更新队列(根据配置自动随机服标识)
	 * @param entity 新建实体对象
	 * @return 返回保存的实体对象(可能与entity不是同一个实例)
	 * @throws IllegalArgumentException 如果主键id==null
	 */
	<T extends BaseModel<PK>, PK extends Comparable<PK> & Serializable> T submitNew2Queue(T entity);
	
	/**
	 * 提交新建实体到更新队列(id==null时根据主键id生成器接口生成id)
	 * @param entity 新建实体对象
	 * @param serverId 服标识
	 * @return 返回保存的实体对象(可能与entity不是同一个实例)
	 * @throws IllegalArgumentException 如果主键id==null且没有定义主键id生成器接口
	 */
	<T extends BaseModel<PK>, PK extends Comparable<PK> & Serializable> T submitNew2Queue(T entity, int serverId);
	
	/**
	 * 提交新建实体到更新队列(id==null时根据主键id生成器接口生成id)
	 * @param entity 新建实体对象
	 * @param serverId 服标识
	 * @param callback 回调
	 * @return 返回保存的实体对象(可能与entity不是同一个实例)
	 * @throws IllegalArgumentException 如果主键id==null且没有定义主键id生成器接口
	 */
	<T extends BaseModel<PK>, PK extends Comparable<PK> & Serializable> T submitNew2Queue(T entity, int serverId, DbCallback callback);
	
	/**
	 * 实时保存新建实体(根据配置自动随机服标识)
	 * @param entity 新建实体对象
	 * @return 返回保存的实体对象(可能与entity不是同一个实例)
	 * @throws IllegalArgumentException 如果主键id==null
	 */
	<T extends BaseModel<PK>, PK extends Comparable<PK> & Serializable> T saveEntityIntime(T entity);
	
	/**
	 * 实时保存新建实体(id==null时根据主键id生成器接口生成id)
	 * @param entity 新建实体对象
	 * @param serverId 服标识
	 * @return 返回保存的实体对象(可能与entity不是同一个实例)
	 * @throws IllegalArgumentException 如果主键id==null且没有定义主键id生成器接口
	 */
	<T extends BaseModel<PK>, PK extends Comparable<PK> & Serializable> T saveEntityIntime(T entity, int serverId);
	
	/**
	 * 取得(缓存的)查询结果集(一般是id列表, 由业务维护缓存的生命周期)
	 * @param cachedKey 缓存key
	 * @param criteria DetachedCriteria
	 * @param fromIdx 开始索引
	 * @param fetchCount 获取数量
	 * @return ConcurrentHashSet<T>
	 */
	<T> ConcurrentHashSet<T> getCachedQueryResult(String cachedKey, DetachedCriteria criteria, int fromIdx, int fetchCount);
	
	
	/**
	 * 同 ConcurrentMap.putIfAbsent(k,v), 提供原子性操作
	 * @param key 
	 * @param value
	 * @return Object
	 */
	Object put2CommonCacheIfAbsent(String key, Object value);
	
	/**
	 * 放入通用缓存 
	 * @param key  Key
	 * @param obj 缓存对象
	 */
	void put2CommonCache(String key, Object obj);	
	
	/**
	 * 放入通用缓存 
	 * @param key Key
	 * @param obj 缓存对象
	 * @param timeToLive  存活时间(ms)
	 */
	void put2CommonCache(String key, Object obj, long timeToLive);	
	
	/**
	 * 放入通用缓存
	 * @param hashKey Hash key
	 * @param subKey 子key
	 * @param obj 缓存对象
	 */
	void put2CommonCache(String hashKey, String subKey, Object obj);	
	
	/**
	 * 放入通用缓存
	 * @param hashKey Hash key
	 * @param subKey 子key
	 * @param obj    缓存对象
	 * @param timeToLive 存活时间(ms)
	 */
	void put2CommonCache(String hashKey, String subKey, Object obj, long timeToLive);	
	
	/**
	 * 从通用缓存取得对象
	 * @param key KEY
	 * @return Object
	 */
	Object getFromCommonCache(String key);
	
	/**
	 * 从通用缓存取得对象
	 * @param hashKey Hash Key
	 * @param subKey  子key
	 * @return Object
	 */
	Object getFromCommonCache(String hashKey, String subKey);	
	
	/**
	 * 从通用缓存删除
	 * @param key KEY
	 */
	void removeFromCommonCache(String key);
	
	
	/**
	 * 注册实体主键id生成器
	 * @param serverId 服标识
	 * @param clazz  实体类型
	 * @param idGenerator 主键id生成器接口
	 */
	void registerEntityIdGenerator(int serverId, Class<?> clazz, IdGenerator<?> idGenerator);
	
	/**
	 * 取得服标识ID列表
	 * @return List<Integer>
	 */
	List<Integer> getServerIdList();
	
	/**
	 * 是否包含服标识
	 * @param serverId 服标识
	 * @return true/false
	 */
	boolean containsServerId(int serverId);
	
	/**
	 * 判断是否合服
	 * @return true/false
	 */
	boolean isServerMerged();

}
