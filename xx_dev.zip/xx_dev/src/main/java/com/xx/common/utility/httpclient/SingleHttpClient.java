/**
 * 
 */
package com.xx.common.utility.httpclient;

import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.conn.scheme.PlainSocketFactory;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeSocketFactory;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpProtocolParams;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.helpers.FormattingTuple;
import org.slf4j.helpers.MessageFormatter;

/**
 * 只有一个连接的httpclient
 * <p>
 * 	本实现是线程不安全的,虽然很多资料都说httpClient是可以共享的，但是经过测试在多线程
 * 访问同一个httpClient实例的情况，很容易出一些“奇葩”问题，而实际上构建一个httpClient
 * 其实代价并不会很高，主要的代价还是在连接的建立那块，而即使共用一个httpClient连接其实
 * 也是在使用后马上关闭掉了，因为web服务器都是服务端主动关闭socket的。
 * </p>
 * @author fansth
 *
 */
public class SingleHttpClient {
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	/**
	 * 连接
	 */
	private final DefaultHttpClient httpClient = new DefaultHttpClient();
	
	/**
	 * 新建一个只有一个连接的httpclient
	 */
	@SuppressWarnings("deprecation")
	public SingleHttpClient(){
		this.setCharset(HTTP.UTF_8);
        this.setConnectionTimeout(5000);;//设置链接超时时间5秒
        this.setSocketBufferSize(1024);//设置socket缓冲区大小
        this.setSocketSoTimeout(5000);//设置读写数据超时时间时间
        this.registerNoCheckSSLScheme(443);
        this.registerPlainHttpScheme(80);
	}
	
	
	/**
	 * 设置参数
	 *  {@see HttpParamsNames} 
	 *  {@see HttpProtocolParams}
	 *  {@see HttpConnectionParams}
	 * @param name
	 * @param value
	 */
	public void setParams(String name, Object value){
		this.httpClient.getParams().setParameter(name, value);
	}
	
	/**
	 * 设置socket读写超时时间
	 * @param millis
	 */
	public void setSocketSoTimeout(long millis){
		 HttpConnectionParams.setSoTimeout(this.httpClient.getParams(), (int)millis);//设置读写数据超时时间时间
	}
	
	/**
	 * 设置socket缓冲区大小
	 * @param bufferSize
	 */
	public void setSocketBufferSize(int bufferSize){
		 HttpConnectionParams.setSocketBufferSize(this.httpClient.getParams(), bufferSize);//设置socket缓冲区大小
	}
	
	/**
	 * 设置连接超时时间
	 * @param millis
	 */
	public void setConnectionTimeout(long millis){
		 HttpConnectionParams.setConnectionTimeout(this.httpClient.getParams(), (int)millis);//设置链接超时时间5秒
	}
	
	
	/**
	 * 设置字符集 如 UTF-8
	 * @param charset
	 */
	public void setCharset(String charset){
		HttpProtocolParams.setContentCharset(this.httpClient.getParams(), charset);
		HttpProtocolParams.setHttpElementCharset(this.httpClient.getParams(), charset);
	}
	
	
	/**
	 * 注册协议
	 * @param schemeName 协议名 如：http , https 这样
	 * @param schemePort 协议的端口号
	 * @param schemeSocketFactory 协议的socket工厂
	 */
	private void registerScheme(String schemeName, int schemePort, SchemeSocketFactory schemeSocketFactory){
		this.httpClient.getConnectionManager().getSchemeRegistry().register(new Scheme(schemeName, schemePort, schemeSocketFactory));
	}
	
	/**
	 * 注册一个不验证的https 协议
	 * @param port
	 */
	private void registerNoCheckSSLScheme(int port){
		try {
			SSLContext ctx = SSLContext.getInstance("TLS");
	         X509TrustManager tm = new javax.net.ssl.X509TrustManager() {
				@Override
				public void checkClientTrusted(X509Certificate[] chain,
						String authType) throws CertificateException {
					//总是接受所有的证书从来不抛出异常
				}

				@Override
				public void checkServerTrusted(X509Certificate[] chain,String authType) throws CertificateException {
					//总是接受所有的证书从来不抛出异常
				}

				@Override
				public X509Certificate[] getAcceptedIssuers() {
					return null;
				}
	                
	         };
	         ctx.init(null, new TrustManager[]{tm}, null);
	         SSLSocketFactory ssf = new SSLSocketFactory(ctx, SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
	         this.registerScheme("https", port, ssf);
		} catch (Exception e) {
		}
	}
	
	/**
	 * 注册一个简单的http 协议
	 * @param port
	 */
	private void registerPlainHttpScheme(int port){
		this.registerScheme("http", port, new PlainSocketFactory());
	}
	
	/**
	 * 关闭客户端
	 */
	public void close(){
		try {
			this.httpClient.getConnectionManager().shutdown();
		} catch (Exception e) {
			logger.error("关闭httpclient错误!", e);
		}
	}
	
	
	/**
	 * 请求url返回String
	 * @param url
	 * @param httpMethod
	 * @return
	 */
	public String requestForString(String url, HttpMethod httpMethod){
		return this.requestForString(url, httpMethod, null, null);
	}
	
	
	/**
	 * 请求url返回String (请求后自动关闭httpclient)
	 * @param url
	 * @param httpMethod
	 * @param parameters 参数
	 * @param headers 头消息
	 * @return
	 */
	public String requestForString(String url, HttpMethod httpMethod, Map<String, Object> parameters, Map<String, Object> headers){
		HttpRequestBase request = null;
		
		if(httpMethod == HttpMethod.GET){//get方式
			request = new HttpGet(url);
		} else if(httpMethod == HttpMethod.POST){
			request = new HttpPost(url);
		} else {
			throw new IllegalArgumentException("不支持的http请求方法");
		}
		
		if(parameters != null){
			for(Entry<String, Object> entry : parameters.entrySet()){
				request.getParams().setParameter(entry.getKey(), entry.getValue());
			}
		}
		
		if(headers != null){
			for(Entry<String, Object> entry : headers.entrySet()){
				request.setHeader(entry.getKey(), String.valueOf(entry.getValue()));
			}
		}
		
		String responseString = "";
		HttpResponse response = null;
		
		try {
			response = this.httpClient.execute(request);
			HttpEntity entity = response.getEntity();
			
			if(entity != null){
				responseString = EntityUtils.toString(entity);
			}
			
		} catch (Exception e) {
			FormattingTuple tuple = MessageFormatter.format("请求 url [{}] 错误!", url);
			logger.error(tuple.getMessage(), e);
		} finally {
			if(response != null){
				try {
					response.getEntity().getContent().close();
				} catch (Exception e) {
					logger.error("httpclient关闭响应流错误!", e);
				} 
			}
			try {
				request.releaseConnection();
			} catch (Exception e) {
				logger.error("httpclient释放连接错误!", e);
			}
			
		}
		
		if(responseString == null){
			responseString = "";
		}
		
		return responseString;	
	}
	
	/**
	 * 请求url返回String (HttpMethod.POST,请求后自动关闭httpclient)
	 * @param url URL
	 * @param parameters 参数
	 * @return String
	 */
	@SuppressWarnings("deprecation")
	public String postRequestForString(String url, Map<String, String> parameters) {
		return postRequestForString(url, parameters, HTTP.UTF_8);
	}
	
	/**
	 * 请求url返回String (HttpMethod.POST,请求后自动关闭httpclient)
	 * @param url URL
	 * @param parameters 参数
	 * @param charset 字符集
	 * @return String
	 */
	public String postRequestForString(String url, Map<String, String> parameters, String charset){
		HttpPost  request = new HttpPost(url);
		
		List<NameValuePair> params = null;
		if (parameters != null && parameters.size() > 0) {
			params = new ArrayList<NameValuePair>(parameters.size());
			
			for (Entry<String, String> entry: parameters.entrySet()) {
				String key = entry.getKey();
				String value = entry.getValue();
				
				params.add(new BasicNameValuePair(key, value));  
			}
		}
		
		String responseString = "";
		HttpResponse response = null;
		
		try {
			if (params != null) {
				request.setEntity(new UrlEncodedFormEntity(params, charset)); 
			}
			
			response = this.httpClient.execute(request);
			HttpEntity entity = response.getEntity();
			
			if(entity != null){
				responseString = EntityUtils.toString(entity);
			}
			
		} catch (Exception e) {
			FormattingTuple tuple = MessageFormatter.format("请求 url [{}] 错误!", url);
			logger.error(tuple.getMessage(), e);
		} finally {
			if(response != null){
				try {
					response.getEntity().getContent().close();
				} catch (Exception e) {
					logger.error("httpclient关闭响应流错误!", e);
				} 
			}
			try {
				request.releaseConnection();
			} catch (Exception e) {
				logger.error("httpclient释放连接错误!", e);
			}
			
		}
		
		if(responseString == null){
			responseString = "";
		}
		
		return responseString;	
	}
	
	
	public static void main(String[] args) {
		SingleHttpClient simpleHttpClient = new SingleHttpClient();
		String response = simpleHttpClient.requestForString("http://www.163.com", HttpMethod.GET);
		System.out.println(response);
	}
	
	
}
