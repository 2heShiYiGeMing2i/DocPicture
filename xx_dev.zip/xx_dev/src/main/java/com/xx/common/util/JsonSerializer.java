package com.xx.common.util;

import java.io.InputStream;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import net.sf.json.JSONArray;



public class JsonSerializer {
	
	@SuppressWarnings("unchecked")
	public static <T> List<T> read(InputStream fis, Class<T> clazz) throws Exception {
		byte[] data = new byte[fis.available()];
		fis.read(data);
		String json = new String(data, "UTF-8").trim();
		JSONArray jsonArray = JSONArray.fromObject(json);
//		List<T> list = new ArrayList<T>();
//		for(Map map : mapList){
//			T t = clazz.newInstance();
//			BeanUtils.copyProperties(map, t);
////			Set<String> keySet = map.keySet();
////			for(String key : keySet){
//////				Field field = clazz.getField(key);
//////				field.setAccessible(true);
////				
////				Object value = map.get(key);
////				
////				System.out.println(String.format("key [%s], value[%s]", key, value));
////				
////				BeanUtils.copyProperties(map, t);
////			}
//			
//			list.add(t);
//		}
		
		
		T[] array = (T[])JSONArray.toArray(jsonArray, clazz);
		if(array != null){
			return Arrays.asList(array);
		}
		return Collections.emptyList();
		
	}
	
}
