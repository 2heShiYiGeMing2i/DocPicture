/**
 * 
 */
package com.xx.common.db.service;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

/**
 * @author fansth
 *
 */
public abstract class ManagerSupport extends HibernateDaoSupport {

	@Autowired  
    public void setSessionFactory0(SessionFactory sessionFactory){   
    	super.setSessionFactory(sessionFactory);   
    }
	
}
