package com.xx.common.utility.mvel;

import java.io.Serializable;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.mvel2.MVEL;
import org.mvel2.ParserContext;
import org.mvel2.optimizers.OptimizerFactory;

/**
 * 公式处理助手类
 */
public class MvelHelper {
	
	private static ThreadLocal<Map<String, Serializable>> threadLocal = new ThreadLocal<Map<String,Serializable>>();

	static {
		OptimizerFactory.setDefaultOptimizer("ASM");
	}

	/**
	 * 获取已编译的表达式
	 * 
	 * @param expression 			表达式
	 * @return {@link Serializable}	已编译表达式
	 */
	private static Serializable getCompiledExpression(String expression) {
		Map<String, Serializable> map = threadLocal.get();
		if(map == null) {
			synchronized (threadLocal) {
				map = new ConcurrentHashMap<String, Serializable>();
				threadLocal.set(map);
			}
		}
		
		Serializable expr = map.get(expression);		
		if(expr == null) {
			ParserContext ctx = new ParserContext();
			ctx.setCompiled(true);
			ctx.setStrictTypeEnforcement(true);
			ctx.addInput("X", Map.class);
			ctx.addInput("Y", Map.class);
			MVEL.analysisCompile(expression, ctx);
			expr = MVEL.compileExpression(expression, ctx);
			
			map.put(expression, expr);
		}
		
		return expr;
	}
	
	// ----------------------------------------

	/**
	 * 执行公式表达式
	 * 
	 * @param  expression 		公式表达式
	 * @param  ctx 				公式执行上下文
	 * @return {@link Number}	公式表达式执行结果
	 */
	public static Number invoke(String expression, Map<String, ?> ctx) {
		Serializable compiledExpression = getCompiledExpression(expression);
		if(compiledExpression == null) {
			return null;
		}
		
		return invoke(expression, ctx, Double.class);
	}

	/**
	 * 执行公式表达式
	 * 
	 * @param  expression 		公式表达式
	 * @param  ctx 				公式执行上下文
	 * @return {@link Number}	公式表达式执行结果
	 */
	public static <T> T invoke(String expression, Map<String, ?> ctx, Class<T> resultType) {
		Serializable compiledExpression = getCompiledExpression(expression);
		if(compiledExpression == null) {
			return null;
		}
		// 一律使用Double进行计算
		return MVEL.executeExpression(compiledExpression, ctx, resultType);
	}

}
