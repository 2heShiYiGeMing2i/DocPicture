/**
 * 
 */
package com.xx.common.utility;

import java.io.Serializable;
import java.util.List;

/**
 * 分页对象
 * @author fansth
 *
 */
public class Page<T> implements Serializable{

	private static final long serialVersionUID = -2710723003307841155L;

	/**
	 * 总记录数
	 */
	private int totalSize;
	
	/**
	 * 在总记录列表中从这个索引位置开始取记录(>=0)
	 */
	private int startIndex;
	
	/**
	 * 从startIndex处开始取这么多条记录
	 */
	private int pageSize;
	
	/**
	 * 取到的结果列表
	 */
	private List<T> pageList;
	
	
	public static <T> Page<T> valueOf(int totalSize, int startIndex, int pageSize, List<T> pageList){
		Page<T> page = new Page<T>();
		page.totalSize = totalSize;
		page.startIndex = startIndex;
		page.pageSize = pageSize;
		page.pageList = pageList;
		return page;
	}


	public int getTotalSize() {
		return totalSize;
	}


	public int getStartIndex() {
		return startIndex;
	}


	public int getPageSize() {
		return pageSize;
	}


	public List<T> getPageList() {
		return pageList;
	}


	public void setTotalSize(int totalSize) {
		this.totalSize = totalSize;
	}


	public void setStartIndex(int startIndex) {
		this.startIndex = startIndex;
	}


	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}


	public void setPageList(List<T> pageList) {
		this.pageList = pageList;
	}
	
	
	
}
