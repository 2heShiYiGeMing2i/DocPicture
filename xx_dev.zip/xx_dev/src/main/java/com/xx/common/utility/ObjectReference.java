/**
 * 
 */
package com.xx.common.utility;

/**
 * 对象引用类
 * @author fansth
 *
 */
public class ObjectReference<T> {
	
	private T object = null;
	
	@SuppressWarnings("unchecked")
	public ObjectReference(Object object){
		this.object = (T)object;
	}
	
	public ObjectReference(){
	}

	public T getObject() {
		return (T)object;
	}

	@SuppressWarnings("unchecked")
	public void setObject(Object object) {
		this.object = (T)object;
	}
	
}
