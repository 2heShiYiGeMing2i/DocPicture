/**
 * 
 */
package com.xx.common.basedb;

import java.util.List;

import com.xx.common.basedb.anno.Index;

/**
 * 基础数据服务类
 * @author fansth
 *
 */
public interface BasedbService {
	
	/**
	 * 根据id获取指定类的实体
	 * @param <T>
	 * @param clazz 实体类对象
	 * @param id 主键
	 * @return
	 */
	<T> T get(Class<T> clazz, Object id);
	
	/**
	 * 根据索引键、值获取实体列表
	 * @param <T>
	 * @param clazz 实体类对象
	 * @param indexName 索引名
	 * @param indexValues 索引值(顺序对应 {@link Index#order})
	 * @return List<T>
	 */
	<T> List<T> listByIndex(Class<T> clazz, String indexName, Object... indexValues);
	
	/**
	 * 根据索引键、值获取唯一实体
	 * @param <T>
	 * @param clazz 实体类对象
	 * @param indexName 索引名
	 * @param indexValues 索引值(顺序对应 {@link Index#order})
	 * @return T
	 */
	<T> T getByUnique(Class<T> clazz, String indexName, Object... indexValues);
	
	/**
	 * 获取最小值
	 * @param clazz 实体类对象
	 * @param minmaxName minmax名
	 * @return 返回一定不空的数字默认是0
	 */
	Number getMinValue(Class<?> clazz, String minmaxName);
	
	/**
	 * 获取最大值
	 * @param clazz 实体类对象
	 * @param minmaxName minmax名
	 * @return 返回一定不空的数字默认是0
	 */
	Number getMaxValue(Class<?> clazz, String minmaxName);
	
	/**
	 * 获取所有指定类的实例集合
	 * @param <T>
	 * @param clazz 实体类对象
	 * @return
	 */
	<T> List<T> listAll(Class<T> clazz);
	
	/**
	 * 获取所有指定类的id列表集合
	 * @param <T>
	 * @param clazz 实体类对象
	 * @return
	 */
	List<?> listId(Class<?> clazz);
	
	/**
	 * 重新加载所有的基础数据
	 */
	void reloadAll();
	
	/**
	 * 重新加载指定的类
	 * @param clazz
	 */
	void reload(Class<?>... classes);
	
}
