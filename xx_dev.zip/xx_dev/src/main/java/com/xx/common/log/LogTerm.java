package com.xx.common.log;

import static com.xx.common.util.Splitable.*;

/**
 * 日志的条目
 * 
 * @author Hyint
 */
public class LogTerm {
	
	/**
	 * 条目名称
	 */
	private String name;
	
	/**
	 * 条目值
	 */
	private Object value;
	
	
	private LogTerm(String name, Object value) {
		this.name = name;
		this.value = value;
	}

	/**
	 * 构建一个日志子项
	 * 
	 * @param name 条目名称
	 * @param value 条目值
	 */
	public static LogTerm valueOf(String name, Object value) {
		return new LogTerm(name, value);
	}
	
	/**
	 * 将若干个{@link LogTerm}信息变成: 名字1:信息1 的字符串
	 * 
	 * @return {@link String}	返回构造后的字符串
	 */
	@Override
	public String toString() {
		return name + DELIMITER_ARGS + value;
	}
	
	/**
	 * 将若干个{@link LogTerm}信息变成: 名字1:信息1|名字2:信息2|... 的字符串
	 * 
	 * @param  terms			{@link LogTerm}可变参
	 * @return {@link String}	返回构造后的字符串
	 */
	public static String toString(LogTerm... terms) {
		StringBuilder builder = new StringBuilder();
		for (LogTerm obj : terms) {
			builder.append(obj).append(BETWEEN_ITEMS);
		}
		if (builder.length() > 0) {
			builder.deleteCharAt(builder.length() - 1);
		}
		return builder.toString();
	}
}