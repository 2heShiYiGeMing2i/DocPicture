/**
 * 
 */
package com.xx.common.utility.rank;

/**
 * 可排名抽象类(比较的时候越小越靠前哦,如果排序数据没有变化就返回0哦)
 * @author fansth
 *
 */
public abstract class Rankable implements Comparable<Rankable>{

	/**
	 * 排名
	 */
	protected int rank;
	
	/**
	 * 主体id(一般就是玩家id或者联盟id等)
	 */
	protected long ownerId;

	public int getRank() {
		return rank;
	}

	public void setRank(int rank) {
		this.rank = rank;
	}

	public long getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(long ownerId) {
		this.ownerId = ownerId;
	}
	
//	public abstract boolean before(Rankable other);
//	
//	public abstract boolean after(Rankable other); 
	
}
