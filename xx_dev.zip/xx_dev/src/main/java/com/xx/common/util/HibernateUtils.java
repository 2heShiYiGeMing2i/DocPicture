/**
 * 
 */
package com.xx.common.util;

import java.util.Collection;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.orm.hibernate3.SessionFactoryUtils;

/**
 * hibernate工具类
 * @author fansth
 *
 */
public class HibernateUtils extends SessionFactoryUtils {
	
	private static final Logger logger = LoggerFactory.getLogger(HibernateUtils.class);
	
	/**
	 * 获取sessionFactroy托管的所有实体类
	 * @param sessionFactory
	 * @return
	 */
	public static Collection<Class<?>> getAllEntityClass(SessionFactory sessionFactory){
		Set<Class<?>> classSet = new HashSet<Class<?>>();
		@SuppressWarnings("unchecked")
		Map<String, ?> classMap = sessionFactory.getAllClassMetadata();
		for(String className : classMap.keySet()){
			try {
				Class<?> clazz = Class.forName(className);
				classSet.add(clazz);
			} catch (ClassNotFoundException e) {
				logger.error("类不存在!", e);
			}
		}
		return classSet;
	}
	
	
}
