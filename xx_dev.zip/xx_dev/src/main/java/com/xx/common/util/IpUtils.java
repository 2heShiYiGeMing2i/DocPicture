package com.xx.common.util;

import java.net.InetSocketAddress;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.apache.mina.core.session.IoSession;


/**
 * 简单ip相关工具类
 * 
 * @author bingshan
 */
public abstract class IpUtils {
	
	/**
	 * 将IP地址转换为正则表达式
	 * @param ip IP地址
	 * @return Pattern
	 */
	public static Pattern ipToPattern(String ip) {
		if (StringUtils.isBlank(ip)) {
			return null;
		}
		
		String reg = ip.trim().replace(".", "[.]").replace("*", "[0-9]*");
		Pattern pattern = Pattern.compile(reg);
		return pattern;
	}
	
	/**
	 * 取得会话远程ip
	 * @param session {@link IoSession}
	 * @return String
	 */
	public static String getRemoteIp(IoSession session) {
		InetSocketAddress addr = (InetSocketAddress) session.getRemoteAddress();		
		if (addr == null) {
			return null;
		}
		
		String ip = addr.getAddress().getHostAddress();
		return ip;
	}
}
