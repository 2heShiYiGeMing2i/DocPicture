/**
 * 
 */
package com.xx.common.basedb;

/**
 * @author fansth
 *
 */
public interface BasedbListener {

	/**
	 * 当所有的实体加载后调用
	 */
	void onBasedbReload(Class<?>... reloadedClass);
	
}
