package com.xx.common.log;

/**
 * 日志类型
 * 
 * @author Hyint
 */
public enum LogType {
	
	/**
	 * 性能分析故障排解
	 */
	PROFILE("PROFILE"),
	
	/**
	 * 注册日志
	 */
	CREATER_USER("CREATER_USER"),
	
	/**
	 * 登陆日志
	 */
	LOGIN("LOGIN"),
	
	/**
	 * 金钱
	 */
	MONEY("MONEY"),
	
	/**
	 * 银元
	 */
	SLIVER("SLIVER"),
	
	/**
	 * 粮草
	 */
	FOODS("FOODS"),
	
	/**
	 * 体力
	 */
	ENERGY("ENERGY"),
	
	/**
	 * 体力Buff
	 */
	ENERGY_BUFF("ENERGY_BUFF"),
	
	/**
	 * 经验
	 */
	EXP("EXP"),
	
	/**
	 * 武将经验
	 */
	SOUL("SOUL"),
	
	/**
	 * 水晶
	 */
	CRYSTAL("CRYSTAL"),
	
	/**
	 * 声望
	 */
	FAME("FAME"),
	
	/**
	 * 功勋
	 */
	EXPLOIT("EXPLOIT"),
	
	/**
	 * 积分
	 */
	CREDIT("CREDIT"),
	
	/**
	 * 战魂
	 */
	DRILL_EXP("DRILL_EXP"),
	
	/**
	 * 道具
	 */
	ITEM("ITEM"),
	
	/**
	 * 武将装备
	 */
	HERO_EQUIP("HERO_EQUIP"),
	
	/**
	 * 命签
	 */
	DIVINATION("DIVINATION"),
	
	/**
	 * 开启VIP
	 */
	OPEN_VIP("OPEN_VIP"),
	
	/**
	 * 商城购买|兑换
	 */
	SHOP_BUY("SHOP_BUY"),
	
	/**
	 * 武将下野|被吞并
	 */
	HERO_COST("HERO_COST"),
	
	/**
	 * 武将装备出售
	 */
	SELL_HERO_EQUIP("SELL_HERO_EQUIP"),
	
	/**
	 * 主公装备出售
	 */
	SELL_EQUIP("SELL_EQUIP"),
	
	/**
	 * 领取全服任务奖励
	 */
	RECEIVE_SERVER_TASK_REWARD("RECEIVE_SERVER_TASK_REWARD"),
	
	/**
	 * 重置全服任务奖励
	 */
	RESET_SERVER_TASK("RESET_SERVER_TASK"),
	
	/**
	 * 跑环日志监控
	 */
	LOOPFIX("LOOPFIX"),
	
	/**
	 * 酒馆日志监控
	 */
	PLUNDERFOOD("PLUNDERFOOD"),
	
	/**
	 * 全服礼包日志监控
	 */
	SERVER_GIFT("SERVER_GIFT"),
	
	/**
	 * 登出日志
	 */
	LOGOUT("LOGOUT"),
	
	/**
	 * 充值玩家信息日志
	 */
	CHARGE_PLAYER("CHARGE_PLAYER"),
	
	/**
	 * 爬塔pve資源銷售
	 */
	SELL_TOWER_RESOURCE("SELL_TOWER_RESOURCE");
	
	/** 日志名*/
	private String logName = "";
	
	/**
	 * 日志类型
	 * 
	 * @param logName		日志名
	 */
	LogType(String name) {
		this.logName = name;
	}

	public String getLogName() {
		return logName;
	}

	public void setLogName(String logName) {
		this.logName = logName;
	}
	
}
