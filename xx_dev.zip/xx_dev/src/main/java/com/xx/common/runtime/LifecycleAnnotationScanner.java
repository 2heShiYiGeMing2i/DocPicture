/**
 * 
 */
package com.xx.common.runtime;

import java.lang.reflect.Method;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.helpers.FormattingTuple;
import org.slf4j.helpers.MessageFormatter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.stereotype.Component;
import org.springframework.util.ReflectionUtils;
import org.springframework.util.ReflectionUtils.MethodCallback;

import com.xx.common.utility.thread.NamedRunnable;

/**
 * 注解扫描器
 * @author fansth
 *
 */
@Component
public class LifecycleAnnotationScanner implements ApplicationListener<ContextRefreshedEvent>{
	
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private ApplicationContext applicationContext;
	
	/**
	 * 扫描一个
	 * @param bean
	 */
	private void scanBean(final Object bean){
		ReflectionUtils.doWithMethods(bean.getClass(), new MethodCallback() {
			
			@Override
			public void doWith(final Method method) throws IllegalArgumentException,IllegalAccessException {
				final LifecycleMethod lifecycleMethod = AnnotationUtils.getAnnotation(method, LifecycleMethod.class);
				if(lifecycleMethod != null){
					if(method.getParameterTypes() != null && method.getParameterTypes().length > 0){
						FormattingTuple tuple = MessageFormatter.arrayFormat("处理链方法  [{}#{}] 不能有参数!", new Object[]{bean.getClass().getName(), method.getName()});
						throw new RuntimeException(tuple.getMessage());
					}
					method.setAccessible(true);
					final String lifecycleName = lifecycleMethod.name();
					LifecycleManager.registerLifecycle(lifecycleMethod.lifecycle(), new NamedRunnable() {
						
						@Override
						public void run() {
							try {
								method.invoke(bean);
							} catch (Exception e) {
								FormattingTuple tuple = MessageFormatter.format("执行 [{}] 阶段 [{}] 任务错误!", lifecycleMethod.lifecycle(), lifecycleName);
								logger.error(tuple.getMessage(), e);
							}
						}
						
						@Override
						public String getName() {
							return lifecycleName;
						}
					});
				}
			}
		});
	}

	@Override
	public void onApplicationEvent(ContextRefreshedEvent event) {
		Map<String, Object> beans = applicationContext.getBeansOfType(Object.class);
		for(Object bean : beans.values()){
			this.scanBean(bean);
		}
	}

}
