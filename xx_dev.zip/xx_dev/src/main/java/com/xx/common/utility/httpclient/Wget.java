/**
 * 
 */
package com.xx.common.utility.httpclient;

/**
 * 用于测试的wget
 * @author fansth
 *
 */
public class Wget {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String url = args[0];
		System.out.println("请求url：" +url);
		SingleHttpClient simpleHttpClient = new SingleHttpClient();
		System.out.println("返回结果" + simpleHttpClient.requestForString(url, HttpMethod.GET));
	}

}
