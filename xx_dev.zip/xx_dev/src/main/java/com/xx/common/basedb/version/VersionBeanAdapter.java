package com.xx.common.basedb.version;

import java.util.Date;

import org.apache.commons.lang.StringUtils;

import com.xx.common.util.DatePattern;
import com.xx.common.util.DateUtil;


/**
 * 基础数据区分版本适配器
 * 
 * @author bingshan
 */
public abstract class VersionBeanAdapter implements VersionBean {
	
	/**
	 * 开服时间段,格式：yyyyMMdd_yyyyMMdd (包含起始日期, 不包含结束日期)
	 */
	protected String serverSection;
	
	

	@Override
	public boolean isBasicDataActived(Date versionTime) {
		if (StringUtils.isBlank(this.serverSection)) {
			return true;
		}
		
		String[] arr = this.serverSection.split("_");
		if (arr == null || arr.length == 0) {
			return true;
		}
		
		String start = arr[0];
		String end = "21000101";
		if (arr.length > 1) {
			end = arr[1];
		}
		
		if (versionTime == null) {
			versionTime = new Date();
		}
		
		String compareDay = DateUtil.date2String(versionTime, DatePattern.PATTERN_YYYYMMDD);
		return compareDay.compareTo(start) >= 0 && compareDay.compareTo(end) < 0;
	}

	public String getServerSection() {
		return serverSection;
	}

	public void setServerSection(String serverSection) {
		this.serverSection = serverSection;
	}
}
