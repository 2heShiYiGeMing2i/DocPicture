/**
 * 
 */
package com.xx.common.utility.upgrade;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * 升级对象
 * @author fansth
 *
 */
public class Upgrader<T extends Upgradeable> {

	private int currentLevel;
	
	private long currentValue;
	
	private List<T> growList;
	
	public Upgrader(int currentLevel, long currentValue, List<T> growList){
		this.currentLevel = currentLevel;
		this.currentValue = currentValue;
		this.growList = growList;
		Collections.sort(this.growList, new Comparator<T>() {
			@Override
			public int compare(T o1, T o2) {
				return o1.getLevel() < o2.getLevel() ? -1 : 1;
			}
		});
	}
	
	public UpgradeResult upgrade(long addGrowValue){
		boolean upgrade = false;
		this.currentValue += addGrowValue;
		for(int i = 0; i < growList.size(); i++){
			Upgradeable upgradeable = growList.get(i);
			if(upgradeable.getLevel() == currentLevel){
				if(currentValue  >= upgradeable.getUpgradeValue()){//升级了
					if(i < growList.size() - 1){
						currentLevel++;
						currentValue -= upgradeable.getUpgradeValue();
						upgrade = true;
					} else {
						if(upgradeable.getUpgradeValue() > 0){
							currentValue = upgradeable.getUpgradeValue() - 1;
						}
						break;
					}
				} else {
					break;
				}
			} 
		}
		return new UpgradeResult(upgrade, currentLevel, currentValue);
	}
	
}
