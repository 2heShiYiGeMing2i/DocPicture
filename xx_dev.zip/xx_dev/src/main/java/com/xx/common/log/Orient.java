package com.xx.common.log;

/**
 * 收支情况对象
 * 
 * @author Hyint
 */
public enum Orient {

	/** 0-收入 */
	INCOME(0),
	
	/** 1-支出 */
	OUTCOME(1);

	/** 下标 */
	private int code = -1;
	
	Orient(int code) {
		this.code = code;
	}
	
	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}
	
	
}
