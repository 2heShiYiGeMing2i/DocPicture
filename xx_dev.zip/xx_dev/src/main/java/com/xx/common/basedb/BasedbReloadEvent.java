/**
 * 
 */
package com.xx.common.basedb;

import org.springframework.context.ApplicationContext;
import org.springframework.context.event.ApplicationContextEvent;

/**
 * 基础数据已加载完毕事件
 * @author fansth
 *
 */
public class BasedbReloadEvent extends ApplicationContextEvent {

	private static final long serialVersionUID = 3736694453466621055L;

	public BasedbReloadEvent(ApplicationContext source) {
		super(source);
	}
	
}
