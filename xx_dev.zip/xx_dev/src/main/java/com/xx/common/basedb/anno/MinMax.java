package com.xx.common.basedb.anno;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 字段的最大最小值
 * @author fansth
 *
 */
@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)
public @interface MinMax {
	
	/**
	 * 名字默认是字段名
	 * @return
	 */
	String name() default "";
	
}
