package com.xx.common.socket;

import static com.xx.common.socket.constant.ServerConfigConstant.POOL_CORE_SIZE;
import static com.xx.common.socket.constant.ServerConfigConstant.POOL_KEEP_ALIVE_TIME;
import static com.xx.common.socket.constant.ServerConfigConstant.POOL_MAX_SIZE;
import static com.xx.common.socket.constant.ServerConfigConstant.SERVER_PORT;
import static com.xx.common.socket.constant.ServerConfigConstant.SESSION_IDLE_TIME;
import static com.xx.common.socket.constant.ServerConfigConstant.SESSION_READ_BUFF;
import static com.xx.common.socket.constant.ServerConfigConstant.SESSION_SEND_BUFF;

import java.util.Properties;

/**
 * 服务器配置信息
 * 
 * @author bingshan
 */
public class ServerConfig {
	
	/**
	 * 端口号
	 */
	private int port = 10101;
	
	/**
	 * session读缓存大小
	 */
	private int sessionReadBuffer = 2048;
	
	/**
	 * session写缓存大小
	 */
	private int sessionSendBuffer = 2048;
	
	/**
	 * session IdleTime
	 */
	private int sessionIdleTime = 300;
	
	/**
	 * 最小线程数
	 */
	private int poolCoreSize = 16;
	
	/**
	 * 最大线程数
	 */
	private int poolMaxSize = 64;
	
	/**
	 * KeepAliveTime
	 */
	private long poolKeepAliveTime = 30000L;
	
	public static ServerConfig valueOf(Properties properties) {
		ServerConfig cfg = new ServerConfig();
		
		String serverPort = properties.getProperty(SERVER_PORT);
		if (serverPort != null) {
			cfg.setPort(Integer.valueOf(serverPort));
		}
		
		String readBuff = properties.getProperty(SESSION_READ_BUFF);
		if (readBuff != null) {
			cfg.setSessionReadBuffer(Integer.valueOf(readBuff));
		}
		
		String sendBuff = properties.getProperty(SESSION_SEND_BUFF);
		if (sendBuff != null) {
			cfg.setSessionSendBuffer(Integer.valueOf(sendBuff));
		}
		
		String idleTime = properties.getProperty(SESSION_IDLE_TIME);
		if (idleTime != null) {
			cfg.setSessionIdleTime(Integer.valueOf(idleTime));
		}
		
		String poolMin = properties.getProperty(POOL_CORE_SIZE);
		if (poolMin != null) {
			cfg.setPoolCoreSize(Integer.valueOf(poolMin));
		}
		
		String poolMax = properties.getProperty(POOL_MAX_SIZE);
		if (poolMax != null) {
			cfg.setPoolMaxSize(Integer.valueOf(poolMax));
		}
		
		String aliveTime = properties.getProperty(POOL_KEEP_ALIVE_TIME);
		if (aliveTime != null) {
			cfg.setPoolKeepAliveTime(Long.valueOf(aliveTime));
		}
		return cfg;
	}

	public int getPort() {
		return port;
	}

	public void setPort(int port) {
		this.port = port;
	}

	public int getSessionReadBuffer() {
		return sessionReadBuffer;
	}

	public void setSessionReadBuffer(int sessionReadBuffer) {
		this.sessionReadBuffer = sessionReadBuffer;
	}

	public int getSessionSendBuffer() {
		return sessionSendBuffer;
	}

	public void setSessionSendBuffer(int sessionSendBuffer) {
		this.sessionSendBuffer = sessionSendBuffer;
	}

	public int getSessionIdleTime() {
		return sessionIdleTime;
	}

	public void setSessionIdleTime(int sessionIdleTime) {
		this.sessionIdleTime = sessionIdleTime;
	}

	public int getPoolCoreSize() {
		return poolCoreSize;
	}

	public void setPoolCoreSize(int poolCoreSize) {
		this.poolCoreSize = poolCoreSize;
	}

	public int getPoolMaxSize() {
		return poolMaxSize;
	}

	public void setPoolMaxSize(int poolMaxSize) {
		this.poolMaxSize = poolMaxSize;
	}

	public long getPoolKeepAliveTime() {
		return poolKeepAliveTime;
	}

	public void setPoolKeepAliveTime(long poolKeepAliveTime) {
		this.poolKeepAliveTime = poolKeepAliveTime;
	}
	
	

}
