package com.xx.common.db.cache;


/**
 * DbCached 配置常量约定
 */
public interface DbCachedCfgConstant {
	
	/**
	 * 分隔符定义
	 */
	String SPLIT = ",";
	
	/**
	 * 实体缓存最大容量
	 */
	String KEY_MAX_CAPACITY_OF_ENTITY_CACHE = "dbcache.entitycache.maxcapacity";
	
	/**
	 * 通用缓存最大容量
	 */
	String KEY_MAX_CAPACITY_OF_COMMON_CACHE = "dbcache.commoncache.maxcapacity";
	
	/**
	 * 入库线程池容量
	 */
	String KEY_DB_POOL_CAPACITY = "dbcache.dbpool.capacity";
	
	/**
	 * 服务器ID标识集合(1~89999, 多个以","隔开)
	 */
	String KEY_SERVER_ID_SET = "dbcache.server.id.set";

}
