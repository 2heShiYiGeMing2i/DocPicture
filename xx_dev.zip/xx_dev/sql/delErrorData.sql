-- --------------------------------------------------------------------------------------------
--
-- 移除错误的数据 （部分玩家id=0的错误数据）,备份会引起主键重复的数据
-- 
-- --------------------------------------------------------------------------------------------

-- 决战长安记录(错误记录)
DELETE FROM playerDecisiveRecord WHERE id = 0;

-- 删除玩家活动信息(错误记录)
DELETE FROM playerActivity WHERE playerId = 0;

-- 删除错误的掉落记录
DELETE FROM dropRecord WHERE id <= 0;

-- 创建自定义活动的备份表
CREATE TABLE IF NOT EXISTS `customActivity_bak` (
  `id` int(11) NOT NULL COMMENT '主键id',
  `actDesc` text COLLATE utf8_unicode_ci COMMENT '活动描述',
  `actName` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT '活动名',
  `actType` tinyint(3) DEFAULT '0' COMMENT '活动类型, 0-充值  1-消费',
  `endTime` datetime DEFAULT NULL COMMENT '活动结束时间',
  `startTime` datetime DEFAULT NULL COMMENT '活动开始时间',
  `status`  tinyint(3) NOT NULL DEFAULT 1 COMMENT '活动状态, 0-关闭  1-开启',
  PRIMARY KEY (`id`),
  KEY `customActivity_idx_endTime` (`endTime`),
  KEY `customActivity_idx_status` (`status`) 
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
-- 复制自定义活动到自定义活动备份表
INSERT INTO customActivity_bak(`id`, `actDesc`, `actName`, `actType`, `endTime`, `startTime`, `status`) 
SELECT `id`, `actDesc`, `actName`, `actType`, `endTime`, `startTime`, `status` FROM customActivity 
WHERE id NOT IN (SELECT a.id FROM customActivity_bak a);
-- 删除自定义活动表
DELETE FROM customActivity;

-- 创建自定义任务的备份表
CREATE TABLE IF NOT EXISTS `customTask_bak` (
  `id` int(11) NOT NULL COMMENT '主键id',
  `activityId` int(11) NOT NULL COMMENT '所属活动id',
  `targets` text COLLATE utf8_unicode_ci COMMENT '任务目标',
  `taskReward` text COLLATE utf8_unicode_ci COMMENT '任务奖励',
  PRIMARY KEY (`id`),
  KEY `customTask_idx_activityId` (`activityId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
-- 复制自定义任务到自定义任务备份表
INSERT INTO customTask_bak(`id`, `activityId`, `targets`, `taskReward`) 
SELECT `id`, `activityId`, `targets`, `taskReward` FROM customTask 
WHERE id NOT IN (SELECT t.id FROM customTask_bak t);
-- 删除自定义任务表
DELETE FROM customTask;

-- 创建市场购买限制记录备份表
CREATE TABLE IF NOT EXISTS `playerMarket_bak` (
  `id` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '主键',
  `buyTime` datetime DEFAULT '2013-01-01 00:00:00' COMMENT '购买物品的时间',
  `everydayAmount` int(11) DEFAULT '0' COMMENT '每日购买数量',
  `totalAmount` bigint(20) DEFAULT '0' COMMENT '总购买数量',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
-- 复制市场购买限制记录到市场购买记录备份表
INSERT INTO playerMarket_bak(`id`, `buyTime`, `everydayAmount`, `totalAmount`) 
SELECT `id`, `buyTime`, `everydayAmount`, `totalAmount` FROM playerMarket 
WHERE id NOT IN (SELECT t.id FROM playerMarket_bak t);
-- 删除市场购买限制记录表
DELETE FROM playerMarket;

-- 创建keyValue备份表
CREATE TABLE IF NOT EXISTS `keyValue_bak` (
  `propKey` char(255) COLLATE utf8_unicode_ci NOT NULL COMMENT '属性键',
  `propValue` longtext COLLATE utf8_unicode_ci COMMENT '属性值',
  PRIMARY KEY (`propKey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
-- 复制keyValue记录到keyValue备份表
INSERT INTO keyValue_bak(`propKey`, `propValue`) 
SELECT `propKey`, `propValue` FROM keyValue 
WHERE propKey NOT IN (SELECT t.propKey FROM keyValue_bak t);
-- 删除keyValue表
DELETE FROM keyValue;

