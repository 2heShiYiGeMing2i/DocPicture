-- ------------------------------------------------------------------------------------------
--
-- 合服后在合服上按顺序执行 
-- 
-- ------------------------------------------------------------------------------------------


-- ----------------------------
-- 存储过程开始
-- ----------------------------

DELIMITER // 

-- ----------------------------
-- 主公重名处理存储过程
-- ----------------------------

DROP PROCEDURE IF EXISTS sp_RenamePlayerName //
CREATE PROCEDURE sp_RenamePlayerName()
BEGIN
	DECLARE playerName1 varchar(200) DEFAULT '';
	DECLARE id1 BIGINT DEFAULT -1;
	DECLARE hadMore boolean DEFAULT TRUE;

	-- 重名的角色名
	DECLARE playerNameCursor CURSOR FOR SELECT playerName FROM 
			(SELECT playerName, count(id) as count FROM player GROUP BY playerName) as tmp WHERE tmp.count > 1;

	-- 重名的玩家id
	DECLARE renameCursor CURSOR FOR SELECT id FROM player 
			WHERE playerName = (playerName1 COLLATE utf8_unicode_ci) ORDER BY level DESC, registerTime;

	DECLARE CONTINUE HANDLER FOR NOT found SET hadMore = FALSE;

	DROP TABLE IF EXISTS renamePlayer;
	CREATE TEMPORARY TABLE renamePlayer
	(
		id BIGINT(20) PRIMARY KEY
	);

	OPEN playerNameCursor;
	FETCH playerNameCursor INTO playerName1;
	WHILE (hadMore) DO
		SET @index = 1;
		OPEN renameCursor;
		FETCH renameCursor INTO id1;
		WHILE (hadMore) DO
			-- 第一个保留原来的角色名
			IF (@index != 1) THEN 
				INSERT INTO renamePlayer values (id1);
			END IF;
			
			FETCH renameCursor INTO id1;
			SET @index = @index + 1;
		END WHILE;
		CLOSE renameCursor;

		SET hadMore = TRUE;
		FETCH playerNameCursor INTO playerName1;
	END WHILE;

	-- 修改角色名称，重命名状态
	UPDATE player SET playerName = CONCAT(playerName, "_", SERVER), mustRename = 1
	WHERE id IN 
	(SELECT id FROM renamePlayer);

	CLOSE playerNameCursor;
	DROP TABLE renamePlayer;
END //

-- ----------------------------
-- 军团重名处理存储过程
-- ----------------------------

DROP PROCEDURE IF EXISTS sp_RenameArmyGroupName //
CREATE PROCEDURE sp_RenameArmyGroupName()
BEGIN
	DECLARE serverId INT DEFAULT -1;
	DECLARE armyGroupName varchar(200) DEFAULT '';
	DECLARE id1 BIGINT DEFAULT -1;
	DECLARE hadMore boolean DEFAULT TRUE;

	-- 重名的军团名称
	DECLARE armyGroupNameCursor CURSOR FOR SELECT `name` FROM 
	(SELECT `name`, count(id) as count FROM armyGroup GROUP BY `name`) as tmp WHERE tmp.count > 1;

	-- 重名的军团id
	DECLARE renameCursor CURSOR FOR SELECT a.id FROM armyGroup a 
	WHERE a.`name` = (armyGroupName COLLATE utf8_unicode_ci) ORDER BY a.wealth DESC;

	DECLARE CONTINUE HANDLER FOR NOT found SET hadMore = FALSE;

	DROP TABLE IF EXISTS renameArmyGroup;
	CREATE TEMPORARY TABLE renameArmyGroup
	(
		id BIGINT(20) PRIMARY KEY,
		`server` int(11) NOT NULL
	);

	OPEN armyGroupNameCursor;
	FETCH armyGroupNameCursor INTO armyGroupName;
	WHILE (hadMore) DO
		SET @index = 1;
		OPEN renameCursor;
		FETCH renameCursor INTO id1;
		WHILE (hadMore) DO
			-- 第一个保留原来的名称
			IF (@index != 1) THEN 
				INSERT INTO renameArmyGroup values (id1, @index);
			END IF;
			
			SET hadMore = TRUE;
			FETCH renameCursor INTO id1;
			SET @index = @index + 1;
		END WHILE;
		CLOSE renameCursor;

		SET hadMore = TRUE;
		FETCH armyGroupNameCursor INTO armyGroupName;
	END WHILE;

	-- 修改军团名称，重命名状态
	UPDATE armyGroup a INNER JOIN renameArmyGroup b ON a.id = b.id
	SET a.`name` = CONCAT(b.`server`, "_", a.`name`), a.mustRename = 1
	WHERE a.id = b.id;

	-- 发送军团改名邮件
	SET @currTime = NOW();
	SET @endTime = DATE_ADD(@currTime,INTERVAL 3 DAY);

	INSERT INTO mail (
	id, addtion, content, createTime, endTime, 
	hadAddtion, jsonKeyValues, mailTemplateId, 
	senderId, senderName, startTime, targetId, 
	title, type) 
	SELECT a.id, '', 
	CONCAT('由于服务器合并，您的军团名称与其他军团重名，系统已将您的军团名更改为', a.`name`, '以便您更加方便的进行游戏!'), 
	@currTime, @endTime, 0, '', -1, 0, a.`name`, @currTime, a.id, '军团改名', 6
	FROM armyGroup a, renameArmyGroup b
	WHERE a.id = b.id;

	CLOSE armyGroupNameCursor;
	DROP TABLE renameArmyGroup;
END //

-- ----------------------------
-- 添加合服时间存储过程
-- ----------------------------

DROP PROCEDURE IF EXISTS sp_AddCombineTime //
CREATE PROCEDURE sp_AddCombineTime()
BEGIN
	SET @SERVER_COMBINE_TIME = NULL;
	SELECT propKey INTO @SERVER_COMBINE_TIME from keyValue WHERE propKey = 'SERVER_COMBINE_TIME' LIMIT 1;
	IF (@SERVER_COMBINE_TIME IS NULL) THEN 
		INSERT INTO keyValue VALUES('SERVER_COMBINE_TIME', NOW());
	ELSE
		UPDATE keyValue SET propValue = NOW() WHERE propKey = 'SERVER_COMBINE_TIME';
	END IF;
	
	-- 添加合服充值活动
	DELETE FROM `chargeActivity` WHERE id = -1000;
	INSERT INTO `chargeActivity` (`id`, `actName`, `actDesc`, `actType`, `endTime`, `rewardCfg`, `rewardTime`, `startTime`, `status`) 
	VALUES (-1000,'单笔充值活动','活动时间内，单笔充值订单充值金额满足以下条件即可获得相应礼包一份，多次充值可以多次领取奖励！',0,DATE_ADD(date_format(NOW(),'%Y-%m-%d 23:59:59'),INTERVAL 3 DAY),'[{\"value\":1000,\"amount\":99999999,\"reward\":\"[{\\\"type\\\":6,\\\"count\\\":200,\\\"id\\\":39000138,\\\"bind\\\":1},{\\\"type\\\":6,\\\"count\\\":1,\\\"id\\\":32000067,\\\"bind\\\":1}]\"},{\"value\":5000,\"amount\":99999999,\"reward\":\"[{\\\"type\\\":6,\\\"count\\\":1000,\\\"id\\\":39000138,\\\"bind\\\":1},{\\\"type\\\":6,\\\"count\\\":1,\\\"id\\\":32000069,\\\"bind\\\":1}]\"},{\"value\":10000,\"amount\":99999999,\"reward\":\"[{\\\"type\\\":6,\\\"count\\\":2000,\\\"id\\\":39000138,\\\"bind\\\":1},{\\\"type\\\":6,\\\"count\\\":2,\\\"id\\\":32000069,\\\"bind\\\":1},{\\\"type\\\":6,\\\"count\\\":600,\\\"id\\\":39000081,\\\"bind\\\":1}]\"},{\"value\":20000,\"amount\":99999999,\"reward\":\"[{\\\"type\\\":6,\\\"count\\\":4000,\\\"id\\\":39000138,\\\"bind\\\":1},{\\\"type\\\":6,\\\"count\\\":4,\\\"id\\\":32000069,\\\"bind\\\":1},{\\\"type\\\":6,\\\"count\\\":1200,\\\"id\\\":39000081,\\\"bind\\\":1},{\\\"type\\\":12,\\\"count\\\":30000}]\"},{\"value\":50000,\"amount\":99999999,\"reward\":\"[{\\\"type\\\":6,\\\"count\\\":10000,\\\"id\\\":39000138,\\\"bind\\\":1},{\\\"type\\\":6,\\\"count\\\":10,\\\"id\\\":32000069,\\\"bind\\\":1},{\\\"type\\\":6,\\\"count\\\":3000,\\\"id\\\":39000081,\\\"bind\\\":1},{\\\"type\\\":12,\\\"count\\\":75000},{\\\"type\\\":6,\\\"count\\\":100,\\\"id\\\":39000092,\\\"bind\\\":1}]\"},{\"value\":100000,\"amount\":99999999,\"reward\":\"[{\\\"type\\\":6,\\\"count\\\":20000,\\\"id\\\":39000138,\\\"bind\\\":1},{\\\"type\\\":6,\\\"count\\\":20,\\\"id\\\":32000069,\\\"bind\\\":1},{\\\"type\\\":6,\\\"count\\\":6000,\\\"id\\\":39000081,\\\"bind\\\":1},{\\\"type\\\":12,\\\"count\\\":150000},{\\\"type\\\":6,\\\"count\\\":200,\\\"id\\\":39000092,\\\"bind\\\":1},{\\\"type\\\":6,\\\"count\\\":5,\\\"id\\\":39000211,\\\"bind\\\":1}]\"}]',DATE_ADD(date_format(NOW(),'%Y-%m-%d 23:59:59'),INTERVAL 3 DAY),NOW(),1);
END //

DELIMITER ; 

-- ----------------------------
-- 存储过程 结束
-- ----------------------------

-- 修改重名的角色名
CALL sp_RenamePlayerName;

-- 修改重名的军团名称
CALL sp_RenameArmyGroupName;

-- 设置合服时间
CALL sp_AddCombineTime;

-- ----------------------------
-- 合服以后其他数据修改
-- ----------------------------
-- 好友邀请信息
UPDATE playerCheerInfo SET cheerId = -1,cheerState = 0,formation = null,cheerInfo = null,cdPlayerInfo = null; 

-- 征战天下将剩余免费剩数重置
UPDATE playerJourneyInfo set incomeDate = '2012-01-01 00:00:00';

-- 攻城掠地将剩余免费剩数、掠夺列表重置
UPDATE plunderMirror set incomeDate = '2012-01-01 00:00:00',plunderPlayer = null;

-- 玩家活动信息
DELETE FROM playerActivity where activityId not in (1, 13, 82, 83, 92, 93, 94, 95);

-- 玩家活动任务信息
DELETE FROM playerActivityTask where taskId not in (57000101,57000102,57000103,57000104,57000105,57000106,57000107,57000201,57000202,57000203,57000204,57000205,57008201,57008202,57008203,57008204,57008205,57008206,57008301,57008302,57008303,57008304,57008305,57008306,57009201,57009202,57009203,57009204,57009205,57009206,57009301,57009302,57009303,57009304,57009401,57009402,57009403,57009404,57009405,57009406,57009501,57009502,57009503,57009504);

-- 自定义活动(从备份表里面复制)
INSERT INTO customActivity(`id`, `actDesc`, `actName`, `actType`, `endTime`, `startTime`, `status`) 
SELECT `id`, `actDesc`, `actName`, `actType`, `endTime`, `startTime`, `status` FROM customActivity_bak;
-- 删除自定义活动备份表
DROP TABLE IF EXISTS `customActivity_bak`;

-- 自定义活动任务(从备份表里面复制)
INSERT INTO customTask(`id`, `activityId`, `targets`, `taskReward`) 
SELECT `id`, `activityId`, `targets`, `taskReward` FROM customTask_bak;
-- 删除自定义任务备份表
DROP TABLE IF EXISTS `customTask_bak`;

-- 修改全服VIP礼包为无效状态
UPDATE vipServerActivityGift set `invalid` = 1;

-- 添加合服礼包
INSERT INTO `serverGift` (`id`, `endDate`, `giftNo`, `reward`, `startDate`, `tip`, `title`, `levelLimit`, `delFlag`) VALUES ('1000', '2114-03-08 23:59:59', '-1', '[{\"type\":2,\"count\":\"50\"},{\"type\":6,\"id\":39000001,\"bind\":1,\"count\":\"1\"},{\"type\":6,\"id\":39000079,\"bind\":1,\"count\":\"5\"},{\"type\":6,\"id\":31029001,\"bind\":1,\"count\":\"5\"},{\"type\":6,\"id\":39000093,\"bind\":1,\"count\":\"20\"},{\"type\":6,\"id\":31029001,\"bind\":1,\"count\":\"20\"}]', '2014-01-01 10:00:01', '合服礼包', '合服礼包', 0, 0);

-- 发放幸运大抽奖排名奖励---------------------------------------------------------------------------
INSERT INTO `personalGift` (`id`,`endDate`,`giftNo`,`playerId`,`reward`,`startDate`,`tip`,`title`)
SELECT id, DATE_ADD(NOW(),INTERVAL 2 DAY), '-1', id, '[{"type":6,"id":31010041,"bind":1,"count":"50"},{"type":6,"id":32000074,"bind":1,"count":"1"}]', NOW(), '幸运抽奖第一名奖励', '幸运抽奖第一名奖励'
FROM playerLuckyDraw WHERE rank = 1 and `status` = 0;

INSERT INTO `personalGift` (`id`,`endDate`,`giftNo`,`playerId`,`reward`,`startDate`,`tip`,`title`)
SELECT id, DATE_ADD(NOW(),INTERVAL 2 DAY), '-1', id, '[{"type":6,"id":31010041,"bind":1,"count":"50"}]', NOW(), '幸运抽奖第二名奖励', '幸运抽奖第二名奖励'
FROM playerLuckyDraw WHERE rank = 2 and `status` = 0;

INSERT INTO `personalGift` (`id`,`endDate`,`giftNo`,`playerId`,`reward`,`startDate`,`tip`,`title`)
SELECT id, DATE_ADD(NOW(),INTERVAL 2 DAY), '-1', id, '[{"type":6,"id":31010041,"bind":1,"count":"40"}]', NOW(), '幸运抽奖第三名奖励', '幸运抽奖第三名奖励'
FROM playerLuckyDraw WHERE rank = 3 and `status` = 0;

INSERT INTO `personalGift` (`id`,`endDate`,`giftNo`,`playerId`,`reward`,`startDate`,`tip`,`title`)
SELECT id, DATE_ADD(NOW(),INTERVAL 2 DAY), '-1', id, '[{"type":6,"id":31010041,"bind":1,"count":"30"}]', NOW(), '幸运抽奖第四名奖励', '幸运抽奖第四名奖励'
FROM playerLuckyDraw WHERE rank = 4 and `status` = 0;

INSERT INTO `personalGift` (`id`,`endDate`,`giftNo`,`playerId`,`reward`,`startDate`,`tip`,`title`)
SELECT id, DATE_ADD(NOW(),INTERVAL 2 DAY), '-1', id, '[{"type":6,"id":31010041,"bind":1,"count":"20"}]', NOW(), '幸运抽奖第五名奖励', '幸运抽奖第五名奖励'
FROM playerLuckyDraw WHERE rank = 5 and `status` = 0;

UPDATE playerLuckyDraw SET `status` = 1 WHERE rank in (1, 2, 3, 4, 5);
-- 发放幸运大抽奖排名奖励完毕------------------------------------------------------------------------

-- 市场购买限制记录
INSERT INTO playerMarket(`id`, `buyTime`, `everydayAmount`, `totalAmount`) 
SELECT `id`, `buyTime`, `everydayAmount`, `totalAmount` FROM playerMarket_bak;
-- 删除市场购买限制记录备份表
DROP TABLE IF EXISTS playerMarket_bak;

-- 清空全服礼包领取记录
UPDATE playerGiftInfo set serverGiftRecord = null;

-- keyValue表
INSERT INTO keyValue(`propKey`, `propValue`) 
SELECT `propKey`, `propValue` FROM keyValue_bak t
WHERE t.propKey NOT IN (SELECT a.propKey FROM keyValue a);
-- 删除keyValue备份表
DROP TABLE IF EXISTS keyValue_bak;
