-- ------------------------------------------------------------------------------------------
-- 删除等级低的非人民币玩家数据（合并数据以后执行）
-- 
-- ------------------------------------------------------------------------------------------

-- ----------------------------
-- 可配置项, 在执行前配置好
-- ----------------------------

-- 当前时间
SET @currTime = NOW();
-- 移除等级
SET @delLevel = 30;
-- 移除下线天数
SET @delLogoutDays = 30;


-- ----------------------------
-- 待删除的角色
-- ----------------------------

-- 待删除角色的id临时表
DROP TABLE IF EXISTS delPlayer;
CREATE TEMPORARY TABLE delPlayer
(
	id BIGINT(20) PRIMARY KEY
);

-- @delLogoutDays天没上过线的删除
SET @delBeforDay = DATE_ADD(@currTime,INTERVAL -@delLogoutDays DAY);

INSERT INTO delPlayer
SELECT id FROM player
WHERE `level` < @delLevel AND totalGold <= 0 AND logoutTime <= @delBeforDay;

-- 待删除武将的id临时表
DROP TABLE IF EXISTS delPlayerHero;
CREATE TEMPORARY TABLE delPlayerHero
(
	id BIGINT(20) PRIMARY KEY
);

INSERT INTO delPlayerHero 
SELECT id FROM playerHero WHERE playerId IN (SELECT id FROM delPlayer);

-- ----------------------------
-- 删除角色相关数据
-- ----------------------------

-- 主公
DELETE FROM player WHERE id IN (SELECT id FROM delPlayer);

-- 玩家状态标识记录
DELETE FROM playerFlag WHERE id IN (SELECT id FROM delPlayer);

-- 清空军团排行榜
UPDATE armyGroup set ranking = -1;

-- 军团申请记录
DELETE FROM armyGroupApply WHERE playerId IN (SELECT id FROM delPlayer);

-- 军团商品购买记录
DELETE FROM armyGroupBuyRecord WHERE playerId IN (SELECT id FROM delPlayer);

-- 军团成员
DELETE FROM armyGroupMember WHERE id IN (SELECT id FROM delPlayer);

-- 军团科技
DELETE FROM armyGroupTech WHERE playerId IN (SELECT id FROM delPlayer);

-- 玩家的兵
DELETE FROM playerSoldier WHERE id IN (SELECT id FROM delPlayer);

-- 黑市（这里表名称搞错了，暂时先不改）
DELETE FROM playerBalckMarket WHERE id IN (SELECT id FROM delPlayer);

-- 主城建筑
DELETE FROM playerBuilding WHERE playerId IN (SELECT id FROM delPlayer);

-- 冷却队列
DELETE FROM playerCoolQueue WHERE playerId IN (SELECT id FROM delPlayer);

-- 决战长安记录
DELETE FROM playerDecisiveRecord WHERE id IN (SELECT id FROM delPlayer);

-- 决战长安记录(错误记录)
DELETE FROM playerDecisiveRecord WHERE id = 0;

-- 命签记录
DELETE FROM divinationRecord WHERE id IN (SELECT id FROM delPlayer);

-- 命签
DELETE FROM playerDivination WHERE playerId IN (SELECT id FROM delPlayer);

-- 主公装备
DELETE FROM playerEquip WHERE playerId IN (SELECT id FROM delPlayer);

-- 穿着的主公装备
DELETE FROM playerWearEquip WHERE id IN (SELECT id FROM delPlayer);

-- 神兵抽奖（神兵阁）
DELETE FROM playerEquipRaffle WHERE id IN (SELECT id FROM delPlayer);

-- 返还基金
DELETE FROM playerFund WHERE id IN (SELECT id FROM delPlayer);

-- 阵型
DELETE FROM playerBattleLineup WHERE id IN (SELECT id FROM delPlayer);

-- 上阵武将
DELETE FROM playerBattlePosition WHERE id IN (SELECT id FROM delPlayer);

-- 删除玩家37平台vip记录
DELETE FROM playerCn37Vip WHERE playerId IN (SELECT id FROM delPlayer);

-- 删除玩家爬塔PVE记录
DELETE FROM playerTower WHERE id IN (SELECT id FROM delPlayer);

-- 自定义武将技能
DELETE FROM playerCustomHeroSkill
WHERE playerId IN
(SELECT id FROM delPlayer);

-- 武将
DELETE FROM playerHero
WHERE playerId IN
(SELECT id FROM delPlayer);

-- 武将天赋技能
DELETE FROM playerHeroTalentSkill
WHERE heroId IN
(SELECT id FROM delPlayerHero);

-- 装备洗炼记录
DELETE FROM playerBaptizeHistory
WHERE id IN
(SELECT id FROM delPlayer);

-- 武将装备
DELETE FROM playerHeroEquip
WHERE playerId IN
(SELECT id FROM delPlayer);

-- Buff
DELETE FROM playerBuff
WHERE playerId IN
(SELECT id FROM delPlayer);

-- 道具
DELETE FROM playerItem
WHERE playerid IN
(SELECT id FROM delPlayer);

-- 群体邮件
DELETE FROM mail;

-- 玩家邮件
DELETE FROM playerMail
WHERE targetId IN
(SELECT id FROM delPlayer);

-- 玩家邮件发送记录
DELETE FROM playerMailBookMark
WHERE id IN
(SELECT id FROM delPlayer);

-- 消费记录（管理后台）
DELETE FROM consumeRecord
WHERE playerId IN
(SELECT id FROM delPlayer);

-- 背包格子
DELETE FROM playerPack
WHERE id IN
(SELECT id FROM delPlayer);

-- 玩家属性奖励
DELETE FROM playerAttrReward;

-- 排行榜
DELETE FROM rankingList;

-- 排行榜活动
DELETE FROM rankingListActivity;

-- 税收
DELETE FROM playerRevenue
WHERE id IN
(SELECT id FROM delPlayer);

-- 玩家全服活动任务状态信息
DELETE FROM playerServerActivityTaskStatus;

-- 玩家摸金全服礼包活动状态信息
DELETE FROM playerTreasureServerActivityGiftStatus;

-- 玩家VIP全服礼包活动状态信息
DELETE FROM playerVipServerActivityGiftStatus;

-- 玩家昨天的全服活动任务状态
DELETE FROM playerYestodayTaskStatus;

-- 全服活动任务信息
DELETE FROM serverActivityTask;

-- 摸金全服活动礼包信息
DELETE FROM treasureServerActivityGift;

-- 昨天能领取的全服活动任务
DELETE FROM yestodayServerActivityTask;

-- 科技
DELETE FROM playerTech
WHERE playerId IN
(SELECT id FROM delPlayer);

-- 图腾
DELETE FROM playerTotem
WHERE id IN
(SELECT id FROM delPlayer);

-- 民心事件
DELETE FROM playerWishEvent
WHERE id IN
(SELECT id FROM delPlayer);

-- 单人副本
DELETE FROM chapterBattleReport;
DELETE FROM chapterInfo;
DELETE FROM chapterRankInfo;

DELETE FROM playerChapterInfo
WHERE id IN
(SELECT id FROM delPlayer);

-- 礼包数据
DELETE FROM gift;

DELETE FROM personalGift;

DELETE FROM serverGift;

DELETE FROM playerGiftInfo
WHERE id IN
(SELECT id FROM delPlayer);

-- 日行一善
DELETE FROM playerGoodness
WHERE id IN
(SELECT id FROM delPlayer);

-- 征战天下
DELETE FROM journeyRankInfo;

DELETE FROM playerJourneyInfo
WHERE id IN
(SELECT id FROM delPlayer);

-- 富甲天下
DELETE FROM playerLoopInfo
WHERE id IN
(SELECT id FROM delPlayer);

-- 新手军队
DELETE FROM playerNewArmy
WHERE id IN
(SELECT id FROM delPlayer);

-- 精英副本
DELETE FROM playerNewCreamInfo
WHERE id IN
(SELECT id FROM delPlayer);

-- 酒馆
DELETE FROM playerPub
WHERE id IN
(SELECT id FROM delPlayer);

-- 攻城掠地
DELETE FROM plunderMirror
WHERE id IN
(SELECT id FROM delPlayer);

-- 好友相关
DELETE FROM playerCheerInfo
WHERE id IN
(SELECT id FROM delPlayer);

DELETE FROM playerRelation
WHERE userId IN
(SELECT id FROM delPlayer);

DELETE FROM playerRelation
WHERE otherUserId IN
(SELECT id FROM delPlayer);

DELETE FROM playerRelationBless
WHERE id IN
(SELECT id FROM delPlayer);

-- 商城相关
DELETE FROM playerPresentInfo
WHERE userId IN
(SELECT id FROM delPlayer);

DELETE FROM playerShopInfo
WHERE id IN
(SELECT id FROM delPlayer);

-- 删除元宵商城无用的玩家记录
DELETE FROM specialPlayerShopInfo
WHERE id IN
(SELECT id FROM delPlayer);

-- 技能系统
DELETE FROM heroSkills
WHERE playerId IN
(SELECT id FROM delPlayer);

DELETE FROM playerSkillInfo
WHERE id IN
(SELECT id FROM delPlayer);

-- 奴隶系统
DELETE FROM playerSlaveInfo
WHERE id IN
(SELECT id FROM delPlayer);

UPDATE playerSlaveInfo set status=0,masterId=null,slaveOutDate=null,beSlaveDate=null,appeaseDate=null,afflictDate=null,pleaseDate=null,curseDate=null,sliver=0,slaveDate=null,slaveWorkDate=null,buyTime=0
WHERE id IN
(SELECT id FROM delPlayer);

-- VIP相关
DELETE FROM playerVipInfo
WHERE id IN
(SELECT id FROM delPlayer);


-- 周理财计划相关
DELETE FROM userWeekPlan
WHERE id IN
(SELECT id FROM delPlayer);

-- 月理财计划相关
DELETE FROM userMonthPlan
WHERE id IN
(SELECT id FROM delPlayer);

-- 图腾卡片相关
DELETE FROM playerTotemCard
WHERE playerId IN
(SELECT id FROM delPlayer);

-- 年兽活动相关
DELETE FROM playerIntegra
WHERE id IN
(SELECT id FROM delPlayer);

-- 其他

-- ----------------------------
-- 删除角色相关数据 结束
-- ----------------------------


-- ----------------------------
-- 删除无用的数据
-- ----------------------------

-- 删除无人的军团
DELETE FROM armyGroup 
WHERE id NOT IN
(SELECT DISTINCT armyGroupId FROM armyGroupMember);

-- 删除无人的军团的建筑
DELETE FROM armyGroupBuilding 
WHERE armyGroupId NOT IN
(SELECT DISTINCT armyGroupId FROM armyGroupMember);

-- 删除无人的军团的加入申请
DELETE FROM armyGroupApply
WHERE armyGroupId NOT IN
(SELECT DISTINCT armyGroupId FROM armyGroupMember);

-- 删除无人的军团的捐赠记录
DELETE FROM armyGroupContribute
WHERE armyGroupId NOT IN
(SELECT DISTINCT armyGroupId FROM armyGroupMember);

-- 删除排行榜
DELETE FROM rankingList;

-- 删除排行榜相关活动
DELETE FROM rankingListActivity;

-- 删除没有附件的个人邮件
DELETE FROM playerMail
WHERE hadAddtion = 0;

-- 删除没有附件的团体邮件
DELETE FROM mail
WHERE hadAddtion = 0;

-- 删除玩家活动信息
DELETE FROM playerActivity WHERE playerId IN (SELECT id FROM delPlayer);

-- 删除玩家活动信息(错误记录)
DELETE FROM playerActivity WHERE playerId = 0;

-- 删除玩家活动任务信息
DELETE FROM playerActivityTask WHERE playerId IN (SELECT id FROM delPlayer);

-- 删除玩家竞技场信息
DELETE FROM playerArena WHERE playerId IN (SELECT id FROM delPlayer);
-- 重置玩家竞技场信息
UPDATE playerArena SET wins = 0, balanceRank = 0, topRank = 0, challengeHis = '';

-- 删除玩家每日指引任务信息
DELETE FROM playerDailyGuide WHERE playerId IN (SELECT id FROM delPlayer);

-- 删除玩家每日奖励
DELETE FROM playerDailyReward WHERE playerId IN (SELECT id FROM delPlayer);

-- 删除玩家目标章节信息
DELETE FROM playerGoalChapter WHERE playerId IN (SELECT id FROM delPlayer);

-- 删除玩家目标章节任务信息
DELETE FROM playerChapterTask WHERE playerId IN (SELECT id FROM delPlayer);

-- 删除玩家锯子令信息
DELETE FROM playerJzl WHERE playerId IN (SELECT id FROM delPlayer);

-- 删除玩家日常任务信息
DELETE FROM playerDailyTask WHERE playerId IN (SELECT id FROM delPlayer);

-- 删除玩家主支线任务信息
DELETE FROM playerTask WHERE playerId IN (SELECT id FROM delPlayer);

-- 删除玩家任务历史信息
DELETE FROM playerTaskHis WHERE playerId IN (SELECT id FROM delPlayer);

-- 删除玩家临时背包条目明细
DELETE FROM bagEntry WHERE playerId IN (SELECT id FROM delPlayer);

-- 删除玩家vip副本信息
DELETE FROM playerVipFb WHERE playerId IN (SELECT id FROM delPlayer);

-- 删除玩家360特权
DELETE FROM player360Privilege WHERE playerId IN (SELECT id FROM delPlayer);

-- 删除玩家360红钻vip
DELETE FROM playerRedVip WHERE playerId IN (SELECT id FROM delPlayer);

-- 删除玩家迅雷金卡vip
DELETE FROM xunleiMember WHERE playerId IN (SELECT id FROM delPlayer);

-- 删除玩家YY平台会员信息
DELETE FROM yyMember WHERE playerId IN (SELECT id FROM delPlayer);

-- 删除玩家一次性礼包信息
DELETE FROM playerOneTimeGift WHERE playerId IN (SELECT id FROM delPlayer);

-- 删除玩家自定义活动任务信息
DELETE FROM playerCustomTask WHERE playerId IN (SELECT id FROM delPlayer);

-- 植树活动信息
DELETE FROM playerPlant WHERE id IN (SELECT id FROM delPlayer);

-- 玩家团购信息
DELETE FROM playerGroupPurchase WHERE playerId IN (SELECT id FROM delPlayer);

-- 玩家练兵信息
DELETE FROM playerTraining WHERE id IN (SELECT id FROM delPlayer);

-- 玩家一夫当关副本信息
DELETE FROM playerManpass WHERE playerId IN (SELECT id FROM delPlayer);

-- 玩家宝石交换记录
DELETE FROM playerItemConvert WHERE id IN (SELECT id FROM delPlayer);

-- 玩家月卡信息
DELETE FROM playerCard WHERE playerId IN (SELECT id FROM delPlayer);

-- 玩家幸运抽奖记录
DELETE FROM playerLuckyDraw WHERE id IN (SELECT id FROM delPlayer);

-- 玩家稀有物品抽奖记录
DELETE FROM playerRareItemDraw WHERE id IN (SELECT id FROM delPlayer);

-- 玩家元宝抽奖记录
DELETE FROM playerGoldDraw WHERE id IN (SELECT id FROM delPlayer);

-- 玩家使用经验丹记录
DELETE FROM playerExpPill WHERE id IN (SELECT id FROM delPlayer);

-- 全服摸金记录
DELETE FROM serverTreasure WHERE playerId IN (SELECT id FROM delPlayer);

-- 玩家全服摸金记录
DELETE FROM playerServerTreasure WHERE playerId IN (SELECT id FROM delPlayer);

-- 玩家跨服群雄争霸信息
DELETE FROM playerKFChampion WHERE playerId IN (SELECT id FROM delPlayer);

-- 玩家皇城缉盗信息
DELETE FROM playerRoyalInfo WHERE playerId IN (SELECT id FROM delPlayer);

-- 玩家皇城缉盗任务明细信息
DELETE FROM playerRoyalTask WHERE playerId IN (SELECT id FROM delPlayer);

-- 玩家五一劳动节种植活动信息
DELETE FROM playerLaborPlant WHERE id IN (SELECT id FROM delPlayer);

-- 玩家坐骑信息
DELETE FROM playerHorse WHERE id IN (SELECT id FROM delPlayer);

-- 玩家购买宝石升级道具记录
DELETE FROM playerJewelUpgradeItem WHERE id IN (SELECT id FROM delPlayer);

-- 玩家神秘商店信息
DELETE FROM playerMysteryStore WHERE id IN (SELECT id FROM delPlayer);

-- 玩家购买命签升级道具记录
DELETE FROM playerDivinationUpgradeItem WHERE id IN (SELECT id FROM delPlayer);

-- 玩家一元商店购买记录
DELETE FROM playerOneYuanShopInfo WHERE id IN (SELECT id FROM delPlayer);

-- 玩家端午活动记录
DELETE FROM playerDuanWuInfo WHERE id IN (SELECT id FROM delPlayer);

-- 玩家累计登陆礼包记录
DELETE FROM playerLoginDaysGift WHERE id IN (SELECT id FROM delPlayer);

-- 玩家灵翼记录
DELETE FROM playerNetherwing WHERE id IN (SELECT id FROM delPlayer);

-- 玩家跨服掠夺记录
DELETE FROM playerLoot WHERE playerId IN (SELECT id FROM delPlayer);

-- 玩家世界杯卡牌信息
DELETE FROM playerWorldCupCard WHERE id IN (SELECT id FROM delPlayer);

-- 玩家世界杯信息
DELETE FROM playerWorldCupInfo WHERE id IN (SELECT id FROM delPlayer);

-- 玩家世界杯每日积分记录
DELETE FROM worldCupIntegral WHERE playerId IN (SELECT id FROM delPlayer);

-- 玩家神将战魄记录
DELETE FROM playerHeroSoulSkill WHERE heroId IN (SELECT id FROM delPlayerHero);

-- 玩家元宝商店购买信息
DELETE FROM playerGoldShopInfo WHERE id IN (SELECT id FROM delPlayer);

-- 玩家充值积分
DELETE FROM playerChargeIntegral WHERE id IN (SELECT id FROM delPlayer);

-- 玩家单次充值活动记录
DELETE FROM playerChargeReward WHERE id IN (SELECT id FROM delPlayer);

-- 玩家风云争霸信息
DELETE FROM playerFungWan WHERE playerId IN (SELECT id FROM delPlayer);

-- 玩家宝石迷阵信息
DELETE FROM playerBejeweled WHERE id IN (SELECT id FROM delPlayer);

-- 玩家灵翼入魂信息
DELETE FROM playerNetherwingActivity WHERE playerId IN (SELECT id FROM delPlayer);

-- 玩家充值抽奖信息
DELETE FROM playerChargeDraw WHERE id IN (SELECT id FROM delPlayer);

-- 玩家当前称号信息
DELETE FROM playerCurrentHonor WHERE playerId IN (SELECT id FROM delPlayer);

-- 玩家称号信息
DELETE FROM playerHonor WHERE playerId IN (SELECT id FROM delPlayer);

-- 玩家财富乐翻天信息
DELETE FROM playerDeposit WHERE id IN (SELECT id FROM delPlayer);

-- 玩家帝王盛宴信息
DELETE FROM playerMonarchFeast WHERE id IN (SELECT id FROM delPlayer);

-- 玩家时装衣柜信息
DELETE FROM playerBureau WHERE playerId IN (SELECT id FROM delPlayer);

-- 玩家时装信息
DELETE FROM playerFashionEquip WHERE playerId IN (SELECT id FROM delPlayer);
-- ----------------------------
-- 删除无用的数据 结束
-- ----------------------------


-- ----------------------------
-- 存储过程开始
-- ----------------------------

DELIMITER // 

-- ----------------------------
-- 修正军团没有团长的存储过程
-- ----------------------------

DROP PROCEDURE IF EXISTS sp_ChangeArmyGroupChief //
CREATE PROCEDURE sp_ChangeArmyGroupChief()
BEGIN
	DECLARE armyGroupId1 BIGINT DEFAULT -1;
	DECLARE playerId BIGINT DEFAULT -1;
	DECLARE hadMore boolean DEFAULT TRUE;

	-- 没有团长的军团
	DECLARE armyGroupCursor CURSOR FOR SELECT id FROM armyGroup
	WHERE id NOT IN (SELECT armyGroupId FROM armyGroupMember WHERE positionId = 4);

	-- 没有团长的军团的成员列表
	DECLARE memberCursor CURSOR FOR SELECT id FROM player
	WHERE id IN (SELECT id FROM armyGroupMember WHERE armyGroupId = armyGroupId1) ORDER BY ability DESC LIMIT 1;

	DECLARE CONTINUE HANDLER FOR NOT found SET hadMore = FALSE;
	
	DROP TABLE IF EXISTS newArmyGroupChief;
	CREATE TEMPORARY TABLE newArmyGroupChief
	(
		id BIGINT(20) NOT NULL,
		PRIMARY KEY(id)
	);

	OPEN armyGroupCursor;
	FETCH armyGroupCursor INTO armyGroupId1;
	WHILE (hadMore) DO
		OPEN memberCursor;
		FETCH memberCursor INTO playerId;
		IF (hadMore) THEN
			INSERT INTO newArmyGroupChief values (playerId);
		END IF;
		CLOSE memberCursor;

		SET hadMore = TRUE;
		FETCH armyGroupCursor INTO armyGroupId1;
	END WHILE;

	-- 修改军团的团长
	UPDATE armyGroupMember SET positionId = 4
	WHERE id IN (SELECT id FROM newArmyGroupChief);

	CLOSE armyGroupCursor;
	DROP TABLE newArmyGroupChief;
	
	-- 修改军团的团长
	UPDATE armyGroup, armyGroupMember
	SET armyGroup.chief = armyGroupMember.id 
	WHERE armyGroup.id = armyGroupMember.armyGroupId AND 
	armyGroup.chief NOT IN (SELECT id FROM armyGroupMember WHERE positionId = 4) AND
	armyGroupMember.positionId = 4;
END //

DELIMITER ; 

-- ----------------------------
-- 存储过程 结束
-- ----------------------------

-- 修改没有团长的军团
CALL sp_ChangeArmyGroupChief;