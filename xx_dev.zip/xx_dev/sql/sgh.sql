
SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `arenaInfo`
-- ----------------------------
DROP TABLE IF EXISTS `arenaInfo`;
CREATE TABLE `arenaInfo` (
  `id` tinyint(4) NOT NULL COMMENT '主键id',
  `info` longtext COLLATE utf8_unicode_ci COMMENT '信息',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `armageddonCheerInfo`
-- ----------------------------
DROP TABLE IF EXISTS `armageddonCheerInfo`;
CREATE TABLE `armageddonCheerInfo` (
  `id` bigint(20) NOT NULL COMMENT '玩家ID',
  `cdPlayerInfo` text COLLATE utf8_unicode_ci COMMENT '已进入CD回合玩家',
  `cheerIdOne` bigint(20) DEFAULT '-1' COMMENT '当前助阵用户ID',
  `cheerIdTwo` bigint(20) DEFAULT '-1' COMMENT '当前助阵用户ID',
  `cheerInfo` text COLLATE utf8_unicode_ci COMMENT '当前助阵玩家列表',
  `cheerOneState` int(11) DEFAULT '0' COMMENT '当前助阵用户奖励类型',
  `cheerTwoState` int(11) DEFAULT '0' COMMENT '当前助阵用户奖励类型',
  `formation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '阵形',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of armageddonCheerInfo
-- ----------------------------

-- ----------------------------
-- Table structure for `armyGroup`
-- ----------------------------
DROP TABLE IF EXISTS `armyGroup`;
CREATE TABLE `armyGroup` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `advertiseTimes` int(11) NOT NULL COMMENT '当天发送招贤榜的次数',
  `chief` bigint(20) NOT NULL COMMENT '团长id',
  `declaration` varchar(1000) COLLATE utf8_unicode_ci NOT NULL COMMENT '军团宣言',
  `lastSendAdvertiseTime` datetime DEFAULT '2013-01-01 00:00:00' COMMENT '最后发送招贤榜的时间',
  `mustRename` int(11) NOT NULL COMMENT '是否需要改名',
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '军团名称',
  `notice` varchar(1000) COLLATE utf8_unicode_ci NOT NULL COMMENT '军团公告',
  `ranking` int(11) NOT NULL COMMENT '排名',
  `wealth` bigint(20) NOT NULL COMMENT '财富',
  `multiFubenId` int(11) NOT NULL DEFAULT 0 COMMENT '最高多人副本ID',
  `multiFubenDur` int(11) NOT NULL DEFAULT 0 COMMENT '最高多人副本对应的耐久度',
  PRIMARY KEY (`id`),
  KEY `armyGroup_name_index` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of armyGroup
-- ----------------------------

-- ----------------------------
-- Table structure for `armyGroupApply`
-- ----------------------------
DROP TABLE IF EXISTS `armyGroupApply`;
CREATE TABLE `armyGroupApply` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `armyGroupId` bigint(20) NOT NULL COMMENT '军团id',
  `playerId` bigint(20) NOT NULL COMMENT '玩家id',
  PRIMARY KEY (`id`),
  KEY `armyGroup_apply_playerId_index` (`playerId`),
  KEY `armyGroup_apply_armyGroupId_index` (`armyGroupId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of armyGroupApply
-- ----------------------------

-- ----------------------------
-- Table structure for `armyGroupBuilding`
-- ----------------------------
DROP TABLE IF EXISTS `armyGroupBuilding`;
CREATE TABLE `armyGroupBuilding` (
  `id` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT 'id',
  `armyGroupId` bigint(20) NOT NULL COMMENT '军团id',
  `buildingId` int(11) NOT NULL COMMENT '建筑id',
  `level` int(11) DEFAULT '0' COMMENT '建筑等级',
  `progress` int(11) DEFAULT '0' COMMENT '完成度',
  PRIMARY KEY (`id`),
  KEY `armyGroupBuilding_idx_buildingId` (`buildingId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of armyGroupBuilding
-- ----------------------------

-- ----------------------------
-- Table structure for `armyGroupBuyRecord`
-- ----------------------------
DROP TABLE IF EXISTS `armyGroupBuyRecord`;
CREATE TABLE `armyGroupBuyRecord` (
  `id` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT 'id',
  `amount` int(11) DEFAULT '0' COMMENT '购买数量',
  `goodsId` int(11) NOT NULL COMMENT '商品id',
  `lastBuyTime` datetime DEFAULT '2013-01-01 00:00:00' COMMENT '最后购买商品的时间',
  `playerId` bigint(20) NOT NULL COMMENT '玩家id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of armyGroupBuyRecord
-- ----------------------------

-- ----------------------------
-- Table structure for `armyGroupContribute`
-- ----------------------------
DROP TABLE IF EXISTS `armyGroupContribute`;
CREATE TABLE `armyGroupContribute` (
  `id` bigint(20) NOT NULL,
  `armyGroupId` bigint(20) NOT NULL COMMENT '军团id',
  `buildingId` int(11) NOT NULL COMMENT '建筑id',
  `contribute` int(11) NOT NULL COMMENT '贡献值',
  `contributeTime` datetime DEFAULT '2013-01-01 00:00:00' COMMENT '捐献时间',
  `eventId` int(11) NOT NULL COMMENT '捐献事件id',
  `itemAmount` int(11) NOT NULL COMMENT '道具数量',
  `itemId` int(11) NOT NULL COMMENT '道具id',
  `playerId` bigint(20) NOT NULL COMMENT '玩家id',
  `progress` int(11) NOT NULL COMMENT '完成度',
  `silverReward` int(11) NOT NULL COMMENT '银元奖励',
  PRIMARY KEY (`id`),
  KEY `armyGroup_contribute_index` (`armyGroupId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of armyGroupContribute
-- ----------------------------

-- ----------------------------
-- Table structure for `armyGroupMember`
-- ----------------------------
DROP TABLE IF EXISTS `armyGroupMember`;
CREATE TABLE `armyGroupMember` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `armyGroupId` bigint(20) NOT NULL COMMENT '军团id',
  `contribute` int(11) NOT NULL COMMENT '贡献值',
  `curContribute` int(11) NOT NULL COMMENT '当前军团贡献值',
  `joinTime` datetime DEFAULT '2013-01-01 00:00:00' COMMENT '加入军团的时间',
  `positionId` int(11) NOT NULL COMMENT '职位id',
  `quitTime` datetime DEFAULT '2013-01-01 00:00:00' COMMENT '退出军团的时间',
  `receiveFoodsTime` datetime DEFAULT '2013-01-01 00:00:00' COMMENT '最后领取粮草福利的时间',
  `receiveHeroSoulTime` datetime DEFAULT '2013-01-01 00:00:00' COMMENT '最后领取武将经验福利的时间',
  PRIMARY KEY (`id`),
  KEY `armyGroup_member_index` (`armyGroupId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of armyGroupMember
-- ----------------------------

-- ----------------------------
-- Table structure for `armyGroupTech`
-- ----------------------------
DROP TABLE IF EXISTS `armyGroupTech`;
CREATE TABLE `armyGroupTech` (
  `id` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT 'id',
  `level` int(11) DEFAULT '0' COMMENT '科技等级',
  `playerId` bigint(20) NOT NULL COMMENT '玩家id',
  `techId` int(11) NOT NULL COMMENT '科技id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of armyGroupTech
-- ----------------------------

-- ----------------------------
-- Table structure for `bagEntry`
-- ----------------------------
DROP TABLE IF EXISTS `bagEntry`;
CREATE TABLE `bagEntry` (
  `id` bigint(20) NOT NULL COMMENT '主键ID',
  `createTime` datetime DEFAULT NULL COMMENT '创建时间',
  `playerId` bigint(20) NOT NULL COMMENT '角色id',
  `rewards` varchar(255) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '存放的条目明细信息',
  PRIMARY KEY (`id`),
  KEY `bagEntry_idx_playerId` (`playerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of bagEntry
-- ----------------------------

-- ----------------------------
-- Table structure for `championCandidate`
-- ----------------------------
DROP TABLE IF EXISTS `championCandidate`;
CREATE TABLE `championCandidate` (
  `playerId` bigint(20) NOT NULL COMMENT '角色id',
  `rank` int(11) DEFAULT '0' COMMENT '排名',
  `supports` longtext COLLATE utf8_unicode_ci COMMENT '支持者(json)',
  PRIMARY KEY (`playerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of championCandidate
-- ----------------------------

-- ----------------------------
-- Table structure for `championship`
-- ----------------------------
DROP TABLE IF EXISTS `championship`;
CREATE TABLE `championship` (
  `id` tinyint(4) NOT NULL COMMENT '主键id',
  `candidateDay` varchar(20) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '已经初始化种子选手的日期',
  `candidates` text COLLATE utf8_unicode_ci COMMENT '种子选手信息',
  `championDay` varchar(20) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '争霸赛日期',
  `status` tinyint(4) DEFAULT '0' COMMENT '状态',
  `topPlayerId`  bigint(20) NOT NULL DEFAULT 0 COMMENT '第一名玩家id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `chapterBattleReport`
-- ----------------------------
DROP TABLE IF EXISTS `chapterBattleReport`;
CREATE TABLE `chapterBattleReport` (
  `id` int(11) NOT NULL COMMENT '主键(据点ID)',
  `battleReport` longblob,
  `createDate` datetime DEFAULT '2012-01-01 00:00:00' COMMENT '创建时间',
  `level` int(11) DEFAULT '1' COMMENT '等级',
  `newBattleReport` longtext COLLATE utf8_unicode_ci COMMENT '最近的战报列表',
  `playerName` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT '主公名称',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of chapterBattleReport
-- ----------------------------

-- ----------------------------
-- Table structure for `chapterInfo`
-- ----------------------------
DROP TABLE IF EXISTS `chapterInfo`;
CREATE TABLE `chapterInfo` (
  `armyId` int(11) NOT NULL COMMENT '军队id',
  `createTime` datetime DEFAULT '2012-01-01 00:00:00' COMMENT '创建时间',
  `userId` bigint(20) NOT NULL COMMENT '用户id',
  PRIMARY KEY (`armyId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of chapterInfo
-- ----------------------------

-- ----------------------------
-- Table structure for `charges`
-- ----------------------------
DROP TABLE IF EXISTS `charges`;
CREATE TABLE `charges` (
  `id` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '订单号',
  `createTime` datetime DEFAULT NULL COMMENT '创建日期',
  `gold` int(10) DEFAULT '0' COMMENT '充值元宝',
  `playerId` bigint(20) NOT NULL COMMENT '角色id',
  `money` int(11) DEFAULT 0 COMMENT '金额',
  `currency` varchar(255) DEFAULT 'CNY' COMMENT '货币类型',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of charges
-- ----------------------------

-- ----------------------------
-- Table structure for `circularNotice`
-- ----------------------------
DROP TABLE IF EXISTS `circularNotice`;
CREATE TABLE `circularNotice` (
  `id` bigint(20) NOT NULL COMMENT '循环公告id',
  `content` varchar(1000) COLLATE utf8_unicode_ci NOT NULL COMMENT '公告内容',
  `intervalSecond` int(11) NOT NULL COMMENT '循环间隔（秒）',
  `noticeNum` bigint(20) NOT NULL COMMENT '循环公告编号',
  `startTime` datetime DEFAULT '2013-01-01 00:00:00' COMMENT '开始时间',
  `times` int(11) NOT NULL COMMENT '循环次数',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of circularNotice
-- ----------------------------

-- ----------------------------
-- Table structure for `consumeRecord`
-- ----------------------------
DROP TABLE IF EXISTS `consumeRecord`;
CREATE TABLE `consumeRecord` (
  `id` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT 'id',
  `addTime` datetime DEFAULT '2013-01-01 00:00:00' COMMENT '添加时间',
  `money` int(11) NOT NULL COMMENT '消费额度',
  `playerId` bigint(20) NOT NULL COMMENT '玩家id',
  `times` int(11) NOT NULL COMMENT '消费次数',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of consumeRecord
-- ----------------------------

-- ----------------------------
-- Table structure for `creamInfo`
-- ----------------------------
DROP TABLE IF EXISTS `creamInfo`;
CREATE TABLE `creamInfo` (
  `armyId` int(11) NOT NULL COMMENT '军队id',
  `createTime` datetime DEFAULT '2012-01-01 00:00:00' COMMENT '创建时间',
  `userId` bigint(20) NOT NULL COMMENT '用户id',
  PRIMARY KEY (`armyId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of creamInfo
-- ----------------------------

-- ----------------------------
-- Table structure for `customActivity`
-- ----------------------------
DROP TABLE IF EXISTS `customActivity`;
CREATE TABLE `customActivity` (
  `id` int(11) NOT NULL COMMENT '主键id',
  `actDesc` text COLLATE utf8_unicode_ci COMMENT '活动描述',
  `actName` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT '活动名',
  `actType` tinyint(3) DEFAULT '0' COMMENT '活动类型, 0-充值  1-消费',
  `endTime` datetime DEFAULT NULL COMMENT '活动结束时间',
  `startTime` datetime DEFAULT NULL COMMENT '活动开始时间',
  `status`  tinyint(3) NOT NULL DEFAULT 1 COMMENT '活动状态, 0-关闭  1-开启',
  PRIMARY KEY (`id`),
  KEY `customActivity_idx_endTime` (`endTime`),
  KEY `customActivity_idx_status` (`status`) 
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of customActivity
-- ----------------------------

-- ----------------------------
-- Table structure for `customTask`
-- ----------------------------
DROP TABLE IF EXISTS `customTask`;
CREATE TABLE `customTask` (
  `id` int(11) NOT NULL COMMENT '主键id',
  `activityId` int(11) NOT NULL COMMENT '所属活动id',
  `targets` text COLLATE utf8_unicode_ci COMMENT '任务目标',
  `taskReward` text COLLATE utf8_unicode_ci COMMENT '任务奖励',
  PRIMARY KEY (`id`),
  KEY `customTask_idx_activityId` (`activityId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of customTask
-- ----------------------------

-- ----------------------------
-- Table structure for `divinationRecord`
-- ----------------------------
DROP TABLE IF EXISTS `divinationRecord`;
CREATE TABLE `divinationRecord` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `autoCombine` tinyint(4) NOT NULL COMMENT '是否自动合并，0否，非0是',
  `buyCellTimes` int(11) NOT NULL COMMENT '购买的命签格子数量',
  `intergal` int(11) NOT NULL COMMENT '积分',
  `onlyNull` tinyint(4) NOT NULL COMMENT '是否只出售空签，0否，非0是',
  `rateLevel` int(11) NOT NULL COMMENT '概率等级',
  `takeType` int(11) NOT NULL COMMENT '求签类型',
  `lockRateLevel` tinyint(4) NOT NULL COMMENT '是否锁定概率等级，0否，非0是',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of divinationRecord
-- ----------------------------

-- ----------------------------
-- Table structure for `dropRecord`
-- ----------------------------
DROP TABLE IF EXISTS `dropRecord`;
CREATE TABLE `dropRecord` (
  `id` bigint(20) NOT NULL COMMENT '角色id',
  `info` longtext COLLATE utf8_unicode_ci COMMENT '掉落信息',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of dropRecord
-- ----------------------------

-- ----------------------------
-- Table structure for `gift`
-- ----------------------------
DROP TABLE IF EXISTS `gift`;
CREATE TABLE `gift` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `endTime` datetime NOT NULL DEFAULT '2112-01-01 00:00:00' COMMENT '礼包结束时间',
  `giftNo` bigint(20) NOT NULL COMMENT '礼包编号',
  `rewards` text COLLATE utf8_unicode_ci COMMENT '奖励内容 ',
  `startTime` datetime NOT NULL DEFAULT '2012-01-01 00:00:00' COMMENT '礼包开始时间',
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '标题',
  `repeatable` int(3) DEFAULT '0' COMMENT '是否可以重复领取',
  PRIMARY KEY (`id`),
  KEY `giftNo_index` (`giftNo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of gift
-- ----------------------------

-- ----------------------------
-- Table structure for `heroSkills`
-- ----------------------------
DROP TABLE IF EXISTS `heroSkills`;
CREATE TABLE `heroSkills` (
  `id` bigint(20) NOT NULL COMMENT 'id',
  `activeSkillId` int(11) DEFAULT '-1' COMMENT '武将主动技能id',
  `activeSkillLevel` int(11) DEFAULT '-1' COMMENT '武将主动技能等级',
  `awaken` bit(1) NOT NULL,
  `awakenSkillId` int(11) DEFAULT '-1' COMMENT '武将觉醒技能Id',
  `awakenSkillLevel` int(11) DEFAULT '-1' COMMENT '武将觉醒技能等级',
  `captainSkillId` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '武将队长技能Id',
  `playerId` bigint(20) NOT NULL COMMENT '所属玩家ID',
  `unactiveSkillId` text COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '武将被动技能id',
  `activeSkillExp` int(11) DEFAULT '0' COMMENT '武将主动技能当前等级剩余经验',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of heroSkills
-- ----------------------------

-- ----------------------------
-- Table structure for `invadeRankInfo`
-- ----------------------------
DROP TABLE IF EXISTS `invadeRankInfo`;
CREATE TABLE `invadeRankInfo` (
  `id` int(11) NOT NULL COMMENT 'id',
  `battleRankInfo` text COLLATE utf8_unicode_ci COMMENT '排行信息',
  `maxArmyId` int(11) NOT NULL COMMENT 'id',
  `minArmyId` int(11) NOT NULL COMMENT 'id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of invadeRankInfo
-- ----------------------------

-- ----------------------------
-- Table structure for `journeyRankInfo`
-- ----------------------------
DROP TABLE IF EXISTS `journeyRankInfo`;
CREATE TABLE `journeyRankInfo` (
  `id` int(11) NOT NULL COMMENT 'id',
  `battleRankInfo` text COLLATE utf8_unicode_ci COMMENT '战役排行',
  `honorRankInfo` text COLLATE utf8_unicode_ci COMMENT '成就丰碑',
  `maxMissionId` int(11) NOT NULL COMMENT '战役排行最远的missionId',
  `minMissionId` int(11) NOT NULL COMMENT '战役排行最近的missionId',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of journeyRankInfo
-- ----------------------------

-- ----------------------------
-- Table structure for `keyValue`
-- ----------------------------
DROP TABLE IF EXISTS `keyValue`;
CREATE TABLE `keyValue` (
  `propKey` char(255) COLLATE utf8_unicode_ci NOT NULL COMMENT '属性键',
  `propValue` longtext COLLATE utf8_unicode_ci COMMENT '属性值',
  PRIMARY KEY (`propKey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of keyValue
-- ----------------------------

-- ----------------------------
-- Table structure for `magicRank`
-- ----------------------------
DROP TABLE IF EXISTS `magicRank`;
CREATE TABLE `magicRank` (
  `id` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT '主键id',
  `rankContent` longtext COLLATE utf8_unicode_ci COMMENT '排名信息',
  `receiveTime` datetime DEFAULT NULL COMMENT '开启时间',
  `rewards` longtext COLLATE utf8_unicode_ci COMMENT '已经领取奖励的角色id集合',
  `status` tinyint(4) DEFAULT '0' COMMENT '排名状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of magicRank
-- ----------------------------

-- ----------------------------
-- Table structure for `mail`
-- ----------------------------
DROP TABLE IF EXISTS `mail`;
CREATE TABLE `mail` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `addtion` longtext COLLATE utf8_unicode_ci COMMENT '附件',
  `content` longtext COLLATE utf8_unicode_ci COMMENT '内容',
  `createTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '创建时间',
  `endTime` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '有效时间',
  `hadAddtion` tinyint(4) NOT NULL COMMENT '是否有附件',
  `jsonKeyValues` varchar(1000) COLLATE utf8_unicode_ci NOT NULL COMMENT '邮件模板里面用到的键值对',
  `mailTemplateId` int(11) NOT NULL COMMENT '邮件模板id',
  `senderId` bigint(20) NOT NULL COMMENT '发送者id',
  `senderName` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '发送者名称',
  `startTime` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '生效时间',
  `targetId` bigint(20) NOT NULL COMMENT '接收者id',
  `title` longtext COLLATE utf8_unicode_ci COMMENT '标题',
  `type` smallint(6) NOT NULL COMMENT '邮件类型',
  PRIMARY KEY (`id`),
  KEY `mail_index` (`endTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of mail
-- ----------------------------

-- ----------------------------
-- Table structure for `manpassInfo`
-- ----------------------------
DROP TABLE IF EXISTS `manpassInfo`;
CREATE TABLE `manpassInfo` (
  `id` int(11) NOT NULL COMMENT '主键ID',
  `balanceStatus` tinyint(2) DEFAULT '0' COMMENT '当天是否结算',
  `balanceTime` datetime DEFAULT NULL COMMENT '最近一次结算时间',
  `currDate` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '日期',
  `freeCount` tinyint(4) DEFAULT '0' COMMENT '免费挑战次数',
  `freeTime` datetime DEFAULT NULL COMMENT '最近一次结算时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of manpassInfo
-- ----------------------------

-- ----------------------------
-- Table structure for `manpassValue`
-- ----------------------------
DROP TABLE IF EXISTS `manpassValue`;
CREATE TABLE `manpassValue` (
  `id` tinyint(4) NOT NULL COMMENT '主键id',
  `info` longtext COLLATE utf8_unicode_ci COMMENT '信息',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of manpassValue
-- ----------------------------

-- ----------------------------
-- Table structure for `open`
-- ----------------------------
DROP TABLE IF EXISTS `open`;
CREATE TABLE `open` (
  `id` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT '主键',
  `endTime` datetime DEFAULT NULL COMMENT '结束时间',
  `opened` bit(1) DEFAULT b'0' COMMENT '是否开启',
  `startTime` datetime DEFAULT NULL COMMENT '开启时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of open
-- ----------------------------

-- ----------------------------
-- Table structure for `personalGift`
-- ----------------------------
DROP TABLE IF EXISTS `personalGift`;
CREATE TABLE `personalGift` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `endDate` datetime DEFAULT NULL COMMENT '礼包领取结束时间',
  `giftNo` bigint(20) NOT NULL COMMENT '礼包编号 ',
  `playerId` bigint(20) NOT NULL COMMENT '玩家ID',
  `reward` text COLLATE utf8_unicode_ci COMMENT '奖励串',
  `startDate` datetime DEFAULT NULL COMMENT '礼包领取开始时间',
  `tip` text COLLATE utf8_unicode_ci COMMENT '备注',
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '标题',
  PRIMARY KEY (`id`),
  KEY `personalGift_index1` (`giftNo`),
  KEY `personalGift_index` (`playerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of personalGift
-- ----------------------------

-- ----------------------------
-- Table structure for `player`
-- ----------------------------
DROP TABLE IF EXISTS `player`;
CREATE TABLE `player` (
  `id` bigint(20) NOT NULL COMMENT '玩家id',
  `EnergyBuffStartTime` datetime DEFAULT '2013-01-01 00:00:00' COMMENT '体力Buff的开始时间',
  `ability` double DEFAULT '0' COMMENT '第一阵型战斗力',
  `blockChat` tinyint(4) DEFAULT '0' COMMENT '是否禁止发言  0-可以发言 1-禁止发言',
  `blockChatExpireTime` datetime DEFAULT '2013-01-01 00:00:00' COMMENT '禁止发言到期时间',
  `blockChatReason` varchar(255) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '禁言原因',
  `blockLogin` tinyint(4) DEFAULT '0' COMMENT '是否禁止登陆  0-可以登陆 1-禁止登陆',
  `blockLoginExpireTime` datetime DEFAULT '2013-01-01 00:00:00' COMMENT '禁止登陆到期时间',
  `blockLoginReason` varchar(255) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '禁止登陆的原因',
  `buyEnergyAmount` int(11) DEFAULT '0' COMMENT '购买体力次数',
  `buyPackCount` int(11) DEFAULT '0' COMMENT '购买背包格子的数量',
  `country` tinyint(4) NOT NULL COMMENT '国家id',
  `credit` bigint(20) DEFAULT '0' COMMENT '积分',
  `crystal` bigint(20) DEFAULT '0' COMMENT '水晶',
  `drillExp` bigint(20) DEFAULT '0' COMMENT '战魂',
  `energy` bigint(20) DEFAULT '100' COMMENT '体力',
  `energyBuff` bigint(20) DEFAULT '0' COMMENT '体力buff',
  `energyLimit` bigint(20) DEFAULT '0' COMMENT '体力上限',
  `experience` bigint(20) DEFAULT '0' COMMENT '经验',
  `exploit` bigint(20) DEFAULT '0' COMMENT '功勋',
  `exts` text COLLATE utf8_unicode_ci COMMENT '平台扩展参数',
  `fame` bigint(20) DEFAULT '0' COMMENT '声望',
  `firstChargeGift` tinyint(4) DEFAULT '0' COMMENT '首充礼包是否已领取  0-未领取 1-已领取',
  `foods` bigint(20) DEFAULT '0' COMMENT '粮草',
  `fundGold` bigint(20) DEFAULT '0' COMMENT '返还金币',
  `gold` bigint(20) DEFAULT '0' COMMENT '金币',
  `growGold` int(11) DEFAULT '0' COMMENT 'VIP消费金币 计算成长值结余(不够增加每点成长值 的余额)',
  `growValue` int(11) DEFAULT '0' COMMENT 'VIP成长值',
  `guideStep` int(11) DEFAULT '0' COMMENT '指引已经完成的步骤',
  `headId` int(11) DEFAULT '0' COMMENT '主公头像id',
  `heroLimit` int(11) DEFAULT '0' COMMENT '武将上限',
  `identify` int(11) DEFAULT NULL,
  `jewelLevel` int(11) DEFAULT '0' COMMENT '所戴宝石的等级',
  `jewelIntegral` int(11) DEFAULT '0' COMMENT '所有宝石的积分',
  `jobId` int(11) DEFAULT '0' COMMENT '官职id',
  `lastAutoAddEnergyTime` datetime DEFAULT '2013-01-01 00:00:00' COMMENT '最后自动增加体力的时间',
  `lastBuyEnergyTime` datetime DEFAULT '2013-01-01 00:00:00' COMMENT '最后购买体力的时间',
  `lastCalculateTime` datetime DEFAULT '2013-01-01 00:00:00' COMMENT '最后一次计算在线时长的时间',
  `lastReceiveSalaryTime` datetime DEFAULT '2013-01-01 00:00:00' COMMENT '最后领取俸禄时间',
  `level` int(11) DEFAULT '1' COMMENT '等级',
  `loginCount` int(11) DEFAULT '1' COMMENT '总登陆次数',
  `loginDays` int(11) DEFAULT '1' COMMENT '连续登陆天数',
  `loginTime` datetime DEFAULT '2013-01-01 00:00:00' COMMENT '最后一次登陆时间',
  `logoutTime` datetime DEFAULT '2013-01-01 00:00:00' COMMENT '最后一次登出时间',
  `loveliness` int(11) DEFAULT '0' COMMENT '魅力值',
  `mustRename` int(11) NOT NULL COMMENT '是否需要改名',
  `newerStep` int(11) DEFAULT '0' COMMENT '新手已经完成的步骤',
  `oldVipLevel` int(11) DEFAULT '0' COMMENT 'VIP失效时的VIP等级，如果当前VIP没有失效，则和vipLevel保持同步',
  `playerName` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT '主公名称',
  `registerTime` datetime DEFAULT '2013-01-01 00:00:00' COMMENT '注册时间',
  `rmb` bigint(20) DEFAULT '0' COMMENT '内币',
  `server` int(11) DEFAULT '1' COMMENT '服标识',
  `sex` int(11) DEFAULT NULL,
  `silver` bigint(20) DEFAULT '0' COMMENT '银元',
  `soul` bigint(20) DEFAULT '0' COMMENT '武将经验',
  `tmpVipLevel` int(11) DEFAULT '-1' COMMENT '临时VIP等级',
  `tmpVipNotice` tinyint(4) DEFAULT '0' COMMENT '临时VIP是否已经弹窗提示  0-不是 1-是',
  `tmpVipTime` datetime DEFAULT '2012-01-01 00:00:00' COMMENT '临时VIP到期时间',
  `totalAbility` double DEFAULT '0' COMMENT '总战斗力',
  `totalConsume` bigint(20) DEFAULT '0' COMMENT '总累计消费',
  `totalGold` bigint(20) DEFAULT '0' COMMENT '元宝总累计充值',
  `totalLoginDays` int(11) DEFAULT '1' COMMENT '累计登陆天数',
  `totalOlineTimeAtToday` bigint(20) DEFAULT '0' COMMENT '今天第一次登陆时的总在线时长',
  `totalOnlineTime` bigint(20) DEFAULT '0' COMMENT '总在线时长(累计，单位毫秒)',
  `todayOnlineTime` bigint(20) DEFAULT '0' COMMENT '当天在线时长(累计，单位毫秒)',
  `totalRmb` bigint(20) DEFAULT '0' COMMENT '内币总累计充值',
  `userName` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT '用户名',
  `vipEver` tinyint(4) DEFAULT '0' COMMENT '是否永久VIP  0-不是 1-是',
  `vipGiftLevel` int(11) DEFAULT '-1' COMMENT '上一次领取VIP礼包等级',
  `vipIncomeDate` datetime DEFAULT '2012-01-01 00:00:00' COMMENT 'VIP最后登录领取成长值时间',
  `vipLevel` int(11) DEFAULT '0' COMMENT 'vip等级',
  `vipNotice` tinyint(4) DEFAULT '0' COMMENT '正式VIP是否已经弹窗提示  0-不是 1-是',
  `vipTime` datetime DEFAULT '2012-01-01 00:00:00' COMMENT 'VIP等级失效时间',
  `vipWeekGiftDate` datetime DEFAULT '2012-01-01 00:00:00' COMMENT '当前领取每周VIP礼包时间',
  `discountShopTime` bigint(20) NOT NULL DEFAULT 0 COMMENT '折扣商店购买时间',
  `ipAddress` varchar(50) DEFAULT '' COMMENT '最后一次登陆的IP地址',
  `firstCharge` int(11) NOT NULL DEFAULT 0 COMMENT '首充金额',
  `gsScore` bigint(20) NOT NULL DEFAULT 0 COMMENT 'GS分值',
  `divinationIntegral` int(11) NOT NULL DEFAULT 0 COMMENT '所戴命签的积分',
  `topTotalAbility` double NOT NULL DEFAULT 0 COMMENT '历史最高总战斗力',
  PRIMARY KEY (`id`),
  KEY `player_playername_index` (`playerName`),
  KEY `player_level_index` (`level`),
  KEY `player_username_index` (`userName`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of player
-- ----------------------------

-- ----------------------------
-- Table structure for `playerActivity`
-- ----------------------------
DROP TABLE IF EXISTS `playerActivity`;
CREATE TABLE `playerActivity` (
  `id` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT '主键id',
  `activityId` int(11) NOT NULL COMMENT '活动ID',
  `playerId` bigint(20) NOT NULL COMMENT '玩家id',
  `receiveTime` datetime DEFAULT NULL COMMENT '任务进度信息',
  `status` tinyint(4) DEFAULT '0' COMMENT '状态, 0-关闭  1-开启',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerActivity
-- ----------------------------

-- ----------------------------
-- Table structure for `playerActivityTask`
-- ----------------------------
DROP TABLE IF EXISTS `playerActivityTask`;
CREATE TABLE `playerActivityTask` (
  `id` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT '主键id',
  `playerId` bigint(20) NOT NULL COMMENT '玩家id',
  `taskContent` text COLLATE utf8_unicode_ci COMMENT '任务进度信息',
  `taskId` int(11) DEFAULT '0' COMMENT '基础任务id',
  `taskStatus` tinyint(4) DEFAULT '2' COMMENT '任务状态',
  `rewardTime` datetime DEFAULT NULL COMMENT '领奖时间',
  `rewardedCount` int(11) DEFAULT '0' COMMENT '已领奖次数',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerActivityTask
-- ----------------------------

-- ----------------------------
-- Table structure for `playerArena`
-- ----------------------------
DROP TABLE IF EXISTS `playerArena`;
CREATE TABLE `playerArena` (
  `playerId` bigint(20) NOT NULL COMMENT '角色id',
  `balanceRank` int(10) DEFAULT '0' COMMENT '结算排名',
  `boxCount` int(10) DEFAULT '1' COMMENT '宝箱奖励倍数',
  `boxId` int(10) DEFAULT '0' COMMENT '宝箱id',
  `boxStatus` tinyint(4) DEFAULT '0' COMMENT '宝箱状态：0-未领取 1-已领取',
  `buyCount` tinyint(4) DEFAULT '0' COMMENT '当天(重置时间)购买次数',
  `cdTime` bigint(20) DEFAULT '0' COMMENT '自最后一次挑战以来累计cd时间(ms)',
  `challengeCount` tinyint(4) DEFAULT '0' COMMENT '当天(重置时间)挑战次数',
  `challengeHis` text COLLATE utf8_unicode_ci COMMENT '信息',
  `challengeTime` bigint(20) DEFAULT '0' COMMENT '最近一次挑战时间(ms)',
  `challenged` tinyint(4) DEFAULT '0' COMMENT '是否曾经挑战过竞技场, 0-否  1-是',
  `nextChallengeTime` bigint(20) DEFAULT '0' COMMENT '下次可挑战时间(ms)',
  `preLeftBuyCount` tinyint(4) DEFAULT '0' COMMENT '当天(重置时间)之前的剩余购买次数',
  `refreshTime` datetime DEFAULT NULL COMMENT '上次重置时间',
  `topRank` int(10) DEFAULT '0' COMMENT '历史最高排名',
  `wins` int(10) DEFAULT '0' COMMENT '当前连胜',
  PRIMARY KEY (`playerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerArena
-- ----------------------------

-- ----------------------------
-- Table structure for `playerArmageddonInfo`
-- ----------------------------
DROP TABLE IF EXISTS `playerArmageddonInfo`;
CREATE TABLE `playerArmageddonInfo` (
  `id` bigint(20) NOT NULL COMMENT '玩家id',
  `battleCdTime` bigint(20) NOT NULL COMMENT '战斗CD时间',
  `curMissionId` int(11) DEFAULT '-1' COMMENT '当前据点军队进度ID',
  `first` tinyint(3) DEFAULT '1' COMMENT '是否首次进入 ',
  `hardType` tinyint(3) DEFAULT '0' COMMENT '当前困难模式',
  `hookStatus` tinyint(3) DEFAULT '0' COMMENT '挂机状态 0-正常 1-挂机中  2-挂机结束',
  `incomeDate` datetime DEFAULT '2012-01-01 00:00:00' COMMENT '收益次数最后计算时间',
  `lastMissionId` int(11) DEFAULT '-1' COMMENT '最近通关的最大据点ID',
  `missionId` int(11) DEFAULT '-1' COMMENT '当前据点进度(保存最高已进入的据点id)',
  `noticeResult` text COLLATE utf8_unicode_ci COMMENT '当前累计的奖励串结果',
  `reward` tinyint(3) DEFAULT '0' COMMENT '当前累计的奖励串结果是否可以领取(据点通关)',
  `rewardResult` text COLLATE utf8_unicode_ci COMMENT '当前累计的奖励串结果',
  `times` int(11) DEFAULT '0' COMMENT '当前已用次数',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerArmageddonInfo
-- ----------------------------

-- ----------------------------
-- Table structure for `playerAttrReward`
-- ----------------------------
DROP TABLE IF EXISTS `playerAttrReward`;
CREATE TABLE `playerAttrReward` (
  `id` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT 'id',
  `playerId` bigint(20) NOT NULL COMMENT '玩家id',
  `receiveRewardDate` datetime DEFAULT '2013-01-01 00:00:00' COMMENT '领取奖励时间 ',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerAttrReward
-- ----------------------------

-- ----------------------------
-- Table structure for `playerBalckMarket`
-- ----------------------------
DROP TABLE IF EXISTS `playerBalckMarket`;
CREATE TABLE `playerBalckMarket` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `firstRefresh` int(11) NOT NULL COMMENT '是否已经刷新过',
  `freeRefreshTimes` int(11) NOT NULL COMMENT '已经使用的免费刷新次数',
  `goods` varchar(1000) COLLATE utf8_unicode_ci NOT NULL COMMENT '出售物品列表',
  `goodsIds` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '已购买的物品id列表',
  `integral` int(11) NOT NULL COMMENT '黑市积分',
  `lastFreeRefreshTime` datetime DEFAULT '2013-01-01 00:00:00' COMMENT '最后免费刷新物品的时间',
  `lastRefreshTime` datetime DEFAULT '2013-01-01 00:00:00' COMMENT '最后刷新物品的时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerBalckMarket
-- ----------------------------

-- ----------------------------
-- Table structure for `playerBaptizeHistory`
-- ----------------------------
DROP TABLE IF EXISTS `playerBaptizeHistory`;
CREATE TABLE `playerBaptizeHistory` (
  `id` bigint(20) NOT NULL COMMENT '玩家id',
  `baptizeTimes` int(11) DEFAULT '0' COMMENT '洗炼次数',
  `lastBaptizeTime` datetime DEFAULT '2012-01-01 00:00:00' COMMENT '最后洗炼时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerBaptizeHistory
-- ----------------------------

-- ----------------------------
-- Table structure for `playerBattleLineup`
-- ----------------------------
DROP TABLE IF EXISTS `playerBattleLineup`;
CREATE TABLE `playerBattleLineup` (
  `id` bigint(20) NOT NULL COMMENT 'id',
  `drillId` int(11) DEFAULT '-1' COMMENT '当前使用的军阵id',
  `eight` bigint(20) DEFAULT '-1' COMMENT '阵形位置8武将id',
  `eleven` bigint(20) DEFAULT '-1' COMMENT '阵形位置11武将id',
  `five` bigint(20) DEFAULT '-1' COMMENT '阵形位置5武将id',
  `four` bigint(20) DEFAULT '-1' COMMENT '阵形位置4武将id',
  `general` bigint(20) NOT NULL COMMENT '主将id',
  `nine` bigint(20) DEFAULT '-1' COMMENT '阵形位置9武将id',
  `one` bigint(20) DEFAULT '-1' COMMENT '阵形位置1武将id',
  `seven` bigint(20) DEFAULT '-1' COMMENT '阵形位置7武将id',
  `six` bigint(20) DEFAULT '-1' COMMENT '阵形位置6武将id',
  `ten` bigint(20) DEFAULT '-1' COMMENT '阵形位置10武将id',
  `three` bigint(20) DEFAULT '-1' COMMENT '阵形位置3武将id',
  `twelve` bigint(20) DEFAULT '-1' COMMENT '阵形位置12武将id',
  `two` bigint(20) DEFAULT '-1' COMMENT '阵形位置2武将id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerBattleLineup
-- ----------------------------

-- ----------------------------
-- Table structure for `playerBattlePosition`
-- ----------------------------
DROP TABLE IF EXISTS `playerBattlePosition`;
CREATE TABLE `playerBattlePosition` (
  `id` bigint(20) NOT NULL COMMENT 'id',
  `eight` bigint(20) DEFAULT '-1' COMMENT '位置8武将id',
  `five` bigint(20) DEFAULT '-1' COMMENT '位置5武将id',
  `four` bigint(20) DEFAULT '-1' COMMENT '位置4武将id',
  `nine` bigint(20) DEFAULT '-1' COMMENT '位置9武将id',
  `one` bigint(20) DEFAULT '-1' COMMENT '位置1武将id',
  `seven` bigint(20) DEFAULT '-1' COMMENT '位置7武将id',
  `six` bigint(20) DEFAULT '-1' COMMENT '位置6武将id',
  `ten` bigint(20) DEFAULT '-1' COMMENT '位置10武将id',
  `three` bigint(20) DEFAULT '-1' COMMENT '位置3武将id',
  `two` bigint(20) DEFAULT '-1' COMMENT '位置2武将id',
  `eleven` bigint(20) DEFAULT '-1' COMMENT '位置11武将id',
  `twelve` bigint(20) DEFAULT '-1' COMMENT '位置12武将id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerBattlePosition
-- ----------------------------

-- ----------------------------
-- Table structure for `playerBuff`
-- ----------------------------
DROP TABLE IF EXISTS `playerBuff`;
CREATE TABLE `playerBuff` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `itemId` int(11) NOT NULL COMMENT '道具ID',
  `persistenceTime` bigint(20) NOT NULL COMMENT '持续时间(毫秒)',
  `playerId` bigint(20) NOT NULL COMMENT '角色ID',
  `startTime` datetime DEFAULT '2013-01-01 00:00:00' COMMENT '开始时间',
  PRIMARY KEY (`id`),
  KEY `player_buff_index` (`playerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerBuff
-- ----------------------------

-- ----------------------------
-- Table structure for `playerBuilding`
-- ----------------------------
DROP TABLE IF EXISTS `playerBuilding`;
CREATE TABLE `playerBuilding` (
  `id` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT 'id',
  `buildingId` int(11) NOT NULL COMMENT '建筑id',
  `level` int(11) DEFAULT '1' COMMENT '建筑等级',
  `playerId` bigint(20) NOT NULL COMMENT '玩家id',
  `quality` int(11) DEFAULT '1' COMMENT '建筑品质',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerBuilding
-- ----------------------------

-- ----------------------------
-- Table structure for `playerChampion`
-- ----------------------------
DROP TABLE IF EXISTS `playerChampion`;
CREATE TABLE `playerChampion` (
  `playerId` bigint(20) NOT NULL COMMENT '角色id',
  `championDay` varchar(20) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '参加争霸赛日期',
  `rank` int(11) DEFAULT '0' COMMENT '名次',
  `rewardStatus` tinyint(2) DEFAULT '0' COMMENT '奖励是否领取',
  `rewards` text COLLATE utf8_unicode_ci COMMENT '奖励信息',
  `supports` text COLLATE utf8_unicode_ci COMMENT '支持谁(json)',
  PRIMARY KEY (`playerId`),
  KEY `playerChampion_idx_championDay` (`championDay`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerChampion
-- ----------------------------

-- ----------------------------
-- Table structure for `playerChapterInfo`
-- ----------------------------
DROP TABLE IF EXISTS `playerChapterInfo`;
CREATE TABLE `playerChapterInfo` (
  `id` bigint(20) NOT NULL COMMENT '玩家id',
  `simpleAttributes` text COLLATE utf8_unicode_ci COMMENT '自定义属性',
  `armyId` int(11) DEFAULT '-1' COMMENT '当前据点军队进度ID',
  `breakTop` tinyint(3) DEFAULT '0' COMMENT '首破标识',
  `breakTopMissionId` int(11) DEFAULT '-1' COMMENT '首破missionId',
  `breakTopReward` text COLLATE utf8_unicode_ci COMMENT '当前累计的首破奖励',
  `chapterRewardIds` text COLLATE utf8_unicode_ci COMMENT '章节通关奖励 领取记录',
  `chapterStarReward` text COLLATE utf8_unicode_ci COMMENT '章节通关奖励 领取记录',
  `curArmyId` int(11) DEFAULT '-1' COMMENT '当前据点军队进度ID',
  `hookAttackCount` int(11) DEFAULT '0' COMMENT '挂机已结算次数',
  `hookCount` int(11) DEFAULT '0' COMMENT '挂机次数',
  `hookMissionId` int(11) DEFAULT '-1' COMMENT '挂机据点id',
  `hookRecord` text COLLATE utf8_unicode_ci COMMENT ' 挂机奖励',
  `hookStatus` tinyint(3) DEFAULT '0' COMMENT '挂机状态 0-正常 1-挂机中  2-挂机结束',
  `hookTime` datetime DEFAULT '2012-01-01 00:00:00' COMMENT '挂机时间 ',
  `lastMissionId` int(11) DEFAULT '-1' COMMENT '最近通关的最大据点ID',
  `lastStar` int(11) DEFAULT '-1' COMMENT '上一次战斗的星级信息',
  `missionId` int(11) DEFAULT '-1' COMMENT '当前据点进度(保存最高已进入的据点id)',
  `missionStar` text COLLATE utf8_unicode_ci COMMENT '据点星级信息',
  `noticeResult` text COLLATE utf8_unicode_ci COMMENT '当前累计的奖励串结果',
  `reward` tinyint(3) DEFAULT '0' COMMENT '当前累计的奖励串结果是否可以领取(据点通关)',
  `rewardResult` text COLLATE utf8_unicode_ci COMMENT '当前累计的奖励串结果',
  `specialMissionId` int(11) DEFAULT '-1' COMMENT '上一次特殊据点',
  PRIMARY KEY (`id`),
  KEY `playerChapterInfo_index` (`lastMissionId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerChapterInfo
-- ----------------------------

-- ----------------------------
-- Table structure for `playerChapterTask`
-- ----------------------------
DROP TABLE IF EXISTS `playerChapterTask`;
CREATE TABLE `playerChapterTask` (
  `id` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT '主键id',
  `playerId` bigint(20) NOT NULL COMMENT '玩家id',
  `taskContent` text COLLATE utf8_unicode_ci COMMENT '任务进度信息',
  `taskId` int(11) DEFAULT '0' COMMENT '基础任务id',
  `taskStatus` tinyint(4) DEFAULT '2' COMMENT '任务状态',
  PRIMARY KEY (`id`),
  KEY `playerChapterTask_idx_playerId` (`playerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerChapterTask
-- ----------------------------

-- ----------------------------
-- Table structure for `playerCheerInfo`
-- ----------------------------
DROP TABLE IF EXISTS `playerCheerInfo`;
CREATE TABLE `playerCheerInfo` (
  `id` bigint(20) NOT NULL COMMENT '玩家ID',
  `cdPlayerInfo` text COLLATE utf8_unicode_ci COMMENT '已进入CD回合玩家',
  `cheerId` bigint(20) DEFAULT '-1' COMMENT '当前助阵用户主将ID',
  `cheerInfo` text COLLATE utf8_unicode_ci COMMENT '当前助阵玩家列表',
  `cheerState` int(11) DEFAULT '0' COMMENT '当前助阵用户奖励类型',
  `formation` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '邀请助阵玩家布阵信息',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerCheerInfo
-- ----------------------------

-- ----------------------------
-- Table structure for `playerCoolQueue`
-- ----------------------------
DROP TABLE IF EXISTS `playerCoolQueue`;
CREATE TABLE `playerCoolQueue` (
  `id` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT 'id',
  `expireTime` datetime DEFAULT '2012-01-01 00:00:00' COMMENT '冷却到期时间',
  `freezing` bit(1) DEFAULT b'0' COMMENT '是否空闲中  true空闲中/false冷却中',
  `playerId` bigint(20) NOT NULL COMMENT '玩家id',
  `queueId` int(11) NOT NULL COMMENT '冷却队列id',
  `type` int(11) NOT NULL COMMENT '冷却队列类型',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerCoolQueue
-- ----------------------------

-- ----------------------------
-- Table structure for `playerCustomHeroSkill`
-- ----------------------------
DROP TABLE IF EXISTS `playerCustomHeroSkill`;
CREATE TABLE `playerCustomHeroSkill` (
  `id` bigint(20) NOT NULL COMMENT 'id',
  `activeSkill` text COLLATE utf8_unicode_ci COMMENT '武将主动技能',
  `playerId` bigint(20) NOT NULL COMMENT '所属玩家ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerCustomHeroSkill
-- ----------------------------

-- ----------------------------
-- Table structure for `playerCustomTask`
-- ----------------------------
DROP TABLE IF EXISTS `playerCustomTask`;
CREATE TABLE `playerCustomTask` (
  `id` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT '主键id',
  `playerId` bigint(20) NOT NULL COMMENT '玩家id',
  `taskContent` text COLLATE utf8_unicode_ci COMMENT '任务进度信息',
  `taskId` int(11) DEFAULT '0' COMMENT '基础任务id',
  `taskStatus` tinyint(4) DEFAULT '2' COMMENT '任务状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerCustomTask
-- ----------------------------

-- ----------------------------
-- Table structure for `playerDailyGuide`
-- ----------------------------
DROP TABLE IF EXISTS `playerDailyGuide`;
CREATE TABLE `playerDailyGuide` (
  `id` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT '主键id',
  `playerId` bigint(20) NOT NULL COMMENT '玩家id',
  `taskContent` text COLLATE utf8_unicode_ci COMMENT '任务进度信息',
  `taskId` int(11) DEFAULT '0' COMMENT '基础任务id',
  `taskStatus` tinyint(4) DEFAULT '2' COMMENT '任务状态',
  PRIMARY KEY (`id`),
  KEY `playerDailyGuide_idx_playerId` (`playerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerDailyGuide
-- ----------------------------

-- ----------------------------
-- Table structure for `playerDailyReward`
-- ----------------------------
DROP TABLE IF EXISTS `playerDailyReward`;
CREATE TABLE `playerDailyReward` (
  `playerId` bigint(20) NOT NULL COMMENT '玩家id',
  `guideTime` datetime DEFAULT NULL COMMENT '接受指引时间',
  `vitalityRewards` text COLLATE utf8_unicode_ci COMMENT '已领取的活跃度奖励ID json串',
  PRIMARY KEY (`playerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerDailyReward
-- ----------------------------

-- ----------------------------
-- Table structure for `playerDailyTask`
-- ----------------------------
DROP TABLE IF EXISTS `playerDailyTask`;
CREATE TABLE `playerDailyTask` (
  `id` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT '主键id',
  `playerId` bigint(20) NOT NULL COMMENT '玩家id',
  `taskContent` text COLLATE utf8_unicode_ci COMMENT '任务进度信息',
  `taskId` int(11) DEFAULT '0' COMMENT '基础任务id',
  `taskStatus` tinyint(4) DEFAULT '2' COMMENT '任务状态',
  `rewardTime` datetime DEFAULT NULL COMMENT '领奖时间',
  `rewardedCount` int(11) DEFAULT '0' COMMENT '已领奖次数',
  PRIMARY KEY (`id`),
  KEY `playerDailyTask_idx_playerId` (`playerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerDailyTask
-- ----------------------------

-- ----------------------------
-- Table structure for `playerDayRevenue`
-- ----------------------------
DROP TABLE IF EXISTS `playerDayRevenue`;
CREATE TABLE `playerDayRevenue` (
  `id` bigint(20) NOT NULL COMMENT '玩家id',
  `simpleAttributes` text COLLATE utf8_unicode_ci COMMENT '自定义属性',
  `checkTime` datetime DEFAULT '2012-01-01 00:00:00' COMMENT '挂机时间 ',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerDayRevenue
-- ----------------------------

-- ----------------------------
-- Table structure for `playerDivination`
-- ----------------------------
DROP TABLE IF EXISTS `playerDivination`;
CREATE TABLE `playerDivination` (
  `Id` bigint(20) NOT NULL COMMENT '主键',
  `divinationId` int(11) NOT NULL COMMENT '命签id',
  `exp` int(11) NOT NULL COMMENT '命签经验',
  `level` int(11) NOT NULL COMMENT '命签等级',
  `locked` tinyint(4) NOT NULL COMMENT '是否锁定，0没锁定，非0锁定',
  `playerId` bigint(20) NOT NULL COMMENT '玩家id',
  `state` tinyint(4) NOT NULL COMMENT '是否已经拾取，0没拾取，非0已拾取',
  `wear` int(11) NOT NULL COMMENT '是否穿戴，0没穿，非0穿上',
  `orderNumber` bigint(20) DEFAULT '0' COMMENT '求签序号',
  `costRate` double DEFAULT '1.0' COMMENT '求签消耗倍率',
  PRIMARY KEY (`Id`),
  KEY `divination_index` (`playerId`,`wear`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerDivination
-- ----------------------------

-- ----------------------------
-- Table structure for `playerDrillTech`
-- ----------------------------
DROP TABLE IF EXISTS `playerDrillTech`;
CREATE TABLE `playerDrillTech` (
  `id` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT 'id',
  `level` int(11) DEFAULT '0' COMMENT '军阵科技等级',
  `playerId` bigint(20) NOT NULL COMMENT '玩家id',
  `techId` int(11) NOT NULL COMMENT '军阵科技id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerDrillTech
-- ----------------------------

-- ----------------------------
-- Table structure for `playerEquipRaffle`
-- ----------------------------
DROP TABLE IF EXISTS `playerEquipRaffle`;
CREATE TABLE `playerEquipRaffle` (
  `id` bigint(20) NOT NULL COMMENT '玩家id',
  `autoSell` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否自动出售',
  `integral` int(11) NOT NULL DEFAULT '0' COMMENT '积分',
  `equipSoul` int(11) NOT NULL DEFAULT '0' COMMENT '器灵值',
  `raffles` text COLLATE utf8_unicode_ci COMMENT '已经抽过的基础数据id数组Json串',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerEquipRaffle
-- ----------------------------

-- ----------------------------
-- Table structure for `playerExchange`
-- ----------------------------
DROP TABLE IF EXISTS `playerExchange`;
CREATE TABLE `playerExchange` (
  `playerId` bigint(20) NOT NULL COMMENT '角色id',
  `exchanges` longtext COLLATE utf8_unicode_ci COMMENT '有兑换次数限制的商店兑换兑换信息',
  PRIMARY KEY (`playerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerExchange
-- ----------------------------

-- ----------------------------
-- Table structure for `playerFlag`
-- ----------------------------
DROP TABLE IF EXISTS `playerFlag`;
CREATE TABLE `playerFlag` (
  `id` bigint(20) NOT NULL COMMENT '玩家id',
  `abilityLv` int(11) NOT NULL COMMENT '战斗力等级id',
  `friendFlag` int(3) DEFAULT '0' COMMENT '一键弹出好友面板功能',
  `hadDiaoChan` int(11) DEFAULT '0' COMMENT '是否已经送过貂蝉0-没有 1-送过',
  `validFlag` int(3) DEFAULT '0' COMMENT '是否已领取 手机验证礼包',
  `younglingFlag` int(3) DEFAULT '0' COMMENT '是否已领取 新手卡卡号',
  `microEndGiftFlag` int(3) DEFAULT '0' COMMENT '是否已领取 微端大礼',
  `weChatFlag`  tinyint(2) NOT NULL DEFAULT 0 COMMENT '是否领取微信礼包',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerFlag
-- ----------------------------

-- ----------------------------
-- Table structure for `playerFund`
-- ----------------------------
DROP TABLE IF EXISTS `playerFund`;
CREATE TABLE `playerFund` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `simpleAttributes` text COLLATE utf8_unicode_ci COMMENT '自定义属性',
  `buyTime` datetime DEFAULT '2013-01-01 00:00:00' COMMENT '购买时间',
  `hadBuyed` int(11) NOT NULL COMMENT '是否已经购买',
  `lastSendTime` datetime DEFAULT '2013-01-01 00:00:00' COMMENT '最后赠送时间',
  `sendTimes` int(11) NOT NULL COMMENT '当天已经赠送的次数',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerFund
-- ----------------------------

-- ----------------------------
-- Table structure for `playerGiftInfo`
-- ----------------------------
DROP TABLE IF EXISTS `playerGiftInfo`;
CREATE TABLE `playerGiftInfo` (
  `id` bigint(20) NOT NULL COMMENT '玩家id',
  `collection` tinyint(4) DEFAULT '0' COMMENT '收藏礼包  0-未领取 1-已领取',
  `giftId` int(11) DEFAULT '-1' COMMENT '已领取在线礼包的ID记录',
  `lastLoginDate` datetime DEFAULT '2012-01-01 00:00:00' COMMENT '上次登录时间 ',
  `levelGiftRecord` text COLLATE utf8_unicode_ci COMMENT '连续消费礼包已领取记录',
  `loginCount` int(11) DEFAULT '0' COMMENT '连续登录次数',
  `loginGiftReward` text COLLATE utf8_unicode_ci COMMENT '连续礼包领取记录',
  `serverGiftRecord` text COLLATE utf8_unicode_ci COMMENT '全服礼包已领取记录',
  `totalOnlineTime` bigint(20) DEFAULT '0' COMMENT '上一次领取总在线时长(累计，单位毫秒)',
  `cdKeyNoRecord` text COLLATE utf8_unicode_ci COMMENT 'cdkey礼包已领取记录',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerGiftInfo
-- ----------------------------

-- ----------------------------
-- Table structure for `playerGoalChapter`
-- ----------------------------
DROP TABLE IF EXISTS `playerGoalChapter`;
CREATE TABLE `playerGoalChapter` (
  `id` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT '主键id',
  `goalChapterId` int(11) NOT NULL COMMENT '目标章节ID',
  `playerId` bigint(20) NOT NULL COMMENT '玩家id',
  `status` tinyint(4) DEFAULT '0' COMMENT '状态',
  `tasks` longtext COLLATE utf8_unicode_ci COMMENT '已领取完奖励的章节任务id信息',
  PRIMARY KEY (`id`),
  KEY `playerGoalChapter_idx_playerId` (`playerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerGoalChapter
-- ----------------------------

-- ----------------------------
-- Table structure for `playerGoodness`
-- ----------------------------
DROP TABLE IF EXISTS `playerGoodness`;
CREATE TABLE `playerGoodness` (
  `id` bigint(20) NOT NULL COMMENT 'id',
  `goodnessDetail` text COLLATE utf8_unicode_ci COMMENT '日行一善领取信息',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerGoodness
-- ----------------------------

-- ----------------------------
-- Table structure for `playerHero`
-- ----------------------------
DROP TABLE IF EXISTS `playerHero`;
CREATE TABLE `playerHero` (
  `id` bigint(20) NOT NULL COMMENT 'id',
  `arm` bigint(20) NOT NULL COMMENT '武器id',
  `awaked` tinyint(4) DEFAULT '0' COMMENT '是否觉醒 0-没有觉醒 1-觉醒',
  `book` bigint(20) NOT NULL COMMENT '兵书id',
  `cimelia` bigint(20) NOT NULL COMMENT '宝物id',
  `costTalentPoint` int(11) DEFAULT '0' COMMENT '已经消耗的天赋点',
  `divinationId1` bigint(20) NOT NULL COMMENT '命签槽位1的命签id',
  `divinationId10` bigint(20) NOT NULL COMMENT '命签槽位10的命签id',
  `divinationId2` bigint(20) NOT NULL COMMENT '命签槽位2的命签id',
  `divinationId3` bigint(20) NOT NULL COMMENT '命签槽位3的命签id',
  `divinationId4` bigint(20) NOT NULL COMMENT '命签槽位4的命签id',
  `divinationId5` bigint(20) NOT NULL COMMENT '命签槽位5的命签id',
  `divinationId6` bigint(20) NOT NULL COMMENT '命签槽位6的命签id',
  `divinationId7` bigint(20) NOT NULL COMMENT '命签槽位7的命签id',
  `divinationId8` bigint(20) NOT NULL COMMENT '命签槽位8的命签id',
  `divinationId9` bigint(20) NOT NULL COMMENT '命签槽位9的命签id',
  `exp` bigint(20) DEFAULT '0' COMMENT '累积经验',
  `heroHeadId` int(11) DEFAULT '-1' COMMENT '武将头像id',
  `heroName` varchar(50) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '武将名称',
  `heroType` int(11) NOT NULL COMMENT '武将类型id',
  `initTalentPoint` int(11) DEFAULT '0' COMMENT '初始天赋点',
  `left_Bangle` bigint(20) NOT NULL COMMENT '左手镯',
  `left_Ring` bigint(20) NOT NULL COMMENT '左戒指',
  `level` int(11) DEFAULT '1' COMMENT '等级',
  `lineupId` tinyint(4) DEFAULT '0' COMMENT '1-6上阵 -1不上阵',
  `locked` tinyint(4) DEFAULT '0' COMMENT '是否锁定 0-没有锁定 1-锁定',
  `mount` bigint(20) NOT NULL COMMENT '坐骑id',
  `playerId` bigint(20) NOT NULL COMMENT '玩家id',
  `right_Bangle` bigint(20) NOT NULL COMMENT '右手镯',
  `right_Ring` bigint(20) NOT NULL COMMENT '右戒指',
  `seal` bigint(20) NOT NULL COMMENT '兵符id',
  `soldierAmount` int(11) DEFAULT '0' COMMENT '带的士兵数量',
  `star` int(11) DEFAULT '1' COMMENT '星级',
  `talentLevel` int(11) DEFAULT '0' COMMENT '天赋等级',
  `talentPoint` int(11) DEFAULT '0' COMMENT '当前剩余天赋点',
  `resonateProgress` int(11) DEFAULT '0' COMMENT '宝石共鸣进度',
  `cape` bigint(20) NOT NULL DEFAULT '-1' COMMENT '披风id',
  `rank` int(11) DEFAULT '0' COMMENT '品阶',
  PRIMARY KEY (`id`),
  KEY `player_hero_index` (`playerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerHero
-- ----------------------------

-- ----------------------------
-- Table structure for `playerHeroCard`
-- ----------------------------
DROP TABLE IF EXISTS `playerHeroCard`;
CREATE TABLE `playerHeroCard` (
  `id` bigint(20) NOT NULL COMMENT '主键id',
  `bind` bit(1) DEFAULT b'1' COMMENT '是否绑定  true绑定/false不绑定',
  `itemId` int(11) NOT NULL COMMENT '武将卡id',
  `level` int(11) NOT NULL COMMENT '武将卡等级',
  `locked` bit(1) DEFAULT b'0' COMMENT '是否锁定  true锁定/false没锁定',
  `playerId` bigint(20) NOT NULL COMMENT '玩家id',
  `sell` bit(1) DEFAULT b'0' COMMENT '是否售出  true已售出/false没售出',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerHeroCard
-- ----------------------------

-- ----------------------------
-- Table structure for `playerHeroCollect`
-- ----------------------------
DROP TABLE IF EXISTS `playerHeroCollect`;
CREATE TABLE `playerHeroCollect` (
  `id` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT 'id',
  `collectId` int(11) NOT NULL COMMENT '猛将录id',
  `playerId` bigint(20) NOT NULL COMMENT '玩家id',
  `status` int(11) NOT NULL COMMENT '状态(0-未激活 1-已激活)',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerHeroCollect
-- ----------------------------

-- ----------------------------
-- Table structure for `playerHeroEquip`
-- ----------------------------
DROP TABLE IF EXISTS `playerHeroEquip`;
CREATE TABLE `playerHeroEquip` (
  `id` bigint(20) NOT NULL COMMENT '主键id',
  `addAttrStar1` int(11) NOT NULL COMMENT '附加属性类型1的星级',
  `addAttrStar2` int(11) NOT NULL COMMENT '附加属性类型2的星级',
  `addAttrStar3` int(11) NOT NULL COMMENT '附加属性类型3的星级',
  `addAttrStar4` int(11) NOT NULL COMMENT '附加属性类型4的星级',
  `addAttrStar5` int(11) NOT NULL COMMENT '附加属性类型5的星级',
  `addAttrStar6` int(11) NOT NULL COMMENT '附加属性类型6的星级',
  `addAttrType1` int(11) NOT NULL COMMENT '附加属性类型1',
  `addAttrType2` int(11) NOT NULL COMMENT '附加属性类型2',
  `addAttrType3` int(11) NOT NULL COMMENT '附加属性类型3',
  `addAttrType4` int(11) NOT NULL COMMENT '附加属性类型4',
  `addAttrType5` int(11) NOT NULL COMMENT '附加属性类型5',
  `addAttrType6` int(11) NOT NULL COMMENT '附加属性类型6',
  `bind` bit(1) DEFAULT b'1' COMMENT '是否绑定  true绑定/false不绑定',
  `equipId` int(11) NOT NULL COMMENT '装备id',
  `locked` bit(1) DEFAULT b'0' COMMENT '是否锁定  true锁定/false没锁定',
  `playerId` bigint(20) NOT NULL COMMENT '玩家id',
  `refineTimes` int(11) NOT NULL COMMENT '精炼次数',
  `sell` bit(1) DEFAULT b'0' COMMENT '是否售出  true已售出/false没售出',
  `slotId1` bit(1) DEFAULT b'0' COMMENT '宝石槽位1是否开启',
  `slotId2` bit(1) DEFAULT b'0' COMMENT '宝石槽位2是否开启',
  `slotId3` bit(1) DEFAULT b'0' COMMENT '宝石槽位3是否开启',
  `slotId4` bit(1) DEFAULT b'0' COMMENT '宝石槽位4是否开启',
  `slotItemId1` int(11) NOT NULL COMMENT '槽位1的宝石id',
  `slotItemId2` int(11) NOT NULL COMMENT '槽位2的宝石id',
  `slotItemId3` int(11) NOT NULL COMMENT '槽位3的宝石id',
  `slotItemId4` int(11) NOT NULL COMMENT '槽位4的宝石id',
  `strengthenLevel` int(11) NOT NULL COMMENT '强化等级',
  `wear` int(11) NOT NULL COMMENT '是否穿戴，0-没穿戴；非0已穿戴（穿戴位置）',
  `enhanceTimes` int(11) NOT NULL DEFAULT '0' COMMENT '附魔次数',
  PRIMARY KEY (`id`),
  KEY `player_equip_index` (`playerId`,`sell`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerHeroEquip
-- ----------------------------

-- ----------------------------
-- Table structure for `playerHeroPiece`
-- ----------------------------
DROP TABLE IF EXISTS `playerHeroPiece`;
CREATE TABLE `playerHeroPiece` (
  `id` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT 'id',
  `heroNumber` int(11) NOT NULL COMMENT '武将编号',
  `playerId` bigint(20) NOT NULL COMMENT '玩家id',
  `status` int(11) NOT NULL COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerHeroPiece
-- ----------------------------

-- ----------------------------
-- Table structure for `playerHeroTalentSkill`
-- ----------------------------
DROP TABLE IF EXISTS `playerHeroTalentSkill`;
CREATE TABLE `playerHeroTalentSkill` (
  `id` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT 'id',
  `heroId` bigint(20) NOT NULL COMMENT '武将id',
  `talentSkillId` int(11) NOT NULL COMMENT '天赋技能id',
  `talentSkillLevel` int(11) DEFAULT '0' COMMENT '天赋技能等级',
  PRIMARY KEY (`id`),
  KEY `player_hero_talent_skill_index` (`heroId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerHeroTalentSkill
-- ----------------------------

-- ----------------------------
-- Table structure for `playerInvadeInfo`
-- ----------------------------
DROP TABLE IF EXISTS `playerInvadeInfo`;
CREATE TABLE `playerInvadeInfo` (
  `id` bigint(20) NOT NULL COMMENT '玩家id',
  `armyId` int(11) DEFAULT '-1' COMMENT '当前据点军队进度ID',
  `battleDetail` text COLLATE utf8_unicode_ci COMMENT '当前各个据点战斗结果',
  `buyCountTimes` int(11) DEFAULT '0' COMMENT '当天购买总次数',
  `buyTimes` int(11) DEFAULT '0' COMMENT '当前剩余购买次数',
  `hookStatus` tinyint(3) DEFAULT '0' COMMENT '挂机状态 0-正常 1-挂机中  2-挂机结束',
  `incomeDate` datetime DEFAULT '2012-01-01 00:00:00' COMMENT '收益次数最后计算时间',
  `lastMissionId` int(11) DEFAULT '-1' COMMENT '最近通关的最大据点ID',
  `missionId` int(11) DEFAULT '-1' COMMENT '当前据点进度(保存最高已进入的据点id)',
  `times` int(11) DEFAULT '0' COMMENT '当前已用次数',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerInvadeInfo
-- ----------------------------

-- ----------------------------
-- Table structure for `playerItem`
-- ----------------------------
DROP TABLE IF EXISTS `playerItem`;
CREATE TABLE `playerItem` (
  `id` bigint(20) NOT NULL COMMENT '主键id',
  `amount` int(11) NOT NULL COMMENT '道具数量',
  `bind` bit(1) DEFAULT b'1' COMMENT '是否绑定  true绑定/false不绑定',
  `itemId` int(11) NOT NULL COMMENT '道具id',
  `level` int(11) NOT NULL COMMENT '道具等级',
  `locked` bit(1) DEFAULT b'0' COMMENT '是否锁定  true锁定/false没锁定',
  `playerId` bigint(20) NOT NULL COMMENT '玩家id',
  `sell` bit(1) DEFAULT b'0' COMMENT '是否售出  true已售出/false没售出',
  `expireTime` bigint(20) DEFAULT '0' COMMENT '失效时间',
  PRIMARY KEY (`id`),
  KEY `player_item_index` (`playerId`,`sell`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerItem
-- ----------------------------

-- ----------------------------
-- Table structure for `playerJourneyInfo`
-- ----------------------------
DROP TABLE IF EXISTS `playerJourneyInfo`;
CREATE TABLE `playerJourneyInfo` (
  `id` bigint(20) NOT NULL COMMENT '玩家id',
  `armyId` int(11) DEFAULT '-1' COMMENT '当前据点军队进度ID',
  `buyTimes` int(11) DEFAULT '0' COMMENT '当天使用道具购买次数(简单)',
  `buyTimesHard` int(11) DEFAULT '0' COMMENT '当天使用道具购买次数(困难)',
  `curArmyId` int(11) DEFAULT '-1' COMMENT '当前据点军队进度ID',
  `die` tinyint(3) DEFAULT '0' COMMENT '最后一场战斗是否死亡',
  `hardType` tinyint(3) DEFAULT '0' COMMENT '当前困难模式',
  `hookFubenId` int(11) DEFAULT '-1' COMMENT '挂机已结算州id',
  `hookRecord` text COLLATE utf8_unicode_ci COMMENT ' 挂机奖励',
  `hookStatus` tinyint(3) DEFAULT '0' COMMENT '挂机状态 0-正常 1-挂机中  2-挂机结束',
  `hookTime` datetime DEFAULT '2012-01-01 00:00:00' COMMENT '挂机时间 ',
  `incomeDate` datetime DEFAULT '2012-01-01 00:00:00' COMMENT '收益次数最后计算时间',
  `lastEasyMissionId` int(11) DEFAULT '-1' COMMENT '当前正在打的(简单)missionId',
  `lastHardMissionId` int(11) DEFAULT '-1' COMMENT '当前正在打的(困难)missionId',
  `lastMaxEasyFubenId` int(11) DEFAULT '-1' COMMENT '最近通关的最大据点ID(简单)',
  `lastMaxEasyMissionId` int(11) DEFAULT '-1' COMMENT '最近通关的最大据点ID(简单)',
  `lastMaxHardFubenId` int(11) DEFAULT '-1' COMMENT '最近通关的最大据点ID(困难)',
  `lastMaxHardMissionId` int(11) DEFAULT '-1' COMMENT '最近通关的最大据点ID(困难)',
  `missionId` int(11) DEFAULT '-1' COMMENT '当前据点进度(保存最高已进入的据点id)',
  `nextHookMissionId` int(11) DEFAULT '-1' COMMENT '下一个需要挂机的missionId',
  `noticeResult` text COLLATE utf8_unicode_ci COMMENT '当前累计的奖励串结果',
  `reviveTimes` int(11) DEFAULT '0' COMMENT '当天可用免费的复活次数',
  `reward` tinyint(3) DEFAULT '0' COMMENT '当前累计的奖励串结果是否可以领取(据点通关)',
  `rewardResult` text COLLATE utf8_unicode_ci COMMENT '当前累计的奖励串结果',
  `times` int(11) DEFAULT '0' COMMENT '当前已用次数',
  `useReviveTimes` int(11) DEFAULT '0' COMMENT '当前已使用复活次数',
  `buyHardCount` int(11) DEFAULT '0' COMMENT '当前已购买困难模式次数',
  `buyHardTimes` int(11) DEFAULT '0' COMMENT '当前已购买困难模式剩余次数(能用的次数)',
  `journeyHardItemTimes` int(11) DEFAULT '0' COMMENT '当前已消费困难模式免费次数',
  `hardTimes` int(11) DEFAULT '0' COMMENT '当前困难剩余次数',
  `hardReward` tinyint(3) DEFAULT '0' COMMENT '当前困难模式收益 0-100% 1-50%',
  `easyHonorRank` text COLLATE utf8_unicode_ci COMMENT '已领取的简单成就丰碑奖励',
  `hardHonorRank` text COLLATE utf8_unicode_ci COMMENT '已领取的复杂成就丰碑奖励',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerJourneyInfo
-- ----------------------------

-- ----------------------------
-- Table structure for `playerLoopInfo` 
-- ----------------------------
DROP TABLE IF EXISTS `playerLoopInfo`;
CREATE TABLE `playerLoopInfo` (
  `id` bigint(20) NOT NULL COMMENT '玩家id',
  `boxRewards` varchar(255) NOT NULL DEFAULT '' COMMENT '宝箱奖励验证,每天的宝箱不能重复开启(gird,grid,grid[300001_300002_300001_])',
  `buyCommonDiceCount` int(11) NOT NULL DEFAULT '0' COMMENT '当日购买普通骰子的总数',
  `buyLuckyDiceCount` int(11) NOT NULL DEFAULT '0' COMMENT '当日购买幸运骰子的总数',
  `commonDiceSum` int(11) NOT NULL DEFAULT '0' COMMENT '普通骰子的总数',
  `completeTaskCityGId` int(11) NOT NULL DEFAULT '0' COMMENT '完成任务的城市Id',
  `completeTaskCount` int(11) NOT NULL DEFAULT '0' COMMENT '完成任务的总数',
  `coupon` int(11) NOT NULL DEFAULT '0' COMMENT '点卷',
  `direction` int(11) NOT NULL DEFAULT '8' COMMENT '前进的方向(保存客户端的方向)',
  `exchangeScore` varchar(255) DEFAULT '' COMMENT '积分兑换的列表(每日清空)',
  `gridId` int(11) NOT NULL DEFAULT '0' COMMENT '记录玩家当前所处的格子ID',
  `isFirst` int(1) NOT NULL DEFAULT '0' COMMENT '是否第一次跑环 0,否 1,是 ',
  `luckyDiceSum` int(11) NOT NULL DEFAULT '0' COMMENT '幸运骰子的总数',
  `revicedCommonDiceTime_360` bigint(22) NOT NULL DEFAULT '0' COMMENT '上一次领取普通骰子的时间-6小时领一个',
  `revicedCommonDiceTime_5` bigint(22) NOT NULL DEFAULT '0' COMMENT '上一次领取普通骰子的时间-5分钟领一次',
  `revicedLuckDiceTime` datetime NOT NULL DEFAULT '2013-10-01 00:00:00' COMMENT '上一次领取超级骰的时间-保存天数',
  `sceneId` int(11) NOT NULL DEFAULT '0' COMMENT '玩家当前所在的场景id',
  `score` int(11) NOT NULL DEFAULT '0' COMMENT '攻击boss的获得的积分',
  `taskId` int(11) NOT NULL DEFAULT '0' COMMENT '当前领取的任务Id',
  `todayLoginTime` datetime NOT NULL DEFAULT '2012-01-01 00:00:00' COMMENT '最后进入系统的时间',
  `bossSilverSum` int(11) NOT NULL DEFAULT '0' COMMENT '当天攻击boss获得的银币总数(每日清空)',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of playerLoopInfo
-- ----------------------------

-- ----------------------------
-- Table structure for `playerMagicTask`
-- ----------------------------
DROP TABLE IF EXISTS `playerMagicTask`;
CREATE TABLE `playerMagicTask` (
  `id` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT '主键id',
  `playerId` bigint(20) NOT NULL COMMENT '玩家id',
  `taskContent` text COLLATE utf8_unicode_ci COMMENT '任务进度信息',
  `taskId` int(11) DEFAULT '0' COMMENT '基础任务id',
  `taskStatus` tinyint(4) DEFAULT '2' COMMENT '任务状态',
  PRIMARY KEY (`id`),
  KEY `playerMagicTask_idx_playerId` (`playerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerMagicTask
-- ----------------------------

-- ----------------------------
-- Table structure for `playerMail`
-- ----------------------------
DROP TABLE IF EXISTS `playerMail`;
CREATE TABLE `playerMail` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `addtion` longtext COLLATE utf8_unicode_ci COMMENT '附件',
  `content` longtext COLLATE utf8_unicode_ci COMMENT '内容',
  `createTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '创建时间',
  `endTime` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '有效时间',
  `hadAddtion` tinyint(4) NOT NULL COMMENT '是否有附件',
  `jsonKeyValues` varchar(1000) COLLATE utf8_unicode_ci NOT NULL COMMENT '邮件模板里面用到的键值对',
  `mailId` bigint(20) NOT NULL COMMENT '对应的群体邮件id',
  `mailTemplateId` int(11) NOT NULL COMMENT '邮件模板id',
  `senderId` bigint(20) NOT NULL COMMENT '发送者id',
  `senderName` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '发送者名称',
  `status` tinyint(4) NOT NULL COMMENT '邮件状态',
  `targetId` bigint(20) NOT NULL COMMENT '接收者id',
  `title` longtext COLLATE utf8_unicode_ci COMMENT '标题',
  `type` smallint(6) NOT NULL COMMENT '邮件类型',
  PRIMARY KEY (`id`),
  KEY `player_mail_index` (`targetId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerMail
-- ----------------------------

-- ----------------------------
-- Table structure for `playerMailBookMark`
-- ----------------------------
DROP TABLE IF EXISTS `playerMailBookMark`;
CREATE TABLE `playerMailBookMark` (
  `id` bigint(20) NOT NULL,
  `simpleAttributes` text COLLATE utf8_unicode_ci COMMENT '自定义属性',
  `lastOpenMailTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后打开邮件的时间',
  `lastReceivedMailTime` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '最后接收邮件的时间',
  `lastUpdateTime` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '最后更新时间',
  `sentAmount` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerMailBookMark
-- ----------------------------

-- ----------------------------
-- Table structure for `playerManpass`
-- ----------------------------
DROP TABLE IF EXISTS `playerManpass`;
CREATE TABLE `playerManpass` (
  `playerId` bigint(20) NOT NULL COMMENT '角色id',
  `areaId` int(11) DEFAULT '0' COMMENT '当前副本id',
  `buyCount` tinyint(4) DEFAULT '0' COMMENT '当天已购买次数',
  `challengeCount` tinyint(4) DEFAULT '0' COMMENT '当天已挑战次数',
  `challengeRewards` text COLLATE utf8_unicode_ci COMMENT '已领取的挑战奖励id(json串)',
  `challengeTime` bigint(20) DEFAULT '0' COMMENT '最近一次挑战时间',
  `lastScore` int(11) DEFAULT '0' COMMENT '最近一次副本积分',
  `preLeftBuyCount` tinyint(4) DEFAULT '0' COMMENT '当天之前剩余的已购买次数',
  `rankRewardId` int(11) DEFAULT '0' COMMENT '积分排名奖励id',
  `rankStatus` tinyint(4) DEFAULT '0' COMMENT '积分排名奖励状态, 0-未领取  1-已领取',
  `refreshTime` datetime DEFAULT NULL COMMENT '上次重置时间',
  `score` int(11) DEFAULT '0' COMMENT '当前累计积分',
  `scoreRank` int(11) DEFAULT '0' COMMENT '当前积分排名',
  `topArmyId` int(11) DEFAULT '0' COMMENT '打过的历史最高部队id',
  PRIMARY KEY (`playerId`),
  KEY `playerManpass_idx_areaId` (`areaId`),
  KEY `playerManpass_idx_refreshTime` (`refreshTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerManpass
-- ----------------------------

-- ----------------------------
-- Table structure for `playerMarket`
-- ----------------------------
DROP TABLE IF EXISTS `playerMarket`;
CREATE TABLE `playerMarket` (
  `id` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '主键',
  `buyTime` datetime DEFAULT '2013-01-01 00:00:00' COMMENT '购买物品的时间',
  `everydayAmount` int(11) DEFAULT '0' COMMENT '每日购买数量',
  `totalAmount` bigint(20) DEFAULT '0' COMMENT '总购买数量',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerMarket
-- ----------------------------

-- ----------------------------
-- Table structure for `playerNewArmy`
-- ----------------------------
DROP TABLE IF EXISTS `playerNewArmy`;
CREATE TABLE `playerNewArmy` (
  `id` bigint(20) NOT NULL COMMENT '玩家id',
  `curArmyId` int(11) DEFAULT '-1' COMMENT '当前据点军队进度ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerNewArmy
-- ----------------------------

-- ----------------------------
-- Table structure for `playerNewCreamInfo`
-- ----------------------------
DROP TABLE IF EXISTS `playerNewCreamInfo`;
CREATE TABLE `playerNewCreamInfo` (
  `id` bigint(20) NOT NULL COMMENT '玩家id',
  `simpleAttributes` text COLLATE utf8_unicode_ci COMMENT '自定义属性',
  `armyId` int(11) DEFAULT '-1' COMMENT '当前据点军队进度ID',
  `chapterStarReward` text COLLATE utf8_unicode_ci COMMENT '章节通关奖励 领取记录',
  `curArmyId` int(11) DEFAULT '-1' COMMENT '当前据点军队进度ID',
  `incomeDate` datetime DEFAULT '2012-01-01 00:00:00' COMMENT '收益次数最后计算时间',
  `lastMissionId` int(11) DEFAULT '-1' COMMENT '最近通关的最大据点ID',
  `lastStar` int(11) DEFAULT '-1' COMMENT '上一次战斗的星级信息',
  `missionId` int(11) DEFAULT '-1' COMMENT '当前据点进度(保存最高已进入的据点id)',
  `missionResetTimes` text COLLATE utf8_unicode_ci COMMENT '单个据点重置次数记录',
  `missionStar` text COLLATE utf8_unicode_ci COMMENT '据点星级信息',
  `noticeResult` text COLLATE utf8_unicode_ci COMMENT '当前累计的奖励串结果',
  `reward` tinyint(3) DEFAULT '0' COMMENT '当前累计的奖励串结果是否可以领取(据点通关)',
  `rewardResult` text COLLATE utf8_unicode_ci COMMENT '当前累计的奖励串结果',
  `shopInfo` text COLLATE utf8_unicode_ci COMMENT '精英副本商店兑换限制(每日) ',
  `shopInfoRecord` text COLLATE utf8_unicode_ci COMMENT '精英副本商店兑换限制 (永久) ',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerNewCreamInfo
-- ----------------------------

-- ----------------------------
-- Table structure for `playerPack`
-- ----------------------------
DROP TABLE IF EXISTS `playerPack`;
CREATE TABLE `playerPack` (
  `id` bigint(20) NOT NULL COMMENT '玩家id',
  `buyCellTime` bigint(20) DEFAULT '0' COMMENT '已经购买的背包格子时间',
  `jsonSelledGoodIds` varchar(500) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '已经出售的物品',
  `openedAmount` int(11) DEFAULT '0' COMMENT '已经开启的格子',
  `openedIndex` int(11) DEFAULT '1' COMMENT '已经解锁的格子位置',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerPack
-- ----------------------------

-- ----------------------------
-- Table structure for `playerPub`
-- ----------------------------
DROP TABLE IF EXISTS `playerPub`;
CREATE TABLE `playerPub` (
  `id` bigint(20) NOT NULL COMMENT '玩家id',
  `hirings` text COLLATE utf8_unicode_ci COMMENT '已经招贤过的基础数据id json数组',
  `selectCamp` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  `first` int(3) DEFAULT '1' COMMENT '是否第一次使用十连抽',
  `luckyValue` int(8) DEFAULT '0' COMMENT '将灵值（幸运值，给予运气差的玩家有抽到高星武将的保底）',
  `firstSelCamp` int(2) DEFAULT '1' COMMENT '是否第一次选择阵营',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerPub
-- ----------------------------

-- ----------------------------
-- Table structure for `playerRelation`
-- ----------------------------
DROP TABLE IF EXISTS `playerRelation`;
CREATE TABLE `playerRelation` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `closeLv` int(11) DEFAULT '0' COMMENT '亲密度等级',
  `closeValue` int(11) DEFAULT '0' COMMENT '亲密度',
  `otherUserId` bigint(20) DEFAULT NULL COMMENT '关系对方的用户id',
  `state` int(11) DEFAULT '0' COMMENT '改关系属于何种关系 0=默认 1=好友 2=陌生人',
  `userId` bigint(20) DEFAULT NULL COMMENT '该关系的持有人 用户id',
  PRIMARY KEY (`id`),
  KEY `relationShip_index1` (`userId`),
  KEY `relationShip_index2` (`otherUserId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerRelation
-- ----------------------------

-- ----------------------------
-- Table structure for `playerRelationBless`
-- ----------------------------
DROP TABLE IF EXISTS `playerRelationBless`;
CREATE TABLE `playerRelationBless` (
  `id` bigint(20) NOT NULL COMMENT '玩家ID',
  `abilityJson` longtext COLLATE utf8_unicode_ci COMMENT '好友战斗力已领取json',
  `blessAbilityCount` int(11) NOT NULL COMMENT '今天祝福了多少次',
  `blessCount` int(11) NOT NULL COMMENT '今天祝福了多少次',
  `json` longtext COLLATE utf8_unicode_ci COMMENT '好友升级已领取json',
  `refreshDate` datetime DEFAULT '2012-01-01 00:00:00' COMMENT '刷新的日期 ',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerRelationBless
-- ----------------------------

-- ----------------------------
-- Table structure for `playerRevenue`
-- ----------------------------
DROP TABLE IF EXISTS `playerRevenue`;
CREATE TABLE `playerRevenue` (
  `id` bigint(20) NOT NULL COMMENT '玩家id',
  `foodsCDTime` datetime DEFAULT '2013-01-01 00:00:00' COMMENT '征收粮草冷却到期时间',
  `foodsTimes` int(11) NOT NULL COMMENT '粮草征收次数',
  `fullFoodsCDTime` datetime DEFAULT '2013-01-01 00:00:00' COMMENT '征收粮草冷冻到期时间',
  `fullSilverCDTime` datetime DEFAULT '2013-01-01 00:00:00' COMMENT '征收银元冷冻到期时间',
  `lastPressReceiveFoodsDay` datetime DEFAULT '2013-01-01 00:00:00' COMMENT '最后强征粮草的日期',
  `lastPressReceiveSilverDay` datetime DEFAULT '2013-01-01 00:00:00' COMMENT '最后强征银元的日期',
  `lastReceiveFoodsDay` datetime DEFAULT '2013-01-01 00:00:00' COMMENT '最后征收粮草的日期',
  `lastReceiveSilverDay` datetime DEFAULT '2013-01-01 00:00:00' COMMENT '最后征收银元的日期',
  `pressFoodsTimes` int(11) NOT NULL COMMENT '强征粮草次数',
  `pressSilverTimes` int(11) NOT NULL COMMENT '强征银元次数',
  `silverCDTime` datetime DEFAULT '2013-01-01 00:00:00' COMMENT '征收银元冷却到期时间',
  `silverTimes` int(11) NOT NULL COMMENT '银元征收次数',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerRevenue
-- ----------------------------

-- ----------------------------
-- Table structure for `playerShopInfo`
-- ----------------------------
DROP TABLE IF EXISTS `playerShopInfo`;
CREATE TABLE `playerShopInfo` (
  `id` bigint(20) NOT NULL COMMENT '玩家ID',
  `dayServerLimit` text COLLATE utf8_unicode_ci COMMENT '全服每日限量',
  `foodsTime` int(11) DEFAULT '0' COMMENT '粮食购买次数',
  `incomeDate` datetime DEFAULT '2012-01-01 00:00:00' COMMENT '每日限量最后计算时间',
  `serverLimit` text COLLATE utf8_unicode_ci COMMENT '全服总限量',
  `silverTime` int(11) DEFAULT '0' COMMENT '银两购买次数',
  `soulTime` int(11) DEFAULT '0' COMMENT '武将经验购买次数',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerShopInfo
-- ----------------------------

-- ----------------------------
-- Table structure for `playerSkillInfo`
-- ----------------------------
DROP TABLE IF EXISTS `playerSkillInfo`;
CREATE TABLE `playerSkillInfo` (
  `id` bigint(20) NOT NULL COMMENT 'id',
  `rewardTime` datetime DEFAULT '2012-01-01 00:00:00' COMMENT '免费次数结算时间',
  `times` tinyint(3) DEFAULT '0' COMMENT '免费次数',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerSkillInfo
-- ----------------------------

-- ----------------------------
-- Table structure for `playerSlaveInfo`
-- ----------------------------
DROP TABLE IF EXISTS `playerSlaveInfo`;
CREATE TABLE `playerSlaveInfo` (
  `id` bigint(20) NOT NULL COMMENT '玩家id',
  `simpleAttributes` text COLLATE utf8_unicode_ci COMMENT '自定义属性',
  `afflictDate` datetime DEFAULT '2012-01-01 00:00:00' COMMENT '折磨冷却',
  `appeaseDate` datetime DEFAULT '2012-01-01 00:00:00' COMMENT '安抚冷却时间 ',
  `army` text COLLATE utf8_unicode_ci COMMENT '夺仆之敌 列表',
  `beSaveTimes` int(11) DEFAULT '0' COMMENT '当前剩余解救次数',
  `beSlaveDate` datetime DEFAULT NULL COMMENT '成为奴隶的时间',
  `beTouchTimes` int(11) DEFAULT '0' COMMENT '当前剩余奴隶互动次数',
  `buyCountTimes` int(11) DEFAULT '0' COMMENT '当天购买总次数',
  `buyTime` bigint(20) DEFAULT '0' COMMENT '当天压榨已购买时间',
  `buyTimes` int(11) DEFAULT '0' COMMENT '当前剩余购买抓捕次数',
  `curSliver` int(11) DEFAULT '0' COMMENT '做为主人当前累计的银币',
  `curseDate` datetime DEFAULT '2012-01-01 00:00:00' COMMENT '诅咒冷却 ',
  `incomeDate` datetime DEFAULT '2012-01-01 00:00:00' COMMENT '收益次数最后计算时间',
  `loser` text COLLATE utf8_unicode_ci COMMENT '手下败将 列表',
  `masterId` bigint(20) DEFAULT NULL COMMENT '主人玩家id',
  `masterSliver` int(11) DEFAULT '0' COMMENT '做为主人当前已获得银币数量',
  `masterSliverDate` datetime DEFAULT '2012-01-01 00:00:00' COMMENT '做为主人最后一次获得银币时间 ',
  `pleaseDate` datetime DEFAULT '2012-01-01 00:00:00' COMMENT '讨好冷却',
  `protectOutDate` datetime DEFAULT NULL COMMENT '保护时间到期时间',
  `saveTimes` int(11) DEFAULT '0' COMMENT '当前剩余解救次数',
  `slaveDate` datetime DEFAULT NULL COMMENT '成为奴隶时的时间',
  `slaveLog` text COLLATE utf8_unicode_ci COMMENT '奴隶日志',
  `slaveOutDate` datetime DEFAULT NULL COMMENT '奴隶身份过期时间 ',
  `slavePlayerLevel` int(11) DEFAULT '0' COMMENT '成为奴隶时候的等级',
  `slaveWorkDate` datetime DEFAULT NULL COMMENT '成为奴隶时的时间',
  `sliver` int(11) DEFAULT '0' COMMENT '干活过0点前一天累计银币',
  `status` int(3) DEFAULT '0' COMMENT '当前身份 0-自由身 1-主人 2-奴隶',
  `times` int(11) DEFAULT '0' COMMENT '当前剩余抓捕次数',
  `touchTimes` int(11) DEFAULT '0' COMMENT '当前剩余互动次数',
  PRIMARY KEY (`id`),
  KEY `slave_masterId_index` (`masterId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerSlaveInfo
-- ----------------------------

-- ----------------------------
-- Table structure for `playerSoldier`
-- ----------------------------
DROP TABLE IF EXISTS `playerSoldier`;
CREATE TABLE `playerSoldier` (
  `id` bigint(20) NOT NULL COMMENT '玩家id',
  `amount` int(11) DEFAULT '0' COMMENT '空闲兵的数量',
  `star` int(11) NOT NULL COMMENT '兵阶',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerSoldier
-- ----------------------------

-- ----------------------------
-- Table structure for `playerTask`
-- ----------------------------
DROP TABLE IF EXISTS `playerTask`;
CREATE TABLE `playerTask` (
  `id` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT '主键id',
  `playerId` bigint(20) NOT NULL COMMENT '玩家id',
  `taskContent` text COLLATE utf8_unicode_ci COMMENT '任务进度信息',
  `taskId` int(11) DEFAULT '0' COMMENT '基础任务id',
  `taskStatus` tinyint(4) DEFAULT '2' COMMENT '任务状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerTask
-- ----------------------------

-- ----------------------------
-- Table structure for `playerTaskHis`
-- ----------------------------
DROP TABLE IF EXISTS `playerTaskHis`;
CREATE TABLE `playerTaskHis` (
  `playerId` bigint(20) NOT NULL COMMENT '玩家id',
  `tasks` longtext COLLATE utf8_unicode_ci COMMENT '已领取完奖励的任务id信息',
  PRIMARY KEY (`playerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerTaskHis
-- ----------------------------

-- ----------------------------
-- Table structure for `playerTech`
-- ----------------------------
DROP TABLE IF EXISTS `playerTech`;
CREATE TABLE `playerTech` (
  `id` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT 'id',
  `level` int(11) DEFAULT '0' COMMENT '科技等级',
  `playerId` bigint(20) NOT NULL COMMENT '玩家id',
  `techId` int(11) NOT NULL COMMENT '科技id',
  `techType` int(11) NOT NULL COMMENT '科技类型',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerTech
-- ----------------------------

-- ----------------------------
-- Table structure for `playerVipInfo`
-- ----------------------------
DROP TABLE IF EXISTS `playerVipInfo`;
CREATE TABLE `playerVipInfo` (
  `id` bigint(20) NOT NULL COMMENT '玩家id',
  `shopInfoRecord` text COLLATE utf8_unicode_ci COMMENT 'VIP购买次数',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerVipInfo
-- ----------------------------

-- ----------------------------
-- Table structure for `playerWishEvent`
-- ----------------------------
DROP TABLE IF EXISTS `playerWishEvent`;
CREATE TABLE `playerWishEvent` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `eventAmount` int(11) NOT NULL COMMENT '累积的官府事件数量',
  `eventId` int(11) NOT NULL COMMENT '刷新出来的事件id',
  `eventStar` tinyint(4) NOT NULL COMMENT '事件的星级',
  `firstFullStar` tinyint(4) NOT NULL COMMENT '是否已经首次刷新满星（0-还没 1-已经满星过）',
  `freeRefreshTimes` int(11) NOT NULL COMMENT '已经使用的免费刷新次数',
  `lastEventTime` datetime DEFAULT '2013-01-01 00:00:00' COMMENT '最后发生官府事件的时间',
  `lastRefreshTime` datetime DEFAULT '2013-01-01 00:00:00' COMMENT '最后刷新事件的时间',
  `starAmount` int(11) NOT NULL COMMENT '民心数量',
  `starRewardId` int(11) NOT NULL COMMENT '已经领取的民心奖励id',
  `times` int(11) NOT NULL COMMENT '已经处理事件的次数',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of playerWishEvent
-- ----------------------------

-- ----------------------------
-- Table structure for `plunderMirror`
-- ----------------------------
DROP TABLE IF EXISTS `plunderMirror`;
CREATE TABLE `plunderMirror` (
  `id` bigint(20) NOT NULL COMMENT '主键id',
  `ability` bigint(20) NOT NULL COMMENT '玩家战斗力',
  `battleCdTime` bigint(20) NOT NULL COMMENT '战斗CD时间',
  `battleMaxTime` bigint(20) NOT NULL COMMENT '战斗CD时间已满',
  `boxId` int(11) DEFAULT '0' COMMENT '当前领取的宝箱ID',
  `buyCountTimes` int(11) DEFAULT '0' COMMENT '当天购买总次数',
  `buyTimes` int(11) DEFAULT '0' COMMENT '当前剩余购买次数',
  `enemy` text COLLATE utf8_unicode_ci COMMENT '仇人列表',
  `incomeDate` datetime DEFAULT '2012-01-01 00:00:00' COMMENT '收益次数最后计算时间',
  `inspireCdTime` bigint(20) NOT NULL COMMENT '鼓舞的CD时间',
  `inspireTime` int(11) DEFAULT '0' COMMENT '当前鼓舞次数',
  `level` int(11) NOT NULL COMMENT '玩家等级',
  `lineupJsonString` text COLLATE utf8_unicode_ci COMMENT '阵形镜像数据',
  `mirrorJsonString` text COLLATE utf8_unicode_ci COMMENT '战斗镜像数据',
  `nextProtectCdTime` bigint(20) NOT NULL COMMENT '下一次可使用保护令的CD时间',
  `plunderLog` text COLLATE utf8_unicode_ci COMMENT '掠夺日志',
  `plunderPlayer` text COLLATE utf8_unicode_ci COMMENT '掠夺列表数据',
  `plunderTime` int(11) DEFAULT '0' COMMENT '当前被掠夺次数',
  `point` int(11) DEFAULT '0' COMMENT '当前积分',
  `protectCdTime` bigint(20) NOT NULL COMMENT '保护CD时间',
  `times` int(11) DEFAULT '0' COMMENT '当前剩余次数',  
  `totemJsonString` text COLLATE utf8_unicode_ci COMMENT '图腾镜像数据',
  `horseJsonString` text COLLATE utf8_unicode_ci COMMENT '坐骑镜像数据',
  `netherwingJsonString` text COLLATE utf8_unicode_ci COMMENT '灵翼镜像数据',
  `junWeiLevel` int(11) DEFAULT '0' COMMENT '军威的等级 ',
  PRIMARY KEY (`id`),
  KEY `battleFeastMirror_index` (`level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of plunderMirror
-- ----------------------------

-- ----------------------------
-- Table structure for `rankingList`
-- ----------------------------
DROP TABLE IF EXISTS `rankingList`;
CREATE TABLE `rankingList` (
  `id` int(11) NOT NULL DEFAULT '0' COMMENT '排行榜ID',
  `rankDate` datetime DEFAULT '2013-01-01 00:00:00' COMMENT '排名时间 ',
  `rankInfo` longtext COLLATE utf8_unicode_ci COMMENT '排名信息列表 ',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of rankingList
-- ----------------------------

-- ----------------------------
-- Table structure for `rankingListActivity`
-- ----------------------------
DROP TABLE IF EXISTS `rankingListActivity`;
CREATE TABLE `rankingListActivity` (
  `id` int(11) NOT NULL DEFAULT '0' COMMENT '排行榜ID',
  `rankDate` datetime DEFAULT '2013-01-01 00:00:00' COMMENT '排名时间 ',
  `rankInfo` longtext COLLATE utf8_unicode_ci COMMENT '排名信息列表 ',
  `status` int(11) DEFAULT '0' COMMENT '活动是否已经结束',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of rankingListActivity
-- ----------------------------

-- ----------------------------
-- Table structure for `serverGift`
-- ----------------------------
DROP TABLE IF EXISTS `serverGift`;
CREATE TABLE `serverGift` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `endDate` datetime DEFAULT NULL COMMENT '礼包领取结束时间 ',
  `giftNo` bigint(20) NOT NULL COMMENT '礼包编号 ',
  `reward` text COLLATE utf8_unicode_ci COMMENT '奖励串',
  `startDate` datetime DEFAULT NULL COMMENT '礼包领取开始时间 ',
  `tip` text COLLATE utf8_unicode_ci COMMENT '备注',
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '标题',
  `levelLimit` int(11) DEFAULT '0' COMMENT '领取礼包等级限制',
  `delFlag` int(11) DEFAULT '0' COMMENT '是否删除 0-未删除 1-已删除',
  PRIMARY KEY (`id`),
  KEY `servergift_index1` (`endDate`),
  KEY `servergift_index` (`startDate`),
  KEY `servergift_index2` (`giftNo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of serverGift
-- ----------------------------

-- ----------------------------
-- Table structure for `shopInfo`
-- ----------------------------
DROP TABLE IF EXISTS `shopInfo`;
CREATE TABLE `shopInfo` (
  `id` int(11) NOT NULL COMMENT 'id',
  `dayServerLimit` text COLLATE utf8_unicode_ci COMMENT '全服每日限量',
  `incomeDate` datetime DEFAULT '2012-01-01 00:00:00' COMMENT '每日限量最后计算时间',
  `serverLimit` text COLLATE utf8_unicode_ci COMMENT '全服总限量',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of shopInfo
-- ----------------------------

-- ----------------------------
-- Table structure for `userPub`
-- ----------------------------
DROP TABLE IF EXISTS `userPub`;
CREATE TABLE `userPub` (
  `playerId` bigint(20) NOT NULL COMMENT '玩家id',
  `heros` text COLLATE utf8_unicode_ci COMMENT '仓库里的武将卡信息',
  `hirings` text COLLATE utf8_unicode_ci COMMENT '已经招贤过的基础数据id json数组',
  `selectCamp` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`playerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of userPub
-- ----------------------------


-- ----------------------------
-- Table structure for `sqlMapping`
-- ----------------------------
DROP TABLE IF EXISTS `sqlMapping`;
CREATE TABLE `sqlMapping` (
  `id` int(11) NOT NULL,
  `info` varchar(1000) DEFAULT NULL,
  `queryType` int(11) DEFAULT NULL,
  `statement` varchar(5000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of sqlMapping
-- ----------------------------
INSERT INTO `sqlMapping` VALUES ('1', '查询消费额度1', '0', 'SELECT count(playerId) count, sum(money) money from (SELECT playerId, SUM(money) as money from consumeRecord WHERE addTime >= :$1 and addTime <= :$2 AND money >= :$3 AND money < :$4 GROUP BY playerId) as tmp');
INSERT INTO `sqlMapping` VALUES ('2', '查询消费额度2', '0', 'SELECT count(playerId) count, sum(money) money from (SELECT playerId, SUM(money) as money from consumeRecord WHERE addTime >= :$1 and addTime <= :$2 AND money >= :$3 GROUP BY playerId) as tmp');
INSERT INTO `sqlMapping` VALUES ('3', '查询新手指引步骤', '0', 'SELECT newerStep, count(DISTINCT id) count from player GROUP BY newerStep order by newerStep');
INSERT INTO `sqlMapping` VALUES ('4', '查询消费大户1', '0', 'SELECT b.playerId, a.playerName, a.level, a.vipLevel, b.times, b.money, a.userName from player a RIGHT JOIN (SELECT playerId, sum(times) times, sum(money) money from consumeRecord WHERE addTime >= :$1 and addTime <= :$2 AND money >= :$3 AND money < :$4 GROUP BY playerId) b on a.id = b.playerId order by b.money desc');
INSERT INTO `sqlMapping` VALUES ('5', '查询消费大户2', '0', 'SELECT b.playerId, a.playerName, a.level, a.vipLevel, b.times, b.money, a.userName from player a RIGHT JOIN (SELECT playerId, sum(times) times, sum(money) money from consumeRecord WHERE addTime >= :$1 and addTime <= :$2 AND money >= :$3 GROUP BY playerId) b on a.id = b.playerId order by b.money desc');
INSERT INTO `sqlMapping` VALUES ('6', '查询玩家等级分布', '0', 'SELECT level, count(id) count from player GROUP BY level');
INSERT INTO `sqlMapping` VALUES ('7', '查询玩家VIP分布', '0', 'SELECT vipLevel, count(id) count from player WHERE vipLevel > 0 and (vipEver = 1 or vipTime > NOW()) GROUP BY vipLevel');
INSERT INTO `sqlMapping` VALUES ('8', '查询金币留存', '0', 'SELECT count(id) count, sum(gold) gold from player WHERE gold > 0 ');
INSERT INTO `sqlMapping` VALUES ('9', '查询禁言玩家id列表', '0', 'SELECT id from player WHERE blockChat = 1');
INSERT INTO `sqlMapping` VALUES ('10', '查询某一等级的玩家人数', '1', 'SELECT count(id) count from player where level >= :$1');
INSERT INTO `sqlMapping` VALUES ('11', '查询玩家据点分布', '0', 'select lastMissionId,count(*) as playerNum from playerChapterInfo where lastMissionId != -1 and lastMissionId >= :$1 and lastMissionId <= :$2 group by lastMissionId order by lastMissionId');
INSERT INTO `sqlMapping` VALUES ('12', '查询金币留存分布', '0', 'SELECT count(id) count, sum(gold) gold from player WHERE gold > :$1 and gold <= :$2');
INSERT INTO `sqlMapping` VALUES ('13', '等级排行', '0', 'SELECT id, userName, playerName, `level`, silver, sex from player ORDER BY `level` desc');
INSERT INTO `sqlMapping` VALUES ('14', '银两排行', '0', 'SELECT id, userName, playerName, `level`, silver, sex from player ORDER BY silver desc');
INSERT INTO `sqlMapping` VALUES ('15', '查询人民币玩家等级分布', '0', 'SELECT level, count(id) count from player WHERE totalGold > :$1 GROUP BY level');
INSERT INTO `sqlMapping` VALUES ('16', '查询人民币玩家据点分布', '0', 'select lastMissionId, count(*) as playerNum from playerChapterInfo a where lastMissionId != -1 and lastMissionId >= :$1 and lastMissionId <= :$2 and EXISTS(SELECT id from player b WHERE totalGold > :$3 and a.id = b.id) group by lastMissionId order by lastMissionId');
INSERT INTO `sqlMapping` VALUES ('17', '查询某一天的登陆人数', '1', 'SELECT count(id) count from player WHERE TO_DAYS(registerTime) = TO_DAYS(:$1) and TO_DAYS(loginTime) = TO_DAYS(:$2)');
INSERT INTO `sqlMapping` VALUES ('18', '留存查询', '1', 'SELECT count(id) count from player WHERE TO_DAYS(registerTime) = TO_DAYS(:$1) and TO_DAYS(loginTime) >= TO_DAYS(:$2)');
INSERT INTO `sqlMapping` VALUES ('19', '查询注册人数', '1', 'SELECT count(id) count from player where TO_DAYS(registerTime) = TO_DAYS(:$1)');
INSERT INTO `sqlMapping` VALUES ('20', '武将星级统计', '0', 'select star, count(*) as heroAmount, count(distinct playerId) as playerAmount from playerHero group by star');
INSERT INTO `sqlMapping` VALUES ('21', '道具统计', '0', 'select itemId, sum(amount) as itemAmount, count(distinct playerId) as playerAmount from playerItem where sell = 0 group by itemId');
INSERT INTO `sqlMapping` VALUES ('22', '命签统计', '0', 'select divinationId, `level`, count(divinationId) as divinationAmount, count(distinct playerId) as playerAmount from playerDivination where state = 1 group by divinationId, `level`');
INSERT INTO `sqlMapping` VALUES ('23', '武将装备统计', '0', 'select equipId, count(equipId) as equipAmount, count(distinct playerId) as playerAmount from playerHeroEquip where sell = 0 group by equipId');
INSERT INTO `sqlMapping` VALUES ('24', '武将装备强化等级统计', '0', 'select strengthenLevel, count(strengthenLevel) as equipAmount, count(distinct playerId) as playerAmount from playerHeroEquip where sell = 0 group by strengthenLevel');
INSERT INTO `sqlMapping` VALUES ('25', '武将天赋等级统计', '0', 'select talentLevel, count(*) as heroAmount, count(distinct playerId) as playerAmount from playerHero group by talentLevel');
INSERT INTO `sqlMapping` VALUES ('26', '命签品质等级统计', '0', 'select divinationId, `level`, count(*) as divinationAmount, count(distinct playerId) as playerAmount from playerDivination where state = 1 group by divinationId, `level`');
INSERT INTO `sqlMapping` VALUES ('27', '充值玩家留存查询', '1', 'SELECT count(id) count from player a, (SELECT playerId, createTime from charges WHERE TO_DAYS(createTime) <= TO_DAYS(:$1) GROUP BY playerId having TO_DAYS(createTime) = TO_DAYS(:$2)) b WHERE a.id = b.playerId and TO_DAYS(loginTime) >= TO_DAYS(:$3)');
INSERT INTO `sqlMapping` VALUES ('28', '查询充值', '0', 'SELECT date_format(registerTime,\'%Y-%m-%d\') as regeditTime, DATEDIFF(createTime, registerTime) as chargeTime, count(DISTINCT b.playerId) as chargeAmount, sum(b.money) as money from player a, charges b \r\nWHERE a.id = b.playerId and TO_DAYS(registerTime) = TO_DAYS(:$1) and DATEDIFF(createTime, registerTime) in (0, 1, 2, 3, 4, 5, 6, 7, 14, 30) GROUP BY regeditTime, chargeTime');
INSERT INTO `sqlMapping` VALUES ('29', '宝石统计', '0', 'SELECT itemId, SUM(count) as itemCount, count(DISTINCT playerId) as playerCount from (\r\nselect playerId, slotItemId1 as itemId, 1 as count from playerHeroEquip where sell = 0 and slotItemId1 > 0\r\nunion all\r\nselect playerId, slotItemId2 as itemId, 1 as count from playerHeroEquip where sell = 0 and slotItemId2 > 0 \r\nunion all \r\nselect playerId, slotItemId3 as itemId, 1 as count from playerHeroEquip where sell = 0 and slotItemId3 > 0 \r\nunion all \r\nselect playerId, slotItemId4 as itemId, 1 as count from playerHeroEquip where sell = 0 and slotItemId4 > 0\r\nunion all\r\nSELECT playerId, itemId, amount from playerItem WHERE sell = 0\r\n) tmp \r\nGROUP BY itemId');
INSERT INTO `sqlMapping` VALUES ('30', '查询当天的登陆人数', '1', 'SELECT count(id) count from player WHERE TO_DAYS(loginTime) = TO_DAYS(NOW())');
INSERT INTO `sqlMapping` VALUES ('31', '查询当月的登陆人数', '1', 'SELECT count(id) count from player WHERE EXTRACT(YEAR_MONTH FROM loginTime) = EXTRACT(YEAR_MONTH FROM NOW())');
INSERT INTO `sqlMapping` VALUES ('32', '龙将星级统计', '0', 'select heroType, star, rank, count(*) as heroAmount, count(distinct playerId) as playerAmount from playerHero group by heroType, star, rank');
INSERT INTO `sqlMapping` VALUES ('33', '武将主动技能统计', '0', 'select activeSkillLevel, count(*) as amount, count(distinct playerId) as playerAmount from heroSkills group by activeSkillLevel');
INSERT INTO `sqlMapping` VALUES ('34', '图腾阶级统计', '0', 'select grade, count(grade) as totemAmount from playerTotem group by grade');
INSERT INTO `sqlMapping` VALUES ('35', '查询当天在线时长', '1', 'SELECT count(DISTINCT id) count from player WHERE TO_DAYS(loginTime) = TO_DAYS(NOW()) and todayOnlineTime > :$1 and todayOnlineTime <= :$2');
INSERT INTO `sqlMapping` VALUES ('36', '查询最近的金币留存', '0', 'SELECT count(id) count, sum(gold) gold from player WHERE gold > 0 and TO_DAYS(loginTime) >= TO_DAYS(:$1)');
INSERT INTO `sqlMapping` VALUES ('37', '查询当天通关所有据点的人数，按据点分组', '0', 'SELECT areaId, count(id) breakPlayers from playerTower WHERE TO_DAYS(breakTime) = TO_DAYS(:$1) group by areaId');
INSERT INTO `sqlMapping` VALUES ('38', '精彩活动参与人数统计', '1', 'SELECT count(DISTINCT playerId) as count from playerActivityTask WHERE taskStatus >=3 and taskId = :$1 and rewardTime >= :$2 and rewardTime <= :$3');
INSERT INTO `sqlMapping` VALUES ('39', '特惠商店参与人数统计', '0', 'SELECT date_format(buyTime,\'%Y-%m-%d\') as statTime, COUNT(DISTINCT id) as count FROM playerOneYuanShopInfo WHERE buyTime >= :$1 AND buyTime <= :$2 GROUP BY statTime');
INSERT INTO `sqlMapping` VALUES ('40', '自定义活动参与人数统计', '1', 'SELECT count(DISTINCT playerId) as count from playerCustomTask WHERE taskStatus >=3 and taskId = :$1');
INSERT INTO `sqlMapping` VALUES ('41', '练兵等级统计', '0', 'SELECT `level`, count(*) as amount from playerTraining GROUP BY `level`');
INSERT INTO `sqlMapping` VALUES ('42', '百服活动参与人数统计', '1', 'SELECT count(id) as count from playerHundredServerGift WHERE activityId = :$1 and INSTR(simpleAttributes, :$2) > 0');
INSERT INTO `sqlMapping` VALUES ('43', '精炼装备统计', '0', 'SELECT enhanceTimes, count(DISTINCT id) as count from playerHeroEquip WHERE playerId in (SELECT id from player WHERE DATEDIFF(NOW(), loginTime) <= :$1) GROUP BY enhanceTimes');
INSERT INTO `sqlMapping` VALUES ('44', '查询玩家等级分布（活跃筛选）', '0', 'SELECT level, count(id) count from player WHERE DATEDIFF(NOW(), loginTime) <= :$1 GROUP BY level');
INSERT INTO `sqlMapping` VALUES ('45', '查询玩家VIP分布（活跃筛选）', '0', 'SELECT vipLevel, count(id) count from player WHERE vipLevel > 0 and (vipEver = 1 or vipTime > NOW()) and DATEDIFF(NOW(), loginTime) <= :$1 GROUP BY vipLevel');
INSERT INTO `sqlMapping` VALUES ('46', '查询新手分布（活跃筛选）', '0', 'SELECT newerStep, count(DISTINCT id) count from player where DATEDIFF(NOW(), loginTime) <= :$1 GROUP BY newerStep order by newerStep');
INSERT INTO `sqlMapping` VALUES ('47', '查询玩家据点分布（活跃筛选）', '0', 'select lastMissionId,count(*) as playerNum from playerChapterInfo a, player b where lastMissionId != -1 and lastMissionId >= :$1 and lastMissionId <= :$2 and a.id = b.id and DATEDIFF(NOW(), loginTime) <= :$3 group by lastMissionId order by lastMissionId');
INSERT INTO `sqlMapping` VALUES ('48', '武将星级统计（活跃筛选）', '0', 'select star, count(*) as heroAmount, count(distinct playerId) as playerAmount from playerHero a, player b where a.playerId = b.id and DATEDIFF(NOW(), loginTime) <= :$1 group by star');
INSERT INTO `sqlMapping` VALUES ('49', '武将天赋等级统计（活跃筛选）', '0', 'select talentLevel, count(*) as heroAmount, count(distinct playerId) as playerAmount from playerHero a, player b where a.playerId = b.id and DATEDIFF(NOW(), loginTime) <= :$1 group by talentLevel');
INSERT INTO `sqlMapping` VALUES ('50', '武将装备统计（活跃筛选）', '0', 'select equipId, count(equipId) as equipAmount, count(distinct playerId) as playerAmount from playerHeroEquip a, player b where sell = 0 and DATEDIFF(NOW(), loginTime) <= :$1 group by equipId');
INSERT INTO `sqlMapping` VALUES ('51', '命签品质等级统计（活跃筛选）', '0', 'select divinationId, a.`level`, count(*) as divinationAmount, count(distinct playerId) as playerAmount from playerDivination a, player b where state = 1 and DATEDIFF(NOW(), loginTime) <= :$1 group by divinationId, a.`level`');
-- ----------------------------
-- 单人副本排行榜
-- ----------------------------
DROP TABLE IF EXISTS `chapterRankInfo`;
CREATE TABLE `chapterRankInfo` (
  `id` int(11) NOT NULL COMMENT 'id',
  `chapterRankInfo` text COLLATE utf8_unicode_ci COMMENT '排行信息',
  `maxChapterId` int(11) NOT NULL COMMENT '排行最远的据点ID',
  `minChapterId` int(11) NOT NULL COMMENT '排行最近的据点ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- ----------------------------
-- 个人商城赠送礼包
-- ----------------------------
DROP TABLE IF EXISTS `playerPresentInfo`;
CREATE TABLE `playerPresentInfo` (
  `id` bigint(20) NOT NULL COMMENT '主键ID',
  `otherUserId` bigint(20) DEFAULT NULL COMMENT '赠送者的用户ID',
  `presentTime` datetime DEFAULT '2013-01-01 00:00:00' COMMENT '赠送时间',
  `shopCount` int(11) DEFAULT '0' COMMENT '商品数量',
  `shopId` int(11) DEFAULT '0' COMMENT '商品信息',
  `userId` bigint(20) DEFAULT NULL COMMENT '用户id',
  PRIMARY KEY (`id`),
  KEY `playerPresentInfo_index1` (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- ----------------------------
-- 跑环地图
-- ----------------------------
CREATE TABLE `playerLoopMap` (
  `id` int(11) NOT NULL,
  `loopSceneMap` longtext COLLATE utf8_unicode_ci COMMENT '场景地图',
  `scenemapList` longtext COLLATE utf8_unicode_ci  COMMENT '格子-事件',
  `todayLoginTime` datetime NOT NULL DEFAULT '2012-01-01 00:00:00'COMMENT '创建时间', 
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8  COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `playertreasure`
-- ----------------------------
DROP TABLE IF EXISTS `playerTreasure`;
CREATE TABLE `playerTreasure` (
  `playerId` bigint(20) NOT NULL COMMENT '角色id',
  `actStatus` tinyint(3) DEFAULT '0' COMMENT '活动状态, 0-关闭  1-开启',
  `openActTime` datetime DEFAULT NULL COMMENT '开启活动时间',
  `treasureInfo` longtext COLLATE utf8_unicode_ci COMMENT '参加该活动的玩家摸金信息',
  PRIMARY KEY (`playerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `playerRedVip`
-- ----------------------------
DROP TABLE IF EXISTS `playerRedVip`;
CREATE TABLE `playerRedVip` (
  `playerId` bigint(20) NOT NULL COMMENT '角色id',
  `dailyGiftTime` datetime DEFAULT NULL COMMENT '领取每日礼包的时间',
  `level` tinyint(3) DEFAULT '0' COMMENT 'vip等级',
  `levelGifts` text COLLATE utf8_unicode_ci COMMENT '已领取的等级礼包json串',
  `status` tinyint(2) DEFAULT '0' COMMENT 'vip状态：0-未激活 1-激活',
  `vipType` tinyint(2) DEFAULT '0' COMMENT 'vip类型：0-月付 1-年付',
  `yearGiftStatus` tinyint(2) DEFAULT '0' COMMENT '年费礼包领取状态：0-未领取  1-领取',
  PRIMARY KEY (`playerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `playerServerActivityTaskStatus`
-- ----------------------------
DROP TABLE IF EXISTS `playerServerActivityTaskStatus`;
CREATE TABLE `playerServerActivityTaskStatus` (
  `id` varchar(255) NOT NULL COMMENT '主键id',
  `activityId` int(11) NOT NULL COMMENT '活动ID',
  `playerId` bigint(20) NOT NULL COMMENT '玩家id',
  `receiveTime` datetime DEFAULT NULL COMMENT '接受任务时间',
  `receiveTaskTime` bigint(20) DEFAULT '0' COMMENT '接受任务的时间',
  `receivedReward1` int(11) DEFAULT '0' COMMENT '已经领取奖励1的次数',
  `receivedReward2` int(11) DEFAULT '0' COMMENT '已经领取奖励2的次数',
  `receivedReward3` int(11) DEFAULT '0' COMMENT '已经领取奖励3的次数',
  `receivedReward4` int(11) DEFAULT '0' COMMENT '已经领取奖励4的次数',
  `taskId` int(11) NOT NULL COMMENT '任务ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `playerVipServerActivityGiftStatus`
-- ----------------------------
DROP TABLE IF EXISTS `playerVipServerActivityGiftStatus`;
CREATE TABLE `playerVipServerActivityGiftStatus` (
  `id` bigint(20) NOT NULL COMMENT 'id',
  `playerId` bigint(20) NOT NULL COMMENT '玩家id',
  `receivedReward1` int(11) DEFAULT '0' COMMENT '已经领取奖励1的次数',
  `receivedReward2` int(11) DEFAULT '0' COMMENT '已经领取奖励2的次数',
  `receivedReward3` int(11) DEFAULT '0' COMMENT '已经领取奖励3的次数',
  `receivedReward4` int(11) DEFAULT '0' COMMENT '已经领取奖励4的次数',
  `vipGiftId` varchar(50) NOT NULL COMMENT 'VIP全服礼包ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `serverActivityTask`
-- ----------------------------
DROP TABLE IF EXISTS `serverActivityTask`;
CREATE TABLE `serverActivityTask` (
  `taskId` int(11) NOT NULL COMMENT '基础任务id',
  `finishedCount` int(11) NOT NULL COMMENT '已完成次数',
  `receiveTime` datetime DEFAULT NULL COMMENT '接受任务时间',
  `receiveTaskTime` bigint(20) DEFAULT '0' COMMENT '接受任务的时间',
  `taskContent` text COMMENT '任务进度信息',
  `taskStatus` tinyint(4) DEFAULT '2' COMMENT '任务状态',
  PRIMARY KEY (`taskId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `vipServerActivityGift`
-- ----------------------------
DROP TABLE IF EXISTS `vipServerActivityGift`;
CREATE TABLE `vipServerActivityGift` (
  `id` varchar(255) NOT NULL COMMENT '主键id',
  `activityId` int(11) NOT NULL COMMENT '活动ID',
  `giftId` int(11) NOT NULL COMMENT '礼包基础ID',
  `playerId` bigint(20) NOT NULL COMMENT '玩家id',
  `invalid` tinyint(4) DEFAULT '0' COMMENT '礼包是否失效0-否 1-是',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `playerOneTimeGift`
-- ----------------------------
DROP TABLE IF EXISTS `playerOneTimeGift`;
CREATE TABLE `playerOneTimeGift` (
  `playerId` bigint(20) NOT NULL COMMENT '角色id',
  `oneTimeGifts` text COLLATE utf8_unicode_ci COMMENT '一次性礼包领取信息',
  PRIMARY KEY (`playerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `playerVipFb`
-- ----------------------------
DROP TABLE IF EXISTS `playerVipFb`;
CREATE TABLE `playerVipFb` (
  `playerId` bigint(20) NOT NULL COMMENT '角色id',
  `fbInfo` text COLLATE utf8_unicode_ci COMMENT '攻打副本信息',
  PRIMARY KEY (`playerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `arenaDayRankReward`
-- ----------------------------
DROP TABLE IF EXISTS `arenaDayRankReward`;
CREATE TABLE `arenaDayRankReward` (
  `id` int(11) NOT NULL COMMENT '主键id',
  `dayRanks` longtext COLLATE utf8_unicode_ci COMMENT '天排行信息',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `Player360Privilege`
-- ----------------------------
DROP TABLE IF EXISTS `player360Privilege`;
CREATE TABLE `player360Privilege` (
  `playerId` bigint(20) NOT NULL COMMENT '角色id',
  `levelGifts` text COMMENT '已领取的等级礼包json串',
  `privLevel` int(3) DEFAULT '0' COMMENT '特权等级',
  PRIMARY KEY (`playerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `playerTotem`
-- ----------------------------
DROP TABLE IF EXISTS `playerTotem`;
CREATE TABLE `playerTotem` (
  `id` bigint(20) NOT NULL COMMENT '玩家id',
  `expireTime` bigint(20) DEFAULT '0' COMMENT '一阶属性失效时间',
  `grade` int(11) NOT NULL COMMENT '阶',
  `luckyValue` int(11) DEFAULT '0' COMMENT '幸运值',
  `maxProgress` int(11) DEFAULT '-1' COMMENT '升阶完成进度',
  `progress` int(11) DEFAULT '0' COMMENT '升阶进度',
  `soulAmount` int(11) DEFAULT '0' COMMENT '魂的数量',
  `spiritAmount` int(11) DEFAULT '0' COMMENT '灵的数量',
  `luckyValueTime` datetime DEFAULT '2013-01-01 00:00:00' COMMENT '获得祝福值的时间',
  `activityId` int(11) DEFAULT '0' COMMENT '活动id',
  `costItemAmount` int(11) DEFAULT '0' COMMENT '升阶消耗的道具数量',
  `hadReceiveReward` tinyint(4) DEFAULT '1' COMMENT '是否已经领取奖励',
  `showTotemId` int(11) NOT NULL DEFAULT 0 COMMENT '前端用作显示的图腾id',
  `simpleAttributes` text COLLATE utf8_unicode_ci COMMENT '自定义属性',
  `exp` int(11) DEFAULT '0' COMMENT '升阶经验值',
  `expBuff` int(11) DEFAULT '0' COMMENT '升阶经验值Buff',
  `expBuffExpireTime` bigint(20) DEFAULT '0' COMMENT '升阶经验值Buff到期时间',
  `expBuffItemId` int(11) DEFAULT '0' COMMENT '经验Buff道具id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `decisiveRecord`
-- ----------------------------
DROP TABLE IF EXISTS `decisiveRecord`;
CREATE TABLE `decisiveRecord` (
  `id` int(11) NOT NULL COMMENT 'id',
  `winArmyGroupId` bigint(20) NOT NULL COMMENT '获胜的军团id',
  `winTime` datetime DEFAULT '2013-01-01 00:00:00' COMMENT '获胜时间',
  `winTimes` int(11) NOT NULL COMMENT '连胜次数',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `playerDecisiveRecord`
-- ----------------------------
DROP TABLE IF EXISTS `playerDecisiveRecord`;
CREATE TABLE `playerDecisiveRecord` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `simpleAttributes` text COLLATE utf8_unicode_ci COMMENT '自定义属性',
  `defendMinute` int(11) DEFAULT '0' COMMENT '守城分钟数',
  `integral` int(11) DEFAULT '0' COMMENT '积分',
  `level` int(11) DEFAULT '0' COMMENT '等级段',
  `ranking` int(11) DEFAULT '-1' COMMENT '军团积分排名',
  `receivedActiveReward` tinyint(4) DEFAULT '1' COMMENT '是否已经领取活动奖励',
  `receivedArmyGroupReward` tinyint(4) DEFAULT '1' COMMENT '是否已经领取军团奖励',
  `remainHpRate` double DEFAULT '0' COMMENT '剩余血量比',
  `teamId` int(11) DEFAULT '0' COMMENT '队伍id',
  `win` tinyint(4) DEFAULT '0' COMMENT '是否胜利',
  `winArmyGroupId` bigint(20) DEFAULT '-1' COMMENT '夺城军团id',
  `winArmyGroupName` varchar(50) COLLATE utf8_unicode_ci DEFAULT '' COMMENT '夺城军团名称',
  `winDay` datetime DEFAULT '2013-01-01 00:00:00' COMMENT '胜利时间',
  `winTimes` int(11) DEFAULT '0' COMMENT '连胜次数',
  `activityRewardId` int(11) DEFAULT '0' COMMENT '活动奖励id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- ----------------------------
-- 军团劫粮信息实体 添加不同批次运粮管功能
-- ----------------------------
CREATE TABLE `plunderFoodInfo` (
  `id` bigint(20) NOT NULL COMMENT '主键id',
  `plunderFooderId` int(11) DEFAULT '0' COMMENT '运粮管批次ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `discountShop`
-- ----------------------------
DROP TABLE IF EXISTS `discountShop`;
CREATE TABLE `discountShop` (
  `id` tinyint(4) NOT NULL COMMENT '主键id',
  `actCount` int(11) DEFAULT '0' COMMENT '活动次数',
  `actTime` datetime DEFAULT NULL COMMENT '本次活动创建时间',
  `currMaterials` text COLLATE utf8_unicode_ci COMMENT '当前的物品信息',
  `loginPlayers` int(11) DEFAULT '0' COMMENT '昨日登录玩家数',
  `materialInfo` longtext COLLATE utf8_unicode_ci COMMENT '物品相关信息',
  `refreshTime` datetime DEFAULT NULL COMMENT '刷新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- ----------------------------
-- Table structure for `xunleiMember`
-- ----------------------------
DROP TABLE IF EXISTS `xunleiMember`;
CREATE TABLE `xunleiMember` (
  `playerId` bigint(20) NOT NULL COMMENT '角色id',
  `goldDailyGiftTime` datetime DEFAULT NULL COMMENT '领取每日礼包的时间',
  `goldlevel` tinyint(3) DEFAULT '0' COMMENT '金卡会员等级',
  `goldlevelGifts` text COLLATE utf8_unicode_ci COMMENT '已领取的等级礼包json串',
  `isgoldvip` tinyint(2) DEFAULT '0' COMMENT '是否为金卡vip：0表示非金卡，1表示金卡',
  `openType` tinyint(3) DEFAULT '0' COMMENT '开通会员的状态',
  `viplevel` tinyint(3) DEFAULT '0' COMMENT 'vip等级',
  `viptype` tinyint(2) DEFAULT '0' COMMENT '会员类型：0-非会员 1一般会员 2-金卡会员',
  PRIMARY KEY (`playerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `yyMember`
-- ----------------------------
DROP TABLE IF EXISTS `yyMember`;
CREATE TABLE `yyMember` (
  `playerId` bigint(20) NOT NULL COMMENT '角色id',
  `chargeType` tinyint(3) DEFAULT '-1' COMMENT '充值类型',
  `dailyGiftTime` datetime DEFAULT NULL COMMENT '领取每日礼包的时间',
  `endTime` datetime DEFAULT NULL COMMENT '会员过期时间',
  `seasonGiftState` tinyint(3) DEFAULT '0' COMMENT '季度礼包领取状态',
  `vipLevel` tinyint(3) DEFAULT '0' COMMENT 'vip等级',
  `yearGiftState` tinyint(3) DEFAULT '0' COMMENT '年度礼包领取状态',
  PRIMARY KEY (`playerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
-- ----------------------------
-- Table structure for `playerTreasureServerActivityGiftStatus`
-- ----------------------------
DROP TABLE IF EXISTS `playerTreasureServerActivityGiftStatus`;
CREATE TABLE `playerTreasureServerActivityGiftStatus` (
  `id` bigint(20) NOT NULL COMMENT 'id',
  `playerId` bigint(20) NOT NULL COMMENT '玩家id',
  `receivedReward1` int(11) DEFAULT '0' COMMENT '已经领取奖励1的次数',
  `receivedReward2` int(11) DEFAULT '0' COMMENT '已经领取奖励2的次数',
  `receivedReward3` int(11) DEFAULT '0' COMMENT '已经领取奖励3的次数',
  `receivedReward4` int(11) DEFAULT '0' COMMENT '已经领取奖励4的次数',
  `sendGiftTime` datetime NOT NULL COMMENT '赠送礼包时间',
  `treasureGiftId` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '摸金全服礼包ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `treasureServerActivityGift`
-- ----------------------------
DROP TABLE IF EXISTS `treasureServerActivityGift`;
CREATE TABLE `treasureServerActivityGift` (
  `id` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT '主键id',
  `activityId` int(11) NOT NULL COMMENT '活动ID',
  `giftId` int(11) NOT NULL COMMENT '礼包基础ID',
  `playerId` bigint(20) NOT NULL COMMENT '玩家id',
  `sendGiftTime` datetime NOT NULL COMMENT '赠送礼包时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

DROP TABLE IF EXISTS `userWeekPlan`;
CREATE TABLE `userWeekPlan` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `simpleAttributes` text COMMENT '自定义属性',
  `beginDate` datetime DEFAULT NULL,
  `planId` int(11) NOT NULL COMMENT '周计划id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

DROP TABLE IF EXISTS `userMonthPlan`;
CREATE TABLE `userMonthPlan` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `simpleAttributes` text COMMENT '自定义属性',
  `beginDate` datetime DEFAULT NULL,
  `planId` int(11) NOT NULL COMMENT '周计划id',
  `scores` bigint(20) DEFAULT '0' COMMENT '返回金币积分',
  `clearScoresDate` datetime DEFAULT NULL COMMENT '最后一次清除积分的时间点',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `playerEquip`
-- ----------------------------
DROP TABLE IF EXISTS `playerEquip`;
CREATE TABLE `playerEquip` (
  `id` bigint(20) NOT NULL COMMENT '主键id',
  `bind` bit(1) DEFAULT b'1' COMMENT '是否绑定  true绑定/false不绑定',
  `equipId` int(11) NOT NULL COMMENT '装备id',
  `locked` bit(1) DEFAULT b'0' COMMENT '是否锁定  true锁定/false没锁定',
  `playerId` bigint(20) NOT NULL COMMENT '玩家id',
  `sell` bit(1) DEFAULT b'0' COMMENT '是否售出  true已售出/false没售出',
  `wear` int(11) NOT NULL COMMENT '是否穿戴，0-没穿戴；非0已穿戴（穿戴位置）',
  PRIMARY KEY (`id`),
  KEY `equip_index` (`playerId`,`sell`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `playerWearEquip`
-- ----------------------------
DROP TABLE IF EXISTS `playerWearEquip`;
CREATE TABLE `playerWearEquip` (
  `id` bigint(20) NOT NULL COMMENT '玩家id',
  `arm` bigint(20) DEFAULT '-1' COMMENT '武器id',
  `book` bigint(20) DEFAULT '-1' COMMENT '兵书id',
  `cape` bigint(20) DEFAULT '-1' COMMENT '披风id',
  `cimelia` bigint(20) DEFAULT '-1' COMMENT '宝物id',
  `mount` bigint(20) DEFAULT '-1' COMMENT '坐骑id',
  `seal` bigint(20) DEFAULT '-1' COMMENT '兵符id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `playerIntegra`
-- ----------------------------
DROP TABLE IF EXISTS `playerIntegra`;
CREATE TABLE `playerIntegra` (
  `id` bigint(20) NOT NULL COMMENT '玩家id',
  `blessCount` int(11)  NOT NULL default '0' COMMENT '当天祝福次数',
  `buyBombCount` int(11) NOT NULL default '0' COMMENT '当天购买炸弹次数',
  `attactCount` int(11) NOT NULL default '0' COMMENT '当天攻击次数',
  `blessJson` text COMMENT '祝福玩家的json',
  `refreshDate` datetime COMMENT '重置时间点',
  `startDate` datetime DEFAULT '2000-01-01 00:00:00' COMMENT '上一次活动开始时间',
  `endDate` datetime DEFAULT '2000-01-01 00:00:00' COMMENT '上一次活动结束时间',
  `integral` int(11) NOT NULL DEFAULT '0' COMMENT '累计积分',
  `giftIdJson` text COMMENT '能领取祝福礼包  对应的玩家id',
  `receiveCount` int(11) NOT NULL DEFAULT '0' COMMENT '当天领取祝福礼包次数',
  `simpleAttributes` text COLLATE utf8_unicode_ci COMMENT '商城购买次数',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

DROP TABLE IF EXISTS `playerTotemCard`;
CREATE TABLE `playerTotemCard` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `cardId` int(11) NOT NULL DEFAULT '0' COMMENT '卡片基础id',
  `playerId` bigint(20) NOT NULL COMMENT '玩家id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `playerYestodayTaskStatus`
-- ----------------------------
DROP TABLE IF EXISTS `playerYestodayTaskStatus`;
CREATE TABLE `playerYestodayTaskStatus` (
  `id` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT '主键id',
  `activityId` int(11) NOT NULL COMMENT '活动ID',
  `playerId` bigint(20) NOT NULL COMMENT '玩家id',
  `receiveTaskTime` bigint(20) DEFAULT '0' COMMENT '接受任务的时间',
  `receiveTime` datetime DEFAULT NULL COMMENT '接受任务时间',
  `receivedReward1` int(11) DEFAULT '0' COMMENT '已经领取奖励1的次数',
  `receivedReward2` int(11) DEFAULT '0' COMMENT '已经领取奖励2的次数',
  `receivedReward3` int(11) DEFAULT '0' COMMENT '已经领取奖励3的次数',
  `receivedReward4` int(11) DEFAULT '0' COMMENT '已经领取奖励4的次数',
  `taskId` int(11) NOT NULL COMMENT '任务ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `yestodayServerActivityTask`
-- ----------------------------
DROP TABLE IF EXISTS `yestodayServerActivityTask`;
CREATE TABLE `yestodayServerActivityTask` (
  `taskId` int(11) NOT NULL COMMENT '基础任务id',
  `receiveTaskTime` bigint(20) DEFAULT '0' COMMENT '接受任务的时间',
  `receiveTime` datetime DEFAULT NULL COMMENT '接受任务时间',
  `taskStatus` tinyint(4) DEFAULT '2' COMMENT '任务状态',
  PRIMARY KEY (`taskId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `playerJzl`
-- ----------------------------
DROP TABLE IF EXISTS `playerJzl`;
CREATE TABLE `playerJzl` (
  `playerId` bigint(20) NOT NULL COMMENT '角色id',
  `buyCount` int(11) DEFAULT '0' COMMENT '当天购买次数',
  `buyTime` datetime DEFAULT NULL COMMENT '购买时间',
  `grantTime` datetime DEFAULT NULL COMMENT '发放时间',
  `jzl` bigint(20) DEFAULT '0' COMMENT '锯子令',
  PRIMARY KEY (`playerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `specialPlayerShopInfo`
-- ----------------------------
DROP TABLE IF EXISTS `specialPlayerShopInfo`;
CREATE TABLE `specialPlayerShopInfo` (
  `id` bigint(20) NOT NULL COMMENT '玩家ID',
  `dayServerLimit` text COMMENT '全服每日限量',
  `incomeDate` datetime DEFAULT '2012-01-01 00:00:00' COMMENT '每日限量最后计算时间',
  `serverLimit` text COMMENT '全服总限量',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
-- ----------------------------
-- Records of specialPlayerShopInfo
-- ----------------------------

-- ----------------------------
-- Table structure for `specialShopInfo`
-- ----------------------------
DROP TABLE IF EXISTS `specialShopInfo`;
CREATE TABLE `specialShopInfo` (
  `id` int(11) NOT NULL COMMENT 'id',
  `dayServerLimit` text COMMENT '全服每日限量',
  `incomeDate` datetime DEFAULT '2012-01-01 00:00:00' COMMENT '每日限量最后计算时间',
  `serverLimit` text COMMENT '全服总限量',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
-- ----------------------------
-- Records of specialShopInfo
-- ----------------------------
DROP TABLE IF EXISTS `playerPlant`;
CREATE TABLE `playerPlant` (
  `id` bigint(20) NOT NULL COMMENT '主键id',
  `jsonLands` text COMMENT '农地信息json信息',
  `obianCount` int(11) NOT NULL COMMENT '领取次数',
  `refreshDate` datetime DEFAULT NULL COMMENT '重置时间点',
  `totalCount` int(11) NOT NULL COMMENT '总购买的次数',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- ----------------------------
-- Table structure for `groupPurchase`
-- ----------------------------
DROP TABLE IF EXISTS `groupPurchase`;
CREATE TABLE `groupPurchase` (
  `id` varchar(255) NOT NULL COMMENT '活动开关id',
  `groupId` int(11) NOT NULL COMMENT '当前出售的物品组id',
  `startTime` datetime DEFAULT NULL COMMENT '此组物品团购开始的时间',
  `state` int(11) NOT NULL COMMENT '此活动的状态，0为进行中，1为结束，2为完成结算',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
-- ----------------------------
-- Table structure for `playerGroupPurchase`
-- ----------------------------
DROP TABLE IF EXISTS `playerGroupPurchase`;
CREATE TABLE `playerGroupPurchase` (
  `id` varchar(255) NOT NULL COMMENT '活动开关id_玩家id',
  `goods` text COMMENT '已团购的商品',
  `masterOpenId` varchar(255) NOT NULL COMMENT '活动开关id',
  `playerId` bigint(20) NOT NULL COMMENT '玩家id',
  `purchased` int(11) DEFAULT '0' COMMENT '是否购买，0未购买过，1购买过',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `playerTraining`
-- ----------------------------
DROP TABLE IF EXISTS `playerTraining`;
CREATE TABLE `playerTraining` (
  `id` bigint(20) NOT NULL COMMENT '玩家id',
  `simpleAttributes` text COLLATE utf8_unicode_ci COMMENT '自定义属性',
  `costPoint` int(11) NOT NULL COMMENT '已经消耗的练兵点数',
  `level` int(11) NOT NULL COMMENT '练兵等级',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `hundredServerActivity`
-- ----------------------------
DROP TABLE IF EXISTS `hundredServerActivity`;
CREATE TABLE `hundredServerActivity` (
  `id` int(11) NOT NULL COMMENT '活动id',
  `description` varchar(1000) COLLATE utf8_unicode_ci NOT NULL COMMENT '活动描述',
  `endTime` datetime DEFAULT '2013-01-01 00:00:00' COMMENT '结束时间',
  `startTime` datetime DEFAULT '2013-01-01 00:00:00' COMMENT '开始时间',
  `status` int(11) NOT NULL COMMENT '活动状态，0-有效 1-无效',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `hundredServerGift`
-- ----------------------------
DROP TABLE IF EXISTS `hundredServerGift`;
CREATE TABLE `hundredServerGift` (
  `id` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '礼包唯一标识',
  `activityId` int(11) NOT NULL COMMENT '活动id',
  `content` varchar(500) COLLATE utf8_unicode_ci NOT NULL COMMENT '礼包内容',
  `giftId` int(11) NOT NULL COMMENT '礼包id',
  `maxBuyAmount` int(11) NOT NULL COMMENT '最打可购买数量',
  `price` int(11) NOT NULL COMMENT '礼包价格',
  `status` int(11) NOT NULL COMMENT '礼包状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `playerHundredServerGift`
-- ----------------------------
DROP TABLE IF EXISTS `playerHundredServerGift`;
CREATE TABLE `playerHundredServerGift` (
  `id` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '主键',
  `simpleAttributes` text COLLATE utf8_unicode_ci COMMENT '自定义属性',
  `activityId` int(11) NOT NULL COMMENT '活动id',
  `addTime` datetime DEFAULT '2013-01-01 00:00:00' COMMENT '添加时间',
  `playerId` bigint(20) NOT NULL COMMENT '玩家id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `luckyDrawInfo`
-- ----------------------------
DROP TABLE IF EXISTS `luckyDrawInfo`;
CREATE TABLE `luckyDrawInfo` (
  `id` int(11) NOT NULL COMMENT '主键',
  `activityTime` datetime DEFAULT '2014-01-01 00:00:00' COMMENT '活动时间',
  `logContent` text COLLATE utf8_unicode_ci NOT NULL COMMENT '日志内容',
  `rankContent` text COLLATE utf8_unicode_ci NOT NULL COMMENT '排行榜内容',
  `status` int(11) NOT NULL COMMENT '状态：0-还没结算 1-已经结算',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `playerLuckyDraw`
-- ----------------------------
DROP TABLE IF EXISTS `playerLuckyDraw`;
CREATE TABLE `playerLuckyDraw` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `activityTime` datetime DEFAULT '2014-01-01 00:00:00' COMMENT '活动时间',
  `costItemAmount` int(11) NOT NULL COMMENT '消耗的道具数量',
  `drawTimes` int(11) NOT NULL COMMENT '抽奖次数',
  `lastDrawTime` datetime DEFAULT '2014-01-01 00:00:00' COMMENT '最后抽奖时间',
  `rank` int(11) NOT NULL COMMENT '排名',
  `status` int(11) NOT NULL COMMENT '状态：0-没有奖励 1-可领奖 2-已经领奖',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `playerCard`
-- ----------------------------
DROP TABLE IF EXISTS `playerCard`;
CREATE TABLE `playerCard` (
  `playerId` bigint(20) NOT NULL COMMENT '玩家id',
  `bufferGetState` int(11) NOT NULL COMMENT '是否领取每日buffer，0-未领取，1-已经领取',
  `endTime` datetime DEFAULT NULL COMMENT '月卡结束时间',
  `energyGetState` int(11) NOT NULL COMMENT '是否领取体力，0-未领取，1-已经领取',
  `fjtxGetState` int(11) NOT NULL COMMENT '是否领取富甲天下，0-未领取，1-已经领取',
  `getTime` datetime DEFAULT NULL COMMENT '月卡特权领取时间',
  `isOpen` int(11) NOT NULL COMMENT '是否激活月卡，0-未激活，1-已经激活',
  PRIMARY KEY (`playerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `playerItemConvert`
-- ----------------------------
DROP TABLE IF EXISTS `playerItemConvert`;
CREATE TABLE `playerItemConvert` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `activityTime` datetime DEFAULT '2014-01-01 00:00:00' COMMENT '活动时间',
  `convertTimes` int(11) NOT NULL COMMENT '当天已经转换的次数',
  `lastConvertTime` datetime DEFAULT '2014-01-01 00:00:00' COMMENT '最后转换时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `playerExpPill`
-- ----------------------------
DROP TABLE IF EXISTS `playerExpPill`;
CREATE TABLE IF NOT EXISTS `playerExpPill` (
  `id` bigint(20) NOT NULL COMMENT '玩家id',
  `lastUseDay` datetime DEFAULT '2013-01-01 00:00:00' COMMENT '最后使用经验丹的日期',
  `useAmount` int(11) NOT NULL COMMENT '当天使用经验丹的次数',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `playerGoldDraw`
-- ----------------------------
DROP TABLE IF EXISTS `playerGoldDraw`;
CREATE TABLE IF NOT EXISTS `playerGoldDraw` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `activityTime` datetime DEFAULT '2014-01-01 00:00:00' COMMENT '活动时间',
  `drawTimes` int(11) NOT NULL COMMENT '抽奖次数',
  `lastDrawTime` datetime DEFAULT '2014-01-01 00:00:00' COMMENT '最后抽奖时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `playerRareItemDraw`
-- ----------------------------
DROP TABLE IF EXISTS `playerRareItemDraw`;
CREATE TABLE IF NOT EXISTS `playerRareItemDraw` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `simpleAttributes` text COLLATE utf8_unicode_ci COMMENT '自定义属性',
  `activityTime` datetime DEFAULT '2014-01-01 00:00:00' COMMENT '活动时间',
  `drawTimes` int(11) NOT NULL COMMENT '抽奖次数',
  `lastDrawTime` datetime DEFAULT '2014-01-01 00:00:00' COMMENT '最后抽奖时间',
  `rareItemId` int(11) NOT NULL COMMENT '抽中的稀有物品id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `rareItemDrawInfo`
-- ----------------------------
DROP TABLE IF EXISTS `rareItemDrawInfo`;
CREATE TABLE IF NOT EXISTS `rareItemDrawInfo` (
  `id` int(11) NOT NULL COMMENT '主键',
  `activityTime` datetime DEFAULT '2014-01-01 00:00:00' COMMENT '活动时间',
  `logContent` text COLLATE utf8_unicode_ci NOT NULL COMMENT '日志内容',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `chargeActivity`
-- ----------------------------
DROP TABLE IF EXISTS `chargeActivity`;
CREATE TABLE IF NOT EXISTS `chargeActivity` (
  `id` int(11) NOT NULL COMMENT '主键id',
  `actDesc` text COMMENT '活动描述',
  `actName` varchar(255) NOT NULL COMMENT '活动名',
  `actType` tinyint(3) DEFAULT '0' COMMENT '活动类型, 0-充值  1-消费',
  `endTime` datetime DEFAULT NULL COMMENT '活动结束时间',
  `startTime` datetime DEFAULT NULL COMMENT '活动开始时间',
  `status` tinyint(3) DEFAULT '1' COMMENT '活动状态, 0-关闭  1-开启',
  `rewardCfg` longtext COMMENT '奖励配置',
  `rewardTime` datetime DEFAULT NULL COMMENT '活动奖励结束时间，必须大于活动结束时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `playerChargeReward`
-- ----------------------------
DROP TABLE IF EXISTS `playerChargeReward`;
CREATE TABLE IF NOT EXISTS `playerChargeReward`(
  `id` bigint(20) NOT NULL COMMENT 'id',
  `rewards` longtext COMMENT '玩家获得的充值消费奖励',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `kFChampion`
-- ----------------------------
DROP TABLE IF EXISTS `kFChampion`;
CREATE TABLE `kFChampion` (
  `id` int(11) NOT NULL COMMENT '主键ID',
  `champion` int(11) NOT NULL COMMENT '是否为冠军服，0-否，1-是',
  `championDay` varchar(20) DEFAULT '' COMMENT '跨服争霸日期',
  `championPlayerId` bigint(20) NOT NULL COMMENT '冠军id',
  `participators` text COMMENT '排名',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
-- ----------------------------
-- Table structure for `kFChampionInfo`
-- ----------------------------
DROP TABLE IF EXISTS `kFChampionInfo`;
CREATE TABLE `kFChampionInfo` (
  `id` int(11) NOT NULL COMMENT '主键ID',
  `info` longtext COMMENT '跨服争霸的全局信息',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `playerKFChampion`
-- ----------------------------
DROP TABLE IF EXISTS `playerKFChampion`;
CREATE TABLE `playerKFChampion` (
  `playerId` bigint(20) NOT NULL COMMENT '角色id',
  `championDay` varchar(20) DEFAULT '' COMMENT '跨服争霸日期',
  `rank` tinyint(4) DEFAULT '0' COMMENT '参与跨服争霸的名次，0表示没有参与过',
  `rewardStatus` tinyint(2) DEFAULT '0' COMMENT '奖励是否领取',
  `supportReward` text COMMENT '奖励信息',
  `supportedPlayerUniqueId` text COMMENT '被支持玩家在一场跨服争霸中的唯一性id',
  PRIMARY KEY (`playerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `playerServerTreasure`
-- ----------------------------
DROP TABLE IF EXISTS `playerServerTreasure`;
CREATE TABLE `playerServerTreasure` (
  `id` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT 'id',
  `actId` bigint(20) NOT NULL COMMENT '活动id',
  `count` int(11) NOT NULL COMMENT '已摸金的次数',
  `playerId` bigint(20) NOT NULL COMMENT '玩家id',
  `treasureTime` datetime DEFAULT NULL COMMENT '最后摸金的时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `serverTreasure`
-- ----------------------------
DROP TABLE IF EXISTS `serverTreasure`;
CREATE TABLE `serverTreasure` (
  `playerId` bigint(20) NOT NULL COMMENT '角色id',
  `actStatus` tinyint(3) DEFAULT '0' COMMENT '活动状态, 0-关闭  1-开启',
  `openActTime` datetime DEFAULT NULL COMMENT '开启活动时间',
  PRIMARY KEY (`playerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `loopBossInfo`
-- ----------------------------
DROP TABLE IF EXISTS `loopBossInfo`;
CREATE TABLE `loopBossInfo` (
  `id` int(11) NOT NULL COMMENT '主键',
  `bossId` int(11) NOT NULL COMMENT '魔神吕布的id',
  `winTimes` int(11) NOT NULL COMMENT '没被击杀的次数',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `playerRoyalInfo`
-- ----------------------------
DROP TABLE IF EXISTS `playerRoyalInfo`;
CREATE TABLE `playerRoyalInfo` (
  `playerId` bigint(20) NOT NULL COMMENT '角色id',
  `buyCount` tinyint(4) NOT NULL DEFAULT '0' COMMENT '当天购买次数',
  `freeRefreshCount` tinyint(4) NOT NULL DEFAULT '0' COMMENT '当天免费刷新次数',
  `refreshTaskTime` datetime DEFAULT NULL COMMENT '刷新任务时间',
  `refreshTime` datetime DEFAULT NULL COMMENT '跨天刷新时间',
  `taskCount` tinyint(4) NOT NULL DEFAULT '0' COMMENT '当天已做任务次数',
  `npcId` int(11) NOT NULL DEFAULT '0' COMMENT '当前刷出来的npcId',
  PRIMARY KEY (`playerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `playerRoyalTask`
-- ----------------------------
DROP TABLE IF EXISTS `playerRoyalTask`;
CREATE TABLE `playerRoyalTask` (
  `id` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT '主键id',
  `playerId` bigint(20) NOT NULL COMMENT '玩家id',
  `taskContent` text COLLATE utf8_unicode_ci COMMENT '任务进度信息',
  `taskId` int(11) DEFAULT '0' COMMENT '基础任务id',
  `taskStatus` tinyint(4) DEFAULT '2' COMMENT '任务状态',
  `star` int(11) NOT NULL DEFAULT '0' COMMENT '任务星级',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

DROP TABLE IF EXISTS `playerLaborPlant`;
CREATE TABLE `playerLaborPlant` (
  `id` bigint(20) NOT NULL COMMENT '主键id',
  `jsonLands` text COLLATE utf8_unicode_ci COMMENT '农地信息JSON信息',
  `obianCount` int(11) NOT NULL COMMENT '领取次数',
  `refreshDate` datetime DEFAULT NULL COMMENT '重置时间点',
  `totalCount` int(11) NOT NULL COMMENT '总购买的次数',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `playerCn37Vip`
-- ----------------------------
DROP TABLE IF EXISTS `playerCn37Vip`;
CREATE TABLE `playerCn37Vip` (
  `playerId` bigint(20) NOT NULL COMMENT '角色id',
  `level` tinyint(3) DEFAULT '0' COMMENT 'vip等级',
  `levelGifts` text COMMENT '已领取的等级礼包json串',
  PRIMARY KEY (`playerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `playerTower`
-- ----------------------------
DROP TABLE IF EXISTS `playerTower`;
CREATE TABLE `playerTower` (
  `id` bigint(20) NOT NULL COMMENT '玩家id',
  `areaId` int(11) DEFAULT '0' COMMENT '当前通关的据点',
  `areasResourceReward` text COMMENT '据点资源奖励记录',
  `areasReward` text COMMENT '通关记录',
  `breakTime` datetime DEFAULT '2012-01-01 00:00:00' COMMENT '据点通关的日期',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `towerBreakInfo`
-- ----------------------------
DROP TABLE IF EXISTS `towerBreakInfo`;
CREATE TABLE `towerBreakInfo` (
  `id` int(11) NOT NULL COMMENT '据点id',
  `createTime` datetime DEFAULT '2012-01-01 00:00:00' COMMENT '创建时间',
  `userId` bigint(20) NOT NULL COMMENT '用户id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `towerLastFirstBreakInfo`
-- ----------------------------
DROP TABLE IF EXISTS `towerLastFirstBreakInfo`;
CREATE TABLE `towerLastFirstBreakInfo` (
  `id` int(11) NOT NULL COMMENT '据点id',
  `battleHeros` text COMMENT '上阵的所有武将，前后军',
  `level` int(11) NOT NULL COMMENT '主公等级',
  `name` varchar(255) NOT NULL COMMENT '主公名称',
  `totleAbility` double DEFAULT '0' COMMENT '总战斗力',
  `battleAbilityInfo` text COMMENT '计算玩家战力明细的其他相关信息',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `playerHorse`
-- ----------------------------
DROP TABLE IF EXISTS `playerHorse`;
CREATE TABLE `playerHorse` (
  `id` bigint(20) NOT NULL COMMENT '主键id',
  `simpleAttributes` text COLLATE utf8_unicode_ci COMMENT '自定义属性',
  `extLevelLimit` int(11) NOT NULL COMMENT '额外获得的属性等级上限',
  `horseId` int(11) NOT NULL COMMENT '坐骑外形id',
  `rank` int(11) NOT NULL COMMENT '品阶',
  `rided` tinyint(4) NOT NULL COMMENT '是否骑乘(0-不骑乘 1-骑乘)',
  `totalExp` int(11) NOT NULL COMMENT '总经验',
  `trainAttrs` text COLLATE utf8_unicode_ci COMMENT '培养属性JSON信息',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `playerJewelUpgradeItem`
-- ----------------------------
DROP TABLE IF EXISTS `playerJewelUpgradeItem`;
CREATE TABLE `playerJewelUpgradeItem` (
  `id` bigint(20) NOT NULL COMMENT '主键id',
  `simpleAttributes` text COLLATE utf8_unicode_ci COMMENT '自定义属性',
  `buyTime` datetime DEFAULT '2013-01-01 00:00:00' COMMENT '购买时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- ----------------------------
-- Table structure for `playerMysteryStore`
-- ----------------------------
DROP TABLE IF EXISTS `playerMysteryStore`;
CREATE TABLE `playerMysteryStore` (
  `id` bigint(20) NOT NULL COMMENT '玩家id',
  `activityBoughtInfo` text COMMENT '单次活动已购买商品信息',
  `activityTime` datetime DEFAULT NULL COMMENT '本次活动开启时间',
  `lastRefreshTime` datetime DEFAULT NULL COMMENT '上次刷新的时间',
  `playerBoughtInfo` text COMMENT '玩家已购买商品信息',
  `refreshBoughtInfo` text COMMENT '商店里的商品及单次刷新时间内已购买数量',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `playerOneYuanShopInfo`
-- ----------------------------
DROP TABLE IF EXISTS `playerOneYuanShopInfo`;
CREATE TABLE `playerOneYuanShopInfo` (
  `id` bigint(20) NOT NULL COMMENT '玩家id',
  `buyAmount` int(11) NOT NULL COMMENT '购买数量',
  `buyTime` datetime DEFAULT '2013-01-01 00:00:00' COMMENT '购买时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `playerDivinationUpgradeItem`
-- ----------------------------
DROP TABLE IF EXISTS `playerDivinationUpgradeItem`;
CREATE TABLE `playerDivinationUpgradeItem` (
  `id` bigint(20) NOT NULL COMMENT '主键id',
  `simpleAttributes` text COLLATE utf8_unicode_ci COMMENT '自定义属性',
  `buyTime` datetime DEFAULT '2013-01-01 00:00:00' COMMENT '购买时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `playerDuanWuInfo`
-- ----------------------------
DROP TABLE IF EXISTS `playerDuanWuInfo`;
CREATE TABLE `playerDuanWuInfo` (
  `id` bigint(20) NOT NULL COMMENT '玩家id',
  `activityTime` datetime DEFAULT NULL COMMENT '本次活动时间',
  `completedCount` tinyint(4) NOT NULL DEFAULT '0' COMMENT '已完成答题任务次数',
  `npcId` int(11) NOT NULL DEFAULT '0' COMMENT '答题npcId',
  `refreshTime` datetime DEFAULT NULL COMMENT '每日刷新时间',
  `rightOption` tinyint(4) NOT NULL DEFAULT '-1' COMMENT '正确选项',
  `subjectId` int(11) NOT NULL DEFAULT '0' COMMENT '题目id',
  `taskStatus` tinyint(4) NOT NULL DEFAULT '0' COMMENT '答题任务状态',
  `xianLiaoBoughtCount` int(11) NOT NULL DEFAULT '0' COMMENT '已购买馅料数量',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8  COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `playerNetherwing`
-- ----------------------------
DROP TABLE IF EXISTS `playerNetherwing`;
CREATE TABLE `playerNetherwing` (
  `id` bigint(20) NOT NULL COMMENT '主键id',
  `netherwingId` int(11) NOT NULL COMMENT '当前幻化的灵翼id',
  `netherwings` text COMMENT '玩家所有的灵翼',
  `netterwingAttrs` text COMMENT '入魂培养属性列表JSON信息',
  `trainNetherwingId` int(11) NOT NULL COMMENT '当前培养的灵翼id',
  `trainTimes` int(11) NOT NULL COMMENT '已培养次数',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8  COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `playerLoot`
-- ----------------------------
DROP TABLE IF EXISTS `playerLoot`;
CREATE TABLE `playerLoot` (
  `playerId` bigint(20) NOT NULL COMMENT '角色id',
  `buyCount` int(11) DEFAULT '0' COMMENT '当天已购买次数',
  `cdEnd` bigint(20) NOT NULL DEFAULT '0' COMMENT 'CD结束时间（ms）',
  `cdStatus` int(11) not null default '0' comment 'cd状态：0-不需要等待cd结束  1-需要等待cd结束',
  `currTargets` longtext COLLATE utf8_unicode_ci COMMENT '当前掠夺对象',
  `leftCount` int(11) DEFAULT '0' COMMENT '当天可掠夺次数（含当天购买和赠送次数, 不包括每天的默认次数）',
  `lootCount` int(11) DEFAULT '0' COMMENT '当天已掠夺次数',
  `lootDay` varchar(12) COLLATE utf8_unicode_ci NOT NULL COMMENT '掠夺日期',
  `refreshTime` datetime DEFAULT NULL COMMENT '系统刷新时间',
  PRIMARY KEY (`playerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `kfLootMember`
-- ----------------------------
DROP TABLE IF EXISTS `kfLootMember`;
CREATE TABLE `kfLootMember` (
  `id` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT '主键id',
  `playerBattles` longtext COLLATE utf8_unicode_ci COMMENT '玩家的战斗信息',
  `playerInfos` text COLLATE utf8_unicode_ci COMMENT '玩家基本信息',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- ----------------------------
-- Table structure for `kfLootValue`
-- ----------------------------
DROP TABLE IF EXISTS `kfLootValue`;
CREATE TABLE `kfLootValue` (
  `id` int(11) NOT NULL COMMENT '主键id',
  `info` longtext COLLATE utf8_unicode_ci COMMENT '信息',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `playerLoginDaysGift`
-- ----------------------------
DROP TABLE IF EXISTS `playerLoginDaysGift`;
CREATE TABLE `playerLoginDaysGift` (
  `id` bigint(20) NOT NULL COMMENT '主键id',
  `simpleAttributes` text COLLATE utf8_unicode_ci COMMENT '自定义属性',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `playerWorldCupCard`
-- ----------------------------
DROP TABLE IF EXISTS `playerWorldCupCard`;
CREATE TABLE `playerWorldCupCard` (
  `id` bigint(20) NOT NULL COMMENT '玩家id',
  `actTime` datetime DEFAULT '2013-01-01 00:00:00' COMMENT '每天第一次进入兑换的时间',
  `cardExchangeHis` text COLLATE utf8_unicode_ci COMMENT '卡牌兑换记录',
  `extractCount` int(11) DEFAULT '0' COMMENT '每日免费宝箱抽取次数',
  `lastActTime` datetime DEFAULT '2013-01-01 00:00:00' COMMENT '总积分最后修改时间',
  `pointCount` int(11) DEFAULT '0' COMMENT '点数(卡牌兑换的点数)',
  `rank` int(11) DEFAULT '0' COMMENT '玩家总积分排名',
  `totalIntegral` int(11) DEFAULT '0' COMMENT '抽取卡片宝箱获得的总积分',
  `totalReceive` tinyint(4) NOT NULL DEFAULT '0' COMMENT '总积分排名奖励是否领取',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `playerWorldCupInfo`
-- ----------------------------
DROP TABLE IF EXISTS `playerWorldCupInfo`;
CREATE TABLE `playerWorldCupInfo` (
  `id` bigint(20) NOT NULL,
  `abandonTeamTime` datetime DEFAULT NULL COMMENT '放弃支持球队时间',
  `activityTime` datetime DEFAULT NULL COMMENT '活动时间',
  `chargeGoldInfo` text COLLATE utf8_unicode_ci COMMENT '活动期间充值元宝信息',
  `fundGold` int(11) NOT NULL DEFAULT '0' COMMENT '已获得的充值返还元宝',
  `fundGoldRewardStatus` tinyint(4) NOT NULL DEFAULT '0' COMMENT '充值奖励领取状态',
  `guessResultInfo` text COLLATE utf8_unicode_ci COMMENT '猜胜负信息',
  `guessScoreInfo` text COLLATE utf8_unicode_ci COMMENT '猜比分信息',
  `loginDays` tinyint(4) NOT NULL DEFAULT '0' COMMENT '世界杯期间登录天数',
  `loginRewardInfo` text COLLATE utf8_unicode_ci COMMENT '已领取的登录奖励',
  `matchRewardStatus` tinyint(4) NOT NULL DEFAULT '0' COMMENT '球队比赛奖励领取状态',
  `refreshTime` datetime DEFAULT NULL COMMENT '刷新时间',
  `supportRewardInfo` text COLLATE utf8_unicode_ci COMMENT '已领取的总支持人数奖励',
  `supportTeamId` tinyint(4) NOT NULL DEFAULT '-1' COMMENT '支持的球队id',
  `supportTime` datetime DEFAULT NULL COMMENT '第一次选择支持的球队时间',
  `fundGoldRewardInfo` text COMMENT '已领取的返还元宝信息',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `worldCupInfo`
-- ----------------------------
DROP TABLE IF EXISTS `worldCupInfo`;
CREATE TABLE `worldCupInfo` (
  `id` tinyint(4) NOT NULL COMMENT 'id',
  `matchGuessInfo` text COLLATE utf8_unicode_ci COMMENT '比赛的比分信息',
  `matchScoreInfo` text COLLATE utf8_unicode_ci COMMENT '比赛的比分信息',
  `teamStatusInfo` text COLLATE utf8_unicode_ci COMMENT '各队支持人数情况',
  `totalSupportCount` int(11) NOT NULL DEFAULT '0' COMMENT '总支持人数',
  `activityTime` datetime DEFAULT NULL COMMENT '活动时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `worldCupIntegral`
-- ----------------------------
DROP TABLE IF EXISTS `worldCupIntegral`;
CREATE TABLE `worldCupIntegral` (
  `id` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT 'id',
  `actTime` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '日期:格式yyyy-MM-dd',
  `integral` int(11) DEFAULT '0' COMMENT '积分',
  `lastActTime` datetime DEFAULT '2013-01-01 00:00:00' COMMENT '总积分最后修改时间',
  `playerId` bigint(20) NOT NULL COMMENT '玩家id',
  `rank` int(11) DEFAULT '0' COMMENT '积分',
  `receive` tinyint(3) DEFAULT '0' COMMENT '昨天是否领取积分排名奖励',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `worldCupMatchSchedule`
-- ----------------------------
DROP TABLE IF EXISTS `worldCupMatchSchedule`;
CREATE TABLE `worldCupMatchSchedule` (
  `id` int(11) NOT NULL COMMENT '比赛id',
  `date` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '比赛日期',
  `field` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '比赛场地',
  `homeTeamId` tinyint(4) NOT NULL DEFAULT '-1' COMMENT '主队id',
  `matchType` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '比赛类型',
  `time` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '比赛时间',
  `visitingTeamId` tinyint(4) NOT NULL DEFAULT '-1' COMMENT '客队id',
  PRIMARY KEY (`id`),
  KEY `world_cup_match_date_index` (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

DROP TABLE IF EXISTS `playerHeroSoulSkill`;
CREATE TABLE `playerHeroSoulSkill` (
  `id` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT 'id',
  `heroId` bigint(20) NOT NULL COMMENT '武将id',
  `soulSkillId` int(11) NOT NULL COMMENT '战魄技能id',
  `soulSkillLevel` int(11) DEFAULT '0' COMMENT '战魄技能等级',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of worldcupmatchschedule
-- ----------------------------
INSERT INTO `worldCupMatchSchedule` (`id`, `date`, `field`, `homeTeamId`, `matchType`, `time`, `visitingTeamId`) VALUES (1,'2014-06-13','圣保罗',1,'A组 小组赛','04:00:00',2),(2,'2014-06-14','纳塔尔',3,'A组 小组赛','00:00:00',4),(3,'2014-06-14','萨尔瓦多',5,'B组 小组赛','03:00:00',6),(4,'2014-06-14','库亚巴',7,'B组 小组赛','06:00:00',8),(5,'2014-06-15','贝洛奥里藏特',9,'C组 小组赛','00:00:00',10),(6,'2014-06-15','福塔莱萨',13,'D组 小组赛','03:00:00',14),(7,'2014-06-15','马瑙斯',15,'D组 小组赛','06:00:00',16),(8,'2014-06-15','累西腓',11,'C组 小组赛','09:00:00',12),(9,'2014-06-16','巴西利亚',17,'E组 小组赛','00:00:00',18),(10,'2014-06-16','阿雷格里港',19,'E组 小组赛','03:00:00',20),(11,'2014-06-16','里约热内卢',21,'F组 小组赛','06:00:00',22),(12,'2014-06-17','萨尔瓦多',25,'G组 小组赛','00:00:00',26),(13,'2014-06-17','库里奇巴',23,'F组 小组赛','03:00:00',24),(14,'2014-06-17','纳塔尔',27,'G组 小组赛','06:00:00',28),(15,'2014-06-18','贝洛奥里藏特',29,'H组 小组赛','00:00:00',30),(16,'2014-06-18','福塔莱萨',1,'A组 小组赛','03:00:00',3),(17,'2014-06-18','库亚巴',31,'H组 小组赛','06:00:00',32),(18,'2014-06-19','阿雷格里港',8,'B组 小组赛','00:00:00',6),(19,'2014-06-19','里约热内卢',5,'B组 小组赛','03:00:00',7),(20,'2014-06-19','马瑙斯',4,'A组 小组赛','06:00:00',2),(21,'2014-06-20','巴西利亚',9,'C组 小组赛','00:00:00',11),(22,'2014-06-20','圣保罗',13,'D组 小组赛','03:00:00',15),(23,'2014-06-20','纳塔尔',12,'C组 小组赛','06:00:00',10),(24,'2014-06-21','累西腓',16,'D组 小组赛','00:00:00',14),(25,'2014-06-21','萨尔瓦多',17,'E组 小组赛','03:00:00',19),(26,'2014-06-21','库里奇巴',20,'E组 小组赛','06:00:00',18),(27,'2014-06-22','贝洛奥里藏特',21,'F组 小组赛','00:00:00',23),(28,'2014-06-22','福塔莱萨',25,'G组 小组赛','03:00:00',27),(29,'2014-06-22','库亚巴',24,'F组 小组赛','06:00:00',22),(30,'2014-06-23','里约热内卢',29,'H组 小组赛','00:00:00',31),(31,'2014-06-23','阿雷格里港',32,'H组 小组赛','03:00:00',30),(32,'2014-06-23','马瑙斯',28,'G组 小组赛','06:00:00',26),(33,'2014-06-24','库里奇巴',8,'B组 小组赛','00:00:00',5),(34,'2014-06-24','圣保罗',6,'B组 小组赛','00:00:00',7),(35,'2014-06-24','巴西利亚',4,'A组 小组赛','04:00:00',1),(36,'2014-06-24','累西腓',2,'A组 小组赛','04:00:00',3),(37,'2014-06-25','纳塔尔',16,'D组 小组赛','00:00:00',13),(38,'2014-06-25','贝洛奥里藏特',14,'D组 小组赛','00:00:00',15),(39,'2014-06-25','库亚巴',12,'C组 小组赛','04:00:00',9),(40,'2014-06-25','福塔莱萨',10,'C组 小组赛','04:00:00',11),(41,'2014-06-26','阿雷格里港',24,'F组 小组赛','00:00:00',21),(42,'2014-06-26','萨尔瓦多',22,'F组 小组赛','00:00:00',23),(43,'2014-06-26','马瑙斯',20,'E组 小组赛','04:00:00',17),(44,'2014-06-26','里约热内卢',18,'E组 小组赛','04:00:00',19),(45,'2014-06-27','累西腓',28,'G组 小组赛','00:00:00',25),(46,'2014-06-27','巴西利亚',26,'G组 小组赛','00:00:00',27),(47,'2014-06-27','圣保罗',32,'H组 小组赛','04:00:00',29),(48,'2014-06-27','库里奇巴',30,'H组 小组赛','04:00:00',31);

-- ----------------------------
-- Table structure for `playerChargeIntegral`
-- ----------------------------
DROP TABLE IF EXISTS `playerChargeIntegral`;
CREATE TABLE `playerChargeIntegral` (
  `id` bigint(20) NOT NULL COMMENT '玩家id',
  `simpleAttributes` text COLLATE utf8_unicode_ci COMMENT '自定义属性',
  `activityTime` datetime DEFAULT '2013-01-01 00:00:00' COMMENT '活动时间',
  `integral` int(11) DEFAULT '0' COMMENT '积分',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `playerGoldShopInfo`
-- ----------------------------
DROP TABLE IF EXISTS `playerGoldShopInfo`;
CREATE TABLE `playerGoldShopInfo` (
  `id` bigint(20) NOT NULL COMMENT '玩家id',
  `simpleAttributes` text COLLATE utf8_unicode_ci COMMENT '自定义属性',
  `buyTime` datetime DEFAULT '2013-01-01 00:00:00' COMMENT '购买时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `armyGroupTrainInfo`
-- ----------------------------
DROP TABLE IF EXISTS `armyGroupTrainInfo`;
CREATE TABLE `armyGroupTrainInfo` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `date` varchar(50) NOT NULL COMMENT '试炼日期',
  `ranks` longtext COMMENT '军团试炼排名',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `playerChargeReturn`
-- ----------------------------
DROP TABLE IF EXISTS `playerChargeReturn`;
CREATE TABLE `playerChargeReturn` (
  `id` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '' COMMENT '订单号',
  `playerId` bigint(20) NOT NULL COMMENT '角色id',
  `status` int(11) DEFAULT '0' COMMENT '是否领取',
  `returnGolds` int(11) DEFAULT '0' COMMENT '返还元宝数量',
  `rewardTime` datetime DEFAULT NULL COMMENT '领取奖励的日期',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `netherwingActivity`
-- ----------------------------
DROP TABLE IF EXISTS `netherwingActivity`;
CREATE TABLE `netherwingActivity` (
  `id` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT '主键id',
  `netherwings` text COLLATE utf8_unicode_ci COMMENT '灵翼池',
  `receiveTime` datetime DEFAULT NULL COMMENT '活动生成日期',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `playerNetherwingActivity`
-- ----------------------------
DROP TABLE IF EXISTS `playerNetherwingActivity`;
CREATE TABLE `playerNetherwingActivity` (
  `id` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT '主键id',
  `netherwingId` int(11) NOT NULL COMMENT '灵翼id',
  `playerId` bigint(20) NOT NULL COMMENT '玩家id',
  `rewardTime` datetime DEFAULT NULL COMMENT '领取奖励的日期',
  `stars` text COLLATE utf8_unicode_ci COMMENT '已经领取过奖励的星级',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `fungWanBattleReport`
-- ----------------------------
DROP TABLE IF EXISTS `fungWanBattleReport`;
CREATE TABLE `fungWanBattleReport` (
  `id` bigint(20) NOT NULL COMMENT '主键ID',
  `battleReport` longblob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `fungWanChampion`
-- ----------------------------
DROP TABLE IF EXISTS `fungWanChampion`;
CREATE TABLE `fungWanChampion` (
  `id` bigint(20) NOT NULL COMMENT '主键ID',
  `ability` double DEFAULT '0' COMMENT '战斗力',
  `agent` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '平台',
  `fungWanNo` int(11) NOT NULL DEFAULT '0' COMMENT '第几届',
  `leaderId` bigint(20) NOT NULL COMMENT '队长id',
  `leaderName` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '队长名',
  `localTeamId` bigint(20) NOT NULL COMMENT '本地战队id',
  `members` longtext COLLATE utf8_unicode_ci COMMENT '成员信息',
  `msg` text COLLATE utf8_unicode_ci COMMENT '平台',
  `respectCount` int(11) NOT NULL DEFAULT '0' COMMENT '参拜次数',
  `section` int(11) NOT NULL DEFAULT '0' COMMENT '赛段ID',
  `teamId` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '战队id',
  `teamName` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '战队名称',
  `warZone` int(11) NOT NULL DEFAULT '0' COMMENT '战区ID',
  PRIMARY KEY (`id`),
  KEY `fungWanChampion_idx_fungWanNo` (`fungWanNo`),
  KEY `fungWanChampion_idx_warZone` (`warZone`),
  KEY `fungWanChampion_idx_section` (`section`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `fungWanChampionMatch`
-- ----------------------------
DROP TABLE IF EXISTS `fungWanChampionMatch`;
CREATE TABLE `fungWanChampionMatch` (
  `id` bigint(20) NOT NULL COMMENT '主键ID',
  `matchType` tinyint(2) NOT NULL DEFAULT '0' COMMENT '比赛类型',
  `ngroup` tinyint(2) NOT NULL DEFAULT '0' COMMENT '组别',
  `reports` text COLLATE utf8_unicode_ci COMMENT '场次战报信息',
  `rivalTeamId` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '对手战队id',
  `rivalWins` tinyint(2) NOT NULL DEFAULT '0' COMMENT '对手胜利场数',
  `section` int(11) NOT NULL DEFAULT '0' COMMENT '赛段ID',
  `teamId` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '战队id',
  `warZone` int(11) NOT NULL DEFAULT '0' COMMENT '战区ID',
  `winTeamId` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '晋级战队id',
  `wins` tinyint(2) NOT NULL DEFAULT '0' COMMENT '胜利场数',
  PRIMARY KEY (`id`),
  KEY `fungWanChampionMatch_idx_matchType` (`matchType`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `fungWanMatchBattle`
-- ----------------------------
DROP TABLE IF EXISTS `fungWanMatchBattle`;
CREATE TABLE `fungWanMatchBattle` (
  `id` bigint(20) NOT NULL COMMENT '主键ID',
  `ability` double DEFAULT '0' COMMENT '战斗力',
  `agent` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '平台',
  `matchType` tinyint(2) NOT NULL DEFAULT '0' COMMENT '比赛类型',
  `rivalAbility` double DEFAULT '0' COMMENT '战斗力',
  `rivalAgent` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '对手平台',
  `rivalTeamId` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '对手战队id',
  `rivalTeamName` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '对手战队名称',
  `teamId` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '战队id',
  `teamName` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '战队名称',
  `winTeamId` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '胜利战队id',
  PRIMARY KEY (`id`),
  KEY `fungWanMatchBattle_idx_matchType` (`matchType`),
  KEY `fungWanMatchBattle_idx_teamId` (`teamId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `fungWanMatchPoint`
-- ----------------------------
DROP TABLE IF EXISTS `fungWanMatchPoint`;
CREATE TABLE `fungWanMatchPoint` (
  `id` bigint(20) NOT NULL COMMENT '主键ID',
  `ability` double DEFAULT '0' COMMENT '战斗力',
  `agent` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '平台',
  `matchType` tinyint(2) NOT NULL DEFAULT '0' COMMENT '比赛类型',
  `ngroup` tinyint(2) NOT NULL DEFAULT '0' COMMENT '第几组',
  `rank` int(11) NOT NULL DEFAULT '0' COMMENT '排名',
  `score` int(11) NOT NULL DEFAULT '0' COMMENT '总积分',
  `section` int(11) NOT NULL DEFAULT '0' COMMENT '赛段ID',
  `teamId` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT '战队id',
  `teamName` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '战队id',
  `warZone` int(11) NOT NULL DEFAULT '0' COMMENT '战区ID',
  `wins` int(5) NOT NULL DEFAULT '0' COMMENT '胜利场次',
  PRIMARY KEY (`id`),
  KEY `fungWanMatchPoint_idx_rank` (`rank`),
  KEY `fungWanMatchPoint_idx_matchType` (`matchType`),
  KEY `fungWanMatchPoint_idx_warZone` (`warZone`),
  KEY `fungWanMatchPoint_idx_section` (`section`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- ----------------------------
-- Table structure for `fungWanMember`
-- ----------------------------
DROP TABLE IF EXISTS `fungWanMember`;
CREATE TABLE `fungWanMember` (
  `id` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT '主键id',
  `playerBattles` longtext COLLATE utf8_unicode_ci COMMENT '玩家的战斗信息',
  `playerInfos` longtext COLLATE utf8_unicode_ci COMMENT '玩家的战斗信息',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- ----------------------------
-- Table structure for `fungWanTeam`
-- ----------------------------
DROP TABLE IF EXISTS `fungWanTeam`;
CREATE TABLE `fungWanTeam` (
  `id` bigint(20) NOT NULL COMMENT '战队ID',
  `passWd` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '战队密码',
  `playerId` bigint(20) NOT NULL COMMENT '队长id',
  `rank` int(11) NOT NULL DEFAULT '0' COMMENT '排名',
  `section` int(11) NOT NULL DEFAULT '0' COMMENT '赛段ID',
  `signUp` tinyint(3) NOT NULL DEFAULT '0' COMMENT '报名状态：0-未报名  1-已报名',
  `teamName` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT '战队名称',
  `warZone` int(11) NOT NULL DEFAULT '0' COMMENT '战区ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- ----------------------------
-- Table structure for `fungWanTeamServer`
-- ----------------------------
DROP TABLE IF EXISTS `fungWanTeamServer`;
CREATE TABLE `fungWanTeamServer` (
  `id` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT '主键id',
  `dayRefresh` datetime DEFAULT NULL COMMENT '每天刷新时间',
  `eggs` int(11) NOT NULL DEFAULT '0' COMMENT '当天塞蛋数',
  `flowers` int(11) NOT NULL DEFAULT '0' COMMENT '当天献花数',
  `members` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '成员信息',
  `qualifierRank` int(11) NOT NULL DEFAULT '0' COMMENT '排名',
  `rank` int(11) NOT NULL DEFAULT '0' COMMENT '排名',
  `section` int(11) NOT NULL DEFAULT '0' COMMENT '赛段ID',
  `supports` int(11) NOT NULL DEFAULT '0' COMMENT '当天支持数',
  `teamInfos` longtext COLLATE utf8_unicode_ci COMMENT '队伍信息',
  `warZone` int(11) NOT NULL DEFAULT '0' COMMENT '战区ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- ----------------------------
-- Table structure for `fungWanValue`
-- ----------------------------
DROP TABLE IF EXISTS `fungWanValue`;
CREATE TABLE `fungWanValue` (
  `id` int(11) NOT NULL COMMENT '主键id',
  `info` longtext COLLATE utf8_unicode_ci COMMENT '信息',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `playerFungWan`
-- ----------------------------
DROP TABLE IF EXISTS `playerFungWan`;
CREATE TABLE `playerFungWan` (
  `playerId` bigint(20) NOT NULL COMMENT '角色id',
  `betLog` text COLLATE utf8_unicode_ci COMMENT '玩家押注信息',
  `dataUpdateCdEnd` bigint(20) NOT NULL DEFAULT '0' COMMENT '本人数据更新冷却结束时间（ms）',
  `dayRefresh` datetime DEFAULT NULL COMMENT '每天刷新时间',
  `eggs` int(11) NOT NULL DEFAULT '0' COMMENT '当天免费塞蛋数',
  `flowers` int(11) NOT NULL DEFAULT '0' COMMENT '当天免费献花数',
  `globalRewardLog` text COLLATE utf8_unicode_ci COMMENT '冠军队伍全服奖励领取记录',
  `lastAbility` double DEFAULT '0' COMMENT '上次更新的战斗力',
  `lastActTime` datetime DEFAULT '2013-01-01 00:00:00' COMMENT '最后领取冠军队伍全服奖励时间',
  `promotedRewardLog` text COLLATE utf8_unicode_ci COMMENT '晋级奖励记录',
  `quitTeamCdEnd` bigint(20) NOT NULL DEFAULT '0' COMMENT '退出战队冷却结束时间（ms）',
  `respectLog` text COLLATE utf8_unicode_ci COMMENT '参拜记录',
  `score` int(11) NOT NULL DEFAULT '0' COMMENT '积分',
  `signUpReady` tinyint(3) NOT NULL DEFAULT '0' COMMENT '报名状态：0-未准备  1-已准备',
  `support` tinyint(3) NOT NULL DEFAULT '0' COMMENT '当天是否已支持 0-未支持  1-已支持',
  `teamId` bigint(20) NOT NULL DEFAULT '0' COMMENT '战队ID',
  `toastDay` varchar(12) NULL DEFAULT '20100101' COMMENT '敬酒日期, 格式：yyyyMMdd',
  PRIMARY KEY (`playerId`),
  KEY `playerFungWan_idx_teamId` (`teamId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

DROP TABLE IF EXISTS `playerBejeweled`;
CREATE TABLE `playerBejeweled` (
  `id` bigint(20) NOT NULL COMMENT '玩家id',
  `addMoveTimes` int(11) DEFAULT NULL COMMENT '增加步数的次数',
  `boxLevel` tinyint(4) DEFAULT '1' COMMENT '宝箱品质',
  `curGoalInfo` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '当前目标',
  `nextGoalInfo` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT '下一个目标',
  `refreshTime` datetime DEFAULT NULL COMMENT '每日刷新时间',
  `score` int(11) DEFAULT NULL COMMENT '分数',
  `takenMoves` int(11) DEFAULT NULL COMMENT '已走步数',
  `weeklyRefreshTime` datetime DEFAULT NULL COMMENT '每周刷新时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `chargeDrawInfo`
-- ----------------------------
DROP TABLE IF EXISTS `chargeDrawInfo`;
CREATE TABLE `chargeDrawInfo` (
  `id` int(11) NOT NULL COMMENT '主键',
  `activityTime` datetime DEFAULT '2014-01-01 00:00:00' COMMENT '活动时间',
  `logContent` text COLLATE utf8_unicode_ci NOT NULL COMMENT '日志内容',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `playerChargeDraw`
-- ----------------------------
DROP TABLE IF EXISTS `playerChargeDraw`;
CREATE TABLE `playerChargeDraw` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `simpleAttributes` text COLLATE utf8_unicode_ci COMMENT '自定义属性',
  `activityTime` datetime DEFAULT '2014-01-01 00:00:00' COMMENT '活动时间',
  `balance` int(11) NOT NULL COMMENT '当天余额',
  `hadDrawTimes` int(11) NOT NULL COMMENT '已经抽奖次数',
  `lastChargeTime` datetime DEFAULT '2014-01-01 00:00:00' COMMENT '最后充值的时间',
  `lastDrawTime` datetime DEFAULT '2014-01-01 00:00:00' COMMENT '最后抽奖时间',
  `remainderDrawTimes` int(11) NOT NULL COMMENT '剩余抽奖次数',
  `winDrawTimes` int(11) NOT NULL COMMENT '当天获得的抽奖次数',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `playerCurrentHonor`
-- ----------------------------
DROP TABLE IF EXISTS `playerCurrentHonor`;
CREATE TABLE `playerCurrentHonor` (
  `playerId` bigint(20) NOT NULL COMMENT '玩家id',
  `honorId` int(11) DEFAULT '-1' COMMENT '称号基础id',
  PRIMARY KEY (`playerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `playerHonor`
-- ----------------------------
DROP TABLE IF EXISTS `playerHonor`;
CREATE TABLE `playerHonor` (
  `id` char(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '玩家id_称号基础id',
  `honorId` int(11) NOT NULL COMMENT '称号基础id',
  `ownedTime` datetime DEFAULT '2014-01-01 00:00:00' COMMENT '达成称号的时间',
  `playerId` bigint(20) NOT NULL COMMENT '玩家id',
  `status` tinyint(4) DEFAULT '0' COMMENT '称号状态 0-未获得  1-新获得  2-已获得',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `playerDeposit`
-- ----------------------------
DROP TABLE IF EXISTS `playerDeposit`;
CREATE TABLE `playerDeposit` (
  `id` bigint(20) NOT NULL COMMENT '玩家id',
  `simpleAttributes` text COLLATE utf8_unicode_ci COMMENT '自定义属性',
  `activityTime` datetime DEFAULT '2014-01-01 00:00:00' COMMENT '参加活动时间',
  `chargeMoney` int(11) DEFAULT '0' COMMENT '充值金额',
  `consumeMoney` int(11) DEFAULT '0' COMMENT '消费金额',
  `consumeTime` datetime DEFAULT '2014-01-01 00:00:00' COMMENT '消费时间',
  `depositId` int(11) NOT NULL COMMENT '存款类型id',
  `jsonStarRewards` text COLLATE utf8_unicode_ci COMMENT '已领奖励id列表 ',
  `status` tinyint(4) DEFAULT '0' COMMENT '取款状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `playerMonarchFeast`
-- ----------------------------
DROP TABLE IF EXISTS `playerMonarchFeast`;
CREATE TABLE `playerMonarchFeast` (
  `id` bigint(20) NOT NULL COMMENT '玩家id',
  `simpleAttributes` text COLLATE utf8_unicode_ci COMMENT '自定义属性',
  `activityTime` datetime DEFAULT '2014-01-01 00:00:00' COMMENT '参加活动时间',
  `chargeMoney` int(11) DEFAULT '0' COMMENT '充值金额',
  `consumeMoney` int(11) DEFAULT '0' COMMENT '消费金额',
  `consume` int(11) DEFAULT '0' COMMENT '消费',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `playerBureau`
-- ----------------------------
DROP TABLE IF EXISTS `playerBureau`;
CREATE TABLE `playerBureau` (
  `playerId` bigint(20) NOT NULL COMMENT '玩家id',
  `exp` int(11) NOT NULL COMMENT '衣柜经验',
  `fashionEquipId` int(11) NOT NULL COMMENT '当前穿戴的时装id',
  `level` int(11) NOT NULL COMMENT '衣柜等级',
  PRIMARY KEY (`playerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `playerFashionEquip`
-- ----------------------------
DROP TABLE IF EXISTS `playerFashionEquip`;
CREATE TABLE `playerFashionEquip` (
  `id` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT '主键id',
  `expireTime` datetime DEFAULT NULL COMMENT '到期时间',
  `fashionEquipId` int(11) NOT NULL COMMENT '时装id',
  `playerId` bigint(20) NOT NULL COMMENT '玩家id',
  `validType` int(11) NOT NULL COMMENT '时装有效期类型，-1表示永久有效',
  `status` int(11) NOT NULL COMMENT '1表示过期',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;



-- 这个语句保留到最后一行（方便修改）
INSERT INTO `kFChampionInfo` VALUES (1, '{\"port\":8001,\"ip\":\"61.153.99.248\"}');
INSERT INTO `kfLootValue` VALUES (1, '{\"port\":8001,\"ip\":\"61.153.99.248\"}');
INSERT INTO `fungWanValue` VALUES (1, '{\"port\":8001,\"ip\":\"61.153.99.248\"}');
