-- ----------------------------
-- Table structure for `playerCurrentHonor`
-- ----------------------------
CREATE TABLE IF NOT EXISTS `playerCurrentHonor` (
  `playerId` bigint(20) NOT NULL COMMENT '玩家id',
  `honorId` int(11) DEFAULT '-1' COMMENT '称号基础id',
  PRIMARY KEY (`playerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `playerHonor`
-- ----------------------------
CREATE TABLE IF NOT EXISTS `playerHonor` (
  `id` char(50) COLLATE utf8_unicode_ci NOT NULL COMMENT '玩家id_称号基础id',
  `honorId` int(11) NOT NULL COMMENT '称号基础id',
  `ownedTime` datetime DEFAULT '2014-01-01 00:00:00' COMMENT '达成称号的时间',
  `playerId` bigint(20) NOT NULL COMMENT '玩家id',
  `status` tinyint(4) DEFAULT '0' COMMENT '称号状态 0-未获得  1-新获得  2-已获得',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `playerMonarchFeast`
-- ----------------------------
CREATE TABLE IF NOT EXISTS `playerMonarchFeast` (
  `id` bigint(20) NOT NULL COMMENT '玩家id',
  `simpleAttributes` text COLLATE utf8_unicode_ci COMMENT '自定义属性',
  `activityTime` datetime DEFAULT '2014-01-01 00:00:00' COMMENT '参加活动时间',
  `chargeMoney` int(11) DEFAULT '0' COMMENT '充值金额',
  `consumeMoney` int(11) DEFAULT '0' COMMENT '消费金额',
  `consume` int(11) DEFAULT '0' COMMENT '消费',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `playerBureau`
-- ----------------------------
CREATE TABLE IF NOT EXISTS `playerBureau` (
  `playerId` bigint(20) NOT NULL COMMENT '玩家id',
  `exp` int(11) NOT NULL COMMENT '衣柜经验',
  `fashionEquipId` int(11) NOT NULL COMMENT '当前穿戴的时装id',
  `level` int(11) NOT NULL COMMENT '衣柜等级',
  PRIMARY KEY (`playerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Table structure for `playerFashionEquip`
-- ----------------------------
CREATE TABLE IF NOT EXISTS `playerFashionEquip` (
  `id` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT '主键id',
  `expireTime` datetime DEFAULT NULL COMMENT '到期时间',
  `fashionEquipId` int(11) NOT NULL COMMENT '时装id',
  `playerId` bigint(20) NOT NULL COMMENT '玩家id',
  `validType` int(11) NOT NULL COMMENT '时装有效期类型，-1表示永久有效',
  `status` int(11) NOT NULL COMMENT '1表示过期',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

ALTER TABLE `playerFungWan`
ADD COLUMN `toastDay` varchar(12) NULL DEFAULT '20100101' COMMENT '敬酒日期, 格式：yyyyMMdd' AFTER `teamId`;
