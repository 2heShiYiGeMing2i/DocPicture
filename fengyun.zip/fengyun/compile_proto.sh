protoc --java_out=src/main/java --proto_path=protobuf:shared_protobuf:cluster_protobuf protobuf/*.proto shared_protobuf/*.proto cluster_protobuf/*.proto
