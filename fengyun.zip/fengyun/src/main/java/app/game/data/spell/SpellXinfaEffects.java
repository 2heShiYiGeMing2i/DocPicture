package app.game.data.spell;

import static com.mokylin.sink.util.Preconditions.checkArgument;

import java.util.Collection;
import java.util.List;

import app.game.data.GameObjects;

import com.google.inject.Inject;
import com.mokylin.collection.IntHashMap;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class SpellXinfaEffects{

    public static final String LOCATION = GameObjects.SPELL_BASE_FOLDER
            + "xinfa.txt";

    /**
     * 存所有技能第一级, key是spellType
     */
    final IntHashMap<SpellXinfaEffect> map;

    @Inject
    SpellXinfaEffects(GameObjects go, PassiveSpells spells){

        List<ObjectParser> data = go.loadFile(LOCATION);

        map = new IntHashMap<>(data.size());

        for (ObjectParser p : data){
            SpellXinfaEffect ps = new SpellXinfaEffect(p, spells);
            checkArgument(map.putIfAbsent(ps.id, ps) == null, "技能心法id冲突: %s",
                    ps);
        }
    }

    public SpellXinfaEffect get(int id){
        return map.get(id);
    }

    Collection<SpellXinfaEffect> all(){
        return map.values();
    }
}
