/**
 * 
 */
package app.game.data;

import static com.mokylin.sink.util.Preconditions.checkArgument;
import static com.mokylin.sink.util.Preconditions.checkNotNull;

import java.util.List;

import app.protobuf.ConfigContent.Config;
import app.utils.VariableConfig;

import com.google.inject.Inject;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 * 
 */
public class HeroLevelDatas{

    private static final String LOCATION = "config/data/hero_level.txt";

    private final HeroLevelData[] levelDatas;

    @Inject
    HeroLevelDatas(GameObjects go, SpriteStats spriteStats,
            VariableConfig config){
        levelDatas = new HeroLevelData[VariableConfig.HERO_MAX_LEVEL];

        List<ObjectParser> data = go.loadFile(LOCATION);
        for (ObjectParser p : data){
            HeroLevelData levelData = new HeroLevelData(p, spriteStats, config);

            checkArgument(levelDatas[levelData.level - 1] == null,
                    "英雄等级数据存在重复的数据，重复数据等级level: %s", levelData.level);

            levelDatas[levelData.level - 1] = levelData;
        }

        HeroLevelData previousLevel = null;
        for (int i = 0; i < VariableConfig.HERO_MAX_LEVEL; i++){
            HeroLevelData levelData = checkNotNull(levelDatas[i],
                    "英雄%s 级的等级数据没找到", i + 1);

            if (i > 0){
                previousLevel.nextLevel = levelData;
            }
            previousLevel = levelData;
        }
    }

    public HeroLevelData get(int level){
        return Utils.getValidObject(levelDatas, level - 1);
    }

    public void encode(Config.Builder config, VariableConfig variableConfig){
        config.setOfflineExp3Yuanbao(variableConfig.OFFLINE_EXP_3_COLLECT_YUANBAO);
        for (HeroLevelData data : levelDatas){
            config.addOfflineExpPerMinuteByLevel(data.getOfflineExp());
        }
    }
}
