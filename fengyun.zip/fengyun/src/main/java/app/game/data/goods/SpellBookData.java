/**
 * 
 */
package app.game.data.goods;

import static app.game.module.GoodsContainerMessages.*;
import static app.game.module.SuperWeaponMessages.buySuperWeaponMsg;
import static com.mokylin.sink.util.Preconditions.*;

import org.jboss.netty.buffer.ChannelBuffer;

import app.cluster.client.combat.scene.ILocalClusterScene;
import app.cluster.shared.scene.ClusterSceneHeader;
import app.game.data.GameObjects;
import app.game.data.SpriteStat;
import app.game.data.mount.HeroMount;
import app.game.data.mount.MountData;
import app.game.data.pet.HeroPet;
import app.game.data.pet.HeroTianJie;
import app.game.data.pet.HeroTianZui;
import app.game.data.pet.PetLevelData;
import app.game.data.pet.TianJieData;
import app.game.data.pet.TianZuiData;
import app.game.data.spell.PassiveSpell;
import app.game.data.spell.PassiveSpellList;
import app.game.data.spell.SingleEffectSpell.SingleEffectSpellWithUsedTimes;
import app.game.data.spell.Spell;
import app.game.data.spell.Spells;
import app.game.data.weapon7.HeroSuperWeapon;
import app.game.data.weapon7.SuperWeaponData;
import app.game.entity.Hero;
import app.game.entity.SpellList;
import app.game.module.MountMessages;
import app.game.module.PetMessages;
import app.game.module.scene.HeroFightModule;
import app.game.module.scene.IScene;
import app.message.ISender;
import app.protobuf.GoodsContent.SpellBookDataProto;
import app.protobuf.GoodsContent.SpellBookDataProto.SpellType;
import app.protobuf.GoodsServerContent.GoodsType;
import app.utils.VariableConfig;

import com.google.protobuf.ByteString;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * 技能书
 * 
 * @author Liwei
 * 
 */
public class SpellBookData extends GoodsData{

    static final String LOCATION = GameObjects.GOODS_BASE_LOCATION
            + "spell_book.txt";

    final SpellType type;

    /**
     * 需要几阶系统阶数才能学习（坐骑技能就是坐骑阶数）
     */
    final int requiredObjectLevel;

    /**
     * 产出说明
     */
    final String outputDesc;

    private final SpellBookDataProto proto;

    private final byte[] protoBytes;

    private final ByteString protoByteString;

    private final Efficacy efficacy;

    SpellBookData(ObjectParser p){
        super(p, GoodsType.SPELL_BOOK);

        String spellParam = p.getKey("spell");

        SpellType spType = null;
        int spellId = 0;
        for (SpellType type : SpellType.values()){
            int idx = spellParam.indexOf(type.name());

            if (idx >= 0){
                idx += type.name().length();
                spType = type;

                if (idx + 1 < spellParam.length()){
                    spellId = Integer.parseInt(spellParam.substring(idx + 1)); // 中间有个分号
                }
                break;
            }
        }

        type = checkNotNull(spType, "%s 配置的技能类型无效，param: %s", this, spellParam);

        requiredObjectLevel = p.getIntKey("required_object_level");

        outputDesc = p.getKey("output_desc");

        switch (type){
            case HERO:{
                efficacy = new LearnHeroSpellEfficacy(this, spellId);
                break;
            }
            case MOUNT:{
                efficacy = new LearnMountSpellEfficacy(requiredObjectLevel,
                        spellId);
                break;
            }
            case SUPER_WEAPON:{
                efficacy = new LearnSuperWeaponSpellEfficacy(
                        requiredObjectLevel);
                break;
            }
            case PET:{
                efficacy = new LearnPetSpellEfficacy(spellId,
                        requiredObjectLevel);
                break;
            }
            case TIAN_JIE:{
                efficacy = new LearnTianJieSpellEfficacy(requiredObjectLevel,
                        spellId);
                break;
            }
            case TIAN_ZUI:{
                efficacy = new LearnTianZuiSpellEfficacy(requiredObjectLevel,
                        spellId);
                break;
            }
            default:{
                throw new IllegalArgumentException(this + " 技能书类型还不支持, 类型："
                        + type);
            }
        }

        proto = build();
        protoBytes = processProtoBytes(proto.toByteArray());
        protoByteString = ByteString.copyFrom(protoBytes);
    }

    void initSpell(Spells spells){
        if (efficacy instanceof InitSpell){
            ((InitSpell) efficacy).initSpell(spells);
        }
    }

    private SpellBookDataProto build(){
        SpellBookDataProto.Builder builder = SpellBookDataProto.newBuilder();
        builder.setBaseData(encode());
        builder.setType(type);

        if (requiredObjectLevel > 0){
            builder.setRequiredObjectLevel(requiredObjectLevel);
        }

        if (!outputDesc.isEmpty()){
            builder.setOutputDesc(outputDesc);
        }

        return builder.build();
    }

    public SpellBookDataProto getProto(){
        return proto;
    }

    @Override
    public byte[] getProtoBytes(){
        return protoBytes;
    }

    @Override
    public ByteString getProtoByteString(){
        return protoByteString;
    }

    @Override
    public int getAuctionType(){
        switch (type){
            case MOUNT:{
                return 72;
            }
            case PET:{
                return 73;
            }
            case TIAN_JIE:{
                return 74;
            }
            case TIAN_ZUI:{
                return 75;
            }
            case SUPER_WEAPON:{
                return 76;
            }
            case HERO:{
                return 77;
            }
            // 其他类型 TODO
            default:{
                return 7;
            }
        }
    }

    @Override
    public Efficacy getEfficacy(){
        return efficacy;
    }

    private static interface InitSpell{
        void initSpell(Spells spells);
    }

    private static class LearnHeroSpellEfficacy implements Efficacy, InitSpell{

        private final SpellBookData data;

        private final int spellId;

        private Spell spell;

        LearnHeroSpellEfficacy(SpellBookData data, int spellId){
            this.data = data;
            this.spellId = spellId;
        }

        @Override
        public void initSpell(Spells spells){

            spell = checkNotNull(spells.get(spellId),
                    "%s 配置的英雄技能没找到, param: %s", data, spellId);

            checkArgument(spell.spellCategory == Spell.HERO_SPELL_CATEGORY,
                    "%s 是英雄技能，但是配置技能的分类不是英雄技能", data);

            checkArgument(data == spell.getSpellBook(),
                    "%s 是英雄技能书，但是技能上配置的技能书不是这个， 技能上配置的: %s", data,
                    spell.getSpellBook());
        }

        @Override
        public int useTo(HeroFightModule heroFightModule, int useCount,
                long ctime, String iEventId){

            Hero hero = heroFightModule.getHero();
            ISender sender = heroFightModule.getSender();

            if (spell.race != 0 && spell.race != hero.getRaceId()){
                logger.debug("学习英雄技能书，但是英雄技能职业跟英雄职业不符");
                sender.sendMessage(ERR_USE_SPELL_BOOK_FAIL_INVALID_RACE);
                return 0;
            }

            SpellList spellList = hero.getSpellList();

            Spell sp = null;
            if (spell instanceof PassiveSpell){
                sp = spellList.getPassiveSpell(spell.spellType);
            } else{
                SingleEffectSpellWithUsedTimes currentSpell = spellList
                        .getSingleEffectSpell(spell.spellType);

                if (currentSpell != null){
                    sp = currentSpell.getActualSpell();
                }
            }

            if (sp == null){
                if (spell.getSpellLevel() > 1){
                    logger.debug("学习英雄技能书，但是英雄没有学会前置技能");
                    sender.sendMessage(ERR_USE_SPELL_BOOK_FAIL_PREV_SPELL_NOT_LEARNED);
                    return 0;
                }
            } else{
                if (sp.getNextLevel() != spell){
                    if (sp.getSpellLevel() >= spell.getSpellLevel()){
                        logger.debug("学习英雄技能书，但是英雄已经学会这个技能了");
                        sender.sendMessage(ERR_USE_SPELL_BOOK_FAIL_HAS_LEARNED);
                    } else{
                        logger.debug("学习英雄技能书，但是英雄没有学会前置技能");
                        sender.sendMessage(ERR_USE_SPELL_BOOK_FAIL_PREV_SPELL_NOT_LEARNED);
                    }
                    return 0;
                }
            }

            heroFightModule.getServices().getModules().spellModule
                    .doLearnOrUpgradeActiveSpell(heroFightModule, spell, ctime,
                            iEventId);

            return 1; // 技能书，每次使用一个
        }
    }

    private static class LearnMountSpellEfficacy implements Efficacy, InitSpell{

        private final int requiredMount;

        private final int spellId;

        private PassiveSpell spell;

        private transient ChannelBuffer[] learnSpellMsgs;

        LearnMountSpellEfficacy(int requiredMount, int spellId){
            this.requiredMount = requiredMount;
            this.spellId = spellId;
        }

        @Override
        public void initSpell(Spells spells){

            spell = checkNotNull(spells.getPassiveSpells().get(spellId),
                    "%s 配置的坐骑技能没找到, param: %s", spellId);

            checkArgument(spell.spellCategory == Spell.MOUNT_SPELL_CATEGORY,
                    "%s 是坐骑技能，但是配置技能的分类不是坐骑技能", this);

            checkArgument(spell.race == 0, "%s 是坐骑技能，但是有职业限制, race: %s", this,
                    spell.race);

            byte[] data = spell.getProto().toByteArray();

            learnSpellMsgs = new ChannelBuffer[VariableConfig.MOUNT_SPELL_SLOT_MAX_COUNT];
            for (int i = 0; i < learnSpellMsgs.length; i++){
                learnSpellMsgs[i] = MountMessages.learnSpellMsg(i, data);
            }
        }

        @Override
        public int useTo(HeroFightModule heroFightModule, int useCount,
                long ctime, String iEventId){
            assert spell != null: "技能书学习时，spell == null";
            assert learnSpellMsgs != null
                    && learnSpellMsgs.length == VariableConfig.MOUNT_SPELL_SLOT_MAX_COUNT: "技能书学习时， learnSpellMsgs错误";

            Hero hero = heroFightModule.getHero();
            ISender sender = heroFightModule.getSender();

            HeroMount mount = hero.getMount();

            if (mount == null){
                logger.warn("学习坐骑技能书，但是英雄还没有坐骑");
                sender.sendMessage(ERR_USE_SPELL_BOOK_FAIL_NOT_MOUNT);
                return 0;
            }

            MountData data = mount.getBestMount();
            if (data.getId() < requiredMount){
                logger.warn("学习坐骑技能书，但是坐骑等级不足");
                sender.sendMessage(ERR_USE_SPELL_BOOK_FAIL_MOUNT_LEVEL_NOT_ENOUGH);
                return 0;
            }

            if (data.getSpellSlotCount() <= 0){
                logger.warn("学习坐骑技能书，但是坐骑技能格子<=0");
                sender.sendMessage(ERR_USE_SPELL_BOOK_FAIL_NOT_MOUNT_SLOT);
                return 0;
            }

            // 随机一个位置，将技能放到这个位置上
            int pos = data.randomSpellSlot();
            assert pos >= 0 && pos < data.getSpellSlotCount();

            // 获取更新技能之前的值
            SpriteStat mountStat = mount.getTotalStat();
            int mountFightingAmount = mount.getFightingAmount();

            // 替换坐骑技能
            PassiveSpell toRemove = mount.replace(pos, spell);
            sender.sendMessage(learnSpellMsgs[pos]);

            heroFightModule.getRankObject().onMountUpdate(hero);

            int removeSpellId = 0;
            if (toRemove != null){
                removeSpellId = toRemove.spellType;
            }

            heroFightModule.getServices().getLogService().todo();
//            heroFightModule
//                    .getServices()
//                    .getLogService()
//                    .writeOperateLog(GOODS_USE, MOUNT_SPELL, pos, 0,
//                            removeSpellId, spell.spellType, 0, hero);

            // 骑着马
            if (mount.isValid() && toRemove != spell){

                PassiveSpellList spellList = heroFightModule
                        .getPassiveSpellList();

                spellList.add(spell);
                if (toRemove != null){
                    spellList.remove(toRemove);

                    IScene parent = heroFightModule.getParent();
                    if (parent instanceof ILocalClusterScene){
                        ILocalClusterScene localScene = (ILocalClusterScene) parent;
                        localScene.sendToRemoteScene(ClusterSceneHeader.S2C
                                .replacePassiveSpell(localScene.getSceneUUID(),
                                        hero.getID(), toRemove.id, spell.id));
                    }
                } else{
                    IScene parent = heroFightModule.getParent();
                    if (parent instanceof ILocalClusterScene){
                        ILocalClusterScene localScene = (ILocalClusterScene) parent;
                        localScene.sendToRemoteScene(ClusterSceneHeader.S2C
                                .addPassiveSpellMsg(localScene.getSceneUUID(),
                                        hero.getID(), spell.id));
                    }
                }
                spellList.onSpellChanged();

                if (mountStat != mount.getTotalStat()){
                    // 变更属性
                    heroFightModule.changeBaseStat(mountStat,
                            mount.getTotalStat(), ctime);
                }

                if (mountFightingAmount != mount.getFightingAmount()){
                    // 更新战斗力
                    heroFightModule.updateFightingAmount();
                }
            }

            return 1; // 技能书，每次使用一个
        }
    }

    public static class LearnSuperWeaponSpellEfficacy implements Efficacy{

        private final int weaponIndex;

        private SuperWeaponData data;

        LearnSuperWeaponSpellEfficacy(int weapon){
//            this.weapon = weapon;

            checkArgument(weapon > 0
                    && weapon <= VariableConfig.SUPER_WEAPON_COUNT,
                    "神兵技能中配置的神兵id无效[1-7], weapon: %s", weapon);

            weaponIndex = weapon - 1;
        }

        public void initSuperWeapon(SuperWeaponData data){
            this.data = data;
        }

        @Override
        public int useTo(HeroFightModule heroFightModule, int useCount,
                long ctime, String iEventId){
            Hero hero = heroFightModule.getHero();
            ISender sender = heroFightModule.getSender();

            HeroSuperWeapon[] weapons = hero.getSuperWeapons();
            HeroSuperWeapon weapon = weapons[weaponIndex];

            if (weapon != null && weapon.hasUnlockSoul()){
                logger.warn("学习神兵心法技能书，但是英雄已经学习过了这个神兵心法");
                sender.sendMessage(ERR_USE_SPELL_BOOK_FAIL_WEAPON_HAS_LEARNED);
                return 0;
            } else{

            }

            if (data == null){
                // 防御性
                logger.error("学习神兵心法技能书，data == null");
                sender.sendMessage(ERR_USE_GOODS_CAN_NOT_TO_USE);
                return 0;
            }

            if (weapon == null){
                weapons[weaponIndex] = weapon = data.newWeapon();
            }

            weapon.setUnlockSoul();
            sender.sendMessage(buySuperWeaponMsg(weapon.encode4Client()));

            return 1; // 技能书，每次使用一个
        }
    }

    private static class LearnPetSpellEfficacy implements Efficacy, InitSpell{

        private final int spellId;

        private final int requiredLevel;

        private PassiveSpell spell;

        private transient ChannelBuffer[] learnSpellMsgs;

        LearnPetSpellEfficacy(int spellId, int requiredLevel){
            this.spellId = spellId;
            this.requiredLevel = requiredLevel;
        }

        @Override
        public void initSpell(Spells spells){

            spell = checkNotNull(spells.getPassiveSpells().get(spellId),
                    "%s 配置的宠物技能没找到, param: %s", this, spellId);

            checkArgument(spell.spellCategory == Spell.PET_SPELL_CATEGORY,
                    "%s 是宠物技能，但是配置技能的分类不是宠物技能", this);

            checkArgument(spell.race == 0, "%s 是宠物技能，但是有职业限制, race: %s", this,
                    spell.race);

            byte[] data = spell.getProto().toByteArray();

            learnSpellMsgs = new ChannelBuffer[VariableConfig.PET_SPELL_SLOT_MAX_COUNT];
            for (int i = 0; i < learnSpellMsgs.length; i++){
                learnSpellMsgs[i] = PetMessages.learnSpellMsg(i, data);
            }
        }

        @Override
        public int useTo(HeroFightModule heroFightModule, int useCount,
                long ctime, String iEventId){

            Hero hero = heroFightModule.getHero();

            if (hero.getLevel() < requiredLevel){
                heroFightModule.sendMessage(ERR_USE_GOODS_LEVEL_NOT_ENOUGH);
                return 0;
            }

            HeroPet pet = hero.getPet();

            if (pet == null){
                logger.warn("学习宠物技能书，但是英雄还没有坐骑");
                heroFightModule
                        .sendMessage(ERR_USE_SPELL_BOOK_FAIL_NOT_PET_OR_SLOT);
                return 0;
            }

            PetLevelData data = pet.getData();
            if (data.getSpellSlotCount() <= 0){
                logger.warn("学习宠物技能书，但是技能格子<=0");
                heroFightModule
                        .sendMessage(ERR_USE_SPELL_BOOK_FAIL_NOT_PET_OR_SLOT);
                return 0;
            }

            // 随机一个位置，将技能放到这个位置上
            int pos = data.randomSpellSlot();
            assert pos >= 0 && pos < data.getSpellSlotCount();

            // 替换坐骑技能
            PassiveSpell toRemove = pet.replace(pos, spell);
            heroFightModule.sendMessage(learnSpellMsgs[pos]);

            int removeSpellId = 0;
            if (toRemove != null){
                removeSpellId = toRemove.spellType;
            }

            IScene parent = heroFightModule.getParent();
            if (parent instanceof ILocalClusterScene){
                ILocalClusterScene localScene = (ILocalClusterScene) parent;
                localScene.sendToRemoteScene(ClusterSceneHeader.S2C
                        .changePetSpellMsg(localScene.getSceneUUID(),
                                hero.getID(), pos, spellId));
            }

            heroFightModule.getServices().getLogService().todo();
//            heroFightModule
//                    .getServices()
//                    .getLogService()
//                    .writeOperateLog(GOODS_USE, PET_SPELL, pos, 0,
//                            removeSpellId, spell.spellType, 0, hero);

            return 1; // 技能书，每次使用一个
        }
    }

    private static class LearnTianJieSpellEfficacy implements Efficacy,
            InitSpell{

        private final int requiredTianJie;

        private final int spellId;

        private PassiveSpell spell;

        private transient ChannelBuffer[] learnSpellMsgs;

        LearnTianJieSpellEfficacy(int requiredTianJie, int spellId){
            this.requiredTianJie = requiredTianJie;
            this.spellId = spellId;
        }

        @Override
        public void initSpell(Spells spells){

            spell = checkNotNull(spells.getPassiveSpells().get(spellId),
                    "%s 配置的天劫技能没找到, param: %s", this, spellId);

            checkArgument(spell.spellCategory == Spell.TIAN_JIE_SPELL_CATEGORY,
                    "%s 是天劫技能，但是配置技能的分类不是天劫技能", this);

            checkArgument(spell.race == 0, "%s 是天劫技能，但是有职业限制, race: %s", this,
                    spell.race);

            checkArgument(spell.isPropertyPassiveSpell(),
                    "%s 是天劫技能，但是配置技能不是加属性技能", this);

            byte[] data = spell.getProto().toByteArray();

            learnSpellMsgs = new ChannelBuffer[VariableConfig.TIAN_JIE_SPELL_SLOT_MAX_COUNT];
            for (int i = 0; i < learnSpellMsgs.length; i++){
                learnSpellMsgs[i] = PetMessages.learnTianJieSpellMsg(i, data);
            }
        }

        @Override
        public int useTo(HeroFightModule heroFightModule, int useCount,
                long ctime, String iEventId){

            Hero hero = heroFightModule.getHero();

            HeroTianJie tianjie = hero.getTianJie();

            if (tianjie == null){
                logger.warn("学习天劫技能书，但是英雄还没有天劫");
                heroFightModule
                        .sendMessage(ERR_USE_SPELL_BOOK_FAIL_NOT_TIAN_JIE_OR_SLOT);
                return 0;
            }

            TianJieData data = tianjie.getData();
            if (data.getId() < requiredTianJie){
                logger.warn("学习天劫技能书，但是天劫等级不足");
                heroFightModule
                        .sendMessage(ERR_USE_SPELL_BOOK_FAIL_NOT_TIAN_JIE_OR_SLOT);
                return 0;
            }

            if (data.getSpellSlotCount() <= 0){
                logger.warn("学习天劫技能书，但是技能格子<=0");
                heroFightModule
                        .sendMessage(ERR_USE_SPELL_BOOK_FAIL_NOT_TIAN_JIE_OR_SLOT);
                return 0;
            }

            // 随机一个位置，将技能放到这个位置上
            int pos = data.randomSpellSlot();
            assert pos >= 0 && pos < data.getSpellSlotCount();

            // 获取更新技能之前的值
            SpriteStat oldStat = tianjie.getTotalStat();
            int oldFightingAmount = tianjie.getFightingAmount();

            // 替换天劫技能
            PassiveSpell toRemove = tianjie.replace(pos, spell);
            heroFightModule.sendMessage(learnSpellMsgs[pos]);

            if (spell != toRemove){
                if (oldStat != tianjie.getTotalStat()){
                    // 变更属性
                    heroFightModule.changeBaseStat(oldStat,
                            tianjie.getTotalStat(), ctime);
                }

                if (oldFightingAmount != tianjie.getFightingAmount()){
                    // 更新战斗力
                    heroFightModule.updateFightingAmount();
                }

                heroFightModule.getRankObject().onTianjieUpdate(hero);
            }

            int removeSpellId = 0;
            if (toRemove != null){
                removeSpellId = toRemove.spellType;
            }

            heroFightModule.getServices().getLogService().todo();
//            heroFightModule
//                    .getServices()
//                    .getLogService()
//                    .writeOperateLog(GOODS_USE, TIAN_JIE_SPELL, pos, 0,
//                            removeSpellId, spell.spellType, 0, hero);

            return 1; // 技能书，每次使用一个
        }
    }

    private static class LearnTianZuiSpellEfficacy implements Efficacy,
            InitSpell{

        private final int requiredTianZui;

        private final int spellId;

        private PassiveSpell spell;

        private transient ChannelBuffer[] learnSpellMsgs;

        LearnTianZuiSpellEfficacy(int requiredTianZui, int spellId){
            this.requiredTianZui = requiredTianZui;
            this.spellId = spellId;
        }

        @Override
        public void initSpell(Spells spells){

            spell = checkNotNull(spells.getPassiveSpells().get(spellId),
                    "%s 配置的天罪技能没找到, param: %s", this, spellId);

            checkArgument(spell.spellCategory == Spell.TIAN_ZUI_SPELL_CATEGORY,
                    "%s 是天罪技能，但是配置技能的分类不是天罪技能", this);

            checkArgument(spell.race == 0, "%s 是天罪技能，但是有职业限制, race: %s", this,
                    spell.race);

            checkArgument(spell.isPropertyPassiveSpell(),
                    "%s 是天罪技能，但是配置技能不是加属性技能", this);

            byte[] data = spell.getProto().toByteArray();

            learnSpellMsgs = new ChannelBuffer[VariableConfig.TIAN_ZUI_SPELL_SLOT_MAX_COUNT];
            for (int i = 0; i < learnSpellMsgs.length; i++){
                learnSpellMsgs[i] = PetMessages.learnTianZuiSpellMsg(i, data);
            }
        }

        @Override
        public int useTo(HeroFightModule heroFightModule, int useCount,
                long ctime, String iEventId){

            Hero hero = heroFightModule.getHero();

            HeroTianZui tianzui = hero.getTianZui();

            if (tianzui == null){
                logger.warn("学习天罪技能书，但是英雄还没有天罪");
                heroFightModule
                        .sendMessage(ERR_USE_SPELL_BOOK_FAIL_NOT_TIAN_ZUI_OR_SLOT);
                return 0;
            }

            TianZuiData data = tianzui.getData();
            if (data.getId() < requiredTianZui){
                logger.warn("学习天罪技能书，但是天罪等级不足");
                heroFightModule
                        .sendMessage(ERR_USE_SPELL_BOOK_FAIL_NOT_TIAN_ZUI_OR_SLOT);
                return 0;
            }

            if (data.getSpellSlotCount() <= 0){
                logger.warn("学习天罪技能书，但是技能格子<=0");
                heroFightModule
                        .sendMessage(ERR_USE_SPELL_BOOK_FAIL_NOT_TIAN_ZUI_OR_SLOT);
                return 0;
            }

            // 随机一个位置，将技能放到这个位置上
            int pos = data.randomSpellSlot();
            assert pos >= 0 && pos < data.getSpellSlotCount();

            // 获取更新技能之前的值
            SpriteStat oldStat = tianzui.getTotalStat();
            int oldFightingAmount = tianzui.getFightingAmount();

            // 替换天罪技能
            PassiveSpell toRemove = tianzui.replace(pos, spell);
            heroFightModule.sendMessage(learnSpellMsgs[pos]);

            if (spell != toRemove){
                if (oldStat != tianzui.getTotalStat()){
                    // 变更属性
                    heroFightModule.changeBaseStat(oldStat,
                            tianzui.getTotalStat(), ctime);
                }

                if (oldFightingAmount != tianzui.getFightingAmount()){
                    // 更新战斗力
                    heroFightModule.updateFightingAmount();
                }

                heroFightModule.getRankObject().onTianzuiUpdate(hero);
            }

            int removeSpellId = 0;
            if (toRemove != null){
                removeSpellId = toRemove.spellType;
            }

            heroFightModule.getServices().getLogService().todo();
//            heroFightModule
//                    .getServices()
//                    .getLogService()
//                    .writeOperateLog(GOODS_USE, TIAN_ZUI_SPELL, pos, 0,
//                            removeSpellId, spell.spellType, 0, hero);

            return 1; // 技能书，每次使用一个
        }
    }
}
