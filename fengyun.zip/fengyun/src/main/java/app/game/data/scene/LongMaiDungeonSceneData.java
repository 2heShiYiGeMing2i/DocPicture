package app.game.data.scene;

import static com.mokylin.sink.util.Preconditions.*;

import java.util.List;

import org.jboss.netty.buffer.ChannelBuffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.cluster.client.combat.scene.LocalGroupDungeonScene;
import app.cluster.client.combat.scene.LocalLongMaiDungeonScene;
import app.cluster.combat.master.logic.scene.RemoteGroupDungeonScene;
import app.cluster.combat.master.logic.scene.RemoteLongMaiDungeonScene;
import app.game.data.GameObjects;
import app.game.data.Prize;
import app.game.data.PrizeConfigs;
import app.game.data.goods.GoodsDatas;
import app.game.data.goods.GoodsWrapper;
import app.game.entity.Hero;
import app.game.module.scene.FightData;
import app.game.module.scene.IClusterLocalDungeonService;
import app.game.module.scene.IDungeonService;
import app.game.module.scene.LongMaiLongMaiFightModule;
import app.message.ISender;
import app.protobuf.ConfigContent.LongMaiDungeonProto;
import app.protobuf.LogContent.LogEnum.SceneType;

import com.google.protobuf.ByteString;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.parse.ObjectParser;

public class LongMaiDungeonSceneData extends GroupDungeonSceneData{

    private static final Logger logger = LoggerFactory
            .getLogger(LongMaiDungeonSceneData.class);

    private static final String MON_LOCATION = GameObjects.LONG_MAI_SCENE_BASE_FOLDER
            + "mon.txt";

    /**
     * 首通奖励
     */
    private final GroupDungeonPrizeConfig dailyFirstPassPrizeConfig;

    /**
     * 非首通的奖励
     */
    private final Prize notFirstPassPrize;

    // --- 具体怪物配置 ---

    private final MonsterData longmaiMonsterData;
    private final int longmaiX;
    private final int longmaiY;
    private final ChannelBuffer removeLongMaiMsg;

    /**
     * 距离英雄多远后, 就满血去打龙脉
     */
    public final int maxTraceSteps;

    private final LongMaiBatchInfo[] batchInfos;

    private final int maxUsedMonsterID;

    LongMaiDungeonSceneData(GameObjects go, ObjectParser p, BlockInfos blocks,
            MonsterDatas monsters, Scripts scripts, Plunders plunders, Ais ais,
            SceneTransportDatas transports, GoodsDatas goodsDatas,
            PlunderGroups groups, PrizeConfigs prizes,
            SceneRemoveObjectMsgCache removeMsgCache){
        super(go, p, blocks, monsters, scripts, plunders, ais, transports,
                removeMsgCache);

        // 检查里面不能配有任何怪
        checkArgument(!hasRelivableMonster(), "守护龙脉副本 %s 不能在mon文件夹下配置任何怪物",
                this);
        checkArgument(!hasSingleLifeMonster(), "守护龙脉副本 %s 不能在mon文件夹下配置任何怪物",
                this);

        // --- 首通奖励 ---
        this.dailyFirstPassPrizeConfig = new GroupDungeonPrizeConfig(this, p,
                prizes, groups);

        // --- 非首通奖励 ---
        int normalPrizeExp = p.getIntKey("normal_prize_exp");
        int normalPrizeRealAir = p.getIntKey("normal_prize_real_air");
        int normalPrizeMoney = p.getIntKey("normal_prize_money");
        String[] normalPrizeGoods = p.getStringArray("normal_prize_goods");
        GoodsWrapper[] normalPrizeGoodsWrappers = GoodsWrapper.parse("守护龙脉奖励",
                goodsDatas, normalPrizeGoods);
        this.notFirstPassPrize = new Prize(normalPrizeExp, normalPrizeMoney,
                normalPrizeRealAir, 0, 0, normalPrizeGoodsWrappers);

        // 龙脉怪物
        String longMaiName = p.getKey("longmai_monster");
        this.longmaiMonsterData = checkNotNull(monsters.get(longMaiName),
                "没有找到守护龙脉的怪物: %s", longMaiName);
        this.removeLongMaiMsg = removeMsgCache.get(1);

        // 龙脉点
        this.longmaiX = p.getIntKey("longmai_x");
        this.longmaiY = p.getIntKey("longmai_y");
        checkArgument(blockInfo.isWalkable(longmaiX, longmaiY),
                "守护龙脉副本, 龙脉的坐标不可走: <%s, %s>", longmaiX, longmaiY);

        this.longmaiMonsterData.setScene(this,
                new int[]{Utils.short2Int(longmaiX, longmaiY)});

        // 刷怪点, 多个, 每个刷怪点配2个坐标
        int[] spawnX1 = p.getIntKeyArray("spawn_x1");
        int[] spawnY1 = p.getIntKeyArray("spawn_y1");
        checkArgument(spawnX1.length == spawnY1.length,
                "守护龙脉副本, 刷怪点spawn_x1 和spawn_y1 的个数不同");
        checkArgument(spawnX1.length > 0, "守护龙脉副本, 没有配置刷怪点 spawn_x1 spawn_y1");

        int[] spawnX2 = p.getIntKeyArray("spawn_x2");
        int[] spawnY2 = p.getIntKeyArray("spawn_y2");
        checkArgument(spawnX1.length == spawnX2.length,
                "守护龙脉副本, 刷怪点spawn_x1 和 spawn_x2 的个数不同");
        checkArgument(spawnY1.length == spawnY2.length,
                "守护龙脉副本, 刷怪点spawn_y1 和 spawn_y2 的个数不同");

        SpawnConfig[] spawnConfig = new SpawnConfig[spawnX1.length];

        for (int i = 0; i < spawnConfig.length; i++){
            spawnConfig[i] = new SpawnConfig(spawnX1[i], spawnY1[i],
                    spawnX2[i], spawnY2[i]);
        }

        // 怪物追击步数
        this.maxTraceSteps = p.getIntKey("max_trace_step");
        checkArgument(maxTraceSteps > 0, "守护龙脉怪物最大追击距离max_trace_step必须>0");

        // 加载怪物
        List<ObjectParser> monsterParsers = go.loadFile(MON_LOCATION);
        this.batchInfos = LongMaiBatchInfo.parse(spawnConfig, monsterParsers,
                monsters, removeMsgCache, this);

        // 最大使用的怪物id
        int maxMonID = 0;
        for (LongMaiBatchInfo b : batchInfos){
            maxMonID = Math.max(maxMonID, b.maxUsedMonsterID);
        }
        this.maxUsedMonsterID = maxMonID;
    }

    @Override
    public int getMaxUsedMonsterID(){
        return maxUsedMonsterID;
    }

    @Override
    public boolean canHeroEnterToday(Hero hero){
        return true;
    }

    public Prize getNotFirstPassPrize(){
        return notFirstPassPrize;
    }

    @Override
    public GroupDungeonPrizeConfig getPrizeConfig(){
        return dailyFirstPassPrizeConfig;
    }

    public LongMaiBatchInfo getBatch(int batch){
        return batchInfos[batch];
    }

    public int getBatchCount(){
        return batchInfos.length;
    }

    @Override
    public LocalGroupDungeonScene newLocalClusterScene(int uuid,
            IClusterLocalDungeonService dungeonService, ISender combatClient,
            long heroID){
        return new LocalLongMaiDungeonScene(this, uuid, dungeonService,
                combatClient, heroID);
    }

    @Override
    public RemoteGroupDungeonScene newRemoteClusterScene(int uuid,
            IDungeonService dungeonService, long creator, ISender worker){
        return new RemoteLongMaiDungeonScene(this, uuid, dungeonService,
                creator, worker);
    }

    public LongMaiLongMaiFightModule newLongMai(RemoteLongMaiDungeonScene parent){
        FightData fightData = new FightData(longmaiMonsterData.stat,
                longmaiMonsterData.level);
        fightData.setSceneIDAndPos(parent.getSceneID(), longmaiX, longmaiY);
        return new LongMaiLongMaiFightModule(1, longmaiMonsterData, fightData,
                parent, removeLongMaiMsg, parent.getPositionModuleSharedSync());
    }

    public LongMaiDungeonProto generateProto(){
        LongMaiDungeonProto.Builder builder = LongMaiDungeonProto.newBuilder();
        builder.setSceneId(id).setMap(blockName)
                .setName(ByteString.copyFrom(nameBytes)).setSound(sound);
        if (requiredLevel > 1){
            builder.setRequiredLevel(requiredLevel);
        }
        if (isHeroLevelProtect){
            builder.setIsHeroLevelProtect(true);
        }
        if (isNewHeroProtect){
            builder.setIsNewHeroProtect(true);
        }
        if (isDeathProtect){
            builder.setIsDeathProtect(true);
        }
        if (isNightAutoProtect){
            builder.setIsNightAutoProtect(true);
        }
        if (isJumpLimit){
            builder.setIsJumpLimit(true);
        }
        if (isMountLimit){
            builder.setIsMountLimit(true);
        }

        if (poet != null){
            String tp = poet.trim();
            if (tp.length() > 0){
                builder.setPoet(ByteString.copyFromUtf8(tp));
            }
        }
        if (fixedPkMode != null){
            builder.setFixedPkMode(fixedPkMode.getIntMode());
        }

        if (reliveOutOfDungeon){
            builder.setIsDeathReturnTown(true);
        }

        builder.setMinHeroCount(minHeroCount).setMaxHeroCount(maxHeroCount)
                .setRecommendedFightAmount(recommendedFightAmount)
                .setRequiredLevel(requiredLevel);

        // --- 特有字段 ---
        builder.setBatchCount(getBatchCount());
        builder.setFirstPassGroupDungeonPrize(dailyFirstPassPrizeConfig
                .encode());
        builder.setNotFirstPassPrize(notFirstPassPrize.encode4Client());

        return builder.build();
    }

    class SpawnConfig{
        final int x1;
        final int y1;
        final int x2;
        final int y2;

        SpawnConfig(int x1, int y1, int x2, int y2){
            this.x1 = x1;
            this.y1 = y1;
            this.x2 = x2;
            this.y2 = y2;

            checkArgument(blockInfo.isWalkable(x1, y1),
                    "守护龙脉其中一个刷怪点不可走: <%s, %s>", x1, y1);
            checkArgument(blockInfo.isWalkable(x2, y2),
                    "守护龙脉其中一个刷怪点不可走: <%s, %s>", x2, y2);

            // 确保有路径可以到龙脉的

            checkNotNull(blockInfo.searchPath(x1, y1, longmaiX, longmaiY),
                    "守护龙脉其中一个刷怪点 <%s, %s> 没有路径到龙脉点 <%s, %s>", x1, y1, longmaiX,
                    longmaiY);
            checkNotNull(blockInfo.searchPath(x2, y2, longmaiX, longmaiY),
                    "守护龙脉其中一个刷怪点 <%s, %s> 没有路径到龙脉点 <%s, %s>", x2, y2, longmaiX,
                    longmaiY);
        }
    }

    @Override
    public int getIntType(){
        return SceneType.LONG_MAI_DUNGEON.getNumber();
    }
}
