package app.game.data.scene;

import static com.mokylin.sink.util.Preconditions.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jboss.netty.buffer.ChannelBuffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.cluster.client.combat.scene.LongMaiDungeonMessages;
import app.cluster.combat.master.logic.scene.RemoteLongMaiDungeonScene;
import app.game.data.scene.LongMaiDungeonSceneData.SpawnConfig;
import app.game.module.scene.FightData;
import app.game.module.scene.LongMaiMonsterFightModule;

import com.mokylin.collection.IntHashSet;
import com.mokylin.collection.IntValueIntHashMap;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.parse.ObjectParser;

public class LongMaiBatchInfo{

    private static final Logger logger = LoggerFactory
            .getLogger(LongMaiBatchInfo.class);

    /**
     * 这是第几波, 从1开始 
     */
    public final int batch;

    /**
     * 每0.5秒要刷的怪物
     * 
     * 第一维是第几次怪物
     * 第二维是这一次里要刷的所有怪物
     */
    public final LongMaiMonsterPosAndID[][] monsters;

    /**
     * 这一波的具体信息
     */
    public final ChannelBuffer batchInfoMsg;

    /**
     * 下一波, 如果是最后一波, 则是null
     */
    public final LongMaiBatchInfo nextBatch;

    final int maxUsedMonsterID;

    LongMaiBatchInfo(int batch, LongMaiMonsterPosAndID[][] monsters,
            LongMaiBatchInfo nextBatch, int maxUsedMonsterID){
        this.batch = batch;
        this.monsters = monsters;
        this.nextBatch = nextBatch;
        this.maxUsedMonsterID = maxUsedMonsterID;

        IntHashSet set = new IntHashSet();
        for (LongMaiMonsterPosAndID[] l : monsters){
            for (LongMaiMonsterPosAndID m : l){
                set.add(m.monsterData.id);
            }
        }
        int[] array = new int[1 + set.size()];
        array[0] = batch;
        int index = 1;
        for (Integer i : set){
            array[index++] = i;
        }
        this.batchInfoMsg = LongMaiDungeonMessages.setBatchInfo(array);
    }

    public static class LongMaiMonsterPosAndID{
        public final long id;
        public final ChannelBuffer removeMeMsg;
        public final int x;
        public final int y;
        public final MonsterData monsterData;

        LongMaiMonsterPosAndID(long id, ChannelBuffer removeMeMsg, int x,
                int y, MonsterData monsterData){
            super();
            this.id = id;
            this.removeMeMsg = removeMeMsg;
            this.x = x;
            this.y = y;
            this.monsterData = monsterData;
        }

        public LongMaiMonsterFightModule newMonster(
                RemoteLongMaiDungeonScene parent){
            FightData fightData = new FightData(monsterData.stat,
                    monsterData.level);
            fightData.setSceneIDAndPos(parent.getSceneID(), x, y);
            return new LongMaiMonsterFightModule(id, monsterData, fightData,
                    parent, removeMeMsg, parent.getPositionModuleSharedSync());
        }
    }

    // --- parse config ---

    private static final int[] ZERO_POS = new int[]{0};

    public static LongMaiBatchInfo[] parse(SpawnConfig[] spawnPos,
            List<ObjectParser> parsers, MonsterDatas monsterDatas,
            SceneRemoveObjectMsgCache removeMsgCache,
            LongMaiDungeonSceneData sceneData){
        logger.debug("解析守护龙脉的怪物配置");
        checkArgument(spawnPos.length > 0);
        Map<Integer, EachSpawnPos[]> batchAndSpawns = new HashMap<>();

        IntValueIntHashMap perBatchIDCounter = new IntValueIntHashMap(); // 每一波的id都重新开始算. 最小的id是2. 1是龙脉

        for (ObjectParser p : parsers){
            String monsterName = p.getKey("monster_name");
            int count = p.getIntKey("count");
            int batch = p.getIntKey("batch");

            MonsterData monsterData = checkNotNull(
                    monsterDatas.get(monsterName), "守护龙脉第 %s 波的怪物没找到: %s",
                    batch, monsterName);

            monsterData.setScene(sceneData, ZERO_POS);
            checkArgument(count > 0, "守护龙脉第 %s 波的怪物数量非法: %s", batch, count);

            EachSpawnPos[] eachSpawn = batchAndSpawns.get(batch);
            if (eachSpawn == null){
                eachSpawn = new EachSpawnPos[spawnPos.length];
                for (int i = 0; i < eachSpawn.length; i++){
                    eachSpawn[i] = new EachSpawnPos();
                }
                batchAndSpawns.put(batch, eachSpawn);
            }

            int idStart = perBatchIDCounter.get(batch);
            if (idStart <= 1){
                idStart = 2;
            }

            // 给每一个出怪口都刷这么多个怪
            for (int spawn = 0; spawn < spawnPos.length; spawn++){
                SpawnConfig sc = spawnPos[spawn];
                EachSpawnPos esp = eachSpawn[spawn];
                for (int c = 0; c < count; c++){
                    // 要刷多少个
                    boolean usePos1 = (esp.monsters.size() & 1) == 1;
                    int x = usePos1 ? sc.x1 : sc.x2;
                    int y = usePos1 ? sc.y1 : sc.y2;

                    int id = idStart++;
                    LongMaiMonsterPosAndID mon = new LongMaiMonsterPosAndID(id,
                            removeMsgCache.get(id), x, y, monsterData);
                    esp.monsters.add(mon);
                }
            }

            perBatchIDCounter.put(batch, idStart);
        }

        checkArgument(batchAndSpawns.size() > 0, "守护龙脉的怪物没有配");

        // 导出成需要的格式
        LongMaiBatchInfo[] result = new LongMaiBatchInfo[batchAndSpawns.size()];

        for (int i = batchAndSpawns.size(); i >= 1; i--){
            EachSpawnPos[] eachSpawn = batchAndSpawns.get(i);
            checkNotNull(eachSpawn, "守护龙脉的怪物波数必须是从1开始连续的");
            // 如果有, 里面一定有怪物, 因为count>0才会新建, 而且里面的怪物数量是相同的

            int eachSpawnCount = eachSpawn[0].monsters.size();
            LongMaiMonsterPosAndID[][] mons = new LongMaiMonsterPosAndID[Utils
                    .divide(eachSpawnCount, 2)][];
            int index = 0;
            for (int p = 0; p < eachSpawnCount; p += 2){
                boolean hasTwo = (p + 1) < eachSpawnCount;
                LongMaiMonsterPosAndID[] m;
                if (hasTwo){
                    m = new LongMaiMonsterPosAndID[2 * eachSpawn.length];
                    int index2 = 0;
                    for (EachSpawnPos esp : eachSpawn){
                        m[index2++] = esp.monsters.get(p);
                        m[index2++] = esp.monsters.get(p + 1);
                    }
                } else{
                    m = new LongMaiMonsterPosAndID[eachSpawn.length];

                    int index2 = 0;
                    for (EachSpawnPos esp : eachSpawn){
                        m[index2++] = esp.monsters.get(p);
                    }
                }

                mons[index++] = m;
            }

            // 检查bug, 设置最大使用到的id
            long maxUsedID = 0;
            for (LongMaiMonsterPosAndID[] l : mons){
                checkNotNull(l, "守护龙脉初始化错误, 某波的怪物没有. 程序错误");
                for (LongMaiMonsterPosAndID m : l){
                    checkNotNull(m, "守护龙脉初始化错误, 某波里某个怪物没有. 程序错误");
                    maxUsedID = m.id;
                }
            }

            result[i - 1] = new LongMaiBatchInfo(i, mons,
                    i == batchAndSpawns.size() ? null : result[i],
                    (int) maxUsedID);
        }
        return result;
    }

    private static class EachSpawnPos{
        private final List<LongMaiMonsterPosAndID> monsters;

        private EachSpawnPos(){
            this.monsters = new ArrayList<>();
        }
    }
}
