package app.game.data.scene;

import org.jboss.netty.buffer.BigEndianHeapChannelBuffer;
import org.jboss.netty.buffer.ChannelBuffer;

import app.game.data.Prize;
import app.game.module.scene.DefenceDungeonMessages;
import app.protobuf.PrizeContent.PrizeProto;

import com.google.protobuf.ByteString;
import com.mokylin.sink.util.BufferUtil;
import com.mokylin.sink.util.Utils;

public class DefenceCollectablePrize{

    public final int startBatch;
    public final int endBatch;
    public final Prize prize;

    public final byte[] prizeDiffInfo;
    public final byte[] prizeProtoCompressed;
    public final ByteString prizeProtoCompressedByteString;
    public final ChannelBuffer addCollectableMsg;

    /**
     * 扫荡成功消息
     */
    public final ChannelBuffer autoFinishMsg;

    DefenceCollectablePrize(int startBatch, int endBatch, Prize prize){
        super();
        this.startBatch = startBatch;
        this.endBatch = endBatch;
        this.prize = prize;

        int batchVarint32Size = BufferUtil.computeVarInt32Size(endBatch);

        // 缓存prizeDiffInfo
        PrizeProto p = prize.encode4Client();
        byte[] prizeByteArray = p.toByteArray();
        p = null;
        ChannelBuffer buffer = new BigEndianHeapChannelBuffer(batchVarint32Size
                + prizeByteArray.length);
        BufferUtil.writeVarInt32(buffer, endBatch);
        buffer.writeBytes(prizeByteArray);
        assert buffer.writableBytes() == 0;
        this.prizeDiffInfo = Utils.zlibCompress(buffer.array());
        buffer = null;

        // 缓存prizeProtoCompressed
        this.prizeProtoCompressed = Utils.zlibCompress(prizeByteArray);
        this.prizeProtoCompressedByteString = ByteString
                .copyFrom(prizeProtoCompressed);

        // 缓存添加可领取消息
        this.addCollectableMsg = DefenceDungeonMessages
                .addCollectableTempKongciPrize(prizeProtoCompressed);

        this.autoFinishMsg = DefenceDungeonMessages.autoFinishSuccess(endBatch,
                prizeByteArray);
        prizeByteArray = null;
    }

    public DefenceCollectablePrizeWithExpireTime withExpireTime(long expireTime){
        return new DefenceCollectablePrizeWithExpireTime(expireTime);
    }

    public class DefenceCollectablePrizeWithExpireTime{
        public final long expireTime;

        private DefenceCollectablePrizeWithExpireTime(long expireTime){
            this.expireTime = expireTime;
        }

        public DefenceCollectablePrize getPrize(){
            return DefenceCollectablePrize.this;
        }
    }
}
