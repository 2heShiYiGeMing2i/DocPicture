package app.game.data.scene;

import static com.mokylin.sink.util.Preconditions.checkArgument;

import java.util.List;

import app.game.data.GameObjects;
import app.game.data.goods.GoodsDatas;
import app.game.data.goods.GoodsWrapper;
import app.protobuf.ConfigContent.SouShenShopGoodsProto;

import com.google.inject.Inject;
import com.mokylin.collection.IntHashMap;
import com.mokylin.sink.util.parse.ObjectParser;

public class SouShenShop{

    private static final String LOCATION = GameObjects.SOU_SHEN_SCENE_BASE_FOLDER
            + "shop.txt";

    private final SouShenShopGoods[] goods;
    private final IntHashMap<SouShenShopGoods> goodsMap;

    @Inject
    SouShenShop(GameObjects go, GoodsDatas goodsDatas){
        List<ObjectParser> data = go.loadFile(LOCATION);

        goods = new SouShenShopGoods[data.size()];
        this.goodsMap = new IntHashMap<>(data.size());

        for (int i = 0; i < data.size(); i++){
            SouShenShopGoods g = new SouShenShopGoods(data.get(i), goodsDatas);
            goods[i] = g;

            goodsMap.putUnique(g.id, g);
        }
    }

    public SouShenShopGoods getGoods(int id){
        return goodsMap.get(id);
    }

    public SouShenShopGoods[] getGoods(){
        return goods;
    }

    public static class SouShenShopGoods{
        private final int id;

        public final GoodsWrapper goodsWrapper;

        public final int souShenPointCost;

        public final int dailyLimit;

        private final String tabName;

        private SouShenShopGoods(ObjectParser p, GoodsDatas goodsDatas){
            this.id = p.getIntKey("id");
            checkArgument(id > 0, "搜神宫商店里的id必须>0");

            String item = p.getKey("goods_item");
            this.goodsWrapper = GoodsWrapper.parse("搜神宫商店", goodsDatas, item);

            this.tabName = p.getKey("tab_name");

            this.souShenPointCost = p.getIntKey("cost");
            this.dailyLimit = p.getIntKey("daily_limit");

            checkArgument(souShenPointCost > 0, "搜神宫商店里的价格必须>0: %s", item);
            checkArgument(dailyLimit >= 0, "搜神宫商店里的物品每日兑换限制必须>=0: %s", item);
        }

        SouShenShopGoodsProto encode(){
            SouShenShopGoodsProto.Builder builder = SouShenShopGoodsProto
                    .newBuilder();
            builder.setId(id);
            builder.setGoods(goodsWrapper.encode4Client());
            builder.setCost(souShenPointCost);
            builder.setDailyLimit(dailyLimit);
            builder.setTabName(tabName);
            return builder.build();
        }
    }
}
