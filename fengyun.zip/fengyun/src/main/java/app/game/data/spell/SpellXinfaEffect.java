package app.game.data.spell;

import static com.mokylin.sink.util.Preconditions.checkArgument;
import static com.mokylin.sink.util.Preconditions.checkNotNull;
import app.game.data.GameObject;
import app.protobuf.GoodsContent.XinfaType;

import com.mokylin.sink.util.parse.ObjectParser;

/**
 * 技能心法效果，触发技能时使用的数据
 * @author Liwei
 *
 */
public class SpellXinfaEffect extends GameObject{

    public static final SpellXinfaEffect EMPTY_XINFA = new SpellXinfaEffect();

    public final int requireSpellLevel;

    public final XinfaType type;

    // 附加效果

    public final int hurtCount;

    public final int releaseRange;

    public final int hurtRange;

    public final int angle;

    /**
     * 技能伤害的倍率, 计算时, 按配置的数字/100
     */
    public final float damageMultiple;

    public final int damage;

    /**
     * 技能额外的命中率, 分母为1万
     */
    public final int additionalHitRate;

    /**
     * 技能额外的暴击率, 分母为1万
     */
    public final int additionalCritRate;

    public final PassiveSpell spell;

    SpellXinfaEffect(ObjectParser p, PassiveSpells spells){
        super(p);

        requireSpellLevel = p.getIntKey("require_spell_level");

        int intType = p.getIntKey("xinfa_type");
        type = checkNotNull(XinfaType.valueOf(intType), "%s 没找到心法类型, %s", this,
                intType);

        hurtCount = p.getIntKey("hurt_count");
        checkArgument(hurtCount >= 0, "心法 %s 的参数hurtCount无效，取值必须 >= 0", this);

        releaseRange = p.getIntKey("release_range");
        checkArgument(releaseRange >= 0, "心法 %s 的参数releaseRange无效，取值必须 >= 0",
                this);

        hurtRange = p.getIntKey("hurt_range");
        checkArgument(hurtRange >= 0, "心法 %s 的参数hurtRange无效，取值必须 >= 0", this);

        angle = p.getIntKey("angle");
        checkArgument(angle >= 0, "心法 %s 的参数angle无效，取值必须 >= 0", this);

        int m = p.getIntKey("damage_multiple");
        checkArgument(m >= 0, "心法 %s 的参数damage_multiple无效，取值必须 >= 0", this);

        this.damageMultiple = m / 100f;

        damage = p.getIntKey("damage");
        checkArgument(damage >= 0, "心法 %s 的参数damage无效，取值必须 >= 0", this);

        additionalHitRate = p.getIntKey("additional_hit_rate");
        checkArgument(additionalHitRate >= 0,
                "心法 %s 的参数additionalHitRate无效，取值必须 >= 0", this);

        additionalCritRate = p.getIntKey("additional_crit_rate");
        checkArgument(additionalCritRate >= 0,
                "心法 %s 的参数additionalCritRate无效，取值必须 >= 0", this);

        int spellId = p.getIntKey("spell_id");

        if (spellId > 0){
            spell = checkNotNull(spells.get(spellId), "%s 配置的触发被动技能没找到，%s",
                    this, spellId);

            checkArgument(!spell.isPropertyPassiveSpell(),
                    "%s 配置的触发技能是个加属性的技能，神马情况", this);

            checkArgument(spell.spellCategory == Spell.XINFA_SPELL_CATEGORY,
                    "心法%s 配置触发的被动技能类型必须=10(心法技能), spell: %s", this, spell);
        } else{
            spell = null;
        }
    }

    private SpellXinfaEffect(){
        requireSpellLevel = 0;
        type = null;

        hurtCount = 0;
        releaseRange = 0;
        hurtRange = 0;
        angle = 0;
        damageMultiple = 0;
        damage = 0;
        additionalHitRate = 0;
        additionalCritRate = 0;
        spell = null;
    }
}
