package app.game.data;

import static com.google.common.base.Preconditions.checkArgument;

import java.io.File;
import java.io.InputStream;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.service.redeploy.IHotRedeployService;

import com.google.common.collect.Lists;
import com.google.inject.AbstractModule;
import com.google.inject.Provides;
import com.google.inject.Singleton;
import com.google.protobuf.InvalidProtocolBufferException;
import com.mokylin.sink.util.Empty;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.pack.CharSetConvertor;
import com.mokylin.sink.util.pack.ConfigPackFileLoader;
import com.mokylin.sink.util.pack.FileLoader;
import com.mokylin.sink.util.pack.FilePacker;
import com.mokylin.sink.util.pack.RealTimeFileLoader;
import com.mokylin.sink.util.parse.ObjectParser;
import com.mokylin.sink.util.parse.ObjectParsers;
import com.mokylin.zk.util.ClusterSharedConfiguration;
import com.ning.http.client.ListenableFuture;

public class FileLoaderModule extends AbstractModule{
    private static final Logger logger = LoggerFactory
            .getLogger(FileLoaderModule.class);

    @Override
    protected void configure(){
        binder().requireExplicitBindings();
    }

    public FileLoader doGetFromLocal(){
        // 查看当前目录下有没有后缀名是hyc的
        File folder = new File(".");
        if (!folder.isDirectory()){
            throw new IllegalArgumentException();
        }

        // 读取configuration.property, 读到默认的config目录
        ObjectParser config = loadFile(ClusterSharedConfiguration.LOCATION);

        String defaultConfigFolder = config.getKey("config_dir", "config");
        File conffolder = new File(defaultConfigFolder);

        File[] files = null;
        if (conffolder.exists() && conffolder.isDirectory()
                && ((files = conffolder.listFiles()) != null)
                && (files.length != 0)){
            logger.info("读取config文件夹下的配置");
            return new RealTimeFileLoader();
        } else{
            //是jar包,找secret.hyc
            try (InputStream is = Utils
                         .getInputStreamFromClassPath("secret.hyc")){
                if (is == null){
                    logger.error("当前路径没有找到hyc结尾的配置文件, 也不存在非空config文件夹,在ClassLoader的资源里面无secret.hyc文件,无法开服");
                    throw new IllegalArgumentException();
                }

                logger.info("当前路径没有找到hyc结尾的配置文件, 也不存在非空config文件夹,使用ClassLoader资源里面的secret.hyc文件");
                return decodeHyc(is);
            } catch (Throwable ex){
                throw new RuntimeException(ex);
            }
        }
    }

    /**
     * 优先级: 1.当前路径的config文件夹(并会关闭自动更新)  2. 网上的同服务器版本hyc  3.jar包中hyc文件
     * @return FileLoader
     */
    @Provides
    @Singleton
    public FileLoader get(IHotRedeployService redeployService){
        // 取config文件夹
        File folder = new File(".");
        if (!folder.isDirectory()){
            throw new IllegalArgumentException();
        }

        File conffolder = new File("config");

        File[] files = null;
        if (conffolder.exists() && conffolder.isDirectory()
                && ((files = conffolder.listFiles()) != null)
                && (files.length != 0)){
            redeployService.setDisable();
            return new RealTimeFileLoader();
        }

        logger.debug("尝试获取网上本版本最新的配置文件");
        ListenableFuture<ConfigPackFileLoader> future = redeployService
                .getCurrentConfig();

        if (future != null){
            try{
                ConfigPackFileLoader fileLoader = future.get();
                if (fileLoader != null){
                    return fileLoader;
                }
            } catch (Throwable ex){
                logger.error("FileLoaderModule获取网上新的配置文件出错, 使用本地配置", ex);
            }
        }

        //是jar包,找secret.hyc
        try (InputStream is = Utils.getInputStreamFromClassPath("secret.hyc")){
            if (is == null){
                logger.error("当前路径没有找到hyc结尾的配置文件, 也不存在非空config文件夹,在ClassLoader的资源里面无secret.hyc文件,无法开服");
                throw new IllegalArgumentException();
            }

            logger.info("当前路径没有找到hyc结尾的配置文件, 也不存在非空config文件夹,使用ClassLoader资源里面的secret.hyc文件");
            return decodeHyc(is);
        } catch (Throwable ex){
            throw new RuntimeException(ex);
        }
    }

    private ConfigPackFileLoader decodeHyc(InputStream is)
            throws InvalidProtocolBufferException{
        byte[] content = Utils.readGzipFile(is);
        Map<String, byte[]> configFiles = FilePacker.unpack(content);
        return new ConfigPackFileLoader(configFiles);
    }

    private static ObjectParser loadFile(String location){
        String data = CharSetConvertor.readFile(location);
        if (data == null){
            return ObjectParsers.EMPTY_PARSER;
        }

        String[] as = data.split("\\r?\\n"); // 兼顾\n和\r\n

        List<String> headerList = Lists.newArrayListWithCapacity(as.length);
        List<String> valueList = Lists.newArrayListWithCapacity(as.length);

        for (String rawLine : as){
            try{
                String line = rawLine.trim();
                if (line.length() == 0){
                    continue;
                }

                if (line.startsWith("#")){
                    continue;
                }

                int commentPos = line.indexOf("//");
                if (commentPos >= 0){
                    line = line.substring(0, commentPos);
                }
                line = line.trim();
                if (line.length() == 0){
                    continue;
                }

                int epos = line.indexOf("=");
                checkArgument(epos > 0, "%s 格式错误. 必须是 key = value: %s",
                        location, line);
                String key = line.substring(0, epos).trim();

                String value = line.substring(epos + 1).trim();

                headerList.add(key);
                valueList.add(value);
            } catch (Throwable e){
                throw new IllegalArgumentException(e);
            }
        }

        return new ObjectParser(headerList.toArray(Empty.STRING_ARRAY),
                valueList.toArray(Empty.STRING_ARRAY));
    }
}
