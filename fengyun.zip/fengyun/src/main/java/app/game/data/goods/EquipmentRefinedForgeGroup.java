package app.game.data.goods;

import static com.mokylin.sink.util.Preconditions.*;

import java.util.List;

import app.game.data.UpgradeData;
import app.game.shop.VendingMachine;
import app.protobuf.GoodsServerContent.GoodsType;

import com.mokylin.sink.util.parse.ObjectParser;

/**
 * 装备强化数据
 * @author Liwei
 *
 */
public class EquipmentRefinedForgeGroup{

    final String name;

    final int maxRefinedTimes;

    final UpgradeData[] upgradeDatas;

    final boolean[] isBroadcasts;

    EquipmentRefinedForgeGroup(String name, List<ObjectParser> parserList,
            GoodsDatas goodsDatas, VendingMachine systemShop){

        this.name = name;
        maxRefinedTimes = parserList.size();

        upgradeDatas = new UpgradeData[maxRefinedTimes];
        isBroadcasts = new boolean[maxRefinedTimes];
        for (ObjectParser p : parserList){
            int level = p.getIntKey("level"); // level从1开始
            checkArgument(level > 0 && level <= maxRefinedTimes,
                    "%s 中存在无效的等级，level: %s", this, level);

            checkArgument(upgradeDatas[level - 1] == null,
                    "%s 中存在重复等级的数据，level: %s", this, level);

            UpgradeData upgradeData = upgradeDatas[level - 1] = new UpgradeData(
                    this, p, goodsDatas, systemShop);

            checkArgument(upgradeData.getUpgradeMaxTimes() < 4096,
                    "装备最大进阶次数必须小于4096");

            upgradeData
                    .setCustomAuctionType(GoodsData.REFINED_FORGE_AUCTION_TYPE);

            checkNotNull(upgradeData.getUpgradeGoods(), "%s 中没有配置升级消耗物品", this);

            checkArgument(upgradeData.getUpgradeMoneyCost() > 0,
                    "%s 中消耗物品没有配置银两消耗", this);

            checkArgument(upgradeData.getUpgradeGoodsYuanbaoPrice() > 0,
                    "%s 中强化消耗物品没有配置元宝价格", this);

            checkArgument(
                    upgradeData.getUpgradeGoods().getType() != GoodsType.EQUIPMENT,
                    "%s 中强化消耗物品不能是装备类型, %s", this,
                    upgradeData.getUpgradeGoods());

            for (GoodsData goods : upgradeData.getSubstituteGoods()){
                checkArgument(goods.getType() != GoodsType.EQUIPMENT,
                        "%s 中强化消耗替代物品不能是装备类型, %s", this, goods);
            }

            isBroadcasts[level - 1] = p.getBooleanKey("is_broadcast");

            String rateDesc = p.getKey("rate_desc");

            checkArgument(!rateDesc.isEmpty(), "%s 中%s 级的概率描述没有配置", this, level);
        }

        UpgradeData prev = null;
        for (UpgradeData data : upgradeDatas){
            if (prev != null){
                data.checkArg(this, prev);
            }
            prev = data;
        }
    }

    @Override
    public String toString(){
        return "[装备强化]-" + name;
    }
}
