/**
 * 
 */
package app.game.data.goods;

import app.protobuf.GoodsContent.GoodsDataProto;
import app.protobuf.GoodsServerContent.GoodsType;

import com.google.protobuf.ByteString;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * 任务物品
 * 
 * @author Liwei
 * 
 */
public class TaskGoodsData extends GoodsData{

    private final GoodsDataProto proto;

    private final byte[] protoBytes;

    private final ByteString protoByteString;

    TaskGoodsData(ObjectParser p){
        super(p, GoodsType.TASK);

        proto = encode().build();
        protoBytes = processProtoBytes(proto.toByteArray());
        protoByteString = ByteString.copyFrom(protoBytes);
    }

    public GoodsDataProto getProto(){
        return proto;
    }

    @Override
    public byte[] getProtoBytes(){
        return protoBytes;
    }

    @Override
    public ByteString getProtoByteString(){
        return protoByteString;
    }

    @Override
    public int getAuctionType(){
        return 123;
    }

}
