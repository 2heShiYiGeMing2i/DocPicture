package app.game.data.scene;

import static com.mokylin.sink.util.Preconditions.*;

import java.util.List;
import java.util.Map;

import app.game.data.SpriteStat;
import app.game.data.SpriteStats;
import app.game.data.goods.GoodsDatas;
import app.game.data.goods.GoodsWrapper;
import app.game.data.spell.SingleEffectSpell;
import app.game.data.spell.SingleEffectSpellWithRate;
import app.game.data.spell.SpellAnimation;
import app.game.data.spell.Spells;
import app.i18n.I18NConfig;
import app.i18n.MESSAGE_ENUM;
import app.protobuf.ConfigContent.MonsterDataProto;

import com.google.protobuf.ByteString;
import com.mokylin.collection.IntArrayList;
import com.mokylin.sink.util.Empty;
import com.mokylin.sink.util.StringEncoder;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * 怪物信息. 属性/外观 等等
 * 
 * @author Timmy
 * 
 */
public class MonsterData{

    public static final int TYPE_MONSTER = 0;

    public static final int TYPE_ELITE_MONSTER = 1;

    public static final int TYPE_BOSS = 2;

    public final int id;

    public final String name;

    public final byte[] clientDisplayName;

    /**
     * 动作资源
     */
    public final String res;

    /**
     * 头像
     */
    public final String head;

    /**
     * 等级
     */
    public final int level;

    /**
     * 0普通怪, 1 精英怪, 2 boss 只供客户端显示用
     */
    public final int type;

    private transient final boolean isBoss;

    private transient final boolean isMustDie;

    /**
     * 被打固定少血的量. 0表示正常受伤
     */
    public final int staticHurt;

    public final SpriteStat stat;

    /**
     * 死亡后给的经验
     */
    public final int exp;

    // 经验是否不衰减，true表示不衰减
    public final boolean isExpNotDecay;

    public final SingleEffectSpell normalSpell;

    public final SingleEffectSpellWithRate[] specialSpells;

    public transient final int specialSpellsCount;

    /**
     * 所有伤害技能中, 攻击距离最远的
     */
    public transient final int attackRange;

    /**
     * 特殊技能中, 有没有可以对自己放的技能
     */
    public transient final boolean hasBuffSkill;

//    private transient final byte[] cacheData;

    private transient final boolean needBroadcastTarget;

    /**
     * 闲聊
     */
    private final String[] chat;

    /**
     * 闲聊间隔，单位毫秒
     */
    private final int chatInterval;

    /**
     * 怪物掉落说明
     */
    private final String plunderTips;

    public final boolean needLog;

    /**
     * 背景，世界Boss需要配置背景
     */
    public final String introduction;

    public final GoodsWrapper[] showGoods;

    /**
     * 所属的地图，每个怪物只能出现在一个地图里，否则在任务里就不知道怪物在哪个地图了
     */
    private SceneData scene;

    private IntArrayList posList;

    private int[] navigatePoses;

    private transient final int normalSpellReleaseRangeOrHurtRangeIfHaveNormalSpell;

    /**
     * 击杀归属类型（有排行榜时忽略） 0-仇恨最高 1-最后一刀
     */
    public final int killOwnType;

    // 排名个数，0表示不需要排行榜
    public final int rankCount;

    public final GoodsWrapper[] rankPrizeGoods;

    public final byte[][] rankMailContents;

    MonsterData(ObjectParser p, SpriteStats spriteStats, Spells spells,
            GoodsDatas goodsDatas, Map<String, GoodsWrapper> showPlunderCache,
            I18NConfig i18nConfig, List<GoodsWrapper> showGoodsList){
        this.id = p.getIntKey("id");
        this.name = p.getKey("name");

        this.clientDisplayName = StringEncoder
                .encode(getClientDisplayName(name));

        this.res = p.getKey("res");
        this.level = p.getIntKey("level");
        this.head = p.getKey("head");
        this.type = p.getIntKey("type");
        this.exp = p.getIntKey("exp");
        isExpNotDecay = p.getBooleanKey("is_exp_not_decay");

        checkArgument(type >= 0 && type <= 2,
                "%s 配置的怪物类型无效，0普通怪, 1 精英怪, 2 boss", this);

        isBoss = type == TYPE_BOSS;

        isMustDie = type == TYPE_BOSS || type == TYPE_ELITE_MONSTER;

        this.staticHurt = p.getIntKey("static_hurt");
        checkArgument(staticHurt >= 0, "怪物 %s 的被攻击固定少血static_hurt 比如 >=0: %s",
                this, staticHurt);

        int spriteStatID = p.getIntKey("stat");
        this.stat = checkNotNull(spriteStats.get(spriteStatID),
                "没找到怪物 %s 所用的属性: %s", this, spriteStatID);

        checkArgument(stat.maxLife > 0, "怪物 %s 使用的属性 %s 的最大血量max_life必须大于0",
                this, stat);

        // 普通技能
        int normalSpellID = p.getIntKey("normal_spell");
        if (normalSpellID > 0){
            normalSpell = checkNotNull(
                    spells.getSingleEffectSpells().get(normalSpellID),
                    "没有找到怪物 %s 的默认攻击技能: %s", this, normalSpellID);

            checkArgument(normalSpell.isAttack, "怪物 %s 的普通技能必须是伤害技能: %s", this,
                    normalSpell);

            normalSpellReleaseRangeOrHurtRangeIfHaveNormalSpell = normalSpell
                    .getReleaseRangeOrHurtRange();
        } else{
            normalSpell = null;
            normalSpellReleaseRangeOrHurtRangeIfHaveNormalSpell = 0;
        }

        // 特殊技能
        String specialSpellsString = p.getKey("special_spell");
        if (specialSpellsString.length() == 0){
            specialSpells = SingleEffectSpellWithRate.EMPTY_ARRAY;
        } else{
            String[] s = specialSpellsString.split(";");
            specialSpells = new SingleEffectSpellWithRate[s.length];
            for (int i = 0; i < s.length; i++){
                String[] idAndRate = s[i].split("%");
                checkArgument(
                        idAndRate.length == 2,
                        "怪物 %s 特殊技能配置格式: id%触发概率@触发血量;id%触发概率@触发血量. @触发血量 表示怪物血量到了多少百分比以下才会触发. 可以不填, 默认是100. ",
                        this);
                int sid = Integer.parseInt(idAndRate[0]);

                String[] rateAndLifePercent = idAndRate[1].split("@");

                int srate = Integer.parseInt(rateAndLifePercent[0]);
                int lifePercent = 0;
                if (rateAndLifePercent.length == 1){
                    lifePercent = 100;
                } else{
                    lifePercent = Integer.parseInt(rateAndLifePercent[1]);
                }

                SingleEffectSpell sp = checkNotNull(spells
                        .getSingleEffectSpells().get(sid),
                        "怪物 %s 配置的特殊技能 %s 不存在", this, sid);

                // 怪物的技能, 如果施法目标是别人, 则一定是有害的
                if (sp.spellAnimation.targetType == SpellAnimation.TARGET_TYPE_TARGET){
                    checkArgument(sp.isAttack,
                            "怪物 %s 的特殊技能 %s 目标类型是要选择目标, 必须是伤害技能", this, sp);
                }

                checkArgument(srate > 0 && srate <= 100,
                        "怪物 %s 配置的特殊技能触发概率必须是1-100: %s", this, srate);

                checkArgument(lifePercent > 0 && lifePercent <= 100,
                        "怪物 %s 配置的特殊技能触发血量必须是1-100: %s", this, lifePercent);

                specialSpells[i] = new SingleEffectSpellWithRate(srate,
                        lifePercent / 100f, sp);
            }
        }
        specialSpellsCount = specialSpells.length;

        // 设置最大的攻击技能的攻击范围
        int maxRange = normalSpell == null ? 0 : normalSpell
                .getReleaseRangeOrHurtRange();
        for (SingleEffectSpellWithRate sp : specialSpells){
            if (sp.spell.isAttack){
                maxRange = Math.max(sp.spell.getReleaseRangeOrHurtRange(),
                        maxRange);
            }
        }
        this.attackRange = maxRange;

        // 检查是否有有益技能
        boolean hasBuffSpell = false;
        for (SingleEffectSpellWithRate sp : specialSpells){
            if (!sp.spell.isAttack){
                hasBuffSpell = true;
                break;
            }
        }
        this.hasBuffSkill = hasBuffSpell;

        this.needBroadcastTarget = type == 2 || type == 1;

        String chatStr = p.getKey("chat");
        if (chatStr.isEmpty()){
            this.chat = Empty.STRING_ARRAY;

            chatInterval = 0;
        } else{
            this.chat = chatStr.split(";");

            chatInterval = p.getIntKey("chat_interval");
            checkArgument(chatInterval > 0, "怪物-%s 的闲聊时间间隔必须大于等于0", name);
        }

//        this.cacheData = getCacheData();
        navigatePoses = Empty.INT_ARRAY;

        // 击杀归属
        killOwnType = p.getIntKey("kill_own_type");

        rankCount = p.getIntKey("rank_count");
        if (rankCount > 0){
            checkArgument(isBoss(), "怪物-%s 配置了伤害排行榜，但是怪物不是boss（只有boss怪可以配置排行榜）");
            String[] rankGoodsArray = p.getStringArray("rank_prize_goods");
            checkArgument(rankGoodsArray.length == 4,
                    "怪物-%s 的rank_prize_goods字段太多了，只能有4个（一二三名和四名之后的奖励）");

            showGoodsList.clear();
            for (String key : rankGoodsArray){
                if (key == null || key.isEmpty())
                    break;

                GoodsWrapper wrapper = showPlunderCache.get(key);
                if (wrapper == null){
                    wrapper = GoodsWrapper.parse(this, goodsDatas, key);
                }

                showGoodsList.add(wrapper);
            }

            checkArgument(
                    !showGoodsList.isEmpty() && showGoodsList.size() == 4,
                    "怪物-%s 的伤害排行榜奖励错误，只能不配置或者配置4个（一二三名和四名之后的奖励）");

            rankMailContents = new byte[rankCount][];
            for (int i = 0; i < rankCount; i++){
                int rankPos = i + 1;
                rankMailContents[i] = i18nConfig.getMessage(
                        MESSAGE_ENUM.MONSTER_RANK_PRIZE, clientDisplayName,
                        String.valueOf(rankPos).getBytes());
            }
        } else{
            rankMailContents = Empty.BYTES_ARRAY;
        }

        rankPrizeGoods = showGoodsList.toArray(GoodsWrapper.EMPTY_ARRAY);

        plunderTips = p.getKey("plunder_tips");
        this.needLog = p.getBooleanKey("need_log", false);

        introduction = p.getKey("introduction");

        showGoodsList.clear();
        String[] showGoodsArray = p.getStringArray("show_goods");
        for (String key : showGoodsArray){
            if (key == null || key.isEmpty())
                continue;

            GoodsWrapper wrapper = showPlunderCache.get(key);
            if (wrapper == null){
                wrapper = GoodsWrapper.parse(this, goodsDatas, key);
            }

            showGoodsList.add(wrapper);
        }

        showGoods = showGoodsList.toArray(GoodsWrapper.EMPTY_ARRAY);
    }

    public int getNormalSpellReleaseRangeOrHurtRangeIfHaveNormalSpell(){
        return normalSpellReleaseRangeOrHurtRangeIfHaveNormalSpell;
    }

    private static String getClientDisplayName(String name){
        int underScorePos = name.indexOf("_");
        if (underScorePos < 0){
            return name;
        }

        return name.substring(0, underScorePos);
    }

    public long[] newSpecialSpellsCoolDown(){
        if (specialSpellsCount == 0){
            return Empty.LONG_ARRAY;
        }
        return new long[specialSpellsCount];
    }

    public MonsterDataProto encode4Client(){
        MonsterDataProto.Builder builder = MonsterDataProto.newBuilder();
        builder.setId(id).setName(ByteString.copyFrom(clientDisplayName))
                .setLevel(level).setType(type).setRes(res).setHead(head)
                .setStat(stat.encode());

        if (chat.length > 0){
            builder.setChatInterval(chatInterval);
            for (String c : chat){
                builder.addChat(ByteString.copyFromUtf8(c));
            }
        }

        for (SingleEffectSpellWithRate specialSpell : specialSpells){
            builder.addSpecialSpellId(specialSpell.spell.spellAnimationID);
            builder.addSpecialSpellName(ByteString
                    .copyFrom(specialSpell.spell.nameBytes));
        }

        if (scene != null){
            if (!(scene instanceof DefenceDungeonSceneData)
                    && !(scene instanceof LongMaiDungeonSceneData)){
                // 所有的场景都encode, 除了 守护孔慈/守护龙脉 里的怪不要encode场景和坐标
                builder.setSceneId(scene.id);

                for (int pos : navigatePoses){
                    builder.addPos(pos);
                }
            }
        }

        if (!plunderTips.isEmpty()){
            builder.setPlunderTips(ByteString.copyFromUtf8(plunderTips));
        }

        if (rankCount > 0){
            builder.setRankCount(rankCount);
            for (GoodsWrapper g : rankPrizeGoods){
                builder.addRankGoods(g.encode4Client());
            }
        }

        return builder.build();
    }

    @Override
    public String toString(){
        return id + "-" + name;
    }

    public boolean needBroadcastTarget(){
        return needBroadcastTarget;
    }

    public SceneData getScene(){
        return scene;
    }

    public int[] getNavigatePoses(){
        return navigatePoses;
    }

    public boolean isBoss(){
        return isBoss;
    }

    public boolean isMustDie(){
        return isMustDie;
    }

    public boolean needEncodeToClient;

    boolean needEncodeToClient(){
        return needEncodeToClient;
    }

    void setScene(SceneData sceneData, int[] poses){
        needEncodeToClient = true;

        // 支持一个怪既可以放在副本中, 又可以放在普通场景中
        if (scene == null){
            scene = sceneData;
            posList = new IntArrayList();
        } else{
            checkArgument(scene.id == sceneData.id,
                    "一种怪物只能出现在一个场景内. %s 出现在了 %s 和 %s 中", this, sceneData, scene);
        }

        for (int pos : poses){
            posList.add(pos);
        }
    }

    void initNavigatePoses(){
        if (scene == null)
            return;

        checkArgument(posList != null && !posList.isEmpty(),
                "初始化怪物寻路点时，发现怪物没有寻路点, %s", name);

        // 把所有怪物根据X坐标和Y坐标分成4等分，在4个区域中选中4个位置
        // 遍历每个区域的各个位置，选择周围4格内本区域怪物最多的那个位置

        int avgX = 0;
        int avgY = 0;
        for (int i = 0; i < posList.size(); i++){
            int pos = posList.get(i);
            int x = Utils.getHighShort(pos);
            int y = Utils.getLowShort(pos);
            avgX += x;
            avgY += y;
        }
        avgX = avgX / posList.size();
        avgY = avgY / posList.size();

        IntArrayList area1 = new IntArrayList();
        IntArrayList area2 = new IntArrayList();
        IntArrayList area3 = new IntArrayList();
        IntArrayList area4 = new IntArrayList();
        for (int i = 0; i < posList.size(); i++){
            int pos = posList.get(i);
            int x = Utils.getHighShort(pos);
            int y = Utils.getLowShort(pos);

            if (x < avgX){
                if (y < avgY){
                    area1.add(pos);
                } else{
                    area2.add(pos);
                }
            } else{
                if (y < avgY){
                    area3.add(pos);
                } else{
                    area4.add(pos);
                }
            }
        }

        IntArrayList navigateList = new IntArrayList(4);
        if (!area1.isEmpty())
            navigateList.add(findNavigatePos(area1, avgX, avgY));

        if (!area2.isEmpty())
            navigateList.add(findNavigatePos(area2, avgX, avgY));

        if (!area3.isEmpty())
            navigateList.add(findNavigatePos(area3, avgX, avgY));

        if (!area4.isEmpty())
            navigateList.add(findNavigatePos(area4, avgX, avgY));

        navigatePoses = navigateList.toArray();
        posList = null; // 清空
    }

    private int findNavigatePos(IntArrayList area, int avgX, int avgY){
        assert !area.isEmpty();

        // 找周围4格内怪物最多的那个位置，如果怪物个数一样多，则选择离中心点远的那个点

        int navigatePos = 0;
        int maxCount = 0;
        int distance = 0;
        for (int i = 0; i < area.size(); i++){
            int pos = area.get(i);
            int x = Utils.getHighShort(pos);
            int y = Utils.getLowShort(pos);

            int nearCount = 0;
            for (int j = 0; j < area.size(); j++){
                int checkPos = area.get(j);

                if (Utils.isInEasyRange(x, y, Utils.getHighShort(checkPos),
                        Utils.getLowShort(checkPos), 4)){
                    nearCount++;
                }
            }

            if (nearCount > maxCount){
                maxCount = nearCount;
                navigatePos = pos;
                distance = (x - avgX) * (x - avgX) + (y - avgY) * (y - avgY);
            } else if (nearCount == maxCount){
                int newDistance = (x - avgX) * (x - avgX) + (y - avgY)
                        * (y - avgY);
                if (newDistance > distance){
                    maxCount = nearCount;
                    navigatePos = pos;
                    distance = newDistance;
                }
            }
        }

        return navigatePos;
    }
}
