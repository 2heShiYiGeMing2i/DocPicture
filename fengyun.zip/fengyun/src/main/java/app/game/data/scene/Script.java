package app.game.data.scene;

/**
 * npc对话信息
 * @author Timmy
 *
 */
public class Script{

    public final String name;

    Script(String name, String content){
        this.name = name;
    }
}
