package app.game.data.mount;

import static com.mokylin.sink.util.Preconditions.checkArgument;
import static com.mokylin.sink.util.Preconditions.checkNotNull;
import app.game.data.SpriteStat;
import app.game.module.scene.FightData;
import app.protobuf.SpriteStatContent.SpriteStatProto;

import com.mokylin.collection.IntHashMap;

/**
 * @author Liwei
 *
 */
public class MountAddedDatas{

    /**
     * 坐骑名称
     */
    final String name;

    /**
     * 最高等级
     */
    final int maxLevel;

    /**
     * 等级数据
     */
    final MountAddedData[] datas;

    /**
     * 一级数据
     */
    final transient MountAddedData oneLevelData;

    /**
     * 最高级数据
     */
    final transient MountAddedData maxLevelData;

    MountAddedDatas(String name, IntHashMap<SpriteStat> statMap){
        this.name = name;
        maxLevel = statMap.size();

        datas = new MountAddedData[maxLevel];
        SpriteStat prevStat = null;
        for (int lv = 1; lv <= maxLevel; lv++){
            SpriteStat stat = checkNotNull(statMap.get(lv),
                    "没有找到%s 坐骑的%s级附加属性", name, lv);

            datas[lv - 1] = new MountAddedData(lv, stat);

            if (prevStat != null){
                checkArgument(!stat.hasAnyFieldLessThan(prevStat),
                        "坐骑-%s 的%s 级附加属性字段中居然存在比前一级低的字段", name, lv);
            }
            prevStat = stat;
        }

        oneLevelData = datas[0];
        maxLevelData = datas[maxLevel - 1];
    }

    MountAddedData getAddedData(int level){
        if (level > 0 && level <= maxLevel){
            return datas[level - 1];
        }

        if (level > maxLevel){
            return maxLevelData;
        }

        return oneLevelData;
    }

    public static class MountAddedData{

        public final int level;

        /**
         * 附加属性
         */
        final SpriteStat addedStat;

        final transient SpriteStatProto addedStatProto;

        final transient int addedFightingAmount;

        transient SpriteStat baseAndAddedStat;

        transient int baseAndAddedFightingAmount;

        MountAddedData(int level, SpriteStat addedStat){
            this.level = level;
            this.addedStat = addedStat;

            addedStatProto = addedStat.encode();
            addedFightingAmount = FightData.calculateFightingAmount(addedStat);
        }

        public SpriteStat getStat(){
            return addedStat;
        }
    }
}
