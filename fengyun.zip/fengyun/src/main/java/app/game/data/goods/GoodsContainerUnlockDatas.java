/**
 * 
 */
package app.game.data.goods;

import static com.mokylin.sink.util.Preconditions.checkArgument;

import java.util.List;

import app.game.data.GameObjects;
import app.game.data.SpriteStats;
import app.game.entity.Depot;
import app.game.entity.Storage;

import com.google.common.annotations.VisibleForTesting;
import com.google.inject.Inject;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 * 
 */
public class GoodsContainerUnlockDatas{
    public static final String DEPOT_LOCATION = "config/data/depot_unlock.txt";

    public static final String STORAGE_LOCATION = "config/data/storage_unlock.txt";

    private final GoodsContainerUnlockData[] depotUnlockDatas;

    private final GoodsContainerUnlockData[] storageUnlockDatas;

    @Inject
    GoodsContainerUnlockDatas(GameObjects go, SpriteStats stats){
        List<ObjectParser> data = go.loadFile(DEPOT_LOCATION);
        checkArgument(
                Depot.DEPOT_INIT_SIZE + data.size() == Depot.DEPOT_MAX_SIZE,
                "背包解锁配置表配置的条数错误, init + unlock = max, init:%s max:%s unlock:%s",
                Depot.DEPOT_INIT_SIZE, Depot.DEPOT_MAX_SIZE, data.size());

        int count = data.size() + 1;
        depotUnlockDatas = new GoodsContainerUnlockData[count];

        depotUnlockDatas[0] = GoodsContainerUnlockData.FIRST_DEPOT_UNLOCK_DATA;
        int index = 1;
        for (ObjectParser p : data){
            GoodsContainerUnlockData s = new GoodsContainerUnlockData(index++,
                    p, Depot.DEPOT_INIT_SIZE, stats);

            checkArgument(s.openSlotCount >= 0 && s.openSlotCount < count
                    && depotUnlockDatas[s.openSlotCount] == null,
                    "Duplicate DepotUnlockData id: %s", s.openSlotCount);
            depotUnlockDatas[s.openSlotCount] = s;
        }

        for (int i = 1; i < count; i++){
            depotUnlockDatas[i].init(depotUnlockDatas[i - 1],
                    Depot.DEPOT_ROW_SLOT_COUNT, depotUnlockDatas);
        }

        data = go.loadFile(STORAGE_LOCATION);
        checkArgument(
                Storage.STORAGE_INIT_SIZE + data.size() == Storage.STORAGE_MAX_SIZE,
                "仓库解锁配置表配置的的条数错误, init + unlock = max, init:%s max:%s unlock:%s",
                Storage.STORAGE_INIT_SIZE, Storage.STORAGE_MAX_SIZE,
                data.size());

        count = data.size() + 1;
        storageUnlockDatas = new GoodsContainerUnlockData[count];

        storageUnlockDatas[0] = GoodsContainerUnlockData.FIRST_STORAGE_UNLOCK_DATA;
        index = 1;
        for (ObjectParser p : data){
            GoodsContainerUnlockData s = new GoodsContainerUnlockData(index++,
                    p, Storage.STORAGE_INIT_SIZE, stats);
            checkArgument(s.openSlotCount >= 0 && s.openSlotCount < count
                    && storageUnlockDatas[s.openSlotCount] == null,
                    "Duplicate StorageUnlockData id: %s", s.openSlotCount);
            storageUnlockDatas[s.openSlotCount] = s;
        }

        for (int i = 1; i < count; i++){
            storageUnlockDatas[i].init(storageUnlockDatas[i - 1],
                    Storage.STORAGE_ROW_SLOT_COUNT, storageUnlockDatas);
        }
    }

    public GoodsContainerUnlockData getDepotUnlockData(int openSlotCount){
        return Utils.getValidObject(depotUnlockDatas, openSlotCount);
    }

    public GoodsContainerUnlockData getStorageUnlockData(int openSlotCount){
        return Utils.getValidObject(storageUnlockDatas, openSlotCount);
    }

    @VisibleForTesting
    GoodsContainerUnlockData[] getDepotGlobalMap(){
        return depotUnlockDatas;
    }

    @VisibleForTesting
    GoodsContainerUnlockData[] getStorageGlobalMap(){
        return storageUnlockDatas;
    }

// public GoodsContainerUnlockConfig generateProto(){
// GoodsContainerUnlockConfig.Builder builder = GoodsContainerUnlockConfig
// .newBuilder();
//
// for (int i = 1; i < depotUnlockDatas.length; i++){
// builder.addDepot(depotUnlockDatas[i].encode());
// }
//
// for (int i = 1; i < storageUnlockDatas.length; i++){
// builder.addStorage(storageUnlockDatas[i].encode());
// }
//
// return builder.build();
// }
}
