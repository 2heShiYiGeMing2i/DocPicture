package app.game.data.scene;

import static com.mokylin.sink.util.Preconditions.checkArgument;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.data.GameObjects;
import app.game.data.PrizeConfigs;
import app.game.data.goods.GoodsDatas;

import com.google.inject.Inject;
import com.mokylin.collection.IntHashMap;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * 无绝神阵
 * 
 * 明明就是走传送门, 名字取得这么妖
 * @author Timmy
 *
 */
public class PortalDungeonSceneDatas{
    private static final Logger logger = LoggerFactory
            .getLogger(PortalDungeonSceneDatas.class);

    public static final String LOCATION = GameObjects.PORTAL_SCENE_BASE_FOLDER
            + "wu_jue.txt";

    private final PortalDungeonSceneData sceneData;

    @Inject
    PortalDungeonSceneDatas(GameObjects go, BlockInfos blocks,
            MonsterDatas monsters, Scripts scripts, Plunders plunders, Ais ais,
            SceneTransportDatas transports, GoodsDatas goodsDatas,
            PlunderGroups groups, PrizeConfigs prizes,
            SceneRemoveObjectMsgCache removeMsgCache){

        logger.debug("loading wu jue dungeon scenes");

        List<ObjectParser> list = go.loadFile(LOCATION);
        checkArgument(list.size() == 1, "必须有且只有一条无绝神阵的配置: %s", LOCATION);

        ObjectParser p = list.get(0);

        sceneData = new PortalDungeonSceneData(go, p, blocks, monsters,
                scripts, plunders, ais, transports, goodsDatas, groups, prizes,
                removeMsgCache);
    }

    public PortalDungeonSceneData getSceneData(){
        return sceneData;
    }

    void putAll(IntHashMap<SceneData> totalMap){
        totalMap.putUnique(sceneData.id, sceneData);
    }

}
