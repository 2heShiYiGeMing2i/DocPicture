package app.game.data.scene;

import static com.mokylin.sink.util.Preconditions.checkArgument;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import app.game.data.GameObjects;
import app.game.data.SpriteStats;
import app.game.data.goods.GoodsDatas;
import app.game.data.goods.GoodsWrapper;
import app.game.data.spell.Spells;
import app.i18n.I18NConfigs;
import app.protobuf.ConfigContent.MonsterConfig;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.inject.Inject;
import com.mokylin.collection.IntHashMap;
import com.mokylin.sink.util.parse.ObjectParser;

public class MonsterDatas{

    public static final String LOCATION = GameObjects.SCENE_BASE_FOLDER
            + "monster.txt";

    private final IntHashMap<MonsterData> idMap;

    private final HashMap<String, MonsterData> nameMap;

    @Inject
    MonsterDatas(GameObjects go, SpriteStats spriteStats, Spells spells,
            GoodsDatas goodsDatas, I18NConfigs i18nConfigs){
        List<ObjectParser> data = go.loadFile(LOCATION);

        idMap = new IntHashMap<>();
        nameMap = new HashMap<>(data.size());

        Map<String, GoodsWrapper> showPlunderCache = Maps.newHashMap();
        List<GoodsWrapper> showGoodsList = Lists.newArrayList();
        for (ObjectParser p : data){
            MonsterData m = new MonsterData(p, spriteStats, spells, goodsDatas,
                    showPlunderCache, i18nConfigs.getI18N(), showGoodsList);

            checkArgument(idMap.put(m.id, m) == null, "怪物表monster.txt中ID重复");
            checkArgument(nameMap.put(m.name, m) == null, "怪物表monster.txt中名字重复");
        }

        showPlunderCache.clear();
        showGoodsList.clear();
    }

    public MonsterData get(int id){
        return idMap.get(id);
    }

    public MonsterData get(String name){
        return nameMap.get(name);
    }

    public Collection<MonsterData> all(){
        return nameMap.values();
    }

    public void initNavigatePoses(){
        for (MonsterData mon : idMap.values()){
            mon.initNavigatePoses();
        }
    }

    public MonsterConfig generateProto(){
        MonsterConfig.Builder builder = MonsterConfig.newBuilder();

        for (MonsterData mon : idMap.values()){
            if (mon.needEncodeToClient())
                builder.addMonsters(mon.encode4Client());
        }
        return builder.build();
    }
}
