package app.game.data.spell;

import static com.mokylin.sink.util.Preconditions.*;

import org.jboss.netty.buffer.BigEndianHeapChannelBuffer;
import org.jboss.netty.buffer.ChannelBuffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.data.GameObject;
import app.game.data.SpriteStat;
import app.game.data.SpriteStats;
import app.protobuf.ConfigContent.SingleState;
import app.protobuf.HeroServerContent.FightDataProto;

import com.google.protobuf.ByteString;
import com.mokylin.sink.util.BufferUtil;
import com.mokylin.sink.util.RandomNumber;
import com.mokylin.sink.util.parse.ObjectParser;

public class FightState extends GameObject{

    private static final Logger logger = LoggerFactory
            .getLogger(FightState.class);
    public static final FightStateWithRate[] EMPTY_FightStateWithRate_ARRAY = new FightStateWithRate[0];

    public static final FightStateInstance[] EMPTY_FightStateInstance_ARRAY = new FightStateInstance[0];

    public static final FightState[] EMPTY_ARRAY = new FightState[0];

    private final Animation stateAnimation;

    private final String icon;

    /**
     * 增加的属性
     */
    public final SpriteStat spriteStat;

    public final int group;

    public final int level;

    /**
     * 总生效次数, 总生效时间: totalTick * frameTime
     */
    public final int totalTick;

    /**
     * 每次生效间隔
     */
    public final int frameTime;

    public final int eachLife;

    public final float eachLifePer;

    public final int eachJumpShield;

    /**
     * 经验倍率，1表示双倍经验，2表示3倍经验
     */
    public final float expMultiple;

    /**
     * 是否是buff
     */
    public final boolean isBuff;

    /**
     * 是否是晕眩, 无法移动, 无法攻击, 无法跳跃
     */
    public final boolean isStun;

    /**
     * 是否不可移动
     */
    public final boolean isUnmovable;

    /**
     * 是否无法放技能
     */
    public final boolean isHush;

    /**
     * 是否射马
     */
    public final boolean isShootMount;

    /**
     * 是否死亡驱散
     */
    public final boolean isDeathDispel;

    /**
     * 是否下线驱散
     */
    public final boolean isOfflineDispel;

    /**
     * 是否经验丹
     */
    public final boolean isExpMultiple;

    /**
     * 最大堆叠层数
     */
    public final int maxStackCount;

    /**
     * 描述
     */
    public final String description;

    /**
     * 中了这个状态之后要提示的信息
     */
    public final String noticeOnAdd;

    /**
     * 叠加/覆盖 类型
     * 
     * 1. 叠加效果, 时间刷新
     * 
     * 2. 不叠加效果, 只刷新时间
     * 
     * 3. 重复无效, 不给加
     * 
     * 4. 时间叠加, 效果不叠加, 层数概念还是有, 但是客户端不显示层数
     */
    public final int stackType;
    /**
     * 叠加效果, 时间刷新
     */
    public static final int STACK_TYPE_STACK_EFFECT_AND_REFRESH_TIME = 1;
    /**
     * 不叠加效果, 只刷新时间
     */
    public static final int STACK_TYPE_NO_STACK_EFFECT_JUST_REFRESH_TIME = 2;
    /**
     * 重复无效, 不给叠加
     */
    public static final int STACK_TYPE_NO_SUBSTITUTE = 3;
    /**
     * 时间叠加, 效果不叠加
     */
    public static final int STACK_TYPE_NO_STACK_EFFECT_AND_POSTPONE_TIME = 4;

    public final transient boolean affectsState;

    public final transient boolean affectsLife;

    private final transient long totalTime;

    public final FightState nextStackInstance;

    /**
     * 当前这个状态叠加的层数
     */
    public final transient int currentStack;

    /**
     * 最大剩余时间. 只供叠加类型是4(时间叠加)的使用
     */
    private final transient long maxRemainingTime;

    private final transient FightState[] fightStateWithStack;

    FightState(ObjectParser p, SpriteStats stats, Animations animations){
        super(p);

        String animationID = p.getKey("animation");
        if (animationID.length() > 0){
            stateAnimation = checkNotNull(animations.get(animationID),
                    "没有找到状态 %s 的特效animation: %s", this, animationID);
        } else{
            stateAnimation = null;
        }

        this.group = p.getIntKey("group");
        this.level = p.getIntKey("level");
        this.icon = p.getKey("icon");
        this.description = p.getKey("description");
        this.noticeOnAdd = p.getKey("notice_on_add");

        // spriteStat
        int statID = p.getIntKey("sprite_stat");
        spriteStat = checkNotNull(stats.get(statID), "状态 %s 的属性id没找到: %s",
                this, statID);

        totalTick = p.getIntKey("total_tick");
        frameTime = p.getIntKey("frame_time");
        this.totalTime = totalTick * frameTime;

        eachLife = p.getIntKey("each_life");
        eachLifePer = p.getIntKey("each_life_per") / 100f;

        expMultiple = p.getIntKey("exp_multiple") / 100f;
        checkArgument(expMultiple >= 0, "状态 %s 的经验倍率居然<0, mul: %s", this,
                expMultiple);

        eachJumpShield = p.getIntKey("each_jump_shield");

        isBuff = p.getBooleanKey("is_buff");

        isStun = p.getBooleanKey("is_stun");
        isUnmovable = p.getBooleanKey("is_unmovable");
        isHush = p.getBooleanKey("is_hush");
        isShootMount = p.getBooleanKey("is_shoot_mount");
        isDeathDispel = p.getBooleanKey("is_death_dispel");
        isOfflineDispel = p.getBooleanKey("is_offline_dispel");

        stackType = p.getIntKey("stack_type");

        affectsLife = eachLife != 0 || eachLifePer != 0;
        affectsState = affectsLife || eachJumpShield != 0;

        // 经验丹
        isExpMultiple = expMultiple > 0;
        if (isExpMultiple){
            checkArgument(isBuff, "状态%s 加经验倍率，但是居然不是Buff", this);

            checkArgument(
                    stackType == STACK_TYPE_NO_STACK_EFFECT_AND_POSTPONE_TIME,
                    "状态%s 加经验倍率，但是居然不是叠加时间的状态");

            checkArgument(!isSingleEffective(), "状态%s 加经验倍率，但是居然是一次性的状态", this);
        }

        int maxStackCount = p.getIntKey("max_stack_count");
        if (isSingleEffective()){
            // 如果默认不配，也算对的
            checkArgument(maxStackCount <= 1, "状态 %s 只能生效一次, 那最大堆叠次数 > 1有啥用?",
                    this);
            maxStackCount = 1;

            // 单次生效, 只能有血量/魔法变化，或者射马, 不能有别的东西
            checkArgument(affectsState || isShootMount,
                    "状态 %s totalTick为0, 表示瞬间生效, 但是完全不改变血量、魔法和跳闪，也没有射马, 没毛用",
                    this);

            checkArgument(spriteStat == SpriteStat.EMPTY_STAT,
                    "状态 %s totalTick为0, 表示瞬间生效, 只能改变血量和魔法，或者射马, 附加的属性没毛用", this);
        } else{
            // 一次性生效的状态，不需要配置stackType

            checkArgument(stackType >= 1 && stackType <= 4,
                    "状态 %s 的stack_type 只能是1-4", this);
            switch (stackType){
                case STACK_TYPE_STACK_EFFECT_AND_REFRESH_TIME:{
                    checkArgument(maxStackCount > 1,
                            "状态 %s 的stack_type 是1, max_stack_count至少要是2", this);
                    break;
                }

                case STACK_TYPE_NO_STACK_EFFECT_JUST_REFRESH_TIME:{
                    checkArgument(maxStackCount == 1,
                            "状态 %s 的stack_type 是2, max_stack_count只能是1", this);
                    break;
                }

                case STACK_TYPE_NO_SUBSTITUTE:{
                    checkArgument(maxStackCount == 1,
                            "状态 %s 的stack_type 是3, max_stack_count只能是1", this);
                    break;
                }

                case STACK_TYPE_NO_STACK_EFFECT_AND_POSTPONE_TIME:{
                    checkArgument(maxStackCount > 1,
                            "状态 %s 的stack_type 是4, max_stack_count至少要是2", this);
                    break;
                }

                default:{
                    throw new IllegalArgumentException("状态的stack_type 只能是1-4: "
                            + this.toString());
                }
            }

            if (!affectsState){
                checkArgument(totalTick == 1,
                        "状态 %s 不是HOT/DOT, 总生效次数total_tick只能是1", this);
            }
        }

        this.maxStackCount = maxStackCount;

        if (isBuff){
            checkArgument(eachLife >= 0 && eachLifePer >= 0,
                    "状态 %s 是buff, 怎么还减血?", this);
            checkArgument(eachJumpShield >= 0, "状态 %s 是buff, 怎么还减跳闪值?", this);
            checkArgument(!isStun, "状态 %s 是buff, 怎么还带晕", this);
            checkArgument(!isUnmovable, "状态 %s 是buff, 怎么还不能移动", this);
            checkArgument(!isHush, "状态 %s 是buff, 怎么还带沉默", this);

            checkArgument(!isShootMount, "状态 %s 是buff, 怎么还带射马", this);
        } else{
            checkArgument(eachLife <= 0 && eachLifePer <= 0,
                    "状态 %s 不是buff, 怎么还加血?", this);

            checkArgument(eachJumpShield <= 0, "状态 %s 是buff, 怎么还加跳闪值?", this);
        }

        this.currentStack = 1;

        if (stackType == STACK_TYPE_STACK_EFFECT_AND_REFRESH_TIME){
            nextStackInstance = new FightState(this, 2);
            fightStateWithStack = new FightState[maxStackCount];
            fightStateWithStack[0] = this;

            for (int i = 1; i < maxStackCount; i++){
                fightStateWithStack[i] = fightStateWithStack[i - 1].nextStackInstance;
            }

        } else{
            nextStackInstance = null;
            fightStateWithStack = new FightState[1];
            fightStateWithStack[0] = this;
        }

        if (stackType == STACK_TYPE_NO_STACK_EFFECT_AND_POSTPONE_TIME){
            maxRemainingTime = totalTime * maxStackCount; // 最大持续时间是最大堆叠层数+每一层的持续时间
        } else{
            maxRemainingTime = totalTime;
        }
    }

    public FightState getStack(int stack){
        if (stack <= fightStateWithStack.length){
            return fightStateWithStack[stack - 1];
        }
        return fightStateWithStack[fightStateWithStack.length - 1];
    }

    public boolean isSingleEffective(){
        return totalTick == 0;
    }

    public boolean isAffectStat(){
        return spriteStat != SpriteStat.EMPTY_STAT;
    }

    public boolean needSendToClient(){
        return !isSingleEffective(); // TODO 使用到的才发
    }

    public SingleState generateProto(){
        SingleState.Builder builder = SingleState.newBuilder();
        builder.setId(id).setName(ByteString.copyFrom(nameBytes))
                .setGroup(group).setStackType(stackType)
                .setDescription(ByteString.copyFromUtf8(description))
                .setIcon(icon);

        if (noticeOnAdd.length() > 0){
            builder.setNoticeOnAdd(ByteString.copyFromUtf8(noticeOnAdd));
        }

        if (isBuff){
            builder.setIsBuff(true);
        }

        if (isStun){
            builder.setIsStun(true);
        }

        if (isUnmovable){
            builder.setIsUnmovable(true);
        }

        if (isHush){
            builder.setIsHush(true);
        }

        if (stateAnimation != null){
            builder.setAnimation(stateAnimation.id);
        }

        return builder.build();
    }

    /**
     * 能叠加效果的state. 改变原来的state的spriteStat和eachLife之类的
     * 
     * @param copy
     * @param multiple
     */
    private FightState(FightState copy, int multiple){
        super(copy);

        this.currentStack = multiple;
        this.spriteStat = copy.spriteStat.multiply(multiple);
        this.eachLife = copy.eachLife * multiple;
        this.eachLifePer = copy.eachLifePer * multiple;
        this.expMultiple = copy.expMultiple * multiple; // 这玩意应该是0
        this.eachJumpShield = copy.eachJumpShield * multiple;
        this.fightStateWithStack = copy.fightStateWithStack;

        // 别的都一样
        this.description = copy.description;
        this.noticeOnAdd = copy.noticeOnAdd;
        this.icon = copy.icon;
        this.stateAnimation = copy.stateAnimation;
        this.group = copy.group;
        this.level = copy.level;
        this.totalTick = copy.totalTick;
        this.frameTime = copy.frameTime;
        this.isBuff = copy.isBuff;
        this.isStun = copy.isStun;
        this.isUnmovable = copy.isUnmovable;
        this.isHush = copy.isHush;
        this.isShootMount = copy.isShootMount;
        this.isDeathDispel = copy.isDeathDispel;
        this.isOfflineDispel = copy.isOfflineDispel;
        this.isExpMultiple = copy.isExpMultiple;

        this.maxStackCount = copy.maxStackCount;
        this.stackType = copy.stackType;

        this.affectsLife = copy.affectsLife;
        this.affectsState = copy.affectsState;
        this.totalTime = copy.totalTime;
        this.maxRemainingTime = copy.maxRemainingTime;

        if (multiple < maxStackCount){
            this.nextStackInstance = new FightState(copy, multiple + 1);
        } else{
            this.nextStackInstance = null;
        }
    }

    // -------------- 加在人物身上的状态 --------------
    /**
     * 是否是同一类型的, 要判断是否顶掉
     * 
     * @param fsi
     * @return
     */
    public boolean isSameGroup(FightStateInstance fsi){
        return group == fsi.actualState.group
                && stackType == fsi.actualState.stackType;
    }

    public FightStateInstance newInstanceWithDisappearTime(long ctime,
            long disappearTime){
        return new FightStateInstance(this, disappearTime, ctime + frameTime);
    }

    /**
     * 新建一个状态, 根据叠加/替换规则. 这个状态会顶掉别的所有group相同和stackType相同的状态
     * 
     * @param lastInstance
     * @param casterID
     * @param ctime
     * @return
     */
    public FightStateInstance newInstance(FightStateInstance lastInstance,
            long ctime, int multiple){
        // 之前没有这状态, 新建一个
        if (lastInstance == null){
            // 处理多倍的问题
            if (multiple > maxStackCount){
                return null; // 超出最大的层数
            }

            if (multiple > 1){
                switch (stackType){
                    case STACK_TYPE_STACK_EFFECT_AND_REFRESH_TIME:{
                        // 叠加层数
                        FightState realState = getStack(multiple);
                        return new FightStateInstance(realState, ctime);

                    }
                    case STACK_TYPE_NO_STACK_EFFECT_AND_POSTPONE_TIME:{
                        // 叠加时间
                        return new FightStateInstance(this, ctime + totalTime
                                * multiple, ctime + frameTime);
                    }
                }
            }

            return new FightStateInstance(this, ctime);
        }

        if (lastInstance.actualState.level > level){
            // 之前的等级比这个高
            return null;
        }

        switch (stackType){
            case STACK_TYPE_STACK_EFFECT_AND_REFRESH_TIME:{

                int newStack = multiple;
                if (lastInstance.actualState.id == id){
                    newStack += lastInstance.actualState.currentStack;
                }

                if (newStack > maxStackCount){
                    // 已经是满层了
                    return null; // 不给叠加了, 也不刷新时间, 反正这次添加失败
                }

                FightState realState = getStack(newStack);
                return new FightStateInstance(realState, ctime);
            }

            case STACK_TYPE_NO_STACK_EFFECT_JUST_REFRESH_TIME:{
                // 直接替换
                return new FightStateInstance(this, ctime);
            }

            case STACK_TYPE_NO_SUBSTITUTE:{
                // 不给替换
                return null;
            }

            case STACK_TYPE_NO_STACK_EFFECT_AND_POSTPONE_TIME:{

                if (lastInstance.actualState.id == id){
                    long newDisappearTime = lastInstance.disappearTime
                            + totalTime * multiple;
                    if (newDisappearTime > ctime + maxRemainingTime){
                        // 剩余时间再加这个Buff的话, 超出了最大剩余时间, 不给加
                        return null;
                    }

                    return new FightStateInstance(lastInstance.actualState,
                            newDisappearTime, lastInstance.nextWorkingTime); // 增加结束时间,
                                                                             // 不改变下一次生效时间
                } else{
                    // 不同的状态, 重新计算层数和时间
                    return new FightStateInstance(this, ctime + totalTime
                            * multiple, ctime + frameTime);
                }
            }

            default:{
                logger.error("状态的stack_type未知: {}: {}", this, stackType);
                return null;
            }
        }
    }

    /**
     * 实例, 加在英雄或怪物身上的
     * 
     * @author Timmy
     * 
     */
    public static class FightStateInstance{
        private final FightState actualState;
        public final long disappearTime;
        public long nextWorkingTime;
        private final byte[] msgData;

        /**
         * 普通状态
         * 
         * @param actualState
         * @param ctime
         */
        private FightStateInstance(FightState actualState, long ctime){
            this(actualState, ctime + actualState.totalTime, ctime
                    + actualState.frameTime);
        }

        /**
         * 叠加了时间的
         * 
         * @param actualState
         * @param disappearTime
         * @param nextWorkingTime
         */
        private FightStateInstance(FightState actualState, long disappearTime,
                long nextWorkingTime){
            this.actualState = actualState;
            this.disappearTime = disappearTime;
            this.nextWorkingTime = nextWorkingTime;

            ChannelBuffer buffer = new BigEndianHeapChannelBuffer(
                    BufferUtil.computeVarInt32Size(actualState.id)
                            + BufferUtil
                                    .computeVarInt32Size(actualState.currentStack)
                            + BufferUtil.computeVarInt64Size(disappearTime));
            // TODO actualState.id+actualState.currentStack 初始化时可缓存
            BufferUtil.writeVarInt32(buffer, actualState.id);
            BufferUtil.writeVarInt32(buffer, actualState.currentStack);
            BufferUtil.writeVarInt64(buffer, disappearTime);
            msgData = buffer.array();
        }

        public void tick(){
            nextWorkingTime += actualState.frameTime;
        }

        public FightState getActualState(){
            return actualState;
        }

        public int getCurrentStack(){
            return actualState.currentStack;
        }

        public void encode(FightDataProto.Builder builder, long ctime){
            long remainTime = disappearTime - ctime; // 保存的是剩余时间
            if (remainTime > 0){
                builder.addStateId(actualState.id);
                builder.addStateStackCount(actualState.currentStack);
                builder.addStateDisappearTime(remainTime);
            }
        }

        public void writeTo(ChannelBuffer buffer){
            buffer.writeBytes(msgData);
        }

        public int getMsgDataLen(){
            return msgData.length;
        }
    }

    public FightStateInstance decode(int stackCount, long disappearTime,
            long ctime){
        FightState state = getStack(stackCount);
        return new FightStateInstance(state, disappearTime,
                state.affectsState ? ctime + state.frameTime : disappearTime);
    }

    // ---------- 附加概率 ------------
    private FightStateWithRate100 cacheRate100;

    public FightStateWithRate withRate(int rate){
        checkArgument(rate > 0 && rate <= 100, "技能的概率必须是1-100: %s", rate);
        if (rate == 100){
            if (cacheRate100 != null){
                return cacheRate100;
            }
            return (cacheRate100 = new FightStateWithRate100());
        }
        return new FightStateWithRate(rate);
    }

    private class FightStateWithRate100 extends FightStateWithRate{

        public FightStateWithRate100(){
            super(100);
        }

        public boolean tryRelease(){
            return true;
        }
    }

    public class FightStateWithRate{

        private final int rate;

        public FightStateWithRate(int rate){
            this.rate = rate;
        }

        public boolean tryRelease(){
            return RandomNumber.getRate() < rate;
        }

        public FightState getActualFightState(){
            return FightState.this;
        }

        @Override
        public String toString(){
            return FightState.this.toString();
        }
    }

}
