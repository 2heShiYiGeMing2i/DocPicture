package app.game.data.task;

import app.game.data.Prize;
import app.game.data.PrizeConfig;
import app.game.data.task.TaskTarget.TaskTargetProgress;
import app.protobuf.GoodsServerContent.Quality;
import app.protobuf.HeroServerContent.ChanceTaskServerProto;
import app.protobuf.TaskContent.ChanceTaskProto;

/**
 * @author Liwei
 *
 */
public class ChanceTask{

    private final int taskId;

    final ChanceTaskData data;

    final TaskTargetProgress[] progress;

    int swallowPercent;

    Prize chanceTaskPrize;

    ChanceTask(int taskId, ChanceTaskData data, TaskTargetProgress[] progress,
            Prize chanceTaskPrize){
        super();
        this.taskId = taskId;
        this.data = data;
        this.progress = progress;
        this.chanceTaskPrize = chanceTaskPrize;

        if (data.baseExp > 0)
            swallowPercent = (chanceTaskPrize.getExp() - data.baseExp) * 100
                    / data.baseExp;
    }

    public int getTaskId(){
        return taskId;
    }

    public int getIntType(){
        return data.getIntType();
    }

    public int getRealTaskId(){
        return data.id;
    }

    public ChanceTaskData getData(){
        return data;
    }

    public int getSwallowPercent(){
        return swallowPercent;
    }

    public Prize getPrize(){
        return chanceTaskPrize;
    }

    public TaskTargetProgress[] getProgress(){
        return progress;
    }

    public boolean isAllProgressCompleted(){
        for (TaskTargetProgress p : progress){
            if (!p.isCompleted())
                return false;
        }

        return true;
    }

    ChanceTaskProto encode4Client(){
        return data.encode4Client(taskId, chanceTaskPrize, progress,
                swallowPercent);
    }

    ChanceTaskServerProto encode(){
        ChanceTaskServerProto.Builder builder = ChanceTaskServerProto
                .newBuilder();

        builder.setChanceTaskId(data.id);

        if (chanceTaskPrize != null){
            builder.setPrize(chanceTaskPrize.encode());
        }

        for (TaskTargetProgress p : progress){
            builder.addProgress(p.progress);
        }

        return builder.build();
    }

    static ChanceTask decode(int taskId, Prize chanceTaskPrize,
            ChanceTaskData data, ChanceTaskServerProto proto){
        return new ChanceTask(taskId, data, data.taskData.newProgress(taskId,
                proto.getProgressList()), chanceTaskPrize);
    }

    public int getAutoCompleteTimesLimit(){
        return data.relatedData.autoCompleteLimit;
    }

    public boolean isAutoCompleteTimesLimit(){
        return data.relatedData.autoCompleteLimit > 0;
    }

    public int getAutoCompleteCost(){
        return data.relatedData.autoCompleteCost;
    }

    public int randomSwallowPercent(){
        return data.relatedData.randomSwallowPercent();
    }

    public Quality getQuality(){
        return data.quality;
    }

    public Prize swallow(ChanceTask beSwallowedTask, float multiple){

        PrizeConfig basePrize = beSwallowedTask.data.prizeConfig;

        Prize.Builder builder = Prize.newBuilder().add(chanceTaskPrize);

        // 吞噬获得的，就不衰减
        builder.addExp(beSwallowedTask.chanceTaskPrize.getExp()
                - basePrize.getExp());
        builder.addMoney(beSwallowedTask.chanceTaskPrize.getMoney()
                - basePrize.getMoney());
        builder.addGuildLilian(beSwallowedTask.chanceTaskPrize.getGuildLilian()
                - basePrize.getGuildLilian());
        builder.addRealAir(beSwallowedTask.chanceTaskPrize.getRealAir()
                - basePrize.getRealAir());
        builder.addHonor(beSwallowedTask.chanceTaskPrize.getHonor()
                - basePrize.getHonor());

        if (basePrize.getExp() > 0)
            builder.addExp((int) (basePrize.getExp() * multiple));

        if (basePrize.getMoney() > 0)
            builder.addMoney((int) (basePrize.getMoney() * multiple));

        if (basePrize.getGuildLilian() > 0)
            builder.addGuildLilian((int) (basePrize.getGuildLilian() * multiple));

        if (basePrize.getRealAir() > 0)
            builder.addRealAir((int) (basePrize.getRealAir() * multiple));

        chanceTaskPrize = builder.build();
        if (data.baseExp > 0)
            swallowPercent = (int) ((chanceTaskPrize.getExp() - data.baseExp) * 100L / data.baseExp);

        return chanceTaskPrize;
    }
}
