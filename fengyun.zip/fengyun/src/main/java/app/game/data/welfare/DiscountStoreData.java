package app.game.data.welfare;

import static com.mokylin.sink.util.Preconditions.checkArgument;

import java.util.List;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.data.ServerData;
import app.game.data.goods.GoodsDatas;
import app.game.module.promotion.PromotionSinceServerStart;
import app.game.module.promotion.PromotionTimeData;
import app.game.module.promotion.discount.DiscountMessages;
import app.protobuf.ConfigContent.DiscountStoreProto;

import com.google.common.collect.Lists;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class DiscountStoreData{

    static final DiscountStoreData[] EMPTY_ARRAY = new DiscountStoreData[0];

    private final PromotionTimeData promotionTimeData;

    // 折扣物品
    private final List<DiscountGoods> goodsList;

    private final String title;

    private final ChannelBuffer[] storeInfoMsgs;

    DiscountStoreData(String fileName, List<ObjectParser> parser,
            GoodsDatas goodsDatas, ServerData[] serverDatas,
            PromotionSinceServerStart serverStartPromotion){

        this.promotionTimeData = new PromotionTimeData("折扣店", fileName,
                serverDatas, serverStartPromotion);

        title = parser.get(0).getKey("title");
        checkArgument(!title.isEmpty(), "%s 必须配置标题title", this);

        goodsList = Lists.newArrayList();
        for (ObjectParser p : parser){
            goodsList.add(new DiscountGoods(this, p, goodsDatas));
        }

        DiscountStoreProto.Builder builder = DiscountStoreProto.newBuilder();
        builder.setTitle(title);
        for (DiscountGoods goods : goodsList){
            builder.addGoodsArray(goods.encode());
        }

        storeInfoMsgs = new ChannelBuffer[serverDatas.length];
        for (ServerData serverData : serverDatas){
            int i = serverData.sequence;
            builder.setStartTime(promotionTimeData.getStartTime(i));
            builder.setEndTime(promotionTimeData.getEndTime(i));

            storeInfoMsgs[i] = DiscountMessages.getDiscountStoreInfo(builder
                    .build());
        }
    }

    public ChannelBuffer getMsg(ServerData serverData){
        return getMsg(serverData.sequence);
    }

    public ChannelBuffer getMsg(int serverSequence){
        return storeInfoMsgs[serverSequence];
    }

    public int getSize(){
        return goodsList.size();
    }

    public DiscountGoods getGoods(int index){
        return goodsList.get(index);
    }

    public PromotionTimeData getPromotionTimeData(){
        return promotionTimeData;
    }

    DiscountStoreProto.Builder encodeCommonData(){
        DiscountStoreProto.Builder builder = DiscountStoreProto.newBuilder();

        builder.setTitle(title);

        for (DiscountGoods goods : goodsList){
            builder.addGoodsArray(goods.encode());
        }

        return builder;
    }

    @Override
    public String toString(){
        return "折扣店 " + promotionTimeData.toString();
    }
}
