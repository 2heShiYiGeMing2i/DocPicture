package app.game.data;

import static com.mokylin.sink.util.Preconditions.*;

import java.util.List;

import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Lists;

/**
 * 开服后几天, 固定开启活动
 * 
 * @author Timmy
 *
 */
public class FixedTimeDataAfterDate{
    private static final Logger logger = LoggerFactory
            .getLogger(FixedTimeDataAfterDate.class);

    public static FixedTimeDataAfterDate parse(long startTime, String input){
        return new FixedTimeDataAfterDate(startTime, input);
    }

    /**
     * 所有符合的时间点
     */
    private final long[] calculatedTime;

    /**
     * 最后一个符合的时间点
     */
    private final long finalTime;

    /**
     * 
     * @param startTime 起始点
     * @param input 开启的时候, 格式是 [第几天][几点]. 第几天是从1开始的. 例  [1,3,5][18:00] 表示开服的第一第三第五天的18:00开启活动
     */
    private FixedTimeDataAfterDate(long startTime, String input){
        checkNotNull(input);

        List<String> components = Lists.newArrayList();

        int startPos = -1;
        for (int i = 0; i < input.length(); i++){
            char c = input.charAt(i);
            if (c == '['){
                checkArgument(startPos == -1,
                        "时间格式不正确. 应该是 [1,3,5][18:00]: %s", input);
                startPos = i;
            } else if (c == ']'){
                checkArgument(startPos != -1,
                        "时间格式不正确. 应该是 [1,3,5][18:00]: %s", input);
                components.add(input.substring(startPos + 1, i).trim());
                startPos = -1;
            }
        }
        checkArgument(startPos == -1 && components.size() == 2,
                "时间格式不正确. 应该是 [1,3,5][18:00]: %s", input);

        // 解析日期
        String date = components.get(0);

        String[] dates = date.split(",");
        int[] intDates = new int[dates.length];
        for (int i = 0; i < dates.length; i++){
            intDates[i] = Integer.parseInt(dates[i]);
        }
        checkArgument(dates.length > 0,
                "时间格式不正确, 必须填开服后的天数: [1,3,5][18:00]: %s", input);

        checkArgument(intDates[0] >= 1, "时间格式不正确, 开服天数必须至少是1: %s", input);
        for (int i = 1; i < dates.length; i++){
            checkArgument(intDates[i] > intDates[i - 1],
                    "时间格式不正确, 必须是递增的天数: %s", input);
        }

        // 解析时间
        String time = components.get(1);
        int lpos = time.indexOf(":");
        checkArgument(lpos > 0, "时间格式错误, 必须是hh:mm -> %s", input);
        int hour = Integer.parseInt(time.substring(0, lpos));
        int minute = Integer.parseInt(time.substring(lpos + 1));
        checkArgument(hour >= 0 && hour <= 23, "小时必须是0-23: %s", input);
        checkArgument(minute >= 0 && minute <= 59, "分钟必须是0-59: %s", input);

        // ok
        DateTime startT = new DateTime(startTime).withTime(hour, minute, 0, 0);

        this.calculatedTime = new long[intDates.length];
        for (int i = 0; i < intDates.length; i++){
            int day = intDates[i];
            calculatedTime[i] = startT.plusDays(day - 1).getMillis();
        }
        this.finalTime = calculatedTime[calculatedTime.length - 1];
    }

    public long getNextTime(long ctime){
        if (ctime >= finalTime){
            return Long.MAX_VALUE;
        }

        for (long t : calculatedTime){
            if (t > ctime){
                return t;
            }
        }

        // should not be here
        logger.error(
                "FixedTimeDataAfterDate.getNextTime, 竟然运行到了不该到的地方: ctime: {}, finalTime: {}",
                ctime, finalTime);
        return Long.MAX_VALUE;
    }
}
