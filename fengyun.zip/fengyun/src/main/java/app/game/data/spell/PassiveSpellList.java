package app.game.data.spell;

import java.util.EnumMap;

import app.game.data.mount.HeroMount;
import app.game.entity.Hero;
import app.protobuf.HeroServerContent.TriggerType;

import com.google.common.collect.Maps;
import com.mokylin.collection.IntHashMap;
import com.mokylin.sink.util.RandomNumber;
import com.mokylin.sink.util.holder.CountHolder;

public class PassiveSpellList{

    private final EnumMap<TriggerType, IntHashMap<CountHolder<PassiveSpell>>> spellHolderMap;

    /**
     * 攻击别人触发
     */
    private volatile PassiveSpellWithCount[] attackOtherTrigSpells;

    /**
     * 释放攻击技能触发
     */
    private volatile PassiveSpellWithCount[] releaseAttackSpellTrigSpells;

    public PassiveSpellList(Hero hero){
        spellHolderMap = Maps.newEnumMap(TriggerType.class);
        attackOtherTrigSpells = PassiveSpellWithCount.EMPTY_ARRAY;
        releaseAttackSpellTrigSpells = PassiveSpellWithCount.EMPTY_ARRAY;

        // 英雄技能
//        英雄技能只有加属性的被动，这里不管
//        if (hero.getSpellList() != null){ // 让测试通过
//            SpellList spellList = hero.getSpellList();
//            for (PassiveSpell spell : spellList.getPassiveSpells()){
//                if (spell != null){
//                    add(spell);
//                }
//            }
//        }

        // 坐骑技能
        HeroMount mount = hero.getMount();
        if (mount != null && mount.isValid()){
            for (PassiveSpell spell : mount.getSpellList()){
                if (spell != null){
                    add(spell);
                }
            }
        }

        // 别的系统的技能

        // 根据触发条件分类
        classifySpellByTriggerType();
    }

    public void add(PassiveSpell spell){
        IntHashMap<CountHolder<PassiveSpell>> map = spellHolderMap
                .get(spell.triggerType);

        if (map == null){
            map = new IntHashMap<>();
            spellHolderMap.put(spell.triggerType, map);
        }

        CountHolder<PassiveSpell> holder = map.get(spell.id);
        if (holder == null){
            map.put(spell.id, new CountHolder<PassiveSpell>(spell, 1));
        } else{
            holder.incrementAndGet();
        }
    }

    public boolean remove(PassiveSpell spell){
        IntHashMap<CountHolder<PassiveSpell>> map = spellHolderMap
                .get(spell.triggerType);

        if (map == null){
            return false;
        }

        CountHolder<PassiveSpell> holder = map.get(spell.id);
        if (holder == null){
            return false;
        } else{
            if (holder.getValue() > 1){
                holder.decrementAndGet();
            } else{
                map.remove(spell.id);
            }
        }

        return true;
    }

    public void onSpellChanged(){
        classifySpellByTriggerType();
    }

    /**
     * 根据触发类型将技能分类
     */
    private void classifySpellByTriggerType(){

        rebuildAttackOtherSpells();

        rebuildAttackSpellReleased();
    }

    private void rebuildAttackOtherSpells(){
        // 攻击别人时触发
        IntHashMap<CountHolder<PassiveSpell>> attackOtherMap = spellHolderMap
                .get(TriggerType.ATTACK_OTHER);
        if (attackOtherMap == null || attackOtherMap.isEmpty()){
            attackOtherTrigSpells = PassiveSpellWithCount.EMPTY_ARRAY;
        } else{
            PassiveSpellWithCount[] spells = new PassiveSpellWithCount[attackOtherMap
                    .size()];

            int idx = 0;
            for (CountHolder<PassiveSpell> holder : attackOtherMap.values()){
                spells[idx++] = new PassiveSpellWithCount(holder.getKey(),
                        holder.getValue());
            }

            attackOtherTrigSpells = spells;
        }
    }

    private void rebuildAttackSpellReleased(){
        // 技能释放后触发
        IntHashMap<CountHolder<PassiveSpell>> spellReleasedMap = spellHolderMap
                .get(TriggerType.ATTACK_SPELL_RELEASED);
        if (spellReleasedMap == null || spellReleasedMap.isEmpty()){
            releaseAttackSpellTrigSpells = PassiveSpellWithCount.EMPTY_ARRAY;
        } else{
            PassiveSpellWithCount[] spells = new PassiveSpellWithCount[spellReleasedMap
                    .size()];

            int idx = 0;
            for (CountHolder<PassiveSpell> holder : spellReleasedMap.values()){
                spells[idx++] = new PassiveSpellWithCount(holder.getKey(),
                        holder.getValue());
            }

            releaseAttackSpellTrigSpells = spells;
        }
    }

    public PassiveSpellWithCount[] getAttackOtherTrigSpells(){
        return attackOtherTrigSpells;
    }

    public PassiveSpellWithCount[] getReleaseAttackSpellTrigSpells(){
        return releaseAttackSpellTrigSpells;
    }

    public static class PassiveSpellWithCount{

        private static final PassiveSpellWithCount[] EMPTY_ARRAY = new PassiveSpellWithCount[0];

        private final PassiveSpell spell;

//        private final int count;

        private final int rate;

        private PassiveSpellWithCount(PassiveSpell spell, int count){
            this.spell = spell;
//            this.count = count;

            int spellRate = spell.rate;
            if (spellRate >= PassiveSpell.TRIG_RATE){
                this.rate = PassiveSpell.TRIG_RATE;
            } else{
                // 算出多次重复随机的成功概率

                int derate = PassiveSpell.TRIG_RATE - spellRate;

                int rate = spellRate;

                // 需要失败i次才能成功
                for (int i = 1; i < count; i++){
                    int r = spellRate;

                    for (int n = 0; n < i; n++){
                        r = r * derate / PassiveSpell.TRIG_RATE;
                    }

                    if (r <= 0)
                        break;

                    rate += r;
                }

                this.rate = rate;
            }
        }

        public PassiveSpell getSpell(){
            return spell;
        }

        public boolean tryTrigger(){
            return RandomNumber.getRate(PassiveSpell.TRIG_RATE, true) < rate;
        }
    }
}
