package app.game.data.goods;

import app.game.data.SpriteStat;
import app.game.module.scene.FightData;

/**
 * @author Liwei
 *
 */
public class EquipmentExtraStat{

    final int refinedTimes;

    final SpriteStat spriteStat;

    private final SpriteStat totalStat;

    private final int fightingAmount;

    EquipmentExtraStat(int refinedTimes, SpriteStat spriteStat,
            SpriteStat prevTotalStat){
        this.refinedTimes = refinedTimes;
        this.spriteStat = spriteStat;

        if (prevTotalStat == null){
            totalStat = spriteStat;
        } else{
            totalStat = prevTotalStat.add(spriteStat);
        }

        fightingAmount = FightData.calculateFightingAmount(totalStat);
    }

    public int getFightingAmount(){
        return fightingAmount;
    }

    public SpriteStat getTotalStat(){
        return totalStat;
    }
}
