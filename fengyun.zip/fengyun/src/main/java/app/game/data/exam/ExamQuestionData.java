package app.game.data.exam;

import static com.mokylin.sink.util.Preconditions.checkArgument;

import java.util.List;
import java.util.Random;

import app.protobuf.ConfigContent.ExamQuestionProto;
import app.utils.VariableConfig;

import com.mokylin.collection.IntArrayList;
import com.mokylin.sink.util.Empty;
import com.mokylin.sink.util.RandomNumber;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class ExamQuestionData{

    private final String question;

    private final String correctAnswer;

    private final String[] wrongAnswers;

    ExamQuestionData(int index, ObjectParser p, List<String> wrongAnswerList){
        question = p.getKey("question");
        checkArgument(!question.isEmpty(), "答题系统-%s 的问题没有配置", index);

        correctAnswer = p.getKey("correct_answer");
        checkArgument(!correctAnswer.isEmpty(), "答题系统-%s 的正确答案没有配置", index);

        String[] wrongAns = p.getStringArray("wrong_answer");

        wrongAnswerList.clear();
        for (String s : wrongAns){
            if (s != null && !s.isEmpty())
                wrongAnswerList.add(s);
        }

        checkArgument(
                wrongAnswerList.size() >= VariableConfig.ANSWER_COUNT - 1,
                "答题系统-%s 的错误答案个数必须大于等于3", index);

        wrongAnswers = wrongAnswerList.toArray(Empty.STRING_ARRAY);
    }

    public ExamQuestion random(Random random, IntArrayList indexList){

        // 随机正确答案所在的位置
        int correctIndex = RandomNumber.getRate(VariableConfig.ANSWER_COUNT,
                true);

        // 随机3个错误答案
        int[] wrongAnswerIndexs = new int[VariableConfig.ANSWER_COUNT - 1];
        Utils.randomRoundIndex(random, indexList, wrongAnswers.length,
                wrongAnswerIndexs.length);

        for (int i = 0; i < wrongAnswerIndexs.length; i++){
            wrongAnswerIndexs[i] = indexList.get(i);
        }

        return new ExamQuestion(this, correctIndex, wrongAnswerIndexs);
    }

    public static class ExamQuestion{

        private final ExamQuestionData data;

        private final int correctIndex;

        private final int[] wrongAnswerIndexs;

        private ExamQuestion(ExamQuestionData data, int correctIndex,
                int[] wrongAnswerIndexs){
            this.data = data;
            this.correctIndex = correctIndex;
            this.wrongAnswerIndexs = wrongAnswerIndexs;
        }

        public void encode(ExamQuestionProto.Builder builder){
            builder.setQuestion(data.question)
                    .setCorrectAnswer(data.correctAnswer)
                    .setCorrectAnswerIndex(correctIndex);

            for (int idx : wrongAnswerIndexs){
                builder.addWrongAnswers(data.wrongAnswers[idx]);
            }
        }

        public int getCorrectIndex(){
            return correctIndex;
        }
    }
}
