package app.game.data;

import static com.mokylin.sink.util.Preconditions.checkArgument;

import java.util.List;

import app.protobuf.ConfigContent.SignConfig;

import com.google.inject.Inject;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * 签到数据
 * @author Liwei
 *
 */
public class SignDatas{

    private static final String LOCATION = "config/data/welfare/sign.txt";

    private final SignData[] datas;

    @Inject
    SignDatas(GameObjects go, PrizeConfigs prizes){
        List<ObjectParser> data = go.loadFile(LOCATION);
        checkArgument(!data.isEmpty(), "每日签到奖励没有配置");

        datas = new SignData[data.size()];

        int index = 0;
        SignData previous = null;
        for (ObjectParser p : data){
            SignData signData = new SignData(index++, p, prizes);
            datas[signData.id] = signData;

            if (previous != null){
                checkArgument(previous.signTimes < signData.signTimes,
                        "签到数据奖励中，前一次的签到次数必须 < 后一次的签到次数，前: %s 后: %s",
                        previous.signTimes, signData.signTimes);
            }
            previous = signData;
        }
    }

    public SignData get(int idx){
        assert idx >= 0 && idx <= datas.length;
        return datas[idx];
    }

    public SignConfig generateProto(){

        SignConfig.Builder builder = SignConfig.newBuilder();

        for (SignData data : datas){
            builder.addSignTimes(data.signTimes);
            builder.addSignPrize(data.prize.encode4Client());
        }

        return builder.build();
    }
}
