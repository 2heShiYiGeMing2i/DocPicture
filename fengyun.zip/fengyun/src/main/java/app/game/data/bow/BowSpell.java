package app.game.data.bow;

import static com.mokylin.sink.util.Preconditions.checkArgument;
import static com.mokylin.sink.util.Preconditions.checkNotNull;
import app.game.data.spell.PassiveSpell;
import app.game.data.spell.Spell;
import app.game.data.spell.Spells;

import com.mokylin.collection.IntArrayList;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class BowSpell{

    final PassiveSpell[] spellList;

    final int spellCount;

    BowSpell(ObjectParser p, Spells spells){

        String[] spellArray = p.getStringArray("spell");

        IntArrayList spellIdList = new IntArrayList(spellArray.length);

        for (String sp : spellArray){
            if (sp == null || sp.isEmpty())
                continue;

            spellIdList.add(Integer.parseInt(sp));
        }

        spellCount = spellIdList.size();
        checkArgument(spellCount > 0, "弓箭技能列表中没有配置技能");

        checkArgument(spellCount <= 12, "弓箭技能超过12个了，我去，缓存的东西太多了，能不能不要这么搞啊");

        spellList = new PassiveSpell[spellCount];
        for (int i = 0; i < spellCount; i++){
            int id = spellIdList.get(i);

            PassiveSpell spell = spellList[i] = checkNotNull(spells
                    .getPassiveSpells().get(id), "弓箭技能列表中配置的技能不存在， %s", id);

            checkArgument(spell.spellCategory == Spell.BOW_SPELL_CATEGORY,
                    "弓箭技能列表中配置的技能不是弓箭技能, spellCategory: %s",
                    spell.spellCategory);
        }
    }
}
