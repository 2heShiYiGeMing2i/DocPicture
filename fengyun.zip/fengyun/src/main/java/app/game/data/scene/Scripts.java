package app.game.data.scene;

import static com.mokylin.sink.util.Preconditions.checkArgument;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import com.google.inject.Inject;
import com.mokylin.collection.Pair;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.pack.FileLoader;

public class Scripts{

    public static final String LOCATION = "config/data/scene/scripts/";

    private final Map<String, Script> map;

    @Inject
    Scripts(FileLoader loader){
        Collection<Pair<String, String>> files = loader
                .loadFilesInFolder(LOCATION);
        map = new HashMap<String, Script>(files.size());

        for (Pair<String, String> pair : files){
            String name = Utils.stripSuffix(pair.left);
            String content = pair.right;

            Script s = new Script(name, content);
            checkArgument(map.put(name, s) == null, "script怎么可能名字相同捏? %s", name);
        }
    }

    public Script get(String name){
        return map.get(name);
    }
}
