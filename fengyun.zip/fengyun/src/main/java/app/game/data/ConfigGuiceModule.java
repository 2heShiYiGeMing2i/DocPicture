package app.game.data;

import app.game.data.bank.BankDatas;
import app.game.data.bow.BowDatas;
import app.game.data.divine.DivineDatas;
import app.game.data.divine.DivineGlobalLogs;
import app.game.data.exam.ExamDatas;
import app.game.data.fight.FightPosDiffDatas;
import app.game.data.fight.FightRefinedStats;
import app.game.data.fight.OneOnOneDatas;
import app.game.data.gem.GemData;
import app.game.data.goods.EquipmentExtraStats;
import app.game.data.mount.MountDatas;
import app.game.data.pet.PetDatas;
import app.game.data.platform.PVipDatas;
import app.game.data.scene.Npcs;
import app.game.data.task.DailyTaskPrizes;
import app.game.data.task.TaskDatas;
import app.game.data.weapon7.SuperWeaponDatas;
import app.game.data.welfare.FirstLoginPrizeDatas;
import app.game.data.welfare.FirstRechargeDatas;
import app.game.module.TerritoryData;
import app.game.module.guild.GuildContributionGoodsShop;
import app.game.module.guild.GuildFlagDatas;
import app.game.module.guild.LongCityData;
import app.game.module.guild.WushuangCityData;
import app.game.shop.Shops;
import app.i18n.I18NConfigs;
import app.utils.VariableConfig;

import com.google.inject.AbstractModule;
import com.google.inject.Singleton;
import com.mokylin.sink.util.pack.RealFileHorizontalConfigLoader;

/**
 * 配置模块. 需要在别处bind FileLoader和ThreadService
 * 
 * @author Timmy
 * 
 */
public class ConfigGuiceModule extends AbstractModule{

    @Override
    protected void configure(){
        binder().requireExplicitBindings();
        bind(GameObjects.class).in(Singleton.class);
        bind(HorizontalConfigLoader.class).in(Singleton.class);
        bind(RealFileHorizontalConfigLoader.class).in(Singleton.class);
        bind(SpriteStats.class).in(Singleton.class);
        bind(SingleSpriteStats.class).in(Singleton.class);
        bind(ConfigService.class).in(Singleton.class);
        bind(HeroLevelDatas.class).in(Singleton.class);
        bind(Shops.class).in(Singleton.class);
        bind(Races.class).in(Singleton.class);
        bind(Npcs.class).in(Singleton.class);
        bind(TaskDatas.class).in(Singleton.class);
        bind(PrizeConfigs.class).in(Singleton.class);
        bind(I18NConfigs.class).in(Singleton.class);
        bind(DailyTaskPrizes.class).in(Singleton.class);
        bind(GuildFlagDatas.class).in(Singleton.class);
        bind(GuildContributionGoodsShop.class).in(Singleton.class);
        bind(MountDatas.class).in(Singleton.class);
        bind(Vips.class).in(Singleton.class);
        bind(SignDatas.class).in(Singleton.class);
        bind(LotteryDatas.class).in(Singleton.class);
        bind(DivineDatas.class).in(Singleton.class);
        bind(DivineGlobalLogs.class).in(Singleton.class);
        bind(SuperWeaponDatas.class).in(Singleton.class);
        bind(BowDatas.class).in(Singleton.class);
        bind(GemData.class).in(Singleton.class);
        bind(MicroLoginData.class).in(Singleton.class);
        bind(ExamDatas.class).in(Singleton.class);
        bind(VariableConfig.class).in(Singleton.class);
        bind(PetDatas.class).in(Singleton.class);

        bind(OneOnOneDatas.class).in(Singleton.class);
        bind(FightRefinedStats.class).in(Singleton.class);
        bind(FightPosDiffDatas.class).in(Singleton.class);
        bind(FurnaceData.class).in(Singleton.class);
        bind(EquipmentExtraStats.class).in(Singleton.class);
        bind(ShengWangDatas.class).in(Singleton.class);
        bind(ActivityPaybacks.class).in(Singleton.class);

        bind(LongCityData.class).in(Singleton.class);
        bind(WushuangCityData.class).in(Singleton.class);
        bind(TerritoryData.class).in(Singleton.class);
        bind(CouponDatas.class).in(Singleton.class);
        bind(FirstRechargeDatas.class).in(Singleton.class);
        bind(FirstLoginPrizeDatas.class).in(Singleton.class);
        bind(BankDatas.class).in(Singleton.class);
        bind(PVipDatas.class).in(Singleton.class);
    }
}
