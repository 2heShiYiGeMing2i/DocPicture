package app.game.data;

import static com.mokylin.sink.util.Preconditions.checkNotNull;

import org.joda.time.DateTimeConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.data.bank.BankDatas;
import app.game.data.bow.BowDatas;
import app.game.data.divine.DivineDatas;
import app.game.data.exam.ExamDatas;
import app.game.data.fight.OneOnOneDatas;
import app.game.data.gem.GemData;
import app.game.data.goods.EquipmentExtraStats;
import app.game.data.goods.GoodsContainerUnlockDatas;
import app.game.data.goods.GoodsData;
import app.game.data.goods.GoodsDatas;
import app.game.data.goods.TaozDatas;
import app.game.data.mount.MountDatas;
import app.game.data.pet.PetDatas;
import app.game.data.scene.CollectObjects;
import app.game.data.scene.DefenceDungeonSceneData;
import app.game.data.scene.GroupDungeonsWithPrizeConfig;
import app.game.data.scene.JijianCostDatas;
import app.game.data.scene.MonsterData;
import app.game.data.scene.MonsterDatas;
import app.game.data.scene.Npcs;
import app.game.data.scene.SceneDatas;
import app.game.data.scene.WorldBoss;
import app.game.data.spell.Animations;
import app.game.data.spell.FightStates;
import app.game.data.spell.SpellAnimations;
import app.game.data.spell.Spells;
import app.game.data.task.TaskDatas;
import app.game.data.weapon7.SuperWeaponDatas;
import app.game.data.welfare.FirstLoginPrizeDatas;
import app.game.data.welfare.FirstRechargeDatas;
import app.game.module.TerritoryData;
import app.game.module.guild.GuildContributionGoodsShop;
import app.game.module.guild.GuildFlagDatas;
import app.game.module.guild.LongCityData;
import app.game.module.guild.WushuangCityData;
import app.game.module.scene.SceneObjectProcessor;
import app.game.shop.Shops;
import app.protobuf.ConfigContent.Config;
import app.protobuf.ConfigContent.FireMonkeyConfigProto;
import app.protobuf.ConfigContent.GuildConfig;
import app.protobuf.ConfigContent.TerritoryConfigProto;
import app.protobuf.ConfigContent.WelfareConfig;
import app.utils.VariableConfig;

import com.google.inject.Inject;

public class ConfigService{
    private static final Logger logger = LoggerFactory
            .getLogger(ConfigService.class);

    private final SpriteStats spriteStats;

    private final Spells spells;

    private final GoodsDatas goods;

    private final SceneDatas scenes;

    private final GroupDungeonsWithPrizeConfig groupDungeonWithPrizeConfig;

    private final TaskDatas tasks;

    private final GoodsContainerUnlockDatas gcUnlockDatas;

    private final Animations animations;

    private final SpellAnimations spellAnimations;

    private final FightStates fightStates;

    private final Npcs npcs;

    private final HeroLevelDatas heroLevelDatas;

    private final Shops shops;

    private final Races races;

    private final CollectObjects collectObjects;

    private final MonsterDatas monsters;

    private final GuildFlagDatas guildFlagDatas;

    private final GuildContributionGoodsShop guildContributionGoodsShop;

    private final MountDatas mounts;

    private final Vips vips;

    private final WorldBoss worldBosses;

    private final SignDatas signDatas;

    private final LotteryDatas lotteryDatas;

    private final VariableConfig variableConfig;
    private final QualityRelatedDatas qualityDatas;

    private final DivineDatas divineDatas;

    private final SuperWeaponDatas superWeaponDatas;

    private final DefenceDungeonSceneData defenceDungeonSceneData;

    private final BowDatas bows;

    private final GemData gemData;

    private final MicroLoginData loginData;

    private final ExamDatas examDatas;

    private final JijianCostDatas swordSacrificeDatas;

    private final PetDatas petDatas;

    private final PrizeConfigs prizes;

    private final OneOnOneDatas oneOnOneDatas;

    private final EquipmentExtraStats extraStats;

    private final WushuangCityData guildFightData;

    private final ShengWangDatas shengWangDatas;

    private final ActivityPaybacks paybacks;

    private final TerritoryData territoryData;

    private final WushuangCityData wsCityData;

    private final LongCityData longCityData;

    private final TaozDatas taozDatas;

    private final FirstRechargeDatas firstRechargeDatas;

    private final FirstLoginPrizeDatas loginPrizeDatas;

    private final BankDatas bankDatas;

    @Inject
    ConfigService(SpriteStats spriteStats, Spells spells, GoodsDatas goods,
            SceneDatas scenes,
            GroupDungeonsWithPrizeConfig groupDungeonWithPrizeConfig,
            TaskDatas tasks, VariableConfig variableConfig,
            GoodsContainerUnlockDatas gcUnlockDatas, Animations animations,
            SpellAnimations spellAnimations, Npcs npcs,
            HeroLevelDatas heroLevelDatas, Shops shops, Races races,
            CollectObjects collectObjects, MonsterDatas monsters,
            GuildFlagDatas guildFlagDatas,
            GuildContributionGoodsShop guildContributionGoodsShop,
            MountDatas mounts, Vips vips, WorldBoss worldBosses,
            SignDatas signDatas, LotteryDatas lotteryDatas,
            QualityRelatedDatas qualityData, DivineDatas divineDatas,
            SuperWeaponDatas superWeaponDatas, BowDatas bows, GemData gemData,
            MicroLoginData loginData, ExamDatas examDatas,
            JijianCostDatas swordSacrificeDatas, PetDatas petDatas,
            PrizeConfigs prizes, OneOnOneDatas oneOnOneDatas,
            EquipmentExtraStats extraStats, WushuangCityData guildFightData,
            ShengWangDatas shengWangDatas, ActivityPaybacks paybacks,
            TerritoryData territoryData, WushuangCityData wushuangCityData,
            LongCityData longCityData, TaozDatas taozDatas,
            FirstRechargeDatas firstRechargeDatas,
            FirstLoginPrizeDatas loginPrizeDatas, BankDatas bankDatas){
        this.spriteStats = spriteStats;
        this.spells = spells;
        this.goods = goods;
        this.scenes = scenes;
        this.groupDungeonWithPrizeConfig = groupDungeonWithPrizeConfig;
        this.tasks = tasks;
        this.gcUnlockDatas = gcUnlockDatas;
        this.animations = animations;
        this.spellAnimations = spellAnimations;
        this.fightStates = spells.fightStates;
        this.npcs = npcs;
        this.heroLevelDatas = heroLevelDatas;
        this.shops = shops;
        this.races = races;
        this.collectObjects = collectObjects;
        this.monsters = monsters;
        this.guildFlagDatas = guildFlagDatas;
        this.guildContributionGoodsShop = guildContributionGoodsShop;
        this.mounts = mounts;
        this.vips = vips;
        this.worldBosses = worldBosses;
        this.signDatas = signDatas;
        this.lotteryDatas = lotteryDatas;
        this.variableConfig = variableConfig;
        this.qualityDatas = qualityData;
        this.divineDatas = divineDatas;
        this.superWeaponDatas = superWeaponDatas;
        this.bows = bows;
        this.gemData = gemData;
        this.loginData = loginData;
        this.examDatas = examDatas;
        this.swordSacrificeDatas = swordSacrificeDatas;
        this.defenceDungeonSceneData = scenes.getDefence();
        this.petDatas = petDatas;
        this.prizes = prizes;
        this.oneOnOneDatas = oneOnOneDatas;
        this.extraStats = extraStats;
        this.guildFightData = guildFightData;
        this.shengWangDatas = shengWangDatas;
        this.paybacks = paybacks;
        this.territoryData = territoryData;
        this.wsCityData = wushuangCityData;
        this.longCityData = longCityData;
        this.taozDatas = taozDatas;
        this.firstRechargeDatas = firstRechargeDatas;
        this.loginPrizeDatas = loginPrizeDatas;
        this.bankDatas = bankDatas;

        SceneObjectProcessor.sceneObjectStartId = getMaxUseSceneObjectId();
        goods.doCheck();
    }

    public FirstRechargeDatas getFirstRechargeDatas(){
        return firstRechargeDatas;
    }

    public TerritoryData getTerritoryData(){
        return territoryData;
    }

    public WushuangCityData getWsCityData(){
        return wsCityData;
    }

    public GuildFlagDatas getGuildFlagDatas(){
        return guildFlagDatas;
    }

    public LongCityData getLongCityData(){
        return longCityData;
    }

    public ShengWangDatas getShengWangDatas(){
        return shengWangDatas;
    }

    public MonsterDatas getMonsterDatas(){
        return monsters;
    }

    public PrizeConfigs getPrizes(){
        return prizes;
    }

    public PetDatas getPet(){
        return petDatas;
    }

    public GemData getGem(){
        return gemData;
    }

    public BowDatas getBows(){
        return bows;
    }

    public GroupDungeonsWithPrizeConfig getGroupDungeonWithPrizeConfig(){
        return groupDungeonWithPrizeConfig;
    }

    public DefenceDungeonSceneData getDefenceDungeonSceneData(){
        return defenceDungeonSceneData;
    }

    public SuperWeaponDatas getSuperWeapons(){
        return superWeaponDatas;
    }

    public Vips getVips(){
        return vips;
    }

    public int getMaxUseSceneObjectId(){
        return Math.max(scenes.maxUseSceneObjectID, Math.max(npcs.maxUseNpcId,
                collectObjects.maxUseCollectObjectId));
    }

    public Races getRaces(){
        return races;
    }

    public SpriteStats getSpriteStats(){
        return spriteStats;
    }

    public Spells getSpells(){
        return spells;
    }

    public FightStates getFightStates(){
        return fightStates;
    }

    public GoodsDatas getGoods(){
        return goods;
    }

    public SceneDatas getScenes(){
        return scenes;
    }

    public TaskDatas getTasks(){
        return tasks;
    }

    public GoodsContainerUnlockDatas getUnlockDatas(){
        return gcUnlockDatas;
    }

    public Animations getAnimations(){
        return animations;
    }

    public SpellAnimations getSpellAnimations(){
        return spellAnimations;
    }

    public HeroLevelDatas getHeroLevelDatas(){
        return heroLevelDatas;
    }

    public Npcs getNpcs(){
        return npcs;
    }

    public Shops getShops(){
        return shops;
    }

    public WorldBoss getWorldBosses(){
        return worldBosses;
    }

    public MountDatas getMounts(){
        return mounts;
    }

    public QualityRelatedDatas getQualityData(){
        return qualityDatas;
    }

    public VariableConfig getConfig(){
        return variableConfig;
    }

    public EquipmentExtraStats getExtraStats(){
        return extraStats;
    }

    public BankDatas getBanks(){
        return bankDatas;
    }

    public Config.Builder generateProto(){
        Config.Builder builder = Config.newBuilder();
        builder.setSceneConfig(scenes.generateProto());
        builder.setAnimationConfig(animations.generateProto());
        builder.setSpellEffectConfig(spellAnimations.generateProto());
        builder.setFirstLevelActiveSpells(spells.generateFirstLevelProto());
        builder.setStateConfig(spells.fightStates.generateProto());
        builder.setNpcConfig(npcs.generateProto());
        builder.setShopConfig(shops.generateProto());

        // 死亡复活物品
        builder.setFreePerfectReliveLevel(VariableConfig.FREE_PERFECT_RELIVE_LEVEL);
        builder.setRelivePerfectGoodsBytes(goods.getPerfectReliveGoods()
                .getProtoByteString());
        builder.setRelivePerfectGoodsYuanbaoPrice(shops.getSystemShop()
                .getReliveGoodsYuanbaoPrice());

        // 喇叭id
        builder.setPaidChatGoodsId(variableConfig.PAID_CHAT_GOODS_ID);

        // 飞鞋id
        builder.setAssistTransportGoodsId(variableConfig.ASSIST_TRANSPORT_GOODS_ID);

        // 任务
        builder.setTaskConfig(tasks.generateProto(qualityDatas));

        // 采集物体
        builder.setCollecObjectConfig(collectObjects.generateProto());

        // 怪物
        builder.setMonsterConfig(monsters.generateProto());

        // 帮派
        builder.setGuild(encodeGuildConfig());

        // 离线经验
        heroLevelDatas.encode(builder, variableConfig);

        // vip
        vips.encode(builder);

        // -- pk --
        builder.setRedNamePkAmountThreshold(VariableConfig.RED_NAME_PK_AMOUNT_THRESHOLD); // 红名PK值阀值
        builder.setNightAutoCombatPrepareTime(VariableConfig.NIGHT_PROTECTED_PREPARE_TIME); // 夜晚保护准备时间
        builder.setNewHeroProtectLevel(VariableConfig.NEW_HERO_PROTECT_LEVEL); // 新手保护等级
        builder.setHeroLevelDiffProtectLevel(VariableConfig.HERO_LEVEL_DIFF_PROTECT); // 等级差
        builder.setPkAmountReduceInterval(VariableConfig.PK_AMOUNT_REDUCE_INTERVAL); // 每次减少pk值得时间间隔
        builder.setPkAmountReducePerTimes(VariableConfig.REDUCE_PK_AMOUNT_PER_TIMES); // 每次减少多少点PK值

        // world boss
        builder.setWorldBossContig(worldBosses.generateProto());

        // 福利
        builder.setSignConfig(signDatas.generateProto());
        builder.setLotteryConfig(lotteryDatas.generateProto());

        // 坐骑
        builder.setMount(mounts.generateProto(variableConfig));

        // 英雄最高等级
        builder.setHeroMaxLevel(VariableConfig.HERO_MAX_LEVEL);

        // 剧情副本
        builder.setStoryAutoCompleteNowYuanbaoCost(VariableConfig.STORY_COMPLETE_AUTO_FINISH_STORY_NOW_YUANBAO_COST);

        // 装备额外属性
        extraStats.encode(builder);

        // 火猴
        builder.setFireMonkeyConfig(encodeFireMonkeyConfig());

        // 知天命
        builder.setDivineConfig(divineDatas.generateProto(variableConfig));

        // 守护孔慈
        builder.setDefenceConfig(defenceDungeonSceneData
                .generateConfig(variableConfig));

        // 神兵
        builder.setSuperWeapon(superWeaponDatas.generateProto());

        // 排行榜
        builder.setRankAdmireMaxTimes(VariableConfig.RANK_ADMIRE_MAX_TIMES);
        builder.setRankPerPage(VariableConfig.RANK_PER_PAGE);

        // 怒气值
        builder.setRageMaxAmount(variableConfig.RAGE_MAX_AMOUNT);
        builder.setRageAddInterval(VariableConfig.ADD_RAGE_INTERVAL);
        builder.setRageAddPerTimes(VariableConfig.ADD_RAGE_PER_TIMES);

        // 弓箭
        builder.setBow(bows.generateProto(variableConfig));

        // 微端
        builder.setMicroFirstLoginPrize(loginData.getFirstLoginPrize()
                .encode4Client());
        builder.setMicroDailyLoginPrize(loginData.getDailyLoginPrize()
                .encode4Client());

        // 凤血
        builder.setPhoenixRefineCost(variableConfig.PHOENIX_YUANBAO_REFINE_COST);
        builder.setPhoenixRefineMaxTimes(variableConfig.PHOENIX_YUANBAO_REFINE_MAX_TIMES);
        builder.setPhoenixMoneyRefineCost(variableConfig.PHOENIX_MONEY_REFINE_COST);
        builder.setPhoenixMoneyRefineMaxTimes(variableConfig.PHOENIX_MONEY_REFINE_MAX_TIMES);
        builder.setPhoenixLijinRefineCost(variableConfig.PHOENIX_LIJIN_REFINE_COST);
        builder.setPhoenixLijinRefineMaxTimes(variableConfig.PHOENIX_LIJIN_REFINE_MAX_TIMES);
        builder.setPhoenixYuanbaoRefineCost(variableConfig.PHOENIX_YUANBAO_REFINE_COST);
        builder.setPhoenixYuanbaoRefineMaxTimes(variableConfig.PHOENIX_YUANBAO_REFINE_MAX_TIMES);
        builder.setPhoenixGoods(goods.getPhoenixGoods().getProtoByteString());

        builder.setGuildFight(guildFightData.generateProto());
        builder.setShengWang(shengWangDatas.generateProto());
        paybacks.generateProto(builder);
        builder.setLongCity(longCityData.generateProto());

        // 答题
        builder.setExam(examDatas.encode(variableConfig));

        // 祭剑
        builder.setSwordSacrificeMaxTimes(swordSacrificeDatas.getMaxTimes());

        // 宠物
        builder.setPetConfig(petDatas.generateProto(variableConfig));

        // 个人竞技场
        builder.setFightConfig(oneOnOneDatas.generateProto(variableConfig));

        // 板块
        builder.setTerritory(encodeTerritoryConfig());

        // 熔炉
        builder.setMeltMaxAmount(variableConfig.MELT_MAX_AMOUNT);

        // 套装
        taozDatas.encode(builder);

        builder.setWelfare(encodeWelfareConfig());

        return builder;
    }

    private WelfareConfig encodeWelfareConfig(){
        WelfareConfig.Builder builder = WelfareConfig.newBuilder();

        builder.setFirstRechargeCount(firstRechargeDatas.getCount());
        builder.setLoginPrizeCount(loginPrizeDatas.getCount());

        bankDatas.encode(builder);

        return builder.build();
    }

    private TerritoryConfigProto encodeTerritoryConfig(){
        TerritoryConfigProto.Builder builder = TerritoryConfigProto
                .newBuilder();
        builder.setWinGuildLilian(variableConfig.TERRITORY_WIN_GUILD_LILIAN)
                .setWinExp(variableConfig.TERRITORY_WIN_EXP)
                .setLoseGuildLilian(variableConfig.TERRITORY_LOSE_GUILD_LILIAN)
                .setLoseExp(variableConfig.TERRITORY_LOSE_EXP);

        builder.setCarryFlagMoneyCost(variableConfig.TERRITORY_CARRY_FLAG_MONEY_COST);
        builder.setCarryFlagTime(variableConfig.TERRITORY_CARRY_FLAG_TIME);
        builder.setFirst7DaysStartTime(variableConfig.TERRITORY_SINCE_BATTLE_START_SERVICE_TIME);
        builder.setRegularTime(variableConfig.TERRITORY_REGULAR_DAY);
        builder.setDurationMinute((int) (variableConfig.TERRITORY_DURATION / DateTimeConstants.MILLIS_PER_MINUTE));
        builder.setEarlyWinDurationMinute((int) (variableConfig.TERRITORY_EARLY_WIN_DURATION / DateTimeConstants.MILLIS_PER_MINUTE));
        builder.setPrizeDurationMinute((int) (variableConfig.TERRITORY_PRIZE_DURATION / DateTimeConstants.SECONDS_PER_MINUTE));

        builder.setGuildExtraStat(territoryData.guildExtraStat.encode());

        return builder.build();
    }

    private FireMonkeyConfigProto encodeFireMonkeyConfig(){
        FireMonkeyConfigProto.Builder builder = FireMonkeyConfigProto
                .newBuilder();

        MonsterData fireMonkeyData = monsters
                .get(variableConfig.FIRE_MONKEY_MONSTER_NAME);
        checkNotNull(
                fireMonkeyData,
                "怪物总表中找不到火猴: %s. 在config/settings.txt中配置fire_monkey_monster_name",
                variableConfig.FIRE_MONKEY_MONSTER_NAME);

        builder.setFireMonkeyData(fireMonkeyData.encode4Client());
        builder.setFireMonkeyMaxLife(fireMonkeyData.stat.maxLife);
        builder.setFireMonkeyStartTime(variableConfig.FIRE_MONKEY_TIME);
        builder.setFireMonkeyDurationMinute(VariableConfig.FIRE_MONKEY_DURATION_MINUTE);
        builder.setFireMonkeySceneId(variableConfig.FIRE_MONKEY_SCENE_ID);

        return builder.build();
    }

    private GuildConfig encodeGuildConfig(){
        GuildConfig.Builder builder = GuildConfig.newBuilder();

        builder.setGuildCreateLevel(VariableConfig.GUILD_CREATE_LEVEL_LIMIT);
        builder.setGuildCreateMoney(variableConfig.GUILD_CREATE_MONEY_REQUEST);
        builder.setGuildCreateYuanbao(variableConfig.GUILD_CREATE_YUANBAO_REQUEST);

        GoodsData gift = checkNotNull(
                goods.get(variableConfig.GUILD_GIFT_GOODS_ID_1),
                "没有找到帮派捐献物品1: %s", variableConfig.GUILD_GIFT_GOODS_ID_1);
        builder.setGuildGiftGoods1(gift.getProtoByteString());

        gift = checkNotNull(goods.get(variableConfig.GUILD_GIFT_GOODS_ID_2),
                "没有找到帮派捐献物品2: %s", variableConfig.GUILD_GIFT_GOODS_ID_2);
        builder.setGuildGiftGoods2(gift.getProtoByteString());

        gift = checkNotNull(goods.get(variableConfig.GUILD_GIFT_GOODS_ID_3),
                "没有找到帮派捐献物品3: %s", variableConfig.GUILD_GIFT_GOODS_ID_3);
        builder.setGuildGiftGoods3(gift.getProtoByteString());

        gift = checkNotNull(goods.get(variableConfig.GUILD_GIFT_GOODS_ID_4),
                "没有找到帮派捐献物品4: %s", variableConfig.GUILD_GIFT_GOODS_ID_4);
        builder.setGuildGiftGoods4(gift.getProtoByteString());

        builder.setGuildGiftMoneyPerContribution(VariableConfig.GUILD_GIFT_MONEY_PER_CONTRIBUTION);
        builder.setGuildGiftGoodsAddContribution(VariableConfig.GUILD_GIFT_GOODS_ADD_CONTRIBUTION);

        // --- 帮旗改造型消耗 ---
        builder.setGuildChangeFlagKindCostGoods1(variableConfig.GUILD_CHANGE_FLAG_KIND_COST_GOODS_1);
        builder.setGuildChangeFlagKindCostGoods2(variableConfig.GUILD_CHANGE_FLAG_KIND_COST_GOODS_2);
        builder.setGuildChangeFlagKindCostGoods3(variableConfig.GUILD_CHANGE_FLAG_KIND_COST_GOODS_3);
        builder.setGuildChangeFlagKindCostGoods4(variableConfig.GUILD_CHANGE_FLAG_KIND_COST_GOODS_4);
        builder.setGuildChangeFlagKindCostMoney(variableConfig.GUILD_CHANGE_FLAG_KIND_COST_MONEY);

        // --- 帮旗改名消耗 ---
        builder.setGuildChangeFlagNameCostGoods1(variableConfig.GUILD_CHANGE_FLAG_NAME_COST_GOODS_1);
        builder.setGuildChangeFlagNameCostGoods2(variableConfig.GUILD_CHANGE_FLAG_NAME_COST_GOODS_2);
        builder.setGuildChangeFlagNameCostGoods3(variableConfig.GUILD_CHANGE_FLAG_NAME_COST_GOODS_3);
        builder.setGuildChangeFlagNameCostGoods4(variableConfig.GUILD_CHANGE_FLAG_NAME_COST_GOODS_4);
        builder.setGuildChangeFlagNameCostMoney(variableConfig.GUILD_CHANGE_FLAG_NAME_COST_MONEY);

        // --- 帮旗每级属性 ---
        for (int i = 1; i <= guildFlagDatas.getMaxLevel(); i++){
            builder.addFlagLevel(guildFlagDatas.getLevel(i).encode());
        }

        // --- 帮贡物品兑换 ---
        guildContributionGoodsShop.encodeGoods(builder);

        // --- 入帮等级限制 ---
        builder.setGuildInviteJoinLevelLimit(VariableConfig.GUILD_INVITE_JOIN_LEVEL_LIMIT);
        builder.setGuildRequestJoinLevelLimit(VariableConfig.GUILD_REQUEST_JOIN_LEVEL_LIMIT);

        return builder.build();
    }
}
