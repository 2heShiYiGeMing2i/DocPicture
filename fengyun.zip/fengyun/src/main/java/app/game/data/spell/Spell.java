package app.game.data.spell;

import static com.mokylin.sink.util.Preconditions.checkArgument;
import static com.mokylin.sink.util.Preconditions.checkNotNull;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.data.GameObject;
import app.game.data.goods.GoodsData;
import app.game.data.goods.GoodsDataCount;
import app.game.data.goods.GoodsDatas;
import app.game.data.goods.SpellBookData;
import app.game.module.SpellMessages;
import app.protobuf.ConfigContent.ActiveSpell;
import app.utils.VariableConfig;

import com.google.protobuf.ByteString;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.parse.ObjectParser;

public abstract class Spell extends GameObject{

    public static final int HERO_SPELL_CATEGORY = 1;

    public static final int GUILD_SPELL_CATEGORY = 2;

    public static final int LOVES_SPELL_CATEGORY = 3;

    public static final int MOUNT_SPELL_CATEGORY = 4;

    public static final int SUPER_WEAPON_SPELL_CATEGORY = 5;

    public static final int BOW_SPELL_CATEGORY = 6;

    public static final int PET_SPELL_CATEGORY = 7;

    public static final int TIAN_JIE_SPELL_CATEGORY = 8;

    public static final int TIAN_ZUI_SPELL_CATEGORY = 9;

    public static final int XINFA_SPELL_CATEGORY = 10;

    public static final int SYSTEM_SPELL_CATEGORY = 11;

    /**
     * 技能类型, 相同的技能类型属于统一技能的不同等级
     */
    public final int spellType;

    /**
     * 技能cd，主动释放CD，被动触发CD
     */
    public final int cd;

    /**
     * 技能等级 从1开始, 这个spellType配的最大的spellLevel就是这个技能的最大等级
     */
    public final int spellLevel;

    /**
     * 技能在面板中的分类.
     * 
     * 1. 人物技能
     * 2. 帮派技能
     * 3. 情侣技能
     * 4. 坐骑技能
     * 5. 神兵技能
     * 6. 天劫技能
     * 7. 宠物技能
     * 8. 战甲技能
     * 9. 天罪技能
     * 10. 心法技能
     * 11. 系统技能
     */
    public final int spellCategory;

    /**
     * 多少级的玩家能看到这技能
     */
    public final int clientCanSeeLevel;

    /**
     * 多少级的玩家能学这技能
     */
    public final int clientCanLearnLevel;

    /**
     * 是否到了能学技能的等级自动学会
     */
    public final boolean isAutoLearn;

    /**
     * 技能书
     */
    public final SpellBookData book;

    // 客户端使用，技能图片
    public final String spellImage;

    // 客户端使用，技能视频
    public final String spellVideo;

    /**
     * 升级/学习 所需铜钱
     */
    public final int moneyCost;

    /**
     * 升级/学习 所需真气
     */
    public final int realAirCost;

    /**
     * 升级/学习 所需物品 没有就是null
     */
    public final GoodsDataCount goodsCost;

    /**
     * 所需的职业 0表示不限
     */
    public final int race;

    /**
     * 技能描述
     */
    public final ByteString description;

    protected final int fightingAmount;

    protected int totalLevel;

    private ActiveSpell proto;

    private ChannelBuffer learnedThisSpellMessage;

    private ChannelBuffer autoLearnedThisSpellMessage;

    private transient ChannelBuffer firstLevelSpellDataMsg;

    // 对英雄有效
    transient final boolean isAffectHero;

    // 对普通怪有效
    transient final boolean isAffectMonster;

    // 对精英怪有效
    transient final boolean isAffectEliteMonster;

    // 对Boss有效
    transient final boolean isAffectBoss;

    // 对宠物有效
    transient final boolean isAffectPet;

    Spell(ObjectParser p, GoodsDatas goodsDatas){
        super(p);

        checkArgument(id < VariableConfig.SHORTCUT_MAX_ID, "技能id必须< %s: %s-%s",
                VariableConfig.SHORTCUT_MAX_ID, id, name);

        this.spellType = p.getIntKey("spell_type");
        checkArgument(spellType <= GameObject.ID_MAX_AMOUNT,
                "%s 的spellType不能超过100万", this);

        this.cd = p.getIntKey("cd");

        this.spellLevel = p.getIntKey("spell_level");
        this.clientCanSeeLevel = Math.max(1,
                p.getIntKey("client_can_see_level"));
        this.clientCanLearnLevel = Math.max(1,
                p.getIntKey("client_can_learn_level"));
        this.isAutoLearn = p.getBooleanKey("is_auto_learn");

        if (spellLevel != 1){
            checkArgument(clientCanSeeLevel <= 1,
                    "只有1级的技能才能配置 可见等级限制client_can_see_level: %s", this);

            checkArgument(!isAutoLearn, "只能1级的技能才能配置自动学会is_auto_learn: %s",
                    this);
        }

        this.spellCategory = p.getIntKey("spell_category");

        this.moneyCost = p.getIntKey("money_cost");
        this.realAirCost = p.getIntKey("real_air_cost");
        this.race = p.getIntKey("race");

        String descriptionString = p.getKey("description");
        this.description = ByteString
                .copyFrom(com.mokylin.sink.util.StringEncoder
                        .encode(descriptionString));

        // ------- 升级所需物品 ----------
        String goodsCostString = p.getKey("goods_cost").trim();
        if (goodsCostString.length() == 0){
            this.goodsCost = null;
        } else{
            String[] g = goodsCostString.split("=");
            checkArgument(g.length == 2, "技能升级所需物品的配置格式是 物品id=3");

            int goodsID = Integer.parseInt(g[0].trim());
            int goodsCount = Integer.parseInt(g[1].trim());

            GoodsData goods = checkNotNull(goodsDatas.get(goodsID),
                    "没有找到技能 %s 升级所需的物品 %s", this, goodsID);

            checkArgument(goodsCount > 0, "技能%s 升级所需的物品个数至少是1: %s", this,
                    goodsID);

            this.goodsCost = new GoodsDataCount(goods, goodsCount);
        }

        int spellBookId = p.getIntKey("spell_book", 0);
        if (spellBookId > 0){
            book = checkNotNull(goodsDatas.getSpellBook(spellBookId),
                    "没有找到技能 %s 升级所需的技能书 %s", this, spellBookId);
        } else{
            book = null;
        }

        spellImage = p.getKey("spell_image", "");
        spellVideo = p.getKey("spell_video", "");

        // -------- end 升级物品 --------

        if (isAutoLearn){
            checkArgument(moneyCost <= 0, "%s 可以自动学会，但是配置了升级银两消耗", this);
            checkArgument(realAirCost <= 0, "%s 可以自动学会，但是配置了升级真气消耗", this);
            checkArgument(goodsCost == null, "%s 可以自动学会，但是配置了升级物品消耗", this);
        }

        fightingAmount = p.getIntKey("fighting_amount", 0);
        checkArgument(fightingAmount >= 0, "技能%s 配置的战斗力小于0", this);

        if (spellCategory == MOUNT_SPELL_CATEGORY){
            checkArgument(!isAutoLearn, "%s 技能类型是坐骑技能，但是居然可以自动学会？", this);

            checkArgument(race == 0, "%s 技能类型是坐骑技能，但是居然有职业限制", this);
        }

        // 个位数表示英雄，十位数表示普通怪，百位数表示精英怪，千位数表示Boss
        int isAffectTarget = p.getIntKey("affect_target");
        if (isAffectTarget > 0){
            isAffectHero = isAffectTarget % 10 == 0;
            isAffectMonster = (isAffectTarget / 10) % 10 == 0;
            isAffectEliteMonster = (isAffectTarget / 100) % 10 == 0;
            isAffectBoss = (isAffectTarget / 1000) % 10 == 0;
            isAffectPet = (isAffectTarget / 10000) % 10 == 0;
        } else{
            isAffectHero = isAffectMonster = isAffectEliteMonster = isAffectBoss = isAffectPet = true;
        }
    }

    void init(){
        checkArgument(totalLevel > 0, "%s 怎么Spell的totalLevel是%s", this,
                totalLevel);
        proto = generateProto();

        learnedThisSpellMessage = SpellMessages
                .learnedOrUpgradeActiveSpell(proto);

        if (isAutoLearn){
            autoLearnedThisSpellMessage = SpellMessages
                    .autoLearnedActiveSpell(proto);
        }

        if (spellLevel == 1)
            firstLevelSpellDataMsg = SpellMessages
                    .getFirstLevelSpellDataMsg(getProto());
    }

    public SpellBookData getSpellBook(){
        return book;
    }

    public ChannelBuffer getFirstLevelSpellDataMsg(){
        return firstLevelSpellDataMsg;
    }

    public int getTotalLevel(){
        return totalLevel;
    }

    public int getSpellLevel(){
        return spellLevel;
    }

    public ChannelBuffer getAutoLearnedMessage(){
        return autoLearnedThisSpellMessage;
    }

    public ChannelBuffer getLearnedMessage(){
        return learnedThisSpellMessage;
    }

    public ActiveSpell getProto(){
        return proto;
    }

    public boolean canBeLearnedByHero(){
        // 坐骑技能是不发给客户端的
        return race >= 0 && race <= 4 && spellCategory != MOUNT_SPELL_CATEGORY
                && spellCategory != SUPER_WEAPON_SPELL_CATEGORY;
    }

    public ActiveSpell generateAsFirstSpell(){
        // 第一级的时候, 学习所需的东西就是自己
        ActiveSpell.Builder result = generateBuilder();
        writeLearnRequirement(result);
        return result.build();
    }

    public boolean isAffectHero(){
        return isAffectHero;
    }

    public boolean isAffectMonster(){
        return isAffectMonster;
    }

    public boolean isAffectEliteMonster(){
        return isAffectEliteMonster;
    }

    public boolean isAffectBoss(){
        return isAffectBoss;
    }

    public boolean isAffectPet(){
        return isAffectPet;
    }

    protected ActiveSpell generateProto(){
        ActiveSpell.Builder builder = generateBuilder();

        // 升级条件，配置到下一级技能中
        Spell nextLevel = getNextLevel();
        if (nextLevel != null){
            nextLevel.writeLearnRequirement(builder);
        }

        return builder.build();
    }

    private ActiveSpell.Builder generateBuilder(){
        ActiveSpell.Builder builder = ActiveSpell.newBuilder();
        builder.setName(ByteString.copyFrom(nameBytes)).setSpellType(spellType)
                .setSpellLevel(spellLevel).setSpellCategory(spellCategory)
                .setDescription(description).setRace(race)
                .setMaxSpellLevel(totalLevel)
                .setFightingAmount(getFightingAmount()).setCd(cd);

        if (spellImage.length() > 0){
            builder.setSpellImage(spellImage);
        }

        if (spellVideo.length() > 0){
            builder.setSpellVideo(spellVideo);
        }

        setSpecialSpellField(builder);

        return builder;
    }

    protected abstract void setSpecialSpellField(ActiveSpell.Builder builder);

    public abstract Spell getNextLevel();

    private void writeLearnRequirement(ActiveSpell.Builder builder){
        if (clientCanSeeLevel > 1){
            builder.setClientCanSeeLevel(clientCanSeeLevel);
        }

        if (clientCanLearnLevel > 1){
            builder.setClientCanLearnLevel(clientCanLearnLevel);
        }

        // 技能书
        if (book != null){
            builder.setBook(book.getProtoByteString());
        } else{
            if (moneyCost > 0){
                builder.setMoneyCost(moneyCost);
            }

            if (realAirCost > 0){
                builder.setRealAirCost(realAirCost);
            }
            // TODO 物品
        }
    }

    /**
     * 获取技能的战斗力，加属性类型的技能重写这个方法
     * @return
     */
    public int getFightingAmount(){
        return fightingAmount;
    }

    public boolean isMountSpell(){
        return spellCategory == MOUNT_SPELL_CATEGORY;
    }

    public boolean isSuperWeaponSpell(){
        return spellCategory == SUPER_WEAPON_SPELL_CATEGORY;
    }

    // 相同的技能类型+相同的等级 = 相同的技能
    @Override
    public int hashCode(){
        return Utils.short2Int(spellType, spellLevel);
    }

    @Override
    public boolean equals(Object obj){
        if (obj instanceof Spell){
            Spell s = (Spell) obj;
            return s.spellType == spellType && s.spellLevel == spellLevel;
        }
        return false;
    }

}
