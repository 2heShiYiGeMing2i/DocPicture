package app.game.data.scene;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.module.scene.SceneMessages;

import com.google.inject.Inject;
import com.mokylin.collection.LongConcurrentSynchronizedHashMap;

public class SceneRemoveObjectMsgCache{

    private LongConcurrentSynchronizedHashMap<ChannelBuffer> cache;

    @Inject
    SceneRemoveObjectMsgCache(){
        cache = new LongConcurrentSynchronizedHashMap<>();
    }

    ChannelBuffer get(long id){
        ChannelBuffer result = cache.get(id);
        if (result != null){
            return result;
        }

        result = SceneMessages.removeObject(id);
        ChannelBuffer old = cache.putIfAbsent(id, result);
        if (old == null){
            return result;
        }
        return old;
    }

    void destroy(){
        cache = null;
    }
}
