package app.game.data.welfare;

import static com.mokylin.sink.util.Preconditions.checkArgument;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.data.Prize;
import app.game.data.PrizeConfig;
import app.game.data.PrizeConfigs;
import app.game.module.WelfareMessages;
import app.protobuf.HeroServerContent.RaceId;

import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class FirstLoginPrizeData{

    final int id;

    final Prize singlePrize;

    final Prize[] racePrizes;

    private final ChannelBuffer collectPrizeMsg;

    FirstLoginPrizeData(int id, ObjectParser p, PrizeConfigs prizes){

        this.id = id;

        String prizeName = p.getKey("prize");
        PrizeConfig prizeConfig = prizes.get(prizeName);

        checkArgument(!prizeConfig.hasExipreTimeGoods(), "7日登陆奖励中配置了有过期时间的物品");
        checkArgument(!prizeConfig.isVarPrize(), "7日登陆奖励中配置了随机属性的物品");
        checkArgument(!prizeConfig.hasUnbindedGoods(), "7日登陆奖励中配置了非绑定的物品");

        if (prizeConfig.isRaceDiff()){
            singlePrize = null;
            racePrizes = new Prize[RaceId.values().length];

            for (RaceId race : RaceId.values()){
                racePrizes[race.getNumber() - 1] = prizeConfig.random(race);
            }
        } else{
            singlePrize = prizeConfig.random();
            racePrizes = null;
        }

        collectPrizeMsg = WelfareMessages.collectFirstLoginPrizeMsg(id);

    }

    public int getId(){
        return id;
    }

    public Prize getPrize(int race){
        if (singlePrize != null){
            return singlePrize;
        }

        return Utils.getValidObject(racePrizes, race - 1);
    }

    public ChannelBuffer getCollectPrizeMsg(){
        return collectPrizeMsg;
    }
}
