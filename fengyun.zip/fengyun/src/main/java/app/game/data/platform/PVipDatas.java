package app.game.data.platform;

import static com.mokylin.sink.util.Preconditions.checkArgument;

import java.util.Collection;
import java.util.List;

import app.game.data.GameObjects;
import app.game.data.PrizeConfigs;
import app.game.service.IThreadService;

import com.google.inject.Inject;
import com.mokylin.collection.IntHashMap;
import com.mokylin.collection.Pair;
import com.mokylin.sink.util.parse.ObjectParser;
import com.mokylin.sink.util.parse.ObjectParsers;

/**
 * @author Liwei
 *
 */
public class PVipDatas{

    private static final String LOCATION = "config/data/pvip/";

    private final IntHashMap<PVipData> dataMap;

    private final PVipData[] datas;

    @Inject
    PVipDatas(GameObjects go, IThreadService threadService,
            PrizeConfigs prizeConfigs){

        // 从文件夹中读取所有的文件上来
        Collection<Pair<String, String>> configs = go.getFileLoader()
                .loadFilesInFolder(LOCATION);

        dataMap = new IntHashMap<>();
        for (Pair<String, String> pair : configs){

            if (!pair.left.startsWith("vip_"))
                continue;

            // s_operatorID_prizeID.txt
            String[] array = pair.left.split("_");
            checkArgument(array.length == 3,
                    "平台Vip奖励存在无效的表，格式:[single/daily_运营商ID_奖励ID_说明.txt]，%s",
                    pair.left);

            try{
                int fileNum = Integer.parseInt(array[1]);

                List<ObjectParser> list = ObjectParsers.parseList(pair.left,
                        pair.right, threadService.getDbExecutor());
                PVipData data = new PVipData(array[2], fileNum, list,
                        prizeConfigs);

                dataMap.putUnique(data.getId(), data);
            } catch (Exception e){
                checkArgument(false, "平台Vip奖励存在无效的表- %s, \n %s", pair.left,
                        e.getMessage());
            }
        }

        datas = dataMap.values().toArray(new PVipData[0]);
    }

    public PVipData get(int key){
        return dataMap.get(key);
    }

    public PVipData[] all(){
        return datas;
    }
}
