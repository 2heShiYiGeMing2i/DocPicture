package app.game.data.spell;

import static com.mokylin.sink.util.Preconditions.checkArgument;
import app.protobuf.ConfigContent.SingleAnimation;

import com.mokylin.sink.util.parse.ObjectParser;

public class Animation{

    public final int id;

    public final String name;

    /**
     * 在角色层底下的特效swf, 空则表示没有
     */
    private final String underRoleSwf;

    /**
     * 在角色层上层的特效swf, 空则表示没有. 2个特效不可能同时没有, 但可能同时有
     */
    private final String overRoleSwf;

    /**
     * 第一遍的第一帧播放延时
     */
    public final int delay;

    /**
     * 循环次数, 0表示无限循环. 状态一定是循环播放到持续时间结束, 无视
     */
    public final int loopCount;

    /**
     * 特效是否跟着角色移动.
     * 
     * 同样一个旋风斩特效, 如果跟角色, 则人物移动特效也移动, 感觉是人物不停在伤害周围的人
     * 
     * 如果不跟角色, 则是固定坐标
     *
     * 如果是跟角色的, 需要判断特效是不是5方向的, 如果是, 则需要根据角色方向播放对应方向的特效
     */
    public final boolean isOnRole;

    /**
     * 播放这个动画时需要播放的音效名
     */
    public final String soundName;

    /**
     * 是否需要旋转 (只有飞行特效有效)
     */
    public final boolean flyNeedRotation;

    /**
     * 是否需要在范围内随机多个, 做出类似暴风雪的效果. 0表示不需要
     * 
     * 不是真正的随机, 而是使用固定的算法, 比如范围是3的话, 就一定产生5个, 相对的坐标也是一样的.
     * 这样可以拼接多个特效. 比如施法特效是从天上随机掉几个火, 目标效果是在地上出几个坑.
     * 需要个数和位置都是用一样的算法产生
     */
    public final int randomRange;

    public final int specialEffect;

    Animation(int id, ObjectParser p){
        this.id = id;
        this.name = p.getKey("name").trim();

        checkArgument(name.length() > 0, "特效的名字不能为空");
        this.underRoleSwf = p.getKey("under_role_swf");
        this.overRoleSwf = p.getKey("over_role_swf");
        this.delay = p.getIntKey("delay");
        this.loopCount = p.getIntKey("loop_count");
        this.isOnRole = p.getBooleanKey("is_on_role");
        this.soundName = p.getKey("sound_name");
        this.flyNeedRotation = p.getBooleanKey("fly_need_rotation");
        this.randomRange = p.getIntKey("random_range");
        this.specialEffect = p.getIntKey("special_effect");
    }

    SingleAnimation generateProto(){
        SingleAnimation.Builder builder = SingleAnimation.newBuilder()
                .setId(id);
        if (underRoleSwf.length() > 0){
            builder.setUnderRoleSwf(underRoleSwf);
        }

        if (overRoleSwf.length() > 0){
            builder.setOverRoleSwf(overRoleSwf);
        }

        if (delay > 0){
            builder.setDelay(delay);
        }

        if (loopCount > 0){
            builder.setLoopCount(loopCount);
        }

        if (isOnRole){
            builder.setIsOnRole(true);
        }

        if (flyNeedRotation){
            builder.setFlyNeedRotation(true);
        }

        if (randomRange > 0){
            builder.setRandomRange(randomRange);
        }

        if (soundName.length() > 0){
            builder.setSoundName(soundName);
        }

        if (specialEffect > 0){
            builder.setSpecialEffect(specialEffect);
        }

        return builder.build();
    }
}
