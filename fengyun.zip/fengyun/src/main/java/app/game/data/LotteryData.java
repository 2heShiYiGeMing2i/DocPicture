package app.game.data;

import static com.mokylin.sink.util.Preconditions.*;

import org.joda.time.DateTimeConstants;

import app.game.data.goods.Goods;
import app.game.data.goods.GoodsData;
import app.game.data.goods.GoodsRandomer;
import app.game.data.scene.PlunderGroup;
import app.game.data.scene.PlunderGroups;
import app.protobuf.ConfigContent.LotteryProto;

import com.google.protobuf.ByteString;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * 抽奖数据
 * @author Liwei
 *
 */
public class LotteryData{

    final int id;

    /**
     * 累计时间，单位毫秒，大于0小于1天
     */
    final int time;

    final PlunderGroup plunderGroup;

    LotteryData(int id, ObjectParser p, PlunderGroups groups){
        this.id = id;

        int secontTime = p.getIntKey("time");
        long longTime = secontTime * 1000;
        checkArgument(longTime > 0
                && longTime < DateTimeConstants.MILLIS_PER_DAY,
                "%s 配置的时间无效，单位是秒，0 < time < MILLIS_PER_DAY", this, longTime);

        time = secontTime * 1000;

        String groupName = p.getKey("plunder_group");

        plunderGroup = checkNotNull(groups.get(groupName), "%s 配置掉落组没找到， %s",
                this, groupName);

        int i = 0;
        for (GoodsRandomer goodsRandomer : plunderGroup.getGoodsRandomers()){
            i++;
            checkArgument(goodsRandomer.getExpireTime() == 0,
                    "%s 第%s 个物品中配置了有过期时间的物品", this, i);
            checkArgument(goodsRandomer.isBinded(), "%s 第%s 个物品中配置了非绑定的物品",
                    this, i);
        }
    }

    public long getTime(){
        return time;
    }

    public Goods random(long ctime){
        return plunderGroup.random(ctime);
    }

    LotteryProto encode(){
        LotteryProto.Builder builder = LotteryProto.newBuilder();

        builder.setTimes(time);
        for (GoodsRandomer goodsRandomer : plunderGroup.getGoodsRandomers()){
            GoodsData showGoods = goodsRandomer.getData();

            builder.addGoodsName(ByteString.copyFrom(showGoods.nameBytes));
            builder.addQuality(showGoods.getQuality().getNumber());
        }

        return builder.build();
    }

    @Override
    public String toString(){
        return "抽奖数据-" + id;
    }
}
