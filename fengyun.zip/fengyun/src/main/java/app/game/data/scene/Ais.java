package app.game.data.scene;

import static com.mokylin.sink.util.Preconditions.checkArgument;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import app.game.data.GameObjects;

import com.google.inject.Inject;
import com.mokylin.sink.util.parse.ObjectParser;

public class Ais{

    public static final String LOCATION = GameObjects.SCENE_BASE_FOLDER
            + "ai.txt";

    private final Map<String, Ai> map;

    @Inject
    public Ais(GameObjects go){
        List<ObjectParser> data = go.loadFile(LOCATION);

        map = new HashMap<>(data.size());

        for (ObjectParser p : data){
            Ai a = new Ai(p);
            checkArgument(map.put(a.name, a) == null, "ai的name重复: %s", a);
        }
    }

    public Ai get(String name){
        return map.get(name);
    }
}
