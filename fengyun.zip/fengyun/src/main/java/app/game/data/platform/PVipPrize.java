package app.game.data.platform;

import static com.mokylin.sink.util.Preconditions.*;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.data.Prize;
import app.game.data.PrizeConfig;
import app.game.data.PrizeConfigs;
import app.game.module.pvip.PlatformVipMessages;

import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class PVipPrize{

    final int id;

    private final Prize prize;

    private final ChannelBuffer collectPrizeMsg;

    private final PVipData parent;

    PVipPrize(PVipData parent, ObjectParser parser, PrizeConfigs prizeConfigs){
        this.parent = parent;

        this.id = parser.getIntKey("id");
        checkArgument(id >= 0 && id <= 30,
                "%s 平台奖励中配置的id必须id >= 0 && id <= 30", parent);

        String prizeName = parser.getKey("prize");

        PrizeConfig prizeConfig = checkNotNull(prizeConfigs.get(prizeName),
                "%s 的Vip-%s 奖励不存在, %s", parent, id, prizeName);

        prize = prizeConfig.random();

        collectPrizeMsg = PlatformVipMessages.getCollectPrizeMsg(
                parent.getId(), id);
    }

    public int getID(){
        return id;
    }

    public PVipData getParent(){
        return parent;
    }

    public Prize getPrize(){
        return prize;
    }

    public ChannelBuffer getMsg(){
        return collectPrizeMsg;
    }
}
