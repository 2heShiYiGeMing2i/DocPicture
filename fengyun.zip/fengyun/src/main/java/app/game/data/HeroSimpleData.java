package app.game.data;

import app.protobuf.HeroServerContent.HeroMinorProto;
import app.protobuf.HeroServerContent.HeroServerProto;
import app.utils.IDUtils;
import app.utils.Operators;

/**
 * @author Liwei
 *
 */
public class HeroSimpleData{

    public final long heroID;

    public final byte[] heroName;

    public final HeroServerProto serverProto;

    public final HeroMinorProto minorProto;

    public final String uin;

    public HeroSimpleData(long heroID, byte[] heroName,
            HeroServerProto serverProto, HeroMinorProto minorProto,
            String userName){
        super();
        this.heroID = heroID;
        this.heroName = heroName;
        this.serverProto = serverProto;
        this.minorProto = minorProto;
        this.uin = Operators.getUinString(IDUtils.getOperatorID(heroID),
                IDUtils.getUserID(heroID), userName);
    }
}
