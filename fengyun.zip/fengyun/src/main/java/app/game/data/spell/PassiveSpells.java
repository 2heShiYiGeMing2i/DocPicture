package app.game.data.spell;

import static com.mokylin.sink.util.Preconditions.checkArgument;
import static com.mokylin.sink.util.Preconditions.checkNotNull;

import java.util.List;

import app.game.data.GameObjects;
import app.game.data.SpriteStats;
import app.game.data.goods.GoodsDatas;
import app.protobuf.ConfigContent.FirstLevelActiveSpell;

import com.google.common.collect.Lists;
import com.google.inject.Inject;
import com.mokylin.collection.IntHashMap;
import com.mokylin.collection.IntHashMap.Entry;
import com.mokylin.sink.util.parse.ObjectParser;

public class PassiveSpells{

    public static final String LOCATION = GameObjects.SPELL_BASE_FOLDER
            + "passive.txt";

    final IntHashMap<PassiveSpell> map;

    /**
     * 存所有技能第一级, key是spellType
     */
    final IntHashMap<PassiveSpell> firstLevels;

    @Inject
    PassiveSpells(GameObjects go, SingleEffectSpells ses, Auras as,
            GoodsDatas goodsDatas, SpriteStats stats, FightStates fs){
        List<ObjectParser> data = go.loadFile(LOCATION);
        map = new IntHashMap<PassiveSpell>(data.size());
        firstLevels = new IntHashMap<PassiveSpell>();

        IntHashMap<IntHashMap<PassiveSpell>> spellTypeList = new IntHashMap<>();
        for (ObjectParser p : data){
            PassiveSpell ps = new PassiveSpell(p, ses, as, goodsDatas, stats,
                    fs);
            checkArgument(map.putIfAbsent(ps.id, ps) == null, "被动技能id冲突: %s",
                    ps);

            IntHashMap<PassiveSpell> levels = spellTypeList.get(ps.spellType);
            if (levels == null){
                levels = new IntHashMap<>();
                spellTypeList.put(ps.spellType, levels);
            }
            boolean unique = levels.put(ps.spellLevel, ps) == null;

            checkArgument(unique, "spellType 为 %s 的技能有多个 %s 级的技能",
                    ps.spellType, ps.spellLevel);
        }

        // 给每一级设置下一级, 保存所有的第一级
        for (Entry<IntHashMap<PassiveSpell>> entry : spellTypeList.entrySet()){
            IntHashMap<PassiveSpell> eachSpellTypeMap = entry.getValue();
            final int spellType = entry.getKey();
            PassiveSpell previousLevel = eachSpellTypeMap.get(1);
            checkNotNull(previousLevel, "技能spellType %s 没有找到spellLevel为1的行",
                    spellType);
            firstLevels.put(previousLevel.spellType, previousLevel); // 把第一级放入map中
            final int levelCount = eachSpellTypeMap.size();
            for (int level = 2; level <= levelCount; level++){
                PassiveSpell sp = eachSpellTypeMap.get(level);
                checkNotNull(sp, "技能spellType %s 没有找到 spellLevel 为%s 的行",
                        spellType, level);
                previousLevel.setNextLevelAndTotalLevel(levelCount, sp);
                previousLevel = sp;
            }

            previousLevel.setNextLevelAndTotalLevel(levelCount, null); // 最后一级没有设过
        }

        for (PassiveSpell sp : map.values()){
            sp.init();
        }
    }

    public PassiveSpell get(int id){
        return map.get(id);
    }

    public List<PassiveSpell> getAutoLearnedSpellByRace(int raceID){
        List<PassiveSpell> result = Lists.newArrayList();
        for (PassiveSpell sp : firstLevels.values()){
            if (!sp.isAutoLearn){
                continue;
            }

            if (sp.race == 0 || sp.race == raceID){
                result.add(sp);
            }
        }
        return result;
    }

    public FirstLevelActiveSpell generateFirstLevelProto(){
        FirstLevelActiveSpell.Builder builder = FirstLevelActiveSpell
                .newBuilder();
        for (PassiveSpell sp : firstLevels.values()){
            if (sp.canBeLearnedByHero()){ // 只发英雄能学会的技能
                builder.addFirstLevel(sp.generateAsFirstSpell());
            }
        }
        return builder.build();
    }

    public PassiveSpell getFirstLevelBySpellType(int spellType){
        return firstLevels.get(spellType);
    }
}
