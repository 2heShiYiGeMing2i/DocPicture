package app.game.data.scene;

import static com.mokylin.sink.util.Preconditions.*;

import java.util.List;

import org.jboss.netty.buffer.ChannelBuffer;
import org.joda.time.DateTimeConstants;

import app.game.data.GameObjects;
import app.game.data.Prize;
import app.game.data.PrizeConfig;
import app.game.data.PrizeConfigs;
import app.game.data.goods.GoodsDatas;
import app.game.data.goods.GoodsWrapper;
import app.game.module.scene.AbstractDungeonScene;
import app.game.module.scene.ChallengeDungeonMessages;
import app.game.module.scene.ChallengeDungeonScene;
import app.game.module.scene.IDungeonService;
import app.game.service.log.LogService;
import app.protobuf.ConfigContent.ChallengeDungeonProto;
import app.protobuf.LogContent.LogEnum.SceneType;

import com.google.common.collect.Lists;
import com.google.protobuf.ByteString;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * 挑战侠士
 * @author Timmy
 *
 */
public class ChallengeDungeonSceneData extends DungeonSceneData{

    public final int sequence;
    public final int difficulty;

    /**
     * 副本里的怪物, 只有一个, 且不会重生
     */
    private final MonsterData boss; // 通过找副本里放置的怪得到

    /**
     * 副本限制时间, 毫秒. 配置时配的单位是秒, 初始化时转化成了毫秒
     */
    public final long timeLimitMillis;
    private final GoodsWrapper[] prizeGoods;

    // 通关奖励
    public final Prize crossPrize;

    // 击杀侠士奖励
    public final PlunderGroup[] killPrize;

    private final int recommendedFightAmount;

    private final ChannelBuffer challengeSuccessMsg;

    private final ChannelBuffer emptyServerFastCrossMsg;

    private final ChannelBuffer emptyGuildFastCrossMsg;

    private final ChannelBuffer serverFastCrossChangedMsg;

    private final ChannelBuffer guildFastCrossChangedMsg;

    ChallengeDungeonSceneData(GameObjects go, ObjectParser p,
            BlockInfos blocks, MonsterDatas monsters, Scripts scripts,
            Plunders plunders, Ais ais, SceneTransportDatas transports,
            GoodsDatas goodsDatas, PrizeConfigs prizeConfigs,
            PlunderGroups plunderGroups,
            SceneRemoveObjectMsgCache removeMsgCache){
        super(go, p, blocks, monsters, scripts, plunders, ais, transports,
                removeMsgCache);

        this.sequence = p.getIntKey("sequence");
        this.difficulty = p.getIntKey("difficulty");

        // 时间限制
        int timeLimitSecond = p.getIntKey("time_limit_second");
        this.timeLimitMillis = ((long) timeLimitSecond)
                * DateTimeConstants.MILLIS_PER_SECOND;

        // 通关奖励
        String prizeName = p.getKey("cross_prize");
        PrizeConfig prizeConfig = checkNotNull(prizeConfigs.get(prizeName),
                "挑战侠士副本 %s 配置的通关奖励没找到, prize： %s", this, prizeName);
        crossPrize = prizeConfig.random();

        String[] killPrizeArray = p.getStringArray("kill_prize");
        List<PlunderGroup> killPrizeList = Lists
                .newArrayListWithCapacity(killPrizeArray.length);
        for (String name : killPrizeArray){
            if (name.isEmpty())
                continue;

            PlunderGroup group = checkNotNull(plunderGroups.get(name),
                    "挑战侠士副本 %s 配置的击杀侠士掉落组包没找到, name： %s", this, name);
            killPrizeList.add(group);
        }

        checkArgument(killPrizeList.size() > 0, "挑战侠士副本 %s 没有配置击杀侠士掉落组包", this);

        killPrize = killPrizeList.toArray(PlunderGroup.EMPTY_ARRAY);

        // 奖励
        String[] prizeGoodsStr = p.getStringArray("prize_goods");
        this.prizeGoods = GoodsWrapper.parse("挑战侠士奖励", goodsDatas,
                prizeGoodsStr);
        for (GoodsWrapper w : prizeGoods){
            w.cacheProto();
        }

        // 找到配置的boss
        SceneMonsterData[] mons = getSingleLifeMonsterDatas();
        checkArgument(mons.length == 1, "挑战侠士副本中必须放且只放一个怪: %s. 有 %s 个怪", this,
                mons.length);
        this.boss = mons[0].getMonsterData();

        // 需求等级
        checkArgument(requiredLevel <= 1, "挑战侠士不能限制进入等级: %s", this);

        // 推荐进入战力
        recommendedFightAmount = p.getIntKey("recommended_fight_amount");

        // 缓存完成消息
        challengeSuccessMsg = ChallengeDungeonMessages
                .challengeSuccess(sequence);

        emptyServerFastCrossMsg = ChallengeDungeonMessages
                .getServerFastCrossMsg(sequence, null);

        emptyGuildFastCrossMsg = ChallengeDungeonMessages.getGuildFastCrossMsg(
                sequence, null);

        serverFastCrossChangedMsg = ChallengeDungeonMessages
                .getServerFastCrossChanged(sequence);

        guildFastCrossChangedMsg = ChallengeDungeonMessages
                .getGuildFastCrossChanged(sequence);
    }

    public GoodsWrapper[] getPrizeGoods(){
        return prizeGoods;
    }

    public ChannelBuffer getChallengeSuccessMsg(){
        return challengeSuccessMsg;
    }

    public ChannelBuffer getEmptyServerFastCrossMsg(){
        return emptyServerFastCrossMsg;
    }

    public ChannelBuffer getEmptyGuildFastCrossMsg(){
        return emptyGuildFastCrossMsg;
    }

    public ChannelBuffer getServerFastCrossChangedMsg(){
        return serverFastCrossChangedMsg;
    }

    public ChannelBuffer getGuildFastCrossChangedMsg(){
        return guildFastCrossChangedMsg;
    }

    public MonsterData getMonster(){
        return boss;
    }

    @Override
    public int getIntType(){
        return SceneType.CHALLENGE_DUNGEON.getNumber();
    }

    @Override
    public AbstractDungeonScene newDungeon(int sceneID,
            IDungeonService dungeonService, LogService logService, long creator){
        return new ChallengeDungeonScene(this, sceneID, dungeonService,
                logService, creator);
    }

    public ChallengeDungeonProto generateProto(){
        ChallengeDungeonProto.Builder builder = ChallengeDungeonProto
                .newBuilder();
        builder.setSceneId(id).setMap(blockName)
                .setName(ByteString.copyFrom(nameBytes)).setSound(sound);
        if (isHeroLevelProtect){
            builder.setIsHeroLevelProtect(true);
        }
        if (isNewHeroProtect){
            builder.setIsNewHeroProtect(true);
        }
        if (isDeathProtect){
            builder.setIsDeathProtect(true);
        }
        if (isNightAutoProtect){
            builder.setIsNightAutoProtect(true);
        }
        if (isJumpLimit){
            builder.setIsJumpLimit(true);
        }
        if (isMountLimit){
            builder.setIsMountLimit(true);
        }

        if (poet != null){
            String tp = poet.trim();
            if (tp.length() > 0){
                builder.setPoet(ByteString.copyFromUtf8(tp));
            }
        }
        if (fixedPkMode != null){
            builder.setFixedPkMode(fixedPkMode.getIntMode());
        }

        if (reliveOutOfDungeon){
            builder.setIsDeathReturnTown(true);
        }

        builder.setSequence(sequence);
        if (difficulty != 0){
            builder.setDifficulty(difficulty);
        }

        builder.setTimeLimitSecond((int) (timeLimitMillis / DateTimeConstants.MILLIS_PER_SECOND));
        builder.setBossTypeId(boss.id);
        builder.setBossLife(boss.stat.maxLife).setBossAttack(boss.stat.attack)
                .setBossDefence(boss.stat.defence);

        for (GoodsWrapper w : prizeGoods){
            builder.addPrizeGoods(w.encode4Client());
        }

        builder.setCrossPrize(crossPrize.encode4Client());
        for (PlunderGroup group : killPrize){
            builder.addKillPrizes(group.encodeGoodsGroup());
        }

        builder.setRecommendedFightAmount(recommendedFightAmount);

        return builder.build();
    }
}
