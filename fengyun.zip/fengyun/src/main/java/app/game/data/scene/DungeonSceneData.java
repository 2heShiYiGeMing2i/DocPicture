package app.game.data.scene;

import static com.mokylin.sink.util.Preconditions.checkArgument;
import app.game.data.GameObjects;
import app.game.module.scene.AbstractDungeonScene;
import app.game.module.scene.IDungeonService;
import app.game.service.log.LogService;
import app.utils.IDUtils;
import app.utils.VariableConfig;

import com.google.common.annotations.VisibleForTesting;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.concurrent.PaddedAtomicInteger;
import com.mokylin.sink.util.parse.ObjectParser;

public abstract class DungeonSceneData extends SceneData{

    /**
     * 副本序号最大值
     */
    @VisibleForTesting
    static final int SCENE_SEQUENCE_LIMIT = (1 << 21) - 1;

    private final PaddedAtomicInteger dungeonIDCounter;

    public final int requiredLevel;

    protected final int defaultX;
    protected final int defaultY;

    /**
     * 复活是否是传到进入副本前的位置的
     */
    public final boolean reliveOutOfDungeon;

    DungeonSceneData(GameObjects go, ObjectParser p, BlockInfos blocks,
            MonsterDatas monsters, Scripts scripts, Plunders plunders, Ais ais,
            SceneTransportDatas transports,
            SceneRemoveObjectMsgCache removeMsgCache){
        super(go, p, blocks, monsters, scripts, plunders, ais, transports,
                removeMsgCache);

        dungeonIDCounter = new PaddedAtomicInteger();

        this.requiredLevel = Math.max(1, p.getIntKey("required_level"));

        this.reliveOutOfDungeon = p.getBooleanKey("relive_out_of_dungeon");

        // -- 复活点 --
        if (!this.reliveOutOfDungeon){
            // 复活在副本内
            checkArgument(blockInfo.isWalkable(deathReturnX, deathReturnY),
                    "副本 %s 复活在自己场景内, 但坐标不可走: <%s, %s>", this, deathReturnX,
                    deathReturnY);
        }

        // -- 默认进入点 --
        this.defaultX = p.getIntKey("default_x");
        this.defaultY = p.getIntKey("default_y");
        checkArgument(blockInfo.isWalkable(defaultX, defaultY),
                "副本 %s 的默认进入点不可走: <%s, %s>", this, defaultX, defaultY);
    }

    /**
     * 跨服场景会重写这个id, 返回的sequence一定是SCENE_MAX_LINE_COUNT+1
     * @return
     */
    public int newDungeonID(){
        return IDUtils.combineSceneID(id,
                (dungeonIDCounter.getAndIncrement() & SCENE_SEQUENCE_LIMIT)
                        + VariableConfig.DUNGEON_SEQUENCE_START);
    }

    public int getDeathReturnPointInDungeon(){
        assert !reliveOutOfDungeon;
        return Utils.short2Int(deathReturnX, deathReturnY);
    }

    @Override
    protected boolean canHaveMonsterWithTime(){
        return false;
    }

    @Override
    protected boolean canHaveRelivableMonster(){
        return false;
    }

    public int getDefaultX(){
        return defaultX;
    }

    public int getDefaultY(){
        return defaultY;
    }

    @Override
    public int getCanEnterLevel(){
        return requiredLevel;
    }

    @Override
    public boolean isNormalScene(){
        return false;
    }

    public abstract AbstractDungeonScene newDungeon(int sceneID,
            IDungeonService dungeonService, LogService logService, long creator);

}
