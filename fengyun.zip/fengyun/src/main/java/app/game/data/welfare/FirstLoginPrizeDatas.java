package app.game.data.welfare;

import static com.mokylin.sink.util.Preconditions.checkArgument;

import java.util.List;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.data.GameObjects;
import app.game.data.PrizeConfigs;
import app.game.module.WelfareMessages;
import app.protobuf.HeroServerContent.RaceId;

import com.google.inject.Inject;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class FirstLoginPrizeDatas{

    private static final String LOCATION = "config/data/welfare/first_login_prize.txt";

    private final FirstLoginPrizeData[] datas;

    private final ChannelBuffer[] raceDataMsgs;

    @Inject
    FirstLoginPrizeDatas(GameObjects go, PrizeConfigs prizes){
        List<ObjectParser> list = go.loadFile(LOCATION);
        checkArgument(!list.isEmpty(), "7日登陆奖励没有配置");

        datas = new FirstLoginPrizeData[list.size()];

        int index = 0;
        for (ObjectParser p : list){
            FirstLoginPrizeData data = new FirstLoginPrizeData(index++, p,
                    prizes);
            datas[data.id] = data;
        }

        raceDataMsgs = new ChannelBuffer[RaceId.values().length];

        byte[][] bytes = new byte[list.size()][];
        for (RaceId race : RaceId.values()){

            for (FirstLoginPrizeData data : datas){
                bytes[data.id] = data.getPrize(race.getNumber())
                        .encode4Client().toByteArray();
            }

            raceDataMsgs[race.getNumber() - 1] = WelfareMessages
                    .getLoginPrizeDataMsg(bytes);
        }
    }

    public FirstLoginPrizeData get(int index){
        if (index >= 0 && index < datas.length){
            return datas[index];
        }
        return null;
    }

    public int getCount(){
        return datas.length;
    }

    public ChannelBuffer getDataMsg(int race){
        return Utils.getValidObject(raceDataMsgs, race - 1);
    }
}
