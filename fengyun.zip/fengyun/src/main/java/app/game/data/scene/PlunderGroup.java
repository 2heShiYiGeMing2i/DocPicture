package app.game.data.scene;

import static com.mokylin.sink.util.Preconditions.checkArgument;

import java.util.List;

import app.game.data.goods.Goods;
import app.game.data.goods.GoodsAddHelper;
import app.game.data.goods.GoodsDatas;
import app.game.data.goods.GoodsRandomer;
import app.game.data.goods.GoodsWrapper;
import app.protobuf.ConfigContent.GoodsGroup;

import com.google.common.collect.Lists;
import com.mokylin.collection.LeftIntPair;
import com.mokylin.sink.util.RandomNumber;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.WeightedRandomer;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class PlunderGroup{

    private static final int DENOMINATOR = 100_0000;

    public static final PlunderGroup[] EMPTY_ARRAY = new PlunderGroup[0];

    final String name;

    /**
     * 组包掉落物品的概率
     */
    final int rate;

    final GoodsRandomer[] goodsRandomers;

    final WeightedRandomer<LeftIntPair<GoodsRandomer>> weightedRandomer;

    private GoodsWrapper[] showGoodsWrappers;

    PlunderGroup(ObjectParser p, GoodsDatas goodsDatas){
        name = p.getKey("name");
        checkArgument(!name.isEmpty(), "掉落组包没有配置名称");

        String rateStr = p.getKey("rate");

        int idx = rateStr.indexOf("/");
        if (idx >= 0){
            int intRate = Utils.parseInt(this, rateStr.substring(0, idx));
            int denominator = Utils.parseInt(this, rateStr.substring(idx + 1));

            checkArgument(denominator > 0 && denominator <= DENOMINATOR
                    && DENOMINATOR % denominator == 0,
                    "%s 中items分母必须要可以被一百万整除", this);

            rate = intRate * (DENOMINATOR / denominator);
        } else{
            rate = Utils.parseInt(this, rateStr);
        }

        checkArgument(rate > 0 && rate <= DENOMINATOR,
                "掉落-%s 中配置的概率不合法，概率取值范围 (0%, 100%] rate: %s", name, rate);

        String[] goodsItemArray = p.getStringArray("goods_item");
        String[] paramArray = p.getStringArray("goods_item_param");

        checkArgument(goodsItemArray.length > 0, "%s 配置的物品个数必须大于0", this);
        checkArgument(goodsItemArray.length == paramArray.length,
                "%s 配置的goods_item字段个数必须跟goods_item_param字段的个数一致", this);

        List<GoodsRandomer> allGoodsRandomer = Lists.newArrayList();
        List<LeftIntPair<LeftIntPair<GoodsRandomer>>> weightRandomerList = Lists
                .newArrayList();

        for (int i = 0; i < goodsItemArray.length; i++){
            String item = goodsItemArray[i];
            if (item.isEmpty()){
                continue;
            }

            GoodsRandomer goodsRandomer = GoodsRandomer.newRandomer(this, item,
                    goodsDatas);

            int weight = Utils.parseInt(this, paramArray[i]);
            checkArgument(weight >= 0, "%s 第%s 个物品中权重无效，0 <= rate, rate: %s",
                    this, i + 1, weight);

            allGoodsRandomer.add(goodsRandomer);

            if (weight > 0){
                LeftIntPair<LeftIntPair<GoodsRandomer>> pair = new LeftIntPair<LeftIntPair<GoodsRandomer>>(
                        weight, new LeftIntPair<GoodsRandomer>(
                                allGoodsRandomer.size() - 1, goodsRandomer));

                weightRandomerList.add(pair);
            }
        }

        checkArgument(!weightRandomerList.isEmpty(), "%s 中有概率的物品一个没有?", this);

        goodsRandomers = allGoodsRandomer.toArray(GoodsRandomer.EMPTY_ARRAY);

        weightedRandomer = new WeightedRandomer<>(weightRandomerList);
    }

    public GoodsRandomer[] getGoodsRandomers(){
        return goodsRandomers;
    }

    public GoodsWrapper[] initShowGoodsWrapper(){

        GoodsWrapper[] wrappers = new GoodsWrapper[goodsRandomers.length];

        for (int i = 0; i < goodsRandomers.length; i++){
            GoodsRandomer r = goodsRandomers[i];
            GoodsWrapper wp = r.getGoodsWrapper();
            wp.cacheProto();

            wrappers[i] = wp;
        }

        showGoodsWrappers = wrappers;
        return wrappers;
    }

    public GoodsWrapper[] randomGoodsAndShowGoods(int count){
        GoodsWrapper[] wrappers = showGoodsWrappers;

        if (wrappers == null){
            wrappers = initShowGoodsWrapper();
        }

        int pos = RandomNumber.getRate(wrappers.length);

        GoodsWrapper[] result = new GoodsWrapper[count];
        result[0] = randomGoodsWrapper();
        for (int i = 1; i < count; i++){
            result[i] = wrappers[(i + pos) % wrappers.length];
        }

        return result;
    }

    boolean tryDrop(){
        return RandomNumber.getRate(DENOMINATOR) < rate;
    }

    public Goods random(long ctime){
        return weightedRandomer.next().right.create(ctime);
    }

    public GoodsAddHelper randomHelper(long ctime){
        return weightedRandomer.next().right.newHelper(ctime);
    }

    public GoodsWrapper randomGoodsWrapper(){
        return weightedRandomer.next().right.getGoodsWrapper();
    }

    public int randomGoodsIndex(){
        return weightedRandomer.next().left;
    }

    public GoodsAddHelper newHelper(int index, long ctime){
        assert index >= 0 && index < goodsRandomers.length: "PlunderGroup.newHelper(), invalid index";

        return goodsRandomers[index].newHelper(ctime);
    }

    public GoodsGroup encodeGoodsGroup(){
        GoodsGroup.Builder builder = GoodsGroup.newBuilder();

        GoodsWrapper[] wrappers = showGoodsWrappers;

        if (wrappers == null){
            for (int i = 0; i < goodsRandomers.length; i++){
                GoodsRandomer r = goodsRandomers[i];
                GoodsWrapper wrapper = r.getGoodsWrapper();
                builder.addGoods(wrapper.encode4Client());
            }
        } else{
            for (GoodsWrapper wrapper : wrappers){
                builder.addGoods(wrapper.encode4Client());
            }
        }

        return builder.build();
    }

    @Override
    public String toString(){
        return "掉落组包-" + name;
    }
}
