package app.game.data.bank;

import static com.mokylin.sink.util.Preconditions.checkArgument;

import java.util.List;

import org.joda.time.DateTimeConstants;

import app.game.data.GameObjects;
import app.protobuf.ConfigContent.WelfareConfig;
import app.utils.VariableConfig;

import com.google.inject.Inject;
import com.mokylin.collection.IntValueIntHashMap;
import com.mokylin.collection.IntValueIntHashMap.Entry;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class BankDatas{

    private static final String UPGRADE_LOCATION = "config/data/bank/upgrade_bank.txt";

    // 升级钱庄
    private final IntValueIntHashMap upgradeBankRebateMap;

    private final int upgradeBankMaxQuota;

    // 月卡钱庄
    private final int monthlyBankQuota;

    private final int monthlyBankFirstDayRebate;

    private final int monthlyBankDailyRebate;

    private final long monthlyBankDuration;

    private final long monthlyBankCollectDuration;

    private final int monthlyBankOnlineBaseLijin;

    private final int dailyMaxOnlineHour;

    private final int[] monthlyBankOnlineRates;

    private final int exchangeRate;

    @Inject
    BankDatas(GameObjects go, VariableConfig config){

        upgradeBankMaxQuota = config.UPGRADE_BANK_QUOTA;
        checkArgument(upgradeBankMaxQuota > 0 & upgradeBankMaxQuota % 100 == 0,
                "升级钱庄最大投资额度必须大于0，并且必须是100的倍数 %s", upgradeBankMaxQuota);

        exchangeRate = config.BANK_EXCHANGE_RATE;
        checkArgument(exchangeRate > 0, "钱庄元宝兑换礼金比例并且必须>0 %s", exchangeRate);

        List<ObjectParser> list = go.loadFile(UPGRADE_LOCATION);
        upgradeBankRebateMap = new IntValueIntHashMap();
        for (ObjectParser p : list){
            int level = p.getIntKey("level");
            int rebate = p.getIntKey("rebate");

            checkArgument(level >= 0, "升级钱庄配置的领取等级居然<0");
            checkArgument(rebate > 0, "升级钱庄配置的%s 级返利比例居然<=0", level, rebate);

            upgradeBankRebateMap.putIfAbsent(level, rebate);
        }

        checkArgument(upgradeBankRebateMap.get(0) > 0,
                "升级钱庄充值当日返还比例没有配置(level = 0)");

        // 月卡钱庄
        monthlyBankQuota = config.MONTHLY_BANK_QUOTA;
        checkArgument(monthlyBankQuota > 0 && monthlyBankQuota % 100 == 0,
                "月卡钱庄投资额度必须大于0，并且必须是100的倍数 %s", monthlyBankQuota);

        monthlyBankFirstDayRebate = config.MONTHLY_BANK_FIRST_DAY_REBATE;
        checkArgument(monthlyBankFirstDayRebate > 0, "月卡钱庄首日返利比例必须大于0 %s",
                monthlyBankFirstDayRebate);

        monthlyBankDailyRebate = config.MONTHLY_BANK_DAILY_REBATE;
        checkArgument(monthlyBankDailyRebate > 0, "月卡钱庄每日返利比例必须大于0 %s",
                monthlyBankDailyRebate);

        monthlyBankDuration = 1L * config.MONTHLY_BANK_DAY
                * DateTimeConstants.MILLIS_PER_DAY;
        monthlyBankCollectDuration = 1L * config.MONTHLY_BANK_COLLECT_DAY
                * DateTimeConstants.MILLIS_PER_DAY;
        monthlyBankOnlineBaseLijin = config.MONTHLY_BANK_ONLINE_BASE_LIJIN;

        checkArgument(monthlyBankDuration > 0, "月卡钱庄天数必须大于0 %s");
        checkArgument(monthlyBankCollectDuration > 0, "月卡钱庄在线累计礼金领取天数必须大于0 %s");
        checkArgument(monthlyBankOnlineBaseLijin > 0, "月卡钱庄在线累计礼金基数必须大于0 %s");

        checkArgument(!config.MONTHLY_BANK_ONLINE_RATES.isEmpty(),
                "月卡钱庄每小时在线数据没有配置");

        String[] rates = config.MONTHLY_BANK_ONLINE_RATES.split(";");
        dailyMaxOnlineHour = rates.length;
        monthlyBankOnlineRates = new int[rates.length + 1];
        monthlyBankOnlineRates[0] = 1000;

        try{
            int prev = 0;
            for (int i = 0; i < rates.length; i++){
                int rate = Integer.parseInt(rates[i]);
                checkArgument(rate > 0 && prev <= rate,
                        "月卡钱庄每小时在线累计礼金系数必须大于0，并且必须大于等于前一个数据, prev:%s rate:%s",
                        prev, rate);

                monthlyBankOnlineRates[i + 1] = 1000 + rate;
            }
        } catch (Throwable e){
            checkArgument(false, "月卡钱庄每小时在线数据配置错误，%s",
                    config.MONTHLY_BANK_ONLINE_RATES);
        }

    }

    public int getUpgradeBankRebate(int level){
        return upgradeBankRebateMap.get(level);
    }

    public int getUpgradeBankMaxQuota(){
        return upgradeBankMaxQuota;
    }

    public int getExchangeRate(){
        return exchangeRate;
    }

    public int getMonthlyBankQuota(){
        return monthlyBankQuota;
    }

    public int getMonthlyBankFirstDayRebate(){
        return monthlyBankFirstDayRebate;
    }

    public int getMonthlyBankDailyRebate(){
        return monthlyBankDailyRebate;
    }

    public long getMonthlyBankDuration(){
        return monthlyBankDuration;
    }

    public long getMonthlyBankCollectDuration(){
        return monthlyBankCollectDuration;
    }

    public int getMonthlyBankDailyMaxOnlineHour(){
        return dailyMaxOnlineHour;
    }

    public int getMonthlyBankOnlineBaseLijin(){
        return monthlyBankOnlineBaseLijin;
    }

    public int getMonthlyBankOnlineRebate(int onlineHour){
        return Utils.getValidInteger(monthlyBankOnlineRates, onlineHour);
    }

    public void encode(WelfareConfig.Builder builder){
        builder.setUpgradeBankMaxQuota(upgradeBankMaxQuota);
        builder.setUpgradeBankExchangeRate(exchangeRate);

        for (Entry entry : upgradeBankRebateMap.entrySet()){
            builder.addUpgradeBankRebateLevel(entry.getKey());
            builder.addUpgradeBankRebateRate(entry.getValue());
        }

        builder.setMonthlyBankQuota(monthlyBankQuota);
        builder.setMonthlyBankFirstDayRebate(monthlyBankFirstDayRebate);
        builder.setMonthlyBankDailyRebate(monthlyBankDailyRebate);
        builder.setMonthlyBankDay((int) (monthlyBankDuration / DateTimeConstants.MILLIS_PER_DAY));
        builder.setMonthlyBankCollectDay((int) (monthlyBankCollectDuration / DateTimeConstants.MILLIS_PER_DAY));
        builder.setMonthlyBankOnlineMaxRebate(getMonthlyBankOnlineRebate(monthlyBankOnlineRates.length - 1));
        builder.setMonthlyBankBaseLijin(monthlyBankOnlineBaseLijin);
    }
}
