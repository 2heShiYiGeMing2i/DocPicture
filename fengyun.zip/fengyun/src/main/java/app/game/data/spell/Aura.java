package app.game.data.spell;

import app.game.data.GameObject;

import com.mokylin.sink.util.parse.ObjectParser;

public class Aura extends GameObject{

    Aura(ObjectParser p, FightStates states){
        super(p);
    }
}
