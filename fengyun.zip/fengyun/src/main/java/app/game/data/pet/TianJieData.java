package app.game.data.pet;

import static com.mokylin.sink.util.Preconditions.*;

import java.util.List;

import org.jboss.netty.buffer.ChannelBuffer;
import org.joda.time.DateTimeConstants;

import app.game.data.SpriteStat;
import app.game.data.SpriteStats;
import app.game.data.UpgradeData;
import app.game.data.goods.GoodsData;
import app.game.data.goods.GoodsDatas;
import app.game.data.goods.PanelGoodsData;
import app.game.data.scene.MonsterData;
import app.game.data.scene.MonsterDatas;
import app.game.module.PetMessages;
import app.game.module.scene.FightData;
import app.game.shop.VendingMachine;
import app.protobuf.ConfigContent.PetMonsterDataProto;
import app.protobuf.ConfigContent.TianJieDataProto;
import app.protobuf.GoodsContent.PanelGoodsDataProto.PanelType;
import app.utils.VariableConfig;

import com.google.common.collect.Lists;
import com.google.protobuf.ByteString;
import com.mokylin.collection.IntPair;
import com.mokylin.sink.util.IntWeightedRandomer;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class TianJieData{

    /**
     * 阶级，1阶为1,2阶为2
     */
    final int id;

    /**
     * 名字
     */
    final String name;

    /**
     * 基础属性
     */
    final SpriteStat baseStat;

    /**
     * 基础战斗力
     */
    final transient int fightingAmount;

    // 进阶

    final UpgradeData upgradeData;

    /**
     * 进阶成功后是否广播全服
     */
    final boolean isUpgradeBroadcast;

    // ---------- 技能 ----------

    /**
     * 技能槽开放个数
     */
    final int spellSlotCount;

    final transient IntWeightedRandomer spellSlotRandomer;

    /**
     * 开放这一阶的间隔，单位分钟
     */
    private final long openInterval;

    /**
     * 开放这一阶的时间（毫秒数），数据可以由后台修改
     */
    volatile long openTime;

    // ----------

    private final transient ChannelBuffer upgradeSuccessMsg;

    private final MonsterData monster;

    TianJieData nextLevel;

    TianJieData(ObjectParser p, SpriteStats spriteStats,
            MonsterDatas monsterDatas, GoodsDatas goodsDatas,
            VendingMachine systemShop){
        this.id = p.getIntKey("id");

        name = p.getKey("name");
        checkArgument(!name.isEmpty(), "%s 天劫的名字没有配置", id);

        int statId = p.getIntKey("base_stat");
        baseStat = checkNotNull(spriteStats.get(statId), "没有找到%s 天劫的基础属性-%s",
                name, statId);
        fightingAmount = FightData.calculateFightingAmount(baseStat);

        upgradeSuccessMsg = PetMessages.upgradeTianJieMsg(id);

        // 天劫进阶

        isUpgradeBroadcast = p.getBooleanKey("is_upgrade_broadcast");

        upgradeData = new UpgradeData(this, p, goodsDatas, systemShop);
        checkArgument(upgradeData.getUpgradeMoneyCost() > 0,
                "%s 中消耗物品没有配置银两消耗", this);

        upgradeData.setCustomAuctionType(GoodsData.TIAN_JIE_AUCTION_TYPE);

        GoodsData upgradeGoods = upgradeData.getUpgradeGoods();

        checkArgument(
                (upgradeGoods instanceof PanelGoodsData)
                        && ((PanelGoodsData) upgradeGoods).getPanel() == PanelType.TIAN_JIE,
                "天劫进阶物品必须配置成面板类物品，并且双击打开的面板必须是天劫面板，天劫进阶物品：%s", upgradeGoods);

        checkArgument(upgradeData.getBaseBlessAmount() > 0, "天劫-%s 的祝福值没有配置",
                this);

        checkArgument(upgradeData.getUpgradeMaxBless() > 0, "天劫-%s 的最大祝福值没有配置",
                this);

        checkArgument(upgradeData.getBlessHoldTime() >= 0,
                "天劫-%s 的祝福值保留时间没有配置", this);

        // 天劫技能

        spellSlotCount = p.getIntKey("spell_slot_count");
        checkArgument(
                spellSlotCount >= 0
                        && spellSlotCount <= VariableConfig.TIAN_JIE_SPELL_SLOT_MAX_COUNT,
                "%s 天劫技能开放个数配置错误, count: %s, 0 <= count <= %s", name,
                spellSlotCount, VariableConfig.TIAN_JIE_SPELL_SLOT_MAX_COUNT);

        IntWeightedRandomer randomer = null;
        if (spellSlotCount > 0){
            String spellSlotRates = p.getKey("spell_slot_rates");
            String[] spellSlotRateArray = spellSlotRates.split(";");

            checkArgument(spellSlotCount == spellSlotRateArray.length,
                    "%s 天劫技能随机位置的权重配置的个数与天劫技能格子开放个数不同");

            List<IntPair> pairs = Lists
                    .newArrayListWithCapacity(spellSlotCount);
            for (int i = 0; i < spellSlotCount; i++){
                int weight = Integer.parseInt(spellSlotRateArray[i]);

                pairs.add(new IntPair(weight, i));
            }

            randomer = new IntWeightedRandomer(pairs);
        }

        spellSlotRandomer = randomer;

        // 天劫开放时间
        openInterval = p.getIntKey("open_mount_interval");
        checkArgument(openInterval >= 0, "%s 开放时间必须大于等于0", this);

        openTime = ((long) openInterval) * DateTimeConstants.MILLIS_PER_MINUTE;

        int monId = p.getIntKey("monster");
        monster = checkNotNull(monsterDatas.get(monId), "%s 天劫 对应的怪物没找到, %s",
                this, monId);
    }

    /**
     * id就是等级
     * @return
     */
    public int getId(){
        return id;
    }

    public boolean isUpgradeBroadcast(){
        return isUpgradeBroadcast;
    }

    public long getOpenTime(long startServiceTime){
        if (openTime > 0){
            return startServiceTime + openTime;
        }
        return 0;
    }

    public int getSpellSlotCount(){
        return spellSlotCount;
    }

    public int randomSpellSlot(){
        assert spellSlotCount > 0;

        return spellSlotRandomer.next();
    }

    public ChannelBuffer getUpgradeSuccessMsg(){
        return upgradeSuccessMsg;
    }

    public TianJieData getNextLevel(){
        return nextLevel;
    }

    boolean isMaxLevel(){
        return nextLevel == null;
    }

    public UpgradeData getUpgradeData(){
        return upgradeData;
    }

    public MonsterData getMonster(){
        return monster;
    }

    public int getMonsterId(){
        return monster.id;
    }

    public SpriteStat getBaseStat(){
        return baseStat;
    }

    public HeroTianJie newTianJie(){
        return new HeroTianJie(this);
    }

    TianJieDataProto encode(){
        TianJieDataProto.Builder builder = TianJieDataProto.newBuilder();

        builder.setId(id).setName(ByteString.copyFromUtf8(name))
                .setBaseStat(baseStat.encode())
                .setSpellSlotCount(spellSlotCount)
                .setFightingAmount(fightingAmount)
                .setUpgradeData(upgradeData.getProto())
                .setMonster(encodePetMonster(monster));

        return builder.build();
    }

    static PetMonsterDataProto encodePetMonster(MonsterData m){
        return PetMonsterDataProto.newBuilder().setId(m.id)
                .setName(ByteString.copyFrom(m.clientDisplayName))
                .setType(m.type).setRes(m.res).setHead(m.head)
                .setStaticHurt(m.staticHurt).build();
    }

    @Override
    public String toString(){
        return id + "-" + name;
    }
}