package app.game.data;

import static com.mokylin.sink.util.Preconditions.checkArgument;

import java.util.List;

import app.game.data.scene.PlunderGroups;
import app.protobuf.ConfigContent.LotteryConfig;

import com.google.inject.Inject;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * 抽奖
 * @author Liwei
 *
 */
public class LotteryDatas{

    private static final String LOCATION = "config/data/welfare/lottery.txt";

    private final LotteryData[] datas;

    private final int lotteryCount;

    @Inject
    LotteryDatas(GameObjects go, PlunderGroups plunderGroups){
        List<ObjectParser> data = go.loadFile(LOCATION);
        checkArgument(!data.isEmpty(), "摇奖奖励没有配置");

        datas = new LotteryData[data.size()];

        int index = 0;
        LotteryData previous = null;
        for (ObjectParser p : data){
            LotteryData lotteryData = new LotteryData(index++, p, plunderGroups);
            datas[lotteryData.id] = lotteryData;

            if (previous != null){
                checkArgument(previous.time <= lotteryData.time,
                        "摇奖数据中，前一次的奖励领取累计时间必须 <= 后一次的累计时间，前: %s 后: %s",
                        previous.time, lotteryData.time);
            }
            previous = lotteryData;
        }

        lotteryCount = datas.length;
    }

    public int getLotteryCount(){
        return lotteryCount;
    }

    public LotteryData get(int index){
        assert index >= 0 && index < lotteryCount;

        return datas[index];
    }

    public LotteryConfig generateProto(){
        LotteryConfig.Builder builder = LotteryConfig.newBuilder();

        for (LotteryData d : datas){
            builder.addLottlery(d.encode());
        }

        return builder.build();
    }
}
