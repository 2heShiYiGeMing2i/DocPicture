/**
 * 
 */
package app.game.data.goods;

import static app.game.module.GoodsContainerMessages.usePackageGoodsEmptyPosNotEnoughMsg;
import static app.protobuf.LogContent.LogEnum.OperateType.GOODS_USE;
import static com.mokylin.sink.util.Preconditions.checkArgument;
import static com.mokylin.sink.util.Preconditions.checkNotNull;
import app.game.data.GameObjects;
import app.game.data.scene.Plunder;
import app.game.data.scene.Plunders;
import app.game.entity.Depot;
import app.game.entity.Hero;
import app.game.module.scene.HeroFightModule;
import app.protobuf.GoodsContent.GoodsDataProto;
import app.protobuf.GoodsServerContent.GoodsType;

import com.google.protobuf.ByteString;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * 包裹
 * 
 * @author Liwei
 * 
 */
public class PackageData extends GoodsData{

    static final String LOCATION = GameObjects.GOODS_BASE_LOCATION
            + "package.txt";

    private final String plunderName;

    private final GoodsDataProto proto;

    private final byte[] protoBytes;

    private final ByteString protoByteString;

    private final Efficacy efficacy;

    private Plunder plunder;

    PackageData(ObjectParser p){
        super(p, GoodsType.PACKAGE);

        plunderName = p.getKey("plunder");
        checkArgument(!plunderName.isEmpty(), "%s 没有配置关联的掉落", this);

        efficacy = new PackageEfficacy();

        proto = encode().build();
        protoBytes = processProtoBytes(proto.toByteArray());
        protoByteString = ByteString.copyFrom(protoBytes);
    }

    public void initPlunder(Plunders plunders){
        this.plunder = checkNotNull(plunders.get(plunderName),
                "%s 配置的掉落不存在， %s", this, plunderName);
    }

    @Override
    public byte[] getProtoBytes(){
        return protoBytes;
    }

    @Override
    public ByteString getProtoByteString(){
        return protoByteString;
    }

    @Override
    public int getAuctionType(){
        return 123;
    }

    @Override
    public Efficacy getEfficacy(){
        return efficacy;
    }

    private class PackageEfficacy implements Efficacy{

        @Override
        public int useTo(HeroFightModule heroFightModule, int useCount,
                long ctime, String iEventId){

            Hero hero = heroFightModule.getHero();
            int emptyPosCount = plunder.getEmptyPosCount(hero.getRaceId(),
                    hero.getLevel(), hero.getVipLevel());

            Depot depot = hero.getDepot();
            if (!depot.hasEnoughEmptyCount(emptyPosCount)){
                heroFightModule
                        .sendMessage(usePackageGoodsEmptyPosNotEnoughMsg(emptyPosCount));
                return 0;
            }

            plunder.give(heroFightModule, ctime, GOODS_USE, iEventId);

            return 1;
        }
    }
}
