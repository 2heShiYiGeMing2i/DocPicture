package app.game.data;

import static com.mokylin.sink.util.Preconditions.*;

import java.util.EnumMap;
import java.util.List;

import app.game.data.task.ChanceTaskDatas;
import app.protobuf.GoodsServerContent.Quality;

import com.google.inject.Inject;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class QualityRelatedDatas{

    public static final String LOCATION = "config/data/quality_related_data.txt";

    final EnumMap<Quality, QualityRelatedData> relatedMap;

    public final Quality[] qualityLevelArray;

    public final Quality[] reversalQualityLevelArray;

    @Inject
    QualityRelatedDatas(GameObjects go, SpriteStats spriteStats){

        checkArgument(Quality.WHITE.getNumber() == 0, "白色品质的intValue不是0");
        checkArgument(Quality.GREEN.getNumber() == 1, "绿色品质的intValue不是1");
        checkArgument(Quality.BLUE.getNumber() == 2, "蓝色品质的intValue不是2");
        checkArgument(Quality.PURPLE.getNumber() == 3, "紫色品质的intValue不是3");
        checkArgument(Quality.ORANGE.getNumber() == 4, "橙色品质的intValue不是4");

        checkArgument(Quality.values().length == ChanceTaskDatas.QUALITY_COUNT,
                "机缘任务参数无效，跟配置无关，厕化看到这段东西找程序猿解决");

        List<ObjectParser> data = go.loadFile(LOCATION);
        checkArgument(!data.isEmpty(), "品质数据没有配置：quality_related_data.txt");

        relatedMap = new EnumMap<>(Quality.class);
        for (ObjectParser p : data){
            QualityRelatedData d = new QualityRelatedData(p, spriteStats);

            checkArgument(relatedMap.put(d.quality, d) == null, "品质数据中，%s品质重复",
                    d.quality);
        }

        qualityLevelArray = new Quality[]{Quality.WHITE, Quality.GREEN,
                Quality.BLUE, Quality.PURPLE, Quality.ORANGE};

        checkArgument(relatedMap.size() == qualityLevelArray.length,
                "装备品质数据长度不一样");

        QualityRelatedData prev = null;
        for (Quality quality : qualityLevelArray){
            QualityRelatedData relatedData = checkNotNull(relatedMap
                    .get(quality));

            if (prev != null){
                checkArgument(
                        prev.quality.getNumber() < relatedData.quality
                                .getNumber(),
                        "高级品质的Number必须比低级品质的要大");
                checkArgument(
                        prev.addedStatCoefficient < relatedData.addedStatCoefficient,
                        "高级品质的装备附加属性系数必须要比低级品质的要大");

                checkArgument(
                        prev.addedStatCount <= relatedData.addedStatCount,
                        "高级品质的装备附加属性条数必须要比低级品质的要大");
            }

            prev = relatedData;
        }

        reversalQualityLevelArray = new Quality[qualityLevelArray.length];
        int len = reversalQualityLevelArray.length;
        for (Quality quality : qualityLevelArray){
            reversalQualityLevelArray[--len] = quality;
        }

        len = reversalQualityLevelArray.length;
        for (int i = 0; i < len; i++){
            checkArgument(qualityLevelArray[i] == reversalQualityLevelArray[len
                    - 1 - i]);
        }
    }

    public QualityRelatedData get(Quality quality){
        return relatedMap.get(quality);
    }
}
