package app.game.data.spell;

import static com.mokylin.sink.util.Preconditions.checkArgument;
import static com.mokylin.sink.util.Preconditions.checkNotNull;

import java.util.List;

import app.game.data.GameObjects;
import app.game.data.SpriteStats;
import app.protobuf.ConfigContent.StateConfig;
import app.utils.VariableConfig;

import com.google.inject.Inject;
import com.mokylin.collection.IntHashMap;
import com.mokylin.sink.util.parse.ObjectParser;

public class FightStates{

    public static final String LOCATION = GameObjects.SPELL_BASE_FOLDER
            + "state.txt";

    private final IntHashMap<FightState> globalMap;

    private final FightState maliceKillerDebuff;

    @Inject
    FightStates(GameObjects go, SpriteStats stats, Animations animations,
            VariableConfig variableConfig){
        List<ObjectParser> data = go.loadFile(LOCATION);
        globalMap = new IntHashMap<FightState>(data.size());

        for (ObjectParser p : data){
            FightState fs = new FightState(p, stats, animations);
            globalMap.putUnique(fs.id, fs);
        }

        maliceKillerDebuff = checkNotNull(
                globalMap.get(variableConfig.MALICE_KILLER_DEBUFF_ID),
                "没有找到恶意击杀其他英雄的Debuff，id: %s",
                variableConfig.MALICE_KILLER_DEBUFF_ID);

        checkArgument(!maliceKillerDebuff.isBuff, "恶意击杀其他英雄的状态居然不是Debuff， %s",
                maliceKillerDebuff);
    }

    public FightState get(int id){
        return globalMap.get(id);
    }

    public FightState getMaliceKillerDebuff(){
        return maliceKillerDebuff;
    }

    public StateConfig generateProto(){
        StateConfig.Builder builder = StateConfig.newBuilder();
        for (FightState fs : globalMap.values()){
            if (fs.needSendToClient()){
                builder.addStates(fs.generateProto());
            }
        }
        return builder.build();
    }

}
