package app.game.data.scene;

import java.util.Collection;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.data.GameObjects;
import app.game.data.goods.GoodsDatas;
import app.utils.VariableConfig;

import com.google.inject.Inject;
import com.mokylin.collection.IntHashMap;
import com.mokylin.sink.util.parse.ObjectParser;

public class SouShenDungeonSceneDatas{

    private static final Logger logger = LoggerFactory
            .getLogger(SouShenDungeonSceneDatas.class);

    public static final String LOCATION = GameObjects.SOU_SHEN_SCENE_BASE_FOLDER
            + "soushen.txt";

    private final IntHashMap<SouShenDungeonSceneData> souShenDungeonMap;

    @Inject
    SouShenDungeonSceneDatas(GameObjects go, BlockInfos blocks,
            MonsterDatas monsters, Scripts scripts, Plunders plunders, Ais ais,
            SceneTransportDatas transports, GoodsDatas goodsDatas,
            VariableConfig variableConfig,
            SceneRemoveObjectMsgCache removeMsgCache){

        logger.debug("loading sou shen dungeon scenes");

        // 加载搜神宫
        List<ObjectParser> data = go.loadFile(LOCATION);

        souShenDungeonMap = new IntHashMap<>(data.size());

        for (ObjectParser p : data){
            SouShenDungeonSceneData scene = new SouShenDungeonSceneData(go, p,
                    blocks, monsters, scripts, plunders, ais, transports,
                    goodsDatas, removeMsgCache);

            souShenDungeonMap.put(scene.id, scene);
        }
    }

    public SouShenDungeonSceneData get(int id){
        return souShenDungeonMap.get(id);
    }

    void putAll(IntHashMap<SceneData> map){
        for (SouShenDungeonSceneData sceneData : souShenDungeonMap.values()){
            map.putUnique(sceneData.id, sceneData);
        }
    }

    Collection<SouShenDungeonSceneData> getAll(){
        return souShenDungeonMap.values();
    }
}
