package app.game.data.bow;

import static com.mokylin.sink.util.Preconditions.checkArgument;

import java.util.List;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.data.GameObjects;
import app.game.data.SpriteStats;
import app.game.data.goods.GoodsDatas;
import app.game.data.spell.PassiveSpell;
import app.game.data.spell.Spells;
import app.game.module.BowMessages;
import app.game.shop.Shops;
import app.protobuf.ConfigContent.BowConfig;
import app.protobuf.ConfigContent.ServiceConfig;
import app.utils.VariableConfig;

import com.google.inject.Inject;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class BowDatas{

    private static final String BOW_SPELL_LOATION = "config/data/bow/bow_spell.txt";

    private static final String BOW_LOATION = "config/data/bow/bow.txt";

    private final BowSpell bowSpell;

    private final BowData[] bows;

    private transient final BowData firstBow;

    private transient final ChannelBuffer giveFirstBowMsg;

    @Inject
    BowDatas(GameObjects go, Spells spells, SpriteStats spriteStats,
            GoodsDatas goodsDatas, Shops shops){

        List<ObjectParser> data = go.loadFile(BOW_SPELL_LOATION);
        checkArgument(data.size() == 1, "弓箭技能表配置数据必须只有一条");

        bowSpell = new BowSpell(data.get(0), spells);

        data = go.loadFile(BOW_LOATION);
        checkArgument(!data.isEmpty(), "凤舞弓数据没有配置");

        bows = new BowData[data.size()];
        for (ObjectParser p : data){
            BowData d = new BowData(p, spriteStats, goodsDatas,
                    shops.getSystemShop(), bowSpell);

            checkArgument(bows[d.id - 1] == null, "凤舞弓配置存在重复的ID，%s", d);
            bows[d.id - 1] = d;
        }

        for (int i = 1; i < bows.length; i++){
            checkArgument(bows[i - 1].openSpellCount <= bows[i].openSpellCount,
                    "凤舞弓 %s 的技能开放个数居然小于前一阶", bows[i]);

            checkArgument(bows[i - 1].openBowTime <= bows[i].openBowTime,
                    "凤舞弓-%s 的开放时间居然小于前一阶", bows[i]);

            checkArgument(bows[i - 1].trigSpellCount <= bows[i].trigSpellCount,
                    "凤舞弓 %s 的技能触发个数居然小于前一阶", bows[i]);

            bows[i - 1].nextLevel = bows[i];
        }

        firstBow = bows[0];
        giveFirstBowMsg = BowMessages.giveBowMsg(firstBow.newBow()
                .encode4Client());

    }

    public BowData getBow(int id){
        return Utils.getValidObject(bows, id - 1);
    }

    public BowData getFirstBow(){
        return firstBow;
    }

    public ChannelBuffer getGiveFirstBowMsg(){
        return giveFirstBowMsg;
    }

    public BowConfig generateProto(VariableConfig config){
        BowConfig.Builder builder = BowConfig.newBuilder();

        for (BowData bow : bows){
            builder.addBow(bow.encode());
        }

        for (PassiveSpell ps : bowSpell.spellList){
            builder.addBowSpell(ps.getProto());
        }

        builder.setCollectBowLevel(config.COLLECT_FREE_BOW_LEVEL);

        return builder.build();
    }

    public void setBowOpenTime(ServiceConfig.Builder builder,
            long startServiceTime){
        for (BowData data : bows){
            if (data.openBowTime > 0){
                builder.addBowOpenTime(data.openBowTime + startServiceTime);
            } else{
                builder.addBowOpenTime(0);
            }

        }
    }
}
