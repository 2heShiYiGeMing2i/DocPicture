package app.game.data;

import static com.mokylin.sink.util.Preconditions.checkArgument;
import static com.mokylin.sink.util.Preconditions.checkNotNull;

import java.util.Collection;
import java.util.Collections;

import org.jboss.netty.buffer.ChannelBuffer;
import org.joda.time.DateTimeConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.data.goods.Goods;
import app.game.data.goods.GoodsData;
import app.game.data.goods.GoodsDatas;
import app.game.entity.Depot;
import app.game.entity.Hero;
import app.game.module.GoodsContainerModule;
import app.game.module.HeroMiscModule;
import app.game.shop.ShopGoods;
import app.game.shop.VendingMachine;
import app.message.ISender;
import app.protobuf.ConfigContent.UpgradeProto;
import app.protobuf.LogContent.LogEnum.OperateType;
import app.protobuf.ShopContent.PriceType;
import app.utils.VariableConfig;

import com.mokylin.collection.IntArrayList;
import com.mokylin.collection.IntHashMap;
import com.mokylin.sink.util.BufferUtil;
import com.mokylin.sink.util.RandomNumber;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * 通用升级数据，用于坐骑升级，装备强化等功能
 * @author Liwei
 *
 */
public class UpgradeData{

    private static final Logger logger = LoggerFactory
            .getLogger(UpgradeData.class);

    private static final int RATE_DENOMINATOR = 10000;

    private static final int LIJIN_AUTO_BUY = 1;

    private static final int YUANBAO_AUTO_BUY = 2;

    /**
     * 最大升级次数上限, 不能超过12个bit, 4095
     */
    private static final int UPGRADE_MAX_TIMES_LIMIT = (1 << 12) - 1;

    private static final IntHashMap<GoodsData> EMPTY_MAP = new IntHashMap<GoodsData>(){
        public boolean containsKey(int key){
            return false;
        };

        public java.util.Collection<GoodsData> values(){
            return Collections.emptyList();
        };
    };

    /**
     * 银两消耗
     */
    private final int upgradeMoneyCost;

    /**
     * 真气消耗
     */
    private final int upgradeRealAirCost;

    /**
     * 物品消耗个数
     */
    private final int upgradeGoodsCount;

    final GoodsData goods;

    private transient final int goodsId;

    /**
     * 替代物品
     */
    final IntHashMap<GoodsData> substituteGoodsMap;

    /**
     * 升级次数小于这个值，必定失败
     */
    private final int upgradeMinTimes;

    /**
     * 升级次数大于等于这个值，必定成功
     */
    private final int upgradeMaxTimes;

    /**
     * 最低次数 <= 升级次数 < 最高次数，强化成功的概率，分母是10000
     */
    private final int upgradeRate;

    /**
     * 升级失败的基础祝福值，每次失败的祝福值: baseBlessAmount + random(randomBlessAmount)
     */
    private final int baseBlessAmount;

    /**
     * 升级失败的随机祝福值，每次失败的祝福值: baseBlessAmount + random(randomBlessAmount)
     */
    private final int randomBlessAmount;

    /**
     * 祝福值大于等于这个值，必定成功
     */
    final int upgradeMaxBless;

    /**
     * 祝福值保留时间
     */
    final long blessHoldTime;

    /**
     * 礼金购买价格
     */
    final int upgradeGoodsLijinPrice;

    /**
     * 元宝购买价格
     */
    final int upgradeGoodsYuanbaoPrice;

    final String rateDesc;

    private final UpgradeProto proto;

//    public UpgradeData(Object master, ObjectParser p){
//        this(master, p, null, null);
//    }

    public UpgradeData(Object master, ObjectParser p, GoodsDatas goodsDatas){
        this(master, p, goodsDatas, null);
    }

    public UpgradeData(Object master, ObjectParser p, GoodsDatas goodsDatas,
            VendingMachine systemShop){

        int goodsId = p.getIntKey("goods", 0);
        if (goodsId > 0){
            goods = checkNotNull(goodsDatas.get(goodsId),
                    "%s 的升级物品没找到，goodsId： %s", master, goodsId);
            this.goodsId = goods.getId();

            if (systemShop == null){
                upgradeGoodsLijinPrice = 0;
                upgradeGoodsYuanbaoPrice = 0;
            } else{
                ShopGoods lijinGoods = systemShop.getGoods(PriceType.LIJIN,
                        goods.id);
                if (lijinGoods == null){
                    upgradeGoodsLijinPrice = 0;
                } else{
                    upgradeGoodsLijinPrice = lijinGoods.getPrice();
                    long maxPrice = 1L * upgradeGoodsLijinPrice
                            * goods.getMaxCount();
                    checkArgument(maxPrice <= Integer.MAX_VALUE,
                            "%s 的升级物品整堆礼金价格超出最大限制", master);
                }

                ShopGoods yuanbaoGoods = systemShop.getGoods(PriceType.YUANBAO,
                        goods.id);
                if (yuanbaoGoods == null){
                    upgradeGoodsYuanbaoPrice = 0;
                } else{
                    upgradeGoodsYuanbaoPrice = yuanbaoGoods.getPrice();
                    long maxPrice = 1L * upgradeGoodsYuanbaoPrice
                            * goods.getMaxCount();
                    checkArgument(maxPrice <= Integer.MAX_VALUE,
                            "%s 的升级物品整堆元宝价格超出最大限制", master);
                }
            }

            String substituteGoodsStr = p.getKey("substitute_goods", "");
            if (!substituteGoodsStr.isEmpty()){
                substituteGoodsMap = new IntHashMap<>();

                for (String s : substituteGoodsStr.split(";")){
                    int gid = Integer.parseInt(s);
                    GoodsData g = checkNotNull(goodsDatas.get(gid),
                            "%s 的升级替代物品没找到，goodsId： %s", master, s);

                    checkArgument(substituteGoodsMap.put(g.id, g) == null,
                            "%s 的升级替代物品存在重复，g： %s", master, g);
                }
            } else{
                substituteGoodsMap = EMPTY_MAP;
            }

            upgradeGoodsCount = p.getIntKey("upgrade_goods_count");
            checkArgument(upgradeGoodsCount > 0, "%s 每次升级消耗的物品个数必须大于0", master);

            checkArgument(upgradeGoodsCount <= goods.getMaxCount(),
                    "%s 每次升级消耗的物品个数必须小于等于整堆的个数", master);
        } else{
            goods = null;
            this.goodsId = 0;
            upgradeGoodsLijinPrice = 0;
            upgradeGoodsYuanbaoPrice = 0;
            substituteGoodsMap = EMPTY_MAP;
            upgradeGoodsCount = 0;
        }

        upgradeMoneyCost = p.getIntKey("upgrade_money");
        checkArgument(upgradeMoneyCost >= 0, "%s 每次升级消耗的银两必须大于等于0", master);

        upgradeRealAirCost = p.getIntKey("upgrade_real_air", 0);
        checkArgument(upgradeRealAirCost >= 0, "%s 每次升级消耗的真气必须大于等于0", master);

        checkArgument(goods != null || upgradeMoneyCost > 0
                || upgradeRealAirCost > 0,
                "%s 没有配置消耗物品，没有配置消耗银两，没有配置真气消耗，神马情况", master);

        upgradeMinTimes = p.getIntKey("upgrade_min_times", 1);
        checkArgument(upgradeMinTimes > 0, "%s 升级最小次数必须大于0", master);

        upgradeMaxTimes = p.getIntKey("upgrade_max_times", 1);
        checkArgument(upgradeMaxTimes >= upgradeMinTimes,
                "%s 升级必定成功次数必须大于等于升级最小次数, min： %s  max: %s", master,
                upgradeMinTimes, upgradeMaxTimes);
        checkArgument(upgradeMaxTimes <= UPGRADE_MAX_TIMES_LIMIT,
                "upgrade_max_times不能超过 %s: %s", UPGRADE_MAX_TIMES_LIMIT,
                upgradeMaxTimes); // equipment.goodsIdentifier encode时, 给了12个bit给了已强化次数

        upgradeRate = p.getIntKey("upgrade_rate", 0);
        checkArgument(upgradeRate >= 0 && upgradeRate <= RATE_DENOMINATOR,
                "%s 升级成功概率无效，0 <= 0 <= 10000, 概率： %s", master, upgradeRate);

        String blessStr = p.getKey("bless_per_time", "");
        if (!blessStr.isEmpty()){
            int baseAmount = 0;
            int randomAmount = 0;

            int idx = blessStr.indexOf("_");
            if (idx < 0){
                baseAmount = Integer.parseInt(blessStr);
            } else{
                baseAmount = Integer.parseInt(blessStr.substring(0, idx));
                int maxAmount = Integer.parseInt(blessStr.substring(idx + 1));

                checkArgument(maxAmount > 0, "%s 中进阶失败祝福值配置错误，最大值必须大于0, 值：%s",
                        master, blessStr);

                randomAmount = maxAmount - baseAmount;
                checkArgument(randomAmount >= 0,
                        "%s 中进阶失败祝福值配置错误，最大值必须大于最小值, 值：%s", master, blessStr);

                if (randomAmount > 0){
                    // 因为RandomNumber.getRate(n)返回的值是[0, n)，所以要+1
                    randomAmount++;
                }
            }

            checkArgument(baseAmount > 0, "%s  中进阶失败祝福值配置错误，最小值必须大于0, 值: %s",
                    master, blessStr);

            baseBlessAmount = baseAmount;
            randomBlessAmount = randomAmount;

            long upgradeMinTimesMinBlessAmount = 1L * baseBlessAmount
                    * upgradeMinTimes;

            upgradeMaxBless = p.getIntKey("upgrade_max_bless");
            checkArgument(upgradeMaxBless > 0, "%s 配置的祝福值上限必须大于0，", master);

            checkArgument(
                    upgradeMaxBless > upgradeMinTimesMinBlessAmount,
                    "%s 配置的祝福值上限无效，必须比最小次数成功进阶获得的最低祝福值要大，祝福值上限：%s 最小成功次数：%s 每次最低的祝福值：%s",
                    master, upgradeMaxBless, upgradeMinTimes, baseBlessAmount);

            blessHoldTime = p.getLongKey("bless_hold_time")
                    * DateTimeConstants.MILLIS_PER_MINUTE;
            checkArgument(blessHoldTime >= 0, "%s 祝福值保留时间必须大于等于0", master);
        } else{
            baseBlessAmount = randomBlessAmount = upgradeMaxBless = 0;
            blessHoldTime = 0;
        }

        rateDesc = p.getKey("rate_desc", "");

        proto = build();
    }

    private UpgradeData(Builder b){

        if (b.goods != null){
            goods = b.goods;
            goodsId = goods.getId();
            upgradeGoodsLijinPrice = b.upgradeGoodsLijinPrice;
            upgradeGoodsYuanbaoPrice = b.upgradeGoodsYuanbaoPrice;
            substituteGoodsMap = b.substituteGoodsMap;

            upgradeGoodsCount = b.upgradeGoodsCount;
            checkArgument(upgradeGoodsCount > 0, "%s 每次升级消耗的物品个数必须大于0",
                    b.master);

            checkArgument(upgradeGoodsCount <= goods.getMaxCount(),
                    "%s 每次升级消耗的物品个数必须小于等于整堆的个数", b.master);
        } else{
            goods = null;
            goodsId = 0;
            upgradeGoodsLijinPrice = 0;
            upgradeGoodsYuanbaoPrice = 0;
            substituteGoodsMap = EMPTY_MAP;
            upgradeGoodsCount = 0;
        }

        upgradeMoneyCost = b.upgradeMoneyCost;
        checkArgument(upgradeMoneyCost >= 0, "%s 每次升级消耗的银两必须大于等于0", b.master);

        upgradeRealAirCost = b.upgradeRealAirCost;
        checkArgument(upgradeRealAirCost >= 0, "%s 每次升级消耗的真气必须大于等于0", b.master);

        checkArgument(goods != null || upgradeMoneyCost > 0
                || upgradeRealAirCost > 0,
                "%s 没有配置消耗物品，没有配置消耗银两，没有配置真气消耗，神马情况", b.master);

        upgradeMinTimes = Math.max(b.upgradeMinTimes, 1);
        checkArgument(upgradeMinTimes > 0, "%s 升级最小次数必须大于0", b.master);

        upgradeMaxTimes = Math.max(b.upgradeMaxTimes, 1);
        checkArgument(upgradeMaxTimes >= upgradeMinTimes,
                "%s 升级必定成功次数必须大于等于升级最小次数, min： %s  max: %s", b.master,
                upgradeMinTimes, upgradeMaxTimes);

        upgradeRate = Math.max(b.upgradeRate, 0);
        checkArgument(upgradeRate >= 0 && upgradeRate <= RATE_DENOMINATOR,
                "%s 升级成功概率无效，0 <= 0 <= 10000, 概率： %s", b.master, upgradeRate);

        String blessStr = b.blessPerTimes;
        if (blessStr != null && !blessStr.isEmpty()){
            int baseAmount = 0;
            int randomAmount = 0;

            int idx = blessStr.indexOf("_");
            if (idx < 0){
                baseAmount = Integer.parseInt(blessStr);
            } else{
                baseAmount = Integer.parseInt(blessStr.substring(0, idx));
                int maxAmount = Integer.parseInt(blessStr.substring(idx + 1));

                checkArgument(maxAmount > 0, "%s 中进阶失败祝福值配置错误，最大值必须大于0, 值：%s",
                        b.master, blessStr);

                randomAmount = maxAmount - baseAmount;
                checkArgument(randomAmount >= 0,
                        "%s 中进阶失败祝福值配置错误，最大值必须大于最小值, 值：%s", b.master, blessStr);

                if (randomAmount > 0){
                    // 因为RandomNumber.getRate(n)返回的值是[0, n)，所以要+1
                    randomAmount++;
                }
            }

            checkArgument(baseAmount > 0, "%s  中进阶失败祝福值配置错误，最小值必须大于0, 值: %s",
                    b.master, blessStr);

            baseBlessAmount = baseAmount;
            randomBlessAmount = randomAmount;

            long upgradeMinTimesMinBlessAmount = 1L * baseBlessAmount
                    * upgradeMinTimes;

            upgradeMaxBless = b.upgradeMaxBless;
            checkArgument(upgradeMaxBless > 0, "%s 配置的祝福值上限必须大于0，", b.master);

            checkArgument(
                    upgradeMaxBless > upgradeMinTimesMinBlessAmount,
                    "%s 配置的祝福值上限无效，必须比最小次数成功进阶获得的最低祝福值要大，祝福值上限：%s 最小成功次数：%s 每次最低的祝福值：%s",
                    b.master, upgradeMaxBless, upgradeMinTimes, baseBlessAmount);

            blessHoldTime = b.blessHoldTime
                    * DateTimeConstants.MILLIS_PER_MINUTE;
            checkArgument(blessHoldTime >= 0, "%s 祝福值保留时间必须大于等于0", b.master);
        } else{
            baseBlessAmount = randomBlessAmount = upgradeMaxBless = 0;
            blessHoldTime = 0;
        }

        rateDesc = b.rateDesc;

        proto = build();
    }

    public void checkArg(Object name, UpgradeData prev){
        checkArgument(prev.upgradeGoodsCount <= upgradeGoodsCount,
                "%s 的升级消耗物品个数居然小于前一阶", name);

        checkArgument(prev.upgradeMoneyCost <= upgradeMoneyCost,
                "%s 的升级消耗银两居然小于前一阶", name);

        checkArgument(prev.upgradeMinTimes <= upgradeMinTimes,
                "%s 的最小升级次数居然小于前一阶", name);

        checkArgument(prev.upgradeMaxTimes <= upgradeMaxTimes,
                "%s 的最大升级次数居然小于前一阶", name);
    }

    public boolean isValidGoods(int goodsId){
        return goods.id == goodsId || substituteGoodsMap.containsKey(goodsId);
    }

    public GoodsData getUpgradeGoods(){
        return goods;
    }

    public Collection<GoodsData> getSubstituteGoods(){
        return substituteGoodsMap.values();
    }

    public void setCustomAuctionType(int type){
        if (goods != null){
            goods.setCustomAuctionType(type);

            for (GoodsData g : getSubstituteGoods()){
                g.setCustomAuctionType(type);
            }
        }
    }

    public int getUpgradeRealAirCost(){
        return upgradeMoneyCost;
    }

    public int getUpgradeMoneyCost(){
        return upgradeMoneyCost;
    }

    public int getUpgradeGoodsCount(){
        return upgradeGoodsCount;
    }

    public int getUpgradeMaxBless(){
        return upgradeMaxBless;
    }

    public int getUpgradeMaxTimes(){
        return upgradeMaxTimes;
    }

    public long getBlessHoldTime(){
        return blessHoldTime;
    }

    public int getUpgradeGoodsLijinPrice(){
        return upgradeGoodsLijinPrice;
    }

    public int getUpgradeGoodsYuanbaoPrice(){
        return upgradeGoodsYuanbaoPrice;
    }

    public int getBaseBlessAmount(){
        return baseBlessAmount;
    }

    public UpgradeProto getProto(){
        return proto;
    }

    private UpgradeProto build(){
        UpgradeProto.Builder builder = UpgradeProto.newBuilder();

        if (goods != null)
            builder.setUpgradeGoods(goods.getProtoByteString());

        if (upgradeGoodsLijinPrice > 0)
            builder.setLijinPrice(upgradeGoodsLijinPrice);

        if (upgradeGoodsYuanbaoPrice > 0)
            builder.setYuanbaoPrice(upgradeGoodsYuanbaoPrice);

        if (upgradeGoodsCount > 0)
            builder.setUpgradeGoodsCount(upgradeGoodsCount);

        for (GoodsData g : substituteGoodsMap.values()){
            builder.addSubstituteGoods(g.id);
        }

        if (upgradeMoneyCost > 0)
            builder.setUpgradeMoney(upgradeMoneyCost);

        if (upgradeRealAirCost > 0){
            builder.setUpgradeRealAir(upgradeRealAirCost);
        }

        if (upgradeMaxBless > 0)
            builder.setBlessMaxAmount(upgradeMaxBless);

        if (rateDesc != null && !rateDesc.isEmpty())
            builder.setRateDesc(rateDesc);

        return builder.build();
    }

    public ReduceCostResult tryReduceCostAllowBindedYuanbao(Object master,
            HeroMiscModule miscModule, long ctime, Hero hero, ISender sender,
            ChannelBuffer buffer, GoodsContainerModule goodsContainerModule,
            OperateType opType, String iEventId){
        return tryReduceCost(master, miscModule, ctime, hero, sender, buffer,
                goodsContainerModule, opType, iEventId, true);
    }

    public ReduceCostResult tryReduceCostNotAllowBindedYuanbao(Object master,
            HeroMiscModule miscModule, long ctime, Hero hero, ISender sender,
            ChannelBuffer buffer, GoodsContainerModule goodsContainerModule,
            OperateType opType, String iEventId){
        return tryReduceCost(master, miscModule, ctime, hero, sender, buffer,
                goodsContainerModule, opType, iEventId, false);
    }

    private ReduceCostResult tryReduceCost(Object master,
            HeroMiscModule miscModule, long ctime, Hero hero, ISender sender,
            ChannelBuffer buffer, GoodsContainerModule goodsContainerModule,
            OperateType opType, String iEventId, boolean allowBindedYuanbao){

        if (upgradeMoneyCost > 0
                && !miscModule.hasEnoughMoney(upgradeMoneyCost)){
            logger.warn("{}升级，银两不足", master);
            return ReduceCostResult.MONEY_NOT_ENOUGH;
        }

        if (upgradeRealAirCost > 0
                && !miscModule.hasEnoughRealAir(upgradeRealAirCost)){
            logger.warn("{}升级，真气不足", master);
            return ReduceCostResult.REAL_AIR_NOT_ENOUGH;
        }

        ReduceCostResult result = tryReduceGoods(master, miscModule, ctime,
                hero, sender, buffer, goodsContainerModule, opType, iEventId,
                allowBindedYuanbao);

        switch (result.getStatus()){
            case SUCCESS:{
                // 扣钱
                if (upgradeMoneyCost > 0){
                    miscModule.reduceMoneyAnyway(upgradeMoneyCost, opType,
                            iEventId);
                }

                // 扣真气
                if (upgradeRealAirCost > 0){
                    miscModule.reduceRealAirAnyway(upgradeRealAirCost, opType,
                            iEventId);
                }
                break;
            }
            default:{
                // 什么都不干
                break;
            }
        }

        return result;
    }

//    private ReduceGoodsResult tryBuyAllGoods(Object master, int type,
//            HeroMiscModule miscModule){
//        return tryBuyAllGoods(master, type, miscModule, upgradeGoodsCount);
//    }

    private ReduceCostResult tryBuyAllGoods(Object master, int type,
            HeroMiscModule miscModule, final int upgradeGoodsCount,
            OperateType opType, String iEventId, boolean allowBindedYuanbao){
        int buyCount = upgradeGoodsCount;

        switch (type){
            case LIJIN_AUTO_BUY:{
                if (upgradeGoodsLijinPrice <= 0){
                    logger.warn("{}升级，没有配置礼金价格，还选择用礼金买", master);
                    return ReduceCostResult.GOODS_NOT_ENOUGH;
                }

                // 礼金
                long amount = 1L * upgradeGoodsLijinPrice * buyCount;
                if (amount > VariableConfig.LIJIN_MAX_AMOUNT
                        || !miscModule.reduceLijin((int) amount, opType,
                                iEventId)){
                    logger.warn("{}升级，全部使用礼金购买，但是礼金不足", master);
                    return ReduceCostResult.LIJIN_NOT_ENOUGH;
                }

                return ReduceCostResult.SUCCESS_BINDED;
            }
            case YUANBAO_AUTO_BUY:{
                if (upgradeGoodsYuanbaoPrice <= 0){
                    logger.warn("{}升级，没有配置元宝价格，还选择用元宝买", master);
                    return ReduceCostResult.GOODS_NOT_ENOUGH;
                }

                // 元宝
                long amount = 1L * upgradeGoodsYuanbaoPrice * buyCount;
                if (amount > VariableConfig.YUANBAO_MAX_AMOUNT){
                    logger.warn(
                            "{}升级，全部使用元宝购买，amount > VariableConfig.YUANBAO_MAX_AMOUNT",
                            master);
                    return ReduceCostResult.YUANBAO_NOT_ENOUGH;
                }

                if (allowBindedYuanbao
                        && miscModule.reduceBindedYuanbao((int) amount, opType,
                                iEventId)){
                    return ReduceCostResult.SUCCESS_BINDED_YUANBAO;
                } else{
                    if (!miscModule.reduceYuanbao((int) amount, opType,
                            iEventId, goodsId, buyCount)){
                        logger.warn("{}升级，全部使用元宝购买，但是元宝不足", master);
                        return ReduceCostResult.YUANBAO_NOT_ENOUGH;
                    }
                }

                return ReduceCostResult.SUCCESS;
            }
            default:{
                // 全物品
                logger.warn("{}升级，一个物品都没发，而且还选择使用物品升级", master);
                return ReduceCostResult.GOODS_NOT_ENOUGH;
            }
        }
    }

    private ReduceCostResult tryReduceGoods(Object master,
            HeroMiscModule miscModule, long ctime, Hero hero, ISender sender,
            ChannelBuffer buffer, GoodsContainerModule goodsContainerModule,
            OperateType opType, String iEventId, boolean allowBindedYuanbao){
        return tryReduceGoods(master, miscModule, ctime, hero, sender, buffer,
                goodsContainerModule, upgradeGoodsCount, opType, iEventId,
                allowBindedYuanbao, false);
    }

    public ReduceCostResult tryReduceGoods(Object master,
            HeroMiscModule miscModule, long ctime, Hero hero, ISender sender,
            ChannelBuffer buffer, GoodsContainerModule goodsContainerModule,
            final int upgradeGoodsCount, OperateType opType, String iEventId,
            boolean allowBindedYuanbao){
        return tryReduceGoods(master, miscModule, ctime, hero, sender, buffer,
                goodsContainerModule, upgradeGoodsCount, opType, iEventId,
                allowBindedYuanbao, false);
    }

    public ReduceCostResult tryReduceGoods(Object master,
            HeroMiscModule miscModule, long ctime, Hero hero, ISender sender,
            ChannelBuffer buffer, GoodsContainerModule goodsContainerModule,
            final int upgradeGoodsCount, OperateType opType, String iEventId,
            boolean allowBindedYuanbao, boolean isCareDetails){
        if (upgradeGoodsCount <= 0){
            return ReduceCostResult.SUCCESS;
        }

        int type = BufferUtil.readVarInt32(buffer);
        if (!buffer.readable()){
            return tryBuyAllGoods(master, type, miscModule, upgradeGoodsCount,
                    opType, iEventId, allowBindedYuanbao);
        }

        // 扣物品
        int bindedGoodsCount = 0;
        int reduceGoodsCount = 0;

        IntArrayList reducePosCountList = new IntArrayList(upgradeGoodsCount);
        // 检查客户端发送的位置，就是一个位置一个，最多upgradeGoodsCount次
        for (int i = 0; i < upgradeGoodsCount; i++){
            int pos = BufferUtil.readVarInt32(buffer);

            Depot depot = hero.getDepot();
            if (depot.isInvalidPos(pos)){
                logger.warn("{}，发送的物品位置无效", master);
                return ReduceCostResult.INVALID_POS_COUNT;
            }

            if (depot.isLocked(pos)){
                logger.warn("{}，发送的物品位置已被锁定", master);
                return ReduceCostResult.INVALID_POS_COUNT;
            }

            Goods g = depot.get(pos);
            if (g == null){
                logger.warn("{}，发送的物品位置是null", master);
                return ReduceCostResult.INVALID_POS_COUNT;
            }

            if (g.isExpired(ctime)){
                logger.warn("{}，发送的物品位置是上物品已过期", master);
                return ReduceCostResult.INVALID_POS_COUNT;
            }

            int count = BufferUtil.readVarInt32(buffer);
            if (g.getCount() < count){
                logger.warn("{}，发送的物品位置上的物品个数不足", master);
                return ReduceCostResult.INVALID_POS_COUNT;
            }

            if (!isValidGoods(g.getId())){
                logger.warn("{}，发送的物品位置上的物品不是升级物品", master);
                return ReduceCostResult.INVALID_POS_COUNT;
            }

            // 防止客户端相同的物品位置上来
            if (g.version == ctime){
                logger.warn("{}，消耗物品重复了？", g);
                return ReduceCostResult.INVALID_POS_COUNT;
            }
            g.version = ctime;

            if (reduceGoodsCount + count > upgradeGoodsCount){
                count = upgradeGoodsCount - reduceGoodsCount;
            }

            if (g.isBinded()){
                bindedGoodsCount += count;
            }

            reduceGoodsCount += count;

            reducePosCountList.add(pos);
            reducePosCountList.add(count);

            if (reduceGoodsCount >= upgradeGoodsCount)
                break;

            if (!buffer.readable())
                break;
        }

        boolean bindedYuanbao = false;
        if (reduceGoodsCount < upgradeGoodsCount){
            int buyCount = upgradeGoodsCount - reduceGoodsCount;

            switch (type){
                case LIJIN_AUTO_BUY:{
                    if (upgradeGoodsLijinPrice <= 0){
                        logger.warn("{}，没有配置礼金价格，还选择用礼金买", master);
                        return ReduceCostResult.GOODS_NOT_ENOUGH;
                    }

                    // 礼金
                    long amount = 1L * upgradeGoodsLijinPrice * buyCount;
                    if (amount > VariableConfig.LIJIN_MAX_AMOUNT
                            || !miscModule.reduceLijin((int) amount, opType,
                                    iEventId)){
                        logger.warn("{}，部分使用礼金购买，但是礼金不足", master);
                        return ReduceCostResult.LIJIN_NOT_ENOUGH;
                    }
                    break;
                }
                case YUANBAO_AUTO_BUY:{
                    if (upgradeGoodsYuanbaoPrice <= 0){
                        logger.warn("{}，没有配置元宝价格，还选择用元宝买", master);
                        return ReduceCostResult.GOODS_NOT_ENOUGH;
                    }

                    long amount = 1L * upgradeGoodsYuanbaoPrice * buyCount;
                    if (amount > VariableConfig.YUANBAO_MAX_AMOUNT){
                        logger.warn(
                                "{}，部分使用元宝购买，amount > VariableConfig.YUANBAO_MAX_AMOUNT",
                                master);
                        return ReduceCostResult.YUANBAO_NOT_ENOUGH;
                    }

                    // 元宝
                    if (allowBindedYuanbao
                            && miscModule.reduceBindedYuanbao((int) amount,
                                    opType, iEventId)){
                        bindedYuanbao = true;
                        bindedGoodsCount += buyCount;
                    } else{
                        if (!miscModule.reduceYuanbao((int) amount, opType,
                                iEventId, goodsId, buyCount)){
                            logger.warn("{}，部分使用元宝购买，但是元宝不足", master);
                            return ReduceCostResult.YUANBAO_NOT_ENOUGH;
                        }
                    }

                    break;
                }
                default:{
                    // 全物品
                    logger.warn("{}，物品不足，但是没有选择元宝或者礼金购买", master);
                    return ReduceCostResult.GOODS_NOT_ENOUGH;
                }
            }
        }

        // 扣物品
        goodsContainerModule.reduceGoodsListAnyway(reducePosCountList, hero,
                sender, opType, 0, ctime);

        if (isCareDetails){
            return new ReduceCostResult(UpgradeStatus.SUCCESS,
                    reduceGoodsCount, bindedGoodsCount, bindedYuanbao);
        }

        return bindedYuanbao ? ReduceCostResult.SUCCESS_BINDED_YUANBAO
                : bindedGoodsCount > 0 ? ReduceCostResult.SUCCESS_BINDED
                        : ReduceCostResult.SUCCESS;
    }

    public static class ReduceCostResult{

        private static final ReduceCostResult MONEY_NOT_ENOUGH = new ReduceCostResult(
                UpgradeStatus.MONEY_NOT_ENOUGH, 0, 0, false);

        private static final ReduceCostResult REAL_AIR_NOT_ENOUGH = new ReduceCostResult(
                UpgradeStatus.REAL_AIR_NOT_ENOUGH, 0, 0, false);

        private static final ReduceCostResult INVALID_POS_COUNT = new ReduceCostResult(
                UpgradeStatus.INVALID_POS_COUNT, 0, 0, false);

        private static final ReduceCostResult GOODS_NOT_ENOUGH = new ReduceCostResult(
                UpgradeStatus.GOODS_NOT_ENOUGH, 0, 0, false);

        private static final ReduceCostResult LIJIN_NOT_ENOUGH = new ReduceCostResult(
                UpgradeStatus.LIJIN_NOT_ENOUGH, 0, 0, false);

        private static final ReduceCostResult YUANBAO_NOT_ENOUGH = new ReduceCostResult(
                UpgradeStatus.YUANBAO_NOT_ENOUGH, 0, 0, false);

        private static final ReduceCostResult SUCCESS = new ReduceCostResult(
                UpgradeStatus.SUCCESS, 0, 0, false);

        private static final ReduceCostResult SUCCESS_BINDED = new ReduceCostResult(
                UpgradeStatus.SUCCESS, 0, 1, false);

        private static final ReduceCostResult SUCCESS_BINDED_YUANBAO = new ReduceCostResult(
                UpgradeStatus.SUCCESS, 0, 1, true);

        private final UpgradeStatus status;

        // 总共扣了多少个物品，不包括花钱买的
//        private final int reduceGoodsCount;

        // 公共扣了多少个绑定物品，不包括花钱买的
        private final int reduceBindedCount;

        private final boolean bindedYuanbao;

        ReduceCostResult(UpgradeStatus status, int reduceGoodsCount,
                int reduceBindedCount, boolean bindedYuanbao){
            this.status = status;
//            this.reduceGoodsCount = reduceGoodsCount;
            this.reduceBindedCount = reduceBindedCount;
            this.bindedYuanbao = bindedYuanbao;
        }

        public UpgradeStatus getStatus(){
            return status;
        }

        public boolean hasBindedYuanbao(){
            return bindedYuanbao;
        }

        public boolean hasBindedGoods(){
            return reduceBindedCount > 0;
        }

        public int getBindedGoodsCount(){
            return reduceBindedCount;
        }
    }

    public static enum UpgradeStatus{

        /**
         * 银两不足
         */
        MONEY_NOT_ENOUGH,

        /**
         * 真气不足
         */
        REAL_AIR_NOT_ENOUGH,

        /**
         * 物品位置，或者个数不对
         */
        INVALID_POS_COUNT,

        /**
         * 物品不足
         */
        GOODS_NOT_ENOUGH,

        /**
         * 礼金不足
         */
        LIJIN_NOT_ENOUGH,

        /**
         * 元宝不足
         */
        YUANBAO_NOT_ENOUGH,

        /**
         * 成功，使用的物品中没有绑定物品
         */
        SUCCESS;
    }

    public boolean tryUpgrade(int upgradeTimes){
        if (upgradeTimes < upgradeMinTimes){
            return false;
        }

        if (upgradeTimes >= upgradeMaxTimes){
            return true;
        }

        return RandomNumber.getRate(RATE_DENOMINATOR, true) < upgradeRate;
    }

    public int randomBlessAmount(){
        return baseBlessAmount + RandomNumber.getRate(randomBlessAmount);
    }

    public static Builder newBuilder(Object master){
        return new Builder(master);
    }

    public static class Builder{

        private final Object master;

        private GoodsData goods;

        private int upgradeGoodsCount;

        private int upgradeGoodsLijinPrice;

        private int upgradeGoodsYuanbaoPrice;

        private IntHashMap<GoodsData> substituteGoodsMap = EMPTY_MAP;

        private int upgradeMoneyCost;

        private int upgradeRealAirCost;

        private int upgradeMinTimes;

        private int upgradeMaxTimes;

        private int upgradeRate;

        private String blessPerTimes;

        private int upgradeMaxBless;

        private long blessHoldTime;

        private String rateDesc = "";

        private Builder(Object master){
            this.master = master;
        }

        public void setGoods(GoodsData goods){
            this.goods = goods;
        }

        public void setUpgradeGoodsCount(int upgradeGoodsCount){
            this.upgradeGoodsCount = upgradeGoodsCount;
        }

        public void setUpgradeGoodsLijinPrice(int upgradeGoodsLijinPrice){
            this.upgradeGoodsLijinPrice = upgradeGoodsLijinPrice;
        }

        public void setUpgradeGoodsYuanbaoPrice(int upgradeGoodsYuanbaoPrice){
            this.upgradeGoodsYuanbaoPrice = upgradeGoodsYuanbaoPrice;
        }

        public void addSubstituteGoods(GoodsData substituteGoods){
            if (substituteGoodsMap.isEmpty()){
                substituteGoodsMap = new IntHashMap<GoodsData>();
            }

            substituteGoodsMap.put(substituteGoods.id, substituteGoods);
        }

        public void setUpgradeMoneyCost(int upgradeMoneyCost){
            this.upgradeMoneyCost = upgradeMoneyCost;
        }

        public void setUpgradeRealAirCost(int upgradeRealAirCost){
            this.upgradeRealAirCost = upgradeRealAirCost;
        }

        public void setUpgradeMinTimes(int upgradeMinTimes){
            this.upgradeMinTimes = upgradeMinTimes;
        }

        public void setUpgradeMaxTimes(int upgradeMaxTimes){
            this.upgradeMaxTimes = upgradeMaxTimes;
        }

        public void setUpgradeRate(int upgradeRate){
            this.upgradeRate = upgradeRate;
        }

        public void setBlessPerTimes(String blessPerTimes){
            this.blessPerTimes = blessPerTimes;
        }

        public void setUpgradeMaxBless(int upgradeMaxBless){
            this.upgradeMaxBless = upgradeMaxBless;
        }

        public void setBlessHoldTime(long blessHoldTime){
            this.blessHoldTime = blessHoldTime;
        }

        public void setRateDesc(String rateDesc){
            this.rateDesc = rateDesc;
        }

        public UpgradeData build(){
            return new UpgradeData(this);
        }
    }
}
