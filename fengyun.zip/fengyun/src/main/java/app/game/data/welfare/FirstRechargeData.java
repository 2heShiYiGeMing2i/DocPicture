package app.game.data.welfare;

import static com.mokylin.sink.util.Preconditions.checkArgument;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.data.Prize;
import app.game.data.PrizeConfig;
import app.game.data.PrizeConfigs;
import app.game.module.WelfareMessages;
import app.protobuf.HeroServerContent.RaceId;

import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class FirstRechargeData{

    final int id;

    final Prize singlePrize;

    final Prize[] racePrizes;

    private final ChannelBuffer singleRechargeDataMsg;

    private final ChannelBuffer[] raceDataMsgs;

    private final ChannelBuffer collectPrizeMsg;

    FirstRechargeData(int id, ObjectParser p, PrizeConfigs prizes){

        this.id = id;

        String prizeName = p.getKey("prize");
        PrizeConfig prizeConfig = prizes.get(prizeName);

        checkArgument(!prizeConfig.hasExipreTimeGoods(), "首冲奖励中配置了有过期时间的物品");
        checkArgument(!prizeConfig.isVarPrize(), "首冲奖励中配置了随机属性的物品");
        checkArgument(!prizeConfig.hasUnbindedGoods(), "首冲奖励中配置了非绑定的物品");

        if (prizeConfig.isRaceDiff()){
            singlePrize = null;
            racePrizes = new Prize[RaceId.values().length];

            singleRechargeDataMsg = null;
            raceDataMsgs = new ChannelBuffer[RaceId.values().length];
            for (RaceId race : RaceId.values()){
                racePrizes[race.getNumber() - 1] = prizeConfig.random(race);
                raceDataMsgs[race.getNumber() - 1] = WelfareMessages
                        .getFirstRechargeData(racePrizes[race.getNumber() - 1]
                                .encode4Client());
            }
        } else{
            singlePrize = prizeConfig.random();
            racePrizes = null;

            singleRechargeDataMsg = WelfareMessages
                    .getFirstRechargeData(singlePrize.encode4Client());
            raceDataMsgs = null;
        }

        collectPrizeMsg = WelfareMessages.collectFirstRechargePrizeMsg(id + 1);
    }

    public int getId(){
        return id;
    }

    public Prize getPrize(int race){
        if (singlePrize != null){
            return singlePrize;
        }

        return Utils.getValidObject(racePrizes, race - 1);
    }

    public ChannelBuffer getDataMsg(int race){
        if (singleRechargeDataMsg != null){
            return singleRechargeDataMsg;
        }

        return Utils.getValidObject(raceDataMsgs, race - 1);
    }

    public ChannelBuffer getCollectPrizeMsg(){
        return collectPrizeMsg;
    }
}
