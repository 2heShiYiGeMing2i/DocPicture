package app.game.data.goods;

import static com.mokylin.sink.util.Preconditions.*;

import java.util.Arrays;
import java.util.Map;

import org.joda.time.format.DateTimeFormatter;

import app.protobuf.GoodsServerContent.GoodsType;

import com.google.common.collect.Maps;
import com.mokylin.sink.util.TimeFormatter;
import com.mokylin.sink.util.Utils;

/**
 * 通用物品随机生成器
 * @author Liwei
 *
 */
public class GoodsRandomer{

//    private static final Logger logger = LoggerFactory
//            .getLogger(GoodsRandomer.class);

    public static final GoodsRandomer[] EMPTY_ARRAY = new GoodsRandomer[0];

    static final DateTimeFormatter formatter = TimeFormatter.SECOND;

    static final String BINDED_KEY = "binded";

    private static final String COUNT_KEY = "count";

    static final String EXPIRE_TIME_KEY = "expire_time";

    static final String TAB_KEY = "tab";

    public static GoodsRandomer newRandomer(Object parent, String p,
            GoodsDatas goodsDatas){
        return newRandomer(parent, p, goodsDatas, 0);
    }

    public static GoodsRandomer newRandomer(Object parent, String p,
            GoodsDatas goodsDatas, int defaultCount){
        String[] params = p.split(";");

        GoodsData data = checkNotNull(
                goodsDatas.get(Integer.parseInt(params[0])),
                "GoodsRandomer物品没找到，%s parent:%s", Arrays.toString(params),
                parent);

        Map<String, String> paramMap = Maps
                .newHashMapWithExpectedSize(params.length - 1);

        for (int i = 1; i < params.length; i++){

            String[] keyValues = params[i].split("=");
            switch (keyValues.length){
                case 1:{
                    checkArgument(
                            paramMap.put(keyValues[0], keyValues[0]) == null,
                            "GoodsRandomer的参数Key重复，key: %s parent:%s",
                            keyValues[0], parent);
                    break;
                }
                case 2:{
                    checkArgument(
                            paramMap.put(keyValues[0], keyValues[1]) == null,
                            "GoodsRandomer的参数Key重复，key: %s parent:%s",
                            keyValues[0], parent);
                    break;
                }
                default:{
                    throw new IllegalArgumentException(parent.toString()
                            + " GoodsRandomer属性配置参数格式无效，参数中的'='个数 >1，参数："
                            + params[i]);
                }
            }
        }

        if (defaultCount > 0)
            paramMap.put(COUNT_KEY, String.valueOf(defaultCount));

        if (data instanceof EquipmentData){
            return new EquipmentRandomer(parent, (EquipmentData) data, paramMap);
        } else if (data instanceof MountEquipmentData){
            return new MountEquipmentRandomer(parent,
                    (MountEquipmentData) data, paramMap);
        } else{
            return new GoodsRandomer(parent, data, paramMap);
        }
    }

    protected final GoodsData data;

    // 默认个数
    protected final int defaultCount;

    // 绑定状态
    protected final boolean binded;

    // 物品过期时间点
    protected final long expireTime;

    // 有效期
    protected final int duration;

    protected transient final ExpireTimeType type;

    private transient final int needEmptyPosCount;

    protected final int tab;

    GoodsRandomer(Object parent, GoodsData data, Map<String, String> paramMap){

        this.data = data;
        binded = paramMap.containsKey(BINDED_KEY);

        String countStr = paramMap.get(COUNT_KEY);
        int count = 1;
        if (countStr != null && !countStr.isEmpty()){
            count = Integer.parseInt(countStr);
        }
//        checkArgument(
//                count > 0 && count <= data.getMaxCount(),
//                "%s 在GoodsRandomer中配置的个数无效，个数 0 < count <= maxCount, count: %s parent:%s",
//                data, count, parent);
        defaultCount = count;

        String expireTimeStr = paramMap.get(EXPIRE_TIME_KEY);
        long expireTime = 0;
        int duration = 0;
        if (expireTimeStr != null && !expireTimeStr.isEmpty()){
            checkArgument(data.getType() != GoodsType.EQUIPMENT,
                    "%s 是装备，不能配置过期时间 parent:%s", data, parent);
            checkArgument(data.getType() != GoodsType.MOUNT_EQUIPMENT,
                    "%s 是坐骑装备，不能配置过期时间 parent:%s", data, parent);
            checkArgument(data.getType() != GoodsType.XINFA,
                    "%s 是技能心法，不能配置过期时间 parent:%s", data, parent);

            if (expireTimeStr.indexOf("-") < 0){
                duration = Integer.parseInt(expireTimeStr);
                checkArgument(duration > 0, "%s 配置的有效期为0 parent:%s", data,
                        parent);
                type = ExpireTimeType.DURATION;
            } else{
                expireTime = formatter.parseMillis(expireTimeStr);
                type = ExpireTimeType.EXPIRE_TIME;
            }

            checkArgument(data.dropable || data.canSell(),
                    "%s 不能丢不能卖，但是配置了过期时间，真是太过分了 parent:%s", data, parent);
        } else{
            type = ExpireTimeType.NEVER;
        }
        this.expireTime = expireTime;
        this.duration = duration;

        needEmptyPosCount = Utils.divide(count, data.getMaxCount());

        String tabStr = paramMap.get(TAB_KEY);
        if (tabStr == null || tabStr.isEmpty()){
            tab = 0;
        } else{
            tab = Integer.parseInt(tabStr);
        }
    }

    public GoodsData getData(){
        return data;
    }

    public int getDefaultCount(){
        return defaultCount;
    }

    public int getNeedEmptyPosCount(){
        return needEmptyPosCount;
    }

    public boolean isBinded(){
        return binded;
    }

    public long getExpireTime(){
        return expireTime;
    }

    public int getDuration(){
        return duration;
    }

    public boolean hasRandomProperties(){
        return false;
    }

    public GoodsWrapper getGoodsWrapper(){
        return getGoodsWrapperWithCount(defaultCount);
    }

    public GoodsWrapper getGoodsWrapperWithCount(int count){
        GoodsWrapper wrapper = new GoodsWrapper(data, binded, count,
                expireTime, duration, tab);

        return wrapper;
    }

    public Goods create(long ctime){
        return createWithCount(ctime, defaultCount);
    }

    public Goods createWithCount(long ctime, int count){
        Goods g = data.newGoods(getGoodsExpireTime(ctime));
        g.setCount(count);

        if (binded)
            g.bind();

        return g;
    }

    protected long getGoodsExpireTime(long ctime){
        switch (type){
            case EXPIRE_TIME:{
                return expireTime;
            }
            case DURATION:{
                return ctime + duration;
            }
            default:{
                return 0;
            }
        }
    }

    static enum ExpireTimeType{
        NEVER, EXPIRE_TIME, DURATION;
    }

    public GoodsAddHelper newHelper(long ctime){
        return newHelper(ctime, defaultCount);
    }

    public GoodsAddHelper newHelper(long ctime, int count){
        return getGoodsWrapperWithCount(count).newHelper(ctime);
    }

//    public static class RandomGoodsAddHelper extends GoodsAddHelper{
//
//        private final GoodsRandomer goodsRandomer;
//
//        private final long ctime;
//
//        public RandomGoodsAddHelper(GoodsRandomer goodsRandomer, int count,
//                long ctime){
//            super(goodsRandomer.getData(), count, goodsRandomer.binded,
//                    goodsRandomer.getGoodsExpireTime(ctime));
//            this.goodsRandomer = goodsRandomer;
//            this.ctime = ctime;
//        }
//
//        public Goods create(){
//            assert count > 0: "ShopGoodsHolder的count<=0，还调用create()";
//
//            if (count <= 0){
//                return null; // 防御性
//            }
//
//            int c = data.getMaxCount();
//            if (count > data.getMaxCount()){
//                count -= data.getMaxCount();
//            } else{
//                c = count;
//                count = 0;
//            }
//
//            return goodsRandomer.createWithCount(ctime, c);
//        }
//    }
}
