/**
 * 
 */
package app.game.data;

import static com.mokylin.sink.util.Preconditions.checkArgument;

import java.util.EnumMap;

import app.protobuf.SpriteStatContent.SingleStatProto;
import app.protobuf.SpriteStatContent.StatType;

import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 * 
 */
public class SingleSpriteStat{

    public static final SingleSpriteStat[] EMPTY_ARRAY = new SingleSpriteStat[0];

    private static EnumMap<StatType, SingleSpriteStat> emptyMap = new EnumMap<StatType, SingleSpriteStat>(
            StatType.class);

    static{
        StatType[] types = StatType.values();
        for (int i = 0; i < types.length; i++){
            StatType type = types[i];
            emptyMap.put(type, new SingleSpriteStat(type, 0));
        }
    }

    public static final SingleSpriteStat EMPTY_MAX_LIFE_STAT = getEmptyStat(StatType.MAX_LIFE);

    public static final SingleSpriteStat EMPTY_ATTACK_STAT = getEmptyStat(StatType.ATTACK);

    public static final SingleSpriteStat EMPTY_DEFENCE_STAT = getEmptyStat(StatType.DEFENCE);

    public static SingleSpriteStat getEmptyStat(StatType type){
        return emptyMap.get(type);
    }

    final int id;

    final StatType statType;

    final int amount;

    SingleSpriteStat(ObjectParser p){
        this.id = p.getIntKey("id");

        int type = p.getIntKey("stat_type");
        this.statType = StatType.valueOf(type);
        checkArgument(this.statType != null, "单属性%s 配置的类型无效，type: %s", id, type);

        this.amount = p.getIntKey("amount");
    }

    public SingleSpriteStat(StatType statType, int amount){
        this.id = 0;
        this.statType = statType;
        this.amount = amount;
    }

    public SingleSpriteStat add(SingleSpriteStat toAdd){
        assert statType == toAdd.statType;

        if (amount == 0){
            return toAdd;
        } else if (toAdd.amount == 0){
            return this;
        }

        return new SingleSpriteStat(statType, amount + toAdd.amount);
    }

    public SingleSpriteStat add(SingleSpriteStat toAdd, int precent){
        return add(toAdd, precent / 100f);
    }

    public SingleSpriteStat add(SingleSpriteStat toAdd, float multiply){
        assert statType == toAdd.statType;

        if (toAdd.amount == 0){
            return this;
        }

        return new SingleSpriteStat(statType, amount
                + (int) (toAdd.amount * multiply));
    }

    public SingleSpriteStat remove(SingleSpriteStat toRemove){
        assert statType == toRemove.statType;

        if (toRemove.amount == 0){
            return this;
        }

        return new SingleSpriteStat(statType, amount - toRemove.amount);
    }

    public SingleSpriteStat multiply(float multiply){

        if (amount == 0 || multiply == 1){
            return this;
        }

        return new SingleSpriteStat(statType, (int) (amount * multiply));
    }

    public StatType getStatType(){
        return statType;
    }

    public int getAmount(){
        return amount;
    }

    public boolean isEmptyStat(){
        return amount == 0;
    }

    public boolean isBuffStat(){
        return amount > 0;
    }

    public SingleStatProto encode(){
        return SingleStatProto.newBuilder().setStatType(statType)
                .setAmount(amount).build();
    }

    @Override
    public String toString(){
        return statType + ":" + amount;
    }
}
