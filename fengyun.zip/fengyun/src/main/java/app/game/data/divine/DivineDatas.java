package app.game.data.divine;

import static com.mokylin.sink.util.Preconditions.checkArgument;

import java.util.List;

import app.game.data.GameObjects;
import app.game.data.UpgradeData;
import app.game.data.goods.GoodsData;
import app.game.data.goods.GoodsDatas;
import app.game.data.goods.GoodsRandomer;
import app.game.data.scene.PlunderGroups;
import app.protobuf.ConfigContent.DivineConfig;
import app.utils.VariableConfig;

import com.google.common.collect.Lists;
import com.google.inject.Inject;
import com.mokylin.collection.LeftIntPair;
import com.mokylin.sink.util.WeightedRandomer;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class DivineDatas{

    private static final String LOCATION = "config/data/system/divine.txt";

    private final DivineData[] datas;

    private final WeightedRandomer<DivineData> divineRandomer;

    private final WeightedRandomer<DivineData> luckyDivineRandomer;

    private final GoodsRandomer fireMonkeyGoodsRandomer;

    private final UpgradeData upgradeData;

    @Inject
    DivineDatas(GameObjects go, PlunderGroups groups, GoodsDatas goodsDatas,
            VariableConfig config){
        List<ObjectParser> data = go.loadFile(LOCATION);
        checkArgument(data.size() > 0, "知天命数据没有配置");

        datas = new DivineData[data.size()];
        for (ObjectParser p : data){
            DivineData d = new DivineData(p, groups);
            checkArgument(d.id >= 1 && d.id <= data.size(),
                    "知天命ID配置错误，必须从1开始连续配置, %s", d);

            checkArgument(datas[d.id - 1] == null, "知天命系统存在重复数据, %s", d);

            datas[d.id - 1] = d;
        }

        List<LeftIntPair<DivineData>> pairs = Lists
                .newArrayListWithCapacity(data.size());
        for (DivineData d : datas){
            pairs.add(new LeftIntPair<DivineData>(d.weight, d));
        }
        divineRandomer = new WeightedRandomer<>(pairs);

        pairs.clear();
        for (DivineData d : datas){
            if (d.isLucky)
                pairs.add(new LeftIntPair<DivineData>(d.weight, d));
        }
        checkArgument(!pairs.isEmpty(), "知天命居然没有配置吉门数据");
        luckyDivineRandomer = new WeightedRandomer<>(pairs);

        // 读取火猴物品
        try{
            fireMonkeyGoodsRandomer = GoodsRandomer.newRandomer("抓火猴",
                    config.FIRE_MONKEY_GOODS_CONFIG, goodsDatas);
        } catch (Throwable ex){
            System.err.println("读取抓到火猴后的物品奖励出错: "
                    + config.FIRE_MONKEY_GOODS_CONFIG
                    + ". 在config/settings.txt中配置fire_monkey_goods_config");
            throw ex;
        }

        GoodsData divineGoods = fireMonkeyGoodsRandomer.getData();

        UpgradeData.Builder builder = UpgradeData.newBuilder("知天命");
        builder.setGoods(divineGoods);
        builder.setUpgradeGoodsCount(config.DIVINE_GOODS_COUNT);
        builder.setUpgradeGoodsYuanbaoPrice(config.DIVINE_YUANBAO_COST);
        builder.setBlessPerTimes(config.DIVINE_BLESS_PER_TIMES);
        builder.setUpgradeMaxBless(config.DIVINE_MAX_BLESS);
        upgradeData = builder.build();

        checkArgument(upgradeData.getUpgradeGoods() == divineGoods);
        checkArgument(upgradeData.getUpgradeGoodsYuanbaoPrice() > 0,
                "知天命配置的元宝消耗必须>0");
        checkArgument(upgradeData.getUpgradeMaxBless() > 0, "知天命配置的最大吉运值必须>0");
        checkArgument(upgradeData.getBaseBlessAmount() > 0, "知天命配置的吉运值基础值必须>0");
    }

    public UpgradeData getUpgradeData(){
        return upgradeData;
    }

    public GoodsRandomer getFireMonkeyGoodsRandomer(){
        return fireMonkeyGoodsRandomer;
    }

    public DivineData random(){
        return divineRandomer.next();
    }

    public DivineData luckyRandom(){
        return luckyDivineRandomer.next();
    }

    public DivineConfig generateProto(VariableConfig config){
        DivineConfig.Builder builder = DivineConfig.newBuilder();

        builder.setUpgradeData(upgradeData.getProto())
                .setLogMaxCount(VariableConfig.DIVINE_LOG_MAX_COUNT)
                .setDivineStorageCapcity(config.DIVINE_STORAGE_CAPCITY);

        if (config.DIVINE_MONEY_TIMES > 0){
            builder.setDivineMoneyTimes(config.DIVINE_MONEY_TIMES);
        }

        if (config.DIVINE_MONEY_COST > 0){
            builder.setDivineMoneyCost(config.DIVINE_MONEY_COST);
        }

        for (DivineData data : datas){
            builder.addDivines(data.encode());
        }

        return builder.build();
    }
}
