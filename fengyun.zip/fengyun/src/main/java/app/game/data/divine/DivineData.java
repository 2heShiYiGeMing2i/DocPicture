package app.game.data.divine;

import static com.mokylin.sink.util.Preconditions.checkArgument;
import static com.mokylin.sink.util.Preconditions.checkNotNull;
import app.game.data.goods.Goods;
import app.game.data.scene.PlunderGroup;
import app.game.data.scene.PlunderGroups;
import app.protobuf.ConfigContent.DivineProto;
import app.protobuf.GoodsServerContent.Quality;

import com.google.protobuf.ByteString;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class DivineData{

    /**
     * 1-生门，2-惊门，3-开门，4-杜门，5-休门，6-伤门，7-景门，8-死门
     * 策划跟客户端约定
     */
    final int id;

    /**
     * 权重
     */
    final int weight;

    /**
     * true表示吉门
     */
    final boolean isLucky;

    /**
     * tips名称
     */
    final String name;

    /**
     * tips描述
     */
    final String desc;

    /**
     * tips图标
     */
    final String icon;

    /**
     * 品质
     */
    final Quality quality;

    /**
     * 随机掉落组包
     */
    final PlunderGroup group;

    DivineData(ObjectParser p, PlunderGroups groups){

        id = p.getIntKey("id");

        weight = p.getIntKey("weight");
        checkArgument(weight > 0, "%s 配置的权重<=0", this);

        isLucky = p.getBooleanKey("is_lucky");

        name = p.getKey("name");
        checkArgument(!name.isEmpty(), "%s 没有配置Tips名称", this);

        desc = p.getKey("desc");
        checkArgument(!desc.isEmpty(), "%s 没有配置Tips描述", this);

        icon = p.getKey("icon");
        checkArgument(!icon.isEmpty(), "%s 没有配置Tips的Icon", this);

        int intQuality = p.getIntKey("quality");
        quality = checkNotNull(Quality.valueOf(intQuality), "%s 配置的品质无效，%s",
                this, intQuality);

        String groupName = p.getKey("plunder_group");
        group = checkNotNull(groups.get(groupName), "%s 配置的掉落组没找到", this);
    }

    public int getId(){
        return id;
    }

    public boolean isLucky(){
        return isLucky;
    }

    public Goods random(long ctime){
        return group.random(ctime);
    }

    public DivineProto encode(){
        DivineProto.Builder builder = DivineProto.newBuilder().setId(id)
                .setName(ByteString.copyFromUtf8(name))
                .setDesc(ByteString.copyFromUtf8(desc)).setIcon(icon)
                .setQuality(quality.getNumber());

        if (isLucky){
            builder.setIsLucky(isLucky);
        }

        return builder.build();
    }

    @Override
    public String toString(){
        return "知天命-" + id;
    }
}
