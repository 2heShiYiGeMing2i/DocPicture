package app.game.data.task;

import app.game.data.GameObjects;
import app.game.data.PrizeConfigs;
import app.game.data.QualityRelatedDatas;
import app.game.data.goods.GoodsDatas;
import app.game.data.scene.CollectObjects;
import app.game.data.scene.MonsterData;
import app.game.data.scene.MonsterDatas;
import app.game.data.scene.Npcs;
import app.game.data.scene.SceneData;
import app.game.data.scene.SceneDatas;
import app.protobuf.ConfigContent.TaskConfig;
import app.utils.VariableConfig;

import com.google.inject.Inject;
import com.google.protobuf.ByteString;
import com.mokylin.collection.IntHashMap;
import com.mokylin.collection.LeftIntPair;

public class TaskDatas{

    private final ChapterTaskDatas chapterTaskDatas;

    private final ChanceTaskDatas chanceTaskDatas;

    private final DailyTaskDatas dailyTaskDatas;

    private final GuildTaskDatas guildTaskDatas;

    @Inject
    TaskDatas(GameObjects go, GoodsDatas goodsDatas, MonsterDatas monsters,
            Npcs npcs, PrizeConfigs prizes, DailyTaskPrizes dailyTaskPrize,
            CollectObjects collectObjects, SceneDatas sceneDatas,
            QualityRelatedDatas relatedDatas, VariableConfig variableConfig){

        IntHashMap<MonsterData> monLevelMap = getMonsterLevelMap(monsters);

        chapterTaskDatas = new ChapterTaskDatas(go, npcs, goodsDatas, monsters,
                prizes, collectObjects, sceneDatas, monLevelMap);

        chanceTaskDatas = new ChanceTaskDatas(go, npcs, goodsDatas, monsters,
                prizes, collectObjects, sceneDatas, monLevelMap, relatedDatas);

        dailyTaskDatas = new DailyTaskDatas(go, npcs, goodsDatas, monsters,
                prizes, dailyTaskPrize, collectObjects, sceneDatas, monLevelMap);

        guildTaskDatas = new GuildTaskDatas(go, npcs, goodsDatas, monsters,
                prizes, collectObjects, sceneDatas, variableConfig, monLevelMap);
    }

    public ChapterTaskData getFirstChapterTask(){
        return chapterTaskDatas.getFirstChapterTask();
    }

    public int getMaxUseTaskId(){
        return chapterTaskDatas.maxUseTaskId;
    }

    public LeftIntPair<ByteString[]> getLastChapterTaskInfo(){
        return chapterTaskDatas.getLastChapterTaskInfo();
    }

    public ChapterTaskDatas getChapterTaskDatas(){
        return chapterTaskDatas;
    }

    public ChanceTaskDatas getChanceTaskDatas(){
        return chanceTaskDatas;
    }

    public DailyTaskDatas getDailyTaskDatas(){
        return dailyTaskDatas;
    }

    public GuildTaskDatas getGuildTaskDatas(){
        return guildTaskDatas;
    }

    public TaskConfig generateProto(QualityRelatedDatas relatedDatas){
        TaskConfig.Builder builder = TaskConfig.newBuilder();

        chapterTaskDatas.generateProto(builder);
        chanceTaskDatas.generateProto(builder, relatedDatas);
        dailyTaskDatas.generateProto(builder);
        guildTaskDatas.generateProto(builder);

        return builder.build();
    }

    private IntHashMap<MonsterData> getMonsterLevelMap(MonsterDatas monsters){
        IntHashMap<MonsterData> monLevelMap = new IntHashMap<>();
        for (MonsterData mon : monsters.all()){
            if (monLevelMap.get(mon.level) != null){
                continue;
            }

            if (mon.type != 0){
                continue;
            }

            SceneData sceneData = mon.getScene();
            if (sceneData == null || !sceneData.isNormalScene()){
                continue;
            }

            if (mon.level < sceneData.getCanEnterLevel()){
                // 英雄根本进不去这个场景
                continue;
            }

            monLevelMap.put(mon.level, mon);
        }

        MonsterData previous = null;
        for (int lv = 1; lv <= VariableConfig.HERO_MAX_LEVEL; lv++){
            MonsterData mon = monLevelMap.get(lv);
            if (mon == null){
                monLevelMap.put(lv, previous);
            } else{
                previous = mon;
            }
        }

        return monLevelMap;
    }

    static enum TaskType{
        CHAPTER(1), CHANCE(2), DAILY(3), GUILD(4);
        private final int intType;

        private TaskType(int type){
            this.intType = type;
        }

        public int getIntType(){
            return intType;
        }
    }
}
