package app.game.data.scene;

import static com.mokylin.sink.util.Preconditions.checkArgument;

import java.util.List;

import app.cluster.client.combat.scene.LocalPortalDungeonScene;
import app.cluster.combat.master.logic.scene.RemotePortalDungeonScene;
import app.game.data.GameObjects;
import app.game.data.PrizeConfigs;
import app.game.data.goods.GoodsDatas;
import app.game.entity.Hero;
import app.game.module.scene.IClusterLocalDungeonService;
import app.game.module.scene.IDungeonService;
import app.message.ISender;
import app.protobuf.ConfigContent.WuJueDungeonProto;
import app.protobuf.LogContent.LogEnum.SceneType;

import com.google.protobuf.ByteString;
import com.mokylin.sink.util.RandomNumber;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.parse.ObjectParser;

public class PortalDungeonSceneData extends GroupDungeonSceneData{

    /**
     * 传送门配置地址
     */
    private static final String PORTAL_LOCATION = GameObjects.PORTAL_SCENE_BASE_FOLDER
            + "portal.txt";

    /**
     * 先限制必须是8层
     */
    public static final int LEVEL_COUNT = 8;

    /**
     * 先限制每层必须有8个传送门
     */
    public static final int EACH_LEVEL_PORTAL_COUNT = 8;

    private final int dailyEnterLimit;

    /**
     * 每一层的中心坐标
     */
    private final int[] levelPos;

    private final PortalDungeonPortal[] portals;

    /**
     * 完成奖励. 每次完成都有. 通过每日可完成次数控制
     */
    private final GroupDungeonPrizeConfig prizeConfig;

    PortalDungeonSceneData(GameObjects go, ObjectParser p, BlockInfos blocks,
            MonsterDatas monsters, Scripts scripts, Plunders plunders, Ais ais,
            SceneTransportDatas transports, GoodsDatas goodsDatas,
            PlunderGroups groups, PrizeConfigs prizes,
            SceneRemoveObjectMsgCache removeMsgCache){
        super(go, p, blocks, monsters, scripts, plunders, ais, transports,
                removeMsgCache);

        this.dailyEnterLimit = p.getIntKey("daily_enter_limit");

        // --- 只能有一个怪, 而且是boss ---
        SceneMonsterData[] mons = getSingleLifeMonsterDatas();
        checkArgument(mons.length == 1, "无绝神阵必须且只能配一个怪. 现在有%s个", mons.length);
        checkArgument(mons[0].getMonsterData().isBoss(), "无绝神阵里必须有一个boss");

        // --- 奖励 ---
        this.prizeConfig = new GroupDungeonPrizeConfig(this, p, prizes, groups);

        // --- 每层的中心点 ---
        int[] levelPosX = p.getIntKeyArray("level_pos_x");
        int[] levelPosY = p.getIntKeyArray("level_pos_y");

        checkArgument(levelPosX.length == LEVEL_COUNT,
                "无绝神阵的level_pos_x必须有8个. 现在是%s个", levelPosX.length);
        checkArgument(levelPosY.length == LEVEL_COUNT,
                "无绝神阵的level_pos_y必须有8个. 现在是%s个", levelPosY.length);

        levelPos = new int[LEVEL_COUNT];
        for (int i = 0; i < LEVEL_COUNT; i++){
            int x = levelPosX[i];
            int y = levelPosY[i];
            checkArgument(blockInfo.isWalkable(x, y),
                    "无绝神阵的第%s层中心点不可走: <%s, %s>", i + 1, x, y);
            levelPos[i] = Utils.short2Int(x, y);
        }

        // --- 每层的传送门 ---
        List<ObjectParser> portalList = go.loadFile(PORTAL_LOCATION);
        int portalCount = (LEVEL_COUNT - 1) * EACH_LEVEL_PORTAL_COUNT;
        checkArgument(portalList.size() == portalCount,
                "无绝神阵必须配置%s 个传送门, 现在有%s 个", portalCount, portalList.size());

        portals = new PortalDungeonPortal[portalCount];
        int index = 0;
        for (int level = 1; level <= (LEVEL_COUNT - 1); level++){ // 最后一层没有传送门, 所以-1
            for (int i = 0; i < EACH_LEVEL_PORTAL_COUNT; i++){
                int id = index++;
                PortalDungeonPortal portal = new PortalDungeonPortal(id, i,
                        portalList.get(id));
                checkArgument(portal.level == level,
                        "无绝神阵的传送门一定要从第一层开始一整层一整层地配, 每层要%s个传送门. %s",
                        EACH_LEVEL_PORTAL_COUNT, PORTAL_LOCATION);
                portals[id] = portal;
                checkArgument(
                        blockInfo.isWalkable(portal.sourceX, portal.sourceY),
                        "无绝神阵传送门所在点不可走: 第%s层 <%s, %s>", portal.level,
                        portal.sourceX, portal.sourceY);
            }
        }

        // --- 规定死亡复活点, 如果在副本中, 一定要是最后一层的进入点 ---
        if (!reliveOutOfDungeon){
            checkArgument(deathReturnX == levelPosX[levelPosX.length - 1]
                    && deathReturnY == levelPosY[levelPosY.length - 1],
                    "无绝神阵是复活在副本内, 死亡复活坐标必须和最后一层的中心坐标相同");
        }

        // --- 进入点一定要是第一层的进入点 ---
        checkArgument(defaultX == levelPosX[0] && defaultY == levelPosY[0],
                "无绝神阵的进入点必须和第一层的中心点相同");
    }

    /**
     * 获取某层的中心点
     * @param level 从1开始
     * @return
     */
    public int getEnterPosByLevel(int level){
        return levelPos[level - 1];
    }

    public int getTotalPortalCount(){
        return portals.length;
    }

    public int[] newRandomPortalPos(){
        int[] result = new int[LEVEL_COUNT - 1]; // 最后一层没有
        for (int i = 0; i < result.length; i++){
            result[i] = RandomNumber.getRate(EACH_LEVEL_PORTAL_COUNT);
        }
        return result;
    }

    public PortalDungeonPortal getPortal(int index){
        if (index < 0 || index >= portals.length){
            return null;
        }

        return portals[index];
    }

    /**
     * 获得传送门
     * @param level 层数. 从1开始, 到LEVEL_COUNT - 1
     * @param count 这一层中的序号. 从0开始, 到EACH_LEVEL_COUNT
     * @return
     */
    public PortalDungeonPortal getPortal(int level, int count){
        if (level <= 0 || level >= LEVEL_COUNT){// 最后一层也是没有传送门的
            return null;
        }

        if (count < 0 || count >= EACH_LEVEL_PORTAL_COUNT){
            return null;
        }
        return portals[(level - 1) * EACH_LEVEL_PORTAL_COUNT + count];
    }

    @Override
    public boolean canHeroEnterToday(Hero hero){
        return dailyEnterLimit == 0
                || dailyEnterLimit > hero.getWuJueTodayEnteredTimes();
    }

    @Override
    public GroupDungeonPrizeConfig getPrizeConfig(){
        return prizeConfig;
    }

    @Override
    public LocalPortalDungeonScene newLocalClusterScene(int uuid,
            IClusterLocalDungeonService dungeonService, ISender combatClient,
            long heroID){
        return new LocalPortalDungeonScene(this, uuid, dungeonService,
                combatClient, heroID);
    }

    @Override
    public RemotePortalDungeonScene newRemoteClusterScene(int uuid,
            IDungeonService dungeonService, long creator, ISender worker){
        return new RemotePortalDungeonScene(this, uuid, dungeonService,
                creator, worker);
    }

    @Override
    public int getIntType(){
        return SceneType.WU_JUE_DUNGEON.getNumber();
    }

    @Override
    public boolean isSeeAllInScene(){
        return false;
    }

    public WuJueDungeonProto generateProto(){
        WuJueDungeonProto.Builder builder = WuJueDungeonProto.newBuilder();
        builder.setSceneId(id).setMap(blockName)
                .setName(ByteString.copyFrom(nameBytes)).setSound(sound);
        if (requiredLevel > 1){
            builder.setRequiredLevel(requiredLevel);
        }
        if (isHeroLevelProtect){
            builder.setIsHeroLevelProtect(true);
        }
        if (isNewHeroProtect){
            builder.setIsNewHeroProtect(true);
        }
        if (isDeathProtect){
            builder.setIsDeathProtect(true);
        }
        if (isNightAutoProtect){
            builder.setIsNightAutoProtect(true);
        }
        if (isJumpLimit){
            builder.setIsJumpLimit(true);
        }
        if (isMountLimit){
            builder.setIsMountLimit(true);
        }

        if (poet != null){
            String tp = poet.trim();
            if (tp.length() > 0){
                builder.setPoet(ByteString.copyFromUtf8(tp));
            }
        }
        if (fixedPkMode != null){
            builder.setFixedPkMode(fixedPkMode.getIntMode());
        }

        if (reliveOutOfDungeon){
            builder.setIsDeathReturnTown(true);
        }

        builder.setMinHeroCount(minHeroCount).setMaxHeroCount(maxHeroCount)
                .setRecommendedFightAmount(recommendedFightAmount)
                .setRequiredLevel(requiredLevel);

        builder.setDailyEnterLimit(dailyEnterLimit);
        builder.setGroupDungeonPrize(prizeConfig.encode());

        for (PortalDungeonPortal p : portals){
            builder.addPortalPosX(p.sourceX).addPortalPosY(p.sourceY);
        }

        return builder.build();
    }
}
