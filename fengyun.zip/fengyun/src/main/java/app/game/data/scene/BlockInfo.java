package app.game.data.scene;

import static com.mokylin.sink.util.Preconditions.checkArgument;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.protobuf.MapDataContent.Layer;
import app.protobuf.MapDataContent.Layer.LayerType;
import app.protobuf.MapDataContent.MapData;

import com.google.protobuf.InvalidProtocolBufferException;
import com.mokylin.collection.IntArrayList;
import com.mokylin.sink.util.ByteTable;
import com.mokylin.sink.util.OffHeapByteTable;
import com.mokylin.sink.util.RandomNumber;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.path.GodPathFinder;
import com.mokylin.sink.util.path.LinePathFinder;
import com.mokylin.sink.util.path.PathContext;

public class BlockInfo implements PathContext{

    private static final Logger logger = LoggerFactory
            .getLogger(BlockInfo.class);

    public final String name;

    public final int numBlocksX;

    public final int numBlocksY;

    private final ByteTable walkableTable;

    private final ByteTable surroundingWalkableTable;

    private final ByteTable pkableTable;

    private final ByteTable exp10Table;

    private final ByteTable exp20Table;

    private static int globalMaxWidth;

    private static int globalMaxHeight;

    public BlockInfo(String name, byte[] data)
            throws InvalidProtocolBufferException{
        this.name = name;

        byte[] uncompressedData = Utils.zlibUncompress(data);

        MapData mapData = MapData.parseFrom(uncompressedData);

        numBlocksX = mapData.getNumBlocksX();
        numBlocksY = mapData.getNumBlocksY();

        walkableTable = getLayerData(mapData, LayerType.MOVE, (byte) 1);
        surroundingWalkableTable = GodPathFinder
                .buildSurroundingWalkableTable(this);

        pkableTable = getLayerData(mapData, LayerType.PK_ABLE, (byte) 0);

        exp10Table = getLayerData(mapData, LayerType.EXP_10X, (byte) 0);
        exp20Table = getLayerData(mapData, LayerType.EXP_20X, (byte) 0);

        checkArgument(numBlocksX * numBlocksY <= 65534,
                "地图块 宽度x高度 不能超过 %s. %s %s x %s = %s", 65534, name, numBlocksX,
                numBlocksY, numBlocksX * numBlocksY);
    }

    static void setGlobalMaxSize(int width, int height){
        globalMaxWidth = width;
        globalMaxHeight = height;
    }

    private static final ThreadLocal<LinePathFinder> localFinder = new ThreadLocal<LinePathFinder>(){
        @Override
        protected LinePathFinder initialValue(){
            return new LinePathFinder(globalMaxWidth, globalMaxHeight);
        }
    };

    public static LinePathFinder current(){
        return localFinder.get();
    }

    public IntArrayList searchPath(int startX, int startY, int endX, int endY){
        assert !(startX == endX && startY == endY);
        return current().searchPath(startX, startY, endX, endY, true, this);
    }

    private static final int retryTime = 3;

    public int getRandomMovablePointAroundPoint(int x, int y, int range){
        int i = Math.max(x - range, 0);
        int j = Math.max(y - range, 0);
        int k = Math.min(x + range + 1, getWidth());
        int l = Math.min(y + range + 1, getHeight());

        for (int t = 0; t < retryTime; t++){
            int destX = i + RandomNumber.getRate(k - i);
            int destY = j + RandomNumber.getRate(l - j);
            if (isWalkable(destX, destY)){
                return Utils.short2Int(destX, destY);
            }
        }
        return Utils.short2Int(x, y);
    }

    @Override
    public int getWidth(){
        return numBlocksX;
    }

    @Override
    public int getHeight(){
        return numBlocksY;
    }

    @Override
    public byte getSurroundWalkableGrid(int x, int y){
        return surroundingWalkableTable.get(x, y);
    }

    @Override
    public boolean isWalkable(int x, int y){
        return walkableTable.get(x, y) == 0; // 设置了表示不可走
    }

    public boolean isSafe(int x, int y){
        return isWalkable(x, y) && !isPkable(x, y);
    }

    public boolean isExp20X(int x, int y){
        return exp20Table.get(x, y) == 1;
    }

    public boolean isExp10X(int x, int y){
        return exp10Table.get(x, y) == 1;
    }

    /**
     * 坐标是否可pk
     * 
     * @param x
     * @param y
     * @return
     */
    public boolean isPkable(int x, int y){
        return pkableTable.get(x, y) != 0; // 设置了表示可pk
    }

    // ----- initialize -------
    private OffHeapByteTable getLayerData(MapData mapData, LayerType type,
            byte outOfBoundDefault){
        Layer layer = getLayer(mapData, type);
        if (layer == null){
            // 不存在, 表示所有都没有设置
            logger.debug("{} 地图的 {} 层没找到, 当做全都是空", name, type);
            return new OffHeapByteTable(numBlocksX, numBlocksY);
        }

        return parseData(layer.getData().toByteArray(), outOfBoundDefault);
    }

    private static Layer getLayer(MapData mapData, LayerType type){
        for (Layer layer : mapData.getLayersList()){
            if (layer.getLayerType() == type){
                return layer;
            }
        }
        return null;
    }

    private OffHeapByteTable parseData(byte[] data, byte outOfBoundDefault){
        OffHeapByteTable result = new OffHeapByteTable(numBlocksX, numBlocksY,
                outOfBoundDefault);

        for (int x = 0; x < numBlocksX; x++){
            for (int y = 0; y < numBlocksY; y++){
                int index = getIndex(x, y);
                byte b = data[index / 8];
                int pos = index % 8;
                boolean isSet = ((b >>> pos) & 1) == 1;
                result.set(x, y, isSet ? (byte) 1 : 0);
            }
        }

        return result;
    }

    private int getIndex(int x, int y){
        return numBlocksX * y + x;
    }
}
