package app.game.data.scene;

import static com.mokylin.sink.util.Preconditions.checkArgument;

import java.util.List;
import java.util.Map;

import app.game.data.GameObjects;
import app.game.data.Vips;
import app.game.data.goods.GoodsDatas;

import com.google.common.collect.Maps;
import com.google.inject.Inject;
import com.mokylin.sink.util.parse.ObjectParser;

public class Plunders{

    private static final String LOCATION = GameObjects.SCENE_BASE_FOLDER
            + "plunder.txt";

    private final Map<String, Plunder> plunderMap;

    @Inject
    Plunders(GameObjects go, GoodsDatas goodsDatas, Vips vips,
            PlunderGroups groups){

        List<ObjectParser> data = go.loadFile(LOCATION);
        plunderMap = Maps.newHashMapWithExpectedSize(data.size());
        for (ObjectParser p : data){
            Plunder plunder = new Plunder(p, vips.getMaxVipLevel(), goodsDatas,
                    groups);

            checkArgument(plunderMap.put(plunder.name, plunder) == null,
                    "%s 名称重复了", plunder);
        }

        goodsDatas.initPlunders(this);
    }

    public Plunder get(String name){
        return plunderMap.get(name);
    }
}
