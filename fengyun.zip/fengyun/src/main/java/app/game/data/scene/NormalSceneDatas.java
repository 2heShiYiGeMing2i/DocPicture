package app.game.data.scene;

import static com.mokylin.sink.util.Preconditions.checkNotNull;

import java.util.Collection;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.data.GameObjects;
import app.game.data.PrizeConfigs;
import app.game.data.goods.GoodsDatas;
import app.utils.VariableConfig;

import com.google.inject.Inject;
import com.mokylin.collection.IntHashMap;
import com.mokylin.sink.util.parse.ObjectParser;

public class NormalSceneDatas{
    private static final Logger logger = LoggerFactory
            .getLogger(NormalSceneDatas.class);

    public static final String LOCATION = GameObjects.SCENE_BASE_FOLDER
            + "scene.txt";

    private final IntHashMap<NormalSceneData> normalSceneMap;

    @Inject
    NormalSceneDatas(GameObjects go, BlockInfos blocks, MonsterDatas monsters,
            Scripts scripts, Plunders plunders, Ais ais,
            SceneTransportDatas transports, GoodsDatas goodsDatas,
            VariableConfig variableConfig,
            SceneRemoveObjectMsgCache removeMsgCache, PrizeConfigs prizeConfigs){

        logger.debug("loading normal scenes");
        // 加载普通场景
        List<ObjectParser> data = go.loadFile(LOCATION);

        normalSceneMap = new IntHashMap<>(data.size());
        for (ObjectParser p : data){
            NormalSceneData scene = new NormalSceneData(go, p, blocks,
                    monsters, scripts, plunders, ais, transports,
                    removeMsgCache, prizeConfigs);
            normalSceneMap.put(scene.id, scene);
        }

        // 设置所有普通场景的复活场景
        for (NormalSceneData scene : normalSceneMap.values()){
            NormalSceneData deathReturnScene = checkNotNull(
                    normalSceneMap.get(scene.deathReturnSceneID),
                    "没有找到普通场景 %s的普通复活场景 %s. ", scene, scene.deathReturnSceneID);
            scene.setDeathScene(deathReturnScene);

            scene.setDeathPoints(scene.getDeathSceneData());
        }

        // 检查所有传送门的终点
        for (NormalSceneData scene : normalSceneMap.values()){
            for (SceneTransportData t : scene.transports){
                NormalSceneData destScene = checkNotNull(
                        normalSceneMap.get(t.destSceneID),
                        "没有找到 %s 场景中的传送门的目标场景 %s", scene, t.destSceneID);

                t.setDestSceneData(destScene); // 里面检查了终点附近有没有可走的点了
            }
        }

        goodsDatas.initDestData(this);
    }

    public NormalSceneData get(int sceneID){
        return normalSceneMap.get(sceneID);
    }

    void putAll(IntHashMap<SceneData> map){
        for (NormalSceneData sceneData : normalSceneMap.values()){
            map.putUnique(sceneData.id, sceneData);
        }
    }

    public Collection<NormalSceneData> getAll(){
        return normalSceneMap.values();
    }
}
