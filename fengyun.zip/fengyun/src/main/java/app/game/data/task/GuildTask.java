package app.game.data.task;

import app.game.data.task.TaskTarget.TaskTargetProgress;
import app.protobuf.HeroServerContent.GuildTaskServerProto;
import app.protobuf.TaskContent.GuildTaskProto;

/**
 * @author Liwei
 *
 */
public class GuildTask{

    final int taskId;

    final GuildTaskData data;

    final TaskTargetProgress[] progress;

    GuildTask(int taskId, GuildTaskData data, TaskTargetProgress[] progress){
        super();
        this.taskId = taskId;
        this.data = data;
        this.progress = progress;
    }

    public int getIntType(){
        return data.getIntType();
    }

    public GuildTaskData getData(){
        return data;
    }

    public int getRealTaskId(){
        return data.id;
    }

    public int getTaskId(){
        return taskId;
    }

    public TaskTargetProgress[] getProgress(){
        return progress;
    }

    public boolean isAllProgressCompleted(){
        for (TaskTargetProgress p : progress){
            if (!p.isCompleted())
                return false;
        }

        return true;
    }

    public GuildTaskProto encode4Client(int round){
        return data.encode4Client(round, taskId, progress);
    }

    GuildTaskServerProto encode(){
        GuildTaskServerProto.Builder builder = GuildTaskServerProto
                .newBuilder();

        builder.setGuildTaskId(data.id);
        for (TaskTargetProgress p : progress){
            builder.addProgress(p.progress);
        }

        return builder.build();
    }

    static GuildTask decode(int taskId, GuildTaskData data,
            GuildTaskServerProto proto){
        return new GuildTask(taskId, data, data.taskData.newProgress(taskId,
                proto.getProgressList()));
    }
}
