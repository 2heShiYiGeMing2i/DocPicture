package app.game.data;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

import app.protobuf.SpriteStatContent.SpriteStatProto;
import app.protobuf.SpriteStatContent.StatType;

import com.mokylin.sink.util.parse.ObjectParser;

public class SpriteStat extends GameObject{

    public static final SpriteStat[] EMPTY_ARRAY = new SpriteStat[0];

    public static final SpriteStat EMPTY_STAT = new SpriteStat(0, 0, 0, 0, 0,
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, true);

    /**
     * 最大血量
     */
    public final int maxLife;

    /**
     * 最大体力
     */
    public final int maxStamina;

    /**
     * 攻击
     */
    public final int attack;

    /**
     * 防御
     */
    public final int defence;

    /**
     * 暴击值
     */
    public final int crit;

    /**
     * 韧性值(降低被暴击几率)
     */
    public final int antiCrit;

    /**
     * 命中值
     */
    public final int hit;

    /**
     * 闪避值
     */
    public final int dodge;

    /**
     * 移动速度
     */
    public final int moveSpeed;

    final float maxLifePer;

    final float maxStaminaPer;

    final float attackPer;

    final float defencePer;

    final float critPer;

    final float antiCritPer;

    final float hitPer;

    final float dodgePer;

    final float moveSpeedPer;

    final boolean isZeroPer;

    public SpriteStat(ObjectParser p){
        super(p);
        maxLife = p.getIntKey("max_life");
        maxStamina = p.getIntKey("stamina");
        attack = p.getIntKey("attack");
        defence = p.getIntKey("defence");
        crit = p.getIntKey("crit");
        antiCrit = p.getIntKey("anti_crit");
        hit = p.getIntKey("hit");
        dodge = p.getIntKey("dodge");
        moveSpeed = p.getIntKey("move_speed");

        maxLifePer = p.getIntKey("max_life_per") / 100f;
        maxStaminaPer = p.getIntKey("stamina_per") / 100f;
        attackPer = p.getIntKey("attack_per") / 100f;
        defencePer = p.getIntKey("defence_per") / 100f;
        critPer = p.getIntKey("crit_per") / 100f;
        antiCritPer = p.getIntKey("anti_crit_per") / 100f;
        hitPer = p.getIntKey("hit_per") / 100f;
        dodgePer = p.getIntKey("dodge_per") / 100f;
        moveSpeedPer = p.getIntKey("move_speed_per") / 100f;

        isZeroPer = maxLifePer == 0 && maxStaminaPer == 0 && attackPer == 0
                && defencePer == 0 && critPer == 0 && antiCritPer == 0
                && hitPer == 0 && dodgePer == 0 && moveSpeedPer == 0;
    }

    public SpriteStat(int maxLife, int stamina, int attack, int defence,
            int crit, int antiCrit, int hit, int dodge, int moveSpeed,
            float maxLifePer, float staminaPer, float attackPer,
            float defencePer, float critPer, float antiCritPer, float hitPer,
            float dodgePer, float moveSpeedPer, boolean isSureZeroPer){
        this.maxLife = maxLife;
        this.maxStamina = stamina;
        this.attack = attack;
        this.defence = defence;
        this.crit = crit;
        this.antiCrit = antiCrit;
        this.hit = hit;
        this.dodge = dodge;
        this.moveSpeed = moveSpeed;

        if (isSureZeroPer){
            this.maxLifePer = 0;
            this.maxStaminaPer = 0;
            this.attackPer = 0;
            this.defencePer = 0;
            this.critPer = 0;
            this.antiCritPer = 0;
            this.hitPer = 0;
            this.dodgePer = 0;
            this.moveSpeedPer = 0;
            isZeroPer = true;
        } else{
            this.maxLifePer = maxLifePer;
            this.maxStaminaPer = staminaPer;
            this.attackPer = attackPer;
            this.defencePer = defencePer;
            this.critPer = critPer;
            this.antiCritPer = antiCritPer;
            this.hitPer = hitPer;
            this.dodgePer = dodgePer;
            this.moveSpeedPer = moveSpeedPer;

            isZeroPer = maxLifePer == 0 && staminaPer == 0 && attackPer == 0
                    && defencePer == 0 && critPer == 0 && antiCritPer == 0
                    && hitPer == 0 && dodgePer == 0 && moveSpeedPer == 0;
        }
    }

    public SpriteStat multiply(int times){
        if (times == 0){
            return EMPTY_STAT;
        }
        if (times == 1){
            return this;
        }

        if (isZeroPer){
            return new SpriteStat(maxLife * times, maxStamina * times, attack
                    * times, defence * times, crit * times, antiCrit * times,
                    hit * times, dodge * times, moveSpeed * times, 0, 0, 0, 0,
                    0, 0, 0, 0, 0, true);
        }

        return new SpriteStat(maxLife * times, maxStamina * times, attack
                * times, defence * times, crit * times, antiCrit * times, hit
                * times, dodge * times, moveSpeed * times, maxLifePer * times,
                maxStaminaPer * times, attackPer * times, defencePer * times,
                critPer * times, antiCritPer * times, hitPer * times, dodgePer
                        * times, moveSpeedPer * times, false);
    }

    public SpriteStat add(SingleSpriteStat toAdd){
        return add(toAdd.getStatType(), toAdd.getAmount());
    }

    public SpriteStat add(StatType statType, int amount){

        if (amount == 0){
            return this;
        }

        int maxLife = this.maxLife;
        int maxStamina = this.maxStamina;
        int attack = this.attack;
        int defence = this.defence;
        int crit = this.crit;
        int antiCrit = this.antiCrit;
        int hit = this.hit;
        int dodge = this.dodge;
        int moveSpeed = this.moveSpeed;

        float maxLifePer = this.maxLifePer;
        float staminaPer = this.maxStaminaPer;
        float attackPer = this.attackPer;
        float defencePer = this.defencePer;
        float critPer = this.critPer;
        float antiCritPer = this.antiCritPer;
        float hitPer = this.hitPer;
        float dodgePer = this.dodgePer;
        float moveSpeedPer = this.moveSpeedPer;
        boolean isZeroPer = this.isZeroPer;

        switch (statType){
            case MAX_LIFE:{
                maxLife += amount;
                break;
            }
            case MAX_STAMINA:{
                maxStamina += amount;
                break;
            }
            case ATTACK:{
                attack += amount;
                break;
            }
            case DEFENCE:{
                defence += amount;
                break;
            }
            case CRIT:{
                crit += amount;
                break;
            }
            case ANTI_CRIT:{
                antiCrit += amount;
                break;
            }
            case HIT:{
                hit += amount;
                break;
            }
            case DODGE:{
                dodge += amount;
                break;
            }
            case MOVE_SPEED:{
                moveSpeed += amount;
                break;
            }
        }

        return new SpriteStat(maxLife, maxStamina, attack, defence, crit,
                antiCrit, hit, dodge, moveSpeed, maxLifePer, staminaPer,
                attackPer, defencePer, critPer, antiCritPer, hitPer, dodgePer,
                moveSpeedPer, isZeroPer);
    }

    public SpriteStat remove(SingleSpriteStat toRemove){

        if (toRemove.amount == 0){
            return this;
        }

        int maxLife = this.maxLife;
        int maxStamina = this.maxStamina;
        int attack = this.attack;
        int defence = this.defence;
        int crit = this.crit;
        int antiCrit = this.antiCrit;
        int hit = this.hit;
        int dodge = this.dodge;
        int moveSpeed = this.moveSpeed;

        float maxLifePer = this.maxLifePer;
        float staminaPer = this.maxStaminaPer;
        float attackPer = this.attackPer;
        float defencePer = this.defencePer;
        float critPer = this.critPer;
        float antiCritPer = this.antiCritPer;
        float hitPer = this.hitPer;
        float dodgePer = this.dodgePer;
        float moveSpeedPer = this.moveSpeedPer;
        boolean isZeroPer = this.isZeroPer;

        switch (toRemove.statType){
            case MAX_LIFE:{
                maxLife -= toRemove.amount;
                break;
            }
            case MAX_STAMINA:{
                maxStamina -= toRemove.amount;
                break;
            }
            case ATTACK:{
                attack -= toRemove.amount;
                break;
            }
            case DEFENCE:{
                defence -= toRemove.amount;
                break;
            }
            case CRIT:{
                crit -= toRemove.amount;
                break;
            }
            case ANTI_CRIT:{
                antiCrit -= toRemove.amount;
                break;
            }
            case HIT:{
                hit -= toRemove.amount;
                break;
            }
            case DODGE:{
                dodge -= toRemove.amount;
                break;
            }
            case MOVE_SPEED:{
                moveSpeed -= toRemove.amount;
                break;
            }
        }

        return new SpriteStat(maxLife, maxStamina, attack, defence, crit,
                antiCrit, hit, dodge, moveSpeed, maxLifePer, staminaPer,
                attackPer, defencePer, critPer, antiCritPer, hitPer, dodgePer,
                moveSpeedPer, isZeroPer);
    }

    public static SpriteStat withMaxLife(int maxLife){
        return new SpriteStat(maxLife, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                0, 0, 0, 0, true);
    }

    public static SpriteStat decode(SpriteStatProto proto){
        return new SpriteStat(proto.getMaxLife(), proto.getMaxStamina(),
                proto.getAttack(), proto.getDefence(), proto.getCrit(),
                proto.getAntiCrit(), proto.getHit(), proto.getDodge(),
                proto.getMoveSpeed(), 0, 0, 0, 0, 0, 0, 0, 0, 0, true);
    }

    public SpriteStatProto encode(){

        SpriteStatProto.Builder builder = SpriteStatProto.newBuilder();

        if (maxLife != 0){
            builder.setMaxLife(maxLife);
        }

        if (maxStamina != 0){
            builder.setMaxStamina(maxStamina);
        }

        if (attack != 0){
            builder.setAttack(attack);
        }

        if (defence != 0){
            builder.setDefence(defence);
        }

        if (crit != 0){
            builder.setCrit(crit);
        }

        if (antiCrit != 0){
            builder.setAntiCrit(antiCrit);
        }

        if (hit != 0){
            builder.setHit(hit);
        }

        if (dodge != 0){
            builder.setDodge(dodge);
        }

        if (moveSpeed != 0){
            builder.setMoveSpeed(moveSpeed);
        }

        return builder.build();
    }

    public SpriteStatProto encodePercent(){

        SpriteStatProto.Builder builder = SpriteStatProto.newBuilder();

        if (maxLifePer != 0){
            builder.setMaxLife((int) (maxLifePer * 100));
        }

        if (maxStaminaPer != 0){
            builder.setMaxStamina((int) (maxStaminaPer * 100));
        }

        if (attackPer != 0){
            builder.setAttack((int) (attackPer * 100));
        }

        if (defencePer != 0){
            builder.setDefence((int) (defencePer * 100));
        }

        if (critPer != 0){
            builder.setCrit((int) (critPer * 100));
        }

        if (antiCritPer != 0){
            builder.setAntiCrit((int) (antiCritPer * 100));
        }

        if (hitPer != 0){
            builder.setHit((int) (hitPer * 100));
        }

        if (dodgePer != 0){
            builder.setDodge((int) (dodgePer * 100));
        }

        if (moveSpeedPer != 0){
            builder.setMoveSpeed((int) (moveSpeedPer * 100));
        }

        return builder.build();
    }

    public SpriteStat addLife(int amount){
        if (amount == 0){
            return this;
        }

        if (isZeroPer){
            return new SpriteStat(maxLife + amount, maxStamina, attack,
                    defence, crit, antiCrit, hit, dodge, moveSpeed, 0, 0, 0, 0,
                    0, 0, 0, 0, 0, true);
        }

        return new SpriteStat(maxLife + amount, maxStamina, attack, defence,
                crit, antiCrit, hit, dodge, moveSpeed, maxLifePer,
                maxStaminaPer, attackPer, defencePer, critPer, antiCritPer,
                hitPer, dodgePer, moveSpeedPer, false);
    }

    public SpriteStat add(SpriteStat toAdd){
        if (toAdd == EMPTY_STAT){
            return this;
        }

        if (isZeroPer && toAdd.isZeroPer){
            return new SpriteStat(maxLife + toAdd.maxLife, maxStamina
                    + toAdd.maxStamina, attack + toAdd.attack, defence
                    + toAdd.defence, crit + toAdd.crit, antiCrit
                    + toAdd.antiCrit, hit + toAdd.hit, dodge + toAdd.dodge,
                    moveSpeed + toAdd.moveSpeed, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                    true);
        }

        return new SpriteStat(maxLife + toAdd.maxLife, maxStamina
                + toAdd.maxStamina, attack + toAdd.attack, defence
                + toAdd.defence, crit + toAdd.crit, antiCrit + toAdd.antiCrit,
                hit + toAdd.hit, dodge + toAdd.dodge, moveSpeed
                        + toAdd.moveSpeed, maxLifePer + toAdd.maxLifePer,
                maxStaminaPer + toAdd.maxStaminaPer, attackPer
                        + toAdd.attackPer, defencePer + toAdd.defencePer,
                critPer + toAdd.critPer, antiCritPer + toAdd.antiCritPer,
                hitPer + toAdd.hitPer, dodgePer + toAdd.dodgePer, moveSpeedPer
                        + toAdd.moveSpeedPer, false);
    }

    public SpriteStat add(SpriteStat toAdd, int precent){
        return add(toAdd, precent / 100f);
    }

    public SpriteStat add(SpriteStat toAdd, float amount){
        if (amount == 0){
            return EMPTY_STAT;
        } else if (amount == 1){
            return add(toAdd);
        } else if (toAdd == EMPTY_STAT){
            return this;
        }

        if (isZeroPer && toAdd.isZeroPer){
            return new SpriteStat(maxLife + (int) (toAdd.maxLife * amount),
                    maxStamina + (int) (toAdd.maxStamina * amount), attack
                            + (int) (toAdd.attack * amount), defence
                            + (int) (toAdd.defence * amount), crit
                            + (int) (toAdd.crit * amount), antiCrit
                            + (int) (toAdd.antiCrit * amount), hit
                            + (int) (toAdd.hit * amount), dodge
                            + (int) (toAdd.dodge * amount), moveSpeed
                            + (int) (toAdd.moveSpeed * amount), 0, 0, 0, 0, 0,
                    0, 0, 0, 0, true);
        }

        return new SpriteStat(maxLife + (int) (toAdd.maxLife * amount),
                maxStamina + (int) (toAdd.maxStamina * amount), attack
                        + (int) (toAdd.attack * amount), defence
                        + (int) (toAdd.defence * amount), crit
                        + (int) (toAdd.crit * amount), antiCrit
                        + (int) (toAdd.antiCrit * amount), hit
                        + (int) (toAdd.hit * amount), dodge
                        + (int) (toAdd.dodge * amount), moveSpeed
                        + (int) (toAdd.moveSpeed * amount), maxLifePer
                        + (int) (toAdd.maxLifePer * amount), maxStaminaPer
                        + (int) (toAdd.maxStaminaPer * amount), attackPer
                        + (int) (toAdd.attackPer * amount), defencePer
                        + (int) (toAdd.defencePer * amount), critPer
                        + (int) (toAdd.critPer * amount), antiCritPer
                        + (int) (toAdd.antiCritPer * amount), hitPer
                        + (int) (toAdd.hitPer * amount), dodgePer
                        + (int) (toAdd.dodgePer * amount), moveSpeedPer
                        + (int) (toAdd.moveSpeedPer * amount), false);
    }

    public SpriteStat remove(SpriteStat toAdd){
        if (toAdd == EMPTY_STAT){
            return this;
        }

        if (isZeroPer && toAdd.isZeroPer){
            return new SpriteStat(maxLife - toAdd.maxLife, maxStamina
                    - toAdd.maxStamina, attack - toAdd.attack, defence
                    - toAdd.defence, crit - toAdd.crit, antiCrit
                    - toAdd.antiCrit, hit - toAdd.hit, dodge - toAdd.dodge,
                    moveSpeed - toAdd.moveSpeed, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                    true);
        }
        return new SpriteStat(maxLife - toAdd.maxLife, maxStamina
                - toAdd.maxStamina, attack - toAdd.attack, defence
                - toAdd.defence, crit - toAdd.crit, antiCrit - toAdd.antiCrit,
                hit - toAdd.hit, dodge - toAdd.dodge, moveSpeed
                        - toAdd.moveSpeed, maxLifePer - toAdd.maxLifePer,
                maxStaminaPer - toAdd.maxStaminaPer, attackPer
                        - toAdd.attackPer, defencePer - toAdd.defencePer,
                critPer - toAdd.critPer, antiCritPer - toAdd.antiCritPer,
                hitPer - toAdd.hitPer, dodgePer - toAdd.dodgePer, moveSpeedPer
                        - toAdd.moveSpeedPer, false);
    }

    public SpriteStat multiple(float amount){
        if (amount == 0){
            return EMPTY_STAT;
        } else if (amount == 1){
            return this;
        }

        if (isZeroPer){
            return new SpriteStat((int) (maxLife * amount),
                    (int) (maxStamina * amount), (int) (attack * amount),
                    (int) (defence * amount), (int) (crit * amount),
                    (int) (antiCrit * amount), (int) (hit * amount),
                    (int) (dodge * amount), (int) (moveSpeed * amount), 0, 0,
                    0, 0, 0, 0, 0, 0, 0, true);
        }

        return new SpriteStat((int) (maxLife * amount),
                (int) (maxStamina * amount), (int) (attack * amount),
                (int) (defence * amount), (int) (crit * amount),
                (int) (antiCrit * amount), (int) (hit * amount),
                (int) (dodge * amount), (int) (moveSpeed * amount), maxLifePer
                        * amount, maxStaminaPer * amount, attackPer * amount,
                defencePer * amount, critPer * amount, antiCritPer * amount,
                hitPer * amount, dodgePer * amount, moveSpeedPer * amount,
                false);
    }

    public SpriteStat calculateTotalStat(SpriteStat toAdd){
        if (isZeroPer){
            if (toAdd == EMPTY_STAT){
                return this;
            }

            if (toAdd.isZeroPer){
                return new SpriteStat(maxLife + toAdd.maxLife, maxStamina
                        + toAdd.maxStamina, attack + toAdd.attack, defence
                        + toAdd.defence, crit + toAdd.crit, antiCrit
                        + toAdd.antiCrit, hit + toAdd.hit, dodge + toAdd.dodge,
                        moveSpeed + toAdd.moveSpeed, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                        true);
            }
        }

        // 暂不支持基础属性中也有百分比+-的属性
        return new SpriteStat((int) (maxLife * (1 + toAdd.maxLifePer))
                + toAdd.maxLife, (int) (maxStamina * (1 + toAdd.maxStaminaPer))
                + toAdd.maxStamina, (int) (attack * (1 + toAdd.attackPer))
                + toAdd.attack, (int) (defence * (1 + toAdd.defencePer))
                + toAdd.defence, (int) (crit * (1 + toAdd.critPer))
                + toAdd.crit, (int) (antiCrit * (1 + toAdd.antiCritPer))
                + toAdd.antiCrit, (int) (hit * (1 + toAdd.hitPer)) + toAdd.hit,
                (int) (dodge * (1 + toAdd.dodgePer)) + toAdd.dodge,
                (int) (moveSpeed * (1 + toAdd.moveSpeedPer)) + toAdd.moveSpeed,
                0, 0, 0, 0, 0, 0, 0, 0, 0, true);
    }

    public SpriteStat calculatePetStat(SpriteStat toAdd){
        if (toAdd.isZeroPer){
            return toAdd;
        }

        return new SpriteStat((int) (maxLife * toAdd.maxLifePer)
                + toAdd.maxLife, (int) (maxStamina * toAdd.maxStaminaPer)
                + toAdd.maxStamina, (int) (attack * toAdd.attackPer)
                + toAdd.attack, (int) (defence * toAdd.defencePer)
                + toAdd.defence, (int) (crit * toAdd.critPer) + toAdd.crit,
                (int) (antiCrit * toAdd.antiCritPer) + toAdd.antiCrit,
                (int) (hit * toAdd.hitPer) + toAdd.hit,
                (int) (dodge * toAdd.dodgePer) + toAdd.dodge, moveSpeed, 0, 0,
                0, 0, 0, 0, 0, 0, 0, true);
    }

    // ---- to string ----
    private static final Field[] fields;
    static{
        Field[] temp = SpriteStat.class.getDeclaredFields();

        int count = 0;
        for (Field field : temp){
            if (Modifier.isStatic(field.getModifiers())
                    || !Modifier.isFinal(field.getModifiers())){
                continue;
            }
            count++;
        }

        fields = new Field[count];
        int i = 0;
        for (Field field : temp){
            if (Modifier.isStatic(field.getModifiers())
                    || !Modifier.isFinal(field.getModifiers())){
                continue;
            }
            fields[i++] = field;
        }
    }

    public boolean isOnlyPercentStat(){
        return maxLife == 0 && maxStamina == 0 && attack == 0 && defence == 0
                && crit == 0 && antiCrit == 0 && hit == 0 && dodge == 0
                && moveSpeed == 0;
    }

    /**
     * 有字段<0返回false，否则返回true，不要乱用，这个方法只能在开服检查时使用
     * @param other
     * @return
     */
    public boolean isBuffStat(){
        return !hasAnyFieldLessThan(EMPTY_STAT);
    }

    /**
     * 有字段>0返回false，否则返回true，不要乱用，这个方法只能在开服检查时使用
     * @param other
     * @return
     */
    public boolean isDebuffStat(){
        return !hasAnyFieldGreaterThan(EMPTY_STAT);
    }

    /**
     * 是否存在字段的值小于other，不要乱用，这个方法只能在开服检查时使用
     * @param other
     * @return
     */
    public boolean hasAnyFieldLessThan(SpriteStat other){
        for (Field field : fields){
            try{
                Object obj = field.get(this);
                if (obj instanceof Number){
                    Number value = (Number) obj;
                    Number otherValue = (Number) field.get(other);
                    if (value.intValue() < otherValue.intValue()){
                        return true;
                    }
                }
            } catch (IllegalArgumentException | IllegalAccessException e){
                e.printStackTrace();
            }
        }

        return false;
    }

    /**
     * 是否存在字段的值大于other，不要乱用，这个方法只能在开服检查时使用
     * @param other
     * @return
     */
    public boolean hasAnyFieldGreaterThan(SpriteStat other){
        for (Field field : fields){
            try{
                Object obj = field.get(this);
                if (obj instanceof Number){
                    Number value = (Number) obj;
                    Number otherValue = (Number) field.get(other);
                    if (value.intValue() > otherValue.intValue()){
                        return true;
                    }
                }
            } catch (IllegalArgumentException | IllegalAccessException e){
                e.printStackTrace();
            }
        }
        return false;
    }

    @Override
    public String toString(){
        StringBuilder sb = new StringBuilder(100);
        sb.append("[");
        for (Field field : fields){
            try{
                Object obj = field.get(this);
                if (obj instanceof Number){
                    Number value = (Number) obj;
                    if (value.intValue() == 0){
                        continue;
                    }
                    sb.append(field.getName());
                    sb.append("=");
                    sb.append(value.intValue());
                    sb.append(",");
                }
            } catch (IllegalArgumentException e){
                // TODO Auto-generated catch block
                e.printStackTrace();
                return "Error getting " + field.getName();
            } catch (IllegalAccessException e){
                // TODO Auto-generated catch block
                e.printStackTrace();
                return "Error getting " + field.getName();
            }
        }
        sb.append("]");
        return sb.toString();
    }
}
