package app.game.data.spell;

import static com.mokylin.sink.util.Preconditions.checkArgument;

import java.util.List;
import java.util.Map;

import app.game.data.GameObjects;
import app.protobuf.ConfigContent.SpellEffectConfig;

import com.google.common.collect.Maps;
import com.google.inject.Inject;
import com.mokylin.sink.util.parse.ObjectParser;

public class SpellAnimations{

    public static final String LOCATION = GameObjects.SPELL_BASE_FOLDER
            + "spell_animation.txt";

    private final Map<String, SpellAnimation> map;

    @Inject
    SpellAnimations(GameObjects go, Animations animations){
        List<ObjectParser> list = go.loadFile(LOCATION);
        map = Maps.newHashMap();

        SpellAnimation[] array = new SpellAnimation[list.size()];
        for (ObjectParser p : list){
            SpellAnimation sa = new SpellAnimation(p, animations);
            checkArgument(map.put(sa.name, sa) == null, "技能效果名字重复: %s -> %s",
                    LOCATION, sa.name);

            checkArgument(sa.id > 0 && sa.id <= array.length
                    && array[sa.id - 1] == null, "技能效果ID重复，或者ID无效: %s -> %s",
                    LOCATION, sa.name);
            array[sa.id - 1] = sa;
        }
    }

    public SpellAnimation get(String name){
        return map.get(name);
    }

    public SpellEffectConfig generateProto(){
        SpellEffectConfig.Builder builder = SpellEffectConfig.newBuilder();
        for (SpellAnimation sa : map.values()){
            builder.addSpellEffects(sa.generateProto());
        }
        return builder.build();
    }
}
