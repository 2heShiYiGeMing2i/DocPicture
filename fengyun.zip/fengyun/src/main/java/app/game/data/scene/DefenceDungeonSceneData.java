package app.game.data.scene;

import static com.mokylin.sink.util.Preconditions.*;

import java.util.List;

import org.jboss.netty.buffer.ChannelBuffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.data.GameObjects;
import app.game.data.goods.GoodsDatas;
import app.game.data.goods.GoodsWrapper;
import app.game.module.scene.AbstractDungeonScene;
import app.game.module.scene.DefenceDungeonMessages;
import app.game.module.scene.DefenceDungeonScene;
import app.game.module.scene.DefenceKongCiFightModule;
import app.game.module.scene.FightData;
import app.game.module.scene.IDungeonService;
import app.game.service.log.LogService;
import app.protobuf.ConfigContent.DefenceConfig;
import app.protobuf.ConfigContent.DefenceDungeonProto;
import app.protobuf.LogContent.LogEnum.SceneType;
import app.utils.ServerType;
import app.utils.VariableConfig;

import com.google.common.collect.ImmutableSortedMap;
import com.google.protobuf.ByteString;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.parse.ObjectParser;

public class DefenceDungeonSceneData extends DungeonSceneData{
    private static final Logger logger = LoggerFactory
            .getLogger(DefenceDungeonSceneData.class);

    private static final String LOCATION = GameObjects.DEFENCE_SCENE_BASE_FOLDER
            + "mon.txt";

    private final int totalBatch;

    private final DefenceBatchInfo[] batchs;

    private final MonsterData kongciMonsterData;
    private final int kongciX;
    private final int kongciY;

    /**
     * 距离英雄多远后, 就满血去打孔慈
     */
    public final int maxTraceSteps;

    private final ChannelBuffer removeKongCiMsg; // 其实是没必要的, 不会收到删除孔慈的消息. 但是就缓存着一条吧
    private final ChannelBuffer addKongCiMsg;

    /**
     * 首通奖励. key是关数, value是奖励
     */
    private final ImmutableSortedMap<Integer, GoodsWrapper> firstPassPrize;

    private final int maxUsedMonsterID;

    DefenceDungeonSceneData(GameObjects go, ObjectParser p, BlockInfos blocks,
            MonsterDatas monsters, Scripts scripts, Plunders plunders, Ais ais,
            SceneTransportDatas transports, GoodsDatas goodsDatas,
            SceneRemoveObjectMsgCache removeMsgCache, ServerType serverType){
        super(go, p, blocks, monsters, scripts, plunders, ais, transports,
                removeMsgCache);

        // 检查里面不能配有任何怪
        checkArgument(!hasRelivableMonster(), "守护孔慈副本 %s 不能在mon文件夹下配置任何怪物",
                this);
        checkArgument(!hasSingleLifeMonster(), "守护孔慈副本 %s 不能在mon文件夹下配置任何怪物",
                this);

        // 追踪英雄距离
        this.maxTraceSteps = p.getIntKey("max_trace_steps");

        // 孔慈配置
        String kongciName = p.getKey("kongci_monster");
        this.kongciMonsterData = checkNotNull(monsters.get(kongciName),
                "守护孔慈没有找到孔慈的怪物数据kongci_monster: %s", kongciName);
        this.kongciX = p.getIntKey("kongci_x");
        this.kongciY = p.getIntKey("kongci_y");
        checkArgument(blockInfo.isWalkable(kongciX, kongciY),
                "守护孔慈副本, 孔慈的坐标不可走: <%s, %s>", kongciX, kongciY);
        this.kongciMonsterData.setScene(this,
                new int[]{Utils.short2Int(kongciX, kongciY)});
        this.removeKongCiMsg = removeMsgCache.get(1);
        this.addKongCiMsg = DefenceDungeonMessages.addKongCi(
                kongciMonsterData.id, kongciMonsterData.stat.maxLife, kongciX,
                kongciY);

        // 出怪点
        int centerX = p.getIntKey("center_x");
        int centerY = p.getIntKey("center_y");
        int range = p.getIntKey("range");

        // 加载每波的配置
        int maxMonID = 0;

        if (serverType.getServerType() != ServerType.Type.GAME_SERVER){
            logger.info("不是游戏服, 跳过加载孔慈");
            this.batchs = new DefenceBatchInfo[0];
            this.totalBatch = 0;

            ImmutableSortedMap.Builder<Integer, GoodsWrapper> builder = ImmutableSortedMap
                    .naturalOrder();
            this.firstPassPrize = builder.build();
        } else{
            List<ObjectParser> list = go.loadFile(LOCATION);

            this.totalBatch = list.size();
            this.batchs = new DefenceBatchInfo[totalBatch];

            DefenceMonsterPosCalculator posCalculator = new DefenceMonsterPosCalculator(
                    blockInfo, centerX, centerY, range);

            logger.debug("加载孔慈的怪物配置");
            for (int i = totalBatch; --i >= 0;){
                DefenceBatchInfo info = new DefenceBatchInfo(list.get(i),
                        blockInfo, monsters, goodsDatas, posCalculator,
                        removeMsgCache, this, i == totalBatch - 1 ? null
                                : batchs[i + 1]); // 从最后一波开始初始化, 最后一波的next是null, 之前的每一波的next都是下一波
                checkArgument(info.batch == i + 1, "守护孔慈的每波配置必须是从第1波开始, 且连续的");
                batchs[i] = info;

                maxMonID = Math.max(maxMonID, info.maxUsedMonsterID);
            }
            posCalculator = null; // 可被gc

            // 叠加每波的奖励
            logger.debug("计算孔慈每波的奖励");
            for (int i = 0; i < totalBatch; i++){
                batchs[i].calculateSum(i == 0 ? null : batchs[i - 1]);
            }

            // 预计算每波之间的奖励差
            logger.debug("计算孔慈每波之间的奖励差");
            for (final DefenceBatchInfo batch : batchs){
                batch.calculateDiff(batchs);
            }

            // 统计有首通奖励的波数
            ImmutableSortedMap.Builder<Integer, GoodsWrapper> builder = ImmutableSortedMap
                    .naturalOrder();
            for (DefenceBatchInfo batchInfo : batchs){
                if (batchInfo.firstPassPrize != null){
                    builder.put(batchInfo.batch, batchInfo.firstPassPrize);
                }
            }
            this.firstPassPrize = builder.build();

            logger.debug("加载了 {} 波守护孔慈配置", totalBatch);
        }
        this.maxUsedMonsterID = maxMonID;

        // TODO 检查总的不同物品个数

    }

    @Override
    public int getMaxUsedMonsterID(){
        return maxUsedMonsterID;
    }

    public java.util.Map.Entry<Integer, GoodsWrapper> getNextFirstPassPrize(
            int currentCollectedBatch){
        return firstPassPrize.higherEntry(currentCollectedBatch);
    }

    public DefenceBatchInfo getBatch(int batch){
        return batchs[batch - 1];
    }

    public int getTotalBatch(){
        return batchs.length;
    }

    public ChannelBuffer getAddKongCiMsg(){
        return addKongCiMsg;
    }

    public DefenceDungeonProto generateProto(){
        DefenceDungeonProto.Builder builder = DefenceDungeonProto.newBuilder();
        builder.setSceneId(id).setMap(blockName)
                .setName(ByteString.copyFrom(nameBytes)).setSound(sound);
        if (isHeroLevelProtect){
            builder.setIsHeroLevelProtect(true);
        }
        if (isNewHeroProtect){
            builder.setIsNewHeroProtect(true);
        }
        if (isDeathProtect){
            builder.setIsDeathProtect(true);
        }
        if (isNightAutoProtect){
            builder.setIsNightAutoProtect(true);
        }
        if (isJumpLimit){
            builder.setIsJumpLimit(true);
        }
        if (isMountLimit){
            builder.setIsMountLimit(true);
        }

        if (poet != null){
            String tp = poet.trim();
            if (tp.length() > 0){
                builder.setPoet(ByteString.copyFromUtf8(tp));
            }
        }
        if (fixedPkMode != null){
            builder.setFixedPkMode(fixedPkMode.getIntMode());
        }

        if (reliveOutOfDungeon){
            builder.setIsDeathReturnTown(true);
        }
        return builder.build();
    }

    public DefenceConfig generateConfig(VariableConfig config){
        DefenceConfig.Builder builder = DefenceConfig.newBuilder();
        builder.setRequiredLevel(requiredLevel);
        builder.setResetYuanbaoCost(config.DEFENCE_RESET_YUANBAO_COST);
        for (DefenceBatchInfo batch : batchs){
            // 首通奖励
            if (batch.firstPassPrize != null){
                builder.addFirstPassPrizeBatch(batch.batch);
                builder.addFirstPassPrizeGoods(batch.firstPassPrize
                        .encode4Client());
            }

            // 每关扫荡花费
            builder.addAutoFinishYuanbao(batch.autoFinishMoney);
        }
        return builder.build();
    }

    public DefenceKongCiFightModule newKongCi(DefenceDungeonScene parent){
        FightData fightData = new FightData(kongciMonsterData.stat,
                kongciMonsterData.level);
        fightData.setSceneIDAndPos(parent.getSceneID(), kongciX, kongciY);
        DefenceKongCiFightModule result = new DefenceKongCiFightModule(1,
                kongciMonsterData, fightData, parent, removeKongCiMsg,
                parent.getPositionModuleSharedSync());
        return result;
    }

    /**
     * 是否全场景视野. 组队副本重写
     * @return
     */
    @Override
    public boolean isSeeAllInScene(){
        return true;
    }

    @Override
    public int getIntType(){
        return SceneType.DEFENCE_DUNGEON.getNumber();
    }

    @Override
    public AbstractDungeonScene newDungeon(int sceneID,
            IDungeonService dungeonService, LogService logService, long creator){
        return new DefenceDungeonScene(this, sceneID, dungeonService,
                logService, creator);
    }

}
