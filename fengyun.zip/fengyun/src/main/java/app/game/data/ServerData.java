package app.game.data;

import static com.mokylin.sink.util.Preconditions.*;

import java.util.Arrays;

import app.utils.IDUtils;
import app.utils.Operators;

import com.google.common.annotations.VisibleForTesting;
import com.mokylin.collection.IntHashMap;
import com.mokylin.collection.IntHashSet;
import com.mokylin.sink.util.StringEncoder;
import com.mokylin.sink.util.TimeFormatter;
import com.mokylin.sink.util.Utils;

/**
 * 代表每一个服
 * 一个运营商id, 和多个服务器id
 * @author Timmy
 *
 */
public class ServerData{

    /**
     * 每个服的格式
     *
     * 运营商id + @ + -隔开每个服id
     *
     * 1@1-2-3-4
     * @param config
     * @return
     */
    public static ServerData parse(String config, int sequence){
        int opPos = config.indexOf("@");
        checkArgument(
                opPos > 0,
                "解析服务器id错误, 格式 运营商id@开服时间#服务器id(多个用-隔开), 例: 1@2014-2-14#1-2-3-4   : %s",
                config);

        int operatorID = Integer.parseInt(config.substring(0, opPos));

        int timePos = config.indexOf("#");
        checkArgument(
                timePos > 0,
                "解析服务器id错误, 格式 运营商id@开服时间#服务器id(多个用-隔开), 例: 1@2014-2-14#1-2-3-4   : %s",
                config);
        String dtTime = config.substring(opPos + 1, timePos);
        long startServiceTime = TimeFormatter.DAY2.parseMillis(dtTime);

        String[] sids = config.substring(timePos + 1).split("-");
        int[] serverIDs = new int[sids.length];
        for (int i = 0; i < sids.length; i++){
            serverIDs[i] = Integer.parseInt(sids[i]);
        }

        return new ServerData(operatorID, serverIDs, startServiceTime, sequence);
    }

    public static IntHashMap<ServerData> getCombinedServerIDs(
            ServerData[] serverDatas){
        IntHashMap<ServerData> result = new IntHashMap<>();
        for (ServerData s : serverDatas){
            for (int combineID : s.combindServerIDs){
                checkArgument(result.put(combineID, s) == null,
                        "服务器id有重复, 多条server间不能有运营商又相同, serverid又相同的");
            }
        }
        return result;
    }

    public static int[] getOperatorIDs(ServerData[] serverDatas){
        IntHashSet result = new IntHashSet();
        for (ServerData s : serverDatas){
            result.add(s.operatorID);
        }
        int[] array = new int[result.size()];
        int index = 0;
        for (int id : result){
            array[index++] = id;
        }
        return array;
    }

    // ---
    /**
     * 序列号的Integer
     */
    public final Integer integerSequence;

    /**
     * 序列号, 从0开始, 开服时生成的
     */
    public final int sequence;

    public final int operatorID;

    public final Operators operator;

    public final int[] serverID;

    public final Integer[] integerServerID;

    public final transient int[] combindServerIDs;

    public final transient int minServerID;

    public final transient int minCombineServerID;

    public final long startServiceTime;

    /**
     * 运营商id@1-2-3-4 每个服, 排序. encode decode到数据库, 就用这个string来表示这个服
     * 只要是完全相同的, 就是相同的string
     */
    public transient final String stringRepresentation;

    public transient final byte[] stringRepresentationBytes;

    private transient final int hashCode;

    public ServerData(int operatorID, int[] serverID, long startServiceTime,
            int sequence){
        this.sequence = sequence;
        this.integerSequence = Integer.valueOf(sequence);

        this.integerServerID = new Integer[serverID.length];
        for (int i = 0; i < serverID.length; i++){
            integerServerID[i] = serverID[i];
        }

        this.operatorID = operatorID;
        checkArgument(operatorID > 0 && operatorID <= IDUtils.MAX_OPERATOR_ID,
                "运营商id必须是1-%s 之间: %s", IDUtils.MAX_OPERATOR_ID, operatorID);

        operator = checkNotNull(Operators.valueOf(operatorID), "无效的运营商id-%s",
                operatorID);

        this.serverID = serverID;
        Arrays.sort(serverID);

        int len = serverID.length;

        checkArgument(len > 0, "必须至少配置一个serverID");
        if (Utils.hasDuplicate(serverID)){
            throw new IllegalArgumentException("服务器id不能有重复: "
                    + Arrays.toString(serverID));
        }

        for (int id : serverID){
            checkArgument(id >= 0 && id <= IDUtils.MAX_SERVER_ID,
                    "服务器id 必须是1-%s 之间: %s", IDUtils.MAX_SERVER_ID, id);
        }

        this.combindServerIDs = new int[serverID.length];

        int minServerID = Integer.MAX_VALUE;
        for (int i = 0; i < len; i++){
            combindServerIDs[i] = IDUtils.combineOperatorAndServerID(
                    operatorID, serverID[i]);

            minServerID = Math.min(minServerID, serverID[i]);
        }

        this.minServerID = minServerID;
        this.minCombineServerID = IDUtils.combineOperatorAndServerID(
                operatorID, minServerID);

        this.startServiceTime = startServiceTime;

        this.hashCode = operatorID * 31 + Arrays.hashCode(serverID);

        this.stringRepresentation = generateStringRepresentation(operatorID,
                serverID);
        stringRepresentationBytes = StringEncoder.encode(stringRepresentation);
    }

    public String getStringRepresentation(){
        return stringRepresentation;
    }

    @VisibleForTesting
    static String generateStringRepresentation(int operatorID, int[] serverID){
        StringBuilder sb = new StringBuilder();
        sb.append(operatorID).append("@");
        for (int sid : serverID){
            sb.append(sid).append("-");
        }
        sb.deleteCharAt(sb.length() - 1);
        return sb.toString();
    }

    @Override
    public int hashCode(){
        return hashCode;
    }

    @Override
    public boolean equals(Object obj){
        return this == obj;
    }

    public boolean contains(int combinedServerID){
        for (int id : combindServerIDs){
            if (id == combinedServerID){
                return true;
            }
        }
        return false;
    }
}
