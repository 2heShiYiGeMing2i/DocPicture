package app.game.data.goods;

import static com.mokylin.sink.util.Preconditions.*;

import java.util.Arrays;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.data.GameObjects;
import app.game.data.QualityRelatedDatas;
import app.game.data.SingleSpriteStat;
import app.game.data.SingleSpriteStats;
import app.game.data.UpgradeData;
import app.game.data.goods.EquipmentAddedStatGroup.SingleAddedStat;
import app.game.data.goods.EquipmentAddedStatGroup.SingleAddedStatGroup;
import app.game.module.scene.FightData;
import app.protobuf.ConfigContent.EquipmentLevelForgeProto;
import app.protobuf.GoodsContent.EquipmentDataProto;
import app.protobuf.GoodsContent.EquipmentProto;
import app.protobuf.GoodsServerContent.EquipmentServerProto;
import app.protobuf.GoodsServerContent.GoodsServerProto;
import app.protobuf.GoodsServerContent.GoodsType;
import app.protobuf.GoodsServerContent.Quality;
import app.protobuf.SpriteStatContent.SingleStatProto;
import app.protobuf.SpriteStatContent.StatType;

import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.ByteString;
import com.mokylin.collection.IntHashMap;
import com.mokylin.sink.util.Empty;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.WeightedRandomer;
import com.mokylin.sink.util.parse.ObjectParser;

public class EquipmentData extends GoodsData{
    private static final Logger logger = LoggerFactory
            .getLogger(EquipmentData.class);

    public static final String HERO_LOCATION = GameObjects.GOODS_BASE_LOCATION
            + "equipment.txt";

    public static final String MOUNT_LOCATION = GameObjects.GOODS_BASE_LOCATION
            + "mount_equipment.txt";

    /**
     * 0-all 1-步惊云 2-聂风 3-楚楚 4-第二梦
     */
    private final int race;

    /**
     * 装备部位，0-武器 1-戒指 2-项链 3-护腕 4-玉佩 5-头盔 6-衣服 7-腰带 8-裤子 9-鞋子
     */
    private final int equipType;

    /**
     * 换装资源
     */
    private final int resource;

    /**
     * 基础属性
     */
    final SingleSpriteStat[] baseStats;

    private final SingleStatProto[] baseStatProtos;

    /**
     * 强化最大等级
     */
    final int refinedMaxTimes;

    final String refinedForgeGroupName;

    /**
     * 强化属性
     */
    final RefinedData[] refinedDatas;

    transient final RefinedData nonRefinedData;

    transient final RefinedData maxRefinedData;

    // 套装
    final TaozData taoz;

    // 附加属性
    private final int addedStatMaxCount;

    final EquipmentAddedStatGroup addedStatGroup;

//    private final String qualityForgeGroupName;
//
//    private final EnumMap<StatType, AddedDataGroup> addedDataMap;
//
//    private final WeightedRandomer<AddedDataGroup> addedDataRandomer;
//
//    private transient final WeightedRandomer<StatType> addedStatTypeRandomer;

    // 提升等级

    private final int nextLevelEquipmentId;

    transient EquipmentData nextLevelEquipment;

    final String levelForgeGroupName;

//    private transient EnumMap<StatType, EnumMap<Quality, UpgradeLevelData[]>> upgradeLevelDataMap;

    EquipmentForgeGroup levelForgeGroup;

    private final EquipmentDataProto proto;

    private final byte[] protoBytes;

    private final ByteString protoByteString;

    private final QualityRelatedDatas qualityDatas;

    EquipmentData(ObjectParser p, SingleSpriteStats spriteStats,
            EquipmentAddedStatGroups addedStatGroups,
            QualityRelatedDatas qualityDatas, TaozDatas taozhuangs){
        super(p, GoodsType.EQUIPMENT);
        this.qualityDatas = qualityDatas;

        /*
         *  TODO 检查职业和equipType. 
         *  武器0 头盔5 衣服6 腰带7 裤子8 鞋子9 必须有职业限制
         *  戒指1 项链2 护腕3 玉佩4 必须没有职业限制
         *  20-鞍具 21-缰绳 22-蹬具 23-蹄铁 必须没有职业限制
         */
        race = p.getIntKey("race", 0);
        checkArgument(race >= 0 && race <= 4,
                "物品%s-%s 的职业限制错误（0-all 1-步惊云 2-聂风 3-楚楚 4-第二梦），race: %s", id,
                name, race);

        checkArgument(maxCount == 1, "物品%s-%s 是装备，但是居然可以堆叠，maxCount: %s", id,
                name, maxCount);

        equipType = p.getIntKey("equip_type");

        checkArgument(
                equipType >= 0 && equipType < Equipment.HERO_EQUIPED_MAX_COUNT,
                "%s 配置的EquipType无效, 0-武器 1-戒指 2-项链 3-护腕 4-玉佩 5-头盔 6-衣服 7-腰带 8-裤子 9-鞋子",
                this);

        resource = p.getIntKey("resource", 0);
        checkArgument(resource >= 0 && resource < 16,
                "物品%s-%s 的换装资源必须是 0-15中的一种，0表示没有换装，最多支持15种，resource: %s", id,
                name, resource);

        String baseStatIds = p.getKey("base_stat");

        String[] baseStatIdArray = baseStatIds.split(";");
        checkArgument(baseStatIdArray.length > 0
                && baseStatIdArray.length <= Quality.values().length,
                "%s 配置的基础属性个数，必须大于0且小于等于品质总个数，count: %s", this,
                baseStatIdArray.length);

        baseStats = new SingleSpriteStat[baseStatIdArray.length];
        baseStatProtos = new SingleStatProto[baseStatIdArray.length];

        StatType baseStatType = null;
        for (int i = 0; i < baseStatIdArray.length; i++){
            int baseStatId = Integer.parseInt(baseStatIdArray[i]);

            SingleSpriteStat baseStat = checkNotNull(
                    spriteStats.get(baseStatId),
                    "物品%s-%s 配置的基础属性不存在，base_stat: %s", id, name, baseStatId);

            checkArgument(baseStat.isBuffStat(),
                    "物品%s-%s 配置的基础属性，不是增益属性，base_stat: %s", id, name,
                    baseStatId);

            if (i == 0){
                baseStatType = baseStat.getStatType();
            } else{
                checkArgument(baseStatType == baseStat.getStatType(),
                        "装备%s 配置的基础属性类型必须全部一样(加攻击必须全部都是加攻击的)", this);
            }

            baseStats[i] = baseStat;
            baseStatProtos[i] = baseStat.encode();
        }

        // 强化等级
        refinedMaxTimes = p.getIntKey("refined_max_times",
                Equipment.DEFAULT_REFINED_MAX_TIMES);

        int tid = p.getIntKey("taozhuang");
        if (tid > 0){
            taoz = checkNotNull(taozhuangs.get(tid), "%s 配置的套装ID不存在, %s", this,
                    tid);
        } else{
            taoz = null;
        }

//        addedStatMaxCount = p.getIntKey("added_stat_max_count",
//                Equipment.DEFAULT_ADDED_STAT_COUNT);
        addedStatMaxCount = Equipment.DEFAULT_ADDED_STAT_COUNT;

        String refinedStatStr = p.getKey("refined_stats", "");

        String[] refinedStatPercents = Empty.STRING_ARRAY;
        if (!refinedStatStr.isEmpty()){
            refinedStatPercents = refinedStatStr.split(";");
        }

        int refinedStatCount = refinedStatPercents.length;
        checkArgument(refinedStatCount == refinedMaxTimes,
                "物品%s-%s 配置的强化属性个数错误，最大强化属性个数: %s，refined_stats: %s", id, name,
                refinedMaxTimes, refinedStatStr);

        refinedForgeGroupName = p.getKey("refined_forge_group");

        SingleSpriteStat[] emptyRefinedStat = new SingleSpriteStat[baseStats.length];
        SingleSpriteStat s = SingleSpriteStat.getEmptyStat(baseStatType);
        for (int i = 0; i < emptyRefinedStat.length; i++){
            emptyRefinedStat[i] = s;
        }

        refinedDatas = new RefinedData[refinedStatCount + 1];

        RefinedData nextLevel = null;
        int nextPercent = Integer.MAX_VALUE;
        for (int refinedTimes = refinedStatCount; refinedTimes >= 0; refinedTimes--){
            SingleSpriteStat[] refinedStat = emptyRefinedStat;
            if (refinedTimes > 0){
//                int refinedStatId = Integer
//                        .parseInt(refinedStatIds[refinedTimes - 1]);
//                refinedStat = checkNotNull(spriteStats.get(refinedStatId),
//                        "物品%s-%s 配置的强化属性不存在，refined_stats: %s", id, name,
//                        refinedStatId);
//
//                checkArgument(refinedStat.isBuffStat(),
//                        "物品%s-%s 配置的强化属性，不是增益属性，refined_stats: %s", id, name,
//                        refinedStatId);
//
//                checkArgument(baseStatType == refinedStat.getStatType(),
//                        "物品%s-%s 的基础属性与 %s级的强化属性中的属性类型不一致，base:%s refined:%s",
//                        id, name, refinedTimes + 1, baseStatType,
//                        refinedStat.getStatType());

                int percent = Integer
                        .parseInt(refinedStatPercents[refinedTimes - 1]);
                checkArgument(percent > 0, "装备%s 配置的强化属性百分百比必须大于0", this);
                checkArgument(percent < nextPercent, "装备%s 配置的强化属性百分比必须从小到大",
                        this);
                nextPercent = percent;

                refinedStat = new SingleSpriteStat[baseStats.length];
                for (int i = 0; i < emptyRefinedStat.length; i++){
                    refinedStat[i] = baseStats[i].multiply(percent / 100f);
                }
            }

            nextLevel = refinedDatas[refinedTimes] = new RefinedData(id, name,
                    refinedTimes, refinedStat, nextLevel);
        }

        nonRefinedData = refinedDatas[0];
        maxRefinedData = refinedDatas[refinedStatCount];

        // 附加属性

//        qualityForgeGroupName = p.getKey("quality_forge_group");

        String addedGroupName = p.getKey("added_group");
        addedStatGroup = checkNotNull(addedStatGroups.get(addedGroupName),
                "物品%s-%s 配置附加属性Group数据没找到: %s", id, name, addedGroupName);

//        addedDataMap = Maps.newEnumMap(StatType.class);
//
//        List<LeftIntPair<AddedDataGroup>> dataPairs = Lists
//                .newArrayListWithCapacity(addedDataMap.size());
//
//        List<LeftIntPair<StatType>> statTypePairs = Lists
//                .newArrayListWithCapacity(addedDataMap.size());
//
//        for (SingleAddedStatGroup addedStatData : addedStatGroup.addedStatMap
//                .values()){
//            AddedDataGroup group = new AddedDataGroup(addedStatData);
//            addedDataMap.put(group.statType, group);
//
//            dataPairs.add(new LeftIntPair<AddedDataGroup>(addedStatData.weight,
//                    group));
//            statTypePairs.add(new LeftIntPair<StatType>(addedStatData.weight,
//                    group.statType));
//        }
//
//        addedDataRandomer = new WeightedRandomer<>(dataPairs);
//        addedStatTypeRandomer = new WeightedRandomer<>(statTypePairs);

        nextLevelEquipmentId = p.getIntKey("next_level_equipment");
        levelForgeGroupName = p.getKey("level_forge_group");

        proto = build();

        protoBytes = processProtoBytes(proto.toByteArray());
        protoByteString = ByteString.copyFrom(protoBytes);
    }

    void initNextLevel(IntHashMap<EquipmentData> map){
        if (nextLevelEquipmentId > 0){
            nextLevelEquipment = checkNotNull(map.get(nextLevelEquipmentId),
                    "%s 配置的等级提升后的装备不存在, %s", this, nextLevelEquipmentId);

            checkArgument(requireLevel < nextLevelEquipment.requireLevel,
                    "%s 配置的等级提升后的装备的等级必须大于当前装备的等级", this);

            checkArgument(equipType == nextLevelEquipment.equipType,
                    "%s 配置的等级提升后的装备的部件不一致", this);

            checkArgument(race == nextLevelEquipment.race,
                    "%s 配置的等级提升后的装备的穿戴角色不一致", this);

            // 强化等级
            checkArgument(
                    maxRefinedData.refinedTimes <= nextLevelEquipment.maxRefinedData.refinedTimes,
                    "%s 配置的等级提升后的装备的最大强化等级必须大于等于当前装备的最大强化等级", this);

            // 附加属性

            for (StatType type : addedStatGroup.addedStatMap.keySet()){
                checkArgument(
                        nextLevelEquipment.addedStatGroup.addedStatMap
                                .containsKey(type),
                        "%s 配置的等级提升后的装备的不包含低级装备的附加属性类型, %s", this, type);
            }

            checkArgument(!nextLevelEquipment.levelForgeGroupName.isEmpty(),
                    "%s 配置的等级提升后的装备的levelForgeGroupName数据没有配置", this);
        }
    }

//    void initForgeData(EquipmentForgeDatas forgeDatas){
//        if (!refinedForgeGroupName.isEmpty()){
//            EquipmentRefinedForgeGroup group = checkNotNull(
//                    forgeDatas.getRefinedGroup(refinedForgeGroupName),
//                    "物品%s-%s 配置强化Group数据没找到: %s", id, name,
//                    refinedForgeGroupName);
//
//            checkArgument(refinedMaxTimes == group.maxRefinedTimes,
//                    "物品%s-%s 配置强化个数与强化升级Group中的升级数据个数不一致: %s，%s: %s", id, name,
//                    refinedMaxTimes, group.name, group.maxRefinedTimes);
//
//            for (RefinedData data : refinedDatas){
//                data.setRefinedUpgradeGroup(group);
//            }
//        }
//
//        if (!qualityForgeGroupName.isEmpty()){
//            EquipmentForgeGroup group = checkNotNull(
//                    forgeDatas.getQualityGroup(qualityForgeGroupName),
//                    "物品%s-%s 配置品质Group数据没找到: %s", id, name,
//                    qualityForgeGroupName);
//
//            for (AddedDataGroup addedDataGroup : addedDataMap.values()){
//                addedDataGroup.initForgeData(group);
//            }
//        }
//
//        if (!levelForgeGroupName.isEmpty()){
//            EquipmentForgeGroup group = checkNotNull(
//                    forgeDatas.getLevelGroup(levelForgeGroupName),
//                    "物品%s-%s 配置等级Group数据没找到: %s", id, name, levelForgeGroupName);
//
//            for (AddedDataGroup addedDataGroup : addedDataMap.values()){
//                // 装备提升等级数据
//                EnumMap<Quality, UpgradeLevelData[]> qualityMap = Maps
//                        .newEnumMap(Quality.class);
//
//                // 放入容器中
//                EnumMap<Quality, UpgradeLevelData[]> statData = upgradeLevelDataMap
//                        .put(addedDataGroup.statType, qualityMap);
//
//                checkArgument(statData == null, "物品%s-%s 配置的提升等级重复调用了", id,
//                        name);
//
//                for (AddedData addedData : addedDataGroup.addedDataMap.values()){
//                    UpgradeLevelData[] datas = new UpgradeLevelData[refinedDatas.length];
//                    qualityMap.put(addedData.quality, datas);
//
//                    for (int i = 0; i < refinedDatas.length; i++){
//                        datas[i] = new UpgradeLevelData(refinedDatas[i],
//                                addedData,
//                                group.forgeDataMap.get(addedData.quality));
//                    }
//                }
//            }
//        }
//    }

    public QualityRelatedDatas getQualityDatas(){
        return qualityDatas;
    }

    public TaozData getTaoz(){
        return taoz;
    }

    @Override
    public long getGoodsIdentifier(GoodsServerProto proto){
        EquipmentServerProto equipmentProto = proto
                .getExtension(EquipmentServerProto.goodsProto);

        int refinedTimes = 0;
        int intQuality = 0;
        int intStatType = 0;
        int refinedUpgradeTimes = 0;
        if (equipmentProto != null){
            refinedTimes = equipmentProto.getRefinedTimes();
            intQuality = equipmentProto.getQuality();
            intStatType = equipmentProto.getAddedStatType();
            refinedUpgradeTimes = equipmentProto.getRefinedUpgradeTimes();
        }

        return getGoodsIdentifier(proto.getBinded(), intStatType, intQuality,
                refinedTimes, refinedUpgradeTimes);
    }

    @Override
    public long getGoodsIdentifier(boolean binded, int intExpireTime){
        return getGoodsIdentifierSharedBits(binded);
    }

    public long getGoodsIdentifier(boolean binded, int statType, int quality,
            int refinedTimes, int refinedUpgradeTimes){
        return (getEquipmentGoodsIdentifier(statType, quality, refinedTimes,
                refinedUpgradeTimes) << 28)
                | getGoodsIdentifierSharedBits(binded);
    }

    private long getEquipmentGoodsIdentifier(int intStatType, int intQuality,
            int refinedTimes, int refinedUpgradeTimes){
        // 5个bit给addedData.statType, 4个bit给addedData.quality. 4个bit给refinedTimes, 12个bit给refinedUpgradeTimes
        return intStatType | (intQuality << 5) | (refinedTimes << 9)
                | (refinedUpgradeTimes << 13);
    }

    public Equipment newEquipment4Test(int refinedTimes, StatType statType,
            Quality quality){
        return newEquipment(0, false, refinedTimes, statType.getNumber(),
                quality.getNumber());
    }

    public boolean canRefined(){
        return !refinedForgeGroupName.isEmpty();
    }

//    public boolean canUpgradeQuality(){
//        return !qualityForgeGroupName.isEmpty();
//    }
//
//    public boolean canUpgradeLevel(){
//        return !levelForgeGroupName.isEmpty();
//    }

    public EquipmentForgeGroup getLevelForgeGroup(){
        return levelForgeGroup;
    }

    public EquipmentData getNextLevelEquipment(){
        return nextLevelEquipment;
    }

//    public UpgradeLevelData getUpgradeLevelData(int refinedTimes,
//            StatType statType, Quality quality){
//        EnumMap<Quality, UpgradeLevelData[]> qualityMap = upgradeLevelDataMap
//                .get(statType);
//        if (qualityMap == null){
//            return null;
//        }
//
//        UpgradeLevelData[] array = qualityMap.get(quality);
//        if (array == null){
//            return null;
//        }
//
//        return Utils.getValidObject(array, refinedTimes);
//    }

    @Override
    public int getRequiredRace(){
        return race;
    }

    boolean isValidEquipPos(int equipPos){
        return this.equipType == equipPos;
    }

    public boolean isValidRefinedTimes(int refinedTimes){
        return refinedTimes >= 0 && refinedTimes <= refinedMaxTimes;
    }

    public RefinedData getRefinedData(int refinedTimes){

        if (refinedTimes >= 0 && refinedTimes <= refinedMaxTimes){
            return refinedDatas[refinedTimes];
        }

        if (refinedTimes < 0){
            return nonRefinedData;
        }

        return maxRefinedData;
    }

    int getValidRefinedTimes(int refinedTimes){
        if (refinedTimes >= 0 && refinedTimes <= refinedMaxTimes){
            return refinedTimes;
        }

        if (refinedTimes < 0){
            return 0;
        }

        return refinedTimes;
    }

    int getValidAddedCount(int addedCount){
        if (addedCount >= 0 && addedCount <= addedStatMaxCount){
            return addedCount;
        }

        if (addedCount < 0){
            return 0;
        }

        return addedStatMaxCount;
    }

    public WeightedRandomer<StatType> getDefaultAddedStatTypeRandomer(){
        return addedStatGroup.statRandomer;
    }

    public SingleAddedStat getAddedStat(StatType statType, Quality quality){
        SingleAddedStatGroup group = getAddedStatGroup(statType);
        if (group != null){
            return group.getAddedStat(quality);
        }

        return getDefaultAddedStat(quality);
    }

    SingleAddedStatGroup getAddedStatGroup(StatType statType){
        return addedStatGroup.get(statType);
    }

    public SingleAddedStat getDefaultAddedStat(Quality quality){
        return addedStatGroup.defaultStatGroup.getAddedStat(quality);
    }

    int getEquipType(){
        return equipType;
    }

    public int getResource(){
        return resource;
    }

    @Override
    Goods newGoods(long expireTime){
        return newEquipment(expireTime, false, 0, 0, 0);
    }

    @Override
    Goods newGoods(int realCount, GoodsServerProto proto){
        EquipmentServerProto equipmentProto = proto
                .getExtension(EquipmentServerProto.goodsProto);

        int refinedTimes = 0;
        int intQuality = 0;
        int intStatType = 0;
        int refinedUpgradeTimes = 0;
        boolean isUnmeltable = false;
        if (equipmentProto != null){
            refinedTimes = equipmentProto.getRefinedTimes();
            intQuality = equipmentProto.getQuality();
            intStatType = equipmentProto.getAddedStatType();
            refinedUpgradeTimes = equipmentProto.getRefinedUpgradeTimes();
        }

        Equipment e = new Equipment(this, proto.getExpireTime(), isUnmeltable,
                refinedTimes, intStatType, intQuality, refinedUpgradeTimes);

        if (proto.getBinded())
            e.bind();

        return e;
    }

    Equipment newEquipment(long expireTime, boolean isUnmeltable,
            int refinedTimes, int intStatType, int intQuality){
        return new Equipment(this, expireTime, isUnmeltable, refinedTimes,
                intStatType, intQuality, 0);
    }

    private EquipmentDataProto build(){
        EquipmentDataProto.Builder builder = EquipmentDataProto.newBuilder();
        builder.setBaseData(encode());
        builder.setBaseStat(baseStatProtos[0])
                .setRefinedMaxTimes(refinedMaxTimes)
                .setAddedStatMaxCount(addedStatMaxCount).setPos(equipType)
                .setRace(race);

        builder.setBaseFightingAmount(FightData
                .calculateFightingAmount(baseStats[0]));
        builder.setBestRefinedFightingAmount(maxRefinedData
                .getRefinedFightingAmount(0));
        builder.setCanRefined(!refinedForgeGroupName.isEmpty())
                .setNextLevelEquipment(nextLevelEquipmentId);

        if (taoz != null)
            builder.setTaoz(taoz.id);

        return builder.build();
    }

    public EquipmentDataProto getProto(){
        return proto;
    }

    @Override
    public ByteString getProtoByteString(){
        return protoByteString;
    }

    @Override
    public byte[] getProtoBytes(){
        return protoBytes;
    }

    SingleSpriteStat getBaseStat(int intQuality){
        return Utils.getValidObject(baseStats, intQuality);
    }

    // EquipmentProto
    @Override
    public AbstractMessageLite encodeGoodsProto(Goods g){
        assert g instanceof Equipment: "EquipmentData.encodeGoodsProto中的参数居然不是装备";

        Equipment e = (Equipment) g;

        return encodeGoodsProto(e.binded, e.expireTime, e.refinedTimes,
                e.intQuality, e.intStatType);
    }

    @Override
    public AbstractMessageLite encodeGoodsProto(GoodsServerProto serverProto){
        EquipmentServerProto equipmentProto = serverProto
                .getExtension(EquipmentServerProto.goodsProto);

        int refinedTimes = 0;
        int intQuality = 0;
        int intStatType = 0;
        if (equipmentProto != null){
            refinedTimes = equipmentProto.getRefinedTimes();
            intQuality = equipmentProto.getQuality();
            intStatType = equipmentProto.getAddedStatType();
        }

        return encodeGoodsProto(serverProto.getBinded(),
                serverProto.getExpireTime(), refinedTimes, intQuality,
                intStatType);
    }

    EquipmentProto encodeGoodsProto(boolean binded, long expireTime,
            int refinedTimes, int intQuality, int intStatType){

        RefinedData refinedData = getRefinedData(refinedTimes);

        StatType statType = StatType.valueOf(intStatType);
        Quality quality = Quality.valueOf(intQuality);

        if (quality == null)
            quality = Quality.WHITE;

        SingleAddedStat addedStat;
        if (statType != null){
            addedStat = getAddedStat(statType, quality);
        } else{
            addedStat = getDefaultAddedStat(quality);
        }

        return encodeEquipmentProto(binded, expireTime, refinedData, addedStat);
    }

    private EquipmentProto encodeEquipmentProto(boolean binded,
            long expireTime, RefinedData refinedData, SingleAddedStat addedData){
        EquipmentProto.Builder builder = EquipmentProto.newBuilder();

        if (binded){
            builder.setBinded(binded);
        }

        if (expireTime > 0){
            builder.setExpireTime(expireTime);
        }

        int intQuality = addedData.quality.getNumber();

        builder.setQuality(intQuality);

        if (refinedData.refinedTimes > 0){
            builder.setRefinedTimes(refinedData.refinedTimes);
            builder.setRefinedStat(refinedData.getRefinedStatProto(intQuality));
            builder.setRefinedFightingAmount(refinedData
                    .getRefinedFightingAmount(intQuality));
        }

        if (addedData.addedStatCount > 0){
            builder.setAddedStatCount(addedData.addedStatCount);
            builder.setAddedStat(addedData.addedStatProto);
            builder.setAddedFightingAmount(addedData.addedFightingAmount);
        }
        builder.setAddedStatType(addedData.getStatType().getNumber());

        SingleSpriteStat baseStat = Utils.getValidObject(baseStats, intQuality);
        int baseFightingAmount = FightData.calculateFightingAmount(baseStat);
        SingleStatProto baseStatProto = Utils.getValidObject(baseStatProtos,
                intQuality);

        builder.setBaseStat(baseStatProto);
        builder.setBaseFightingAmount(baseFightingAmount);

        builder.setBestRefinedFightingAmount(maxRefinedData
                .getRefinedFightingAmount(intQuality));

        return builder.build();
    }

    @Override
    public int getAuctionType(){
        switch (equipType){
            case Equipment.EQUIPMENT_TYPE_RING:{
                return 91;
            }

            case Equipment.EQUIPMENT_TYPE_NECKLACE:{
                return 92;
            }

            case Equipment.EQUIPMENT_TYPE_GLOVE:{
                return 93;
            }

            case Equipment.EQUIPMENT_TYPE_JADE:{
                return 94;
            }
            default:{
                // 其他都是职业特定的
                int auctionRace = race;
                if (auctionRace == 0){
                    logger.error(
                            "装备的type是{}, 按策划案应该是有race的. 放到摊位上, 默认作为步惊云的装备.  {}",
                            equipType, this);
                    auctionRace = 1;
                }
                return auctionRace * 10 + equipType;
            }
        }
    }

//    public static class RefinedData{
//
//        final int masterId;
//
//        final int refinedTimes;
//
//        final SingleSpriteStat refinedStat;
//
//        final int refinedFightingAmount;
//
//        transient final SpriteStat baseRefinedStat;
//
//        transient final int baseRefinedFightingAmount;
//
//        final RefinedData nextLevel;
//
//        transient final byte[] dropName;
//
//        transient final SingleStatProto refinedStatProto;
//
//        // 强化消耗
//
//        UpgradeData upgradeData;
//
//        // 升级成功是否广播
//        boolean isBroadcast;
//
//        transient byte[] protoData;
//
//        transient ChannelBuffer upgradeDataMsg;
//
//        private RefinedData(int masterId, String name, int refinedTimes,
//                SingleSpriteStat baseStat, int baseFightingAmount,
//                SingleSpriteStat refinedStat, RefinedData nextLevel){
//            this.masterId = masterId;
//            this.refinedTimes = refinedTimes;
//            this.refinedStat = refinedStat;
//
//            SingleSpriteStat singleBaseRefinedStat = baseStat.add(refinedStat);
//
//            baseRefinedStat = SpriteStat.EMPTY_STAT.add(singleBaseRefinedStat);
//            refinedFightingAmount = FightData
//                    .calculateFightingAmount(refinedStat);
//            baseRefinedFightingAmount = baseFightingAmount
//                    + refinedFightingAmount;
//
//            this.nextLevel = nextLevel;
//
//            dropName = StringEncoder.encode(refinedTimes > 0 ? name + "+"
//                    + refinedTimes : name);
//
//            refinedStatProto = refinedStat.encode();
//        }
//
//        void setRefinedUpgradeGroup(
//                EquipmentRefinedForgeGroup refinedUpgradeGroup){
//            if (refinedTimes > 0){
//                upgradeData = refinedUpgradeGroup.upgradeDatas[refinedTimes - 1];
//                isBroadcast = refinedUpgradeGroup.isBroadcasts[refinedTimes - 1];
//
//                EquipmentRefinedForgeProto proto = EquipmentRefinedForgeProto
//                        .newBuilder().setId(masterId)
//                        .setRefinedTimes(refinedTimes)
//                        .setRefinedStat(refinedStat.encode())
//                        .setRefinedFightingAmount(refinedFightingAmount)
//                        .setCost(upgradeData.getProto()).build();
//
//                protoData = proto.toByteArray();
//                upgradeDataMsg = EquipmentMessages.getRefinedDataMsg(proto);
//            }
//        }
//
//        public int getRefinedTimes(){
//            return refinedTimes;
//        }
//
//        public UpgradeData getUpgradeData(){
//            return upgradeData;
//        }
//
//        public boolean isBroadcast(){
//            return isBroadcast;
//        }
//
//        public byte[] getUpgradeProtoData(){
//            return protoData;
//        }
//
//        public ChannelBuffer getUpgradeDataMsg(){
//            return upgradeDataMsg;
//        }
//    }
//
//    public class AddedDataGroup{
//
//        final StatType statType;
//
//        final EnumMap<Quality, AddedData> addedDataMap;
//
//        AddedDataGroup(SingleAddedStatGroup addedStatGroup){
//            this.statType = addedStatGroup.statType;
//
//            addedDataMap = Maps.newEnumMap(Quality.class);
//
//            // 橙色最前，白色最后
//            AddedData nextLevel = null;
//            for (Quality quality : qualityDatas.reversalQualityLevelArray){
//                AddedData data = nextLevel = new AddedData(
//                        addedStatGroup.getAddedStat(quality), nextLevel);
//                addedDataMap.put(quality, data);
//            }
//
//            nextLevel = null;
//            for (Quality quality : qualityDatas.reversalQualityLevelArray){
//                AddedData data = checkNotNull(addedDataMap.get(quality));
//                checkArgument(data.nextLevel == nextLevel);
//                nextLevel = data;
//            }
//        }
//
//        private void initForgeData(EquipmentForgeGroup group){
//            for (AddedData data : addedDataMap.values()){
//                data.initForgeData(group.forgeDataMap.get(data.quality));
//            }
//        }
//
//        public AddedData getAddedData(Quality quality){
//            return addedDataMap.get(quality);
//        }
//    }
//
//    public class AddedData{
//
//        final Quality quality;
//
//        final int addedStatCount;
//
//        final StatType statType;
//
//        final SingleSpriteStat addedStat;
//
//        transient final SingleStatProto addedStatProto;
//
//        transient final int addedFightingAmount;
//
//        transient final SingleSpriteStat totalStat;
//
//        transient final int totalFightingAmount;
//
//        /**
//         * 在计算装备的goods identifier时, 缓存了 5bit的statType和4bit的quality
//         */
//        final transient int equipmentIdentifierStatTypeAndQualityCombined;
//
//        final AddedData nextLevel;
//
//        private int forgeAmount;
//
//        EquipmentForgeData forgeData;
//
//        transient byte[] qualityProtoData;
//
////        transient ChannelBuffer upgradeQualityMsg;
//
//        AddedData(SingleAddedStat singleAddedStat, AddedData nextLevel){
//            this.quality = singleAddedStat.quality;
//            this.addedStatCount = singleAddedStat.addedStatCount;
//            this.statType = singleAddedStat.getStatType();
//            this.nextLevel = nextLevel;
//
//            this.equipmentIdentifierStatTypeAndQualityCombined = statType
//                    .getNumber() | (quality.getNumber() << 5);
//
//            if (nextLevel == null){
//                checkArgument(quality == Quality.ORANGE, "装备最高级的品质居然不是橙色");
//            } else{
//                checkArgument(
//                        quality.getNumber() + 1 == nextLevel.quality
//                                .getNumber(),
//                        "装备品质的下一级居然是不连续的Number");
//            }
//
//            addedStat = singleAddedStat.getSingleStat();
//            addedStatProto = singleAddedStat.getSingleStatProto();
//            addedFightingAmount = singleAddedStat.addedFightingAmount;
//
//            totalStat = singleAddedStat.getTotalStat();
//            totalFightingAmount = singleAddedStat.fightingAmount;
//        }
//
//        private void initForgeData(EquipmentForgeData forgeData){
//            checkArgument(this.forgeData == null, "重复设置forgeData");
//
//            this.forgeData = forgeData;
//            forgeAmount = forgeData.forgeAmount;
//
//            EquipmentQualityForgeProto qualityProto = EquipmentQualityForgeProto
//                    .newBuilder().setId(id).setQuality(quality.getNumber())
//                    .setAddedStatType(statType.getNumber())
//                    .setAddedStatCount(addedStatCount)
//                    .setAddedStat(addedStatProto)
//                    .setAddedFightingAmount(addedFightingAmount)
//                    .setForgeAmount(forgeAmount)
//                    .setCoefficient(forgeData.upgradeCoefficient)
//                    .setCost(forgeData.upgradeData.getProto()).build();
//
//            qualityProtoData = qualityProto.toByteArray();
////            upgradeQualityMsg = EquipmentMessages
////                    .getUpgradeQualityDataMsg(qualityProto);
//        }
//
//        public StatType getStatType(){
//            return statType;
//        }
//
//        public EquipmentForgeData getForgeData(){
//            return forgeData;
//        }
//
//        public int getForgeAmount(){
//            return forgeAmount;
//        }
//
//        public SingleSpriteStat getTotalStat(){
//            return totalStat;
//        }
//
//        public byte[] getUpgradeQualityData(){
//            return qualityProtoData;
//        }
//
////        public ChannelBuffer getUpgradeQualityDataMsg(){
////            return upgradeQualityMsg;
////        }
//    }

    public EquipmentLevelForgeProto getLevelForgeProto(int refinedTimes,
            Quality quality, StatType statType, UpgradeData upgradeData){

        SingleAddedStatGroup addedStatData = addedStatGroup.get(statType);
        if (addedStatData == null){
            return null;
        }

        RefinedData refinedData = getRefinedData(refinedTimes);
        SingleAddedStat addedData = addedStatData.getAddedStat(quality);

        int intQuality = quality.getNumber();

        SingleSpriteStat baseStat = Utils.getValidObject(baseStats, intQuality);
        int baseFightingAmount = FightData.calculateFightingAmount(baseStat);
        SingleStatProto baseStatProto = Utils.getValidObject(baseStatProtos,
                intQuality);
        int bestRefinedFightingAmount = maxRefinedData
                .getRefinedFightingAmount(intQuality);

        return EquipmentLevelForgeProto
                .newBuilder()
                .setData(proto)
                .setRefinedTimes(refinedData.refinedTimes)
                .setRefinedStat(refinedData.getRefinedStatProto(intQuality))
                .setRefinedFightingAmount(
                        refinedData.getRefinedFightingAmount(intQuality))
                .setQuality(intQuality).setAddedStat(addedData.addedStatProto)
                .setAddedFightingAmount(addedData.addedFightingAmount)
                .setAddedStatType(addedStatData.statType.getNumber())
                .setCost(upgradeData.getProto()).setBaseStat(baseStatProto)
                .setBaseFightingAmount(baseFightingAmount)
                .setBestRefinedFightingAmount(bestRefinedFightingAmount)
                .build();
    }
//    public class UpgradeLevelData{
//        final RefinedData refinedData;
//
//        final AddedData addedData;
//
//        final EquipmentForgeData forgeData;
//
//        transient final byte[] levelProtoData;
//
//        transient final ChannelBuffer upgradeLevelMsg;
//
//        private UpgradeLevelData(RefinedData refinedData, AddedData addedData,
//                EquipmentForgeData forgeData){
//            this.refinedData = refinedData;
//            this.addedData = addedData;
//            this.forgeData = forgeData;
//
//            levelProtoData = upgradeLevelProto.toByteArray();
//            upgradeLevelMsg = EquipmentMessages
//                    .getUpgradeLevelDataMsg(upgradeLevelProto);
//        }
//
//        public byte[] getUpgradeLevelData(){
//            return levelProtoData;
//        }
//
//        public ChannelBuffer getUpgradeLevelMsg(){
//            return upgradeLevelMsg;
//        }
//
//        public EquipmentForgeData getForgeData(){
//            return forgeData;
//        }
//    }
}
