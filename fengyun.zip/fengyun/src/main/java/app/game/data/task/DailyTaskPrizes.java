package app.game.data.task;

import static com.mokylin.sink.util.Preconditions.checkArgument;
import static com.mokylin.sink.util.Preconditions.checkNotNull;

import java.util.List;
import java.util.Map;

import app.game.data.GameObjects;
import app.game.data.Prize;
import app.game.data.PrizeConfig;
import app.game.data.PrizeConfigs;
import app.utils.VariableConfig;

import com.google.common.collect.Maps;
import com.google.inject.Inject;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class DailyTaskPrizes{

    private static final String LOCATION = "config/data/task/daily_task_prize.txt";

    private final Map<String, DailyTaskPrize> prizeMap;

    private final Prize extraPrize;

    @Inject
    DailyTaskPrizes(GameObjects go, PrizeConfigs prizes,
            VariableConfig variableConfig){

        // 日常额外奖励
        PrizeConfig extraPrizeConfig = checkNotNull(
                prizes.get(variableConfig.DAILY_TASK_EXTRA_PRIZE_NAME),
                "日常任务没有配置日常任务额外奖励，prizeName: %s",
                variableConfig.DAILY_TASK_EXTRA_PRIZE_NAME);

        checkArgument(!extraPrizeConfig.isVarPrize(),
                "日常任务额外奖励中配置了随机属性的物品");

        checkArgument(!extraPrizeConfig.hasExipreTimeGoods(),
                "日常任务额外奖励中配置了有过期时间的物品");

        checkArgument(!extraPrizeConfig.hasUnbindedGoods(),
                "日常任务额外奖励中配置了非绑定的物品");

        checkArgument(!extraPrizeConfig.isRaceDiff(), "日常任务额外奖励中配置了跟职业相关的物品");

        extraPrize = extraPrizeConfig.random();

        List<ObjectParser> data = go.loadFile(LOCATION);
        checkArgument(!data.isEmpty(), "日常任务奖励没有配置");

        prizeMap = Maps.newHashMapWithExpectedSize(data.size());

        for (ObjectParser p : data){
            DailyTaskPrize prize = new DailyTaskPrize(p, prizes, extraPrize);
            checkArgument(prizeMap.put(prize.name, prize) == null,
                    "日常任务奖励名称重复，name: %s", prize.name);
        }
    }

    DailyTaskPrize get(String name){
        return prizeMap.get(name);
    }

    Prize getExtrPrize(){
        return extraPrize;
    }
}
