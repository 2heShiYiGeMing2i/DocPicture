/**
 * 
 */
package app.game.data.scene;

import static com.mokylin.sink.util.Preconditions.checkArgument;

import java.util.List;
import java.util.Map;

import app.game.data.GameObjects;
import app.game.shop.Shops;
import app.protobuf.ConfigContent.NpcConfig;

import com.google.common.collect.Maps;
import com.google.inject.Inject;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 * 
 */
public class Npcs{

    public static final String LOCATION = GameObjects.SCENE_BASE_FOLDER
            + "npc.txt";

    private final int START_ID;

    private final int END_ID;

    public final int maxUseNpcId;

    private final Npc[] npcs;

    private final Map<String, Npc> npcNameMap;

    @Inject
    Npcs(GameObjects go, SceneDatas sceneDatas, Shops shops){
        List<ObjectParser> data = go.loadFile(LOCATION);

        START_ID = sceneDatas.maxUseSceneObjectID + 1;

        maxUseNpcId = sceneDatas.maxUseSceneObjectID = END_ID = START_ID
                + data.size();
        npcs = new Npc[data.size()];
        npcNameMap = Maps.newHashMapWithExpectedSize(data.size());

        int idCounter = START_ID;
        for (ObjectParser p : data){
            Npc npc = new Npc(go, p, idCounter++, sceneDatas, shops);
            npcs[npc.id - START_ID] = npc;
            checkArgument(npcNameMap.put(npc.name, npc) == null,
                    "NPC %s 名字存在重复", npc.name);
        }

    }

    public Npc get(int id){
        if (id >= START_ID && id < END_ID){
            return npcs[id - START_ID];
        }

        return null;
    }

    public Npc get(String name){
        return npcNameMap.get(name);
    }

    public NpcConfig generateProto(){
        NpcConfig.Builder builder = NpcConfig.newBuilder();

        for (Npc npc : npcs){
            builder.addNpc(npc.encode());
        }

        return builder.build();
    }
}
