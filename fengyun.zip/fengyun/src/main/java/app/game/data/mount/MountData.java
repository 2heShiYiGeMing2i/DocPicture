package app.game.data.mount;

import static com.mokylin.sink.util.Preconditions.*;

import java.util.List;
import java.util.Map;

import org.jboss.netty.buffer.ChannelBuffer;
import org.joda.time.DateTimeConstants;

import app.game.data.SpriteStat;
import app.game.data.SpriteStats;
import app.game.data.UpgradeData;
import app.game.data.goods.GoodsData;
import app.game.data.goods.GoodsDatas;
import app.game.data.goods.PanelGoodsData;
import app.game.data.mount.MountAddedDatas.MountAddedData;
import app.game.data.mount.MountDatas.MountLevelData;
import app.game.data.mount.MountDatas.MountLevelDatas;
import app.game.module.MountMessages;
import app.game.module.scene.FightData;
import app.game.shop.VendingMachine;
import app.protobuf.ConfigContent.MountDataProto;
import app.protobuf.GoodsContent.PanelGoodsDataProto.PanelType;
import app.utils.VariableConfig;

import com.google.common.collect.Lists;
import com.google.protobuf.ByteString;
import com.mokylin.collection.IntPair;
import com.mokylin.sink.util.IntWeightedRandomer;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * 坐骑数据
 * @author Liwei
 *
 */
public class MountData{

    /**
     * 坐骑阶级，1阶为1,2阶为2
     */
    final int id;

    /**
     * 坐骑名字
     */
    final String name;

    /**
     * 基础属性
     */
    final SpriteStat baseStat;

    /**
     * 基础战斗力
     */
    final transient int fightingAmount;

    /**
     * 坐骑等级数据
     */
    final MountAddedDatas addedDatas;

    /**
     * 有效期，单位毫秒，0表示永久有效
     */
    final long duration;

    transient final boolean hasExpiredTime;

    // 坐骑进阶

    final UpgradeData upgradeData;

    /**
     * 进阶成功后是否广播全服
     */
    final boolean isUpgradeBroadcast;

    // ---------- 坐骑技能 ----------

    /**
     * 技能槽开放个数
     */
    final int spellSlotCount;

    final transient IntWeightedRandomer spellSlotRandomer;

    /**
     * 开放这一阶坐骑的间隔，单位分钟
     */
    private final long openMountInterval;

    /**
     * 开放这一阶坐骑的时间（毫秒数），数据可以由后台修改
     */
    volatile long openMountTime;

    // ----------

    /**
     * 切换坐骑消息
     */
    private final transient ChannelBuffer upMountMsg;

    private final transient ChannelBuffer upgradeSuccessMsg;

    MountLevelDatas levelAddedDatas;

    MountData nextLevel;

    MountData(int id, ObjectParser p, SpriteStats spriteStats,
            GoodsDatas goodsDatas, Map<String, MountAddedDatas> levelDataMap,
            VendingMachine systemShop){
        this.id = id;

        checkArgument(id < 16, "在坐骑排行榜中用了位移处理坐骑ID，因此如果坐骑阶数超过15阶，需要同时修改排行榜");

        name = p.getKey("name");
        checkArgument(!name.isEmpty(), "%s 坐骑的名字没有配置", id);

        int statId = p.getIntKey("base_stat");
        baseStat = checkNotNull(spriteStats.get(statId), "没有找到%s 坐骑的基础属性-%s",
                name, statId);
        fightingAmount = FightData.calculateFightingAmount(baseStat);

        addedDatas = checkNotNull(levelDataMap.get(name), "没有找到%s 坐骑的等级数据",
                name);

        for (MountAddedData addedData : addedDatas.datas){
            addedData.baseAndAddedStat = baseStat.add(addedData.addedStat);
            addedData.baseAndAddedFightingAmount = fightingAmount
                    + addedData.addedFightingAmount;
        }

//        if (id == 1){
//            duration = VariableConfig.FIRST_MOUNT_EXPIRE_TIME;
//        } else{
//            duration = 0;
//        }
//        hasExpiredTime = duration > 0;
        // 他妹说坐骑不会过期了，我去年买了个表
        duration = 0;
        hasExpiredTime = false;

        upMountMsg = MountMessages.upMountMsg(id);
        upgradeSuccessMsg = MountMessages.upgradeSuccessMsg(id);

        // 坐骑进阶

        isUpgradeBroadcast = p.getBooleanKey("is_upgrade_broadcast");

        upgradeData = new UpgradeData(this, p, goodsDatas, systemShop);
        checkArgument(upgradeData.getUpgradeMoneyCost() > 0,
                "%s 中消耗物品没有配置银两消耗", this);

        upgradeData.setCustomAuctionType(GoodsData.MOUNT_AUCTION_TYPE);

        GoodsData upgradeGoods = upgradeData.getUpgradeGoods();

        checkArgument(
                (upgradeGoods instanceof PanelGoodsData)
                        && ((PanelGoodsData) upgradeGoods).getPanel() == PanelType.MOUNT,
                "坐骑进阶物品必须配置成面板类物品，并且双击打开的面板必须是坐骑面板，坐骑进阶物品：%s", upgradeGoods);

        checkArgument(upgradeData.getBaseBlessAmount() > 0, "坐骑-%s 的祝福值没有配置",
                this);

        checkArgument(upgradeData.getUpgradeMaxBless() > 0, "坐骑-%s 的最大祝福值没有配置",
                this);

        checkArgument(upgradeData.getBlessHoldTime() >= 0,
                "坐骑-%s 的祝福值保留时间没有配置", this);

        // 坐骑技能

        spellSlotCount = p.getIntKey("spell_slot_count");
        checkArgument(spellSlotCount >= 0
                && spellSlotCount <= VariableConfig.MOUNT_SPELL_SLOT_MAX_COUNT,
                "%s 坐骑技能开放个数配置错误, count: %s, 0 <= count <= %s", name,
                spellSlotCount, VariableConfig.MOUNT_SPELL_SLOT_MAX_COUNT);

        IntWeightedRandomer randomer = null;
        if (spellSlotCount > 0){
            String spellSlotRates = p.getKey("spell_slot_rates");
            String[] spellSlotRateArray = spellSlotRates.split(";");

            checkArgument(spellSlotCount == spellSlotRateArray.length,
                    "%s 坐骑技能随机位置的权重配置的个数与坐骑技能格子开放个数不同");

            List<IntPair> pairs = Lists
                    .newArrayListWithCapacity(spellSlotCount);
            for (int i = 0; i < spellSlotCount; i++){
                int weight = Integer.parseInt(spellSlotRateArray[i]);

                pairs.add(new IntPair(weight, i));
            }

            randomer = new IntWeightedRandomer(pairs);
        }

        spellSlotRandomer = randomer;

        // 坐骑开放时间
        openMountInterval = p.getIntKey("open_mount_interval");
        checkArgument(openMountInterval >= 0, "%s 开放时间必须大于等于0", this);

        openMountTime = ((long) openMountInterval)
                * DateTimeConstants.MILLIS_PER_MINUTE;
    }

    /**
     * id就是等级
     * @return
     */
    public int getId(){
        return id;
    }

    public boolean isUpgradeBroadcast(){
        return isUpgradeBroadcast;
    }

    public long getDuration(){
        return duration;
    }

    public long getOpenTime(long startServiceTime){
        if (openMountTime > 0){
            return startServiceTime + openMountTime;
        }
        return 0;
    }

    public int getSpellSlotCount(){
        return spellSlotCount;
    }

    public int randomSpellSlot(){
        assert spellSlotCount > 0;

        return spellSlotRandomer.next();
    }

    public ChannelBuffer getUpMountMsg(){
        return upMountMsg;
    }

    public ChannelBuffer getUpgradeSuccessMsg(){
        return upgradeSuccessMsg;
    }

    public HeroMount newMount(long buyTime, int level){
        HeroMount mount = new HeroMount(buyTime, this, level);
        mount.onStatChanged();
        return mount;
    }

    MountAddedData getAddedData(int level){
        return addedDatas.getAddedData(level);
    }

    MountLevelData getLevelData(int level){
        return levelAddedDatas.getLevelData(level);
    }

    public MountData getNextLevelData(){
        return nextLevel;
    }

    boolean isMaxLevel(){
        return nextLevel == null;
    }

    public UpgradeData getUpgradeData(){
        return upgradeData;
    }

    MountDataProto encode(){
        MountDataProto.Builder builder = MountDataProto.newBuilder();

        builder.setId(id).setName(ByteString.copyFromUtf8(name))
                .setBaseStat(baseStat.encode())
                .setMaxLevel(addedDatas.maxLevel)
                .setSpellSlotCount(spellSlotCount)
                .setFightingAmount(fightingAmount)
                .setUpgradeData(upgradeData.getProto());

        return builder.build();
    }

    @Override
    public String toString(){
        return id + "-" + name;
    }

}
