/**
 * 
 */
package app.game.data.goods;

import static app.game.module.GoodsContainerMessages.ERR_USE_TASK_BOOK_FAIL_ACCEPT_TIMES_LIMIT;
import static app.game.module.GoodsContainerMessages.ERR_USE_TASK_BOOK_FAIL_NOT_OPEN;
import static app.game.module.GoodsContainerMessages.ERR_USE_TASK_BOOK_FAIL_TASK_LIST_IS_FULL;
import static app.protobuf.LogContent.LogEnum.OperateType.GOODS_USE;
import app.game.data.GameObjects;
import app.game.data.task.HeroTaskList;
import app.game.data.task.TaskCallbackModule;
import app.game.entity.Hero;
import app.game.module.scene.HeroFightModule;
import app.message.ISender;
import app.protobuf.GoodsContent.GoodsDataProto;
import app.protobuf.GoodsServerContent.GoodsType;
import app.utils.VariableConfig;

import com.google.protobuf.ByteString;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * 任务卷轴
 * 
 * @author Liwei
 * 
 */
public class TaskBookData extends GoodsData{

    static final String LOCATION = GameObjects.GOODS_BASE_LOCATION
            + "task_book.txt";

    private final GoodsDataProto proto;

    private final byte[] protoBytes;

    private final ByteString protoByteString;

    private final TaskBookEfficacy efficacy;

    TaskBookData(ObjectParser p){
        super(p, GoodsType.TASK_BOOK);

        efficacy = new TaskBookEfficacy();

        proto = encode().build();
        protoBytes = processProtoBytes(proto.toByteArray());
        protoByteString = ByteString.copyFrom(protoBytes);
    }

    public GoodsDataProto getProto(){
        return proto;
    }

    @Override
    public byte[] getProtoBytes(){
        return protoBytes;
    }

    @Override
    public ByteString getProtoByteString(){
        return protoByteString;
    }

    @Override
    public int getAuctionType(){
        return 122;
    }

    @Override
    public Efficacy getEfficacy(){
        return efficacy;
    }

    @Override
    public boolean bulkUseable(){
        return true;
    }

    private class TaskBookEfficacy implements Efficacy{

        @Override
        public int useTo(HeroFightModule heroFightModule, int useCount,
                long ctime, String iEventId){
            Hero hero = heroFightModule.getHero();
            ISender sender = heroFightModule.getSender();

            HeroTaskList taskList = hero.getTaskList();

            // 检测是否完成了第二章主线任务
            if (!taskList.chanceTaskAccaptable()){
                logger.warn("使用任务卷轴，但是还未完成第二章主线任务");
                sender.sendMessage(ERR_USE_TASK_BOOK_FAIL_NOT_OPEN);
                return 0;
            }

            int vipExtraCount = 0;
            if (hero.getVip() != null){
                vipExtraCount = hero.getVip().getChanceTaskExtraAcceptCount();
            }

            // 检测任务卷轴今天使用次数是否已达上限
            int acceptRemaineTimes = VariableConfig.CHANCE_TASK_ACCEPTABLE_COUNT
                    + vipExtraCount - taskList.getChanceTaskAccaptedCount();
            if (acceptRemaineTimes <= 0){
                logger.warn("使用任务卷轴，今日接受机缘任务次数已达上限");
                sender.sendMessage(ERR_USE_TASK_BOOK_FAIL_ACCEPT_TIMES_LIMIT);
                return 0;
            }

            // 检测任务列表是否已满
            int taskListRemaineCount = VariableConfig.CHANCE_TASK_MAX_COUNT
                    - taskList.getChanceTaskListCount();
            if (taskListRemaineCount <= 0){
                logger.warn("使用任务卷轴，机缘任务列表已满");
                sender.sendMessage(ERR_USE_TASK_BOOK_FAIL_TASK_LIST_IS_FULL);
                return 0;
            }

            // 计算可以接取任务的个数
            int acceptTaskCount = Math.min(useCount,
                    Math.min(acceptRemaineTimes, taskListRemaineCount));

            // 接任务
            TaskCallbackModule taskModule = heroFightModule.getServices()
                    .getModules().getTaskCallbackModule();
            if (taskModule != null)
                taskModule.acceptChanceTask(getQuality(), acceptTaskCount,
                        hero, sender, GOODS_USE);

            return acceptTaskCount;
        }
    }
}
