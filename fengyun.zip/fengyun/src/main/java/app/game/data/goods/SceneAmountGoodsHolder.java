package app.game.data.goods;

import static app.protobuf.LogContent.LogEnum.OperateType.SCENE_GOODS_PICK_UP;

import org.jboss.netty.buffer.ChannelBuffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.module.scene.HeroFightModule;
import app.protobuf.GoodsServerContent.GoodsType;

import com.mokylin.sink.util.BufferUtil;

/**
 * @author Liwei
 *
 */
public abstract class SceneAmountGoodsHolder implements SceneGoodsHolder{
    private static final Logger logger = LoggerFactory
            .getLogger(SceneAmountGoodsHolder.class);

    public static SceneGoodsHolder newMoneyHolder(int amount,
            boolean ignoreOwner){
        return new SceneMoneyGoodsHolder(amount, ignoreOwner);
    }

//    
//    public static SceneGoodsHolder newExpHolder(int amount){
//        return new AmountGoodsHolder(GoodsType.EXP_GOODS, amount);
//    }
//
//    public static SceneGoodsHolder newRealAirHolder(int amount){
//        return new AmountGoodsHolder(GoodsType.REAL_AIR_GOODS, amount);
//    }
//
//    public static SceneGoodsHolder newLijinHolder(int amount){
//        return new AmountGoodsHolder(GoodsType.LIJIN_GOODS, amount);
//    }
//
//    public static SceneGoodsHolder newYuanbaoHolder(int amount){
//        return new AmountGoodsHolder(GoodsType.YUANBAO_GOODS, amount);
//    }

    private final GoodsType type;

    protected final int amount;

    private final boolean ignoreOwner;

    SceneAmountGoodsHolder(GoodsType type, int amount, boolean ignoreOwner){
        this.type = type;
        this.amount = amount;
        this.ignoreOwner = ignoreOwner;
    }

    @Override
    public boolean ignoreOwner(){
        return ignoreOwner;
    }

    @Override
    public void writeTo(ChannelBuffer buffer){
        BufferUtil.writeFalse(buffer);
        BufferUtil.writeVarInt32(buffer, type.getNumber());
        BufferUtil.writeVarInt32(buffer, amount);
    }

    public int getAmount(){
        return amount;
    }

    public GoodsType getGoodsType(){
        return type;
    }

    public static SceneAmountGoodsHolder decode(GoodsType type, int amount){
        switch (type){
            case MONEY_GOODS:
                return new SceneMoneyGoodsHolder(amount, true);

            default:{
                logger.error(
                        "SceneAmountGoodsHolder.decode时, 发现没有处理的GoodsType: {}-{}",
                        type, type.getNumber());
                return null;
            }
        }
    }

    private static class SceneMoneyGoodsHolder extends SceneAmountGoodsHolder{

        SceneMoneyGoodsHolder(int amount, boolean ignoreOwner){
            super(GoodsType.MONEY_GOODS, amount, ignoreOwner);
        }

        @Override
        public boolean canAddTo(HeroFightModule hfm){
            return true;
        }

        @Override
        public void give(HeroFightModule hfm){
            hfm.getHeroMiscModule().addMoneyAnyway(
                    (int) (amount * hfm.getHero().getFangChenMiMultiple()),
                    SCENE_GOODS_PICK_UP, null);
        }

        @Override
        public boolean needLog(){
            return false;
        }

//        @Override
//        public void doLog(OperateType type, OperateLogEvent e){
//            throw new UnsupportedOperationException();
//        }
    }

}
