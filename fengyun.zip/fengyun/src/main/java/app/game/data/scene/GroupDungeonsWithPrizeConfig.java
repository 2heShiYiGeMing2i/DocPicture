package app.game.data.scene;

import com.google.inject.Inject;
import com.mokylin.collection.IntHashMap;

/**
 * 有组队副本统一奖励的副本, 都在这里
 * @author Timmy
 *
 */
public class GroupDungeonsWithPrizeConfig{

    private final IntHashMap<GroupDungeonPrizeConfig> prizeConfigs;

    @Inject
    GroupDungeonsWithPrizeConfig(SceneDatas sceneDatas){
        this.prizeConfigs = new IntHashMap<>();

        for (SceneData sceneData : sceneDatas.getAll()){
            if (sceneData instanceof GroupDungeonSceneData){
                GroupDungeonSceneData groupSceneData = (GroupDungeonSceneData) sceneData;

                // 把有组队完成奖励的放在map里
                if (groupSceneData.getPrizeConfig() != null){
                    this.prizeConfigs.put(sceneData.id,
                            groupSceneData.getPrizeConfig());
                }
            }
        }
    }

    public GroupDungeonPrizeConfig get(int id){
        return prizeConfigs.get(id);
    }
}
