package app.game.data.scene;

import com.mokylin.sink.util.RandomNumber;
import com.mokylin.sink.util.parse.ObjectParser;

public class PortalDungeonPortal{

    /**
     * 总的index. 从0开始
     */
    public final int index;

    /**
     * 层数 从0开始
     */
    public final int level;

    /**
     * 在这一层中的index. 从0开始
     */
    public final int levelIndex;
    public final int sourceX;
    public final int sourceY;

    PortalDungeonPortal(int index, int levelIndex, ObjectParser p){
        this.index = index;
        this.levelIndex = levelIndex;
        this.level = p.getIntKey("level");
        this.sourceX = p.getIntKey("x");
        this.sourceY = p.getIntKey("y");
    }

    /**
     * 根据生门所在的pos, 得到这个传送门的类型
     * @param rightPos
     * @return
     */
    public PortalType getPortalType(int rightPos){
        int pos = (levelIndex - rightPos + PortalDungeonSceneData.EACH_LEVEL_PORTAL_COUNT)
                % PortalDungeonSceneData.EACH_LEVEL_PORTAL_COUNT;
        return PORTAL_TYPE_ARRAY[pos];
    }

    private static final PortalType[] PORTAL_TYPE_ARRAY = PortalType.class
            .getEnumConstants();

    public enum PortalType{
        /**
         * 生门, 必定+1层
         */
        SHENG {
            @Override
            public int getLevelChange(){
                return 1;
            }
        },

        /**
         * 伤门, 随机掉3-4层
         */
        SHANG {
            @Override
            public int getLevelChange(){
                return RandomNumber.getRate() < 50 ? -3 : -4;
            }
        },

        /**
         * 杜门, 随机掉1-2层
         */
        DU {
            @Override
            public int getLevelChange(){
                return RandomNumber.getRate() < 50 ? -1 : -2;
            }
        },

        /**
         * 景门, 随机掉1-2层
         */
        JING3 {
            @Override
            public int getLevelChange(){
                return RandomNumber.getRate() < 50 ? -1 : -2;
            }
        },

        /**
         * 死门, 必定倒退回1层
         */
        SI {
            @Override
            public int getLevelChange(){
                return -PortalDungeonSceneData.LEVEL_COUNT;
            }
        },

        /**
         * 惊门, 随机掉3-4层
         */
        JING1 {
            @Override
            public int getLevelChange(){
                return RandomNumber.getRate() < 50 ? -3 : -4;
            }
        },

        /**
         * 开门, 随机掉0-1层
         */
        KAI {
            @Override
            public int getLevelChange(){
                return RandomNumber.getRate() < 50 ? 0 : -1;
            }
        },

        /**
         * 休门, 随机掉0-1层
         */
        XIU {
            @Override
            public int getLevelChange(){
                return RandomNumber.getRate() < 50 ? 0 : -1;
            }
        };

        public abstract int getLevelChange();

    }
}
