package app.game.data.exam;

import static com.mokylin.sink.util.Preconditions.*;

import java.util.List;
import java.util.Random;

import app.game.data.ActivityPayback;
import app.game.data.ActivityPaybacks;
import app.game.data.GameObjects;
import app.game.data.PrizeConfigs;
import app.game.data.TimeData;
import app.game.data.exam.ExamQuestionData.ExamQuestion;
import app.game.data.goods.Goods;
import app.game.data.goods.GoodsDatas;
import app.game.data.goods.GoodsRandomer;
import app.protobuf.ConfigContent.DailyActivityType;
import app.protobuf.ConfigContent.ExamConfig;
import app.utils.VariableConfig;

import com.google.common.collect.Lists;
import com.google.inject.Inject;
import com.mokylin.collection.IntArrayList;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class ExamDatas{

    private static final String LOCATION = "config/data/system/exam.txt";

    public final int startHour;

    public final int startMinute;

    public final long duration;

    public final int EXAM_KEY;

    private final ExamQuestionData[] datas;

    private final GoodsRandomer top1GoodsRandomer;
    private final GoodsRandomer top2GoodsRandomer;
    private final GoodsRandomer top3GoodsRandomer;
    private final GoodsRandomer top20GoodsRandomer;

    private final int examCountPerTimes;

    @Inject
    ExamDatas(GameObjects go, GoodsDatas goods, VariableConfig config,
            PrizeConfigs prizes, ActivityPaybacks paybacks){
        examCountPerTimes = config.EXAM_QUESTION_COUNT;

        duration = VariableConfig.EXAM_WAIT_TIME
                + ((VariableConfig.EXAM_ANSWER_TIME + VariableConfig.EXAM_SHOW_ANSWER_TIME) * examCountPerTimes)
                - VariableConfig.EXAM_SHOW_ANSWER_TIME;

        startHour = config.EXAM_START_TIME / 100;
        startMinute = config.EXAM_START_TIME % 100;
        checkArgument(startHour >= 0 && startHour < 24 && startMinute >= 0
                && startMinute < 60, "答题系统开始时间配置无效, %s", config.EXAM_START_TIME);

        EXAM_KEY = (DailyActivityType.DA_EXAM_VALUE << 12)
                | config.EXAM_START_TIME;

        int endHour = config.EXAM_END_TIME / 100;
        int endMinus = config.EXAM_END_TIME % 100;
        checkArgument(endHour >= 0 && endHour < 24 && endMinus >= 0
                && endMinus < 60, "答题系统结束时间配置无效, %s", config.EXAM_END_TIME);

        List<ObjectParser> data = go.loadFile(LOCATION);
        checkArgument(examCountPerTimes <= data.size(), "答题系统题目个数必须大于等于 %s",
                examCountPerTimes);

        datas = new ExamQuestionData[data.size()];
        int idx = 0;
        List<String> wrongAnswerList = Lists.newArrayList();
        for (ObjectParser p : data){
            datas[idx] = new ExamQuestionData(idx, p, wrongAnswerList);
            idx++;
        }

        top1GoodsRandomer = GoodsRandomer.newRandomer("答题top1",
                config.EXAM_TOP1_PRIZE_GOODS, goods);
        top2GoodsRandomer = GoodsRandomer.newRandomer("答题top2",
                config.EXAM_TOP2_PRIZE_GOODS, goods);
        top3GoodsRandomer = GoodsRandomer.newRandomer("答题top3",
                config.EXAM_TOP3_PRIZE_GOODS, goods);
        top20GoodsRandomer = GoodsRandomer.newRandomer("答题top20",
                config.EXAM_TOP20_PRIZE_GOODS, goods);

        TimeData timeData = TimeData.parse("[*][*][*][" + startHour + ":"
                + startMinute + "]");

        ActivityPayback payback = checkNotNull(
                paybacks.get(DailyActivityType.DA_EXAM), "答题活动买回没有配置");
        payback.setTimeData(timeData);
    }

    public ExamQuestion[] randomQuestion(Random random, IntArrayList indexList){
        Utils.randomRoundIndex(random, indexList, datas.length,
                examCountPerTimes);

        int[] array = new int[examCountPerTimes];
        for (int i = 0; i < examCountPerTimes; i++){
            array[i] = indexList.get(i);
        }

        ExamQuestion[] questions = new ExamQuestion[array.length];
        for (int i = 0; i < array.length; i++){
            questions[i] = datas[array[i]].random(random, indexList);
        }

        return questions;
    }

    public int getExamCountPerTimes(){
        return examCountPerTimes;
    }

    public Goods newTopPrize(int rankPos, long ctime){
        switch (rankPos){
            case 0:{
                return top1GoodsRandomer.create(ctime);
            }
            case 1:{
                return top2GoodsRandomer.create(ctime);
            }
            case 2:{
                return top3GoodsRandomer.create(ctime);
            }
            default:{
                return top20GoodsRandomer.create(ctime);
            }
        }
    }

    public ExamConfig encode(VariableConfig config){
        ExamConfig.Builder builder = ExamConfig
                .newBuilder()
                .setWaitTime(VariableConfig.EXAM_WAIT_TIME)
                .setAnswerTime(VariableConfig.EXAM_ANSWER_TIME)
                .setShowAnswerTime(VariableConfig.EXAM_SHOW_ANSWER_TIME)
                .setQuestionCount(config.EXAM_QUESTION_COUNT)
                .setRequireLevel(config.EXAM_REQUIRE_LEVEL)
                .setDoubleScoreMaxTimes(config.EXAM_DOUBLE_SCORE_MAX_TIMES)
                .setRemoveWrongAnswerTimes(
                        config.EXAM_REMOVE_WRONG_ANSWERT_MAX_TIMES)
                .setStartTime(config.EXAM_START_TIME)
                .setEndTime(config.EXAM_END_TIME)
                .setTop1Goods(top1GoodsRandomer.getData().getProtoByteString())
                .setTop2Goods(top2GoodsRandomer.getData().getProtoByteString())
                .setTop3Goods(top3GoodsRandomer.getData().getProtoByteString())
                .setTop20Goods(
                        top20GoodsRandomer.getData().getProtoByteString());

        return builder.build();
    }
}
