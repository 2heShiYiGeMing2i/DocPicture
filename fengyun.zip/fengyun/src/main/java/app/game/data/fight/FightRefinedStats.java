package app.game.data.fight;

import static com.mokylin.sink.util.Preconditions.*;

import java.util.List;

import app.game.data.GameObjects;
import app.game.data.SpriteStat;
import app.game.data.SpriteStats;

import com.google.inject.Inject;
import com.mokylin.sink.util.RandomNumber;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class FightRefinedStats{

    private static final String LOCATION = "config/data/fight/fight_refined_stats.txt";

    private static final int REFINED_MAX_RATE = 10000;

    private final int[] refinedRate;

    private final SpriteStat[] refinedStats;

    @Inject
    FightRefinedStats(GameObjects go, SpriteStats spriteStats){

        List<ObjectParser> data = go.loadFile(LOCATION);
        checkArgument(!data.isEmpty(), "个人竞技场鼓舞属性表没有配置数据");

        refinedRate = new int[data.size()];
        refinedStats = new SpriteStat[data.size()];
        int i = 0;
        for (ObjectParser p : data){

            refinedRate[i] = p.getIntKey("refined_rate");
            checkArgument(refinedRate[i] >= 0
                    && refinedRate[i] <= REFINED_MAX_RATE,
                    "个人竞技场%s 的鼓舞概率无效[0-10000]， %s", i + 1, refinedRate[i]);

            int statId = p.getIntKey("sprite_stat");
            refinedStats[i] = checkNotNull(spriteStats.get(statId),
                    "个人竞技场%s 的鼓舞属性没找到， %s", i + 1, statId);

            i++;
        }
    }

    public int size(){
        return refinedStats.length;
    }

    public SpriteStat get(int id){
        assert id > 0: "SingleFightRefinedDatas.get(i) i<=0";
        return Utils.getValidObject(refinedStats, id - 1);
    }

    public boolean tryRate(int id){
        if (id >= 0 && id < refinedRate.length){
            return RandomNumber.getRate(REFINED_MAX_RATE, true) < refinedRate[id];
        }

        return false;
    }
}
