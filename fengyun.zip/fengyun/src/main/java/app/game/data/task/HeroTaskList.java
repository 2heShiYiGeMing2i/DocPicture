package app.game.data.task;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.data.ConfigService;
import app.game.data.Prize;
import app.game.data.Race;
import app.game.data.goods.Goods;
import app.protobuf.GoodsServerContent.GoodsServerProto;
import app.protobuf.HeroServerContent.ChanceTaskServerProto;
import app.protobuf.HeroServerContent.ChapterTaskServerProto;
import app.protobuf.HeroServerContent.DailyTaskServerProto;
import app.protobuf.HeroServerContent.GuildTaskServerProto;
import app.protobuf.HeroServerContent.TaskServerProto;
import app.protobuf.TaskContent.HeroTaskProto;
import app.utils.VariableConfig;

import com.google.common.collect.Lists;
import com.mokylin.collection.IntHashMap;
import com.mokylin.collection.ReusableIterator;
import com.mokylin.sink.util.Utils;

/**
 * @author Liwei
 *
 */
public class HeroTaskList{

    private static final Logger logger = LoggerFactory
            .getLogger(HeroTaskList.class);

    public static HeroTaskList newHeroTaskList(int maxUseTaskId,
            ChapterTaskData firstChapterTask){
        HeroTaskList taskList = new HeroTaskList(maxUseTaskId);
        taskList.doingChapterTask = firstChapterTask.newEmptyTask();

        // 机缘任务和日常任务在创建英雄时是没有任务的

        return taskList;
    }

    private int taskIdCounter;

    // 剧情任务
    ChapterTask doingChapterTask;

    // 保存最后完成的剧情任务的章节和索引
    int lastCompletedChanpterAndIndex;

    // 机缘任务
    int chanceTaskSwallowedCount;

    int chanceTaskAcceptedCount;

    final int[] autoCompleteCount;

    final IntHashMap<ChanceTask> chanceTaskMap;

    final ReusableIterator<ChanceTask> chanceTaskIterator;

    // 日常任务
    int dailyTaskRound;

    DailyTask doingDailyTask;

    // 帮派任务

    int guildTaskRound;

    GuildTask doingGuildTask;

    private final List<Goods> taskGoodsList;

    private HeroTaskList(int maxUseTaskId){
        taskIdCounter = maxUseTaskId;
        autoCompleteCount = new int[ChanceTaskDatas.QUALITY_COUNT];
        chanceTaskMap = new IntHashMap<>();
        chanceTaskIterator = chanceTaskMap.newValueIterator();
        taskGoodsList = Lists
                .newArrayListWithCapacity(VariableConfig.TASK_GOODS_MAX_COUNT);
        dailyTaskRound = 1;
        guildTaskRound = 1;
    }

    public void resetDailyStaticstics(int level, TaskDatas taskDatas,
            boolean hasGuild){
        // 重置机缘任务次数
        chanceTaskSwallowedCount = 0;
        chanceTaskAcceptedCount = 0;
        for (int i = 0; i < autoCompleteCount.length; i++){
            autoCompleteCount[i] = 0;
        }

        // 重置日常任务
        dailyTaskRound = 1;
        doingDailyTask = null;
        if (level >= VariableConfig.DAILY_TASK_ACCEPT_LEVEL){
            DailyTaskData data = taskDatas.getDailyTaskDatas().random(level);
            doingDailyTask = data.newEmptyTask(newTaskId());
        }

        // 重置帮派任务
        guildTaskRound = 1;
        doingGuildTask = null;
        if (hasGuild && level >= VariableConfig.GUILD_TASK_ACCEPT_LEVEL){
            GuildTaskData data = taskDatas.getGuildTaskDatas().random(level);
            doingGuildTask = data.newEmptyTask(newTaskId());
        }
    }

    public int getTaskGoodsCount(){
        return taskGoodsList.size();
    }

    public List<Goods> getTaskGoodsList(){
        return taskGoodsList;
    }

    public ChapterTask getDoingChapterTask(){
        return doingChapterTask;
    }

    public boolean chanceTaskAccaptable(){

        // 完成第二章主线任务
        if (doingChapterTask != null){
            if (doingChapterTask.getChapter() >= VariableConfig.CHANCE_TASK_ACCEPTED_MIN_CHAPTER){
                return true;
            }
            return false;
        }

        if (Utils.getHighShort(lastCompletedChanpterAndIndex) >= VariableConfig.CHANCE_TASK_ACCEPTED_MIN_CHAPTER){
            return true;
        }

        return false;
    }

    public int getChanceTaskAccaptedCount(){
        return chanceTaskAcceptedCount;
    }

    public int getChanceTaskSwalowedCount(){
        return chanceTaskSwallowedCount;
    }

    public int incrementSwallowedCount(){
        return ++chanceTaskSwallowedCount;
    }

    public int getChanceTaskListCount(){
        return chanceTaskMap.size();
    }

    public boolean canAutoCompleteChanceTask(ChanceTask chanceTask){
        if (!chanceTask.isAutoCompleteTimesLimit()){
            return true;
        }

        return autoCompleteCount[chanceTask.getQuality().getNumber()] < chanceTask
                .getAutoCompleteTimesLimit();
    }

    public int incrementAutoCompleteChanceTaskTimes(ChanceTask chanceTask){
        assert chanceTask.isAutoCompleteTimesLimit();

        return ++autoCompleteCount[chanceTask.getQuality().getNumber()];
    }

    public ChanceTask getChanceTask(int taskId){
        return chanceTaskMap.get(taskId);
    }

    public ChanceTask removeChanceTask(int taskId){
        return chanceTaskMap.remove(taskId);
    }

    public int getDailyTaskRound(){
        return dailyTaskRound;
    }

    public DailyTask getDoingDailyTask(){
        return doingDailyTask;
    }

    public void onCompleteAllDailyTask(){
        dailyTaskRound = VariableConfig.DAILY_TASK_MAX_ROUND + 1;
        doingDailyTask = null;
    }

    public int getGuildTaskRound(){
        return guildTaskRound;
    }

    public GuildTask getDoingGuildTask(){
        return doingGuildTask;
    }

    public void onHeroLeaveGuild(){
        // 移除当前正在做的帮派任务
        doingGuildTask = null;
    }

    public void onCompleteAllGuildTask(){
        guildTaskRound = VariableConfig.GUILD_TASK_MAX_ROUND + 1;
        doingGuildTask = null;
    }

    int newTaskId(){
        return ++taskIdCounter;
    }

    public HeroTaskProto encodeToSelfOnLogin(Race race){
        HeroTaskProto.Builder builder = HeroTaskProto.newBuilder();

        if (doingChapterTask != null){
            builder.setDoingChapterTask(doingChapterTask
                    .encodeToSelfOnLogin(race));
        }

        // 机缘任务
        builder.setChanceTaskAcceptedCount(chanceTaskAcceptedCount);
        builder.setChanceTaskSwallowedCount(chanceTaskSwallowedCount);
        for (int c : autoCompleteCount){
            builder.addChanceTaskAutoCompleteCount(c);
        }

        for (chanceTaskIterator.rewind(); chanceTaskIterator.hasNext();){
            ChanceTask chanceTask = chanceTaskIterator.next();
            builder.addChanceTask(chanceTask.encode4Client());
        }
        chanceTaskIterator.cleanUp();

        // 日常任务
        if (doingDailyTask != null){
            builder.setDoingDailyTask(doingDailyTask
                    .encode4Client(dailyTaskRound));
        }

        // 帮派任务
        if (doingGuildTask != null){
            builder.setDoingGuildTask(doingGuildTask
                    .encode4Client(guildTaskRound));
        }

        for (Goods g : taskGoodsList){
            builder.addTaskGoodsDatas(g.getData().getProtoByteString());
            builder.addTaskGoodsList(g.encodeByteString4Client());
        }

        return builder.build();
    }

    public TaskServerProto encode(){
        TaskServerProto.Builder builder = TaskServerProto.newBuilder();
        if (doingChapterTask != null){
            builder.setChapterTask(doingChapterTask.encode());
        }
        builder.setCompletedChapterTask(lastCompletedChanpterAndIndex);

        // 机缘任务
        builder.setChanceTaskAcceptedCount(chanceTaskAcceptedCount);
        builder.setChanceTaskSwallowedCount(chanceTaskSwallowedCount);
        for (int c : autoCompleteCount){
            builder.addChanceTaskAutoCompleteCount(c);
        }

        for (chanceTaskIterator.rewind(); chanceTaskIterator.hasNext();){
            ChanceTask chanceTask = chanceTaskIterator.next();
            builder.addChanceTask(chanceTask.encode());
        }
        chanceTaskIterator.cleanUp();

        // 日常任务
        builder.setDailyTaskRound(dailyTaskRound);
        if (doingDailyTask != null){
            builder.setDailyTask(doingDailyTask.encode());
        }

        // 帮派任务
        builder.setGuildTaskRound(guildTaskRound);
        if (doingGuildTask != null){
            builder.setGuildTask(doingGuildTask.encode());
        }

        for (Goods g : taskGoodsList){
            builder.addTaskGoods(g.encode());
        }

        return builder.build();
    }

    public static HeroTaskList decode(int level, Race race,
            TaskServerProto taskProto, ConfigService cs){

        TaskDatas taskDatas = cs.getTasks();

        int maxUseTaskId = taskDatas.getMaxUseTaskId();
        HeroTaskList taskList = new HeroTaskList(maxUseTaskId);

        taskList.lastCompletedChanpterAndIndex = taskProto
                .getCompletedChapterTask();

        if (taskProto.hasChapterTask()){

            ChapterTaskServerProto chapterTaskProto = taskProto
                    .getChapterTask();

            int chapter = chapterTaskProto.getChapter();
            int chapterIndex = chapterTaskProto.getIndex();

            ChapterTaskData chapterTaskData = taskDatas.getChapterTaskDatas()
                    .get(chapter, chapterIndex);

            if (chapterTaskData != null){
                taskList.doingChapterTask = ChapterTask.decode(chapterTaskData,
                        chapterTaskProto);
                // 如果任务已经完成了，则在第一次进入场景的时候处理
            }
        }

        if (taskList.doingChapterTask == null){
            // 英雄已经没有主线任务了，找一下策划是否配置了新的主线任务
            int chapter = Utils
                    .getHighShort(taskList.lastCompletedChanpterAndIndex);
            int chapterIndex = Utils
                    .getLowShort(taskList.lastCompletedChanpterAndIndex);

            ChapterTaskData chapterTaskData = taskDatas.getChapterTaskDatas()
                    .get(chapter, chapterIndex + 1);
            if (chapterTaskData != null){
                taskList.doingChapterTask = chapterTaskData.newEmptyTask();
            }
        }

        // 机缘任务
        taskList.chanceTaskAcceptedCount = taskProto
                .getChanceTaskAcceptedCount();
        taskList.chanceTaskSwallowedCount = taskProto
                .getChanceTaskSwallowedCount();
        int loopCount = Math.min(taskList.autoCompleteCount.length,
                taskProto.getChanceTaskAutoCompleteCountCount());
        for (int i = 0; i < loopCount; i++){
            taskList.autoCompleteCount[i] = taskProto
                    .getChanceTaskAutoCompleteCount(i);
        }

        loopCount = taskProto.getChanceTaskCount();
        for (int i = 0; i < loopCount; i++){
            ChanceTaskServerProto chanceTaskProto = taskProto.getChanceTask(i);
            ChanceTaskData chanceTaskData = taskDatas.getChanceTaskDatas().get(
                    chanceTaskProto.getChanceTaskId());

            if (chanceTaskData != null){
                Prize chanceTaskPrize = Prize.decode(
                        chanceTaskProto.getPrize(), cs);

                ChanceTask chanceTask = ChanceTask.decode(taskList.newTaskId(),
                        chanceTaskPrize, chanceTaskData, chanceTaskProto);
                taskList.chanceTaskMap.put(chanceTask.getTaskId(), chanceTask);
            } else{
                logger.error("英雄身上的机缘任务找不到，补偿一个, chanceTaskId: {}",
                        chanceTaskProto.getChanceTaskId());

                // 补偿一个英雄当前等级的任务
                chanceTaskData = taskDatas.getChanceTaskDatas()
                        .randomCompensateTask(level);
                ChanceTask chanceTask = chanceTaskData.newEmptyTask(
                        taskList.newTaskId(), race.getRaceId());
                taskList.chanceTaskMap.put(chanceTask.getTaskId(), chanceTask);
            }
        }

        // 日常任务
        taskList.dailyTaskRound = taskProto.getDailyTaskRound();

        if (taskProto.hasDailyTask()){
            DailyTaskServerProto dailyTaskProto = taskProto.getDailyTask();
            int dailyTaskId = dailyTaskProto.getDailyTaskId();
            int diffiStar = dailyTaskProto.getDiffiStar();
            int prizeStar = dailyTaskProto.getPrizeStar();

            DailyTaskData data = taskDatas.getDailyTaskDatas().get(dailyTaskId,
                    diffiStar, prizeStar);
            if (data != null){
                taskList.doingDailyTask = DailyTask.decode(
                        taskList.newTaskId(), data, dailyTaskProto);
            } else{
                logger.error("英雄身上的日常任务找不到，首次进场景时候补偿一个, dailyTaskId: {}",
                        dailyTaskId);
            }
        }

        // 帮派任务
        taskList.guildTaskRound = taskProto.getGuildTaskRound();

        if (taskProto.hasGuildTask()){
            GuildTaskServerProto guildTaskProto = taskProto.getGuildTask();
            int guildTaskId = guildTaskProto.getGuildTaskId();

            GuildTaskData data = taskDatas.getGuildTaskDatas().get(guildTaskId);
            if (data != null){
                taskList.doingGuildTask = GuildTask.decode(
                        taskList.newTaskId(), data, guildTaskProto);
            } else{
                logger.error("英雄身上的帮派任务找不到，首次进场景时候补偿一个, guildTaskId: {}",
                        guildTaskId);
            }
        }

        // 如果任务已经完成了，则在第一次进入场景的时候处理

        for (int i = 0; i < taskProto.getTaskGoodsCount(); i++){
            GoodsServerProto goodsProto = taskProto.getTaskGoods(i);
            Goods g = Goods.decodeDontCheck(goodsProto, cs);
            if (g == null)
                continue;

            taskList.taskGoodsList.add(g);
        }

        return taskList;
    }
}
