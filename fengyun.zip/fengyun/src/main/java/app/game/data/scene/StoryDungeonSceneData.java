package app.game.data.scene;

import static com.mokylin.sink.util.Preconditions.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.data.ConfigService;
import app.game.data.GameObjects;
import app.game.data.Prize;
import app.game.data.PrizeConfig;
import app.game.data.PrizeConfigs;
import app.game.data.Vip;
import app.game.data.goods.GoodsAddHelper;
import app.game.data.goods.GoodsDatas;
import app.game.data.goods.GoodsWrapper;
import app.game.entity.User;
import app.game.module.scene.IDungeonService;
import app.game.module.scene.StoryDungeonScene;
import app.game.service.log.LogService;
import app.protobuf.ConfigContent.StoryDungeonProto;
import app.protobuf.HeroContent.StoryDungeonCollectablePrizeProto;
import app.protobuf.HeroServerContent.GoodsWrapperServerProto;
import app.protobuf.LogContent.LogEnum.SceneType;
import app.utils.VariableConfig;

import com.google.protobuf.ByteString;
import com.mokylin.sink.util.Empty;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * 剧情副本配置
 * @author Timmy
 *
 */
public class StoryDungeonSceneData extends DungeonSceneData{
    private static final Logger logger = LoggerFactory
            .getLogger(StoryDungeonSceneData.class);

    private static final int PRIZE_SHOWN_COUNT = 4;

    public final int sequence;
    public final int prerequisite;

    public final boolean isCountWhenEnter;

    /**
     * 要杀的怪的怪物种类id (不是场景中的id), 对应要杀的数量
     */
    private final TargetCounter.Builder targetMonster;

    /**
     * 其他要在进度中展示的要杀的怪. 只有在要杀所有怪时才能配置
     */
    private final int[] targetMonsterIDForDisplay;

    private final boolean isKillAll;

    // --- 奖励 ---
    final Prize fixedPrize;

    public final int fixedPrizeGoodsCount;

    public final GoodsWrapper[] prizeFirst;

    private final PlunderGroup prizeS;

    private final PlunderGroup prizeV5;

    // --- 时间计分 ---

    public final int timeSSS;
    public final int timeSS;
    public final int timeS;
    public final int timeA;

    // ---

    private final String description;
    private final String prizeDescription;
    private final String backgroundImg;
    private final String nameImg;

    StoryDungeonSceneData(GameObjects go, ObjectParser p, BlockInfos blocks,
            MonsterDatas monsters, Scripts scripts, Plunders plunders, Ais ais,
            SceneTransportDatas transports, GoodsDatas goodsDatas,
            PlunderGroups groups, PrizeConfigs prizes,
            SceneRemoveObjectMsgCache removeMsgCache){
        super(go, p, blocks, monsters, scripts, plunders, ais, transports,
                removeMsgCache);

        this.description = p.getKey("description");
        this.prizeDescription = p.getKey("prize_description");
        this.backgroundImg = p.getKey("background_img");
        this.nameImg = p.getKey("name_img");

        this.sequence = p.getIntKey("sequence");
        this.prerequisite = p.getIntKey("prerequisite");
        this.isCountWhenEnter = p.getBooleanKey("is_count_when_enter");

        // 杀怪目标
        String target = p.getKey("target"); // 不填表示所有怪都要杀, 填了表示要杀叫这个名字的怪
        targetMonster = calculateTargetMonster(target);
        checkArgument(targetMonster.getTotalCount() > 0,
                "剧情副本 %s 没有找到通关要杀的怪: %s. 名字填错或者场景中没放怪?", this, target);

        // 额外要展示的杀怪目标
        String otherTarget = p.getKey("other_target");
        if (target.length() != 0){
            // 有特定要杀的怪, 不能再有额外的展示
            isKillAll = false;
            checkArgument(otherTarget.length() == 0,
                    "剧情副本 %s 配置了target, 不是所有的怪都杀, 就不能再配other_target", this);
            this.targetMonsterIDForDisplay = parseDisplayTargetMonster(target);
        } else{
            // 没有特定要杀的怪, 全杀, 可以有额外的展示
            isKillAll = true;
            this.targetMonsterIDForDisplay = parseDisplayTargetMonster(otherTarget);
        }
        checkArgument(targetMonsterIDForDisplay.length <= 31,
                "剧情副本 %s 最多只能显示追踪31种怪", this);

        // --- 通关时间分数段 ---
        this.timeSSS = p.getIntKey("time_sss");
        this.timeSS = p.getIntKey("time_ss");
        this.timeS = p.getIntKey("time_s");
        this.timeA = p.getIntKey("time_a");
        // 检查每个都要>0, 且大于前一等级的
        checkArgument(timeSSS > 0, "剧情副本 %s sss级评分的时间必须 > 0: %s", this.timeSSS);
        checkArgument(timeSS > timeSSS, "剧情副本 %s ss级评分的时间必须 > sss的", this);
        checkArgument(timeS > timeSS, "剧情副本 %s s级评分的时间必须 > ss的", this);
        checkArgument(timeA > timeS, "剧情副本 %s A级评分的时间必须 > s的", this);

        // --- 奖励 ---
        String fixedPrizeName = p.getKey("fixed_prize");
        PrizeConfig fixedPrizeConfig = checkNotNull(prizes.get(fixedPrizeName),
                "剧情副本 %s 配置的固定奖励没找到", this);

        checkArgument(!fixedPrizeConfig.hasExipreTimeGoods(),
                "剧情副本 %s 配置的固定奖励居然有过期时间", this);
        checkArgument(!fixedPrizeConfig.isRaceDiff(),
                "剧情副本 %s 配置的固定奖励居然跟职业相关的", this);
        checkArgument(!fixedPrizeConfig.isVarPrize(), "剧情副本 %s 配置的固定奖励居然是可变的",
                this);

        fixedPrize = fixedPrizeConfig.random();
        for (GoodsWrapper w : fixedPrize.getGoodsWrappers())
            w.cacheProto();

        fixedPrizeGoodsCount = fixedPrize.getGoodsWrappers().length;

        // s级奖励
        String plunderGroupStr = p.getKey("prize_s");
        prizeS = checkNotNull(groups.get(plunderGroupStr),
                "剧情副本 %s 的S级奖励组包没找到，%s", this, plunderGroupStr);
        checkArgument(prizeS.getGoodsRandomers().length >= PRIZE_SHOWN_COUNT,
                "剧情副本 %s 的s级奖励必须至少配%s个", this, PRIZE_SHOWN_COUNT);

        prizeS.initShowGoodsWrapper();

        // v5奖励
        plunderGroupStr = p.getKey("prize_v5");
        prizeV5 = checkNotNull(groups.get(plunderGroupStr),
                "剧情副本 %s 的V5奖励组包没找到，%s", this, plunderGroupStr);
        checkArgument(prizeV5.getGoodsRandomers().length >= PRIZE_SHOWN_COUNT,
                "剧情副本 %s 的V5奖励必须至少配%s个", this, PRIZE_SHOWN_COUNT);

        prizeV5.initShowGoodsWrapper();

        // 首通奖励
        String[] prizeGoodsStr = p.getStringArray("prize_first");
        this.prizeFirst = GoodsWrapper.parse(this, goodsDatas, prizeGoodsStr);
        for (GoodsWrapper w : prizeFirst)
            w.cacheProto();
    }

    public GoodsWrapper getRandomPrizeS(){
        return prizeS.randomGoodsWrapper();
    }

    public GoodsWrapper getRandomPrizeV5(){
        return prizeV5.randomGoodsWrapper();
    }

    public GoodsWrapper[] getRandomPrizeSAnd3More(){
        return prizeS.randomGoodsAndShowGoods(PRIZE_SHOWN_COUNT);
    }

    public GoodsWrapper[] getRandomPrizeV5And3More(){
        return prizeV5.randomGoodsAndShowGoods(PRIZE_SHOWN_COUNT);
    }

    public Prize getFixedPrize(){
        return fixedPrize;
    }

    private static GoodsWrapper decodeGoodsWrapper(ByteString bs,
            ConfigService configService){
        try{
            GoodsWrapperServerProto proto = GoodsWrapperServerProto.parseFrom(
                    bs, User.extensionRegistry);
            return GoodsWrapper.decode(proto, configService);
        } catch (Throwable ex){
            logger.error("StoryDungeonSceneData.decodeGoodsWrapper报错", ex);
            return null;
        }
    }

    public List<GoodsAddHelper> newPrizeGoods(
            StoryDungeonCollectablePrizeProto proto, Vip vip, long ctime,
            ConfigService configService){
        List<GoodsAddHelper> result = new ArrayList<>(fixedPrizeGoodsCount + 2
                + (proto.hasHasFirstPassPrize() ? prizeFirst.length : 0));

        for (GoodsWrapper w : fixedPrize.getGoodsWrappers()){
            result.add(w.newHelper(ctime));
        }

        if (vip != null && vip.hasStoryExtraPrize()){
            if (!proto.hasRandomedVipPrize()){
                result.add(prizeV5.randomHelper(ctime));
            } else{
                // 之前已经随出来了, decode
                GoodsWrapper gw = decodeGoodsWrapper(
                        proto.getRandomedVipPrize(), configService);
                if (gw != null){
                    result.add(gw.newHelper(ctime));
                } else{
                    result.add(prizeV5.randomHelper(ctime));
                }
            }
        }

        if (!proto.hasNoScoreSPrize()){
            if (!proto.hasRandomedSPrize()){
                result.add(prizeS.randomHelper(ctime));
            } else{
                // 之前已经随出来了
                GoodsWrapper gw = decodeGoodsWrapper(proto.getRandomedSPrize(),
                        configService);
                if (gw != null){
                    result.add(gw.newHelper(ctime));
                } else{
                    result.add(prizeS.randomHelper(ctime));
                }
            }
        }

        if (proto.hasHasFirstPassPrize()){
            for (GoodsWrapper w : prizeFirst){
                result.add(w.newHelper(ctime));
            }
        }

        return result;
    }

    public static StoryDungeonCollectablePrizeProto newCollectablePrizeProto(
            int id, long ctime){
        return StoryDungeonCollectablePrizeProto
                .newBuilder()
                .setDungeonId(id)
                .setExpireTime(
                        ctime
                                + VariableConfig.STORY_DUNGEON_COLLECTABLE_PRIZE_KEEP_TIME)
                .build();
    }

    public int[] getTargetMonsterIDForDisplay(){
        return targetMonsterIDForDisplay;
    }

    public int getTotalTargetMonsterCount(){
        return targetMonster.getTotalCount();
    }

    public TargetCounter newTargetCounter(){
        return targetMonster.build();
    }

    private int[] parseDisplayTargetMonster(String otherTarget){
        if (otherTarget.length() == 0){
            return Empty.INT_ARRAY;
        }
        String[] targets = otherTarget.split(";");
        // 检查不能重复
        checkArgument(!Utils.hasDuplicate(targets),
                "剧情副本 %s 需要额外显示的怪物进度追踪里有重复的怪物", this);

        int len = targets.length;
        int[] result = new int[len];
        for (int i = 0; i < len; i++){
            SceneMonsterData mon = getSingleLifeMonsterByName(targets[i]);
            checkNotNull(mon, "剧情副本 %s 需要额外显示的怪物进度追踪里的怪物没找到: %s", this,
                    targets[i]);
            result[i] = mon.getMonsterData().id;
        }

        return result;
    }

    private TargetCounter.Builder calculateTargetMonster(String target){
        final List<String> names;
        if (target.length() == 0){
            names = Collections.emptyList();
        } else{
            String[] str = target.split(";");
            names = Arrays.asList(str);
        }

        TargetCounter.Builder result = TargetCounter.newBuilder();
        SceneMonsterData[] monsterDatas = getSingleLifeMonsterDatas(); // 暂时副本里只能放不能重生的怪物

        for (SceneMonsterData mon : monsterDatas){
            if (names.size() == 0 // 表示要全杀
                    || names.contains(mon.getMonsterData().name)){
                result.increment(mon.getMonsterData().id);
            }
        }
        return result;
    }

    @Override
    public int getIntType(){
        return SceneType.STORY_DUNGEON.getNumber();
    }

    @Override
    public StoryDungeonScene newDungeon(int sceneID,
            IDungeonService dungeonService, LogService logService, long creator){
        return new StoryDungeonScene(this, sceneID, dungeonService, logService,
                creator);
    }

    public StoryDungeonProto generateProto(){
        StoryDungeonProto.Builder builder = StoryDungeonProto.newBuilder();
        builder.setSceneId(id).setMap(blockName)
                .setName(ByteString.copyFrom(nameBytes)).setSound(sound);
        if (requiredLevel > 1){
            builder.setRequiredLevel(requiredLevel);
        }
        if (isHeroLevelProtect){
            builder.setIsHeroLevelProtect(true);
        }
        if (isNewHeroProtect){
            builder.setIsNewHeroProtect(true);
        }
        if (isDeathProtect){
            builder.setIsDeathProtect(true);
        }
        if (isNightAutoProtect){
            builder.setIsNightAutoProtect(true);
        }
        if (isJumpLimit){
            builder.setIsJumpLimit(true);
        }
        if (isMountLimit){
            builder.setIsMountLimit(true);
        }

        if (poet != null){
            String tp = poet.trim();
            if (tp.length() > 0){
                builder.setPoet(ByteString.copyFromUtf8(tp));
            }
        }
        if (fixedPkMode != null){
            builder.setFixedPkMode(fixedPkMode.getIntMode());
        }

        if (reliveOutOfDungeon){
            builder.setIsDeathReturnTown(true);
        }

        builder.setSequence(sequence);
        if (prerequisite != 0){
            builder.setPrerequisite(prerequisite);
        }

        for (int targetMonsterID : targetMonsterIDForDisplay){
            builder.addTargetMonsterToKill(targetMonsterID);
        }
        if (isKillAll){
            builder.setIsKillAll(true);
        }

        // 这里先这样，如果副本奖励需要新加类型的时候，就直接在Prize中添加
        if (fixedPrize.getExp() > 0){
            builder.setPrizeExp(fixedPrize.getExp());
        }
        if (fixedPrize.getMoney() > 0){
            builder.setPrizeMoney(fixedPrize.getMoney());
        }
        if (fixedPrize.getRealAir() > 0){
            builder.setPrizeRealAir(fixedPrize.getRealAir());
        }

        for (GoodsWrapper w : fixedPrize.getGoodsWrappers()){
            builder.addPrizeGoods(w.encode4Client());
        }

        for (GoodsWrapper w : prizeFirst){
            builder.addPrizeFirstPass(w.encode4Client());
        }

        builder.setDescription(ByteString.copyFromUtf8(description));
        builder.setPrizeDescription(ByteString.copyFromUtf8(prizeDescription));
        builder.setBackGroundImg(backgroundImg);
        builder.setNameImg(nameImg);

        return builder.build();
    }
}
