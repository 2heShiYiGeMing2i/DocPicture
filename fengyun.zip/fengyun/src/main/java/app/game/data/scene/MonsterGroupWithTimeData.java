package app.game.data.scene;

import app.game.data.TimeData;
import app.game.module.scene.IScene;

public class MonsterGroupWithTimeData{

    public static final MonsterGroupWithTimeData[] EMPTY_ARRAY = new MonsterGroupWithTimeData[0];

    public static final MonsterGroupWithTimeDataInstance[] EMPTY_INSTANCE_ARRAY = new MonsterGroupWithTimeDataInstance[0];

    public final TimeData timeData;

    final SceneMonsterData[] monsters;

    MonsterGroupWithTimeData(TimeData timeData, SceneMonsterData[] monster){
        this.timeData = timeData;
        this.monsters = monster;
    }

    public MonsterGroupWithTimeDataInstance newInstance(long ctime,
            IScene parent){
        return new MonsterGroupWithTimeDataInstance(ctime, parent);
    }

    public SceneMonsterData[] getMonsters(){
        return monsters;
    }

    public class MonsterGroupWithTimeDataInstance{
        public final IScene parent;
        public long nextCreateTime;

        private MonsterGroupWithTimeDataInstance(long ctime, IScene parent){
            nextCreateTime = timeData.getNextTime(ctime);
            this.parent = parent;
        }

        public void updateTime(){
            updateTime(nextCreateTime);
        }

        public void updateTime(long time){
            nextCreateTime = timeData.getNextTime(time);
        }

        public SceneMonsterData[] getMonsters(){
            return monsters;
        }
    }
}
