package app.game.data.scene;

import static com.mokylin.sink.util.Preconditions.checkArgument;

import org.joda.time.DateTimeConstants;

import app.game.data.GameObjects;
import app.game.data.goods.GoodsDatas;
import app.game.data.goods.GoodsWrapper;
import app.game.module.scene.AbstractDungeonScene;
import app.game.module.scene.IDungeonService;
import app.game.module.scene.VipDungeonScene;
import app.game.service.log.LogService;
import app.protobuf.ConfigContent.VipDungeonProto;
import app.protobuf.LogContent.LogEnum.SceneType;

import com.google.protobuf.ByteString;
import com.mokylin.sink.util.parse.ObjectParser;

public class VipDungeonSceneData extends DungeonSceneData{

    private final MonsterData boss; // 通过找副本里的怪得到

    public final long timeLimitMillis;

    /**
     * 这只是展示的奖励物品, 不需要实际掉出来. 全靠boss掉落
     * 只需要检查这些物品, 这个boss是否有可能会掉就行
     */
    private final GoodsWrapper[] prizeGoods;

    private final String prizeDescription;

    /**
     * 点出副本后, tip中的详细描述
     */
    private final String description;

    public final int vipLevel;

    private final String backgroundImg;

    VipDungeonSceneData(GameObjects go, ObjectParser p, BlockInfos blocks,
            MonsterDatas monsters, Scripts scripts, Plunders plunders, Ais ais,
            SceneTransportDatas transports, GoodsDatas goodsDatas,
            SceneRemoveObjectMsgCache removeMsgCache){
        super(go, p, blocks, monsters, scripts, plunders, ais, transports,
                removeMsgCache);

        this.description = p.getKey("description");
        this.prizeDescription = p.getKey("prize_description");
        this.backgroundImg = p.getKey("background_img");

        // vip等级
        this.vipLevel = p.getIntKey("vip_level");
        checkArgument(vipLevel > 0, "vip副本 %s 所需的vip_level必须>0", this);

        // 时间限制
        int timeLimitSecond = p.getIntKey("time_limit_second");
        this.timeLimitMillis = ((long) timeLimitSecond)
                * DateTimeConstants.MILLIS_PER_SECOND;

        // 奖励
        String[] prizeGoodsStr = p.getStringArray("prize_goods");
        this.prizeGoods = GoodsWrapper.parse(this, goodsDatas, prizeGoodsStr);
        // TODO 需要检查展示的可能掉落的奖励, 是否在boss的plunder中

        // 找到配置的boss
        SceneMonsterData[] mons = getSingleLifeMonsterDatas();
        checkArgument(mons.length == 1, "vip副本中必须放且只放一个怪: {}. 有 {} 个怪", this,
                mons.length);
        this.boss = mons[0].getMonsterData();

        // 需求等级
        checkArgument(requiredLevel <= 1, "vip副本不能限制进入等级: %s", this);

    }

    @Override
    public int getIntType(){
        return SceneType.VIP_DUNGEON.getNumber();
    }

    @Override
    public AbstractDungeonScene newDungeon(int sceneID,
            IDungeonService dungeonService, LogService logService, long creator){
        return new VipDungeonScene(this, sceneID, dungeonService, logService,
                creator);
    }

    public VipDungeonProto generateProto(){
        VipDungeonProto.Builder builder = VipDungeonProto.newBuilder();
        builder.setSceneId(id).setMap(blockName)
                .setName(ByteString.copyFrom(nameBytes)).setSound(sound);
        if (isHeroLevelProtect){
            builder.setIsHeroLevelProtect(true);
        }
        if (isNewHeroProtect){
            builder.setIsNewHeroProtect(true);
        }
        if (isDeathProtect){
            builder.setIsDeathProtect(true);
        }
        if (isNightAutoProtect){
            builder.setIsNightAutoProtect(true);
        }
        if (isJumpLimit){
            builder.setIsJumpLimit(true);
        }
        if (isMountLimit){
            builder.setIsMountLimit(true);
        }

        if (poet != null){
            String tp = poet.trim();
            if (tp.length() > 0){
                builder.setPoet(ByteString.copyFromUtf8(tp));
            }
        }
        if (fixedPkMode != null){
            builder.setFixedPkMode(fixedPkMode.getIntMode());
        }

        if (reliveOutOfDungeon){
            builder.setIsDeathReturnTown(true);
        }

        builder.setBossTypeId(boss.id);
        builder.setTimeLimitSecond((int) (timeLimitMillis / DateTimeConstants.MILLIS_PER_SECOND));
        builder.setDescription(ByteString.copyFromUtf8(description));
        builder.setPrizeDescription(ByteString.copyFromUtf8(prizeDescription));
        builder.setVipLevel(vipLevel);
        builder.setBackgroundImg(backgroundImg);

        for (GoodsWrapper w : prizeGoods){
            builder.addPrizeGoods(w.encode4Client());
        }

        return builder.build();
    }
}
