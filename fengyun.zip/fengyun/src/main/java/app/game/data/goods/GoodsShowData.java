package app.game.data.goods;

import app.game.data.ConfigService;
import app.protobuf.GoodsServerContent.GoodsServerProto;

/**
 * @author Liwei
 *
 */
public class GoodsShowData{

    private final GoodsData data;

    private final byte[] dynamicData;

    private final GoodsServerProto serverProto;

    private final long time;

    public GoodsShowData(GoodsData data, byte[] dynamicData,
            GoodsServerProto serverProto, long time){
        this.data = data;
        this.dynamicData = dynamicData;
        this.serverProto = serverProto;
        this.time = time;
    }

    public GoodsData getData(){
        return data;
    }

    public byte[] getDynamicData(){
        return dynamicData;
    }

    public long getTime(){
        return time;
    }

    public GoodsServerProto getServerProto(){
        return serverProto;
    }

    public static GoodsShowData decode(GoodsServerProto serverProto, long time,
            ConfigService configService){

        int goodsId = serverProto.getId();

        GoodsData data = configService.getGoods().get(goodsId);
        if (data == null){
            return null;
        }

        byte[] dynamicData = data.encodeGoodsProto(serverProto).toByteArray();

        return new GoodsShowData(data, dynamicData, serverProto, time);
    }
}
