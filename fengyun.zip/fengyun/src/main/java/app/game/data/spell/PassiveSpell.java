package app.game.data.spell;

import static com.mokylin.sink.util.Preconditions.checkArgument;
import static com.mokylin.sink.util.Preconditions.checkNotNull;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.data.SpriteStat;
import app.game.data.SpriteStats;
import app.game.data.goods.GoodsDatas;
import app.game.module.scene.FightData;
import app.game.module.scene.SceneMessages;
import app.protobuf.ConfigContent.ActiveSpell.Builder;
import app.protobuf.HeroServerContent.TriggerType;

import com.mokylin.sink.util.RandomNumber;
import com.mokylin.sink.util.parse.ObjectParser;

public class PassiveSpell extends Spell{

    public static final PassiveSpell[] EMPTY_ARRAY = new PassiveSpell[0];

    static final int TRIG_RATE = 100;

    public final String icon;

    /**
     * 触发类型，做成枚举
     */
    final TriggerType triggerType;

    /**
     * 触发概率，分母为100
     */
    final int rate;

    public final boolean isTriggerNotice;

    public transient final ChannelBuffer noticeMsg;

    /**
     * 被动技能加属性
     */
    private final SpriteStat spriteStat;

    /**
     * 被动技能战斗力
     */
    private final int passiveSpellFightingAmount;

    /**
     * 触发时，给自己加的状态
     */
    public final FightState[] selfStates;

    /**
     * 触发时, 给目标添加的状态
     */
    public final FightState[] targetStates;

    /**
     * 触发时, 释放一个技能
     */
    public final SingleEffectSpell triggerSpell;

    private PassiveSpell nextLevel;

    PassiveSpell(ObjectParser p, SingleEffectSpells ses, Auras auras,
            GoodsDatas goodsDatas, SpriteStats stats, FightStates fs){
        super(p, goodsDatas);

        icon = p.getKey("icon");

        int trigger = p.getIntKey("trigger");
        triggerType = checkNotNull(TriggerType.valueOf(trigger),
                "%s 的触发类型无效，trigger: %s", this, trigger);

        if (spellCategory == HERO_SPELL_CATEGORY){
            checkArgument(triggerType == TriggerType.SPRITE_STAT,
                    "英雄被动技能只有加属性的，不能配置其他触发类型的被动技能，%s", this, triggerType);
        }

        if (spellCategory == SUPER_WEAPON_SPELL_CATEGORY){
            checkArgument(triggerType == TriggerType.ATTACK_OTHER,
                    "神兵被动技能只能是击中别人触发类型，不能配置其他触发类型的被动技能，%s", this, triggerType);
        }

        isTriggerNotice = p.getBooleanKey("is_trigger_notice");
        if (isTriggerNotice){
            noticeMsg = SceneMessages.triggerPassiveSpellMsg(id);
        } else{
            noticeMsg = null;
        }

        if (spellCategory == MOUNT_SPELL_CATEGORY){
            checkArgument(isTriggerNotice,
                    "%s 是坐骑技能，但是没有配置触发时通知客户端，is_trigger_notice", this,
                    triggerType);
        } else{
            checkArgument(!isTriggerNotice, "%s 不是坐骑技能，但是配置了触发时通知客户端", this);
        }

        if (triggerType == TriggerType.SPRITE_STAT){

            int statId = p.getIntKey("sprite_stat");

            spriteStat = checkNotNull(stats.get(statId),
                    "%s 加属性被动技能配置的属性无效，sprite_stat: %s", this, statId);

            checkArgument(spriteStat != SpriteStat.EMPTY_STAT,
                    "%s 加属性被动技能配置的属性是个空属性", this);

            checkArgument(spriteStat.isBuffStat(), "%s 加属性被动技能配置的属性存在 <0的字段",
                    this);

            passiveSpellFightingAmount = FightData
                    .calculateFightingAmount(spriteStat);

            checkArgument(passiveSpellFightingAmount > 0, "技能 %s 的战斗力 <= 0",
                    this);

            rate = TRIG_RATE; // 被动加属性，不需要触发概率
        } else{
            spriteStat = SpriteStat.EMPTY_STAT;
            passiveSpellFightingAmount = fightingAmount;

            checkArgument(passiveSpellFightingAmount > 0,
                    "技能 %s 没有配置战斗力 fighting_amount", this);

            rate = p.getIntKey("rate");
            checkArgument(rate > 0 && rate <= TRIG_RATE,
                    "%s 的触发概率无效，0 < rate <= 100，rate：%s", this, rate);
        }

        // 被目标加的状态
        String stateString = p.getKey("states");

        FightState[] states = FightState.EMPTY_ARRAY;
        if (!stateString.isEmpty()){
            // stateID;stateID
            String[] str = stateString.split(";");
            states = new FightState[str.length];
            for (int i = 0; i < str.length; i++){
                int stateID = Integer.parseInt(str[i]);
                states[i] = checkNotNull(fs.get(stateID), "%s 没有找到要附带的状态: %s",
                        this, stateID);
            }
        }
        targetStates = states;

        if (triggerType == TriggerType.ATTACK_OTHER){
            for (FightState state : targetStates){
                checkArgument(!state.isBuff,
                        "技能 %s 是攻击触发,  给目标添加的状态不能是buff: %s", this, state);
            }
        }

        // 给自己加的状态
        stateString = p.getKey("self_states");

        states = FightState.EMPTY_ARRAY;
        if (!stateString.isEmpty()){
            // stateID;stateID
            String[] str = stateString.split(";");
            states = new FightState[str.length];
            for (int i = 0; i < str.length; i++){
                int stateID = Integer.parseInt(str[i]);
                states[i] = checkNotNull(fs.get(stateID), "%s 没有找到要附带的状态: %s",
                        this, stateID);
            }
        }
        selfStates = states;

        for (FightState state : selfStates){
            checkArgument(state.isBuff, "技能 %s 触发后给自己添加的状态必须是buff: %s", this,
                    state);
        }

        int triggerSpellId = p.getIntKey("trigger_spell");
        if (triggerSpellId > 0){
            triggerSpell = checkNotNull(ses.get(triggerSpellId),
                    "%s 触发的技能没找到， spell: %s", this, triggerSpellId);
        } else{
            triggerSpell = null;
        }

        if (triggerType == TriggerType.ATTACK_OTHER){
            if (triggerSpell != null){
                checkArgument(
                        triggerSpell.spellAnimation.targetType == SpellAnimation.TARGET_TYPE_TARGET,
                        "%s 攻击别人触发的被动技能，触发技能只支持向攻击目标施放特定技能", this);

                checkArgument(triggerSpell.isAttack,
                        "%s 攻击别人触发的被动技能，触发技能必须是攻击技能", this);
            }
        }

        if (triggerType == TriggerType.ATTACK_SPELL_RELEASED){
            checkArgument(selfStates.length > 0 || triggerSpell != null,
                    "%s 释放技能触发的被动技能，但是没有被自己加的状态，也没有触发的技能", this);

            if (triggerSpell != null){
                checkArgument(
                        triggerSpell.spellAnimation.targetType == SpellAnimation.TARGET_TYPE_GROUND,
                        "%s 释放技能触发的被动技能，触发技能只支持在英雄的位置朝地面释放的技能", this);
            }
        }
    }

    void setNextLevelAndTotalLevel(int totalLevel, PassiveSpell spell){
        assert this.totalLevel == 0;
        assert this.nextLevel == null;

        this.totalLevel = totalLevel;
        this.nextLevel = spell;

        if (spell != null){
            checkArgument(icon.equals(spell.icon), "技能 %s 和它的下一级的图标居然不一致", this);

            checkArgument(triggerType == spell.triggerType,
                    "技能 %s 和它的下一级的触发方式居然不一致", this);
        }
    }

    public TriggerType getTriggerType(){
        return triggerType;
    }

    public boolean trigByAttackSpellReleased(){
        return triggerType == TriggerType.ATTACK_SPELL_RELEASED;
    }

    public boolean trigByAttackOther(){
        return triggerType == TriggerType.ATTACK_OTHER;
    }

    public boolean isPropertyPassiveSpell(){
        return triggerType == TriggerType.SPRITE_STAT;
    }

    public SpriteStat getPropertyStat(){
        return spriteStat;
    }

    public boolean tryTrigger(){
        return RandomNumber.getRate(TRIG_RATE, true) < rate;
    }

    @Override
    public int getFightingAmount(){
        return passiveSpellFightingAmount;
    }

    @Override
    protected void setSpecialSpellField(Builder builder){
        builder.setIsPassive(true).setIcon(icon).setSpellId(id);

        if (triggerType == TriggerType.SPRITE_STAT){
            builder.setSpriteStat(spriteStat.encode());
        }

        if (nextLevel != null){
            builder.setNextLevelDescription(nextLevel.description);
        }
    }

    @Override
    public PassiveSpell getNextLevel(){
        return nextLevel;
    }

}
