package app.game.data.spell;

/**
 * @author Liwei
 *
 */
public class CombineXinfaSpell{

    private final SingleEffectSpell actualSpell;

    private final SpellXinfaEffect xinfaEffect;

    // 效果

    public transient final int hurtCount;

    public transient final int releaseRange;

    public transient final int hurtRange;

    public transient final int hurtRangeSquared;

    public transient final int angle;

    /**
     * 技能伤害的倍率, 计算时, 按配置的数字/100
     */
    public transient final float damageMultiple;

    public transient final int damage;

    /**
     * 技能额外的命中率, 分母为1万
     */
    public transient final int additionalHitRate;

    /**
     * 技能额外的暴击率, 分母为1万
     */
    public transient final int additionalCritRate;

    // 无视跳闪
    public transient final boolean ignoreJumpShield;

    // 攻击别人触发
    public transient final PassiveSpell attackOtherTrigSpell;

    // 释放攻击技能触发
    public transient final PassiveSpell releaseAttackSpellTrigSpell;

    public CombineXinfaSpell(SingleEffectSpell actualSpell,
            SpellXinfaEffect xinfaEffect){
        this.actualSpell = actualSpell;
        this.xinfaEffect = xinfaEffect;

        hurtCount = actualSpell.maxHurtCount + xinfaEffect.hurtCount;

        if (actualSpell.spellAnimation.targetType == SpellAnimation.TARGET_TYPE_TARGET){
            releaseRange = actualSpell.releaseRange + xinfaEffect.releaseRange;
        } else{
            releaseRange = 0;
        }

        hurtRange = actualSpell.hurtRange + xinfaEffect.hurtRange;
        hurtRangeSquared = hurtRange * hurtRange;

        angle = actualSpell.angle + xinfaEffect.angle;
        damageMultiple = actualSpell.damageMultiple
                + xinfaEffect.damageMultiple;
        damage = actualSpell.damage + xinfaEffect.damage;
        additionalHitRate = actualSpell.additionalHitRate
                + xinfaEffect.additionalHitRate;
        additionalCritRate = actualSpell.additionalCritRate
                + xinfaEffect.additionalCritRate;

        PassiveSpell attackOtherTrigSpell = null;
        PassiveSpell releaseAttackSpellTrigSpell = null;
        if (xinfaEffect.spell != null){
            switch (xinfaEffect.spell.triggerType){
                case ATTACK_OTHER:{
                    attackOtherTrigSpell = xinfaEffect.spell;
                    break;
                }
                case ATTACK_SPELL_RELEASED:{
                    releaseAttackSpellTrigSpell = xinfaEffect.spell;
                    break;
                }
                case SPRITE_STAT:{
                    System.err.println("技能心法触发的被动技能居然是个加属性的被动: "
                            + xinfaEffect.spell);
                    break;
                }
                default:{
                    System.err.println("遇到未知类型的被动技能: " + xinfaEffect.spell);
                    break;
                }
            }
        }

        this.attackOtherTrigSpell = attackOtherTrigSpell;
        this.releaseAttackSpellTrigSpell = releaseAttackSpellTrigSpell;

        this.ignoreJumpShield = actualSpell.ignoreJumpShield;

    }

    public SingleEffectSpell getActualSpell(){
        return actualSpell;
    }

    public SpellAnimation getSpellAnimation(){
        return actualSpell.spellAnimation;
    }

    public int getRepeatTimes(){
        return actualSpell.repeatTimes;
    }

    public int getRepeatInterval(){
        return actualSpell.repeatInterval;
    }

    public SpellXinfaEffect getXinfaEffect(){
        return xinfaEffect;
    }
}
