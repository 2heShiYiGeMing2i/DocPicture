package app.game.data.scene;

import static com.mokylin.sink.util.Preconditions.checkArgument;

import java.util.Collection;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.data.GameObjects;
import app.game.data.PrizeConfigs;
import app.game.data.goods.GoodsDatas;
import app.utils.VariableConfig;

import com.google.inject.Inject;
import com.mokylin.collection.IntHashMap;
import com.mokylin.sink.util.parse.ObjectParser;

public class ChallengeDungeonSceneDatas{

    private static final Logger logger = LoggerFactory
            .getLogger(ChallengeDungeonSceneDatas.class);

    public static final String LOCATION = GameObjects.SCENE_BASE_FOLDER
            + "challenge.txt";

    private final IntHashMap<ChallengeDungeonSceneData> map;

    private final ChallengeDungeonSceneData[] sequenceArray;

    final int challengeMaxTimes;

    final int assistMaxTimes;

    @Inject
    ChallengeDungeonSceneDatas(GameObjects go, BlockInfos blocks,
            MonsterDatas monsters, Scripts scripts, Plunders plunders, Ais ais,
            SceneTransportDatas transports, GoodsDatas goodsDatas,
            PrizeConfigs prizeConfigs, PlunderGroups plunderGroups,
            VariableConfig variableConfig,
            SceneRemoveObjectMsgCache removeMsgCache){
        logger.debug("loading challenge dungeon scenes");

        challengeMaxTimes = variableConfig.CHALLENGE_DUNGEON_MAX_TIMES;
        assistMaxTimes = variableConfig.CHALLENGE_DUNGEON_ASSIST_MAX_TIMES;

        List<ObjectParser> data = go.loadFile(LOCATION);

        map = new IntHashMap<>(data.size());

        for (ObjectParser p : data){
            ChallengeDungeonSceneData scene = new ChallengeDungeonSceneData(go,
                    p, blocks, monsters, scripts, plunders, ais, transports,
                    goodsDatas, prizeConfigs, plunderGroups, removeMsgCache);

            map.putUnique(scene.id, scene);
        }

        // 检查sequence连续
        sequenceArray = new ChallengeDungeonSceneData[map.size()];
        for (ChallengeDungeonSceneData sceneData : map.values()){
            checkArgument(sceneData.sequence >= 1
                    && sceneData.sequence <= sequenceArray.length,
                    "挑战侠士 %s 的sequence必须是从1开始连续的: %s", sceneData,
                    sceneData.sequence);

            checkArgument(sequenceArray[sceneData.sequence - 1] == null,
                    "挑战侠士的sequence冲突: %s", sceneData.sequence);
            sequenceArray[sceneData.sequence - 1] = sceneData;
        }

        // 检查difficulty, 每个difficulty数量相同, 且必须连续

    }

    public int size(){
        return map.size();
    }

    public ChallengeDungeonSceneData getBySequence(int sequence){
        if (sequence > 0 && sequence <= sequenceArray.length){
            return sequenceArray[sequence - 1];
        }

        return null;
    }

    public ChallengeDungeonSceneData get(int sceneID){
        return map.get(sceneID);
    }

    void putAll(IntHashMap<SceneData> totalMap){
        for (ChallengeDungeonSceneData sceneData : map.values()){
            totalMap.putUnique(sceneData.id, sceneData);
        }
    }

    Collection<ChallengeDungeonSceneData> getAll(){
        return map.values();
    }

}
