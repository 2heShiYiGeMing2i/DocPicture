package app.game.data.pet;

import static com.mokylin.sink.util.Preconditions.*;

import java.util.List;

import org.joda.time.DateTimeConstants;

import app.game.data.GameObjects;
import app.game.data.SingleSpriteStats;
import app.game.data.SpriteStats;
import app.game.data.goods.GoodsDatas;
import app.game.data.scene.MonsterData;
import app.game.data.scene.MonsterDatas;
import app.game.shop.Shops;
import app.protobuf.ConfigContent.PetConfig;
import app.protobuf.ConfigContent.ServiceConfig;
import app.utils.VariableConfig;

import com.google.inject.Inject;
import com.mokylin.collection.IntHashMap;
import com.mokylin.collection.IntHashSet;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class PetDatas{

    private static final String GOODS_LOCATION = GameObjects.PET_BASE_FOLDER
            + "master_stat_goods.txt";

    private static final String TIAN_JIE_LOCATION = GameObjects.PET_BASE_FOLDER
            + "tianjie.txt";

    private static final String TIAN_ZUI_LOCATION = GameObjects.PET_BASE_FOLDER
            + "tianzui.txt";

    private final PetLevelDatas levelDatas;

    private final MonsterData defaultPetMonster;

    private final MonsterData freePetMonster;

    private final IntHashMap<MasterStatGoods> goodsMap;

    private final long duration;

    // 天劫
    private final TianJieData[] tianJieDatas;

    private final TianJieData freeTianJie;

    // 天罪
    private final TianZuiData[] tianZuiDatas;

    private final TianZuiData freeTianZui;

    @Inject
    PetDatas(GameObjects go, GoodsDatas goodsDatas, SpriteStats spriteStats,
            SingleSpriteStats singleStats, MonsterDatas monsterDatas,
            Shops shops, VariableConfig config){

        this.levelDatas = new PetLevelDatas(go, spriteStats);

        freePetMonster = checkNotNull(
                monsterDatas.get(config.FREE_PET_MONSTER_ID), "宠物 对应的免费怪物没找到",
                config.FREE_PET_MONSTER_ID);

        // 喂食物品
        List<ObjectParser> data = go.loadFile(GOODS_LOCATION);
        checkArgument(!data.isEmpty(), "宠物喂食表没有配置数据");

        goodsMap = new IntHashMap<>();
        for (ObjectParser p : data){
            MasterStatGoods goods = new MasterStatGoods(p, goodsDatas,
                    singleStats);
            goodsMap.putUnique(goods.getId(), goods);
        }

        duration = 1L * config.FREE_PET_DURATION
                * DateTimeConstants.MILLIS_PER_MINUTE;

        // 天劫
        data = go.loadFile(TIAN_JIE_LOCATION);
        checkArgument(!data.isEmpty(), "天劫表没有配置数据");

        IntHashSet set = new IntHashSet();
        set.add(config.FREE_PET_MONSTER_ID);

        tianJieDatas = new TianJieData[data.size()];
        for (ObjectParser p : data){
            TianJieData d = new TianJieData(p, spriteStats, monsterDatas,
                    goodsDatas, shops.getSystemShop());

            checkArgument(d.id > 0 && d.id <= data.size()
                    && tianJieDatas[d.id - 1] == null,
                    "天劫配置存在重复的ID，或者无效ID（从1开始），%s", d);
            tianJieDatas[d.id - 1] = d;

            checkArgument(set.add(d.getMonsterId()), "天劫怪物id重复， %s %s", d,
                    d.getMonster());
        }

        for (int i = 1; i < tianJieDatas.length; i++){
            checkArgument(
                    tianJieDatas[i - 1].spellSlotCount <= tianJieDatas[i].spellSlotCount,
                    "天劫 %s 的技能开放个数居然小于前一阶", tianJieDatas[i]);

            checkArgument(
                    tianJieDatas[i - 1].openTime <= tianJieDatas[i].openTime,
                    "天劫-%s 的开放时间居然小于前一阶", tianJieDatas[i]);

            tianJieDatas[i - 1].nextLevel = tianJieDatas[i];
        }

        freeTianJie = tianJieDatas[0];
        defaultPetMonster = freeTianJie.getMonster();

        // 天罪
        data = go.loadFile(TIAN_ZUI_LOCATION);
        checkArgument(!data.isEmpty(), "天罪表没有配置数据");

        tianZuiDatas = new TianZuiData[data.size()];
        for (ObjectParser p : data){
            TianZuiData d = new TianZuiData(p, spriteStats, goodsDatas,
                    shops.getSystemShop());

            checkArgument(d.id > 0 && d.id <= data.size()
                    && tianZuiDatas[d.id - 1] == null,
                    "天罪配置存在重复的ID，或者无效ID（从1开始），%s", d);
            tianZuiDatas[d.id - 1] = d;
        }

        for (int i = 1; i < tianZuiDatas.length; i++){
            checkArgument(
                    tianZuiDatas[i - 1].spellSlotCount <= tianZuiDatas[i].spellSlotCount,
                    "天罪 %s 的技能开放个数居然小于前一阶", tianZuiDatas[i]);

            checkArgument(
                    tianZuiDatas[i - 1].openTime <= tianZuiDatas[i].openTime,
                    "天罪-%s 的开放时间居然小于前一阶", tianZuiDatas[i]);

            tianZuiDatas[i - 1].nextLevel = tianZuiDatas[i];
        }

        freeTianZui = tianZuiDatas[0];
    }

    public long getFreeDuration(){
        return duration;
    }

    public MonsterData getFreeMonster(){
        return freePetMonster;
    }

    public TianJieData getFreeTianJie(){
        return freeTianJie;
    }

    public MonsterData getDefaultMonster(){
        return defaultPetMonster;
    }

    public PetLevelDatas getLevelDatas(){
        return levelDatas;
    }

    public MasterStatGoods getMasterStatGoods(int id){
        return goodsMap.get(id);
    }

    public TianJieData getTianJie(int id){
        return Utils.getValidObject(tianJieDatas, id - 1);
    }

    public TianZuiData getTianZui(int id){
        return Utils.getValidObject(tianZuiDatas, id - 1);
    }

    public TianZuiData getFreeTianZui(){
        return freeTianZui;
    }

    public PetConfig generateProto(VariableConfig config){
        PetConfig.Builder builder = PetConfig.newBuilder()
                .setAddLifeCost(config.PET_ADD_LIFE_COST)
                .setPetSpellMaxSlot(VariableConfig.PET_SPELL_SLOT_MAX_COUNT)
                .setCollectTianZuiLevel(config.COLLECT_FREE_TIAN_ZUI_LEVEL);

        for (int lv : levelDatas.spellOpenLevels){
            builder.addSpellSlotOpenLevel(lv);
        }

        builder.setDefaultMonster(TianJieData
                .encodePetMonster(defaultPetMonster));

        builder.setFreeMonster(TianJieData.encodePetMonster(freePetMonster));

        for (MasterStatGoods goods : goodsMap.values()){
            builder.addGoods(goods.encode());
        }

        for (TianJieData t : tianJieDatas){
            builder.addTianJie(t.encode());
        }

        for (TianZuiData t : tianZuiDatas){
            builder.addTianZui(t.encode());
        }

        return builder.build();
    }

    public void setOpenTime(ServiceConfig.Builder builder, long startServiceTime){
        for (TianJieData data : tianJieDatas){
            if (data.openTime > 0){
                builder.addTianJieOpenTime(data.openTime + startServiceTime);
            } else{
                builder.addTianJieOpenTime(0);
            }
        }

        for (TianZuiData data : tianZuiDatas){
            if (data.openTime > 0){
                builder.addTianZuiOpenTime(data.openTime + startServiceTime);
            } else{
                builder.addTianZuiOpenTime(0);
            }
        }
    }

}
