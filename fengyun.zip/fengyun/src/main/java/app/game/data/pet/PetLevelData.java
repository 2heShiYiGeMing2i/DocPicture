package app.game.data.pet;

import static com.mokylin.sink.util.Preconditions.*;

import java.util.List;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.data.SpriteStat;
import app.game.data.SpriteStats;
import app.game.module.PetMessages;
import app.game.module.scene.FightData;
import app.protobuf.HeroContent.PetLevelProto;
import app.utils.VariableConfig;

import com.google.common.collect.Lists;
import com.mokylin.collection.IntPair;
import com.mokylin.sink.util.IntWeightedRandomer;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class PetLevelData{

    final int level;

    // 固定出战属性
    final SpriteStat fixedStat;

    final int staticHurtAmount;

    /**
     * 为主人附加的最大属性
     */
    final int addedMaxLife;

    final int addedMaxAttack;

    final int addedMaxDefence;

    final SpriteStat addedFixedStat;

    final int addedFixedFightAmount;

    /**
     * 技能槽开放个数
     */
    final int spellSlotCount;

    final transient IntWeightedRandomer spellSlotRandomer;

    private final PetLevelProto proto;

    private final ChannelBuffer levelUpMsg;

    PetLevelData(ObjectParser p, SpriteStats spriteStats){

        level = p.getIntKey("level");
        checkArgument(level > 0, "宠物等级无效，level: %s", level);

        int statId = p.getIntKey("fixed_stat");
        fixedStat = checkNotNull(spriteStats.get(statId), "宠物 %s 配置的出战属性没找到",
                this);

        staticHurtAmount = p.getIntKey("static_hurt_amount");
        checkArgument(staticHurtAmount > 0, "宠物 %s 配置的固定扣血值必须大于0", this);

        addedMaxLife = p.getIntKey("added_max_life");
        checkArgument(addedMaxLife > 0, "宠物 %s 配置的给主人附加最大血量必须 > 0", this);

        addedMaxAttack = p.getIntKey("added_max_attack");
        checkArgument(addedMaxAttack > 0, "宠物 %s 配置的给主人附加最大攻击必须 > 0", this);

        addedMaxDefence = p.getIntKey("added_max_defence");
        checkArgument(addedMaxDefence > 0, "宠物 %s 配置的给主人附加最大防御必须 > 0", this);

        statId = p.getIntKey("added_fixed_stat");
        addedFixedStat = checkNotNull(spriteStats.get(statId),
                "宠物 %s 配置的给主人加的默认属性没找到", this);

        addedFixedFightAmount = FightData
                .calculateFightingAmount(addedFixedStat);

        // 技能
        spellSlotCount = p.getIntKey("spell_slot_count");
        checkArgument(spellSlotCount >= 0
                && spellSlotCount <= VariableConfig.PET_SPELL_SLOT_MAX_COUNT,
                "%s 宠物技能开放个数配置错误, count: %s, 0 <= count <= %s", this,
                spellSlotCount, VariableConfig.PET_SPELL_SLOT_MAX_COUNT);

        IntWeightedRandomer randomer = null;
        if (spellSlotCount > 0){
            String spellSlotRates = p.getKey("spell_slot_rates");
            String[] spellSlotRateArray = spellSlotRates.split(";");

            checkArgument(spellSlotCount == spellSlotRateArray.length,
                    "%s 宠物技能随机位置的权重配置的个数与宠物技能格子开放个数不同", this);

            List<IntPair> pairs = Lists
                    .newArrayListWithCapacity(spellSlotCount);
            for (int i = 0; i < spellSlotCount; i++){
                int weight = Integer.parseInt(spellSlotRateArray[i]);

                pairs.add(new IntPair(weight, i));
            }

            randomer = new IntWeightedRandomer(pairs);
        }

        spellSlotRandomer = randomer;

        proto = build();

        levelUpMsg = PetMessages.petLevelUpMsg(proto);
    }

    public int getStaticHurtAmount(){
        return staticHurtAmount;
    }

    private PetLevelProto build(){
        return PetLevelProto.newBuilder()
                .setDefaultAddedAttack(addedFixedStat.attack)
                .setDefaultAddedDefence(addedFixedStat.defence)
                .setDefaultAddedMaxLife(addedFixedStat.maxLife)
                .setMaxAddedMaxAttack(addedMaxAttack)
                .setMaxAddedMaxDefence(addedMaxDefence)
                .setMaxAddedMaxLife(addedMaxLife)
                .setFixedStat(fixedStat.encode())
                .setPercentStat(fixedStat.encodePercent())
                .setStaticHurt(staticHurtAmount).build();
    }

    public PetLevelProto getProto(){
        return proto;
    }

    public ChannelBuffer getLevelUpMsg(){
        return levelUpMsg;
    }

    public int getSpellSlotCount(){
        return spellSlotCount;
    }

    public int randomSpellSlot(){
        assert spellSlotCount > 0;

        return spellSlotRandomer.next();
    }

    @Override
    public String toString(){
        return level + "级";
    }

}
