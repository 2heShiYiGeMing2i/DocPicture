/**
 * 
 */
package app.game.data.goods;

import static com.mokylin.sink.util.Preconditions.checkArgument;
import app.game.data.GameObjects;
import app.game.data.UpgradeData;
import app.game.shop.ShopGoods;
import app.game.shop.VendingMachine;
import app.protobuf.GoodsContent.GemDataProto;
import app.protobuf.GoodsServerContent.GoodsType;
import app.protobuf.ShopContent.PriceType;
import app.utils.VariableConfig;

import com.google.protobuf.ByteString;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * 宝石
 * 
 * @author Liwei
 * 
 */
public class GemGoodsData extends GoodsData{

    static final String LOCATION = GameObjects.GOODS_BASE_LOCATION + "gem.txt";

    // 阶数，1表示1阶
    final int gemLevel;

    private final GemDataProto proto;

    private final byte[] protoBytes;

    private final ByteString protoByteString;

    private final GoodsWrapper bindedGoodsWrapper;

    private final GoodsWrapper unbindedGoodsWrapper;

    private GemGoodsData nextLevel;

    // 宝石插槽升级，上一阶升级到本阶的消耗
    private UpgradeData gemSlotUpgradeData;

    // 背包宝石升级，上一阶升级到本阶的消耗
    private UpgradeData depotGemUpgradeData;

    GemGoodsData(ObjectParser p){
        super(p, GoodsType.GEM);

        gemLevel = p.getIntKey("gem_level");
        checkArgument(gemLevel > 0, "宝石 %s 配置的阶数必须大于0", this);

        proto = build();
        protoBytes = processProtoBytes(proto.toByteArray());
        protoByteString = ByteString.copyFrom(protoBytes);

        bindedGoodsWrapper = new GoodsWrapper(this, true, 1, 0, 0, 0);
        unbindedGoodsWrapper = new GoodsWrapper(this, false, 1, 0, 0, 0);
    }

    void init(GemGoodsData nextLevel, VendingMachine vendingMachine){
        this.nextLevel = nextLevel;

        ShopGoods shopGoods = vendingMachine.getGoods(PriceType.YUANBAO, id);

        // 背包宝石进阶
        UpgradeData.Builder builder = UpgradeData.newBuilder("背包宝石进阶lv"
                + gemLevel + " to next");
        builder.setGoods(this);
        builder.setUpgradeGoodsCount(VariableConfig.GEM_FUSE_COUNT);

        if (shopGoods != null)
            builder.setUpgradeGoodsYuanbaoPrice(shopGoods.getPrice());

        nextLevel.depotGemUpgradeData = builder.build();

        // 插槽宝石进阶
        builder = UpgradeData.newBuilder("插槽宝石进阶lv" + gemLevel + " to next");
        builder.setGoods(this);
        builder.setUpgradeGoodsCount(VariableConfig.GEM_FUSE_COUNT - 1); // 插槽上本来就有一颗

        if (shopGoods != null)
            builder.setUpgradeGoodsYuanbaoPrice(shopGoods.getPrice());

        nextLevel.gemSlotUpgradeData = builder.build();
    }

    public GemGoodsData getNextLevel(){
        return nextLevel;
    }

    public UpgradeData getGemSlotUpgradeData(){
        return gemSlotUpgradeData;
    }

    public UpgradeData getDepotGemUpgradeData(){
        return depotGemUpgradeData;
    }

    public int getGemLevel(){
        return gemLevel;
    }

    public GoodsAddHelper newGemGoods(boolean binded, int c, long ctime){
        if (binded)
            return bindedGoodsWrapper.newHelper(ctime, c);
        else{
            return unbindedGoodsWrapper.newHelper(ctime, c);
        }
    }

    private GemDataProto build(){
        GemDataProto.Builder builder = GemDataProto.newBuilder();
        builder.setBaseData(encode());
        builder.setGemLevel(gemLevel);

        return builder.build();
    }

    public GemDataProto getProto(){
        return proto;
    }

    @Override
    public byte[] getProtoBytes(){
        return protoBytes;
    }

    @Override
    public ByteString getProtoByteString(){
        return protoByteString;
    }

    @Override
    public int getAuctionType(){
        return 105;
    }

}
