package app.game.data.scene;

import java.util.Collection;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.protobuf.DungeonContent.DamageRecordProto;

import com.google.protobuf.ByteString;
import com.mokylin.collection.LongConcurrentSynchronizedHashMap;
import com.mokylin.sink.util.Utils;

/**
 * 统计场景中每个人的伤害
 * @author Timmy
 *
 */
public class DamageRecorder{

    private static final Logger logger = LoggerFactory
            .getLogger(DamageRecorder.class);

    private final LongConcurrentSynchronizedHashMap<HeroInfo> nameMap;

    public DamageRecorder(){
        this.nameMap = new LongConcurrentSynchronizedHashMap<>();
    }

    /**
     * 加入英雄
     * @param heroID
     * @param heroName
     * @return true表示之前不存在, false表示之前已经在了
     */
    public boolean add(long heroID, ByteString heroName){
        HeroInfo oldInfo = nameMap.get(heroID);
        if (oldInfo != null){
            oldInfo.isOffline = false;
            return false;
        }

        this.nameMap.put(heroID, new HeroInfo(heroID, heroName));
        return true;
    }

    public void remove(long heroID){
        boolean contains = this.nameMap.remove(heroID) != null;
        if (!contains){
            logger.error("DamageRecorder.remove时, nameMap里并没有要删除的英雄");
        }
    }

    public void setOffline(long heroID){
        HeroInfo oldInfo = nameMap.get(heroID);
        if (oldInfo == null){
            logger.error("DamageRecorder.setOffline时, nameMap里并没有要下线的英雄");
        } else{
            oldInfo.isOffline = true;
        }
    }

    /**
     * 返回的是加好的, 除完了1000的. 最右边的bit表示加完之后, 数字有没有变化. 可能太小, 导致/1000后没有变化
     * 是1表示有变化, 0表示没有变化
     * @param heroID
     * @param amount
     * @return
     */
    public void increment(long heroID, int amount, long ctime){
        if (amount <= 0){
            logger.error("DamageRecorder.increment怎么amount是个<=0的: {} from {}",
                    amount, Utils.getStackTrace());
            return;
        }

        HeroInfo oldInfo = nameMap.get(heroID);
        if (oldInfo == null){
            logger.error(
                    "DamageRecorder的nameMap中没有的英雄, 被调用了increment增加了伤害量: {} - {}",
                    heroID, amount);
            return;
        }

        long oldAmount = oldInfo.damage / 1000;
        long newAmount = oldInfo.increment(amount) / 1000;
        if (oldAmount != newAmount){
            oldInfo.setBroadcastTime(ctime);
        }
    }

    public DamageRecordProto encode(){
        // encode时, 至少自己已经加进来了

        DamageRecordProto.Builder builder = DamageRecordProto.newBuilder();

        for (HeroInfo info : nameMap.values()){
            builder.addHeroId(info.heroID).addHeroName(info.heroName)
                    .addIsOffline(info.isOffline)
                    .addDamageDividedBy1000(info.getDamage() / 1000);
        }

        return builder.build();
    }

    public Collection<HeroInfo> getAll(){
        return nameMap.values();
    }

    public static class HeroInfo{
        private final long heroID;
        private final ByteString heroName;
        private long damage; // 要正确就使用PaddedAtomicLong, 但不精确无所谓
        private boolean isOffline;
        private long broadcastTime;

        private HeroInfo(long heroID, ByteString heroName){
            this.heroID = heroID;
            this.heroName = heroName;
        }

        public long getID(){
            return heroID;
        }

        public boolean needBroadcast(long ctime){
            return broadcastTime >= ctime;
        }

        private void setBroadcastTime(long ctime){
            broadcastTime = ctime + 1000;
        }

        private long increment(int amount){
            return damage += amount;
        }

        public long getDamage(){
            return damage;
        }
    }
}
