package app.game.data.goods;

import static com.mokylin.sink.util.Preconditions.*;

import java.util.List;
import java.util.Map;

import app.protobuf.GoodsServerContent.Quality;
import app.protobuf.SpriteStatContent.StatType;

import com.google.common.collect.Lists;
import com.mokylin.collection.IntPair;
import com.mokylin.collection.LeftIntPair;
import com.mokylin.sink.util.IntWeightedRandomer;
import com.mokylin.sink.util.WeightedRandomer;

/**
 * @author Liwei
 *
 */
public class MountEquipmentRandomer extends GoodsRandomer{

    private static final String REFINED_TIMES_KEY = "refined_times";
    private static final String ADDED_STAT_COUNT_KEY = "added_stat_count";
    private static final String ADDED_STAT_TYPE_KEY = "added_stat_type";
    private static final String QUALITY_KEY = "quality";

    private static final WeightedRandomer<Quality> DEFAULT_QUALITY_RANDOMER = new WeightedRandomer<>(
            Quality.WHITE);

    private final MountEquipmentData data;

    private final IntWeightedRandomer refinedTimsRandomer;

//    private final IntWeightedRandomer addedStatCountRandomer;

    private final WeightedRandomer<StatType> addedStatTypeRandomer;

    private final WeightedRandomer<Quality> qualityRandomer;

    private final boolean hasRandomProperties;

    MountEquipmentRandomer(Object parent, MountEquipmentData data,
            Map<String, String> paramMap){
        super(parent, data, paramMap);

        this.data = data;
        this.refinedTimsRandomer = getRefinedTimsRandomer(parent, paramMap);
//        this.addedStatCountRandomer = getAddedStatCountRandomer(paramMap);
        this.addedStatTypeRandomer = getAddedDataRandomer(parent, paramMap);
        qualityRandomer = getQualityRandomer(parent, paramMap);

        checkNotNull(addedStatTypeRandomer,
                "MountEquipmentRandomer中的addedDataRandomer == null parent:%s",
                parent);

        hasRandomProperties = checkHasRandomProperties();
    }

    private IntWeightedRandomer getRefinedTimsRandomer(Object parent,
            Map<String, String> paramMap){

        String params = paramMap.get(REFINED_TIMES_KEY);
        if (params == null){
            return null;
        }

        String[] funcWeights = params.split("#");

        List<IntPair> pairs = Lists.newLinkedList();
        for (String funcWeight : funcWeights){
            int idx = funcWeight.indexOf("|");
            checkArgument(
                    idx > 0 && idx < funcWeight.length() - 1,
                    "MountEquipmentRandomer配置的%s 的强化等级参数配置错误，参数格式 : 1|1#2|2#3|3，param: %s parent:%s",
                    data, params, parent);

            int refinedTimes = Integer.parseInt(funcWeight.substring(0, idx));
            int weight = Integer.parseInt(funcWeight.substring(idx + 1));

            checkArgument(
                    data.isValidRefinedTimes(refinedTimes),
                    "MountEquipmentRandomer配置的%s 的强化等级无效，refinedTimes: %s parent:%s",
                    data, refinedTimes, parent);

            pairs.add(new IntPair(weight, refinedTimes));
        }

        return new IntWeightedRandomer(pairs);
    }

    // fuck 策划，这玩意又没用了，先留着，以后说不定会改回来
    private IntWeightedRandomer getAddedStatCountRandomer1(Object parent,
            Map<String, String> paramMap){

        String params = paramMap.get(ADDED_STAT_COUNT_KEY);
        if (params == null){
            return null;
        }

        String[] funcWeights = params.split("#");

        List<IntPair> pairs = Lists.newLinkedList();
        for (String funcWeight : funcWeights){
            int idx = funcWeight.indexOf("|");
            checkArgument(
                    idx > 0 && idx < funcWeight.length() - 1,
                    "MountEquipmentRandomer配置的%s 的附加属性条数参数配置错误，参数格式 : 1|1#2|2#3|3，param: %s parent:%s",
                    data, params, parent);

            int addedStatCount = Integer.parseInt(funcWeight.substring(0, idx));
            int weight = Integer.parseInt(funcWeight.substring(idx + 1));

            checkArgument(
                    data.getValidAddedCount(addedStatCount) == addedStatCount,
                    "MountEquipmentRandomer配置的%s 的附加属性条数无效，addedStatCount: %s parent:%s",
                    data, addedStatCount, parent);

            pairs.add(new IntPair(weight, addedStatCount));
        }

        return new IntWeightedRandomer(pairs);
    }

    private WeightedRandomer<Quality> getQualityRandomer(Object parent,
            Map<String, String> paramMap){

        String params = paramMap.get(QUALITY_KEY);
        if (params == null){
            return DEFAULT_QUALITY_RANDOMER;
        }

        String[] funcWeights = params.split("#");

        List<LeftIntPair<Quality>> pairs = Lists
                .newArrayListWithCapacity(funcWeights.length);
        for (String funcWeight : funcWeights){
            int idx = funcWeight.indexOf("|");
            checkArgument(
                    idx > 0 && idx < funcWeight.length() - 1,
                    "MountEquipmentRandomer配置的%s 的品质参数配置错误，参数格式 : 1|1#2|2#3|3，param: %s parent:%s",
                    data, params, parent);

            int intQuality = Integer.parseInt(funcWeight.substring(0, idx));
            int weight = Integer.parseInt(funcWeight.substring(idx + 1));

            Quality quality = checkNotNull(Quality.valueOf(intQuality),
                    "MountEquipmentRandomer配置的%s 的品质无效，[0-4] parent:%s", data,
                    parent);

            pairs.add(new LeftIntPair<Quality>(weight, quality));
        }

        return new WeightedRandomer<Quality>(pairs);
    }

    private WeightedRandomer<StatType> getAddedDataRandomer(Object parent,
            Map<String, String> paramMap){

        String params = paramMap.get(ADDED_STAT_TYPE_KEY);
        if (params == null){
            return data.getDefaultAddedStatTypeRandomer();
        }

        String[] funcWeights = params.split("#");

        List<LeftIntPair<StatType>> pairs = Lists.newLinkedList();
        for (String funcWeight : funcWeights){
            int idx = funcWeight.indexOf("|");
            checkArgument(
                    idx > 0 && idx < funcWeight.length() - 1,
                    "MountEquipmentRandomer配置的%s 的附加属性类型参数配置错误，参数格式 : 1|1#2|2#3|3，param: %s parent:%s",
                    data, params, parent);

            int addedStatType = Integer.parseInt(funcWeight.substring(0, idx));
            int weight = Integer.parseInt(funcWeight.substring(idx + 1));

            StatType statType = checkNotNull(
                    StatType.valueOf(addedStatType),
                    "MountEquipmentRandomer配置的%s 的附加属性类型参数存在无效的属性类型，invalid:%s param: %s parent:%s",
                    data, addedStatType, params, parent);

            checkNotNull(
                    data.getAddedStatGroup(statType),
                    "MountEquipmentRandomer配置的%s 中不存在的附加属性类型，invalid:%s param: %s parent:%s",
                    data, statType, params, parent);

            pairs.add(new LeftIntPair<StatType>(weight, statType));
        }

        return new WeightedRandomer<StatType>(pairs);
    }

    @Override
    public boolean hasRandomProperties(){
        return hasRandomProperties;
    }

    private boolean checkHasRandomProperties(){
        if (refinedTimsRandomer != null && refinedTimsRandomer.size() > 1){
            return true;
        }

        if (qualityRandomer.size() > 1){
            return true;
        } else{

            if (data.getQualityDatas().get(qualityRandomer.getSingleValue()).addedStatCount > 0){
                if (addedStatTypeRandomer.size() > 1){
                    return true;
                }
            }
        }

        return false;
    }

    @Override
    public GoodsWrapper getGoodsWrapperWithCount(int count){

        int refinedTimes = randomRefinedTimes();
        Quality quality = randomQuality();
        StatType statType = addedStatTypeRandomer.next();

        GoodsWrapper wrapper = new GoodsWrapper(data, binded, count,
                expireTime, duration, false, refinedTimes, quality.getNumber(),
                statType.getNumber(), tab);

        return wrapper;
    }

    @Override
    public Goods create(long ctime){
        MountEquipment e = data.newEquipment(getGoodsExpireTime(ctime),
                randomRefinedTimes(), randomStatType().getNumber(),
                randomQuality().getNumber());

        if (binded)
            e.bind();

        return e;
    }

    @Override
    public Goods createWithCount(long ctime, int count){
        assert count == 1;

        return create(ctime);
    }

    private int randomRefinedTimes(){
        if (refinedTimsRandomer == null){
            return 0;
        }

        return refinedTimsRandomer.next();
    }

    private Quality randomQuality(){
        return qualityRandomer.next();
    }

    private StatType randomStatType(){
        return addedStatTypeRandomer.next();
    }
}
