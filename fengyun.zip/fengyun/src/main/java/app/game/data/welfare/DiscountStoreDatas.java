package app.game.data.welfare;

import static com.google.common.base.Preconditions.checkArgument;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import app.game.data.GameObjects;
import app.game.data.ServerData;
import app.game.data.goods.GoodsDatas;
import app.game.module.promotion.PromotionSinceServerStart;
import app.game.service.IThreadService;
import app.utils.IndividualServerConfig;

import com.google.inject.Inject;
import com.mokylin.collection.Pair;
import com.mokylin.sink.util.parse.ObjectParser;
import com.mokylin.sink.util.parse.ObjectParsers;

/**
 * @author Liwei
 *
 */
public class DiscountStoreDatas{

    public static final String FOLDER_LOCATION = "config/data/promotion/discount_store";

    private final GoodsDatas goodsDatas;

    private final IThreadService threadService;

    private final ServerData[] serverDatas;

    private final PromotionSinceServerStart serverStartPromotion;

    private volatile DiscountStoreData[] datas;

    @Inject
    DiscountStoreDatas(GameObjects go, GoodsDatas goodsDatas,
            IThreadService threadService, IndividualServerConfig serverConfig,
            PromotionSinceServerStart serverStartPromotion){
        this.goodsDatas = goodsDatas;
        this.threadService = threadService;
        this.serverDatas = serverConfig.getServerDatas();
        this.serverStartPromotion = serverStartPromotion;

        doLoadConfig(go);
    }

    public DiscountStoreData getCurrentData(long ctime, int serverSequence){
        DiscountStoreData[] list = datas;
        if (list == null){
            return null;
        }

        for (DiscountStoreData data : list){
            if (data.getPromotionTimeData().isCurrentTimeInPromotionTime(ctime,
                    serverSequence)){
                return data;
            }
        }
        return null;
    }

    public void doLoadConfig(GameObjects go){
        Collection<Pair<String, String>> configs = go.getFileLoader()
                .loadFilesInFolder(FOLDER_LOCATION);

        List<DiscountStoreData> list = new ArrayList<>(configs.size());

        for (Pair<String, String> pair : configs){
            List<ObjectParser> parsers = ObjectParsers.parseList(pair.left,
                    pair.right, threadService.getDbExecutor());

            DiscountStoreData data = new DiscountStoreData(pair.left, parsers,
                    goodsDatas, serverDatas, serverStartPromotion);

            list.add(data);
        }

        // 检查, 如果是开服前的配置, 活动之间不能有重叠的时间
        for (DiscountStoreData data : list){
            for (DiscountStoreData data1 : list){
                checkArgument(
                        !data.getPromotionTimeData().isTimeOverlap(
                                data1.getPromotionTimeData()),
                        "折扣店, 活动时间有重叠: %s, %s", data, data1);
            }
        }

        this.datas = list.toArray(DiscountStoreData.EMPTY_ARRAY);
    }
}
