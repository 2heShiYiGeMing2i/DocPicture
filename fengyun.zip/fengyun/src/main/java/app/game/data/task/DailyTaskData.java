package app.game.data.task;

import static com.mokylin.sink.util.Preconditions.checkArgument;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.data.Prize;
import app.game.data.task.TaskDatas.TaskType;
import app.game.data.task.TaskTarget.TaskTargetProgress;
import app.game.module.TaskMessages;
import app.protobuf.TaskContent.DailyTaskProto;
import app.protobuf.TaskContent.TaskDataProto;

/**
 * @author Liwei
 *
 */
public class DailyTaskData{

    static final DailyTaskData[] EMPTY_ARRAY = new DailyTaskData[0];

    final int id;

    final int diffiStar;

    final int prizeStar;

    final TaskData taskData;

    final DailyTaskPrize dailyTaskPrize;

    final Prize prize;

    final TaskDataProto taskProto;

    private final transient TaskTargetProgress[] emptyProgress;

    private DailyTaskData oneStarDiffiTask;

    private DailyTaskData fullStarPrizeTask;

    final transient ChannelBuffer reduceDiffiBuffer;

    DailyTaskData(int id, int diffiStar, int prizeStar, TaskTarget[] targets,
            DailyTaskPrize dailyTaskPrize){
        this.id = id;
        this.diffiStar = diffiStar;
        this.prizeStar = prizeStar;
        this.dailyTaskPrize = dailyTaskPrize;
        this.prize = dailyTaskPrize.getPrizes(prizeStar);

        taskData = TaskData.newDailyTask(targets);
        taskProto = taskData.encodeData(prize);

        emptyProgress = taskData.newEmptyProgress(0);

        if (isMinDiffiTask()){
            byte[][] targetDatas = new byte[taskData.targets.length][];
            for (int i = 0; i < taskData.targets.length; i++){
                targetDatas[i] = taskData.targets[i].encode().toByteArray();
            }

            reduceDiffiBuffer = TaskMessages
                    .getDailyTaskReduceDiffiMsg(targetDatas);
        } else{
            reduceDiffiBuffer = null;
        }
    }

    void setOneStarDiffiTask(DailyTaskData oneStarDiffiTask){
        checkArgument(this.oneStarDiffiTask == null, "日常任务一星难度任务设置了多次");

        this.oneStarDiffiTask = oneStarDiffiTask;

        checkArgument(oneStarDiffiTask.diffiStar == 1, "%s的一星任务难度列表中的难度星级不是1",
                this);
        checkArgument(oneStarDiffiTask.prizeStar == prizeStar,
                "%s的一星任务难度列表中的奖励星级不一致", this);
        checkArgument(oneStarDiffiTask.reduceDiffiBuffer != null,
                "%s的一星任务难度列表中的任务没有reduceDiffiBuffer", this);

        checkArgument(oneStarDiffiTask.diffiStar == 1, "%s的一星任务难度列表中的难度星级不是1",
                this);
    }

    void setFullStarPrizeTask(DailyTaskData fullStarPrizeTask){
        checkArgument(this.fullStarPrizeTask == null, "日常任务满星奖励任务设置了多次");

        this.fullStarPrizeTask = fullStarPrizeTask;

        checkArgument(fullStarPrizeTask.isMaxPrizeTask(),
                "%s的满星奖励任务星级不是%s，奖励星级：%s", this, DailyTaskDatas.PRIZE_MAX_STAR,
                fullStarPrizeTask.prizeStar);
    }

    public int getIntType(){
        return TaskType.DAILY.getIntType();
    }

    DailyTaskData getOneStarDiffiTask(){
        return oneStarDiffiTask;
    }

    DailyTaskData getFullStarPrizeTask(){
        return fullStarPrizeTask;
    }

    Prize getPrize(){
        return prize;
    }

    ChannelBuffer getAddToFullStarPrizeBuffer(){
        return dailyTaskPrize.addToFullStarPrizeBuffer;
    }

    public Prize getAutoCompleteAllTaskPrize(int times){
        return dailyTaskPrize.getAutoCompleteAllTaskPrize(times);
    }

    boolean isMinDiffiTask(){
        return diffiStar <= 1;
    }

    boolean isMaxPrizeTask(){
        return prizeStar >= DailyTaskDatas.PRIZE_MAX_STAR;
    }

    DailyTask newEmptyTask(int taskId){
        return new DailyTask(taskId, this, taskData.newEmptyProgress(taskId));
    }

    DailyTask newTask(int taskId, TaskTargetProgress[] progress){
        return new DailyTask(taskId, this, taskData.newProgress(taskId,
                progress));
    }

    DailyTaskProto encode4Client(int round, int taskId){
        return encode4Client(round, taskId, emptyProgress);
    }

    DailyTaskProto encode4Client(int round, int taskId,
            TaskTargetProgress[] progress){
        return DailyTaskProto
                .newBuilder()
                .setRound(round)
                .setDiffiStar(diffiStar)
                .setPrizeStar(prizeStar)
                .setBaseTask(
                        TaskData.encodeTaskProto(taskId, taskProto, progress))
                .build();
    }

    @Override
    public String toString(){
        return "日常任务-" + id + "-" + diffiStar + "-" + prizeStar + "任务";
    }
}
