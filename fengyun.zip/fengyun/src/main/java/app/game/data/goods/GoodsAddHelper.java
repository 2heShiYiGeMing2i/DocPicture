package app.game.data.goods;

import com.mokylin.sink.util.Utils;

/**
 * @author Liwei
 *
 */
public abstract class GoodsAddHelper{

    public static final GoodsAddHelper[] EMPTY_ARRAY = new GoodsAddHelper[0];

    protected final GoodsData data;

    private final boolean binded;

    private final long expireTime;

    private final int maxCount;

    /**
     * 原来总共要添加的个数. 不像count, 不会变
     */
    private final int originalToAddCount;

    protected int count;

    // 辅助字段
    public int assistCount;

    // 辅助字段
    public GoodsAddHelper assistNext;

    // 辅助字段
    public int assistPos;

    public GoodsAddHelper(GoodsData data, int count, boolean binded,
            long expireTime){
        this.data = data;
        this.count = count;
        this.originalToAddCount = count;
        this.binded = binded;
        this.expireTime = expireTime;

        maxCount = data.getMaxCount();
    }

    public int getId(){
        return data.id;
    }

    public boolean needLog(){
        return data.needLog;
    }

    public int getOriginalToAddCount(){
        return originalToAddCount;
    }

    public int getCount(){
        return count;
    }

    public int getNeedEmptyPosCount(){
        return Utils.divide(count, maxCount);
    }

    public abstract Goods create();

    public abstract long getGoodsIdentifier();

    public GoodsData getData(){
        return data;
    }

    public boolean isFoldable(){
        return data.isFoldable();
    }

    public boolean canFold(Goods target){
        if (target.notFull() && isSameGoods(target)){
            return true;
        }

        return false;
    }

    public boolean isSameGoods(Goods target){
        return target.isSameGoods(data, binded, expireTime);
    }

    public void foldTo(Goods g){
        assert count > 0: "物品已经用完了，还来堆叠";

        if (count <= 0){
            return; // 防御性
        }

        if (g.getCount() + count > maxCount){
            int addCount = maxCount - g.getCount();
            foldTo(g, addCount);
        } else{
            foldTo(g, count);
        }
    }

    public void foldTo(Goods g, int foldCount){
        assert count >= foldCount: "没这么多物品给你堆叠";
        assert canFold(g): "物品不能堆叠，但是调用了foldTo方法";
        assert g.getCount() + foldCount <= g.getMaxCount(): "物品堆叠之后的个数超出物品最大个数";

        int realFoldCount = foldCount;
        if (count < realFoldCount){
            realFoldCount = count; // 防御性
        }

        if (g.getCount() + realFoldCount > maxCount){
            realFoldCount = maxCount - g.getCount();
        }

        g.addCount(realFoldCount);
        count -= realFoldCount;
    }
}