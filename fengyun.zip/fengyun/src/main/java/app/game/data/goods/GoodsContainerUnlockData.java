/**
 * 
 */
package app.game.data.goods;

import static com.mokylin.sink.util.Preconditions.*;

import java.util.Arrays;

import app.game.data.SpriteStat;
import app.game.data.SpriteStats;
import app.game.entity.Depot;
import app.game.entity.Storage;
import app.game.module.scene.FightData;
import app.protobuf.HeroContent.GoodsContainerUnlockProto;
import app.protobuf.SpriteStatContent.SpriteStatProto;

import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 * 
 */
public class GoodsContainerUnlockData{

    private static final GoodsContainerUnlockData[] EMPTY_DATAS = new GoodsContainerUnlockData[0];

    public static final GoodsContainerUnlockData FIRST_DEPOT_UNLOCK_DATA = new GoodsContainerUnlockData(
            Depot.DEPOT_INIT_SIZE);

    public static final GoodsContainerUnlockData FIRST_STORAGE_UNLOCK_DATA = new GoodsContainerUnlockData(
            Storage.STORAGE_INIT_SIZE);

    public final int openSlotCount;

    public final int unlockTime;

    public final int unlockCost;

    public final int exp;

    public final SpriteStat spriteStat;

    public final SpriteStatProto spriteStatProto;

    public final byte[] spriteStatData;

    private final int pos;

    public final GoodsContainerUnlockProto unlockDataProto;

    public final byte[] unlockDataProtoBytes;

    public transient SpriteStat accStat;

    public transient SpriteStatProto accStatProto;

    public transient byte[] accStatData;

    public transient GoodsContainerUnlockData nextLevel;

    public transient GoodsContainerUnlockData[] rowUnlockDatas = EMPTY_DATAS; // 初始化这个，init中修改

    private transient int fightingAmount;

    GoodsContainerUnlockData(int openSlotCount, ObjectParser p, int initSize,
            SpriteStats stats){
        this.openSlotCount = openSlotCount;
        unlockTime = p.getIntKey("unlock_time");
        unlockCost = p.getIntKey("unlock_cost");
        pos = initSize + openSlotCount - 1;

        exp = p.getIntKey("exp");

        checkArgument(unlockTime > 0, "物品容器解锁配置表%s 的解锁时间必须大于0，unlockTime - %s",
                openSlotCount, unlockTime);

        checkArgument(unlockCost > 0, "物品容器解锁配置表%s 的解锁花费必须大于0，unlockCost - %s",
                openSlotCount, unlockCost);
        checkArgument(exp > 0, "物品容器解锁配置表%s 的奖励经验值必须大于0，exp - %s",
                openSlotCount, exp);

        int statID = p.getIntKey("sprite_stat");
        spriteStat = checkNotNull(stats.get(statID),
                "物品容器解锁配置表%s 的属性id没找到: %s", openSlotCount, statID);
        spriteStatProto = spriteStat.encode();
        spriteStatData = spriteStatProto.toByteArray();
        accStat = spriteStat;
        accStatProto = accStat.encode();
        accStatData = accStatProto.toByteArray();

        unlockDataProto = encode();
        unlockDataProtoBytes = unlockDataProto.toByteArray();
    }

    public void init(GoodsContainerUnlockData previousLevel, int rowCount,
            GoodsContainerUnlockData[] datas){
        previousLevel.nextLevel = this;
        accStat = previousLevel.accStat.add(spriteStat);
        accStatProto = accStat.encode();
        accStatData = accStatProto.toByteArray();

        int cacheCount = rowCount - pos % rowCount;

        int startPos = openSlotCount;

        int endPos = Math.min(startPos + cacheCount, datas.length);

        rowUnlockDatas = Arrays.copyOfRange(datas, startPos, endPos);

        fightingAmount = FightData.calculateFightingAmount(accStat);
    }

    private GoodsContainerUnlockData(int initSize){
        openSlotCount = 0;
        unlockTime = 0;
        unlockCost = 0;
        exp = 0;
        pos = initSize - 1;

        spriteStat = accStat = SpriteStat.EMPTY_STAT;
        spriteStatProto = spriteStat.encode();
        spriteStatData = spriteStatProto.toByteArray();

        accStatProto = accStat.encode();
        accStatData = accStatProto.toByteArray();

        unlockDataProto = encode();
        unlockDataProtoBytes = unlockDataProto.toByteArray();
    }

    public boolean isMaxLevel(){
        return nextLevel == null;
    }

    public int getFightingAmount(){
        return fightingAmount;
    }

    public GoodsContainerUnlockProto encode(){
        return GoodsContainerUnlockProto.newBuilder().setUnlockTime(unlockTime)
                .setUnlockCost(unlockCost).setExp(exp)
                .setSpriteStat(spriteStatProto).setOpenSlotCount(openSlotCount)
                .build();
    }
}
