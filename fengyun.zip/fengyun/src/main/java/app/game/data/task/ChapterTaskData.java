package app.game.data.task;

import static com.mokylin.sink.util.Preconditions.checkArgument;
import static com.mokylin.sink.util.Preconditions.checkNotNull;

import java.util.EnumMap;
import java.util.EnumSet;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.data.Prize;
import app.game.data.PrizeConfig;
import app.game.data.task.TaskDatas.TaskType;
import app.game.data.task.TaskTarget.TaskTargetProgress;
import app.game.module.TaskMessages;
import app.protobuf.HeroServerContent.RaceId;
import app.protobuf.TaskContent.TaskDataProto;
import app.protobuf.TaskContent.TaskProto;
import app.protobuf.TaskContent.TaskRelatedFunction;

import com.google.common.collect.Maps;
import com.google.protobuf.ByteString;
import com.mokylin.sink.util.Utils;

/**
 * @author Liwei
 *
 */
public class ChapterTaskData{

    // 任务ID
    final int taskId;

    // 章节号，从1开始
    final int chapter;

    // 章节名称
//    final String chapterName;

    // 任务索引，从1开始
    final int index;

    // 由章节号和索引组成
    final transient int chapterAndIndex;

    final TaskData taskData;

    // 前一个任务
    final ChapterTaskData prevTask;

    // 下一个任务
    private ChapterTaskData nextTask;

    final ByteString[] completedTaskNames;

    final ChannelBuffer completeTaskBuffer;

    final ChapterTaskRaceData fixedRaceData;

    final EnumMap<RaceId, ChapterTaskRaceData> raceDataMap;

    /**
     * 完成这个任务开启的新功能
     */
    final TaskRelatedFunction func;

    final ChannelBuffer newFunctionMsg;

    final long funcBitData;

    final EnumSet<TaskRelatedFunction> funcSet;

    ChapterTaskData(int taskId, int chapter, int index, TaskData taskData,
            PrizeConfig prizeConfig, int intFunc, ChapterTaskData prevTask,
            ByteString[] completedTaskNames){
        this.taskId = taskId;
        this.chapter = chapter;
        this.index = index;
        this.taskData = taskData;
        this.prevTask = prevTask;
        this.completedTaskNames = completedTaskNames;

        chapterAndIndex = Utils.short2Int(chapter, index);
        completeTaskBuffer = TaskMessages.completeTaskMsg(taskId);

        if (prizeConfig.isRaceDiff()){
            fixedRaceData = null;
            raceDataMap = Maps.newEnumMap(RaceId.class);
            for (RaceId raceId : RaceId.values()){
                raceDataMap.put(raceId,
                        new ChapterTaskRaceData(prizeConfig.random(raceId)));
            }
        } else{
            Prize prize = prizeConfig.random();
            fixedRaceData = new ChapterTaskRaceData(prize);
            raceDataMap = null;
        }

        checkArgument(fixedRaceData != null || raceDataMap != null,
                "fixedRaceData == null && raceDataMap == null");

        if (intFunc > 0){
            func = checkNotNull(TaskRelatedFunction.valueOf(intFunc),
                    "%s 配置的新功能开启ID无效，%s", this, intFunc);
            newFunctionMsg = TaskMessages.newFunctionMsg(intFunc);

            funcSet = EnumSet.of(func);
            if (prevTask == null){
                funcBitData = 1L << (func.getNumber() - 1);
            } else{
                long bit = 1L << (func.getNumber() - 1);

                checkArgument((prevTask.funcBitData & bit) == 0,
                        "%s 配置的新功能开启ID重复了，%s", this, intFunc);

                funcBitData = prevTask.funcBitData
                        | (1L << (func.getNumber() - 1));

                for (TaskRelatedFunction f : prevTask.funcSet){
                    funcSet.add(f);
                }
            }
        } else{
            func = null;
            newFunctionMsg = null;

            if (prevTask == null){
                funcBitData = 0;
                funcSet = EnumSet.noneOf(TaskRelatedFunction.class);
            } else{
                funcBitData = prevTask.funcBitData;
                funcSet = prevTask.funcSet;
            }
        }

        if (prevTask != null){
            checkArgument(prevTask.nextTask == null, "%s 的下级任务重复了", prevTask);

            prevTask.nextTask = this;
        }
    }

    ChapterTaskData getNextTask(){
        return nextTask;
    }

    public int getIntType(){
        return TaskType.CHAPTER.getIntType();
    }

    TaskRelatedFunction getNewFunction(){
        return func;
    }

    ChannelBuffer getNewFunctionMsg(){
        return newFunctionMsg;
    }

    public long getFuncBitData(){
        return funcBitData;
    }

    public EnumSet<TaskRelatedFunction> getFuncions(){
        return funcSet;
    }

    TaskProto getTaskProtoOnLogin(RaceId raceId){
        return getRaceData(raceId).taskProtoOnLogin;
    }

    ChannelBuffer getNewTaskBuffer(RaceId raceId){
        return getRaceData(raceId).newTaskBuffer;
    }

    TaskDataProto getTaskProto(RaceId raceId){
        return getRaceData(raceId).taskProto;
    }

    Prize getPrize(RaceId raceId){
        return getRaceData(raceId).prize;
    }

    private ChapterTaskRaceData getRaceData(RaceId raceId){
        ChapterTaskRaceData raceData = fixedRaceData;
        if (raceData == null){
            raceData = raceDataMap.get(raceId);
        }
        return raceData;
    }

    ChapterTask newEmptyTask(){
        return new ChapterTask(this, taskData.newEmptyProgress(taskId));
    }

    ChapterTask newTask(TaskTargetProgress[] progress){
        return new ChapterTask(this, progress);
    }

    @Override
    public String toString(){
        return "第" + chapter + "章第" + index + "个任务";
    }

    private class ChapterTaskRaceData{
        final ChannelBuffer newTaskBuffer;

        // 不包括接受任务对白和任务进度
        final TaskProto taskProtoOnLogin;

        final Prize prize;

        final TaskDataProto taskProto;

        private ChapterTaskRaceData(Prize prize){
            this.prize = prize;

            taskProto = taskData.encodeData(prize);

            newTaskBuffer = TaskMessages.getNewChapterTaskMsg(
                    chapter,
                    TaskData.encodeTaskProto(taskId, taskProto,
                            taskData.newEmptyProgress(taskId)));

            // 不包含任务对白
            TaskDataProto.Builder dataProtoBuilder = taskProto.toBuilder();
            dataProtoBuilder.clearAcceptDialog();

            taskProtoOnLogin = TaskData.encodeTaskProto(taskId,
                    dataProtoBuilder.build(), new TaskTargetProgress[0]);
        }
    }
}
