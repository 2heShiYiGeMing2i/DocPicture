package app.game.data.goods;

import java.util.ArrayDeque;

import app.game.entity.Depot;

import com.mokylin.collection.IntHashMap;
import com.mokylin.collection.LongArrayList;

/**
 * @author Liwei
 *
 */
public class GoodsTryAddResult{

    public static GoodsTryAddResult current(){
        return localObject.get();
    }

    private static final ThreadLocal<GoodsTryAddResult> localObject = new ThreadLocal<GoodsTryAddResult>(){
        protected GoodsTryAddResult initialValue(){
            return new GoodsTryAddResult();
        }
    };

    private boolean success;

    private final IntHashMap<GoodsAddHelper> foldableMap;

    private final ArrayDeque<Integer> emptyPosList;

//    private final IntArrayList emptyPosList;

    private final LongArrayList foldPosCountList;

    private GoodsTryAddResult(){
        foldableMap = new IntHashMap<>();
        emptyPosList = new ArrayDeque<>(Depot.DEPOT_MAX_SIZE);
        foldPosCountList = new LongArrayList();
    }

    public void clear(){
        success = false;
        foldableMap.clear();
        emptyPosList.clear();
        foldPosCountList.clear();
    }

    public boolean checkStatus(){
        return !success && foldableMap.isEmpty() && emptyPosList.isEmpty()
                && foldPosCountList.isEmpty();
    }

    public void setSuccess(){
        success = true;
    }

    public boolean isSuccess(){
        return success;
    }

    public IntHashMap<GoodsAddHelper> getFoldableMap(){
        return foldableMap;
    }

    public ArrayDeque<Integer> getEmptyPosList(){
        return emptyPosList;
    }

    public LongArrayList getFoldPosCountList(){
        return foldPosCountList;
    }
}