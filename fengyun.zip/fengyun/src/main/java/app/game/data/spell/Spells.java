package app.game.data.spell;

import static com.mokylin.sink.util.Preconditions.checkArgument;

import java.util.Collection;

import app.game.data.goods.GoodsDatas;
import app.protobuf.ConfigContent.FirstLevelActiveSpell;

import com.google.inject.Inject;
import com.mokylin.collection.IntHashMap;

public class Spells{

    public final FightStates fightStates;
    private final SingleEffectSpells singleEffectSpells;
    public final PassiveSpells passiveSpells;
    public final Auras auras;

    private final SpellXinfaEffects xinfaEffects;

    private final IntHashMap<Spell> spells;
    private final IntHashMap<Spell> firstLevels;

    @Inject
    Spells(FightStates fightStates, SingleEffectSpells ses, PassiveSpells ps,
            Auras as, SpellXinfaEffects xinfaEffects, GoodsDatas goods){
        this.fightStates = fightStates;
        this.singleEffectSpells = ses;
        this.passiveSpells = ps;
        this.auras = as;
        this.xinfaEffects = xinfaEffects;

        this.spells = new IntHashMap<Spell>();

        Collection<SpellXinfaEffect> xinfaEffectList = xinfaEffects.all();

        for (SingleEffectSpell sp : singleEffectSpells.map.values()){
            // init 心法
            sp.initXinfaSpell(xinfaEffectList);

            Spell old = spells.put(sp.id, sp);
            checkArgument(old == null, "技能ID重复，技能1:[%s] 技能2:[%s]", old, sp);
        }

        for (Spell sp : passiveSpells.map.values()){
            Spell old = spells.put(sp.id, sp);
            checkArgument(old == null, "技能ID重复，技能1:[%s] 技能2:[%s]", old, sp);
        }

        firstLevels = new IntHashMap<>();

        for (Spell sp : singleEffectSpells.firstLevels.values()){
            Spell old = firstLevels.put(sp.spellType, sp);
            checkArgument(old == null, "技能Type重复，技能1:[%s] 技能2:[%s]", old, sp);
        }

        for (Spell sp : passiveSpells.firstLevels.values()){
            Spell old = firstLevels.put(sp.spellType, sp);
            checkArgument(old == null, "技能Type重复，技能1:[%s] 技能2:[%s]", old, sp);
        }

        goods.initSpell(this);
    }

    public SingleEffectSpells getSingleEffectSpells(){
        return singleEffectSpells;
    }

    public PassiveSpells getPassiveSpells(){
        return passiveSpells;
    }

    public SpellXinfaEffects getXinfaEffects(){
        return xinfaEffects;
    }

    public Spell get(int id){
        return spells.get(id);
    }

    public Spell getFirstLevelSpell(int spellType){
        return firstLevels.get(spellType);
    }

    public FirstLevelActiveSpell generateFirstLevelProto(){
        FirstLevelActiveSpell.Builder builder = FirstLevelActiveSpell
                .newBuilder();
        for (SingleEffectSpell sp : singleEffectSpells.firstLevels.values()){
            if (sp.canBeLearnedByHero()){ // 只发英雄能学会的技能
                builder.addFirstLevel(sp.generateAsFirstSpell());
            }
        }

        for (PassiveSpell sp : passiveSpells.firstLevels.values()){
            if (sp.canBeLearnedByHero()){ // 只发英雄能学会的技能
                builder.addFirstLevel(sp.generateAsFirstSpell());
            }
        }

        return builder.build();
    }
}
