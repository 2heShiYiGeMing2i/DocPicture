package app.game.data.divine;

import java.util.concurrent.LinkedTransferQueue;
import java.util.concurrent.atomic.AtomicStampedReference;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.data.ConfigService;
import app.game.entity.User;
import app.game.module.DivineMessages;
import app.protobuf.HeroServerContent.DivineGlobalLogConfig;
import app.utils.VariableConfig;

import com.google.inject.Inject;
import com.google.protobuf.InvalidProtocolBufferException;
import com.mokylin.sink.util.BufferUtil;
import com.mokylin.sink.util.concurrent.PaddedAtomicInteger;

/**
 * @author Liwei
 *
 */
public class DivineGlobalLogs{

    private final PaddedAtomicInteger logCount;

    private final LinkedTransferQueue<DivineGlobalLog> globalLogs;

    private final AtomicStampedReference<ChannelBuffer> bufferReference;

    private final PaddedAtomicInteger stamp;

    @Inject
    DivineGlobalLogs(){
        logCount = new PaddedAtomicInteger();

        globalLogs = new LinkedTransferQueue<>();

        bufferReference = new AtomicStampedReference<ChannelBuffer>(null, 0);

        stamp = new PaddedAtomicInteger();
    }

    public ChannelBuffer getDivineGlobalLogMsg(){

        ChannelBuffer buffer = bufferReference.getReference();

        if (buffer == null){
            buffer = DivineMessages.divineGlobalLog(this);

            int stamp = bufferReference.getStamp();
            bufferReference.compareAndSet(null, buffer, stamp, newStamp());
        }

        return buffer;
    }

    public void addLog(DivineGlobalLog log){

        globalLogs.add(log);

        int count = logCount.incrementAndGet();
        if (count > VariableConfig.DIVINE_LOG_MAX_COUNT){
            globalLogs.poll();
            logCount.decrementAndGet();
        }

        bufferReference.set(null, newStamp());
    }

    private int newStamp(){
        return stamp.incrementAndGet();
    }

    public void writeData(ChannelBuffer buffer){
        for (DivineGlobalLog log : globalLogs){
            BufferUtil.writeVarInt64(buffer, log.heroId);
            BufferUtil.writeUTF(buffer, log.heroName);

            byte[] staticData = log.data.getProtoBytes();
            BufferUtil.writeVarInt32(buffer, staticData.length);
            buffer.writeBytes(staticData);
            BufferUtil.writeVarInt32(buffer, log.dynamicData.length);
            buffer.writeBytes(log.dynamicData);
        }
    }

    public DivineGlobalLogConfig encode(){
        DivineGlobalLogConfig.Builder builder = DivineGlobalLogConfig
                .newBuilder();

        for (DivineGlobalLog log : globalLogs){
            builder.addLog(log.encode());
        }

        return builder.build();
    }

    public void decode(byte[] data, ConfigService configService){

        if (data == null || data.length <= 0){
            return;
        }

        DivineGlobalLogConfig config = null;
        try{
            config = DivineGlobalLogConfig.parseFrom(data,
                    User.extensionRegistry);
        } catch (InvalidProtocolBufferException e){
            e.printStackTrace();
        }

        if (config == null || config.getLogCount() <= 0){
            return;
        }

        int count = Math.min(config.getLogCount(),
                VariableConfig.DIVINE_LOG_MAX_COUNT);

        for (int i = 0; i < count; i++){
            DivineGlobalLog log = DivineGlobalLog.decode(config.getLog(i),
                    configService);
            if (log == null)
                continue;

            globalLogs.add(log);
            logCount.incrementAndGet();
        }
    }
}
