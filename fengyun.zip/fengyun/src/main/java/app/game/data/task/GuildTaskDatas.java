package app.game.data.task;

import static com.mokylin.sink.util.Preconditions.checkArgument;
import static com.mokylin.sink.util.Preconditions.checkNotNull;

import java.util.List;

import app.game.data.GameObjects;
import app.game.data.Prize;
import app.game.data.PrizeConfig;
import app.game.data.PrizeConfigs;
import app.game.data.goods.GoodsDatas;
import app.game.data.scene.CollectObjects;
import app.game.data.scene.MonsterData;
import app.game.data.scene.MonsterDatas;
import app.game.data.scene.Npcs;
import app.game.data.scene.SceneDatas;
import app.protobuf.ConfigContent.TaskConfig;
import app.utils.VariableConfig;

import com.google.common.collect.Lists;
import com.mokylin.collection.IntHashMap;
import com.mokylin.sink.util.RandomNumber;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * 帮派任务
 * @author Liwei
 *
 */
public class GuildTaskDatas{

    private static final String LOCATION = "config/data/task/guild_task.txt";

    private final IntHashMap<GuildTaskData> taskMap;

    private final GuildTaskData[][] levelTaskDatas;

    private final Prize extraPrize;

    GuildTaskDatas(GameObjects go, Npcs npcs, GoodsDatas goodsDatas,
            MonsterDatas monsters, PrizeConfigs prizes,
            CollectObjects collectObjects, SceneDatas sceneDatas,
            VariableConfig variableConfig, IntHashMap<MonsterData> monLevelMap){

        // 帮派额外奖励
        PrizeConfig extraPrizeConfig = checkNotNull(
                prizes.get(variableConfig.GUILD_TASK_EXTRA_PRIZE_NAME),
                "帮派任务没有配置帮派任务额外奖励，prizeName: %s",
                variableConfig.GUILD_TASK_EXTRA_PRIZE_NAME);

        checkArgument(!extraPrizeConfig.isVarPrize(), "帮派任务额外奖励中配置了随机属性的物品");

        checkArgument(!extraPrizeConfig.hasExipreTimeGoods(),
                "帮派任务额外奖励中配置了有过期时间的物品");

        checkArgument(!extraPrizeConfig.hasUnbindedGoods(),
                "帮派任务额外奖励中配置了非绑定的物品");

        checkArgument(!extraPrizeConfig.isRaceDiff(), "帮派任务额外奖励中配置了跟职业相关的物品");

        extraPrize = extraPrizeConfig.random();

        List<ObjectParser> data = go.loadFile(LOCATION);
        checkArgument(!data.isEmpty(), "帮派任务没有配置");

        taskMap = new IntHashMap<>();

        for (ObjectParser p : data){
            GuildTaskData task = new GuildTaskData(p, npcs, goodsDatas,
                    monsters, prizes, collectObjects, sceneDatas, monLevelMap,
                    extraPrize);
            taskMap.putUnique(task.id, task);
        }

        IntHashMap<List<GuildTaskData>> taskLevelMap = new IntHashMap<>();
        for (GuildTaskData task : taskMap.values()){
            for (int lv = task.minLevel; lv <= task.maxLevel; lv++){
                List<GuildTaskData> list = taskLevelMap.get(lv);
                if (list == null){
                    list = Lists.newLinkedList();
                    taskLevelMap.put(lv, list);
                }

                list.add(task);
            }
        }

        List<GuildTaskData> acceptLevelTaskList = checkNotNull(
                taskLevelMap.get(VariableConfig.GUILD_TASK_ACCEPT_LEVEL),
                "帮派任务开放等级为%s级，但是没有找到这个等级的帮派任务",
                VariableConfig.GUILD_TASK_ACCEPT_LEVEL);

        GuildTaskData[] acceptLevelTasks = acceptLevelTaskList
                .toArray(GuildTaskData.EMPTY_ARRAY);

        levelTaskDatas = new GuildTaskData[VariableConfig.HERO_MAX_LEVEL][];
        for (int lv = 1; lv <= VariableConfig.HERO_MAX_LEVEL; lv++){
            List<GuildTaskData> taskList = taskLevelMap.get(lv);
            if (taskList == null){
                if (lv <= VariableConfig.GUILD_TASK_ACCEPT_LEVEL){
                    levelTaskDatas[lv - 1] = acceptLevelTasks;
                } else{
                    levelTaskDatas[lv - 1] = levelTaskDatas[lv - 2];
                }
                continue;
            }

            levelTaskDatas[lv - 1] = taskList
                    .toArray(GuildTaskData.EMPTY_ARRAY);
        }
    }

    GuildTaskData random(int level){
        GuildTaskData[] taskDatas = null;

        if (level > 0 && level <= levelTaskDatas.length){
            taskDatas = levelTaskDatas[level - 1];
        } else if (level <= 0){
            taskDatas = levelTaskDatas[0];
        } else{
            taskDatas = levelTaskDatas[levelTaskDatas.length - 1];
        }

        return taskDatas[RandomNumber.getRate(taskDatas.length, true)];
    }

    GuildTaskData get(int guildTaskId){
        return taskMap.get(guildTaskId);
    }

    public Prize getExtraPrize(){
        return extraPrize;
    }

    void generateProto(TaskConfig.Builder builder){
        builder.setGuildTaskMaxRound(VariableConfig.GUILD_TASK_MAX_ROUND);
        builder.setGuildTaskExtraPrize(extraPrize.encode4Client());
        builder.setGuildTaskAutoCompleteCost(VariableConfig.GUILD_TASK_AUTO_COMPLETE_COST);
    }
}
