package app.game.data;

import static com.mokylin.sink.util.Preconditions.checkArgument;

import java.util.List;

import app.protobuf.ConfigContent.Config;

import com.google.inject.Inject;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.parse.ObjectParser;

public class Vips{

    private static final String LOCATION = "config/data/vip.txt";

    private final Vip[] vips;

    /**
     * 每级vip所需的exp. 第0个是0, 这个数组长度比vip的数组大1
     */
    private final int[] vipPerLevel;

    @Inject
    Vips(GameObjects go, PrizeConfigs prizes){
        List<ObjectParser> data = go.loadFile(LOCATION);

        int len = data.size();
        vips = new Vip[len];
        vipPerLevel = new int[len + 1];
        vipPerLevel[0] = 0;

        for (int i = 0; i < len; i++){
            Vip v = new Vip(data.get(i), i + 1, prizes);
            vips[i] = v;
            vipPerLevel[i + 1] = v.exp;
        }

        // -- 检查 --

        // 每一级所需exp必须>前一级
        for (int i = 1; i < len; i++){
            checkArgument(vips[i].exp > vips[i - 1].exp,
                    "vip所需的经验必须大于低级的vip: %s级%s exp, %s级%s exp", i + 1,
                    vips[i].exp, i, vips[i - 1].exp);

            checkArgument(
                    vips[i].replenishSignTimes >= vips[i - 1].replenishSignTimes,
                    "vip所需的补签必须大于低级的vip: %s级%s , %s级%s ", i + 1,
                    vips[i].replenishSignTimes, i,
                    vips[i - 1].replenishSignTimes);

            if (vips[i].canCollectOfflineExp2 != vips[i - 1].canCollectOfflineExp2){
                checkArgument(vips[i].canCollectOfflineExp2,
                        "vip不能领取2倍离线经验，但是低级的vip可以领取，vip: %s级", i + 1);
            }

            if (vips[i].canCollectOfflineExp3 != vips[i - 1].canCollectOfflineExp3){
                checkArgument(vips[i].canCollectOfflineExp3,
                        "vip不能领取3倍离线经验，但是低级的vip可以领取，vip: %s级", i + 1);
            }

            checkArgument(
                    vips[i].chanceTaskExtraSwallowCount >= vips[i - 1].chanceTaskExtraSwallowCount,
                    "vip的机缘任务额外吞噬次数居然比低级vip少， %s级", i + 1);

            checkArgument(
                    vips[i].chanceTaskExtraAcceptCount >= vips[i - 1].chanceTaskExtraAcceptCount,
                    "vip的机缘任务额外接受次数居然比低级vip少， %s级", i + 1);

//            if (vips[i].divineExtraTimes >= 0){
//                checkArgument(vips[i - 1].divineExtraTimes >= 0,
//                        "低级vip的知天命次数是无限次，但是高级vip就有次数限制了， %s级", i + 1);
//
//                checkArgument(
//                        vips[i].divineExtraTimes >= vips[i - 1].divineExtraTimes,
//                        "vip的知天命次数居然比低级vip少， %s级", i + 1);
//            }

            if (!vips[i].canMapTransport){
                checkArgument(!vips[i].canTaskTransport,
                        "vip的不能地图传送，但是可以任务传送， %s级", i + 1);

                checkArgument(!vips[i - 1].canMapTransport,
                        "vip的不能地图传送，但是低级的vip可以传送， %s级", i + 1);
            }

            if (!vips[i].canTaskTransport){
                checkArgument(!vips[i - 1].canTaskTransport,
                        "vip的不能任务传送，但是低级的vip可以传送， %s级", i + 1);
            }

            if (!vips[i].canAssistTransport){
                checkArgument(!vips[i - 1].canAssistTransport,
                        "vip的不能飞鞋传送，但是低级的vip可以传送， %s级", i + 1);
            }

            if (vips[i].canCollectVipSuperWeapon != vips[i - 1].canCollectVipSuperWeapon){
                checkArgument(vips[i].canCollectVipSuperWeapon,
                        "vip不能领取专属Vip神兵，但是低级的vip可以领取，vip: %s级", i + 1);
            }

            checkArgument(
                    vips[i].expExtraMultiple >= vips[i - 1].expExtraMultiple,
                    "高级vip的经验倍率必须大于低级的vip: %s级%s , %s级%s ", i + 1,
                    vips[i].expExtraMultiple, i, vips[i - 1].expExtraMultiple);

            checkArgument(
                    vips[i].realAirExtraMultiple >= vips[i - 1].realAirExtraMultiple,
                    "高级vip的真气倍率必须大于低级的vip: %s级%s , %s级%s ", i + 1,
                    vips[i].realAirExtraMultiple, i,
                    vips[i - 1].realAirExtraMultiple);

            if (vips[i].canFastCompleteDailyTask != vips[i - 1].canFastCompleteDailyTask){
                checkArgument(vips[i].canFastCompleteDailyTask,
                        "vip不能一键完成日常任务，但是低级的vip可以，vip: %s级", i + 1);
            }

            if (vips[i].canFastCompleteGuildTask != vips[i - 1].canFastCompleteGuildTask){
                checkArgument(vips[i].canFastCompleteGuildTask,
                        "vip不能一键完成帮派任务，但是低级的vip可以，vip: %s级", i + 1);
            }

            checkArgument(vips[i].freeChatTimes >= vips[i - 1].freeChatTimes,
                    "高级vip的免费喇叭次数必须大于低级的vip: %s级%s , %s级%s ", i + 1,
                    vips[i].freeChatTimes, i, vips[i - 1].freeChatTimes);

            checkArgument(
                    vips[i].depotOpenSlotSpeed >= vips[i - 1].depotOpenSlotSpeed,
                    "高级vip的背包开格子加速必须大于低级的vip: %s级%s , %s级%s ", i + 1,
                    vips[i].depotOpenSlotSpeed, i,
                    vips[i - 1].depotOpenSlotSpeed);

            checkArgument(
                    vips[i].storageOpenSlotSpeed >= vips[i - 1].storageOpenSlotSpeed,
                    "高级vip的仓库开格子加速必须大于低级的vip: %s级%s , %s级%s ", i + 1,
                    vips[i].storageOpenSlotSpeed, i,
                    vips[i - 1].storageOpenSlotSpeed);

            if (vips[i].canCollectPet != vips[i - 1].canCollectPet){
                checkArgument(vips[i].canCollectPet,
                        "vip不能领取宠物，但是低级的vip可以领取，vip: %s级", i + 1);
            }
        }

        Vip maxLevelVip = vips[vips.length - 1];
        checkArgument(maxLevelVip.canCollectOfflineExp2, "最高级的Vip都不能领取双倍经验，搞毛啊");
        checkArgument(maxLevelVip.canCollectOfflineExp3, "最高级的Vip都不能领取三倍经验，搞毛啊");

        checkArgument(maxLevelVip.hasStoryExtraPrize,
                "最高级的Vip都不能领取剧情副本额外礼包，搞毛啊");
        checkArgument(maxLevelVip.isStoryAutoFinishHalveTime,
                "最高级的Vip都不能减半剧情副本扫荡时间，搞毛啊");
        checkArgument(maxLevelVip.isStoryAutoFinishZeroTime,
                "最高级的Vip都不能立刻完成剧情副本扫荡，搞毛啊");

        checkArgument(maxLevelVip.canMapTransport, "最高级的Vip都不能地图传送，搞毛啊");
        checkArgument(maxLevelVip.canTaskTransport, "最高级的Vip都不能任务传送，搞毛啊");
        checkArgument(maxLevelVip.canCollectVipSuperWeapon,
                "最高级的Vip都不能领取专属神兵，搞毛啊");
    }

    public int getMaxVipLevel(){
        return vips.length + 1;
    }

    public Vip get(int level){
        if (level > 0 && level <= vips.length){
            return vips[level - 1];
        }

        return null;
    }

    public Vip[] all(){
        return vips;
    }

    public Vip getVipLevelByExp(int exp){
        int pos = Utils.binarySearchForFloorKey(vipPerLevel, exp);
        if (pos == 0){
            return null;
        }
        return vips[pos - 1];
    }

    public void encode(Config.Builder builder){
        for (Vip v : vips){
            builder.addVips(v.encode());
        }
    }
}
