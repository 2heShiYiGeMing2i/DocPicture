package app.game.data.weapon7;

import static com.mokylin.sink.util.Preconditions.*;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.data.SingleSpriteStat;
import app.game.data.SingleSpriteStats;
import app.game.data.SpriteStat;
import app.game.data.UpgradeData;
import app.game.data.goods.GoodsDatas;
import app.game.module.SuperWeaponMessages;
import app.game.module.scene.FightData;
import app.protobuf.SpriteStatContent.SingleStatProto;
import app.protobuf.SpriteStatContent.SpriteStatProto;

import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class SoulUpgradeData{

    // 神兵ID
    final int weapon;

    // 索引，从1开始，0号位被默认技能占用了
    final int index;

    /**
     * 第几页
     */
    transient final int page;

    // 点完最后一个点就算下一级了
    transient final int realLevel;

    // 升级数据
    final UpgradeData upgradeData;

    // 当前点的属性
    final SingleSpriteStat singleStat;

    final SingleStatProto singleStatProto;

    // 当前点的累计属性
    private final SpriteStat accStat;

    final SpriteStatProto accStatProto;

    private final int fightAmount;

    // 包含神兵基础属性的累计总属性
    final SpriteStat totalStat;

//    private final SpriteStatProto totalStatProto;

//    transient final int totalFightingAmount;

    transient final ChannelBuffer upgradeMsg;

    SoulUpgradeData nextLevel;

    SoulUpgradeData(int weapon, SpriteStat spriteStat){
        this.weapon = weapon;
        this.index = 0;
        this.page = 0;
        this.realLevel = 0;

        upgradeData = null;

        singleStat = null;
        singleStatProto = null;

        accStat = SpriteStat.EMPTY_STAT;
        accStatProto = accStat.encode();
        fightAmount = 0;

        totalStat = spriteStat;
//        totalStatProto = spriteStat.encode();

        upgradeMsg = null;
//        totalFightingAmount = FightData.calculateFightingAmount(totalStat);
    }

    SoulUpgradeData(int weapon, int stepPerLevel, int maxLevel, ObjectParser p,
            SingleSpriteStats spriteStats, GoodsDatas goodsDatas,
            SoulUpgradeData prevLevel){
        this.weapon = weapon;
        index = prevLevel.index + 1;
        page = (index - 1) / stepPerLevel; // level 从0开始
        realLevel = Math.min(index / stepPerLevel, maxLevel - 1); // 点完第一页就是二级的神兵

        upgradeData = new UpgradeData(this, p, goodsDatas);

        int statId = p.getIntKey("single_stat");
        singleStat = checkNotNull(spriteStats.get(statId), "%s 配置的属性没找到， %s",
                this, statId);
        singleStatProto = singleStat.encode();

        accStat = prevLevel.accStat.add(singleStat);
        accStatProto = accStat.encode();
        fightAmount = FightData.calculateFightingAmount(accStat);

        totalStat = prevLevel.totalStat.add(singleStat);
//        totalStatProto = totalStat.encode();
//        totalFightingAmount = FightData.calculateFightingAmount(totalStat);

        if (prevLevel.index > 0 && prevLevel.page == page){
            // 同一级的(如果是技能点，不做要求)，后面消耗比前面的大
            checkArgument(
                    prevLevel.upgradeData.getUpgradeMoneyCost() <= upgradeData
                            .getUpgradeMoneyCost(),
                    "%s 的%s级兵魂升级银两消耗居然比前一级的小", this);

            checkArgument(
                    prevLevel.upgradeData.getUpgradeRealAirCost() <= upgradeData
                            .getUpgradeRealAirCost(),
                    "%s 的%s级兵魂升级真气消耗居然比前一级的小", this);
        }

        checkArgument(prevLevel.nextLevel == null);

        prevLevel.nextLevel = this;

        upgradeMsg = SuperWeaponMessages.upgradeWeaponMsg(weapon, index - 1,
                upgradeData.getProto());
    }

    public int getIndex(){
        return index;
    }

    public int getRealLevel(){
        return realLevel;
    }

    public UpgradeData getUpgradeData(){
        return upgradeData;
    }

    private ChannelBuffer fullLevelUpgradeMsg;

    public ChannelBuffer getUpgradeMsg(){
        if (nextLevel != null)
            return nextLevel.upgradeMsg;

        if (fullLevelUpgradeMsg == null){
            fullLevelUpgradeMsg = SuperWeaponMessages.upgradeWeaponMsg(weapon,
                    index, null);
        }

        return fullLevelUpgradeMsg;
    }

    public SingleSpriteStat getSingleStat(){
        return singleStat;
    }

//    public int getFightingAmount(boolean hasUnlockWeapon){
//        return hasUnlockWeapon ? totalFightingAmount : accFightAmount;
//    }

    public int getFightingAmount(){
        return fightAmount;
    }

    public SpriteStat getTotalStat(boolean hasUnlockWeapon){
        return hasUnlockWeapon ? totalStat : accStat;
    }

    @Override
    public String toString(){
        return "神兵升级数据" + weapon + "-" + index;
    }
}
