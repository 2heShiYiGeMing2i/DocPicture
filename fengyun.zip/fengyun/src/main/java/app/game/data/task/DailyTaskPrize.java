package app.game.data.task;

import static com.mokylin.sink.util.Preconditions.checkArgument;
import static com.mokylin.sink.util.Preconditions.checkNotNull;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.data.Prize;
import app.game.data.PrizeConfig;
import app.game.data.PrizeConfigs;
import app.game.module.TaskMessages;
import app.utils.VariableConfig;

import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class DailyTaskPrize{

    final String name;

    private final Prize[] prizes;

    /**
     * 满星任务奖励缓存
     */
    private final Prize[] autoCompleteAllTaskPrizes;

    final ChannelBuffer autoCompleteAllTaskBuffer;

    final ChannelBuffer addToFullStarPrizeBuffer;

    DailyTaskPrize(ObjectParser p, PrizeConfigs prizeConfigs,
            Prize dailyTaskExtraPrize){
        name = p.getKey("name");

        String[] prizeStrs = p.getStringArray("prize");

        checkArgument(prizeStrs.length == DailyTaskDatas.PRIZE_MAX_STAR,
                "日常任务奖励表中配置的奖励个数不是%s 个", DailyTaskDatas.PRIZE_MAX_STAR);

        PrizeConfig[] prizeConfigArray = new PrizeConfig[DailyTaskDatas.PRIZE_MAX_STAR];
        for (int i = 0; i < DailyTaskDatas.PRIZE_MAX_STAR; i++){
            prizeConfigArray[i] = checkNotNull(prizeConfigs.get(prizeStrs[i]),
                    "日常任务奖励【%s】中配置的第%s个任务奖励不存在，奖励名称【%s】", name, (i + 1),
                    prizeStrs[i]);
        }

        PrizeConfig previous = prizeConfigArray[0];
        for (int i = 1; i < DailyTaskDatas.PRIZE_MAX_STAR; i++){
            PrizeConfig prize = prizeConfigArray[i];

            checkArgument(previous.getExp() <= prize.getExp(),
                    "日常任务奖励【%s】中配置的第%s个任务奖励的经验比下一星的奖励的经验还多", name, i);

            checkArgument(previous.getMoney() <= prize.getMoney(),
                    "日常任务奖励【%s】中配置的第%s个任务奖励的银两比下一星的奖励的银两还多", name, i);

            previous = prize;
        }

        int fullStarMoney = prizeConfigArray[DailyTaskDatas.PRIZE_MAX_STAR - 1]
                .getMoney();
        int oneStarMoney = prizeConfigArray[0].getMoney();
        checkArgument(
                fullStarMoney - oneStarMoney < VariableConfig.DAILY_TASK_ADD_PRIZE_COST,
                "日常任务奖励【%s】中配置的任务奖励，1星跟满星的银两差额小于将任务变成满星的消耗", name);

        prizes = new Prize[DailyTaskDatas.PRIZE_MAX_STAR];
        for (int i = 0; i < DailyTaskDatas.PRIZE_MAX_STAR; i++){
            PrizeConfig prizeConfig = prizeConfigArray[i];

            checkArgument(!prizeConfig.hasExipreTimeGoods(),
                    "日常任务奖励【%s】中配置了有过期时间的物品", name);
            checkArgument(!prizeConfig.isVarPrize(),
                    "日常任务奖励【%s】中配置了随机属性的物品", name);
            checkArgument(!prizeConfig.hasUnbindedGoods(),
                    "日常任务奖励【%s】中配置了非绑定的物品", name);
            checkArgument(!prizeConfig.isRaceDiff(), "日常任务奖励【%s】中配置了跟职业相关的物品",
                    name);

            prizes[i] = prizeConfig.random();
        }

        Prize fullStarPrize = prizes[DailyTaskDatas.PRIZE_MAX_STAR - 1];

        Prize.Builder builder = Prize.newBuilder();
        builder.add(dailyTaskExtraPrize);

        autoCompleteAllTaskPrizes = new Prize[VariableConfig.DAILY_TASK_MAX_ROUND];
        for (int i = 0; i < VariableConfig.DAILY_TASK_MAX_ROUND; i++){
            builder.add(fullStarPrize);
            autoCompleteAllTaskPrizes[i] = builder.build();
        }

        byte[] prizeBytes = fullStarPrize.encode4Client().toByteArray();
        addToFullStarPrizeBuffer = TaskMessages
                .getDailyTaskAddPrizeMsg(prizeBytes);
        autoCompleteAllTaskBuffer = TaskMessages
                .autoCompleteAllDailyTaskMsg(prizeBytes);
    }

    Prize getPrizes(int star){
        return prizes[star - 1];
    }

    Prize getAutoCompleteAllTaskPrize(int times){
        if (times > 0 && times <= VariableConfig.DAILY_TASK_MAX_ROUND){
            return autoCompleteAllTaskPrizes[times - 1];
        }

        return null;
    }
}
