package app.game.data.scene;

import static com.mokylin.sink.util.Preconditions.checkArgument;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.module.scene.JijianMessages;

import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class JijianCostData{

    /**
     * 祭剑次数
     */
    final int times;

    /**
     * 银两祭剑消耗
     */
    final int moneyCost;

    /**
     * 银两祭剑获得真气
     */
    final int realAir4Money;

    /**
     * 元宝祭剑消耗
     */
    final int yuanbaoCost;

    /**
     * 元宝祭剑获得真气
     */
    final int realAir4Yuanbao;

    /**
     * 扩散真气
     */
    final int radiateRealAir;

    private final ChannelBuffer radiateMsg;

    private final ChannelBuffer moneySwordSacrificeMsg;

    private final ChannelBuffer yuanbaoSwordSacrificeMsg;

    JijianCostData(ObjectParser p){
        times = p.getIntKey("times");
        moneyCost = p.getIntKey("money_cost");
        realAir4Money = p.getIntKey("money_real_air");
        yuanbaoCost = p.getIntKey("yuanbao_cost");
        realAir4Yuanbao = p.getIntKey("yuanbao_real_air");
        radiateRealAir = p.getIntKey("radiate_real_air");

        checkArgument(moneyCost > 0, "%s 的银两消耗必须大于0", this);
        checkArgument(realAir4Money > 0, "%s 的银两祭剑获得真气必须大于0", this);
        checkArgument(yuanbaoCost > 0, "%s 的元宝消耗必须大于0", this);
        checkArgument(realAir4Yuanbao > 0, "%s 的元宝祭剑获得真气必须大于0", this);
        checkArgument(radiateRealAir > 0, "%s 的扩散真气必须大于0", this);

        radiateMsg = JijianMessages.getRadiateToMeMsg(radiateRealAir);
        moneySwordSacrificeMsg = JijianMessages
                .getMoneySwordSacrificeMsg(times - 1, moneyCost, realAir4Money);

        yuanbaoSwordSacrificeMsg = JijianMessages
                .getYuanbaoSwordSacrificeMsg(times - 1, yuanbaoCost,
                        realAir4Yuanbao);
    }

    public int getMoneyCost(){
        return moneyCost;
    }

    public int getRealAir4Money(){
        return realAir4Money;
    }

    public int getYuanbaoCost(){
        return yuanbaoCost;
    }

    public int getRealAir4YB(){
        return realAir4Yuanbao;
    }

    public int getRadiateRealAir(){
        return radiateRealAir;
    }

    public ChannelBuffer getRadiateMsg(){
        return radiateMsg;
    }

    public ChannelBuffer getMoneySwordSacrificeMsg(){
        return moneySwordSacrificeMsg;
    }

    public ChannelBuffer getYuanbaoSwordSacrificeMsg(){
        return yuanbaoSwordSacrificeMsg;
    }

    @Override
    public String toString(){
        return "祭剑-" + times;
    }

}