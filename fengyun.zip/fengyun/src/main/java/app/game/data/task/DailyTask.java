package app.game.data.task;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.data.task.TaskTarget.TaskTargetProgress;
import app.protobuf.HeroServerContent.DailyTaskServerProto;
import app.protobuf.TaskContent.DailyTaskProto;

/**
 * @author Liwei
 *
 */
public class DailyTask{

    final int taskId;

    final DailyTaskData data;

    final TaskTargetProgress[] progress;

    DailyTask(int taskId, DailyTaskData data, TaskTargetProgress[] progress){
        this.taskId = taskId;
        this.data = data;
        this.progress = progress;
    }

    public boolean isAllProgressCompleted(){
        for (TaskTargetProgress p : progress){
            if (!p.isCompleted())
                return false;
        }

        return true;
    }

    public int getIntType(){
        return data.getIntType();
    }

    DailyTask newFullPrizeTask(){
        return new DailyTask(taskId, data.getFullStarPrizeTask(), progress);
    }

    public DailyTaskProto encode4Client(int round){
        return data.encode4Client(round, taskId, progress);
    }

    DailyTaskServerProto encode(){
        DailyTaskServerProto.Builder builder = DailyTaskServerProto
                .newBuilder();

        builder.setDailyTaskId(data.id);
        builder.setDiffiStar(data.diffiStar);
        builder.setPrizeStar(data.prizeStar);
        for (TaskTargetProgress p : progress){
            builder.addProgress(p.progress);
        }

        return builder.build();
    }

    static DailyTask decode(int taskId, DailyTaskData data,
            DailyTaskServerProto proto){
        return new DailyTask(taskId, data, data.taskData.newProgress(taskId,
                proto.getProgressList()));
    }

    public int getTaskId(){
        return taskId;
    }

    public int getRealTaskId(){
        return data.id;
    }

    public DailyTaskData getData(){
        return data;
    }

    public ChannelBuffer getAutoCompleteAllTaskBuffer(){
        return data.dailyTaskPrize.autoCompleteAllTaskBuffer;
    }

    public boolean isMinDiffiTask(){
        return data.isMinDiffiTask();
    }

    public boolean isMaxPrizeTask(){
        return data.isMaxPrizeTask();
    }

    public TaskTargetProgress[] getProgress(){
        return progress;
    }
}
