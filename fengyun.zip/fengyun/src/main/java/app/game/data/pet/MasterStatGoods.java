package app.game.data.pet;

import static com.mokylin.sink.util.Preconditions.*;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.data.SingleSpriteStat;
import app.game.data.SingleSpriteStats;
import app.game.data.goods.GoodsDatas;
import app.game.data.goods.PanelGoodsData;
import app.game.module.PetMessages;
import app.protobuf.ConfigContent.MasterStatGoodsProto;
import app.protobuf.GoodsContent.PanelGoodsDataProto.PanelType;
import app.protobuf.SpriteStatContent.StatType;

import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class MasterStatGoods{

    private final PanelGoodsData goods;

    private final SingleSpriteStat singleStat;

    private final ChannelBuffer useOneMsg;

    MasterStatGoods(ObjectParser p, GoodsDatas goodsDatas,
            SingleSpriteStats singleStats){

        int goodsId = p.getIntKey("goods");
        goods = checkNotNull(goodsDatas.getPanel(goodsId),
                "宠物喂食物品没找到（必须是打开宠物面板物品），%s", goodsId);

        checkArgument(goods.getPanel() == PanelType.PET,
                "宠物喂食物品 %s 的打开面板类型不是宠物", goods);

        int statId = p.getIntKey("single_stat");
        singleStat = checkNotNull(singleStats.get(statId),
                "宠物喂食物品 %s 的属性没找到，%s", goods, statId);

        checkArgument(
                singleStat.getStatType() == StatType.MAX_LIFE
                        || singleStat.getStatType() == StatType.ATTACK
                        || singleStat.getStatType() == StatType.DEFENCE,
                "宠物喂食物品 %s 的属性类型无效，%s", goods, singleStat);

        checkArgument(singleStat.getAmount() > 0, "宠物喂食物品 %s 的属性必须大于0，%s",
                goods, singleStat);

        useOneMsg = PetMessages.useMasterStatGoods(goodsId, 1);
    }

    public int getId(){
        return goods.id;
    }

    public PanelGoodsData getData(){
        return goods;
    }

    public StatType getStatType(){
        return singleStat.getStatType();
    }

    public int getAmount(){
        return singleStat.getAmount();
    }

    public int getAmount(int count){
        return singleStat.getAmount() * count;
    }

    public ChannelBuffer getUseOneMsg(){
        return useOneMsg;
    }

    public MasterStatGoodsProto encode(){
        return MasterStatGoodsProto.newBuilder().setGoods(goods.getProto())
                .setSingleStat(singleStat.encode()).build();
    }
}
