/**
 * 
 */
package app.game.data.scene;

import static com.mokylin.sink.util.Preconditions.*;

import java.util.List;

import app.game.data.GameObjects;
import app.game.shop.NpcShop;
import app.game.shop.Shop;
import app.game.shop.Shops;
import app.protobuf.ConfigContent.NpcData;

import com.google.common.collect.Lists;
import com.google.protobuf.ByteString;
import com.mokylin.collection.IntArrayList;
import com.mokylin.sink.util.Empty;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 * 
 */
public class Npc{

    private static final int TOO_FAR_DISTANCE = 8;

    /**
     * 系统生成，全局唯一
     */
    final int id;

    /**
     * NPC名称，全局唯一，不得重复
     */
    final String name;

    /**
     * 客户端显示名称
     */
    private final String displayName;

    /**
     * NPC称号
     */
    private final String title;

    /**
     * 资源
     */
    private final String role;

    /**
     * 资源左右倒转，true为倒转，默认提供右向资源，左向资源由程序进行倒转
     */
    private final boolean isReverse;

    /**
     * 头像
     */
    private final String head;

    /**
     * 等级
     */
    private final int level;

    /**
     * 所在场景，位置
     */
    private final SceneData sceneData;

    private final int posX;

    private final int posY;

    /**
     * 闲聊
     */
    private final String[] chat;

    /**
     * 闲聊间隔，单位毫秒
     */
    private final int chatInterval;

    /**
     * 功能面板对白
     */
    private final String dialog;

    /**
     * 功能类型，0-仓库 1-锻造 2-传送  商店>=20
     */
    private final int[] funcTypeList;

    private final String[] funcDescList;

//    private final NpcShop[] shopList;

    private final NpcTransportList transportData;

    public Npc(GameObjects go, ObjectParser parser, int id,
            SceneDatas sceneDatas, Shops shops){
        this.id = id;
        name = parser.getKey("name");
        displayName = getDisplayName(name);

        this.title = parser.getKey("title");
        this.role = parser.getKey("role");
        this.isReverse = parser.getBooleanKey("is_reverse");
        this.head = parser.getKey("head");
        this.level = parser.getIntKey("level");

        int sceneId = parser.getIntKey("scene");
        this.sceneData = checkNotNull(sceneDatas.get(sceneId),
                "没找到NPC %s-%s 所属的场景: %s", id, name, sceneId);
        checkArgument(sceneData.isNormalScene(), "%s 配置的场景不是普通场景", this);

        this.posX = parser.getIntKey("pos_x");
        this.posY = parser.getIntKey("pos_y");
        // 检查是否可行走
        checkArgument(sceneData.blockInfo.isWalkable(posX, posY),
                "NPC %s-%s 处于地图的不可行走点", id, name);

        String chatStr = parser.getKey("chat");
        if (chatStr.isEmpty()){
            this.chat = Empty.STRING_ARRAY;
            chatInterval = 0;
        } else{
            this.chat = chatStr.split(";");

            chatInterval = parser.getIntKey("chat_interval");
            checkArgument(chatInterval > 0, "NPC %s-%s 的闲聊时间间隔必须大于0", id, name);
        }

        this.dialog = parser.getKey("dialog");

        IntArrayList funcTypeList = new IntArrayList();
        List<String> funcDescList = Lists.newLinkedList();
//        List<NpcShop> shopList = Lists.newLinkedList();
        NpcTransportList transportData = null;
        boolean hasStorage = false;
        boolean hasBlacksmith = false;

        String[] functionList = parser.getStringArray("function");
        String[] functionDescList = parser.getStringArray("function_desc");

        checkArgument(functionList.length == functionDescList.length,
                "NPC %s-%s 的功能列表(function)个数与功能描述个数不一致，功能列表个数：%s 功能描述个数：%s",
                id, name, functionList.length, functionDescList.length);

        for (int i = 0; i < functionList.length; i++){
            String func = functionList[i];
            String funcDesc = functionDescList[i];
            checkArgument(func.isEmpty() == funcDesc.isEmpty(),
                    "NPC %s-%s 的第%s 个功能列表配置错误，缺少功能内容或者缺少功能描述", id, name, i + 1);

            if (func.isEmpty()){
                continue;
            }

            funcDescList.add(funcDesc);

            if (func.startsWith("shop_")){

                String shopName = func.substring("shop_".length());
                checkArgument(!shopName.isEmpty(),
                        "NPC %s-%s 的第%s 个功能列表配置的商店文件名找不到，func: %s", id, name,
                        i + 1, func);

                Shop shop = checkNotNull(shops.get(shopName),
                        "NPC %s-%s 的功能列表配置商店不存在，shop:%s", id, name, shopName);

                NpcShop npcShop = shops.newNpcShop(this, shop);

                checkArgument(
                        npcShop.id >= 20,
                        "NPC %s-%s 的商店Id无效，接口中约定，如果funcType>=20，表示这个是商店类型，并且这个数字是商店ID",
                        id, name, i + 1, func);

                funcTypeList.add(npcShop.id);
//                shopList.add(shops.newNpcShop(this, shop));
            } else if (func.startsWith("tp_")){
                // T1=传送

                checkArgument(
                        transportData == null,
                        "NPC %s-%s 配置了多个传送列表（一个NPC最多只能有一个传送列表），function_list：%s",
                        id, name, func);

                String tpName = func.substring("tp_".length());
                checkArgument(!tpName.isEmpty(),
                        "NPC %s-%s 的第%s 个功能列表配置的商店文件名找不到，func: %s", id, name,
                        i + 1, func);

                NpcTransportList npcTransportData = NpcTransportList
                        .newNpcTransportList(go, tpName, sceneDatas, this);

                funcTypeList.add(2);
                transportData = npcTransportData;
            } else if ("storage".equals(func)){
                checkArgument(!hasStorage,
                        "NPC %s-%s 配置了多个仓库列表，function_list：%s", id, name, func);

                hasStorage = true;
                funcTypeList.add(0);
            } else if ("blacksmith".equals(func)){
                checkArgument(!hasBlacksmith,
                        "NPC %s-%s 配置了多个锻造列表，function_list：%s", id, name, func);

                hasBlacksmith = true;
                funcTypeList.add(1);
            } else{
                throw new IllegalArgumentException("NPC " + id + "-" + name
                        + " 的第" + (i + 1) + "个功能列表的类型不支持，function：" + func);
            }
        }

        this.funcTypeList = funcTypeList.toArray();
//        this.shopList = shopList.toArray(NpcShop.EMPTY_ARRAY);
        this.funcDescList = funcDescList.toArray(Empty.STRING_ARRAY);
        this.transportData = transportData;
    }

    public int getId(){
        return id;
    }

    public String getName(){
        return name;
    }

    public SceneData getSceneData(){
        return sceneData;
    }

    public int getPosX(){
        return posX;
    }

    public int getPosY(){
        return posY;
    }

    public boolean isTooFar(int sceneId, int x, int y){
        if (sceneId == sceneData.id && Math.abs(x - posX) < TOO_FAR_DISTANCE
                && Math.abs(y - posY) < TOO_FAR_DISTANCE){
            return false;
        }

        return true;
    }

    public NpcTransportList getTransportData(){
        return transportData;
    }

    private String getDisplayName(String name){
        int underScorePos = name.indexOf("_");
        if (underScorePos < 0){
            return name;
        }

        return name.substring(0, underScorePos);
    }

    NpcData encode(){
        NpcData.Builder builder = NpcData.newBuilder();

        builder.setId(id).setName(ByteString.copyFromUtf8(displayName))
                .setTitle(ByteString.copyFromUtf8(title)).setRole(role)
                .setHead(head).setLevel(level).setSceneId(sceneData.id)
                .setPosX(posX).setPosY(posY).setChatInterval(chatInterval)
                .setDialog(ByteString.copyFromUtf8(dialog));

        if (isReverse){
            builder.setIsReverse(true);
        }

        for (String chatStr : chat){
            builder.addChat(ByteString.copyFromUtf8(chatStr));
        }

        for (int i = 0; i < funcTypeList.length; i++){
            builder.addFuncTypeList(funcTypeList[i]).addFuncDescList(
                    ByteString.copyFromUtf8(funcDescList[i]));
        }

        if (transportData != null){
            builder.setTransportData(transportData.encode());
        }

        return builder.build();
    }

    @Override
    public String toString(){
        return "NPC-" + name;
    }
}
