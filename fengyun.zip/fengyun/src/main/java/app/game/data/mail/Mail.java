package app.game.data.mail;

import java.util.List;

import app.game.data.ConfigService;
import app.game.data.goods.Goods;
import app.game.data.goods.GoodsAddHelper;
import app.game.data.goods.GoodsData;
import app.game.data.goods.GoodsWrapper;
import app.protobuf.GoodsServerContent.GoodsServerProto;
import app.protobuf.MailContent.MailProto;
import app.protobuf.MailServerContent.MailServerProto;

import com.google.common.collect.Lists;
import com.google.protobuf.ByteString;
import com.mokylin.collection.Pair;
import com.mokylin.sink.util.Empty;

/**
 * @author Liwei
 *
 */
public class Mail{

    @SuppressWarnings("unchecked")
    private static final Pair<GoodsData, GoodsServerProto>[] EMPTY_ARRAY = new Pair[0];

    public static final Mail newMail(long combineId, long sendTime,
            byte[] content, int money, int yuanbao, int bindedYuanbao){
        return new Mail(0, combineId, sendTime, content, money, yuanbao,
                bindedYuanbao, EMPTY_ARRAY);
    }

    public static final Mail newMail(long combineId, long sendTime,
            byte[] content, int money, int yuanbao, int bindedYuanbao,
            List<GoodsWrapper> mailGoods){
        List<Goods> list = Lists.newArrayList();
        for (GoodsWrapper wrapper : mailGoods){
            GoodsAddHelper gah = wrapper.newHelper(sendTime);
            int c = gah.getNeedEmptyPosCount();
            for (int i = 0; i < c; i++){
                list.add(gah.create());
            }
            assert gah.getCount() <= 0;
        }

        return newMail(combineId, sendTime, content, money, yuanbao,
                bindedYuanbao, list.toArray(Goods.EMPTY_GOODS_ARRAY));
    }

    @SuppressWarnings("unchecked")
    public static final Mail newMail(long combineId, long sendTime,
            byte[] content, int money, int yuanbao, int bindedYuanbao,
            Goods[] goodsArray){
        Pair<GoodsData, GoodsServerProto>[] newArray = EMPTY_ARRAY;
        if (goodsArray != null && goodsArray.length > 0){
            newArray = new Pair[goodsArray.length];

            for (int i = 0; i < goodsArray.length; i++){
                Goods g = goodsArray[i];
                newArray[i] = new Pair<GoodsData, GoodsServerProto>(
                        g.getData(), g.encode());
            }
        }

        return new Mail(0, combineId, sendTime, content, money, yuanbao,
                bindedYuanbao, newArray);
    }

    /**
     * 邮件ID
     */
    private int id;

    /**
     * 邮件所有人
     */
    private final long combineId;

    /**
     * 邮件发送时间
     */
    private final long sendTime;

    /**
     * 邮件正文
     */
    private final byte[] content;

    /**
     * 邮件附带银两
     */
    private final int money;

    /**
     * 邮件附带元宝
     */
    private final int yuanbao;

    /**
     * 绑定元宝
     */
    private final int bindedYuanbao;

    /**
     * 邮件附带物品
     */
//    private final Goods[] goodsArray;

    private final Pair<GoodsData, GoodsServerProto>[] goodsInfos;

    private Mail(int id, long combineId, long sendTime, byte[] content,
            int money, int yuanbao, int bindedYuanbao,
            Pair<GoodsData, GoodsServerProto>[] goodsInfos){
        this.id = id;
        this.combineId = combineId;
        this.sendTime = sendTime;
        this.content = content;
        this.money = money;
        this.yuanbao = yuanbao;
        this.bindedYuanbao = bindedYuanbao;
        this.goodsInfos = goodsInfos;
    }

    public int getId(){
        return id;
    }

    public void setId(int id){
        this.id = id;
    }

    public long getCombineId(){
        return combineId;
    }

    public long getSendTime(){
        return sendTime;
    }

    public byte[] getContent(){
        if (content == null){
            return Empty.BYTE_ARRAY;
        }

        return content;
    }

    public int getMoney(){
        return money;
    }

    public int getYuanbao(){
        return yuanbao;
    }

    public int getGoodsCount(){
        return goodsInfos.length;
    }

    public Goods[] getGoodsArray(){

        if (goodsInfos.length == 0){
            return Goods.EMPTY_GOODS_ARRAY;
        }

        Goods[] goodsArray = new Goods[goodsInfos.length];
        for (int i = 0; i < goodsInfos.length; i++){
            Pair<GoodsData, GoodsServerProto> pair = goodsInfos[i];
            goodsArray[i] = pair.left.decodeDontCheck(pair.right);
        }

        return goodsArray;
    }

    private byte[] protoBytes;

    public byte[] getProtoBytes(){
        if (protoBytes == null){
            protoBytes = encode4Client().toByteArray();
        }

        return protoBytes;
    }

    private MailProto encode4Client(){
        MailProto.Builder builder = MailProto.newBuilder();

        if (content.length > 0){
            builder.setContent(ByteString.copyFrom(content));
        }

        if (money > 0){
            builder.setMoney(money);
        }

        // TODO 绑定元宝
        if (yuanbao > 0){
            builder.setYuanbao(yuanbao);
        }

//        if (yuanbao > 0 || bindedYuanbao > 0){
//            builder.setYuanbao(yuanbao + bindedYuanbao);
//        }

        for (Pair<GoodsData, GoodsServerProto> pair : goodsInfos){
            builder.addGoodsStaticData(pair.left.getProtoByteString());
            builder.addGoodsDynamicData(pair.left.encodeGoodsProto(pair.right)
                    .toByteString());
        }

        return builder.build();
    }

    public MailServerProto encode(){
        MailServerProto.Builder builder = MailServerProto.newBuilder();

        if (money > 0){
            builder.setMoney(money);
        }

        if (yuanbao > 0){
            builder.setYuanbao(yuanbao);
        }

        if (bindedYuanbao > 0){
            builder.setBindedYuanbao(bindedYuanbao);
        }

        for (Pair<GoodsData, GoodsServerProto> pair : goodsInfos){
            builder.addGoods(pair.right);
        }

        return builder.build();
    }

    @SuppressWarnings("unchecked")
    public static Mail decode(int id, long combineId, long sendTime,
            byte[] content, MailServerProto proto, ConfigService configService){

        int money = proto.getMoney();
        int yuanbao = proto.getYuanbao();
        int bindedYuanbao = proto.getBindedYuanbao();

        Pair<GoodsData, GoodsServerProto>[] goodsArray = EMPTY_ARRAY;

        if (proto.getGoodsCount() > 0){
            goodsArray = new Pair[proto.getGoodsCount()];
            int notNullGoodsCount = 0;
            for (int i = 0; i < proto.getGoodsCount(); i++){

                GoodsServerProto goodsProto = proto.getGoods(i);
                if (goodsProto == null){
                    continue;
                }

                GoodsData data = configService.getGoods().get(
                        goodsProto.getId());
                if (data == null){
                    continue;
                }

                goodsArray[i] = new Pair<GoodsData, GoodsServerProto>(data,
                        goodsProto);
                notNullGoodsCount++;
            }

            if (notNullGoodsCount < goodsArray.length){
                Pair<GoodsData, GoodsServerProto>[] newArray = new Pair[notNullGoodsCount];

                int idx = 0;
                for (Pair<GoodsData, GoodsServerProto> g : goodsArray){
                    if (g == null)
                        continue;
                    newArray[idx++] = g;
                }

                goodsArray = newArray;
            }
        }

        return new Mail(id, combineId, sendTime, content, money, yuanbao,
                bindedYuanbao, goodsArray);
    }
}
