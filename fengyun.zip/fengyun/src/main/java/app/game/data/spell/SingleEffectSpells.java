package app.game.data.spell;

import static com.mokylin.sink.util.Preconditions.checkArgument;
import static com.mokylin.sink.util.Preconditions.checkNotNull;

import java.util.List;

import app.game.data.GameObjects;
import app.game.data.SpriteStats;
import app.game.data.goods.GoodsDatas;

import com.google.common.collect.Lists;
import com.google.inject.Inject;
import com.mokylin.collection.IntHashMap;
import com.mokylin.collection.IntHashMap.Entry;
import com.mokylin.sink.util.parse.ObjectParser;

public class SingleEffectSpells{

    public static final String LOCATION = GameObjects.SPELL_BASE_FOLDER
            + "single.txt";

    final IntHashMap<SingleEffectSpell> map;

    /**
     * 存所有技能第一级, key是spellType
     */
    final IntHashMap<SingleEffectSpell> firstLevels;

    @Inject
    SingleEffectSpells(GameObjects go, SpriteStats ss, FightStates fs,
            SpellAnimations animations, GoodsDatas goodsDatas){
        List<ObjectParser> data = go.loadFile(LOCATION);

        map = new IntHashMap<SingleEffectSpell>(data.size());
        firstLevels = new IntHashMap<SingleEffectSpell>();

        IntHashMap<IntHashMap<SingleEffectSpell>> spellTypeList = new IntHashMap<>();

        for (ObjectParser p : data){
            SingleEffectSpell s = new SingleEffectSpell(p, ss, fs, animations,
                    goodsDatas);
            checkArgument(map.put(s.id, s) == null, "Single技能id冲突: " + s);

            IntHashMap<SingleEffectSpell> levels = spellTypeList
                    .get(s.spellType);
            if (levels == null){
                levels = new IntHashMap<>();
                spellTypeList.put(s.spellType, levels);
            }
            boolean unique = levels.put(s.spellLevel, s) == null;

            checkArgument(unique, "spellType 为 %s 的技能有多个 %s 级的技能", s.spellType,
                    s.spellLevel);
        }

        // 给每一级设置下一级, 保存所有的第一级
        for (Entry<IntHashMap<SingleEffectSpell>> entry : spellTypeList
                .entrySet()){
            IntHashMap<SingleEffectSpell> eachSpellTypeMap = entry.getValue();
            final int spellType = entry.getKey();
            SingleEffectSpell previousLevel = eachSpellTypeMap.get(1);
            checkNotNull(previousLevel, "技能spellType %s 没有找到spellLevel为1的行",
                    spellType);
            firstLevels.put(previousLevel.spellType, previousLevel); // 把第一级放入map中
            final int levelCount = eachSpellTypeMap.size();
            for (int level = 2; level <= levelCount; level++){
                SingleEffectSpell sp = eachSpellTypeMap.get(level);
                checkNotNull(sp, "技能spellType %s 没有找到 spellLevel 为%s 的行",
                        spellType, level);
                previousLevel.setNextLevelAndTotalLevel(levelCount, sp);
                previousLevel = sp;
            }

            previousLevel.setNextLevelAndTotalLevel(levelCount, null); // 最后一级没有设过
        }

        for (SingleEffectSpell sp : map.values()){
            sp.init();
        }
    }

    public SingleEffectSpell get(int id){
        return map.get(id);
    }

    public List<SingleEffectSpell> getAutoLearnedSpellByRace(int raceID){
        List<SingleEffectSpell> result = Lists.newArrayList();
        for (SingleEffectSpell sp : firstLevels.values()){
            if (!sp.isAutoLearn){
                continue;
            }

            if (sp.race == 0 || sp.race == raceID){
                result.add(sp);
            }
        }
        return result;
    }

    public SingleEffectSpell getFirstLevelBySpellType(int spellType){
        return firstLevels.get(spellType);
    }

}
