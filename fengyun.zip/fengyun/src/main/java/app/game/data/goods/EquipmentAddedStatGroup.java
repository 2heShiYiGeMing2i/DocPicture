package app.game.data.goods;

import static com.mokylin.sink.util.Preconditions.*;

import java.util.EnumMap;
import java.util.List;

import app.game.data.QualityRelatedData;
import app.game.data.QualityRelatedDatas;
import app.game.data.SingleSpriteStat;
import app.game.data.SingleSpriteStats;
import app.game.module.scene.FightData;
import app.protobuf.GoodsServerContent.Quality;
import app.protobuf.SpriteStatContent.SingleStatProto;
import app.protobuf.SpriteStatContent.StatType;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.mokylin.collection.LeftIntPair;
import com.mokylin.sink.util.WeightedRandomer;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class EquipmentAddedStatGroup{

    final String name;

    final EnumMap<StatType, SingleAddedStatGroup> addedStatMap;

    final WeightedRandomer<StatType> statRandomer;

    final SingleAddedStatGroup defaultStatGroup;

    EquipmentAddedStatGroup(String name, List<ObjectParser> parserList,
            SingleSpriteStats stats, QualityRelatedDatas qualityDatas){

        this.name = name;
        addedStatMap = Maps.newEnumMap(StatType.class);

        List<LeftIntPair<StatType>> pairs = Lists
                .newArrayListWithCapacity(parserList.size());
        for (ObjectParser p : parserList){
            SingleAddedStatGroup data = new SingleAddedStatGroup(this, p,
                    stats, qualityDatas);
            checkArgument(addedStatMap.put(data.statType, data) == null,
                    "%s 附加属性中配置了重复类型的属性 -%s", this, data.statType);

            pairs.add(new LeftIntPair<StatType>(data.weight, data.statType));
        }
        defaultStatGroup = addedStatMap.get(pairs.get(0).right);

        statRandomer = new WeightedRandomer<>(pairs);
    }

    public SingleAddedStatGroup get(StatType type){
        return addedStatMap.get(type);
    }

    public static class SingleAddedStatGroup{

        final int weight;

        final StatType statType;

        private final SingleSpriteStat baseStat;

        private final SingleSpriteStat randomStat;

        transient final EnumMap<Quality, SingleAddedStat> statMap;

        private SingleAddedStatGroup(Object master, ObjectParser p,
                SingleSpriteStats stats, QualityRelatedDatas qualityDatas){

            weight = p.getIntKey("weight");
            checkArgument(weight > 0, "%s 附加属性中weight无效，weight必须大于0 -%s",
                    master, weight);

            int baseStatId = p.getIntKey("base_stat");
            baseStat = checkNotNull(stats.get(baseStatId),
                    "%s 附加属性中基础属性没找到 -%s", master, baseStatId);

            int randomStatId = p.getIntKey("random_stat");
            randomStat = checkNotNull(stats.get(randomStatId),
                    "%s 附加属性中随机属性没找到 -%s", master, randomStatId);

            checkArgument(baseStat.getStatType() == randomStat.getStatType(),
                    "%s 附加属性中基础属性和随机属性的类型不一致 base-%s random-%s", master,
                    baseStat.getStatType(), randomStat.getStatType());

            statType = baseStat.getStatType();

            statMap = Maps.newEnumMap(Quality.class);

            for (Quality quality : Quality.values()){
                QualityRelatedData relatedData = qualityDatas.get(quality);

                float coefficient = relatedData.addedStatCoefficient;
                SingleSpriteStat singleStat = baseStat.add(randomStat,
                        coefficient);

                statMap.put(quality, new SingleAddedStat(quality,
                        relatedData.addedStatCount, singleStat));
            }
        }

        public SingleAddedStat getAddedStat(Quality quality){
            return statMap.get(quality);
        }
    }

    public static class SingleAddedStat{

        final Quality quality;

        // 属性条数
        final int addedStatCount;

        // 单条属性
        private final SingleSpriteStat addedStat;

        final SingleStatProto addedStatProto;

        final int addedFightingAmount;

        // 总属性
        private final SingleSpriteStat totalStat;

        final int fightingAmount;

        private SingleAddedStat(Quality quality, int statCount,
                SingleSpriteStat singleStat){
            this.quality = quality;
            this.addedStatCount = statCount;
            this.addedStat = singleStat;
            addedStatProto = singleStat.encode();
            addedFightingAmount = FightData.calculateFightingAmount(singleStat);

            totalStat = singleStat.multiply(statCount);
            fightingAmount = FightData.calculateFightingAmount(totalStat);
        }

        public StatType getStatType(){
            return addedStat.getStatType();
        }

        public SingleSpriteStat getSingleStat(){
            return addedStat;
        }

        public SingleStatProto getSingleStatProto(){
            return addedStatProto;
        }

        public SingleSpriteStat getTotalStat(){
            return totalStat;
        }
    }

    @Override
    public String toString(){
        return "附加属性-" + name;
    }
}
