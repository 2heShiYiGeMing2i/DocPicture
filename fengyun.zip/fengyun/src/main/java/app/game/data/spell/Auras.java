package app.game.data.spell;

import static com.mokylin.sink.util.Preconditions.checkArgument;

import java.util.List;

import app.game.data.GameObjects;

import com.google.inject.Inject;
import com.mokylin.collection.IntHashMap;
import com.mokylin.sink.util.parse.ObjectParser;

public class Auras{

    public static final String LOCATION = GameObjects.SPELL_BASE_FOLDER
            + "aura.txt";

    private final IntHashMap<Aura> map;

    @Inject
    Auras(GameObjects go, FightStates states){
        List<ObjectParser> data = go.loadFile(LOCATION);
        map = new IntHashMap<Aura>(data.size());

        for (ObjectParser p : data){
            Aura a = new Aura(p, states);
            checkArgument(map.putIfAbsent(a.id, a) == null, "光环的id冲突: %s", a);
        }
    }

    public Aura get(int id){
        return map.get(id);
    }
}
