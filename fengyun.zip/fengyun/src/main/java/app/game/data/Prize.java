package app.game.data;

import static com.mokylin.sink.util.Preconditions.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import app.game.data.goods.GoodsAddHelper;
import app.game.data.goods.GoodsTryAddResult;
import app.game.data.goods.GoodsWrapper;
import app.game.entity.Hero;
import app.game.module.HeroMiscModule;
import app.game.module.scene.HeroFightModule;
import app.protobuf.HeroServerContent.PrizeServerProto;
import app.protobuf.LogContent.LogEnum.OperateType;
import app.protobuf.PrizeContent.PrizeProto;
import app.utils.VariableConfig;

import com.google.common.collect.HashMultiset;
import com.google.common.collect.Lists;
import com.google.common.collect.Multiset;
import com.google.common.collect.Multiset.Entry;

/**
 * @author Liwei
 *
 */
public class Prize{
//    private static final Logger logger = LoggerFactory.getLogger(Prize.class);

    public static final Prize EMPTY_PRIZE = new Prize(0, 0, 0, 0, 0,
            GoodsWrapper.EMPTY_ARRAY);

    final int exp;

    final int money;

    final int realAir;

    final int guildLilian;

    final int honor;

    final GoodsWrapper[] wrappers;

    private transient final int wrapperCount;

    public Prize(int exp, int money, int realAir, int guildLilian, int honor,
            GoodsWrapper[] wrappers){
        checkArgument(exp >= 0);
        checkArgument(money >= 0 && money <= VariableConfig.MONEY_MAX_AMOUNT);
        checkArgument(realAir >= 0
                && realAir <= VariableConfig.REAL_AIR_MAX_AMOUNT);
        checkArgument(guildLilian >= 0
                && guildLilian <= VariableConfig.GUILD_LILIAN_UPPER_LIMIT);
        checkArgument(honor >= 0
                && honor <= VariableConfig.HONOR_POINT_MAX_AMOUNT);
        checkNotNull(wrappers);

        this.exp = exp;
        this.money = money;
        this.realAir = realAir;
        this.guildLilian = guildLilian;
        this.honor = honor;
        this.wrappers = wrappers;
        wrapperCount = wrappers.length;
    }

    private boolean isEmpty(){
        return exp == 0 && money == 0 && realAir == 0 && guildLilian == 0
                && wrappers.length == 0;
    }

    public boolean hasGoods(){
        return wrapperCount > 0;
    }

    /**
     * 应该在初始化时才调用, 消耗较大, 且有可能抛错
     * @param toAdd
     * @return
     */
    public Prize add(Prize toAdd){
        if (toAdd.isEmpty()){
            return this;
        }

        if (isEmpty()){
            return toAdd;
        }

        // 判断每个物品
        GoodsWrapper[] array = GoodsWrapper.EMPTY_ARRAY;
        if (wrappers.length + toAdd.wrappers.length > 0){
            List<GoodsWrapper> goodsList = new ArrayList<>(wrappers.length
                    + toAdd.wrappers.length);

            for (GoodsWrapper w : wrappers){
                add(goodsList, w);
            }

            for (GoodsWrapper w : toAdd.wrappers){
                add(goodsList, w);
            }

            array = goodsList.toArray(GoodsWrapper.EMPTY_ARRAY);
        }

        return new Prize(exp + toAdd.exp, money + toAdd.money, realAir
                + toAdd.realAir, guildLilian + toAdd.guildLilian, honor
                + toAdd.honor, array);
    }

    /**
     * 应该在初始化时才调用, 消耗较大, 且有可能抛错
     * @param toRemove
     * @return
     */
    public Prize remove(Prize toRemove){
        if (toRemove.isEmpty()){
            return this;
        }

        checkArgument(exp >= toRemove.exp);
        checkArgument(money >= toRemove.money);
        checkArgument(realAir >= toRemove.realAir);
        checkArgument(guildLilian >= toRemove.guildLilian);
        checkArgument(honor >= toRemove.honor);

        Multiset<GoodsWrapper> set = HashMultiset.create();
        for (GoodsWrapper w : wrappers){
            set.add(w, w.getCount());
        }

        for (GoodsWrapper w : toRemove.wrappers){
            int oldCount = set.remove(w, w.getCount());
            checkArgument(
                    oldCount >= w.getCount(),
                    "Prize.remove时, 要remove的count 超过了原来持有的: 要删除 %s 个%s, 但原本只有 %s 个",
                    w.getCount(), w.getData(), oldCount);
        }

        final GoodsWrapper[] array;
        Set<Entry<GoodsWrapper>> entries = set.entrySet();
        if (entries.size() == 0){
            array = GoodsWrapper.EMPTY_ARRAY;
        } else{
            array = new GoodsWrapper[entries.size()];
            int i = 0;
            for (Entry<GoodsWrapper> entry : entries){
                array[i++] = entry.getElement().setCount(entry.getCount());
            }
            assert i == array.length;
        }

        return new Prize(exp - toRemove.exp, money - toRemove.money, realAir
                - toRemove.realAir, guildLilian - toRemove.guildLilian, honor
                - toRemove.honor, array);
    }

    private static void add(List<GoodsWrapper> list, GoodsWrapper toAdd){
        GoodsWrapper current;
        for (int i = list.size(); --i >= 0;){
            current = list.get(i);
            if (current.canStack(toAdd)){
                list.set(i,
                        current.setCount(current.getCount() + toAdd.getCount()));
                return;
            }
        }
        list.add(toAdd);
    }

    /**
     * 给奖励，成功返回true，失败返回false
     * @return
     */
    public boolean give(HeroFightModule hfm, long ctime, OperateType type,
            String iEventId){

        Hero hero = hfm.getHero();

        GoodsAddHelper[] goodsArray = newGoodsAddHelpers(ctime);
        if (goodsArray.length > 0){
            GoodsTryAddResult result = hero.getDepot().canAddGoods(goodsArray);

            if (!result.isSuccess()){
                return false;
            }

            // 给物品
            hfm.getServices()
                    .getModules()
                    .getGoodsModule()
                    .addBatchGoodsArray(goodsArray, result, hero,
                            hfm.getSender(), hfm.getHeroMiscModule(), type, 0,
                            ctime);
        }

        // 给数值
        giveIgnoreGoods(hfm.getHeroMiscModule(), hfm.getHero(), false, type,
                iEventId);

        return true;
    }

    public void giveOrSendMail(HeroFightModule hfm, long ctime,
            OperateType type, String iEventId){
        Hero hero = hfm.getHero();

        GoodsAddHelper[] goodsArray = newGoodsAddHelpers(ctime);

        if (goodsArray.length > 0){
            GoodsTryAddResult result = hero.getDepot().canAddGoods(goodsArray);

            if (result.isSuccess()){
                // 给物品
                hfm.getServices()
                        .getModules()
                        .getGoodsModule()
                        .addBatchGoodsArray(goodsArray, result, hero,
                                hfm.getSender(), hfm.getHeroMiscModule(), type,
                                0, ctime);
            } else{
                // 发邮件
                hfm.getServices().getModules().getMailModule()
                        .newMailOnDepotEmptyPosNotEnough(hero, goodsArray);
            }
        }

        // 给数值
        giveIgnoreGoods(hfm.getHeroMiscModule(), hfm.getHero(), false, type,
                iEventId);
    }

    /**
     * 添加奖励中的数值奖励
     * @param miscModule
     * @param hero
     * @param isAffectedByFangChenMi 这次给的东西会不会受到防沉迷的影响
     */
    public void giveIgnoreGoods(HeroMiscModule miscModule, Hero hero,
            boolean isAffectedByFangChenMi, OperateType type, String iEventId){
        if (isAffectedByFangChenMi){
            float multiple = hero.getFangChenMiMultiple();
            miscModule.addMoneyAnyway((int) (money * multiple), type, iEventId);
            miscModule.addRealAirAnyway((int) (realAir * multiple), type,
                    iEventId);
            miscModule.addHonorPoint((int) (honor * multiple), type, iEventId);
            miscModule.addGuildLilian((int) (guildLilian * multiple), type,
                    iEventId);
            miscModule.addExperience((int) (exp * multiple), type, iEventId);
        } else{
            miscModule.addMoneyAnyway(money, type, iEventId);
            miscModule.addRealAirAnyway(realAir, type, iEventId);
            miscModule.addHonorPoint(honor, type, iEventId);
            miscModule.addGuildLilian(guildLilian, type, iEventId);
            miscModule.addExperience(exp, type, iEventId);
        }
    }

    public int getExp(){
        return exp;
    }

    public int getMoney(){
        return money;
    }

    public int getRealAir(){
        return realAir;
    }

    public int getGuildLilian(){
        return guildLilian;
    }

    public int getHonor(){
        return honor;
    }

    public GoodsWrapper[] getGoodsWrappers(){
        return wrappers;
    }

//    public Goods[] newGoodsArray(long ctime){
//        if (wrapperCount == 0){
//            return Goods.EMPTY_GOODS_ARRAY;
//        }
//
//        Goods[] result = new Goods[wrapperCount];
//        for (int i = 0; i < wrapperCount; i++){
//            result[i] = wrappers[i].create(ctime);
//        }
//        return result;
//    }

    public int getWrapperCount(){
        return wrapperCount;
    }

    public GoodsAddHelper[] newGoodsAddHelpers(long ctime){
        if (wrapperCount == 0){
            return GoodsAddHelper.EMPTY_ARRAY;
        }

        GoodsAddHelper[] array = new GoodsAddHelper[wrapperCount];
        for (int i = 0; i < wrapperCount; i++){
            array[i] = wrappers[i].newHelper(ctime);
        }

        return array;
    }

    public PrizeProto encode4Client(){
        PrizeProto.Builder builder = PrizeProto.newBuilder();

        if (exp != 0){
            builder.setExp(exp);
        }
        if (money != 0){
            builder.setMoney(money);
        }
        if (realAir != 0){
            builder.setRealAir(realAir);
        }
        if (guildLilian != 0){
            builder.setGuildLilian(guildLilian);
        }

        if (honor != 0){
            builder.setHonor(honor);
        }

        // 物品
        for (GoodsWrapper wrapper : wrappers){
            builder.addGoodsWrapper(wrapper.encode4Client());
        }

        return builder.build();
    }

    public PrizeServerProto encode(){
        PrizeServerProto.Builder builder = PrizeServerProto.newBuilder()
                .setExp(exp).setMoney(money).setRealAir(realAir)
                .setGuildLilian(guildLilian).setHonor(honor);

        // 物品
        for (GoodsWrapper wrapper : wrappers){
            builder.addGoods(wrapper.encode());
        }

        return builder.build();
    }

    public static Prize decode(PrizeServerProto proto, ConfigService cs){
        int exp = proto.getExp();
        int money = proto.getMoney();
        int realAir = proto.getRealAir();
        int jianghuExp = proto.getGuildLilian();
        int honor = proto.getHonor();

        // 物品
        GoodsWrapper[] wrappers = GoodsWrapper.EMPTY_ARRAY;

        if (proto.getGoodsCount() > 0){
            wrappers = new GoodsWrapper[proto.getGoodsCount()];

            int notNullGoodsCount = 0;
            for (int i = 0; i < proto.getGoodsCount(); i++){

                GoodsWrapper wrapper = GoodsWrapper.decode(proto.getGoods(i),
                        cs);

                if (wrapper == null){
                    continue;
                }

                wrappers[i] = wrapper;
                notNullGoodsCount++;
            }

            if (notNullGoodsCount < wrappers.length){
                if (notNullGoodsCount == 0){
                    wrappers = GoodsWrapper.EMPTY_ARRAY;
                } else{
                    // 异常情况，decode出来null值
                    GoodsWrapper[] newArray = new GoodsWrapper[notNullGoodsCount];

                    int idx = 0;
                    for (GoodsWrapper wrapper : wrappers){
                        if (wrapper == null){
                            continue;
                        }
                        newArray[idx++] = wrapper;
                    }

                    wrappers = newArray;
                }
            }
        }

        return new Prize(exp, money, realAir, jianghuExp, honor, wrappers);
    }

    public static Builder newBuilder(){
        return new Builder();
    }

    public static class Builder{

        private int exp;

        private int money;

        private int realAir;

        private int guildLilian;

        private int honor;

        private List<GoodsWrapper> goodsList;

        private Builder(){
        }

        public Builder add(Prize prize){
            exp += prize.exp;
            money += prize.money;
            realAir += prize.realAir;
            guildLilian += prize.guildLilian;
            honor += prize.honor;

            if (prize.wrappers.length > 0){
                if (goodsList == null){
                    goodsList = Lists.newLinkedList();
                }

                for (GoodsWrapper g : prize.wrappers){
                    goodsList.add(g);
                }
            }

            return this;
        }

        public void addGoodsWrapper(GoodsWrapper goodsWrapper){
            if (goodsList == null){
                goodsList = Lists.newLinkedList();
            }

            goodsList.add(goodsWrapper);
        }

        public int getGoodsCount(){
            return goodsList.size();
        }

        public void addExp(int amount){
            exp += amount;
        }

        public void addMoney(int amount){
            money += amount;
        }

        public void addRealAir(int amount){
            realAir += amount;
        }

        public void addGuildLilian(int amount){
            guildLilian += amount;
        }

        public void addHonor(int amount){
            honor += amount;
        }

        public Prize build(){
            GoodsWrapper[] goodsArray = GoodsWrapper.EMPTY_ARRAY;
            if (goodsList != null){
                goodsArray = goodsList.toArray(GoodsWrapper.EMPTY_ARRAY);
            }

            return new Prize(exp, money, realAir, guildLilian, honor,
                    goodsArray);
        }
    }
}
