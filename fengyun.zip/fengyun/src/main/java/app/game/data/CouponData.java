package app.game.data;

import static com.google.common.base.Preconditions.checkArgument;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.data.goods.GoodsDatas;
import app.game.data.goods.GoodsWrapper;
import app.game.module.WelfareMessages;

import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class CouponData{

    public final int id;

    public final GoodsWrapper wrapper;

    public final ChannelBuffer exchangeCouponMsg;

    CouponData(ObjectParser p, GoodsDatas goodsDatas){

        id = p.getIntKey("id");

        String goodsItem = p.getKey("goods_item");
        wrapper = GoodsWrapper.parse(this, goodsDatas, goodsItem);

        checkArgument(wrapper.isBinded(), "激活码兑换的物品一定要是绑定的");

        exchangeCouponMsg = WelfareMessages
                .exchangeCouponMsg(wrapper.getData().icon);
    }

    @Override
    public String toString(){
        return "激活码礼包-" + id;
    }
}
