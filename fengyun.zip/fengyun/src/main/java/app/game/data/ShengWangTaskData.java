package app.game.data;

import static com.mokylin.sink.util.Preconditions.*;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.module.HeroMiscMessages;
import app.protobuf.ConfigContent.ShengWangType;

import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class ShengWangTaskData{

    final ShengWangType type;

    // 完成一次给多少声望
    public final int amount;

    // 最多可以完成多少次
    public final int maxTimes;

    private final ChannelBuffer[] updateTaskMsg;

    ShengWangTaskData(ObjectParser p){
        int intType = p.getIntKey("type");
        type = checkNotNull(ShengWangType.valueOf(intType), "无效的声望类型, %s",
                intType);

        checkArgument(type.getNumber() < 255, "声望类型必须小于 255");

        amount = p.getIntKey("amount");
        checkArgument(amount > 0, "声望%s 完成一次的声望奖励必须大于0", type);

        maxTimes = p.getIntKey("max_times");
        checkArgument(maxTimes > 0, "声望%s 的最大完成次数必须大于0", type);

        updateTaskMsg = new ChannelBuffer[maxTimes];
        for (int i = 0; i < maxTimes; i++){
            updateTaskMsg[i] = HeroMiscMessages.updateShengWangTaskMsg(intType,
                    i + 1);
        }
    }

    public ChannelBuffer getUpdateTaskMsg(int times){
        return Utils.getValidObject(updateTaskMsg, times - 1);
    }
}
