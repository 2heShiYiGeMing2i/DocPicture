package app.game.data.goods;

import static com.mokylin.sink.util.Preconditions.*;
import app.game.data.GameObjects;
import app.game.data.QualityRelatedDatas;
import app.game.data.SingleSpriteStat;
import app.game.data.SingleSpriteStats;
import app.game.data.goods.EquipmentAddedStatGroup.SingleAddedStat;
import app.game.data.goods.EquipmentAddedStatGroup.SingleAddedStatGroup;
import app.game.module.scene.FightData;
import app.protobuf.GoodsContent.MountEquipmentDataProto;
import app.protobuf.GoodsContent.MountEquipmentProto;
import app.protobuf.GoodsServerContent.GoodsServerProto;
import app.protobuf.GoodsServerContent.GoodsType;
import app.protobuf.GoodsServerContent.MountEquipmentServerProto;
import app.protobuf.GoodsServerContent.Quality;
import app.protobuf.SpriteStatContent.SingleStatProto;
import app.protobuf.SpriteStatContent.StatType;

import com.google.protobuf.ByteString;
import com.mokylin.sink.util.Empty;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.WeightedRandomer;
import com.mokylin.sink.util.parse.ObjectParser;

public class MountEquipmentData extends GoodsData{
//    private static final Logger logger = LoggerFactory
//            .getLogger(MountEquipmentData.class);

    public static final String LOCATION = GameObjects.GOODS_BASE_LOCATION
            + "mount_equipment.txt";

    public static final int DEFAULT_REFINED_MAX_TIMES = 10;

    public static final int DEFAULT_ADDED_STAT_COUNT = 6;

    // 坐骑装备

    /**
     * 鞍具
     */
    public static final int EQUIPMENT_TYPE_SADDLE = 20;

    /**
     * 缰绳
     */
    public static final int EQUIPMENT_TYPE_REIN = 21;

    /**
     * 蹬具
     */
    public static final int EQUIPMENT_TYPE_STIRRUP = 22;

    /**
     * 蹄铁
     */
    public static final int EQUIPMENT_TYPE_HORSESHOE = 23;

    /**
     * 坐骑部件装备个数
     */
    public static final int MOUNT_EQUIPED_MAX_COUNT = 4;

    /**
     * 坐骑装备部件，20-鞍具 21-缰绳 22-蹬具 23-蹄铁
     */
    private final int equipType;

    /**
     * 坐骑装备位置，0-鞍具 1-缰绳 2-蹬具 3-蹄铁
     */
    private final int equipPos;

    /**
     * 基础属性
     */
    private final SingleSpriteStat[] baseStats;
    private final SingleStatProto[] baseStatProtos;

    /**
     * 强化属性
     */
    private final RefinedData[] refinedDatas;

    transient final RefinedData nonRefinedData;

    transient final RefinedData maxRefinedData;

    private final int refinedMaxTimes;

    private final int addedStatMaxCount;

    /**
     * 附加属性
     */
    final EquipmentAddedStatGroup addedStatGroup;

    final int requireMountLevel;

    // proto
    private final MountEquipmentDataProto proto;

    private final byte[] protoBytes;

    private final ByteString protoByteString;

    private final QualityRelatedDatas qualityDatas;

    MountEquipmentData(ObjectParser p, SingleSpriteStats spriteStats,
            EquipmentAddedStatGroups addedStatGroups,
            QualityRelatedDatas qualityDatas){
        super(p, GoodsType.MOUNT_EQUIPMENT);
        this.qualityDatas = qualityDatas;

        checkArgument(maxCount == 1, "物品%s-%s 是装备，但是居然可以堆叠，maxCount: %s", id,
                name, maxCount);

        equipType = p.getIntKey("equip_type");
        equipPos = equipType - 20;
        checkArgument(equipPos >= 0 && equipPos <= MOUNT_EQUIPED_MAX_COUNT,
                "%s 配置的EquipType无效, 20-鞍具 21-缰绳 22-蹬具 23-蹄铁", this);

        String baseStatIds = p.getKey("base_stat");

        String[] baseStatIdArray = baseStatIds.split(";");
        checkArgument(baseStatIdArray.length > 0
                && baseStatIdArray.length <= Quality.values().length,
                "%s 配置的基础属性个数，必须大于0且小于等于品质总个数，count: %s", this,
                baseStatIdArray.length);

        baseStats = new SingleSpriteStat[baseStatIdArray.length];
        baseStatProtos = new SingleStatProto[baseStatIdArray.length];

        StatType baseStatType = null;
        for (int i = 0; i < baseStatIdArray.length; i++){
            int baseStatId = Integer.parseInt(baseStatIdArray[i]);

            SingleSpriteStat baseStat = checkNotNull(
                    spriteStats.get(baseStatId),
                    "物品%s-%s 配置的基础属性不存在，base_stat: %s", id, name, baseStatId);

            checkArgument(baseStat.isBuffStat(),
                    "物品%s-%s 配置的基础属性，不是增益属性，base_stat: %s", id, name,
                    baseStatId);

            if (i == 0){
                baseStatType = baseStat.getStatType();
            } else{
                checkArgument(baseStatType == baseStat.getStatType(),
                        "装备%s 配置的基础属性类型必须全部一样(加攻击必须全部都是加攻击的)", this);
            }

            baseStats[i] = baseStat;
            baseStatProtos[i] = baseStat.encode();
        }

        // 强化等级
        refinedMaxTimes = p.getIntKey("refined_max_times",
                DEFAULT_REFINED_MAX_TIMES);

        addedStatMaxCount = DEFAULT_ADDED_STAT_COUNT;

        // 强化属性
        String refinedStatStr = p.getKey("refined_stats");
        String[] refinedStatPercents = Empty.STRING_ARRAY;
        if (!refinedStatStr.isEmpty()){
            refinedStatPercents = refinedStatStr.split(";");
        }

        int c = refinedStatPercents.length;
        checkArgument(c == refinedMaxTimes,
                "物品%s-%s 配置的强化属性个数错误，最大强化属性个数: %s，refined_stats: %s", id, name,
                refinedMaxTimes, refinedStatStr);

        SingleSpriteStat[] emptyRefinedStat = new SingleSpriteStat[baseStats.length];
        SingleSpriteStat s = SingleSpriteStat.getEmptyStat(baseStatType);
        for (int i = 0; i < emptyRefinedStat.length; i++){
            emptyRefinedStat[i] = s;
        }

        refinedDatas = new RefinedData[c + 1];

        RefinedData nextLevel = null;
        int nextPercent = Integer.MAX_VALUE;
        for (int refinedTimes = c; refinedTimes >= 0; refinedTimes--){
            SingleSpriteStat[] refinedStat = emptyRefinedStat;
            if (refinedTimes > 0){
//                int refinedStatId = Integer
//                        .parseInt(refinedStatPercents[refinedTimes - 1]);
//                refinedStat = checkNotNull(spriteStats.get(refinedStatId),
//                        "物品%s-%s 配置的强化属性不存在，refined_stats: %s", id, name,
//                        refinedStatId);
//
//                checkArgument(refinedStat.isBuffStat(),
//                        "物品%s-%s 配置的强化属性，不是增益属性，refined_stats: %s", id, name,
//                        refinedStatId);
//
//                checkArgument(
//                        baseStat.getStatType() == refinedStat.getStatType(),
//                        "物品%s-%s 的基础属性与 %s级的强化属性中的属性类型不一致，base:%s refined:%s",
//                        id, name, refinedTimes + 1, baseStat.getStatType(),
//                        refinedStat.getStatType());

                int percent = Integer
                        .parseInt(refinedStatPercents[refinedTimes - 1]);
                checkArgument(percent > 0, "坐骑装备%s 配置的强化属性百分百比必须大于0", this);
                checkArgument(percent < nextPercent, "坐骑装备%s 配置的强化属性百分比必须从小到大",
                        this);
                nextPercent = percent;

                refinedStat = new SingleSpriteStat[baseStats.length];
                for (int i = 0; i < emptyRefinedStat.length; i++){
                    refinedStat[i] = baseStats[i].multiply(percent / 100f);
                }
            }

            nextLevel = refinedDatas[refinedTimes] = new RefinedData(id, name,
                    refinedTimes, refinedStat, nextLevel);
        }

        nonRefinedData = refinedDatas[0];
        maxRefinedData = refinedDatas[c];

        // 附加属性
        String addedGroupName = p.getKey("added_group");
        addedStatGroup = checkNotNull(addedStatGroups.get(addedGroupName),
                "物品%s-%s 配置附加属性Group数据没找到: %s", id, name, addedGroupName);

        requireMountLevel = Math.max(1, p.getIntKey("require_mount_level"));

        proto = build();

        protoBytes = processProtoBytes(proto.toByteArray());
        protoByteString = ByteString.copyFrom(protoBytes);
    }

    boolean isValidEquipPos(int equipPos){
        return this.equipPos == equipPos;
    }

    public SingleSpriteStat getBaseStat(int intQuality){
        return Utils.getValidObject(baseStats, intQuality);
    }

    public SingleAddedStat getAddedStat(StatType statType, Quality quality){
        SingleAddedStatGroup group = getAddedStatGroup(statType);
        if (group != null){
            return group.getAddedStat(quality);
        }

        return getDefaultAddedStat(quality);
    }

    SingleAddedStatGroup getAddedStatGroup(StatType statType){
        return addedStatGroup.get(statType);
    }

    public SingleAddedStat getDefaultAddedStat(Quality quality){
        return addedStatGroup.defaultStatGroup.getAddedStat(quality);
    }

    public RefinedData getRefinedData(int refinedTimes){

        if (refinedTimes >= 0 && refinedTimes <= refinedMaxTimes){
            return refinedDatas[refinedTimes];
        }

        if (refinedTimes < 0){
            return nonRefinedData;
        }

        return maxRefinedData;
    }

    public boolean isValidRefinedTimes(int refinedTimes){
        return refinedTimes >= 0 && refinedTimes <= refinedMaxTimes;
    }

    int getValidAddedCount(int addedCount){
        if (addedCount >= 0 && addedCount <= addedStatMaxCount){
            return addedCount;
        }

        if (addedCount < 0){
            return 0;
        }

        return addedStatMaxCount;
    }

    public WeightedRandomer<StatType> getDefaultAddedStatTypeRandomer(){
        return addedStatGroup.statRandomer;
    }

    @Override
    Goods newGoods(long expireTime){
        return newEquipment(expireTime, 0, 0, 0);
    }

    @Override
    Goods newGoods(int realCount, GoodsServerProto proto){

        MountEquipmentServerProto equipmentProto = proto
                .getExtension(MountEquipmentServerProto.goodsProto);

        int refinedTimes = 0;
        int intQuality = 0;
        int intStatType = 0;
        if (equipmentProto != null){
            refinedTimes = equipmentProto.getRefinedTimes();
            intQuality = equipmentProto.getQuality();
            intStatType = equipmentProto.getAddedStatType();
        }

        MountEquipment e = newEquipment(proto.getExpireTime(), refinedTimes,
                intStatType, intQuality);

        if (proto.getBinded())
            e.bind();

        return e;
    }

    MountEquipment newEquipment(long expireTime, int refinedTimes,
            int intStatType, int intQuality){
        return new MountEquipment(this, expireTime, refinedTimes, intStatType,
                intQuality);
    }

    // EquipmentProto
    @Override
    public MountEquipmentProto encodeGoodsProto(Goods g){
        assert g instanceof MountEquipment: "MountEquipment.encodeGoodsProto中的参数居然不是坐骑装备";

        MountEquipment e = (MountEquipment) g;

        return encodeGoodsProto(e.binded, e.expireTime, e.refinedTimes,
                e.intQuality, e.intStatType);
    }

    @Override
    public MountEquipmentProto encodeGoodsProto(GoodsServerProto serverProto){
        MountEquipmentServerProto equipmentProto = serverProto
                .getExtension(MountEquipmentServerProto.goodsProto);

        int refinedTimes = 0;
        int intQuality = 0;
        int intStatType = 0;
        if (equipmentProto != null){
            refinedTimes = equipmentProto.getRefinedTimes();
            intQuality = equipmentProto.getQuality();
            intStatType = equipmentProto.getAddedStatType();
        }

        return encodeGoodsProto(serverProto.getBinded(),
                serverProto.getExpireTime(), refinedTimes, intQuality,
                intStatType);
    }

    MountEquipmentProto encodeGoodsProto(boolean binded, long expireTime,
            int refinedTimes, int intQuality, int intStatType){

        RefinedData refinedData = getRefinedData(refinedTimes);

        StatType statType = StatType.valueOf(intStatType);
        Quality quality = Quality.valueOf(intQuality);

        if (quality == null)
            quality = Quality.WHITE;

        SingleAddedStat addedStat;
        if (statType != null){
            addedStat = getAddedStat(statType, quality);
        } else{
            addedStat = getDefaultAddedStat(quality);
        }
        return encodeEquipmentProto(binded, expireTime, refinedData, addedStat);
    }

    private MountEquipmentProto encodeEquipmentProto(boolean binded,
            long expireTime, RefinedData refinedData, SingleAddedStat addedStat){
        MountEquipmentProto.Builder builder = MountEquipmentProto.newBuilder();

        if (binded){
            builder.setBinded(binded);
        }

        if (expireTime > 0){
            builder.setExpireTime(expireTime);
        }

        int intQuality = addedStat.quality.getNumber();
        builder.setQuality(intQuality);

        if (refinedData.refinedTimes > 0){
            builder.setRefinedTimes(refinedData.refinedTimes);
            builder.setRefinedStat(refinedData.getRefinedStatProto(intQuality));
            builder.setRefinedFightingAmount(refinedData
                    .getRefinedFightingAmount(intQuality));
        }

        if (addedStat.addedStatCount > 0){
            builder.setAddedStatCount(addedStat.addedStatCount);
            builder.setAddedStat(addedStat.getSingleStatProto());
            builder.setAddedFightingAmount(addedStat.addedFightingAmount);
        }
        builder.setAddedStatType(addedStat.getStatType().getNumber());

        SingleSpriteStat baseStat = Utils.getValidObject(baseStats, intQuality);
        int baseFightingAmount = FightData.calculateFightingAmount(baseStat);
        SingleStatProto baseStatProto = Utils.getValidObject(baseStatProtos,
                intQuality);

        builder.setBaseStat(baseStatProto);
        builder.setBaseFightingAmount(baseFightingAmount);

        builder.setBestRefinedFightingAmount(maxRefinedData
                .getRefinedFightingAmount(intQuality));

        return builder.build();
    }

    private MountEquipmentDataProto build(){
        MountEquipmentDataProto.Builder builder = MountEquipmentDataProto
                .newBuilder();
        builder.setBaseData(encode())
                .setBaseStat(baseStats[0].encode())
                .setPos(equipPos)
                .setBaseFightingAmount(
                        FightData.calculateFightingAmount(baseStats[0]))
                .setRefinedMaxTimes(refinedMaxTimes)
                .setAddedStatMaxCount(addedStatMaxCount)
                .setBestRefinedFightingAmount(
                        maxRefinedData.getRefinedFightingAmount(0))
                .setRequireMountLevel(requireMountLevel);

        return builder.build();
    }

    public MountEquipmentDataProto getProto(){
        return proto;
    }

    @Override
    public ByteString getProtoByteString(){
        return protoByteString;
    }

    @Override
    public byte[] getProtoBytes(){
        return protoBytes;
    }

    @Override
    public int getAuctionType(){
        switch (equipType){
            case EQUIPMENT_TYPE_SADDLE:{
                return 80;
            }
            case EQUIPMENT_TYPE_REIN:{
                return 81;
            }
            case EQUIPMENT_TYPE_STIRRUP:{
                return 82;
            }
            case EQUIPMENT_TYPE_HORSESHOE:{
                return 83;
            }
            default:{
                return 8;
            }
        }
    }

    @Override
    public long getGoodsIdentifier(GoodsServerProto proto){
        MountEquipmentServerProto equipmentProto = proto
                .getExtension(MountEquipmentServerProto.goodsProto);

        int refinedTimes = 0;
        int intQuality = 0;
        int intStatType = 0;
        if (equipmentProto != null){
            refinedTimes = equipmentProto.getRefinedTimes();
            intQuality = equipmentProto.getQuality();
            intStatType = equipmentProto.getAddedStatType();
        }

        return getGoodsIdentifier(proto.getBinded(), intStatType, intQuality,
                refinedTimes);
    }

    @Override
    public long getGoodsIdentifier(boolean binded, int intExpireTime){
        return getGoodsIdentifierSharedBits(binded);
    }

    public long getGoodsIdentifier(boolean binded, int intStatType,
            int intQuality, int refinedTimes){
        return (getEquipmentGoodsIdentifier(intStatType, intQuality,
                refinedTimes) << 28) | getGoodsIdentifierSharedBits(binded);
    }

    private long getEquipmentGoodsIdentifier(int intStatType, int intQuality,
            int refinedTimes){
        // 5个bit给addedData.statType, 4个bit给addedData.quality. 4个bit给refinedTimes
        return intStatType | (intQuality << 5) | (refinedTimes << 9);
    }

    public QualityRelatedDatas getQualityDatas(){
        return qualityDatas;
    }
}
