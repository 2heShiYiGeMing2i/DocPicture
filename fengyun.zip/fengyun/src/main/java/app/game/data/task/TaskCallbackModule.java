package app.game.data.task;

import static app.game.module.TaskMessages.REMOVE_GUILD_TASK_BUFFER;
import static app.protobuf.LogContent.LogEnum.OperateType.TASK_DONE;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.data.Prize;
import app.game.data.gem.GemData;
import app.game.data.goods.Goods;
import app.game.data.goods.GoodsAddHelper;
import app.game.data.goods.GoodsData;
import app.game.data.goods.GoodsTryAddResult;
import app.game.data.scene.MonsterData;
import app.game.data.scene.SceneData;
import app.game.data.task.TaskTarget.TaskTargetProgress;
import app.game.entity.Hero;
import app.game.module.GoodsContainerModule;
import app.game.module.HeroMiscModule;
import app.game.module.PetModule;
import app.game.module.TaskMessages;
import app.game.module.combat.OneOnOneModule;
import app.game.service.TimeService;
import app.game.service.log.LogService;
import app.message.ISender;
import app.protobuf.ConfigContent.ShengWangType;
import app.protobuf.GoodsServerContent.Quality;
import app.protobuf.LogContent.LogEnum.OperateType;
import app.utils.VariableConfig;

import com.google.inject.Inject;
import com.mokylin.collection.ReusableIterator;

/**
 * @author Liwei
 *
 */
public class TaskCallbackModule{

    private static final Logger logger = LoggerFactory
            .getLogger(TaskCallbackModule.class);

    private final TaskDatas taskDatas;

    private final TimeService timeService;

    private final GoodsContainerModule goodsContainerModule;

    private final GemData gemData;

    private final LogService logService;

    private final PetModule petModule;

    private final OneOnOneModule oneOnOneModule;

    @Inject
    TaskCallbackModule(TaskDatas taskDatas, TimeService timeService,
            GoodsContainerModule goodsContainerModule, GemData gemData,
            LogService logService, PetModule petModule,
            OneOnOneModule oneOnOneModule){
        this.taskDatas = taskDatas;
        this.timeService = timeService;
        this.goodsContainerModule = goodsContainerModule;
        this.gemData = gemData;
        this.logService = logService;
        this.petModule = petModule;
        this.oneOnOneModule = oneOnOneModule;

        goodsContainerModule.setTaskCallbackModule(this);
    }

    public void checkTaskValidate(Hero hero){
        HeroTaskList taskList = hero.getTaskList();
        // 第一次进入场景的时候
        // 检查日常任务，帮派任务是否满足接取条件，是否没有接取到任务
        if (hero.getLevel() >= VariableConfig.DAILY_TASK_ACCEPT_LEVEL
                && taskList.dailyTaskRound <= VariableConfig.DAILY_TASK_MAX_ROUND){

            if (taskList.dailyTaskRound <= 0)
                taskList.dailyTaskRound = 1;

            // 补偿一个日常任务
            if (taskList.doingDailyTask == null){
                taskList.doingDailyTask = taskDatas.getDailyTaskDatas()
                        .random(hero.getLevel())
                        .newEmptyTask(taskList.newTaskId());
            }
        } else{
            // 防御性
            if (taskList.doingDailyTask != null){
                logger.error("doingDailyTask应该为null，但是doingDailyTask不为null");
                taskList.doingDailyTask = null;
            }
        }

        if (hero.hasGuild()
                && hero.getLevel() >= VariableConfig.GUILD_TASK_ACCEPT_LEVEL
                && taskList.guildTaskRound <= VariableConfig.GUILD_TASK_MAX_ROUND){

            if (taskList.guildTaskRound <= 0)
                taskList.guildTaskRound = 1;

            // 补偿一个帮派任务
            if (taskList.doingGuildTask == null){
                taskList.doingGuildTask = taskDatas.getGuildTaskDatas()
                        .random(hero.getLevel())
                        .newEmptyTask(taskList.newTaskId());
            }
        } else{
            // 上线时，帮派没了，将任务也清掉
            taskList.doingGuildTask = null;
        }
    }

    public void onSceneLoaded(Hero hero, ISender sender,
            HeroMiscModule heroMiscModule){
        HeroTaskList taskList = hero.getTaskList();

        // 检查有没有已经完成的任务
        checkCompletedTask(hero, sender, heroMiscModule, taskList);
    }

    public void checkCompletedTask(Hero hero, ISender sender,
            HeroMiscModule heroMiscModule, HeroTaskList taskList){

        // 剧情任务
        if (taskList.getDoingChapterTask() != null){
            ChapterTask chapterTask = taskList.getDoingChapterTask();

            boolean isCompleted = initTaskProgress(chapterTask.getProgress(),
                    hero, sender);
            if (isCompleted){
                // 完成任务
                onCompleteChapterTask(hero, sender, chapterTask, heroMiscModule);
            }
        }

        // 机缘任务
        ReusableIterator<ChanceTask> chanceTaskIterator = taskList.chanceTaskIterator;
        for (chanceTaskIterator.rewind(); chanceTaskIterator.hasNext();){
            ChanceTask chanceTask = chanceTaskIterator.next();

            boolean isCompleted = initTaskProgress(chanceTask.getProgress(),
                    hero, sender);
            if (isCompleted){
                // 完成任务
                onCompleteChanceTask(hero, sender, heroMiscModule,
                        chanceTask.getTaskId());
            }
        }
        chanceTaskIterator.cleanUp();

        // 日常任务
        if (taskList.getDoingDailyTask() != null){
            DailyTask dailyTask = taskList.getDoingDailyTask();

            boolean isCompleted = initTaskProgress(dailyTask.getProgress(),
                    hero, sender);
            if (isCompleted){
                // 完成任务
                onCompleteDailyTask(hero, sender, dailyTask, heroMiscModule);
            }
        }

        // 帮派任务
        if (taskList.getDoingGuildTask() != null){
            GuildTask guildTask = taskList.getDoingGuildTask();

            boolean isCompleted = initTaskProgress(guildTask.getProgress(),
                    hero, sender);
            if (isCompleted){
                // 完成任务
                onCompleteGuildTask(hero, sender, guildTask, heroMiscModule);
            }
        }
    }

    public void tryCompleteTaskOnEnterScene(SceneData dungeonData, Hero hero,
            ISender sender, HeroMiscModule heroMiscModule){
        HeroTaskList taskList = hero.getTaskList();

        // 剧情任务
        if (taskList.getDoingChapterTask() != null){
            ChapterTask chapterTask = taskList.getDoingChapterTask();
            // 进入副本任务只有一个任务目标，如果这个假设不成立（开服已经校验了），这里需要改
            TaskTargetProgress p = chapterTask.getFirstProgress();

            TaskTarget target = p.getTarget();
            if (!target.isEnterDungeon()){
                return;
            }

            if (dungeonData == target.dungeonData){
                // 完成任务
                onCompleteChapterTask(hero, sender, chapterTask, heroMiscModule);
            }
        }

        // 机缘任务
        // 日常任务
        // 帮派任务
    }

    public void onKillMonster(MonsterData monster, Hero hero, ISender sender,
            HeroMiscModule heroMiscModule, boolean isKiller){
        HeroTaskList taskList = hero.getTaskList();

        // 剧情任务
        if (taskList.getDoingChapterTask() != null){
            ChapterTask chapterTask = taskList.getDoingChapterTask();
            TaskTargetProgress[] progress = chapterTask.progress;
            for (TaskTargetProgress p : progress){
                if (p.onKillMonster(monster, sender, isKiller)){
                    // 怪物被消费了
                    if (p.isCompleted() && chapterTask.isAllProgressCompleted()){
                        // 完成任务
                        onCompleteChapterTask(hero, sender, chapterTask,
                                heroMiscModule);
                    }
                    break;
                }
            }
        }

        // 机缘任务
        ReusableIterator<ChanceTask> chanceTaskIterator = taskList.chanceTaskIterator;
        out: for (chanceTaskIterator.rewind(); chanceTaskIterator.hasNext();){
            ChanceTask chanceTask = chanceTaskIterator.next();
            TaskTargetProgress[] progress = chanceTask.progress;
            for (TaskTargetProgress p : progress){
                if (p.onKillMonster(monster, sender, isKiller)){
                    // 怪物被消费了
                    if (p.isCompleted() && chanceTask.isAllProgressCompleted()){
                        // 完成任务
                        onCompleteChanceTask(hero, sender, heroMiscModule,
                                chanceTask.getTaskId());
                    }
                    break out;
                }
            }
        }
        chanceTaskIterator.cleanUp();

        // 日常任务
        if (taskList.getDoingDailyTask() != null){
            DailyTask dailyTask = taskList.getDoingDailyTask();
            TaskTargetProgress[] progress = dailyTask.progress;
            for (TaskTargetProgress p : progress){
                if (p.onKillMonster(monster, sender, isKiller)){
                    // 怪物被消费了
                    if (p.isCompleted() && dailyTask.isAllProgressCompleted()){
                        // 完成任务
                        onCompleteDailyTask(hero, sender, dailyTask,
                                heroMiscModule);
                    }
                    break;
                }
            }
        }

        // 帮派任务
        if (taskList.getDoingGuildTask() != null){
            GuildTask guildTask = taskList.getDoingGuildTask();
            TaskTargetProgress[] progress = guildTask.progress;
            for (TaskTargetProgress p : progress){
                if (p.onKillMonster(monster, sender, isKiller)){
                    // 怪物被消费了
                    if (p.isCompleted() && guildTask.isAllProgressCompleted()){
                        // 完成任务
                        onCompleteGuildTask(hero, sender, guildTask,
                                heroMiscModule);
                    }
                    break;
                }
            }
        }
    }

    /**
     * 看下有没有可以完成的任务，物品已经在背包中了
     * @param pos
     * @param g
     * @param hero
     * @param sender
     */
    public void tryCompleteTaskOnGoodsAdded(GoodsData data, Hero hero,
            ISender sender, HeroMiscModule heroMiscModule){

        if (!data.isTaskCollectGoods()){
            return;
        }

        onAddGoods(data, hero, sender, heroMiscModule);
    }

    /**
     * 检查是否有扣背包物品的任务
     * @param toAdd
     */
    private void onAddGoods(GoodsData toAdd, Hero hero, ISender sender,
            HeroMiscModule heroMiscModule){

        HeroTaskList taskList = hero.getTaskList();

        // 剧情任务
        if (taskList.getDoingChapterTask() != null){
            ChapterTask chapterTask = taskList.getDoingChapterTask();
            TaskTargetProgress[] progress = chapterTask.progress;
            for (TaskTargetProgress p : progress){
                if (p.onAddGoods(toAdd, hero, sender, goodsContainerModule)){
                    // 物品被消费了
                    if (p.isCompleted() && chapterTask.isAllProgressCompleted()){
                        // 完成任务
                        onCompleteChapterTask(hero, sender, chapterTask,
                                heroMiscModule);
                    }
                    break;
                }
            }
        }

        // 机缘任务
        ReusableIterator<ChanceTask> chanceTaskIterator = taskList.chanceTaskIterator;
        for (chanceTaskIterator.rewind(); chanceTaskIterator.hasNext();){
            ChanceTask chanceTask = chanceTaskIterator.next();
            TaskTargetProgress[] progress = chanceTask.progress;
            for (TaskTargetProgress p : progress){
                if (p.onAddGoods(toAdd, hero, sender, goodsContainerModule)){
                    // 物品被消费了
                    if (p.isCompleted() && chanceTask.isAllProgressCompleted()){
                        // 完成任务
                        onCompleteChanceTask(hero, sender, heroMiscModule,
                                chanceTask.getTaskId());
                    }
                    break;
                }
            }
        }
        chanceTaskIterator.cleanUp();

        // 日常任务
        if (taskList.getDoingDailyTask() != null){
            DailyTask dailyTask = taskList.getDoingDailyTask();
            TaskTargetProgress[] progress = dailyTask.progress;
            for (TaskTargetProgress p : progress){
                if (p.onAddGoods(toAdd, hero, sender, goodsContainerModule)){
                    // 物品被消费了
                    if (p.isCompleted() && dailyTask.isAllProgressCompleted()){
                        // 完成任务
                        onCompleteDailyTask(hero, sender, dailyTask,
                                heroMiscModule);
                    }
                    break;
                }
            }
        }

        // 帮派任务
        if (taskList.getDoingGuildTask() != null){
            GuildTask guildTask = taskList.getDoingGuildTask();
            TaskTargetProgress[] progress = guildTask.progress;
            for (TaskTargetProgress p : progress){
                if (p.onAddGoods(toAdd, hero, sender, goodsContainerModule)){
                    // 物品被消费了
                    if (p.isCompleted() && guildTask.isAllProgressCompleted()){
                        // 完成任务
                        onCompleteGuildTask(hero, sender, guildTask,
                                heroMiscModule);
                    }
                    break;
                }
            }
        }
    }

    // ------------剧情任务------------

    public void onCompleteChapterTask(Hero hero, ISender sender,
            ChapterTask completeChapterTask, HeroMiscModule heroMiscModule){
        HeroTaskList taskList = hero.getTaskList();
        assert completeChapterTask == taskList.doingChapterTask;

        // 当前做的任务移除
        taskList.doingChapterTask = null;
        ChapterTaskData taskData = completeChapterTask.data;

        doCompleteChapterTask(taskData, hero, sender, heroMiscModule);
    }

    private void doCompleteChapterTask(ChapterTaskData taskData, Hero hero,
            ISender sender, HeroMiscModule heroMiscModule){
        HeroTaskList taskList = hero.getTaskList();
        taskList.lastCompletedChanpterAndIndex = taskData.chapterAndIndex;

        // 发送完成消息
        sender.sendMessage(taskData.completeTaskBuffer);

        String iEventId = logService.getTaskFinishedProcessor().newEventID(
                hero.getID());

        // 给奖励
        addTaskPrize(taskData.getPrize(hero.getRace().getRaceId()), hero,
                sender, heroMiscModule, iEventId);

        logService.getTaskFinishedProcessor().addLogEvent(hero.getOperatorId(),
                iEventId, hero.getServerId(), hero.getUin(), hero.getUserId(),
                hero.getName(), hero.getRaceId(), hero.getLevel(),
                taskData.taskId, taskData.taskData.name, taskData.getIntType());

        // 开启新功能
        if (taskData.func != null && hero.tryOpenTaskFunction(taskData.func)){

            switch (taskData.func){
                case FUNC_STORAGE:{
                    long ctime = timeService.getCurrentTime();
                    hero.openStorage(ctime);
                    break;
                }
//                case FUNC_GEM:{
//                    hero.setGem(new HeroGem(gemData));
//                    break;
//                }
                case FUNC_SIGN:{
                    // 清除之前的离线经验
                    hero.clearAccumulatedOfflineTime();
                    break;
                }
                case FUNC_TIAN_JIE:{
                    petModule.giveTianJie(heroMiscModule.getHeroFightModule());
                    break;
                }
                case FUNC_SINGLE_FIGHT:{
                    oneOnOneModule.onHeroUnlockFunc(hero.getID());
                    break;
                }
                default:{
                    // NOTHING
                }
            }

            sender.sendMessage(taskData.newFunctionMsg);
        }

        // 接取下一个任务
        ChapterTaskData nextTaskData = taskData.getNextTask();
        if (nextTaskData == null){
            // 已经完成了所有的剧情任务
            return;
        }

        iEventId = logService.getTaskStartProcessor().newEventID(hero.getID());

        logService.getTaskStartProcessor().addLogEvent(hero.getOperatorId(),
                iEventId, hero.getServerId(), hero.getUin(), hero.getUserId(),
                hero.getName(), hero.getRaceId(), hero.getLevel(),
                nextTaskData.taskId, nextTaskData.taskData.name,
                nextTaskData.getIntType());

        sender.sendMessage(nextTaskData.getNewTaskBuffer(hero.getRace()
                .getRaceId()));

        int taskId = nextTaskData.taskId;
        TaskTargetProgress[] progress = nextTaskData.taskData
                .newEmptyProgress(taskId);
        boolean isCompleted = initTaskProgress(progress, hero, sender);
        if (isCompleted){
            // 完成了，递归
            doCompleteChapterTask(nextTaskData, hero, sender, heroMiscModule);
            return;
        }

        taskList.doingChapterTask = nextTaskData.newTask(progress);
    }

    // ------------机缘任务------------

    public void acceptChanceTask(Quality quality, int count, Hero hero,
            ISender sender, OperateType type){
        HeroTaskList taskList = hero.getTaskList();

        taskList.chanceTaskAcceptedCount += count;
        for (int i = 0; i < count; i++){
            ChanceTaskData chanceTaskData = taskDatas.getChanceTaskDatas()
                    .random(quality, hero.getLevel());

            if (chanceTaskData == null){
                // 补偿一个任务
                chanceTaskData = taskDatas.getChanceTaskDatas()
                        .randomCompensateTask(hero.getLevel());
            }

            ChanceTask chanceTask = chanceTaskData.newEmptyTask(
                    taskList.newTaskId(), hero.getRace().getRaceId());

            // 杀怪任务，不可能自动完成
            taskList.chanceTaskMap.put(chanceTask.getTaskId(), chanceTask);
            sender.sendMessage(TaskMessages.getNewChanceTaskMsg(chanceTask
                    .encode4Client()));

            // 记录日志
            String iEventId = logService.getTaskStartProcessor().newEventID(
                    hero.getID());
            logService.getTaskStartProcessor().addLogEvent(
                    hero.getOperatorId(), iEventId, hero.getServerId(),
                    hero.getUin(), hero.getUserId(), hero.getName(),
                    hero.getRaceId(), hero.getLevel(), chanceTaskData.id, "",
                    chanceTaskData.getIntType());
        }
    }

    public void onCompleteChanceTask(Hero hero, ISender sender,
            HeroMiscModule heroMiscModule, int taskId){
        HeroTaskList taskList = hero.getTaskList();

        ChanceTask chanceTask = taskList.chanceTaskMap.remove(taskId);
        if (chanceTask == null){
            logger.error("onCompleteChanceTask时候，发现从chanceTaskMap中remove出来一个null值");
            return;
        }

        // 发送完成消息
        sender.sendMessage(TaskMessages.completeTaskMsg(chanceTask.getTaskId()));

        String iEventId = logService.getTaskFinishedProcessor().newEventID(
                hero.getID());

        // 给奖励
        addTaskPrize(chanceTask.getPrize(), hero, sender, heroMiscModule,
                iEventId);

        // 记录日志
        logService.getTaskFinishedProcessor().addLogEvent(hero.getOperatorId(),
                iEventId, hero.getServerId(), hero.getUin(), hero.getUserId(),
                hero.getName(), hero.getRaceId(), hero.getLevel(),
                chanceTask.getData().id, "", chanceTask.getData().getIntType());
    }

    // -------------日常任务------------

    public void acceptFirstRoundDailyTask(Hero hero, ISender sender,
            HeroMiscModule heroMiscModule){
        HeroTaskList taskList = hero.getTaskList();

        taskList.dailyTaskRound = 1;
        taskList.doingDailyTask = null;

        DailyTaskData dailyTaskData = taskDatas.getDailyTaskDatas().random(
                hero.getLevel());

        // 记录日志
        String iEventId = logService.getTaskStartProcessor().newEventID(
                hero.getID());
        logService.getTaskStartProcessor().addLogEvent(hero.getOperatorId(),
                iEventId, hero.getServerId(), hero.getUin(), hero.getUserId(),
                hero.getName(), hero.getRaceId(), hero.getLevel(),
                dailyTaskData.id, "", dailyTaskData.getIntType());

        int newTaskId = taskList.newTaskId();

        sender.sendMessage(TaskMessages.getNewDailyTaskMsg(dailyTaskData
                .encode4Client(taskList.dailyTaskRound, newTaskId)));

        // 检查任务是否已经完成
        TaskTargetProgress[] progress = dailyTaskData.taskData
                .newEmptyProgress(newTaskId);
        boolean isCompleted = initTaskProgress(progress, hero, sender);
        if (isCompleted){
            // 完成了，递归
            doCompleteDailyTask(newTaskId, dailyTaskData, hero, sender,
                    heroMiscModule);
            return;
        }

        taskList.doingDailyTask = dailyTaskData.newTask(newTaskId, progress);
    }

    public void onCompleteDailyTask(Hero hero, ISender sender,
            DailyTask completeDailyTask, HeroMiscModule heroMiscModule){
        HeroTaskList taskList = hero.getTaskList();

        assert completeDailyTask == taskList.doingDailyTask;

        // 当前做的任务移除
        taskList.doingDailyTask = null;
        DailyTaskData taskData = completeDailyTask.data;

        doCompleteDailyTask(completeDailyTask.taskId, taskData, hero, sender,
                heroMiscModule);
    }

    private void doCompleteDailyTask(int taskId, DailyTaskData taskData,
            Hero hero, ISender sender, HeroMiscModule heroMiscModule){
        HeroTaskList taskList = hero.getTaskList();

        taskList.dailyTaskRound++;

        // 发送完成消息
        sender.sendMessage(TaskMessages.completeTaskMsg(taskId));

        String iEventId = logService.getTaskFinishedProcessor().newEventID(
                hero.getID());

        // 给奖励
        addTaskPrize(taskData.getPrize(), hero, sender, heroMiscModule,
                iEventId);

        // 记录日志
        logService.getTaskFinishedProcessor().addLogEvent(hero.getOperatorId(),
                iEventId, hero.getServerId(), hero.getUin(), hero.getUserId(),
                hero.getName(), hero.getRaceId(), hero.getLevel(), taskData.id,
                "", taskData.getIntType());

        // 声望
        heroMiscModule.tryCompleteShengWangTask(ShengWangType.SW_DAILY_TASK,
                true, 1);

        // 接取下一个任务
        if (taskList.dailyTaskRound > VariableConfig.DAILY_TASK_MAX_ROUND){
            // 完成最后一环任务，给额外奖励
            addTaskPrize(
                    taskDatas.getDailyTaskDatas().getDailyTaskExtraPrize(),
                    hero, sender, heroMiscModule, iEventId);
            return;
        }

        DailyTaskData nextTaskData = taskDatas.getDailyTaskDatas().random(
                hero.getLevel());

        // 记录日志
        iEventId = logService.getTaskStartProcessor().newEventID(hero.getID());
        logService.getTaskStartProcessor().addLogEvent(hero.getOperatorId(),
                iEventId, hero.getServerId(), hero.getUin(), hero.getUserId(),
                hero.getName(), hero.getRaceId(), hero.getLevel(),
                nextTaskData.id, "", nextTaskData.getIntType());

        int newTaskId = taskList.newTaskId();
        sender.sendMessage(TaskMessages.getNewDailyTaskMsg(nextTaskData
                .encode4Client(taskList.dailyTaskRound, newTaskId)));

        TaskTargetProgress[] progress = nextTaskData.taskData
                .newEmptyProgress(newTaskId);
        boolean isCompleted = initTaskProgress(progress, hero, sender);
        if (isCompleted){
            // 完成了，递归
            doCompleteDailyTask(newTaskId, nextTaskData, hero, sender,
                    heroMiscModule);
            return;
        }

        taskList.doingDailyTask = nextTaskData.newTask(newTaskId, progress);
    }

    // ----------帮派任务-------------

    public void onHeroLeaveGuild(Hero hero, ISender sender){
        HeroTaskList taskList = hero.getTaskList();

        if (taskList.guildTaskRound > VariableConfig.GUILD_TASK_MAX_ROUND){
            // 今天已经接完了，没得任务可接
            return;
        }

        if (taskList.getDoingGuildTask() == null){
            // 还不能接取帮派任务
            return;
        }

        taskList.onHeroLeaveGuild();
        sender.sendMessage(REMOVE_GUILD_TASK_BUFFER);
    }

    public void tryAcceptGuildTask(Hero hero, ISender sender,
            HeroMiscModule heroMiscModule){
        HeroTaskList taskList = hero.getTaskList();

        if (taskList.guildTaskRound > VariableConfig.GUILD_TASK_MAX_ROUND){
            // 今天已经接完了，没得任务可接
            return;
        }

        if (taskList.guildTaskRound < 1)
            taskList.guildTaskRound = 1; // 防御性

        taskList.doingGuildTask = null;

        GuildTaskData taskData = taskDatas.getGuildTaskDatas().random(
                hero.getLevel());

        // 记录日志
        String iEventId = logService.getTaskStartProcessor().newEventID(
                hero.getID());
        logService.getTaskStartProcessor().addLogEvent(hero.getOperatorId(),
                iEventId, hero.getServerId(), hero.getUin(), hero.getUserId(),
                hero.getName(), hero.getRaceId(), hero.getLevel(), taskData.id,
                "", taskData.getIntType());

        int newTaskId = taskList.newTaskId();
        sender.sendMessage(TaskMessages.getNewGuildTaskMsg(taskData
                .encode4Client(taskList.guildTaskRound, newTaskId)));

        // 检查任务是否已经完成
        TaskTargetProgress[] progress = taskData.taskData
                .newEmptyProgress(newTaskId);
        boolean isCompleted = initTaskProgress(progress, hero, sender);
        if (isCompleted){
            // 完成了，递归
            doCompleteGuildTask(newTaskId, taskData, hero, sender,
                    heroMiscModule);
            return;
        }

        taskList.doingGuildTask = taskData.newTask(newTaskId, progress);
    }

    public void onCompleteGuildTask(Hero hero, ISender sender,
            GuildTask completeGuildTask, HeroMiscModule heroMiscModule){
        HeroTaskList taskList = hero.getTaskList();

        assert completeGuildTask == taskList.doingGuildTask;

        // 当前做的任务移除
        taskList.doingGuildTask = null;
        GuildTaskData taskData = completeGuildTask.data;

        doCompleteGuildTask(completeGuildTask.taskId, taskData, hero, sender,
                heroMiscModule);
    }

    private void doCompleteGuildTask(int taskId, GuildTaskData taskData,
            Hero hero, ISender sender, HeroMiscModule heroMiscModule){
        HeroTaskList taskList = hero.getTaskList();

        taskList.guildTaskRound++;

        // 发送完成消息
        sender.sendMessage(TaskMessages.completeTaskMsg(taskId));

        String iEventId = logService.getTaskFinishedProcessor().newEventID(
                hero.getID());

        // 给奖励
        addTaskPrize(taskData.getPrize(), hero, sender, heroMiscModule,
                iEventId);

        // 记录日志
        logService.getTaskFinishedProcessor().addLogEvent(hero.getOperatorId(),
                iEventId, hero.getServerId(), hero.getUin(), hero.getUserId(),
                hero.getName(), hero.getRaceId(), hero.getLevel(), taskData.id,
                "", taskData.getIntType());

        heroMiscModule.tryCompleteShengWangTask(ShengWangType.SW_GUILD_TASK,
                true, 1);

        // 接取下一个任务
        if (taskList.guildTaskRound > VariableConfig.GUILD_TASK_MAX_ROUND){
            // 完成最后一环任务，给额外奖励
            addTaskPrize(taskDatas.getGuildTaskDatas().getExtraPrize(), hero,
                    sender, heroMiscModule, iEventId);
            return;
        }

        GuildTaskData nextTaskData = taskDatas.getGuildTaskDatas().random(
                hero.getLevel());

        // 记录日志
        iEventId = logService.getTaskStartProcessor().newEventID(hero.getID());
        logService.getTaskStartProcessor().addLogEvent(hero.getOperatorId(),
                iEventId, hero.getServerId(), hero.getUin(), hero.getUserId(),
                hero.getName(), hero.getRaceId(), hero.getLevel(),
                nextTaskData.id, "", nextTaskData.getIntType());

        int newTaskId = taskList.newTaskId();
        sender.sendMessage(TaskMessages.getNewGuildTaskMsg(nextTaskData
                .encode4Client(taskList.guildTaskRound, newTaskId)));

        TaskTargetProgress[] progress = nextTaskData.taskData
                .newEmptyProgress(newTaskId);
        boolean isCompleted = initTaskProgress(progress, hero, sender);
        if (isCompleted){
            // 完成了，递归
            doCompleteGuildTask(newTaskId, nextTaskData, hero, sender,
                    heroMiscModule);
            return;
        }

        taskList.doingGuildTask = nextTaskData.newTask(newTaskId, progress);
    }

    private boolean initTaskProgress(TaskTargetProgress[] progress, Hero hero,
            ISender sender){
        // 检查任务是否已经完成

        boolean isComplete = true;
        for (TaskTargetProgress p : progress){
            p.init(hero, sender, goodsContainerModule);

            if (!p.isCompleted()){
                isComplete = false;
            }
        }

        return isComplete;
    }

    public void onDailyTaskReduceDiffiStar(Hero hero, ISender sender,
            HeroMiscModule heroMiscModule){
        HeroTaskList taskList = hero.getTaskList();

        assert taskList.doingDailyTask != null
                && !taskList.doingDailyTask.isMinDiffiTask();

        DailyTask oldTask = taskList.doingDailyTask;
        taskList.doingDailyTask = null;

        int taskId = oldTask.getTaskId();

        DailyTaskData newTaskData = oldTask.data.getOneStarDiffiTask();

        assert newTaskData.isMinDiffiTask();
        assert newTaskData.reduceDiffiBuffer != null;

        // 发消息
        sender.sendMessage(newTaskData.reduceDiffiBuffer);

        // 检查任务是否已经完成
        TaskTargetProgress[] progress = newTaskData.taskData.newProgress(
                taskId, oldTask.progress);
        boolean isCompleted = initTaskProgress(progress, hero, sender);
        if (isCompleted){
            // 完成了，递归
            doCompleteDailyTask(taskId, newTaskData, hero, sender,
                    heroMiscModule);
            return;
        }

        taskList.doingDailyTask = newTaskData.newTask(taskId, progress);
    }

    public void onDailyTaskAddPrizeStar(Hero hero, ISender sender){
        HeroTaskList taskList = hero.getTaskList();

        assert taskList.doingDailyTask != null
                && !taskList.doingDailyTask.isMaxPrizeTask();

        taskList.doingDailyTask = taskList.doingDailyTask.newFullPrizeTask();
        // 发消息
        sender.sendMessage(taskList.doingDailyTask.data
                .getAddToFullStarPrizeBuffer());
    }

    /**
     * 给任务奖励，如果背包空间不足，则放入到任务虚拟背包中
     * @param p
     */
    public void addTaskPrize(Prize p, Hero hero, ISender sender,
            HeroMiscModule miscModule, String iEventId){

        if (p.getWrapperCount() > 0){

            long ctime = timeService.getCurrentTime();
            GoodsAddHelper[] goodsArray = p.newGoodsAddHelpers(ctime);

            GoodsTryAddResult result = hero.getDepot().canAddGoods(goodsArray);
            if (result.isSuccess()){
                // よかった = yo katta
                goodsContainerModule.addBatchGoodsArray(goodsArray, result,
                        hero, sender, miscModule, TASK_DONE, 0, ctime);
            } else{
                // なに = nani

                // 将能放的先放入背包 TODO

                // 看下那些没放进去的，放到临时仓库
                HeroTaskList taskList = hero.getTaskList();
                if (taskList.getTaskGoodsCount() < VariableConfig.TASK_GOODS_MAX_COUNT){
                    List<Goods> taskGoodsList = taskList.getTaskGoodsList();

                    out: for (GoodsAddHelper toAdd : goodsArray){
                        if (toAdd.getCount() <= 0)
                            continue;

                        int needEmptyPosCount = toAdd.getNeedEmptyPosCount();
                        for (int i = 0; i < needEmptyPosCount; i++){
                            taskGoodsList.add(toAdd.create());

                            if (taskGoodsList.size() >= VariableConfig.TASK_GOODS_MAX_COUNT){
                                break out; // 到这里的话，说明可能有物品丢弃了
                            }
                        }

                        assert toAdd.getCount() <= 0: "addTaskPrize，物品创建完后，个数还大于0";
                    }

                    if (taskGoodsList.size() >= VariableConfig.TASK_GOODS_MAX_COUNT){
                        for (GoodsAddHelper toAdd : goodsArray){
                            if (toAdd.getCount() <= 0)
                                continue;

                            // 临时仓库已满，记录丢弃日志
                            logService.todo();
//                            logService.writeOperateLog(TASK_DROP_GOODS, GOODS,
//                                    objId, relatedId, toAdd.getId(),
//                                    toAdd.getCount(),
//                                    toAdd.getGoodsIdentifier(), hero);
                        }
                    }

                    // 全部发一次，省的麻烦
                    sender.sendMessage(TaskMessages
                            .getTaskGoodsListMsg(taskGoodsList));
                }
            }
        }

        // 因为可能会加经验，导致升级，所以先给物品，再给数值
        p.giveIgnoreGoods(miscModule, hero, true, TASK_DONE, iEventId);
    }
}
