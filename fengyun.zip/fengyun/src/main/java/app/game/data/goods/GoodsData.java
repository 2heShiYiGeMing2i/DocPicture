package app.game.data.goods;

import static com.mokylin.sink.util.Preconditions.*;

import org.jboss.netty.buffer.ChannelBuffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.data.GameObject;
import app.game.module.ChatMessages;
import app.game.module.scene.HeroFightModule;
import app.protobuf.GoodsContent.GoodsDataProto;
import app.protobuf.GoodsContent.GoodsProto;
import app.protobuf.GoodsServerContent.GoodsServerProto;
import app.protobuf.GoodsServerContent.GoodsType;
import app.protobuf.GoodsServerContent.Quality;
import app.utils.VariableConfig;

import com.google.common.annotations.VisibleForTesting;
import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.ByteString;
import com.mokylin.collection.IntValueLongHashMap;
import com.mokylin.sink.util.StringEncoder;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.parse.ObjectParser;

public abstract class GoodsData extends GameObject{
    protected static final Logger logger = LoggerFactory
            .getLogger(GoodsData.class);

    private final GoodsType type;

    protected final int maxCount;

    private final int sellPrice;

    /**
     * 品质0-白色;1-绿色;2-蓝色;3-紫色;4-橙色
     */
    public final Quality quality;

    /**
     * 等级需求
     */
    protected final int requireLevel;

    /**
     * 物品描述
     */
    private final String desc;

    /**
     * 图标资源
     */
    public final String icon;

    public final byte[] iconBytes;

    public final boolean dropable;

    private final boolean verifySell;

    private final boolean verifyDrop;

    /**
     * 掉出时是否公告
     */
    public final boolean dropBroadAround;

    /**
     * 冷却时间，单位毫秒
     */
    public final int cd;

    /**
     * 公共冷却层级，当公共冷却层级进入冷却时，属于该层级的其他物品同样无法使用
     */
    public final int cdType;

    /**
     * 公共冷却时间，单位毫秒
     */
    public final int gcd;

    /**
     * 是否可以设置到快捷键，true表示可以，必须是可以使用的物品
     */
    protected final boolean canSetShortcut;

    /**
     * 是否提示使用（如双倍经验丹），true表示提示使用
     */
    protected final boolean isSuggestion;

    private ChannelBuffer goodsReplyInfoMsg;

    /**
     * 是否有任务可以直接扣这种物品
     */
    private boolean isTaskCollectGoods;

    /**
     * 是否需要记录英雄物品的来龙去脉
     */
    public final boolean needLog;

    // TODO 掉出时是否记录日志

    GoodsData(ObjectParser p, GoodsType type){
        super(p);

        checkArgument(type.getNumber() >= 0 && type.getNumber() <= 127,
                "GoodsType的数字必须>=0 && <=127: %s", type); // goods identifier里只给了7个bit

        checkArgument(id < VariableConfig.SHORTCUT_MAX_ID, "物品id必须< %s: %s-%s",
                VariableConfig.SHORTCUT_MAX_ID, id, name);

        this.type = type;

        checkArgument(name.length() <= 10, "物品名称不能大于10个字， name: %s", name);

        maxCount = p.getIntKey("max_count", 1);
        checkArgument(
                maxCount > 0 && maxCount < 10000,
                "物品%s-%s 配置的最大堆叠数量错误，maxCount > 0 && maxCount < 10000，maxCount: %s",
                id, name, maxCount);

        sellPrice = p.getIntKey("sell_price");
        checkArgument(sellPrice >= 0, "物品%s-%s 的出售价格必须>=0，sellPrice: %s", id,
                name, sellPrice);

        if (sellPrice > 0){
            long maxSellPrice = ((long) sellPrice) * maxCount
                    * VariableConfig.BUY_BACK_MULTIPLE;

            checkArgument(maxSellPrice > 0
                    && maxSellPrice < VariableConfig.MONEY_MAX_AMOUNT,
                    "物品%s-%s 的整堆出售价格超过英雄最大银两数（20亿），maxSellPrice: %s", id, name,
                    maxSellPrice);
        }

        int qualityValue = p.getIntKey("quality", 0);
        this.quality = checkNotNull(Quality.valueOf(qualityValue),
                "物品%s-%s 的品质配置错误（0-白色;1-绿色;2-蓝色;3-紫色;4-橙色），quality: %s", id,
                name, qualityValue);

        requireLevel = p.getIntKey("require_level");
        checkArgument(requireLevel >= 0,
                "物品%s-%s 的等级需求必须 requireLevel>=0，requireLevel: %s", id, name,
                requireLevel);

        desc = checkNotNull(p.getKey("desc"), "物品%s-%s 的描述desc没找到", id, name);
        checkArgument(!desc.isEmpty(), "物品%s-%s 的描述desc没找到", id, name);

        icon = checkNotNull(p.getKey("icon"), "物品%s-%s 的tiny_icon没找到", id, name);
        checkArgument(!icon.isEmpty(), "物品%s-%s 的icon没找到", id, name);

        iconBytes = StringEncoder.encode(icon);

        dropable = p.getBooleanKey("dropable");
        verifySell = p.getBooleanKey("verify_sell");

        // verifyDrop = dropBroadAround = verifySell;
        verifyDrop = p.getBooleanKey("verify_drop");
        dropBroadAround = p.getBooleanKey("drop_broad_around");

        int cd = p.getIntKey("cd", 0);
        cdType = p.getIntKey("cd_type", 0);
        gcd = p.getIntKey("gcd", 0);

        if (cdType > 0){
            checkArgument(gcd > 0, "物品%s-%s 配置了冷却层级，但是没有公共冷却时间", id, name);

            if (cd <= gcd){
                cd = 0;
            }
        }
        this.cd = cd;

        canSetShortcut = p.getBooleanKey("can_set_shortcut", false);
        isSuggestion = p.getBooleanKey("is_suggestion", false);
        needLog = p.getBooleanKey("need_log", false);
    }

    public Quality getQuality(){
        return quality;
    }

    public void taskCollectGoods(){
        isTaskCollectGoods = true;

        checkArgument(!(this instanceof EquipmentData), "扣背包物品任务要扣除的居然是装备, %s",
                this);
    }

    public boolean isTaskCollectGoods(){
        return isTaskCollectGoods;
    }

    public ChannelBuffer getGoodsReplyInfoMsg(){
        return this.goodsReplyInfoMsg;
    }

    @VisibleForTesting
    public Goods createGoods4Test(int count){
        return createGoods4Test(count, 0);
    }

    @VisibleForTesting
    public Goods createGoods4Test(int count, long expireTime){
        Goods g = newGoods(expireTime);
        g.setCount(count);

        return g;
    }

    public int getId(){
        return id;
    }

    public GoodsType getType(){
        return type;
    }

    public int getIntType(){
        return type.getNumber();
    }

    public int getMaxCount(){
        return maxCount;
    }

    public int getSellPrice(){
        return sellPrice;
    }

    public int getRequireLevel(){
        return requireLevel;
    }

    /**
     * 使用物品所需的职业. 装备重写了此方法
     * @return
     */
    public int getRequiredRace(){
        return 0;
    }

    public boolean isValidRace(int race){
        int requiredRace = getRequiredRace();
        return requiredRace == 0 || requiredRace == race;
    }

    public boolean canSell(){
        return sellPrice > 0;
    }

    /**
     * 是否可以使用，可以使用的物品重写这个方法
     * @return
     */
    public boolean useable(){
        return getEfficacy() != null;
    }

    /**
     * 是否可以批量使用，可以批量使用的物品重写这个方法
     * @return
     */
    public boolean bulkUseable(){
        return false;
    }

    public boolean hasCooldown(){
        return cd > 0 || gcd > 0;
    }

    public int getCd(){
        return cd;
    }

    public int getCdType(){
        return cdType;
    }

    public int getGcd(){
        return gcd;
    }

    public boolean isFoldable(){
        return maxCount > 1;
    }

    public long getGoodsIdentifier(GoodsServerProto proto){
        return getGoodsIdentifier(proto.getBinded(),
                (int) (proto.getExpireTime() / 1000));
    }

    public long getGoodsIdentifier(boolean binded, int intExpireTime){
        // 最右bit, 是否绑定
        // 接下来20位, 物品id
        // 7位物品类型
        // 以上28位是固定的, 每个物品都是这样
        // 再上面, 普通物品就是个过期时间（单位秒）
        return (intExpireTime << 28) | getGoodsIdentifierSharedBits(binded);
    }

    protected long getGoodsIdentifierSharedBits(boolean binded){
        return (getIntType() << 21) | (getId() << 1) | (binded ? 1 : 0);
    }

    private static final int ID_MASK = (1 << 20) - 1;

    public static int getId(long identifier){
        return (int) ((identifier >>> 1) & ID_MASK);
    }

    /**
     * 物品默认没有使用功效，药品，任务卷轴，传送卷轴等重写这个方法
     * @return
     */
    public Efficacy getEfficacy(){
        return null;
    }

    // 子类重写这个方法
    Goods newGoods(long expireTime){
        return new Goods(this, expireTime);
    }

    // for decode 子类重写这个方法
    Goods newGoods(int realCount, GoodsServerProto proto){
        return new Goods(this, realCount, proto);
    }

    public abstract byte[] getProtoBytes();

    public abstract ByteString getProtoByteString();

    /**
     * 全部物品 0
     *
     * 步惊云全部装备 1
     *     武器 10
     *     头盔 15
     *     衣服 16
     *     腰带 17
     *     裤子 18
     *     鞋子 19
     *
     * 聂风全部装备 2
     *     武器 20
     *     头盔 25
     *     衣服 26
     *     腰带 27
     *     裤子 28
     *     鞋子 29
     *
     * 楚楚全部装备 3
     *     武器 30
     *     头盔 35
     *     衣服 36
     *     腰带 37
     *     裤子 38
     *     鞋子 39
     *
     * 第二梦全部装备 4
     *     武器 40
     *     头盔 45
     *     衣服 46
     *     腰带 47
     *     裤子 48
     *     鞋子 49
     *
     * 全部技能书 7 (70-79都预留给技能书了. AuctionTypeHelper里这么干了)
     *     夫妻技能书 70
     *     麒麟臂技能书 71
     *     坐骑技能书 72
     *     宠物技能书73
     *     天劫技能书74
     *     天罪技能书75
     *     神兵心法76
     *     被动技能77
     *     神兵心法78
     *
     * 全部坐骑装备 8
     *     鞍具 80
     *     缰绳 81
     *     蹬具 82
     *     蹄铁 83
     *
     * 全部通用装备 9
     *     戒指 91
     *     项链 92
     *     护腕 93
     *     玉佩 94
     *
     * 全部材料 100
     *     装备强化石 101
     *     装备升级石 102
     *     坐骑进阶丹 106
     *     凤舞进阶石 110
     *     天罪进阶丹111
     *     天劫进阶丹112
     *
     * 全部其他物品 120
     *     增强药品 121
     *     任务卷轴 122
     *     其他 123
     *     血菩提 124
     *     收益丹 125
     *
     * 全部货币 97
     *     银两 98
     *     元宝 99
     *
     */
    protected abstract int getAuctionType();

    public int getRealAuctionType(){
        if (customAuctionType > 0){
            return customAuctionType;
        }

        return getAuctionType();
    }

    public static final int REFINED_FORGE_AUCTION_TYPE = 101;

    public static final int LEVEL_FORGE_AUCTION_TYPE = 102;

    public static final int MOUNT_AUCTION_TYPE = 106;

    public static final int SUPER_WEAPON_AUCTION_TYPE = 108;

    public static final int WEAPON_SOUL_AUCTION_TYPE = 109;

    public static final int BOW_AUCTION_TYPE = 110;

    public static final int TIAN_ZUI_AUCTION_TYPE = 111;

    public static final int TIAN_JIE_AUCTION_TYPE = 112;

    /**
     * 根据系统设置的类型，比如坐骑丹神马的，如果这个大于0就用这样，否则用子类实现的
     */
    private int customAuctionType;

    public void setCustomAuctionType(int type){

        checkArgument(getAuctionType() == 123,
                "物品的AuctionType不是123（其他类型），不允许设置CustomAuctionType");

        if (customAuctionType == 0){
            customAuctionType = type;
        } else if (customAuctionType != type){
            customAuctionType = 123;
        }
    }

    protected byte[] processProtoBytes(byte[] data){

        byte[] input = new byte[data.length + 1];
        input[0] = (byte) getIntType();
        System.arraycopy(data, 0, input, 1, data.length);

        // 顺便初始化这个
        this.goodsReplyInfoMsg = ChatMessages.goodsInfoReply(input);

        return input;
    }

    protected GoodsDataProto.Builder encode(){
        GoodsDataProto.Builder builder = GoodsDataProto.newBuilder();
        builder.setId(id).setName(ByteString.copyFrom(nameBytes))
                .setMaxCount(maxCount).setDesc(ByteString.copyFromUtf8(desc))
                .setIcon(icon);

        if (sellPrice > 0){
            builder.setSellPrice(sellPrice);
        }

        if (quality.getNumber() > 0){
            builder.setQuality(quality.getNumber());
        }

        if (requireLevel > 0){
            builder.setRequireLevel(requireLevel);
        }

        if (dropable){
            builder.setDropable(dropable);
        }

        if (verifySell){
            builder.setVerifySell(verifySell);
        }

        if (verifyDrop){
            builder.setVerifyDrop(verifyDrop);
        }

        if (cdType > 0){
            builder.setCdType(cdType);
        }

        if (useable()){
            builder.setUseable(true);

            if (bulkUseable()){
                builder.setBulkUseable(true);
            }

            if (canSetShortcut){
                builder.setCanSetShortcut(true);
            }

            if (isSuggestion){
                builder.setIsSuggestion(true);
            }
        }

        return builder;
    }

    public AbstractMessageLite encodeGoodsProto(Goods g){
        return encodeGoodsProto(g.getCount(), g.binded, g.expireTime);
    }

    public AbstractMessageLite encodeGoodsProto(GoodsServerProto serverProto){
        return encodeGoodsProto(serverProto.getCount(),
                serverProto.getBinded(), serverProto.getExpireTime());
    }

    GoodsProto encodeGoodsProto(int count, boolean binded, long expireTime){
        GoodsProto.Builder builder = GoodsProto.newBuilder().setCount(count);

        if (binded){
            builder.setBinded(true);
        }

        if (expireTime > 0){
            builder.setExpireTime(expireTime);
        }

        return builder.build();
    }

    // ----- decode -----

    public Goods decodeDontCheck(GoodsServerProto proto){
        return decode(proto, null);
    }

    public Goods decode(GoodsServerProto proto,
            IntValueLongHashMap goodsCountMap){

        if (proto.getCount() <= 0){
            logger.error("decode Goods 时候，发现proto中的count<=0: {} 个, id {} + "
                    + Utils.getStackTrace(), proto.getCount(), proto.getId());
            return null;
        }

        int realCount = proto.getCount();
        if (goodsCountMap != null){
            if (goodsCountMap == null || goodsCountMap.isEmpty()){
                logger.error("decode Goods 时候，发现goodsCountMap.isEmpty()，{}-{}",
                        proto.getId(), proto.getCount());
                return null;
            }

            long identifier = getGoodsIdentifier(proto);
            int remainCount = goodsCountMap.get(identifier);
            if (remainCount <= 0){
                logger.error(
                        "decode Goods 时候，发现物品已经没有了，identifier:{} goods:{} count:{}",
                        identifier, this, proto.getCount());
                return null;
            } else if (proto.getCount() < remainCount){
                goodsCountMap.put(identifier, remainCount - proto.getCount());
            } else{
                goodsCountMap.remove(identifier);
                realCount = remainCount;
            }
        }

        return newGoods(realCount, proto);
    }

    /**
     * 物品功效
     * @author Liwei
     *
     */
    public static interface Efficacy{

        /**
         * 使用物品
         * @param useCount
         * @param ctime TODO
         * @param iEventId TODO
         * @param uuid TODO
         * @param hc
         * @return 实际使用个数，如果返回0，表示一个都没用
         */
        int useTo(HeroFightModule heroFightModule, int useCount, long ctime,
                String iEventId);
    }
}
