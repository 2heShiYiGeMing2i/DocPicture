package app.game.data.goods;

import java.util.List;

import app.game.data.GameObjects;
import app.game.data.SingleSpriteStats;
import app.protobuf.ConfigContent.Config;

import com.google.inject.Inject;
import com.mokylin.collection.IntHashMap;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class TaozDatas{

    public static final String LOCATION = GameObjects.GOODS_BASE_LOCATION
            + "taozhuang.txt";

    private final IntHashMap<TaozData> datas;

    @Inject
    TaozDatas(GameObjects go, SingleSpriteStats spriteStats){
        List<ObjectParser> list = go.loadFile(LOCATION);

        datas = new IntHashMap<TaozData>();
        for (ObjectParser p : list){
            TaozData m = new TaozData(p, spriteStats);
            datas.putUnique(m.id, m);
        }
    }

    TaozData get(int id){
        return datas.get(id);
    }

    public void encode(Config.Builder builder){
        for (TaozData data : datas.values()){
            builder.addTaozs(data.generateProto());
        }
    }
}
