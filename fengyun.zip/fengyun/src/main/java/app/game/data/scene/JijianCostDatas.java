package app.game.data.scene;

import static com.mokylin.sink.util.Preconditions.checkArgument;

import java.util.List;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.data.GameObjects;
import app.game.module.scene.JijianMessages;

import com.google.inject.Inject;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class JijianCostDatas{

    private static final String LOCATION = GameObjects.JI_JIAN_SCENE_BASE_FOLDER
            + "jijian_cost.txt";

    private final JijianCostData[] datas;

    private final ChannelBuffer lastMoneySwordSacrificeMsg;
    private final ChannelBuffer lastYuanbaoSwordSacrificeMsg;

    @Inject
    JijianCostDatas(GameObjects go){
        List<ObjectParser> data = go.loadFile(LOCATION);
        checkArgument(data.size() > 0, "祭剑数据没有配置");

        datas = new JijianCostData[data.size()];
        for (ObjectParser p : data){
            JijianCostData d = new JijianCostData(p);
            checkArgument(d.times >= 1 && d.times <= datas.length,
                    "祭剑次数配置错误，必须从1开始连续配置, %s", d);

            checkArgument(datas[d.times - 1] == null, "祭剑次数存在重复数据, %s", d);
            datas[d.times - 1] = d;
        }

        for (int i = 1; i < datas.length; i++){
            checkArgument(datas[i - 1].moneyCost <= datas[i].moneyCost,
                    "%s 的银两消耗居然比前一级的消耗要少", datas[i]);

            checkArgument(datas[i - 1].realAir4Money <= datas[i].realAir4Money,
                    "%s 的银两祭剑获得真气居然比前一级的要少", datas[i]);

            checkArgument(datas[i - 1].yuanbaoCost <= datas[i].yuanbaoCost,
                    "%s 的元宝消耗居然比前一级的消耗要小", datas[i]);

            checkArgument(
                    datas[i - 1].realAir4Yuanbao <= datas[i].realAir4Yuanbao,
                    "%s 的元宝祭剑获得真气居然比前一级的消耗要小", datas[i]);
        }

        lastMoneySwordSacrificeMsg = JijianMessages
                .getMoneySwordSacrificeMsg(datas.length, 0, 0);
        lastYuanbaoSwordSacrificeMsg = JijianMessages
                .getYuanbaoSwordSacrificeMsg(datas.length, 0, 0);
    }

    public int getMaxTimes(){
        return datas.length;
    }

    public JijianCostData get(int times){
        if (times >= 0 && times < datas.length){
            return datas[times];
        }

        return null;
    }

    public ChannelBuffer getMoneySwordSacrificeMsg(int times){
        if (times >= 0 && times < datas.length){
            return datas[times].getMoneySwordSacrificeMsg();
        }

        return lastMoneySwordSacrificeMsg;
    }

    public ChannelBuffer getYuanbaoSwordSacrificeMsg(int times){
        if (times >= 0 && times < datas.length){
            return datas[times].getYuanbaoSwordSacrificeMsg();
        }

        return lastYuanbaoSwordSacrificeMsg;
    }
}
