/**
 * 
 */
package app.game.data.goods;

import static com.mokylin.sink.util.Preconditions.checkNotNull;
import app.game.data.GameObjects;
import app.protobuf.GoodsContent.PanelGoodsDataProto;
import app.protobuf.GoodsContent.PanelGoodsDataProto.PanelType;
import app.protobuf.GoodsServerContent.GoodsType;

import com.google.protobuf.ByteString;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 * 
 */
public class PanelGoodsData extends GoodsData{

    static final String LOCATION = GameObjects.GOODS_BASE_LOCATION
            + "panel.txt";

    private final PanelType panel;

    private final PanelGoodsDataProto proto;

    private final byte[] protoBytes;

    private final ByteString protoByteString;

    PanelGoodsData(ObjectParser p){
        super(p, GoodsType.PANEL);

        int intPanel = p.getIntKey("panel");

        panel = checkNotNull(PanelType.valueOf(intPanel),
                "%s 配置的面板没找到，pannel: %s", this, intPanel);

        proto = build();
        protoBytes = processProtoBytes(proto.toByteArray());
        protoByteString = ByteString.copyFrom(protoBytes);
    }

    private PanelGoodsDataProto build(){
        PanelGoodsDataProto.Builder builder = PanelGoodsDataProto.newBuilder();
        builder.setBaseData(encode());
        builder.setPanel(panel);

        return builder.build();
    }

    public PanelGoodsDataProto getProto(){
        return proto;
    }

    @Override
    public byte[] getProtoBytes(){
        return protoBytes;
    }

    @Override
    public ByteString getProtoByteString(){
        return protoByteString;
    }

    @Override
    public int getAuctionType(){
        switch (panel){
            case PET:{
                return 124;
            }
            default:{
                return 123;
            }
        }
    }

    public PanelType getPanel(){
        return panel;
    }
}
