package app.game.data.task;

import app.game.data.Race;
import app.game.data.task.TaskTarget.TaskTargetProgress;
import app.protobuf.HeroServerContent.ChapterTaskServerProto;
import app.protobuf.TaskContent.ChapterTaskProto;
import app.protobuf.TaskContent.TaskProto;

/**
 * @author Liwei
 *
 */
public class ChapterTask{

    final ChapterTaskData data;

    final TaskTargetProgress[] progress;

    ChapterTask(ChapterTaskData data, TaskTargetProgress[] progress){
        this.data = data;
        this.progress = progress;
    }

    public int getChapter(){
        return data.chapter;
    }

    public int getIntType(){
        return data.getIntType();
    }

    public ChapterTaskData getData(){
        return data;
    }

    public ChapterTaskData getPrevTaskData(){
        return data.prevTask;
    }

    public int getTaskId(){
        return data.taskId;
    }

    public TaskTargetProgress[] getProgress(){
        return progress;
    }

    public TaskTargetProgress getFirstProgress(){
        return progress[0];
    }

    public boolean isAllProgressCompleted(){
        for (TaskTargetProgress p : progress){
            if (!p.isCompleted())
                return false;
        }

        return true;
    }

    final ChapterTaskProto encodeToSelfOnLogin(Race race){
        ChapterTaskProto.Builder builder = ChapterTaskProto.newBuilder();

        builder.setChapter(data.chapter);
        for (int i = 0; i < data.index; i++){
            builder.addCompletedTask(data.completedTaskNames[i]);
        }

        // 设置进度
        TaskProto.Builder taskBuilder = data.getTaskProtoOnLogin(
                race.getRaceId()).toBuilder();
        for (TaskTargetProgress p : progress){
            taskBuilder.addProgress(p.progress);
        }

        builder.setBaseTask(taskBuilder.build());

        return builder.build();
    }

    final ChapterTaskServerProto encode(){
        ChapterTaskServerProto.Builder chapterTaskBuilder = ChapterTaskServerProto
                .newBuilder();
        chapterTaskBuilder.setChapter(data.chapter);
        chapterTaskBuilder.setIndex(data.index);
        for (TaskTargetProgress p : progress){
            chapterTaskBuilder.addProgress(p.progress);
        }

        return chapterTaskBuilder.build();
    }

    static ChapterTask decode(ChapterTaskData data, ChapterTaskServerProto proto){
        return new ChapterTask(data, data.taskData.newProgress(data.taskId,
                proto.getProgressList()));
    }
}
