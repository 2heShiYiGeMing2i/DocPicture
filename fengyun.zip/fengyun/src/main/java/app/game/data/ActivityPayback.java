package app.game.data;

import static com.mokylin.sink.util.Preconditions.*;
import app.protobuf.ConfigContent.DailyActivityProto;
import app.protobuf.ConfigContent.DailyActivityType;
import app.protobuf.ConfigContent.ShengWangType;

import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class ActivityPayback{

    public final DailyActivityType type;

    public final Prize prize;

    public final int cost;

    private final ShengWangType shengWangType;

    private TimeData timeData;

    ActivityPayback(ObjectParser p, PrizeConfigs prizeConfigs){

        int intType = p.getIntKey("type");
        type = checkNotNull(DailyActivityType.valueOf(intType), "活动买回类型无效, %s",
                intType);

        String prizeName = p.getKey("prize");

        PrizeConfig prizeConfig = checkNotNull(prizeConfigs.get(prizeName),
                "活动买回-%s 奖励无效, %s", type, prizeName);

        prize = prizeConfig.random();

        cost = p.getIntKey("cost");

        switch (type){
            case DA_TERRITORY:
            case DA_WS_CITY:
            case DA_LONG_CITY:
            case DA_WORLD_BOSS:{
                checkArgument(cost == 0, "活动买回-%s 元宝消耗配置必须等于0", type);
                break;
            }
            default:{
                checkArgument(cost >= 0, "活动买回-%s 元宝消耗必须大于等于0", type);
                break;
            }
        }

        switch (type){
            case DA_EXAM:{
                shengWangType = ShengWangType.SW_EXAM;
                break;
            }
            case DA_JIJIAN:{
                shengWangType = ShengWangType.SW_JIJIAN;
                break;
            }
            default:{
                shengWangType = null;
            }
        }
    }

    public ShengWangType getShengWangType(){
        return shengWangType;
    }

    public void setTimeData(TimeData timeData){
        this.timeData = timeData;
    }

    public TimeData getTimeData(){
        return timeData;
    }

    DailyActivityProto encode(){
        DailyActivityProto.Builder builder = DailyActivityProto.newBuilder();

        builder.setType(type);
        if (cost > 0)
            builder.setCost(cost);
        builder.setPrize(prize.encode4Client());

        return builder.build();
    }
}
