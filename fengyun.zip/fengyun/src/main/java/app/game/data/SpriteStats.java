package app.game.data;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.annotations.VisibleForTesting;
import com.google.inject.Inject;
import com.mokylin.collection.IntHashMap;
import com.mokylin.sink.util.parse.ObjectParser;

public class SpriteStats{
    private static final Logger logger = LoggerFactory
            .getLogger(SpriteStats.class);

    public static final String LOCATION = "config/data/sprite_stat.txt";

    private final IntHashMap<SpriteStat> globalMap;

    @Inject
    SpriteStats(GameObjects go){
        logger.debug("loading SpriteStats");
        try{
            List<ObjectParser> data = go.loadFile(LOCATION);
            globalMap = new IntHashMap<SpriteStat>(data.size() + 1);

            globalMap.put(0, SpriteStat.EMPTY_STAT);

            for (ObjectParser p : data){
                SpriteStat s = new SpriteStat(p);
                globalMap.putUnique(s.id, s);
            }
        } catch (Throwable ex){
            logger.error("SpriteStats loading error", ex);
            throw new RuntimeException(ex);
        }
        logger.debug("SpriteStats loaded");
    }

    /**
     * id 0 是个空的属性
     * 
     * @param id
     * @return
     */
    public SpriteStat get(int id){
        return globalMap.get(id);
    }

    @VisibleForTesting
    IntHashMap<SpriteStat> getGlobalMap(){
        return globalMap;
    }

}
