package app.game.data.scene;

import static app.game.module.scene.ChallengeDungeonMessages.*;

import org.jboss.netty.buffer.ChannelBuffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.entity.Hero;
import app.game.module.scene.AbstractDungeonScene;
import app.game.module.scene.ChallengeDungeonScene;
import app.game.module.scene.HeroFightModule;
import app.protobuf.LogContent.LogEnum.TransportType;
import app.utils.VariableConfig;

import com.mokylin.sink.util.concurrent.PaddedAtomicReference;

/**
 * 副本援助
 * @author Liwei
 *
 */
public class DungeonAssistMember{

    private static final Logger logger = LoggerFactory
            .getLogger(DungeonAssistMember.class);

    private static final ChallengeDungeonAssistObject OBJECT = new ChallengeDungeonAssistObject(
            0, 0, null, 0, 0, 0, null);

    private final long id;

    private final HeroFightModule heroFightModule;

    private final VariableConfig config;

    // 邀请者 英雄自己设置
    private ChallengeDungeonAssistObject invitor1;
    private ChallengeDungeonAssistObject invitor2;

    // 被邀请者 别人设置
    private final PaddedAtomicReference<ChallengeDungeonAssistObject> invitees1;
    private final PaddedAtomicReference<ChallengeDungeonAssistObject> invitees2;

    public DungeonAssistMember(HeroFightModule heroFightModule){
        this.id = heroFightModule.getID();
        this.heroFightModule = heroFightModule;
        config = heroFightModule.getServices().getVariableConfig();

        invitees1 = new PaddedAtomicReference<>(null);
        invitees2 = new PaddedAtomicReference<>(null);
    }

    public boolean onHeroAgreeInvitation(long targetId){

        ChallengeDungeonAssistObject inviteesObj = invitees1.get();
        if (inviteesObj != null && inviteesObj.invitorId == targetId){
            if (inviteesObj.inviteesState != INVITEES_AGREE){
                inviteesObj.onInviteesAgree();
            }
            return true;
        }

        inviteesObj = invitees2.get();
        if (inviteesObj != null && inviteesObj.invitorId == targetId){
            if (inviteesObj.inviteesState != INVITEES_AGREE){
                inviteesObj.onInviteesAgree();
            }
            return true;
        }

        return false;
    }

    public boolean onHeroRejectInvitation(long targetId){

        ChallengeDungeonAssistObject inviteesObj = invitees1.get();
        if (inviteesObj != null && inviteesObj.invitorId == targetId){
            inviteesObj.onInviteesReject();
            invitees1.compareAndSet(inviteesObj, null);
            return true;
        }

        inviteesObj = invitees2.get();
        if (inviteesObj != null && inviteesObj.invitorId == targetId){
            inviteesObj.onInviteesReject();
            invitees2.compareAndSet(inviteesObj, null);
            return true;
        }

        return false;
    }

    public void onCancelInviteHero(long targetId){

        if (invitor1 != null && invitor1.inviteesId == targetId){
            invitor1.invitorState = INVITOR_CANCEL;
            invitor1.invitorHasChange = true;
            invitor1 = null;
            return;
        }

        if (invitor2 != null && invitor2.inviteesId == targetId){
            invitor2.invitorState = INVITOR_CANCEL;
            invitor2.invitorHasChange = true;
            invitor2 = null;
            return;
        }
    }

    public void onClosePanel(){
        if (invitor1 != null){
            invitor1.invitorState = INVITOR_CANCEL;
            invitor1.invitorHasChange = true;
            invitor1 = null;
        }

        if (invitor2 != null){
            invitor2.invitorState = INVITOR_CANCEL;
            invitor2.invitorHasChange = true;
            invitor2 = null;
        }
    }

    public ChallengeDungeonAssistObject getInvitor(long targetId){

        if (invitor1 != null && invitor1.inviteesId == targetId){
            return invitor1;
        }

        if (invitor2 != null && invitor2.inviteesId == targetId){
            return invitor2;
        }

        return null;
    }

    public boolean resetAssistMember(ChallengeDungeonAssistObject ignore){
        boolean hasReset = false;
        if (invitor1 != null && invitor1 != ignore){
            invitor1.onInvitorCancel();
            hasReset = true;
        }

        if (invitor2 != null && invitor2 != ignore){
            invitor2.onInvitorCancel();
            hasReset = true;
        }

        invitor1 = null;
        invitor2 = null;

        ChallengeDungeonAssistObject inviteesObj = invitees1.get();
        if (inviteesObj != null){
            inviteesObj.onInviteesReject();
            invitees1.compareAndSet(inviteesObj, null);
            hasReset = true;
        }

        inviteesObj = invitees2.get();
        if (inviteesObj != null){
            inviteesObj.onInviteesReject();
            invitees2.compareAndSet(inviteesObj, null);
            hasReset = true;
        }

        return hasReset;
    }

    public void onOffline(){
        // 处理邀请的人
        onClosePanel();

        // 处理被邀请的人
        ChallengeDungeonAssistObject inviteesObj = invitees1.getAndSet(OBJECT);
        if (inviteesObj != null){
            inviteesObj.onInviteesReject();
        }

        inviteesObj = invitees2.getAndSet(OBJECT);
        if (inviteesObj != null){
            inviteesObj.onInviteesReject();
        }
    }

    public void onInviteHero(DungeonAssistMember target, long ctime,
            ChallengeDungeonSceneData sceneData){
        assert this != target;

        if (invitor1 != null){
            if (invitor1.inviteesId == target.id){
                logger.warn("挑战侠士邀请援助，但是目标在1号邀请位中");
                heroFightModule
                        .sendMessage(ERR_INVITE_HERO_FAIL_TARGET_IN_INVITE_LIST);
                return;
            }
        }

        if (invitor2 != null){
            if (invitor2.inviteesId == target.id){
                logger.warn("挑战侠士邀请援助，但是目标在2号邀请位中");
                heroFightModule
                        .sendMessage(ERR_INVITE_HERO_FAIL_TARGET_IN_INVITE_LIST);
                return;
            }
        }

        if (invitor1 != null && invitor2 != null){
            logger.warn("挑战侠士邀请援助，但是英雄已经邀请了2个人了");
            heroFightModule.sendMessage(ERR_INVITE_HERO_FAIL_INVITE_COUNT_FULL);
            return;
        }

        // 同意了其他人的邀请
        if (target.hasAgreeInvite()){
            logger.warn("挑战侠士邀请援助，但是英雄已经同意了其他人的请求");
            heroFightModule
                    .sendMessage(ERR_INVITE_HERO_FAIL_AGREE_OTHER_INVATION);
            return;
        }

        long expireTime = ctime
                + VariableConfig.CHALLENGE_DUNGEON_INVITE_DURATION;
        Hero hero = heroFightModule.getHero();
        ChallengeDungeonAssistObject assistObject = new ChallengeDungeonAssistObject(
                expireTime, id, hero.getNameBytes(), hero.getLevel(),
                hero.getFightingAmount(), target.id, sceneData);

        // 对方cas成功后再设置自己
        if (!target.tryCasInvite(assistObject)){
            logger.warn("挑战侠士邀请援助，但是目标英雄已经有2个邀请了");
            heroFightModule
                    .sendMessage(ERR_INVITE_HERO_FAIL_INVITEES_COUNT_FULL);
            return;
        }

        if (invitor1 == null){
            invitor1 = assistObject;
        } else{
            invitor2 = assistObject;
        }

        heroFightModule.sendMessage(target.getInviteHeroMsg());
    }

    private ChannelBuffer inviteHeroMsg;

    private ChannelBuffer getInviteHeroMsg(){
        if (inviteHeroMsg == null){
            inviteHeroMsg = inviteHeroMsg(id);
        }
        return inviteHeroMsg;
    }

    private boolean hasAgreeInvite(){
        ChallengeDungeonAssistObject inviteesObj = invitees1.get();
        if (inviteesObj != null && inviteesObj.isInviteesAgree()){
            return true;
        }

        inviteesObj = invitees2.get();
        if (inviteesObj != null && inviteesObj.isInviteesAgree()){
            return true;
        }

        return false;
    }

    private boolean tryCasInvite(ChallengeDungeonAssistObject assistObject){
        return invitees1.compareAndSet(null, assistObject)
                || invitees2.compareAndSet(null, assistObject);

    }

    public void update(long ctime){

        // 邀请者
        if (updateInvitor(invitor1, ctime)){
            invitor1 = null;
        }

        if (updateInvitor(invitor2, ctime)){
            invitor2 = null;
        }

        // 被邀请者
        ChallengeDungeonAssistObject object = invitees1.get();
        if (updateInvitees(object, ctime)){
            invitees1.compareAndSet(object, null);
        }

        object = invitees2.get();
        if (updateInvitees(object, ctime)){
            invitees2.compareAndSet(object, null);
        }
    }

    // 返回true，外面将invitor设置为null
    public boolean updateInvitor(ChallengeDungeonAssistObject invitor,
            long ctime){
        if (invitor == null)
            return false;

        if (invitor.exipreTime < ctime){
            // 已过期，发消息
            heroFightModule.sendMessage(invitationExpiredMsg(true,
                    invitor.inviteesId));
            return true;
        }

        // 被邀请者有改变
        if (invitor.inviteesHasChange){
            invitor.inviteesHasChange = false;

            switch (invitor.inviteesState){
                case INVITEES_REJECT:{
                    // 拒绝，发消息
                    heroFightModule
                            .sendMessage(otherRejectInvitation(invitor.inviteesId));
                    return true;
                }
                case INVITEES_AGREE:{
                    // 接受，发消息
                    heroFightModule
                            .sendMessage(otherAgreeInvitation(invitor.inviteesId));
                    return false;
                }
            }
        }

        return false;
    }

    // 返回true，外面将invitees设置为null
    public boolean updateInvitees(ChallengeDungeonAssistObject invitees,
            long ctime){
        if (invitees == null)
            return false;

        if (invitees.exipreTime < ctime){
            // 已过期
            heroFightModule.sendMessage(invitationExpiredMsg(false,
                    invitees.invitorId));
            return true;
        }

        // 被邀请者有改变
        if (invitees.invitorHasChange){
            invitees.invitorHasChange = false;

            switch (invitees.invitorState){
                case INVITOR_WAIT:{
                    // 邀请中
                    if (!canAssistOther(invitees)){
                        // 不能援助
                        invitees.onInviteesReject();
                        return true;
                    }

                    heroFightModule.sendMessage(otherInviteSelf(
                            invitees.getSequence(), invitees.invitorId,
                            invitees.name, invitees.level,
                            invitees.fightingAmount));
                    return false;
                }
                case INVITOR_CANCEL:{
                    // 取消邀请，发消息
                    heroFightModule
                            .sendMessage(otherCancelInvitation(invitees.invitorId));
                    return true;
                }
                case INVITOR_ENTER_DUNGEON:{
                    // 已经进入场景，英雄状态允许的情况下，传入副本，发消息
                    if (!canAssistOther(invitees)){
                        logger.error("要求英雄传入挑战侠士援助场景时，发现英雄突然不能援助了，神马情况");
                        heroFightModule
                                .sendMessage(otherCancelInvitation(invitees.invitorId));
                        return true;
                    }

                    // 看下副本能不能找到
                    AbstractDungeonScene scene = heroFightModule.getServices()
                            .getSceneService().getDungeon(invitees.dungeonId);

                    if (!(scene instanceof ChallengeDungeonScene)){
                        logger.error("要求英雄传入挑战侠士援助场景时，dungon不存在或者不是挑战侠士副本");
                        heroFightModule
                                .sendMessage(otherCancelInvitation(invitees.invitorId));
                        return true;
                    }

                    // 传入场景
                    heroFightModule.doChangeScene(scene, scene.getSceneData()
                            .getDefaultX(), scene.getSceneData().getDefaultY(),
                            TransportType.ENTER_DUNGEON);

                    return true;
                }
            }
        }

        return false;
    }

    private boolean canAssistOther(ChallengeDungeonAssistObject invitees){
        Hero hero = heroFightModule.getHero();

        // 援助次数
        if (hero.getChallengeDungeonAssistTimes() >= config.CHALLENGE_DUNGEON_ASSIST_MAX_TIMES){
            return false;
        }

        // 通关副本
        if (hero.getFinishedChallengeDungeonSequence() < invitees.getSequence()){
            return false;
        }

        // 副本，活动场景
        if (!heroFightModule.isInAndEnteredNormalScene()){
            return false;
        }

        return true;
    }

    public void checkBug(){
        if (invitor1 != null && invitor1.invitorId != id){
            logger.error("BUG!!! 英雄的副本请求援助中, invitor1.invitorId != id");
        }

        if (invitor2 != null && invitor2.invitorId != id){
            logger.error("BUG!!! 英雄的副本请求援助中, invitor2.invitorId != id");
        }

        ChallengeDungeonAssistObject invitees1Obj = invitees1.get();
        if (invitees1Obj != null && invitees1Obj != OBJECT
                && invitees1Obj.inviteesId != id){
            logger.error("BUG!!! 英雄的副本被请求援助中, invitees1Obj.inviteesId != id");
        }

        ChallengeDungeonAssistObject invitees2Obj = invitees2.get();
        if (invitees2Obj != null && invitees1Obj != OBJECT
                && invitees2Obj.inviteesId != id){
            logger.error("BUG!!! 英雄的副本被请求援助中, invitees2Obj.inviteesId != id");
        }
    }

    private static final int INVITOR_WAIT = 0;

    private static final int INVITOR_CANCEL = 1;

    private static final int INVITOR_ENTER_DUNGEON = 2;

    private static final int INVITEES_REJECT = 1;

    private static final int INVITEES_AGREE = 2;

    public static class ChallengeDungeonAssistObject{

        // 过期时间，只要过了这个时间，邀请者或者被邀请者都移除这个对象
        private final long exipreTime;

        // 邀请者数据，只要邀请者会写，被邀请者会读
        private final long invitorId;

        private final byte[] name;

        private final int level;

        private final int fightingAmount;

        public final ChallengeDungeonSceneData sceneData;

        // 邀请者设置成true，被邀请者设置成false
        private volatile boolean invitorHasChange;

        // 邀请者状态 0-邀请中 1-取消邀请 2-进入场景
        private int invitorState;

        // 副本id
        private int dungeonId;

        // ------------------------

        // 被邀请者数据，只有被邀请者会写，邀请者会读
        public final long inviteesId;

        // 被邀请者设置成true，邀请者设置成false
        private volatile boolean inviteesHasChange;

        // state 1-拒绝邀请 2-接受邀请
        private int inviteesState;

        ChallengeDungeonAssistObject(long exipreTime, long invitorId,
                byte[] name, int level, int fightingAmount, long inviteesId,
                ChallengeDungeonSceneData sceneData){
            this.exipreTime = exipreTime;
            this.invitorId = invitorId;
            this.name = name;
            this.level = level;
            this.fightingAmount = fightingAmount;
            this.inviteesId = inviteesId;
            this.sceneData = sceneData;

            invitorHasChange = true;
            invitorState = INVITOR_WAIT; // 邀请中
        }

        public boolean isInviteesAgree(){
            return inviteesState == INVITEES_AGREE;
        }

        private int getSequence(){
            return sceneData.sequence;
        }

        private void onInvitorCancel(){
            invitorState = INVITOR_CANCEL;
            invitorHasChange = true;
        }

        public void onInvitorEnterDungeon(int dungeonId){
            this.dungeonId = dungeonId;
            invitorState = INVITOR_ENTER_DUNGEON;
            invitorHasChange = true;
        }

        private void onInviteesAgree(){
            inviteesState = INVITEES_AGREE;
            inviteesHasChange = true;
        }

        private void onInviteesReject(){
            inviteesState = INVITEES_REJECT;
            inviteesHasChange = true;
        }
    }

}
