package app.game.data.welfare;

import java.util.List;

import app.game.data.GameObjects;
import app.game.data.PrizeConfigs;

import com.google.inject.Inject;
import com.mokylin.collection.IntHashMap;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class PlatformOneTimesPrizeDatas{

    private static final String LOCATION = "config/data/platform/platform_one_times_prize.txt";

    private final IntHashMap<PlatformOneTimesPrizeData> dataMap;

    private final PlatformOneTimesPrizeData[] datas;

    @Inject
    PlatformOneTimesPrizeDatas(GameObjects go, PrizeConfigs prizes){
        List<ObjectParser> data = go.loadFile(LOCATION);

        dataMap = new IntHashMap<>();

        for (ObjectParser p : data){
            PlatformOneTimesPrizeData d = new PlatformOneTimesPrizeData(p,
                    prizes);
            dataMap.putUnique(d.id, d);
        }

        datas = dataMap.values().toArray(new PlatformOneTimesPrizeData[0]);
    }

    public PlatformOneTimesPrizeData get(int id){
        return dataMap.get(id);
    }

    public PlatformOneTimesPrizeData[] getDatas(){
        return datas;
    }
}
