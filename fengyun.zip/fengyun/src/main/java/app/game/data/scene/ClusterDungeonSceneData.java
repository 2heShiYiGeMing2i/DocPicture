package app.game.data.scene;

import app.cluster.client.combat.scene.LocalDungeonScene;
import app.cluster.combat.master.logic.scene.AbstractRemoteDungeon;
import app.game.data.GameObjects;
import app.game.module.scene.IClusterLocalDungeonService;
import app.game.module.scene.IDungeonService;
import app.message.ISender;

import com.mokylin.sink.util.parse.ObjectParser;

public abstract class ClusterDungeonSceneData extends DungeonSceneData{

    protected ClusterDungeonSceneData(GameObjects go, ObjectParser p,
            BlockInfos blocks, MonsterDatas monsters, Scripts scripts,
            Plunders plunders, Ais ais, SceneTransportDatas transports,
            SceneRemoveObjectMsgCache removeMsgCache){
        super(go, p, blocks, monsters, scripts, plunders, ais, transports,
                removeMsgCache);
    }

    public abstract LocalDungeonScene newLocalClusterScene(int uuid,
            IClusterLocalDungeonService dungeonService, ISender combatClient,
            long heroID);

    public abstract AbstractRemoteDungeon newRemoteClusterScene(int uuid,
            IDungeonService dungeonService, long creator, ISender worker);

}
