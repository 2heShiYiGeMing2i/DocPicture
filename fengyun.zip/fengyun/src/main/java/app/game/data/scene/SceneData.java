package app.game.data.scene;

import static com.mokylin.sink.util.Preconditions.*;

import java.util.Collection;
import java.util.List;

import org.jboss.netty.buffer.ChannelBuffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.data.GameObject;
import app.game.data.GameObjects;
import app.game.data.TimeData;
import app.game.data.scene.MonsterGroupWithTimeData.MonsterGroupWithTimeDataInstance;
import app.game.module.scene.AbstractHeroFightModule.PkMode;
import app.game.module.scene.AbstractMonsterFightModule;
import app.game.module.scene.IScene;
import app.game.module.scene.MonsterFightModule;
import app.game.module.scene.SceneMessages;
import app.game.service.TimeService;

import com.google.common.collect.HashMultimap;
import com.google.common.collect.Lists;
import com.google.common.collect.Multimap;
import com.mokylin.collection.ConcurrentNoOrderArrayList;
import com.mokylin.collection.IntArrayList;
import com.mokylin.sink.util.RandomNumber;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.parse.ObjectParser;

public abstract class SceneData extends GameObject{
    private static final Logger logger = LoggerFactory
            .getLogger(SceneData.class);

    public static final int TRANSPORT_DIFF_LEVEL = 10;

    private final int startX;
    private final int startY;
    private final int endX;
    private final int endY;

    public final boolean isHeroLevelProtect;
    public final boolean isNewHeroProtect;
    public final boolean isDeathProtect;
    public final boolean isNightAutoProtect;
    public final boolean isJumpLimit;
    public final boolean isMountLimit;

    /**
     * 是否不准原地死亡复活
     */
    public final boolean isReliveLimit;

    public final int deathReturnX;
    public final int deathReturnY;
    public final int deathReturnRandomRange;

    public final String blockName;
    public final JumpDestinationCalculator jumpDestinationCalculator;

    /**
     * 进入场景时显示的装b诗
     */
    public final String poet;

    public final BlockInfo blockInfo;
    public final ChannelBuffer changeToThisSceneMessage;

    /**
     * 能复活的怪. 在DungeonSceneData中限制副本中不能有
     */
    private final SceneMonsterData[] reliveMonsterData;
    private final SceneMonsterData[] singleLifeMonsterData;

    /**
     * 固定时间刷新的怪, 在初始化时限制副本中不能有
     */
    protected final MonsterGroupWithTimeData[] monsterWithTime;

    private final int reliveMonsterDataLength;

    protected final int[] defaultRandomPoints;

    protected final int defaultRandomPointCount;

    protected final int maxUseMonsterID;

    /**
     * 场景默认PK模式
     */
    protected final PkMode fixedPkMode;

    protected final String sound;

    SceneData(GameObjects go, ObjectParser p, BlockInfos blocks,
            MonsterDatas monsters, Scripts scripts, Plunders plunders, Ais ais,
            SceneTransportDatas transports,
            SceneRemoveObjectMsgCache removeMsgCache){
        super(p);

        checkArgument(id > 0 && id <= 1023, "场景id必须在1-1023之间: %s-%s", id, name); // SceneService中使用最后10位来存场景id

        sound = p.getKey("sound", "");

        blockName = p.getKey("map_name");
        blockInfo = checkNotNull(blocks.get(blockName),
                "没有找到场景 %s 的地图block文件 %s", name, blockName);

        poet = p.getKey("poet");

        int intPkMode = p.getIntKey("fixed_pk_mode");
        if (intPkMode > 0){
            fixedPkMode = checkNotNull(PkMode.valueOf(intPkMode),
                    "场景%s-%s配置的固定PK模式不存在，pkMode：%s", id, name, intPkMode);
        } else{
            fixedPkMode = null;
        }

        // 地图起始/结束坐标暂时不配置
        // startX = p.getIntKey("start_x");
        // startY = p.getIntKey("start_y");
        // endX = p.getIntKey("end_x");
        // endY = p.getIntKey("end_y");
        startX = 0;
        startY = 0;
        endX = blockInfo.numBlocksX;
        endY = blockInfo.numBlocksY;

        checkArgument(endX > startX);
        checkArgument(endY > startY);
        checkArgument(startX >= 0);
        checkArgument(startY >= 0);

        isHeroLevelProtect = p.getBooleanKey("is_hero_level_protect");
        isNewHeroProtect = p.getBooleanKey("is_new_hero_protect");
        isDeathProtect = p.getBooleanKey("is_death_protect");
        isNightAutoProtect = p.getBooleanKey("is_night_auto_protect");
        isJumpLimit = p.getBooleanKey("is_jump_limit");
        isMountLimit = p.getBooleanKey("is_mount_limit");
        isReliveLimit = p.getBooleanKey("is_relive_limit");

        deathReturnX = p.getIntKey("death_return_x");
        deathReturnY = p.getIntKey("death_return_y");
        deathReturnRandomRange = p.getIntKey("death_return_random_range");

        // 跳跃坐标计算器
        jumpDestinationCalculator = new JumpDestinationCalculator(blockInfo,
                startX, startY, endX, endY);
        // 切线过来的消息
        changeToThisSceneMessage = SceneMessages.changeScene(id);

        // 地图随机传送点
        IntArrayList randomPoints = new IntArrayList();
        for (int i = 0; i < 50; i++){
            int x = RandomNumber.getRate(blockInfo.numBlocksX, true);
            int y = RandomNumber.getRate(blockInfo.numBlocksY, true);

            if (blockInfo.isWalkable(x, y)
                    && !randomPoints.contains(Utils.short2Int(x, y))){
                randomPoints.add(Utils.short2Int(x, y));

                if (randomPoints.size() >= 5){
                    break;
                }
            }
        }

        if (randomPoints.isEmpty()){
            // 从头扫描一遍，找几个随机点

            for (int x = 0; x < blockInfo.numBlocksX; x++){
                for (int y = 0; y < blockInfo.numBlocksY; y++){
                    if (blockInfo.isWalkable(x, y)){
                        randomPoints.add(Utils.short2Int(x, y));

                        if (randomPoints.size() >= 5){
                            break;
                        }
                    }
                }
            }
        }

        checkArgument(!randomPoints.isEmpty(), "场景%s中一个可行走点都没找到，怎么个情况?", this);

        defaultRandomPoints = randomPoints.toArray();
        defaultRandomPointCount = defaultRandomPoints.length;

        // --------------------- 加载怪物 ---------------------

        String monsterLocation = GameObjects.SCENE_BASE_FOLDER + "mon/" + id
                + ".txt";
        List<ObjectParser> monsterGroupDataList = go.loadFile(monsterLocation);
        List<SceneMonsterData> reliveMonsterList = Lists.newArrayList();
        List<SceneMonsterData> singleLifeMonsterList = Lists.newArrayList();
        int monsterIDCounter = 0;

        Multimap<TimeData, SceneMonsterData> monsterWithTime = null; // 固定时间刷的怪
        for (ObjectParser monGroupParser : monsterGroupDataList){
            MonsterGroupData groupData = new MonsterGroupData(monGroupParser,
                    monsters, plunders, ais, blockInfo);

            int[] poses = groupData.getPos();

            groupData.monster.setScene(this, poses);

            for (int pos : poses){
                SceneMonsterData mon = new SceneMonsterData(++monsterIDCounter,
                        id, groupData, Utils.getHighShort(pos),
                        Utils.getLowShort(pos), removeMsgCache);

                if (groupData.timeData != null){
                    assert mon.getAi().isSingleLife;

                    if (monsterWithTime == null){
                        monsterWithTime = HashMultimap.create();
                    }

                    monsterWithTime.put(groupData.timeData, mon);
                } else{
                    if (mon.getAi().isSingleLife){
                        singleLifeMonsterList.add(mon);
                    } else{
                        reliveMonsterList.add(mon);
                    }
                }
            }
        }

        this.reliveMonsterData = reliveMonsterList
                .toArray(SceneMonsterData.EMPTY_ARRAY);
        this.singleLifeMonsterData = singleLifeMonsterList
                .toArray(SceneMonsterData.EMPTY_ARRAY);

        this.reliveMonsterDataLength = this.reliveMonsterData.length;

        if (reliveMonsterDataLength > 0){
            checkArgument(canHaveRelivableMonster(), "%s 内不能有能复活的怪物", this);
        }

        // 初始化有固定时间刷新的怪, 相同时间的都放在同一个MonsterGroupWithTimeData里
        if (monsterWithTime == null){
            this.monsterWithTime = MonsterGroupWithTimeData.EMPTY_ARRAY;
        } else{
            checkArgument(canHaveMonsterWithTime(), "%s 内不能有固定时间刷新的怪物", this);

            List<MonsterGroupWithTimeData> monGroupList = Lists.newArrayList();

            for (TimeData timeData : monsterWithTime.keySet()){
                Collection<SceneMonsterData> mons = monsterWithTime
                        .get(timeData);
                SceneMonsterData[] sceneMons = mons
                        .toArray(SceneMonsterData.EMPTY_ARRAY);
                monGroupList.add(new MonsterGroupWithTimeData(timeData,
                        sceneMons));
            }

            this.monsterWithTime = monGroupList
                    .toArray(MonsterGroupWithTimeData.EMPTY_ARRAY);
        }

        this.maxUseMonsterID = monsterIDCounter;
    }

    public abstract int getCanEnterLevel();

    public abstract boolean isNormalScene();

    public abstract int getIntType();

    /**
     * 是否能有固定时间刷新的怪物
     * 副本只有火麟洞可以有
     * @return
     */
    protected abstract boolean canHaveMonsterWithTime();

    /**
     * 是否能有能重生的怪物
     * 副本只有火麟洞可以有
     * @return
     */
    protected abstract boolean canHaveRelivableMonster();

    /**
     * 守护龙脉和守护孔慈重写此方法
     * @return
     */
    public int getMaxUsedMonsterID(){
        return maxUseMonsterID;
    }

    protected boolean hasRelivableMonster(){
        return reliveMonsterDataLength > 0;
    }

    protected boolean hasSingleLifeMonster(){
        return singleLifeMonsterData.length > 0;
    }

    public MonsterGroupWithTimeData[] getMonsterWithTimes(){
        return monsterWithTime;
    }

    protected SceneMonsterData[] getSingleLifeMonsterDatas(){
        return singleLifeMonsterData;
    }

    protected SceneMonsterData getSingleLifeMonsterByName(String name){
        for (SceneMonsterData mon : singleLifeMonsterData){
            if (name.equals(mon.getMonsterData().name)){
                return mon;
            }
        }
        return null;
    }

    public PkMode getFixedPkMode(){
        return fixedPkMode;
    }

    /**
     * 新建个不可重生, 只有一条命的怪物的列表
     * @param parent
     * @return
     */
    public ConcurrentNoOrderArrayList<AbstractMonsterFightModule> newSingleLifeMonsterFightModules(
            IScene parent){
        ConcurrentNoOrderArrayList<AbstractMonsterFightModule> result = new ConcurrentNoOrderArrayList<>(
                singleLifeMonsterData.length);

        Object positionModuleSharedSync = parent.getPositionModuleSharedSync();
        for (SceneMonsterData data : singleLifeMonsterData){
            result.add(new MonsterFightModule(newSingleLifeMonsterData(data,
                    parent), parent, null, positionModuleSharedSync));
        }
        return result;
    }

    /**
     * 获取真正要使用的SceneMonsterData. 凌云窟重写了此方法, 根据场景的等级决定怪物的等级
     * @param sceneMonsterData
     * @param parent
     * @return
     */
    protected SceneMonsterData newSingleLifeMonsterData(
            SceneMonsterData sceneMonsterData, IScene parent){
        return sceneMonsterData;
    }

    /**
     * 新建个可重生的怪物列表
     * @param parent
     * @return
     */
    public MonsterFightModule[] newReliveMonsterFightModules(IScene parent){
        if (reliveMonsterDataLength == 0){
            return MonsterFightModule.EMPTY_ARRAY;
        }
        Object positionModuleSharedSync = parent.getPositionModuleSharedSync();

        MonsterFightModule[] result = new MonsterFightModule[reliveMonsterDataLength];
        for (int i = reliveMonsterDataLength; --i >= 0;){
            result[i] = new MonsterFightModule(reliveMonsterData[i], parent,
                    null, positionModuleSharedSync);
        }
        return result;
    }

    public MonsterGroupWithTimeDataInstance[] newSingleLifeMonsterWithTime(
            TimeService timeService, IScene parent){
        if (monsterWithTime.length == 0){
            return MonsterGroupWithTimeData.EMPTY_INSTANCE_ARRAY;
        }
        long ctime = timeService.getCurrentTime();
        MonsterGroupWithTimeDataInstance[] result = new MonsterGroupWithTimeDataInstance[monsterWithTime.length];
        for (int i = monsterWithTime.length; --i >= 0;){
            result[i] = monsterWithTime[i].newInstance(ctime, parent);
        }
        return result;
    }

    public int getStartX(){
        return startX;
    }

    public int getStartY(){
        return startY;
    }

    public int getEndX(){
        return endX;
    }

    public int getEndY(){
        return endY;
    }

    public int getRandomPoint(){
        int x = RandomNumber.getRate(blockInfo.numBlocksX, true);
        int y = RandomNumber.getRate(blockInfo.numBlocksY, true);

        if (blockInfo.isWalkable(x, y)){
            return Utils.short2Int(x, y);
        }

        for (int i = 0; i < 3; i++){
            x = RandomNumber.getRate(blockInfo.numBlocksX, true);
            y = RandomNumber.getRate(blockInfo.numBlocksY, true);

            if (blockInfo.isWalkable(x, y)){
                return Utils.short2Int(x, y);
            }
        }

        return defaultRandomPoints[RandomNumber.getRate(
                defaultRandomPointCount, true)];
    }

    /**
     * 是否全场景视野. 组队副本重写
     * @return
     */
    public boolean isSeeAllInScene(){
        return false;
    }

    @Override
    public String toString(){
        return id + "-" + name;
    }
}
