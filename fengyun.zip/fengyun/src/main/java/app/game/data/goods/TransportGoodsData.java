/**
 * 
 */
package app.game.data.goods;

import static app.game.module.GoodsContainerMessages.*;
import static com.mokylin.sink.util.Preconditions.*;
import app.game.data.GameObjects;
import app.game.data.scene.NormalSceneData;
import app.game.data.scene.NormalSceneDatas;
import app.game.data.scene.SceneData;
import app.game.data.scene.TransportData;
import app.game.module.scene.HeroFightModule;
import app.game.service.Services;
import app.message.ISender;
import app.protobuf.GoodsContent.TransportationDataProto;
import app.protobuf.GoodsServerContent.GoodsType;
import app.protobuf.LogContent.LogEnum.TransportType;

import com.google.protobuf.ByteString;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * 传送卷轴
 * 
 * @author Liwei
 * 
 */
public class TransportGoodsData extends GoodsData{

    static final String LOCATION = GameObjects.GOODS_BASE_LOCATION
            + "transportation.txt";

    /**
     * 1为回城卷;2为随即传送卷; 3为地图定点传送卷；4为行会回城卷
     */
    final TransortType transType;

    private final int destSceneID;

    private final int destX;

    private final int destY;

    private final int randomDistance;

    TransportData destData;

    private final TransportationDataProto proto;

    private final byte[] protoBytes;

    private final ByteString protoByteString;

    private final Efficacy efficacy;

    TransportGoodsData(ObjectParser p){
        super(p, GoodsType.TRANSPORTATION);

        int intTransType = p.getIntKey("trans_type");
        transType = checkNotNull(
                TransortType.valueOf(intTransType),
                "物品%s-%s 的传送类型错误（1为回城卷;2为随即传送卷; 3为地图定点传送卷；4为行会回城卷），transType: %s",
                id, name, intTransType);

        destSceneID = p.getIntKey("dest_scene_id");
        destX = p.getIntKey("dest_x");
        destY = p.getIntKey("dest_y");
        randomDistance = p.getIntKey("random_distance");

        if (transType == TransortType.CITY || transType == TransortType.RANDOM){
            checkArgument(destSceneID == 0, "%s 回城卷轴和随机传送卷轴都不要配置传送场景", this);
        }

        efficacy = transType.createEfficacy(this);

        proto = build();
        protoBytes = processProtoBytes(proto.toByteArray());
        protoByteString = ByteString.copyFrom(protoBytes);
    }

    void initDestData(NormalSceneDatas sceneDatas){
        if (transType == TransortType.FIXED
                || transType == TransortType.WU_SHUANG){
            NormalSceneData sceneData = checkNotNull(
                    sceneDatas.get(destSceneID),
                    "物品%s-%s 没找到传送目的地场景，destSceneID：%s", id, destSceneID);

            destData = TransportData.newTransportData(sceneData, destX, destY,
                    randomDistance);

            checkArgument(
                    requireLevel >= destData.requiredLevel,
                    "传送卷轴%s-%s 的使用等级比场景传送所需等级小，会导致英雄传入等级不够的地图，场景需求等级：%s 卷轴使用等级：%s",
                    id, name, destData.requiredLevel, requireLevel);
        }
    }

    private TransportationDataProto build(){
        TransportationDataProto.Builder builder = TransportationDataProto
                .newBuilder();
        builder.setBaseData(encode());
        builder.setTransType(transType.getIntType());

        return builder.build();
    }

    public TransportationDataProto getProto(){
        return proto;
    }

    @Override
    public byte[] getProtoBytes(){
        return protoBytes;
    }

    @Override
    public ByteString getProtoByteString(){
        return protoByteString;
    }

    @Override
    public int getAuctionType(){
        return 123;
    }

    @Override
    public Efficacy getEfficacy(){
        return efficacy;
    }

    static enum TransortType{
        CITY(1) {
            @Override
            Efficacy createEfficacy(TransportGoodsData data){
                return CityTransportEfficacy.efficacy;
            }
        },
        RANDOM(2) {
            @Override
            Efficacy createEfficacy(TransportGoodsData data){
                return RandomTransportEfficacy.efficacy;
            }
        },
        FIXED(3) {
            @Override
            Efficacy createEfficacy(TransportGoodsData data){
                return new FixedTransportEfficacy(data);
            }
        },
        WU_SHUANG(4) {
            @Override
            Efficacy createEfficacy(TransportGoodsData data){
                return new WushuangTransportEfficacy(data);
            }
        };

        private final int type;

        private TransortType(int type){
            this.type = type;
        }

        int getIntType(){
            return type;
        }

        private static TransortType valueOf(int type){
            switch (type){
                case 1:{
                    return CITY;
                }
                case 2:{
                    return RANDOM;
                }
                case 3:{
                    return FIXED;
                }
                case 4:{
                    return WU_SHUANG;
                }
            }

            return null;
        }

        abstract Efficacy createEfficacy(TransportGoodsData data);
    }

    private static class CityTransportEfficacy implements Efficacy{

        private static final CityTransportEfficacy efficacy = new CityTransportEfficacy();

        @Override
        public int useTo(HeroFightModule heroFightModule, int useCount,
                long ctime, String iEventId){
            // 回城卷轴
            ISender sender = heroFightModule.getSender();

            // 红名不能使用传送卷轴
            if (heroFightModule.getHero().isRedName()){
                logger.warn("使用回城卷轴，英雄是红名");
                sender.sendMessage(ERR_USE_TP_FAIL);
                return 0;
            }

            SceneData parentScene = heroFightModule.getParentSceneData();
            if (!heroFightModule.hasEnteredScene() || parentScene == null){
                logger.warn("使用回城卷轴，找不到英雄当前所在的场景");
                sender.sendMessage(ERR_USE_TP_FAIL);
                return 0;
            }

            Services services = heroFightModule.getServices();
            if (services.getModules().getGuildModule()
                    .isInBattle(heroFightModule.getServerData())){
                logger.warn("使用回城卷轴，当前是城战期间");
                sender.sendMessage(ERR_USE_TP_FAIL_BATTLE);
                return 0;
            }

            if (parentScene.isNormalScene()){
                NormalSceneData normalParentScene = (NormalSceneData) parentScene;
                NormalSceneData destSceneData = normalParentScene
                        .getDeathSceneData();
                int destPos = normalParentScene.getRandomDeathReturnPoint();

                heroFightModule.transportHero(destSceneData,
                        Utils.getHighShort(destPos),
                        Utils.getLowShort(destPos), TransportType.TP_GOODS);
            } else{
                // 在副本里, 传到进副本前位置
                heroFightModule.doLeaveDungeon();
            }
            return 1;
        }
    }

    private static class RandomTransportEfficacy implements Efficacy{

        private static final RandomTransportEfficacy efficacy = new RandomTransportEfficacy();

        @Override
        public int useTo(HeroFightModule heroFightModule, int useCount,
                long ctime, String iEventId){
            // 随机传送卷轴
            ISender sender = heroFightModule.getSender();

            // 红名不能使用传送卷轴
            if (heroFightModule.getHero().isRedName()){
                logger.warn("使用随机传送卷轴，英雄是红名");
                sender.sendMessage(ERR_USE_TP_FAIL);
                return 0;
            }

            // 随机传送卷轴
            SceneData parentScene = heroFightModule.getParentSceneData();
            if (parentScene == null){
                logger.warn("使用随机传送卷轴，找不到英雄当前所在的场景");
                sender.sendMessage(ERR_USE_TP_FAIL);
                return 0;
            }

            if (!heroFightModule.hasEnteredScene()
                    || !parentScene.isNormalScene()){
                logger.warn("使用随机传送卷轴，英雄不在普通场景");
                sender.sendMessage(ERR_USE_TP_FAIL);
                return 0;
            }

            Services services = heroFightModule.getServices();
            if (services.getModules().getGuildModule()
                    .isInBattle(heroFightModule.getServerData())){
                logger.warn("使用随机传送卷轴，当前是城战期间");
                sender.sendMessage(ERR_USE_TP_FAIL_BATTLE);
                return 0;
            }

            int destPos = parentScene.getRandomPoint();

            heroFightModule.transportHero((NormalSceneData) parentScene,
                    Utils.getHighShort(destPos), Utils.getLowShort(destPos),
                    TransportType.TP_GOODS);

            return 1;
        }
    }

    private static class FixedTransportEfficacy implements Efficacy{

        private final TransportGoodsData data;

        FixedTransportEfficacy(TransportGoodsData data){
            this.data = data;
        }

        @Override
        public int useTo(HeroFightModule heroFightModule, int useCount,
                long ctime, String iEventId){
            // 固定点传送卷轴
            ISender sender = heroFightModule.getSender();

            // 红名不能使用传送卷轴
            if (heroFightModule.getHero().isRedName()){
                logger.warn("使用回城卷轴，英雄是红名");
                sender.sendMessage(ERR_USE_TP_FAIL);
                return 0;
            }

            TransportData transportData = data.destData;
            if (transportData == null){
                logger.warn("使用定点传送卷轴，没有找到transportData");
                sender.sendMessage(ERR_USE_TP_FAIL);
                return 0;
            }

            if (!heroFightModule.isInAndEnteredNormalScene()){
                logger.warn("使用定点传送卷轴，英雄在个副本里: {}",
                        heroFightModule.getParentSceneData());
                sender.sendMessage(ERR_USE_TP_FAIL);
                return 0;
            }

            NormalSceneData destSceneData = transportData.getSceneData();
            if (heroFightModule.getHero().getLevel() < destSceneData
                    .getCanEnterLevel()){
                logger.warn("使用定点传送卷轴，英雄等级不足");
                sender.sendMessage(ERR_USE_TP_FAIL_LEVEL_NOT_ENOUGH);
                return 0;
            }

            Services services = heroFightModule.getServices();
            if (services.getModules().getGuildModule()
                    .isInBattle(heroFightModule.getServerData())){
                logger.warn("使用定点传送卷轴，当前是城战期间");
                sender.sendMessage(ERR_USE_TP_FAIL_BATTLE);
                return 0;
            }

            int destPos = transportData.getRandomPoint();

            heroFightModule.transportHero(destSceneData,
                    Utils.getHighShort(destPos), Utils.getLowShort(destPos),
                    TransportType.TP_GOODS);

            return 1;
        }
    }

    private static class WushuangTransportEfficacy implements Efficacy{

        private final TransportGoodsData data;

        WushuangTransportEfficacy(TransportGoodsData data){
            this.data = data;
        }

        @Override
        public int useTo(HeroFightModule heroFightModule, int useCount,
                long ctime, String iEventId){

            // 红名不能使用传送卷轴
            if (heroFightModule.getHero().isRedName()){
                logger.warn("使用无双城行会传送卷轴，英雄是红名");
                heroFightModule.sendMessage(ERR_USE_TP_FAIL);
                return 0;
            }

            if (!heroFightModule.isWsCityMaster()){
                logger.warn("使用无双城行会传送卷轴，当前帮派不是占领帮派");
                heroFightModule.sendMessage(ERR_USE_TP_FAIL_NOT_CITY_MASTER);
                return 0;
            }

            if (!heroFightModule.isInAndEnteredNormalScene()){
                logger.warn("使用无双城行会传送卷轴，英雄不在普通场景");
                heroFightModule.sendMessage(ERR_USE_TP_FAIL);
                return 0;
            }

            TransportData transportData = data.destData;
            if (transportData == null){
                logger.warn("使用无双城行会传送卷轴，没有找到transportData");
                heroFightModule.sendMessage(ERR_USE_TP_FAIL);
                return 0;
            }

            NormalSceneData destSceneData = transportData.getSceneData();
            if (heroFightModule.getHero().getLevel() < destSceneData
                    .getCanEnterLevel()){
                logger.warn("使用无双城行会传送卷轴，英雄等级不足");
                heroFightModule.sendMessage(ERR_USE_TP_FAIL_LEVEL_NOT_ENOUGH);
                return 0;
            }

            Services services = heroFightModule.getServices();
            if (services.getModules().getGuildModule()
                    .isInBattle(heroFightModule.getServerData())){
                logger.warn("使用无双城行会传送卷轴，当前是城战期间");
                heroFightModule.sendMessage(ERR_USE_TP_FAIL_BATTLE);
                return 0;
            }

            int destPos = transportData.getRandomPoint();

            heroFightModule.transportHero(destSceneData,
                    Utils.getHighShort(destPos), Utils.getLowShort(destPos),
                    TransportType.TP_GOODS);

            return 1;
        }
    }
}
