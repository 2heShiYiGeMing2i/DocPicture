package app.game.data.gem;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.data.ConfigService;
import app.game.data.SingleSpriteStat;
import app.game.data.SpriteStat;
import app.game.data.SpriteStatBuilder;
import app.game.data.gem.GemData.GemExtraData;
import app.game.data.goods.GemGoodsData;
import app.game.data.goods.Goods;
import app.game.entity.Hero;
import app.game.module.scene.FightData;
import app.protobuf.HeroServerContent.GemServerProto;
import app.utils.VariableConfig;

import com.mokylin.collection.IntValueLongHashMap;
import com.mokylin.sink.util.StringEncoder;

/**
 * @author Liwei
 *
 */
public class HeroGem{

    private static final Logger logger = LoggerFactory.getLogger(HeroGem.class);

    // 宝石基础数据
    private final GemData gemData;

    private final int partCount;

    private final int slotCount;

    // 英雄镶嵌的宝石
    private final Goods[] gems;

    // 部件额外附加属性
    private final GemExtraData[] partExtraDatas;

    // 宝石总品阶
    private int gemTotalLevel;

    // 宝石总属性
    private SpriteStat totalStat;

    // 宝石总战斗力
    private int fightingAmount;

    public HeroGem(GemData gemData){
        this.gemData = gemData;

        partCount = gemData.partStats.length;
        slotCount = VariableConfig.GEM_PART_SLOT_COUNT;

        gems = new Goods[partCount * slotCount];
        partExtraDatas = new GemExtraData[partCount];

        totalStat = SpriteStat.EMPTY_STAT;
    }

    public Goods[] getGems(){
        return gems;
    }

    public int getGemTotalLevel(){
        return gemTotalLevel;
    }

    public int getFightingAmount(){
        return fightingAmount;
    }

    public SpriteStat getTotalStat(){
        return totalStat;
    }

    public int getGemMaxCount(){
        return gems.length;
    }

    public Goods getGem(int gemPos){
        return gems[gemPos];
    }

    public int setGem(int gemPos, Goods toSet){

        Goods old = gems[gemPos];
        gems[gemPos] = toSet;

        int part = gemPos / VariableConfig.GEM_PART_SLOT_COUNT;
        GemStatData statData = gemData.partStats[part];

        if (old != null && old.getData() instanceof GemGoodsData){
            int gemLevel = ((GemGoodsData) old.getData()).getGemLevel();
            gemTotalLevel -= gemLevel;

            SingleSpriteStat gemStat = statData.getSpriteStat(gemLevel);
            fightingAmount -= FightData.calculateFightingAmount(gemStat);

            totalStat = totalStat.remove(gemStat);
        }

        int newGemLevel = 0;
        if (toSet != null && toSet.getData() instanceof GemGoodsData){
            newGemLevel = ((GemGoodsData) toSet.getData()).getGemLevel();
            gemTotalLevel += newGemLevel;

            SingleSpriteStat gemStat = statData.getSpriteStat(newGemLevel);
            fightingAmount += FightData.calculateFightingAmount(gemStat);

            totalStat = totalStat.add(gemStat);

            // 看一下有没有特殊属性加成
            checkExtraStat(part);
        } else{
            // 看一下原来有没有特殊属性，如果有，移除特殊属性
            replacePartExtraData(part, null);
        }

        return newGemLevel;
    }

    public GemExtraData getExtraData(int part){
        return partExtraDatas[part];
    }

    private GemExtraData checkExtraStat(int part){

        int startPos = part * VariableConfig.GEM_PART_SLOT_COUNT;
        int endPos = startPos + VariableConfig.GEM_PART_SLOT_COUNT;

        int minLevel = 0;
        for (int i = startPos; i < endPos; i++){
            Goods g = gems[i];
            if (g == null || !(g.getData() instanceof GemGoodsData)){
                minLevel = 0;
                break;
            }

            minLevel = Math.min(minLevel,
                    ((GemGoodsData) g.getData()).getGemLevel());
        }

        GemExtraData newStat = gemData.getExtraData(minLevel);
        replacePartExtraData(part, newStat);

        return newStat;
    }

    private void replacePartExtraData(int part, GemExtraData newData){

        GemExtraData oldData = partExtraDatas[part];
        if (oldData == newData)
            return;

        partExtraDatas[part] = newData;

        if (newData == null){
            // 看下有没有要移除的
            if (oldData != null){
                totalStat = totalStat.remove(oldData.totalStat);
                fightingAmount -= oldData.fightingAmount;
            }
        } else{
            if (oldData == null){
                totalStat = totalStat.add(newData.totalStat);
                fightingAmount += newData.fightingAmount;
            } else{
                // 属性变化
                totalStat = totalStat.add(newData.getDiffStat(oldData.type));
                fightingAmount += newData.fightingAmount
                        - oldData.fightingAmount;
            }
        }
    }

    private void init(){

        SpriteStatBuilder builder = SpriteStatBuilder.newBuilder();

        for (int p = 0; p < partCount; p++){

            GemStatData statData = gemData.partStats[p];

            int partMinLevel = Integer.MAX_VALUE;
            for (int s = 0; s < slotCount; s++){
                int pos = p * slotCount + s;

                Goods g = gems[pos];
                if (g != null && g.getData() instanceof GemGoodsData){
                    GemGoodsData data = (GemGoodsData) g.getData();
                    int gemLevel = data.getGemLevel();

                    SingleSpriteStat gemStat = statData.getSpriteStat(gemLevel);

                    gemTotalLevel += gemLevel;
                    builder.add(gemStat);
                    fightingAmount += FightData
                            .calculateFightingAmount(gemStat);

                    partMinLevel = Math.min(partMinLevel, gemLevel);
                } else{
                    partMinLevel = 0;
                }
            }

            GemExtraData newStat = gemData.getExtraData(partMinLevel);
            if (newStat != null){
                partExtraDatas[p] = newStat;
                builder.add(newStat.totalStat);
            }
        }

        totalStat = builder.build();
    }

    public GemServerProto encode(){
        GemServerProto.Builder builder = GemServerProto.newBuilder();

        for (int i = 0; i < gems.length; i++){
            Goods g = gems[i];
            if (g != null){
                builder.addGemPos(i);
                builder.addGems(g.encode());
            }
        }

        return builder.build();
    }

    public static HeroGem decode(Hero result, GemServerProto proto,
            ConfigService configService, IntValueLongHashMap goodsCountMap){

        HeroGem heroGems = new HeroGem(configService.getGem());

        int count = Math.min(proto.getGemPosCount(), proto.getGemsCount());

        int emptyPos = 0;
        int depotStartIndex = 0;
        int storageStartIndex = 0;
        Goods[] gems = heroGems.gems;
        out: for (int i = 0; i < count; i++){
            Goods g = Goods.decode(proto.getGems(i), configService,
                    goodsCountMap);

            if (g == null)
                continue;

            int pos = proto.getGemPos(i);
            if (pos < gems.length && gems[pos] == null){
                gems[pos] = g;
                continue;
            }

            // 有错误
            for (; emptyPos < gems.length; emptyPos++){
                if (gems[emptyPos] == null){
                    gems[emptyPos] = g;
                    emptyPos++;
                    continue out;
                }
            }

            // 没有位置放，放入背包，仓库
            if (result.getDepot() != null){
                int idx = result.getDepot().addToEmptyPos(depotStartIndex, g);
                if (idx >= 0){
                    depotStartIndex = idx + 1;
                    continue;
                }

                depotStartIndex = result.getDepot().size() + 1;
            }

            if (result.getStorage() != null){
                int idx = result.getStorage().addToEmptyPos(storageStartIndex,
                        g);
                if (idx >= 0){
                    storageStartIndex = idx + 1;
                    continue;
                }

                storageStartIndex = result.getStorage().size() + 1;
            }

            // 我已经无能为力了，丢就丢了吧
            logger.error("英雄{}-{}在decode宝石的时候丢了一件宝石 {}", result.getID(),
                    StringEncoder.encode(result.getNameBytes()), g);
        }

        heroGems.init();

        return heroGems;
    }
}
