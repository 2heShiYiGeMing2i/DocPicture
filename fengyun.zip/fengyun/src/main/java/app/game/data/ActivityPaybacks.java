package app.game.data;

import static com.mokylin.sink.util.Preconditions.checkArgument;

import java.util.EnumMap;
import java.util.List;

import app.protobuf.ConfigContent.Config;
import app.protobuf.ConfigContent.DailyActivityType;

import com.google.inject.Inject;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class ActivityPaybacks{

    private static final String LOCATION = "config/data/system/activity_payback.txt";

    private final EnumMap<DailyActivityType, ActivityPayback> dataMap;

    public final int mask;

    @Inject
    ActivityPaybacks(GameObjects go, PrizeConfigs prizeConfigs){

        List<ObjectParser> list = go.loadFile(LOCATION);
        checkArgument(!list.isEmpty(), "活动买回表没有配置数据, %s", LOCATION);

        dataMap = new EnumMap<>(DailyActivityType.class);
        for (ObjectParser p : list){
            ActivityPayback data = new ActivityPayback(p, prizeConfigs);
            checkArgument(dataMap.put(data.type, data) == null, "活动买回类型重复，%s",
                    data.type);
        }

        mask = (1 << 12) - 1;
    }

    public ActivityPayback get(DailyActivityType type){
        return dataMap.get(type);
    }

    void generateProto(Config.Builder builder){

        for (ActivityPayback data : dataMap.values()){
            builder.addDailyActivity(data.encode());
        }
    }
}
