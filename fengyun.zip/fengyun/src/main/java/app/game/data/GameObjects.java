package app.game.data;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.Future;
import java.util.concurrent.FutureTask;

import app.game.service.IThreadService;

import com.google.inject.Inject;
import com.mokylin.sink.util.pack.FileLoader;
import com.mokylin.sink.util.parse.ObjectParser;
import com.mokylin.sink.util.parse.ObjectParsers;

public class GameObjects{

    public static final String SPELL_BASE_FOLDER = "config/data/spell/";

    // --- 场景 ---

    public static final String SCENE_BASE_FOLDER = "config/data/scene/";

    public static final String DEFENCE_SCENE_BASE_FOLDER = SCENE_BASE_FOLDER
            + "kongci/";

    public static final String SOU_SHEN_SCENE_BASE_FOLDER = SCENE_BASE_FOLDER
            + "soushen/";

    public static final String LING_YUN_SCENE_BASE_FOLDER = SCENE_BASE_FOLDER
            + "lingyun/";

    public static final String LONG_MAI_SCENE_BASE_FOLDER = SCENE_BASE_FOLDER
            + "longmai/";

    public static final String JI_JIAN_SCENE_BASE_FOLDER = SCENE_BASE_FOLDER
            + "jijian/";

    public static final String PORTAL_SCENE_BASE_FOLDER = SCENE_BASE_FOLDER
            + "wujue/";

    public static final String HUO_LIN_SCENE_BASE_FOLDER = SCENE_BASE_FOLDER
            + "huolin/";

    // ----
    public static final String GOODS_BASE_LOCATION = "config/data/goods/";

    public static final String SHOP_BASE_LOCATION = "config/data/shop/";

    public static final String EXCHANGE_SHOP_BASE_LOCATION = "config/data/shop/exchange/";

    public static final String TP_LIST_BASE_LOCATION = "config/data/transport_list/";

    public static final String MOUNT_BASE_FOLDER = "config/data/mount/";

    public static final String PET_BASE_FOLDER = "config/data/pet/";

    private final FileLoader loader;

    private final IThreadService threadService;

    @Inject
    public GameObjects(FileLoader loader, IThreadService threadService){
        this.loader = loader;
        this.threadService = threadService;
    }

    public FileLoader getFileLoader(){
        return loader;
    }

    public List<ObjectParser> loadFile(String location){
        return ObjectParsers.parseList(location, loader.readFile(location),
                threadService.getDbExecutor());
    }

    public void awaitExecution(Collection<Runnable> runnables){
        List<Future<Void>> futures = new ArrayList<>(runnables.size());

        int index = 0;
        for (final Runnable r : runnables){
            FutureTask<Void> t = new FutureTask<>(new Callable<Void>(){

                @Override
                public Void call() throws Exception{
                    r.run();
                    return null;
                }

            });

            futures.add(t);

            threadService.getExecutor(index++).execute(t);
        }

        for (Future<Void> f : futures){
            try{
                f.get();
            } catch (Throwable e){
                throw new RuntimeException(e);
            }
        }

        return;
    }

}
