package app.game.data.scene;

import static com.mokylin.sink.util.Preconditions.*;

import java.util.Arrays;
import java.util.List;

import app.cluster.client.combat.scene.LocalLingYunDungeonScene;
import app.cluster.combat.master.logic.scene.RemoteLingYunDungeonScene;
import app.game.data.GameObjects;
import app.game.data.PrizeConfigs;
import app.game.data.SpriteStat;
import app.game.data.SpriteStats;
import app.game.data.goods.GoodsDatas;
import app.game.entity.Hero;
import app.game.module.scene.IClusterLocalDungeonService;
import app.game.module.scene.IDungeonService;
import app.game.module.scene.IScene;
import app.message.ISender;
import app.protobuf.ConfigContent.LingYunDungeonProto;
import app.protobuf.LogContent.LogEnum.SceneType;

import com.google.protobuf.ByteString;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.parse.ObjectParser;

public class LingYunDungeonSceneData extends GroupDungeonSceneData{

    private static final String DYNAMIC_BOSS_LOCATION = GameObjects.LING_YUN_SCENE_BASE_FOLDER
            + "boss.txt";

    private final int dailyEnterLimit;

    private final GroupDungeonPrizeConfig prizeConfig;

    // --- 各层级boss属性和奖励 ---

    private final DynamicBossData[] dynamicBossDatas;

    private final int[] dynamicBossLevels;

    public final int bossSceneID;

    LingYunDungeonSceneData(GameObjects go, ObjectParser p,
            SpriteStats spriteStats, BlockInfos blocks, MonsterDatas monsters,
            Scripts scripts, Plunders plunders, Ais ais,
            SceneTransportDatas transports, GoodsDatas goodsDatas,
            PlunderGroups groups, PrizeConfigs prizes,
            SceneRemoveObjectMsgCache removeMsgCache){
        super(go, p, blocks, monsters, scripts, plunders, ais, transports,
                removeMsgCache);

        this.dailyEnterLimit = p.getIntKey("daily_enter_limit");

        checkArgument(dailyEnterLimit > 0, "凌云窟每日进入上限 daily_enter_limit必须>0");

        this.prizeConfig = new GroupDungeonPrizeConfig(this, p, prizes, groups);

        // --- 动态boss属性和掉落 ---
        SceneMonsterData bossSceneMonsterData = getOnlyBossData();

        List<ObjectParser> bossDatas = go.loadFile(DYNAMIC_BOSS_LOCATION);
        this.dynamicBossDatas = new DynamicBossData[bossDatas.size()];
        for (int i = 0; i < bossDatas.size(); i++){
            DynamicBossData dbd = new DynamicBossData(bossDatas.get(i),
                    spriteStats, plunders, bossSceneMonsterData);
            this.dynamicBossDatas[i] = dbd;
        }
        Arrays.sort(dynamicBossDatas);
        checkArgument(dynamicBossDatas.length > 0, "凌云窟必须配置动态boss属性: %s",
                DYNAMIC_BOSS_LOCATION);

        this.dynamicBossLevels = new int[dynamicBossDatas.length];
        for (int i = 0; i < dynamicBossDatas.length; i++){
            dynamicBossLevels[i] = dynamicBossDatas[i].level;
        }

        this.bossSceneID = bossSceneMonsterData.id;
    }

    private SceneMonsterData getOnlyBossData(){
        SceneMonsterData result = null;
        for (SceneMonsterData data : getSingleLifeMonsterDatas()){
            if (data.getMonsterData().isBoss()){
                checkArgument(result == null,
                        "凌云窟只能有一个怪物的类型是boss, 现在有多个: %s, %s", result, data);
                result = data;
            }
        }
        return checkNotNull(result, "凌云窟必须有一个怪物的类型是boss");
    }

    @Override
    public GroupDungeonPrizeConfig getPrizeConfig(){
        return prizeConfig;
    }

    public boolean isTargetBoss(MonsterData monsterData){
        return monsterData.isBoss();
    }

    @Override
    protected SceneMonsterData newSingleLifeMonsterData(
            SceneMonsterData sceneMonsterData, IScene parent){
        // 先判断这个怪物要不要根据等级动态调整
        if (!sceneMonsterData.getMonsterData().isBoss()){
            return sceneMonsterData;
        }

        // 是boss, boss一定只有一个, 找到符合的等级
        RemoteLingYunDungeonScene scene = (RemoteLingYunDungeonScene) parent;
        int averageLevel = scene.getBossLevel();

        int index = Utils.binarySearchForFloorKey(dynamicBossLevels,
                averageLevel);
        return dynamicBossDatas[index].sceneMonsterData;
    }

    @Override
    public LocalLingYunDungeonScene newLocalClusterScene(int uuid,
            IClusterLocalDungeonService dungeonService, ISender combatClient,
            long heroID){
        return new LocalLingYunDungeonScene(this, uuid, dungeonService,
                combatClient, heroID);
    }

    @Override
    public RemoteLingYunDungeonScene newRemoteClusterScene(int uuid,
            IDungeonService dungeonService, long creator, ISender worker){
        return new RemoteLingYunDungeonScene(this, uuid, dungeonService,
                creator, worker);
    }

    @Override
    public int getIntType(){
        return SceneType.LING_YUN_DUNGEON.getNumber();
    }

    @Override
    public boolean canHeroEnterToday(Hero hero){
        return dailyEnterLimit == 0
                || hero.getLingYunTodayFinishedTimes() < dailyEnterLimit;
    }

    public LingYunDungeonProto generateProto(){
        LingYunDungeonProto.Builder builder = LingYunDungeonProto.newBuilder();
        builder.setSceneId(id).setMap(blockName)
                .setName(ByteString.copyFrom(nameBytes)).setSound(sound);
        if (requiredLevel > 1){
            builder.setRequiredLevel(requiredLevel);
        }
        if (isHeroLevelProtect){
            builder.setIsHeroLevelProtect(true);
        }
        if (isNewHeroProtect){
            builder.setIsNewHeroProtect(true);
        }
        if (isDeathProtect){
            builder.setIsDeathProtect(true);
        }
        if (isNightAutoProtect){
            builder.setIsNightAutoProtect(true);
        }
        if (isJumpLimit){
            builder.setIsJumpLimit(true);
        }
        if (isMountLimit){
            builder.setIsMountLimit(true);
        }

        if (poet != null){
            String tp = poet.trim();
            if (tp.length() > 0){
                builder.setPoet(ByteString.copyFromUtf8(tp));
            }
        }
        if (fixedPkMode != null){
            builder.setFixedPkMode(fixedPkMode.getIntMode());
        }

        if (reliveOutOfDungeon){
            builder.setIsDeathReturnTown(true);
        }

        builder.setMinHeroCount(minHeroCount).setMaxHeroCount(maxHeroCount)
                .setRecommendedFightAmount(recommendedFightAmount)
                .setRequiredLevel(requiredLevel);

        builder.setGroupDungeonPrize(prizeConfig.encode());

        builder.setBossMonsterId(getOnlyBossData().getMonsterData().id);

        builder.setDailyEnterTime(dailyEnterLimit);
        return builder.build();
    }

    private static class DynamicBossData implements Comparable<DynamicBossData>{
        private final int level;
        private final SceneMonsterData sceneMonsterData;

        private DynamicBossData(ObjectParser p, SpriteStats spriteStats,
                Plunders plunders, SceneMonsterData bossData){
            this.level = p.getIntKey("level");
            checkArgument(level > 0, "凌云窟的动态boss的等级必须>0: %s", level);
            int statID = p.getIntKey("sprite_stat");
            SpriteStat spriteStat = checkNotNull(spriteStats.get(statID),
                    "凌云窟的动态boss的属性没找到: %s级 %s", level, statID);

            String plunderName = p.getKey("plunder");
            Plunder plunder = checkNotNull(plunders.get(plunderName),
                    "凌云窟的动态boss掉落没找到: %s级 %s", level, plunderName);

            this.sceneMonsterData = new SceneMonsterData(bossData, spriteStat,
                    level, plunder);
        }

        @Override
        public int compareTo(DynamicBossData o){
            return level - o.level;
        }
    }
}
