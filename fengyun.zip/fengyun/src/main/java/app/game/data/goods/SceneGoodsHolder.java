package app.game.data.goods;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.module.scene.HeroFightModule;

/**
 * @author Liwei
 *
 */
public interface SceneGoodsHolder{

    /**
     * 是否为无主之物
     * @return
     */
    boolean ignoreOwner();

    /**
     * 检查英雄是否可以放下这个物品
     * @param hfm
     * @return
     */
    boolean canAddTo(HeroFightModule hfm);

    /**
     * 将物品给英雄
     * @param hfm
     */
    void give(HeroFightModule hfm);

    /**
     * 将goods写给客户端
     * @param buffer
     */
    void writeTo(ChannelBuffer buffer);

    /**
     * 是否需要记录日志
     * @return
     */
    boolean needLog();

//    /**
//     * 记录日志
//     */
//    void doLog(OperateType type, OperateLogEvent e);

}
