package app.game.data.welfare;

import static com.mokylin.sink.util.Preconditions.checkArgument;

import java.util.List;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.data.GameObjects;
import app.game.data.PrizeConfigs;
import app.game.module.WelfareMessages;

import com.google.inject.Inject;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class FirstRechargeDatas{

    private static final String LOCATION = "config/data/welfare/first_recharge.txt";

    private final FirstRechargeData[] datas;

    private final ChannelBuffer fullRechargeInfoMsg;

    @Inject
    FirstRechargeDatas(GameObjects go, PrizeConfigs prizes){
        List<ObjectParser> list = go.loadFile(LOCATION);
        checkArgument(!list.isEmpty(), "首冲奖励没有配置");

        datas = new FirstRechargeData[list.size()];

        int index = 0;
        for (ObjectParser p : list){
            FirstRechargeData data = new FirstRechargeData(index++, p, prizes);
            datas[data.id] = data;
        }

        fullRechargeInfoMsg = WelfareMessages.getFirstRechargeInfo(
                datas.length, 0);
    }

    public FirstRechargeData get(int index){
        if (index >= 0 && index < datas.length){
            return datas[index];
        }
        return null;
    }

    public int getCount(){
        return datas.length;
    }

    public ChannelBuffer getFullRechargeInfoMsg(){
        return fullRechargeInfoMsg;
    }
}
