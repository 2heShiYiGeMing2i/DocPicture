package app.game.data.scene;

import static com.mokylin.sink.util.Preconditions.checkArgument;

import org.joda.time.DateTimeConstants;

import app.cluster.client.combat.scene.LocalGroupDungeonScene;
import app.cluster.combat.master.logic.scene.RemoteGroupDungeonScene;
import app.game.data.GameObjects;
import app.game.entity.Hero;
import app.game.module.scene.AbstractDungeonScene;
import app.game.module.scene.IClusterLocalDungeonService;
import app.game.module.scene.IDungeonService;
import app.game.service.log.LogService;
import app.message.ISender;
import app.utils.IDUtils;
import app.utils.VariableConfig;

import com.mokylin.sink.util.parse.ObjectParser;

public abstract class GroupDungeonSceneData extends ClusterDungeonSceneData{

    // 最小人数 最大人数

    public final int minHeroCount;

    public final int maxHeroCount;

    /**
     * 推荐的进入战力
     */
    public final int recommendedFightAmount;

    /**
     * 是否统计伤害并广播
     */
    public final boolean isRecordDamage;

    /**
     * 副本时限. 0表示没有时间限制
     */
    public final long timeLimit;

    GroupDungeonSceneData(GameObjects go, ObjectParser p, BlockInfos blocks,
            MonsterDatas monsters, Scripts scripts, Plunders plunders, Ais ais,
            SceneTransportDatas transports,
            SceneRemoveObjectMsgCache removeMsgCache){
        super(go, p, blocks, monsters, scripts, plunders, ais, transports,
                removeMsgCache);

        // 最大最小人数
        this.minHeroCount = p.getIntKey("min_hero_count");
        this.maxHeroCount = p.getIntKey("max_hero_count");
        checkArgument(minHeroCount >= 1, "%s 副本最少人数必须>=1: %s", this,
                minHeroCount);
        checkArgument(maxHeroCount >= minHeroCount, "%s 副本最大人数必须大于最小人数", this);

        // 推荐战力
        this.recommendedFightAmount = p.getIntKey("recommended_fight_amount");
        checkArgument(recommendedFightAmount >= 0, "副本 %s 的推荐战斗力必须>=0: %s",
                this, recommendedFightAmount);

        // 是否统计伤害
        this.isRecordDamage = p.getBooleanKey("is_record_damage");

        // 时间限制
        int timeLimitInSecond = p.getIntKey("time_limit_second");
        checkArgument(timeLimitInSecond >= 0, "副本 %s 的时间限制必须>=0: %s", this,
                timeLimitInSecond);
        this.timeLimit = ((long) timeLimitInSecond)
                * DateTimeConstants.MILLIS_PER_SECOND;
    }

    @Override
    public boolean isSeeAllInScene(){
        return true;
    }

    /**
     * 跨服场景会重写这个id, 返回的sequence一定是SCENE_MAX_LINE_COUNT+1
     * @return
     */
    @Override
    public int newDungeonID(){
        return IDUtils.combineSceneID(id,
                VariableConfig.CLUSTER_DUNGEON_SEQUENCE);
    }

    @Override
    public AbstractDungeonScene newDungeon(int sceneID,
            IDungeonService dungeonService, LogService logService, long creator){
        throw new UnsupportedOperationException("组队副本不该由newDungeon创建: "
                + toString());
    }

    // --- abstract methods ---

    @Override
    public abstract LocalGroupDungeonScene newLocalClusterScene(int uuid,
            IClusterLocalDungeonService dungeonService, ISender combatClient,
            long heroID);

    @Override
    public abstract RemoteGroupDungeonScene newRemoteClusterScene(int uuid,
            IDungeonService dungeonService, long creator, ISender worker);

    /**
     * 英雄今天是否还能进入这个副本
     * @param hero
     * @return
     */
    public abstract boolean canHeroEnterToday(Hero hero);

    /**
     * 如果副本完成是统一的组队副本完成逻辑, 则返回奖励. 如果不是, 返回null
     * @return
     */
    public abstract GroupDungeonPrizeConfig getPrizeConfig();
}
