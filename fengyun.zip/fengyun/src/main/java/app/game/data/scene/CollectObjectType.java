package app.game.data.scene;

import static com.mokylin.sink.util.Preconditions.checkArgument;
import static com.mokylin.sink.util.Preconditions.checkNotNull;
import app.protobuf.ConfigContent.CollectObjectProto;

import com.google.protobuf.ByteString;
import com.mokylin.collection.IntHashSet;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class CollectObjectType{

    /**
     * 类型
     */
    final int type;

    /**
     * 采集物品全局名称
     */
    final String name;

    /**
     * 资源
     */
    private final String resource;

    /**
     * 客户端显示名称
     */
    private final String displayName;

    private final SceneData scene;

    final CollectObject[] objects;

    private final String actionName;

    CollectObjectType(ObjectParser p, int type, int startId,
            SceneDatas sceneDatas){
        this.type = type;
        name = p.getKey("name");
        displayName = getDisplayName(name);

        this.resource = p.getKey("resource");

        int sceneId = p.getIntKey("scene");
        this.scene = checkNotNull(sceneDatas.get(sceneId),
                "没找到采集物体 %s-%s 所属的场景: %s", type, name, sceneId);

        String posStr = p.getKey("pos");

        String[] posArray = posStr.split(";");
        checkArgument(posArray.length > 0, "采集物品-%s 没有配置坐标", name);

        actionName = p.getKey("action");
        checkArgument(!actionName.isEmpty(), "采集物品-%s 没有动作名称没有配置，{}", name,
                actionName);

        IntHashSet posSet = new IntHashSet();
        objects = new CollectObject[posArray.length];
        for (int i = 0; i < posArray.length; i++){
            String pos = posArray[i];
            int idx = pos.indexOf(",");
            checkArgument(idx > 0, "采集物品-%s 坐标配置错误，格式: x1,y1;x2,y2;x3,y3", name);

            int posX = Integer.parseInt(pos.substring(0, idx));
            int posY = Integer.parseInt(pos.substring(idx + 1));

            // 检查是否可行走
            checkArgument(scene.blockInfo.isWalkable(posX, posY),
                    "采集物品-%s 处于地图的不可行走点：%s,%s", name, posX, posY);

            checkArgument(posSet.add(Utils.short2Int(posX, posY)),
                    "采集物品-%s 坐标重复：pos: %s, %s", name, posX, posY);

            objects[i] = new CollectObject(startId + i, posX, posY);
        }
    }

    public int getType(){
        return type;
    }

    public SceneData getScene(){
        return scene;
    }

    public CollectObject getFirstObject(){
        return objects[0];
    }

    private String getDisplayName(String name){
        int underScorePos = name.indexOf("_");
        if (underScorePos < 0){
            return name;
        }

        return name.substring(0, underScorePos);
    }

    CollectObjectProto encode(){
        CollectObjectProto.Builder builder = CollectObjectProto.newBuilder()
                .setName(ByteString.copyFromUtf8(displayName))
                .setResource(resource).setSceneId(scene.id)
                .setAction(actionName);

        for (CollectObject obj : objects){
            builder.addObjectId(obj.id).addPosX(obj.posX).addPosY(obj.posY);
        }

        return builder.build();
    }

    public class CollectObject{
        private static final int TOO_FAR_DISTANCE = 5;

        /**
         * 场景中全局唯一
         */
        final int id;

        private final int posX;

        private final int posY;

        private CollectObject(int id, int posX, int posY){
            this.id = id;
            this.posX = posX;
            this.posY = posY;
        }

        public CollectObjectType getType(){
            return CollectObjectType.this;
        }

        public int getPosX(){
            return posX;
        }

        public int getPosY(){
            return posY;
        }

        public boolean isTooFar(int sceneId, int x, int y){
            if (sceneId == scene.id && Math.abs(x - posX) < TOO_FAR_DISTANCE
                    && Math.abs(y - posY) < TOO_FAR_DISTANCE){
                return false;
            }

            return true;
        }
    }

    @Override
    public String toString(){
        return "采集物品-" + name;
    }
}
