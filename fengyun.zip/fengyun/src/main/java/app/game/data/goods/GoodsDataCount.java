package app.game.data.goods;

/**
 * @author Liwei
 *
 */
public class GoodsDataCount{

    public final GoodsData data;

    public final int goodsID;

    public final int goodsCount;

    public GoodsDataCount(GoodsData goodsData, int goodsCount){
        this.data = goodsData;
        this.goodsID = goodsData.id;
        this.goodsCount = goodsCount;
    }

    public GoodsDataCount(int goodsId, int goodsCount){
        data = null;
        this.goodsID = goodsId;
        this.goodsCount = goodsCount;
    }
}
