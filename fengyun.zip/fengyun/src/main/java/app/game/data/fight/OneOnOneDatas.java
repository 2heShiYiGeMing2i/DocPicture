package app.game.data.fight;

import static com.mokylin.sink.util.Preconditions.*;
import app.game.data.scene.SceneData;
import app.game.data.scene.SceneDatas;
import app.protobuf.ConfigContent.FightConfig;
import app.utils.VariableConfig;

import com.google.inject.Inject;

/**
 * @author Liwei
 *
 */
public class OneOnOneDatas{

    private final FightRefinedStats refinedStats;

    private final FightPosDiffDatas diffDatas;

    @Inject
    OneOnOneDatas(FightRefinedStats refinedStats, FightPosDiffDatas diffDatas,
            VariableConfig config, SceneDatas sceneDatas){
        this.refinedStats = refinedStats;
        this.diffDatas = diffDatas;

        SceneData sceneData = checkNotNull(
                sceneDatas.get(config.ONE_ON_ONE_SCENE_ID),
                "没有找到个人竞技场打架的场景-%s", config.ONE_ON_ONE_SCENE_ID);

        checkArgument(sceneData.blockInfo.isWalkable(config.ONE_ON_ONE_SCENE_X,
                config.ONE_ON_ONE_SCENE_Y), "个人竞技场打架场景的位置居然不是一个可以行走的点- %s,%s",
                config.ONE_ON_ONE_SCENE_X, config.ONE_ON_ONE_SCENE_Y);
    }

    public FightRefinedStats getRefinedStats(){
        return refinedStats;
    }

    public FightPosDiffDatas getDiffDatas(){
        return diffDatas;
    }

    public FightConfig generateProto(VariableConfig config){
        FightConfig.Builder builder = FightConfig.newBuilder();

        builder.setMaxChallengeTimes(VariableConfig.ONE_ON_ONE_CHALLENGE_MAX_TIMES);
        builder.setAddChallengeTimesCost(config.ONE_ON_ONE_ADD_CHALLENGE_TIMES_COST);
        builder.setResetCooldownCost(config.ONE_ON_ONE_RESET_COOLDOWN_COST);
        builder.setRefinedLijinCost(config.ONE_ON_ONE_REFINED_LIJIN_COST);
        builder.setRefinedYuanbaoCost(config.ONE_ON_ONE_REFINED_YUANBAO_COST);
        builder.setSceneId(config.ONE_ON_ONE_SCENE_ID);
        builder.setSceneX(config.ONE_ON_ONE_SCENE_X);
        builder.setSceneY(config.ONE_ON_ONE_SCENE_Y);

        diffDatas.encode(builder);

        return builder.build();
    }
}
