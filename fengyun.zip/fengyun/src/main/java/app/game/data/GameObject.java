package app.game.data;

import static com.mokylin.sink.util.Preconditions.checkArgument;

import com.mokylin.sink.util.StringEncoder;
import com.mokylin.sink.util.parse.ObjectParser;

public abstract class GameObject{

    private static final byte[] EMPTY_BYTE_ARRAY = new byte[0];

    public static final int ID_MAX_AMOUNT = 100_0000; // 共20个bit

    public final int id;
    public final String name;
    public final byte[] nameBytes;

    protected GameObject(ObjectParser parser){
        id = parser.getIntKey("id");
        name = parser.getKey("name");
        nameBytes = StringEncoder.encode(name);

        checkArgument(id > 0 && id <= ID_MAX_AMOUNT,
                "配置的id必须 [0 < amount <= 100万]: %s-%s", id, name);
    }

    protected GameObject(int id, String name){
        this.id = id;
        this.name = name;
        nameBytes = StringEncoder.encode(name);
    }

    protected GameObject(GameObject obj){
        id = obj.id;
        name = obj.name;
        nameBytes = obj.nameBytes;
    }

    protected GameObject(){
        id = 0;
        name = "";
        nameBytes = EMPTY_BYTE_ARRAY;
    }

    @Override
    public String toString(){
        return id + "-" + name;
    }
}
