/**
 * 
 */
package app.game.data.goods;

import app.protobuf.GoodsContent.ScriptGoodsDataProto;
import app.protobuf.GoodsServerContent.GoodsType;

import com.google.protobuf.ByteString;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * 脚本道具
 * 
 * @author Liwei
 * 
 */
public class ScriptGoodsData extends GoodsData{

    private final int scriptId;

    private final ScriptGoodsDataProto proto;

    private final byte[] protoBytes;

    private final ByteString protoByteString;

    ScriptGoodsData(ObjectParser p){
        super(p, GoodsType.SCRIPT);

        scriptId = p.getIntKey("script_id");

        proto = build();
        protoBytes = processProtoBytes(proto.toByteArray());
        protoByteString = ByteString.copyFrom(protoBytes);
    }

    private ScriptGoodsDataProto build(){
        ScriptGoodsDataProto.Builder builder = ScriptGoodsDataProto
                .newBuilder();
        builder.setBaseData(encode());
        builder.setScript(scriptId);

        return builder.build();
    }

    public ScriptGoodsDataProto getProto(){
        return proto;
    }

    @Override
    public byte[] getProtoBytes(){
        return protoBytes;
    }

    @Override
    public ByteString getProtoByteString(){
        return protoByteString;
    }

    @Override
    public int getAuctionType(){
        return 123;
    }
}
