package app.game.data.goods;

import static com.mokylin.sink.util.Preconditions.*;
import app.game.data.GameObjects;
import app.game.data.spell.SpellXinfaEffect;
import app.game.data.spell.SpellXinfaEffects;
import app.protobuf.GoodsContent.SpellXinfaDataProto;
import app.protobuf.GoodsServerContent.GoodsType;

import com.google.protobuf.ByteString;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * 技能心法，实在找不到英文来描述这玩意
 * @author Liwei
 *
 */
public class SpellXinfaData extends GoodsData{

    static final String LOCATION = GameObjects.GOODS_BASE_LOCATION
            + "xinfa.txt";

    public final int xinfa;

    // 心法效果
    public SpellXinfaEffect xinfaEffect;

    private byte[] protoBytes;

    private ByteString protoByteString;

    SpellXinfaData(ObjectParser p){
        super(p, GoodsType.XINFA);

        checkArgument(maxCount == 1, "%s 技能心法的最大堆叠数量必须为1", this);

        xinfa = p.getIntKey("xinfa");
    }

    void initXinfa(SpellXinfaEffects xinfaEffects){
        xinfaEffect = checkNotNull(xinfaEffects.get(xinfa), "%s 配置的心法没找到, %s",
                this, xinfa);

        SpellXinfaDataProto proto = build();
        protoBytes = processProtoBytes(proto.toByteArray());
        protoByteString = ByteString.copyFrom(protoBytes);
    }

    private SpellXinfaDataProto build(){
        SpellXinfaDataProto.Builder builder = SpellXinfaDataProto.newBuilder();
        builder.setBaseData(encode());
        builder.setType(xinfaEffect.type);
        builder.setRequireSpellLevel(xinfaEffect.requireSpellLevel);

        if (xinfaEffect.releaseRange > 0)
            builder.setReleaseRange(xinfaEffect.releaseRange);

        if (xinfaEffect.hurtRange > 0)
            builder.setHurtRange(xinfaEffect.hurtRange);

        return builder.build();
    }

    @Override
    public byte[] getProtoBytes(){
        return protoBytes;
    }

    @Override
    public ByteString getProtoByteString(){
        return protoByteString;
    }

    @Override
    protected int getAuctionType(){
        return 78;
    }

}
