package app.game.data.scene;

import static com.mokylin.sink.util.Preconditions.*;
import app.game.data.TimeData;

import com.mokylin.collection.IntArrayList;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.parse.ObjectParser;

public class MonsterGroupData{

    private static final int DROP_MAX_COUNT = 65;

    private final BlockInfo blockInfo;
    private final int x;
    private final int y;
    private final int width;
    private final int height;

    private final int count;

    public final TimeData timeData;

    final MonsterData monster;
    final Ai ai;
    final Plunder plunder;

    public MonsterGroupData(ObjectParser p, MonsterDatas monsterDatas,
            Plunders plunders, Ais ais, BlockInfo blockInfo){
        this.blockInfo = blockInfo;
        this.x = p.getIntKey("x");
        this.y = p.getIntKey("y");
        this.width = p.getIntKey("width");
        this.height = p.getIntKey("height");

        this.count = p.getIntKey("count");

        String monsterName = p.getKey("monster_name");
        this.monster = checkNotNull(monsterDatas.get(monsterName),
                "没有找到场景中要摆放的怪物id: %s", monsterName);

        String aiName = p.getKey("ai");
        this.ai = checkNotNull(ais.get(aiName), "没有找到场景中要摆放的怪物所使用的ai: %s",
                aiName);

        if (monster.rankCount > 0){
            checkArgument(ai.isSingleLife,
                    "怪物%s 配置了伤害排行榜，但是配置的ai居然不是一条命的怪, ai: %s", monster, ai);
        }

        String timeConfig = p.getKey("boss_time");
        if (timeConfig.length() > 0){
            timeData = TimeData.parse(timeConfig);
            checkArgument(ai.isSingleLife, "场景中怪物配置了boss_time, ai不能是可复活的: %s",
                    monsterName);
        } else{
            timeData = null;
        }

        // 如果是个主动/被动 攻击的怪, 必须有默认攻击技能
        if (ai.getActionType() == Ai.ACTION_TYPE_PASSIVE
                || ai.getActionType() == Ai.ACTION_TYPE_PROACTIVE){
            checkNotNull(monster.normalSpell,
                    "场景中的怪物%s 没有配置默认技能, 但是用的ai %s 又是主动/被动的", monster, ai);
        }

        String plunderName = p.getKey("plunder_name");
        Plunder plunder = null;
        if (!plunderName.isEmpty()){
            plunder = checkNotNull(plunders.get(plunderName),
                    "没有找到场景中要摆放的怪物所使用的掉落: %s", plunderName);
        }

        this.plunder = plunder;

        checkArgument(plunder.maxDropGoodsCount < DROP_MAX_COUNT,
                "%s 配置的掉落个数太多了，超过64个", monsterName);
    }

    int[] getPos(){
        IntArrayList allWalkableList = new IntArrayList();
        for (int i = x; i <= x + width; i++){
            for (int j = y; j <= y + height; j++){
                if (blockInfo.isWalkable(i, j)){
                    allWalkableList.add(Utils.short2Int(i, j));
                }
            }
        }
        checkArgument(allWalkableList.size() > 0,
                "%s 场景中要放怪物的范围里没有一个可走的点: <%s, %s> width %s height %s",
                blockInfo.name, x, y, width, height);

        float diff = ((float) allWalkableList.size()) / count;

        int[] result = new int[count];
        for (int i = 0; i < count; i++){
            result[i] = allWalkableList.get((int) (i * diff));
        }
        return result;
    }
}
