package app.game.data;

import static com.mokylin.sink.util.Preconditions.*;
import app.game.data.scene.SceneData;
import app.game.data.scene.SceneDatas;
import app.game.data.spell.Spells;
import app.game.data.task.TaskDatas;
import app.game.service.TimeService;
import app.i18n.I18NConfigs;
import app.i18n.MESSAGE_ENUM;
import app.protobuf.HeroServerContent.RaceId;
import app.utils.VariableConfig;

import com.google.inject.Inject;

public class Races{

    public final Race BU_JING_YUN;

    private final Race NIE_FENG;

    private final Race CHU_CHU;

    private final Race DI_ER_MENG;

    @Inject
    Races(VariableConfig variableConfig, SceneDatas sceneDatas,
            HeroLevelDatas levelDatas, Spells spells, TaskDatas taskDatas,
            LotteryDatas lotteryDatas, TimeService timeService,
            I18NConfigs language){
        int initialHeroSceneID = variableConfig.INITIAL_SCENE_ID;

        SceneData scene = sceneDatas.get(initialHeroSceneID);
        checkNotNull(scene, "英雄出生场景未找到: " + initialHeroSceneID);
        int initialHeroX = variableConfig.INITIAL_SCENE_X;
        int initialHeroY = variableConfig.INITIAL_SCENE_Y;

        checkArgument(scene.blockInfo.isWalkable(initialHeroX, initialHeroY),
                "新建英雄的坐标不可走 %s 场景的 <%s, %s>", scene, initialHeroX, initialHeroY);

        int rageMaxAmount = variableConfig.RAGE_MAX_AMOUNT;
        checkArgument(rageMaxAmount > 0, "怒气最大值必须大于0");

        this.BU_JING_YUN = new Race(RaceId.BU_JING_YUN, true, language
                .getI18N().getOriginalValue(MESSAGE_ENUM.BU_JING_YUN),
                initialHeroSceneID, initialHeroX, initialHeroY, levelDatas,
                spells, taskDatas, lotteryDatas, timeService, rageMaxAmount);
        this.NIE_FENG = new Race(RaceId.NIE_FENG, true, language.getI18N()
                .getOriginalValue(MESSAGE_ENUM.NIE_FENG), initialHeroSceneID,
                initialHeroX, initialHeroY, levelDatas, spells, taskDatas,
                lotteryDatas, timeService, rageMaxAmount);
        this.CHU_CHU = new Race(RaceId.CHU_CHU, false, language.getI18N()
                .getOriginalValue(MESSAGE_ENUM.CHU_CHU), initialHeroSceneID,
                initialHeroX, initialHeroY, levelDatas, spells, taskDatas,
                lotteryDatas, timeService, rageMaxAmount);
        this.DI_ER_MENG = new Race(RaceId.DI_ER_MENG, false, language.getI18N()
                .getOriginalValue(MESSAGE_ENUM.DI_ER_MENG), initialHeroSceneID,
                initialHeroX, initialHeroY, levelDatas, spells, taskDatas,
                lotteryDatas, timeService, rageMaxAmount);
    }

    public Race getRace(int id){
        switch (id){
            case RaceId.BU_JING_YUN_VALUE:{
                return BU_JING_YUN;
            }

            case RaceId.NIE_FENG_VALUE:{
                return NIE_FENG;
            }

            case RaceId.CHU_CHU_VALUE:{
                return CHU_CHU;
            }

            case RaceId.DI_ER_MENG_VALUE:{
                return DI_ER_MENG;
            }
        }
        return null;
    }
}
