/**
 * 
 */
package app.game.data.goods;

import static app.game.module.GoodsContainerMessages.*;
import static app.protobuf.LogContent.LogEnum.OperateType.USE_YUANBAO_PACKAGE;
import static com.mokylin.sink.util.Preconditions.*;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.data.GameObjects;
import app.game.data.Prize;
import app.game.data.PrizeConfig;
import app.game.data.PrizeConfigs;
import app.game.entity.Depot;
import app.game.entity.Hero;
import app.game.module.GoodsContainerMessages;
import app.game.module.HeroMiscModule;
import app.game.module.scene.HeroFightModule;
import app.protobuf.GoodsContent.YuanbaoPackageDataProto;
import app.protobuf.GoodsServerContent.GoodsType;
import app.protobuf.HeroServerContent.RaceId;

import com.google.protobuf.ByteString;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * 元宝礼包
 * 
 * @author Liwei
 * 
 */
public class YuanbaoPackageData extends GoodsData{

    static final String LOCATION = GameObjects.GOODS_BASE_LOCATION
            + "yuanbao_package.txt";

    private final String prizeName;

    private final int cost;

    private final String title;

    private final int showPrice;

    private final YuanbaoPackageDataProto proto;

    private final byte[] protoBytes;

    private final ByteString protoByteString;

    private final Efficacy efficacy;

    private PrizeConfig prizeConfig;

    private final Prize[] prizes;

    private final ChannelBuffer[] prizeMsgs;

    YuanbaoPackageData(ObjectParser p){
        super(p, GoodsType.YUANBAO_PACKAGE);

        prizeName = p.getKey("prize_name");
        checkArgument(!prizeName.isEmpty(), "%s 没有配置关联的奖励", this);

        cost = p.getIntKey("cost");
        checkArgument(cost > 0, "%s 配置的元宝消耗必须>0");

        title = p.getKey("title");
        checkArgument(!title.isEmpty(), "%s 配置的title为空");

        showPrice = p.getIntKey("show_price");
        checkArgument(cost < showPrice, "%s 配置的原价比售价还高");

        efficacy = new PackageEfficacy();

        proto = build();
        protoBytes = processProtoBytes(proto.toByteArray());
        protoByteString = ByteString.copyFrom(protoBytes);

        prizes = new Prize[RaceId.values().length];
        prizeMsgs = new ChannelBuffer[RaceId.values().length];
    }

    public void initPrize(PrizeConfigs prizeConfigs){
        this.prizeConfig = checkNotNull(prizeConfigs.get(prizeName),
                "%s 配置的奖励不存在， %s", this, prizeName);

        int len = RaceId.values().length;
        if (prizeConfig.isRaceDiff()){
            for (RaceId race : RaceId.values()){
                Prize prize = prizeConfig.random(race);
                ChannelBuffer msg = GoodsContainerMessages
                        .getYuanbaoPackageShowGoods(id, prize.encode4Client());

                prizes[race.getNumber() - 1] = prize;
                prizeMsgs[race.getNumber() - 1] = msg;
            }
        } else{
            Prize prize = prizeConfig.random();
            ChannelBuffer msg = GoodsContainerMessages
                    .getYuanbaoPackageShowGoods(id, prize.encode4Client());

            for (int i = 0; i < len; i++){
                prizes[i] = prize;
                prizeMsgs[i] = msg;
            }
        }
    }

    public ChannelBuffer getShowGoodsMsg(int race){
        return Utils.getValidObject(prizeMsgs, race - 1);
    }

    protected YuanbaoPackageDataProto build(){
        YuanbaoPackageDataProto.Builder builder = YuanbaoPackageDataProto
                .newBuilder();
        builder.setBaseData(encode());
        builder.setCost(cost);
        builder.setTitle(title);
        builder.setShowPrice(showPrice);

        return builder.build();
    }

    @Override
    public byte[] getProtoBytes(){
        return protoBytes;
    }

    @Override
    public ByteString getProtoByteString(){
        return protoByteString;
    }

    @Override
    public int getAuctionType(){
        return 123;
    }

    @Override
    public Efficacy getEfficacy(){
        return efficacy;
    }

    private class PackageEfficacy implements Efficacy{

        @Override
        public int useTo(HeroFightModule heroFightModule, int useCount,
                long ctime, String iEventId){

            Hero hero = heroFightModule.getHero();

            Prize prize = prizes[hero.getRaceId() - 1];

            GoodsAddHelper[] toAdds = prize.newGoodsAddHelpers(ctime);

            Depot depot = hero.getDepot();
            GoodsTryAddResult result = depot.canAddGoods(toAdds);

            if (!result.isSuccess()){
                heroFightModule.sendMessage(ERR_USE_YB_PACKAGE_NOT_EMPTY_POS);
                return 0;
            }

            HeroMiscModule miscModule = heroFightModule.getHeroMiscModule();

            if (!miscModule.reduceYuanbao(cost, USE_YUANBAO_PACKAGE, iEventId)){
                heroFightModule.sendMessage(ERR_USE_YB_PACKAGE_YB_NOT_ENOUGH);
                return 0;
            }

            heroFightModule
                    .getServices()
                    .getModules()
                    .getGoodsModule()
                    .addBatchGoodsArray(toAdds, result, hero,
                            heroFightModule.getSender(), miscModule,
                            USE_YUANBAO_PACKAGE, 0, ctime);

            prize.giveIgnoreGoods(heroFightModule.getHeroMiscModule(), hero,
                    false, USE_YUANBAO_PACKAGE, iEventId);

            return 1;
        }
    }
}
