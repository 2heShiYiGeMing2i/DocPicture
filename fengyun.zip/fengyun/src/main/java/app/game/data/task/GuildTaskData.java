package app.game.data.task;

import static com.mokylin.sink.util.Preconditions.checkArgument;
import static com.mokylin.sink.util.Preconditions.checkNotNull;
import app.game.data.Prize;
import app.game.data.PrizeConfig;
import app.game.data.PrizeConfigs;
import app.game.data.goods.GoodsDatas;
import app.game.data.scene.CollectObjects;
import app.game.data.scene.MonsterData;
import app.game.data.scene.MonsterDatas;
import app.game.data.scene.Npcs;
import app.game.data.scene.SceneDatas;
import app.game.data.task.TaskDatas.TaskType;
import app.game.data.task.TaskTarget.TaskTargetProgress;
import app.protobuf.TaskContent.GuildTaskProto;
import app.protobuf.TaskContent.TaskDataProto;
import app.utils.VariableConfig;

import com.mokylin.collection.IntHashMap;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class GuildTaskData{

    public static final GuildTaskData[] EMPTY_ARRAY = new GuildTaskData[0];;

    final int id;

    final int minLevel;

    final int maxLevel;

    final TaskData taskData;

    final Prize prize;

    private final transient TaskDataProto taskProto;

    private final transient TaskTargetProgress[] emptyProgress;

    private final transient Prize[] autoCompleteAllTaskPrizes;

    GuildTaskData(ObjectParser p, Npcs npcs, GoodsDatas goodsDatas,
            MonsterDatas monsters, PrizeConfigs prizes,
            CollectObjects collectObjects, SceneDatas sceneDatas,
            IntHashMap<MonsterData> monLevelMap, Prize extraPrize){
        this.id = p.getIntKey("id");

        int minLevel = p.getIntKey("min_level");
        int maxLevel = p.getIntKey("max_level");
        checkArgument(
                minLevel > 0 && minLevel <= maxLevel
                        && maxLevel <= VariableConfig.HERO_MAX_LEVEL,
                "帮派任务-%s 配置的等级无效, minLevel > 0 && minLevel <= maxLevel && maxLevel <= HERO_MAX_LEVEL, minLevel: %s, maxLevel:%s, heroMaxLevel: %s",
                id, minLevel, maxLevel, VariableConfig.HERO_MAX_LEVEL);

        checkArgument(
                minLevel > 0 && maxLevel <= VariableConfig.HERO_MAX_LEVEL,
                "帮派任务-%s 奖励中配置了有过期时间的物品", id);

        TaskData taskData = TaskData.newGuildTask(id, p, npcs, monsters,
                goodsDatas, collectObjects, sceneDatas, monLevelMap);

        String prizeName = p.getKey("prize");
        PrizeConfig prizeConfig = checkNotNull(prizes.get(prizeName),
                "帮派任务-%s 配置的任务奖励不存在，prizeName: %s", id, prizeName);

        checkArgument(!prizeConfig.hasExipreTimeGoods(),
                "帮派任务-%s 奖励中配置了有过期时间的物品", id);
        checkArgument(!prizeConfig.isVarPrize(), "帮派任务-%s 中配置了随机属性的物品", id);
        checkArgument(!prizeConfig.hasUnbindedGoods(), "帮派任务-%s 奖励中配置了非绑定的物品",
                id);
        checkArgument(!prizeConfig.isRaceDiff(), "帮派任务-%s 奖励中配置了跟职业相关的物品", id);

        Prize prize = prizeConfig.random();

        this.minLevel = minLevel;
        this.maxLevel = maxLevel;
        this.taskData = taskData;
        this.prize = prize;

        taskProto = taskData.encodeData(prize);
        emptyProgress = taskData.newEmptyProgress(0);

        autoCompleteAllTaskPrizes = new Prize[VariableConfig.GUILD_TASK_MAX_ROUND];
        Prize.Builder builder = Prize.newBuilder();
        builder.add(extraPrize);
        for (int i = 0; i < VariableConfig.GUILD_TASK_MAX_ROUND; i++){
            builder.add(prize);
            autoCompleteAllTaskPrizes[i] = builder.build();
        }
    }

    public int getIntType(){
        return TaskType.GUILD.getIntType();
    }

    Prize getPrize(){
        return prize;
    }

    public Prize getAutoCompleteAllTaskPrize(int times){
        if (times > 0 && times <= VariableConfig.GUILD_TASK_MAX_ROUND){
            return autoCompleteAllTaskPrizes[times - 1];
        }

        return null;
    }

    GuildTask newEmptyTask(int taskId){
        return new GuildTask(taskId, this, taskData.newEmptyProgress(taskId));
    }

    GuildTask newTask(int taskId, TaskTargetProgress[] progress){
        return new GuildTask(taskId, this, progress);
    }

    GuildTaskProto encode4Client(int round, int taskId){
        return encode4Client(round, taskId, emptyProgress);
    }

    GuildTaskProto encode4Client(int round, int taskId,
            TaskTargetProgress[] progress){
        return GuildTaskProto
                .newBuilder()
                .setRound(round)
                .setBaseTask(
                        TaskData.encodeTaskProto(taskId, taskProto, progress))
                .build();
    }
}
