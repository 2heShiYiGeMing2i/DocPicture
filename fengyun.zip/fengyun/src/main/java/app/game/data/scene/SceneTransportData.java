package app.game.data.scene;

import app.protobuf.ConfigContent.TransportProto;

import com.mokylin.sink.util.parse.ObjectParser;

public class SceneTransportData{

    public static final SceneTransportData[] EMPTY_ARRAY = new SceneTransportData[0];

    public final int sourceSceneID;

    public final int sourceX;

    public final int sourceY;

    public final String res;

    public final int destSceneID;

    private final int destX;

    private final int destY;

    private final int randomDistance;

    private TransportData destData;

    SceneTransportData(ObjectParser p){
        this.sourceSceneID = p.getIntKey("source_scene_id");
        this.sourceX = p.getIntKey("source_x");
        this.sourceY = p.getIntKey("source_y");

        this.destSceneID = p.getIntKey("dest_scene_id");
        this.destX = p.getIntKey("dest_x");
        this.destY = p.getIntKey("dest_y");
        this.randomDistance = p.getIntKey("random_distance");

        this.res = p.getKey("res");
    }

    void setDestSceneData(NormalSceneData sceneData){
        this.destData = TransportData.newTransportData(sceneData, destX, destY,
                randomDistance);
    }

    public int getRandomPoint(){
        return destData.getRandomPoint();
    }

    public int getDestSceneID(){
        return destSceneID;
    }

    public NormalSceneData getDestSceneData(){
        return destData.getSceneData();
    }

    public int getRequiredLevel(){
        return destData.requiredLevel;
    }

    @Override
    public int hashCode(){
        return sourceSceneID * 31 + sourceX * 77 + sourceY;
    }

    @Override
    public boolean equals(Object obj){
        if (obj instanceof SceneTransportData){
            SceneTransportData t = (SceneTransportData) obj;
            return sourceSceneID == t.sourceSceneID && sourceX == t.sourceX
                    && sourceY == t.sourceY;
        }
        return false;
    }

    TransportProto encode(){
        return TransportProto.newBuilder().setDestSceneId(destSceneID)
                .setSourceX(sourceX).setSourceY(sourceY)
                .setRequiredLevle(destData.requiredLevel).setRes(res).build();
    }

}
