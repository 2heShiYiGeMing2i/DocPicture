package app.game.data.goods;

import static app.game.module.GoodsContainerMessages.*;
import static app.protobuf.LogContent.LogEnum.OperateType.USE_LEGEND_CARD;
import static com.mokylin.sink.util.Preconditions.*;
import app.game.data.GameObjects;
import app.game.data.scene.Plunder;
import app.game.data.scene.Plunders;
import app.game.entity.Depot;
import app.game.entity.Hero;
import app.game.module.scene.HeroFightModule;
import app.protobuf.GoodsContent.GoodsDataProto;
import app.protobuf.GoodsServerContent.GoodsType;

import com.google.protobuf.ByteString;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class LegendCardData extends GoodsData{

    static final String LOCATION = GameObjects.GOODS_BASE_LOCATION
            + "legend_card.txt";

    private final String plunderName;

    private final GoodsDataProto proto;

    private final byte[] protoBytes;

    private final ByteString protoByteString;

    private final Efficacy efficacy;

    private Plunder[] plunderArray;

    LegendCardData(ObjectParser p){
        super(p, GoodsType.PACKAGE);

        int type = p.getIntKey("card_type");

        switch (type){
            case 1:{
                efficacy = new MountEfficacy();
                break;
            }
            case 2:{
                efficacy = new BowEfficacy();
                break;
            }
            case 3:{
                efficacy = new TianjieEfficacy();
                break;
            }
            case 4:{
                efficacy = new TianzuiEfficacy();
                break;
            }
            default:{
                System.err.println("传说卡发现无效的card_type: " + type);
                throw new RuntimeException("传说卡发现无效的card_type: " + type);
            }
        }

        plunderName = p.getKey("plunder");
        checkArgument(!plunderName.isEmpty(), "%s 没有配置关联的掉落", this);

        proto = encode().build();
        protoBytes = processProtoBytes(proto.toByteArray());
        protoByteString = ByteString.copyFrom(protoBytes);
    }

    public void initPlunder(Plunders plunders){

        String[] array = plunderName.split(";");
        checkArgument(array.length > 0, "%s 配置的掉落没有配置", this);

        plunderArray = new Plunder[array.length];

        for (int i = 0; i < array.length; i++){
            plunderArray[i] = checkNotNull(plunders.get(array[i]),
                    "%s 配置的掉落不存在， %s", this, array[i]);
        }
    }

    @Override
    public byte[] getProtoBytes(){
        return protoBytes;
    }

    @Override
    public ByteString getProtoByteString(){
        return protoByteString;
    }

    @Override
    public int getAuctionType(){
        return 123;
    }

    @Override
    public Efficacy getEfficacy(){
        return efficacy;
    }

    private abstract class LegendCardEfficacy implements Efficacy{

        @Override
        public int useTo(HeroFightModule heroFightModule, int useCount,
                long ctime, String iEventId){

            Hero hero = heroFightModule.getHero();
            int type = getSystemType(hero);
            if (type <= 0){
                heroFightModule.sendMessage(ERR_USE_LEGEND_CARD_NOT_OPEN);
                return 0;
            }

            Plunder plunder = Utils.getValidObject(plunderArray, type - 1);

            int emptyPosCount = plunder.getEmptyPosCount(hero.getRaceId(),
                    hero.getLevel(), hero.getVipLevel());

            Depot depot = hero.getDepot();
            if (!depot.hasEnoughEmptyCount(emptyPosCount)){
                heroFightModule.sendMessage(ERR_USE_LEGEND_CARD_NOT_EMPTY_POS);
                return 0;
            }

            plunder.give(heroFightModule, ctime, USE_LEGEND_CARD, iEventId);

            return 1;
        }

        protected abstract int getSystemType(Hero hero);
    }

    private class MountEfficacy extends LegendCardEfficacy{
        @Override
        protected int getSystemType(Hero hero){
            return hero.getBestMountId();
        }
    }

    private class BowEfficacy extends LegendCardEfficacy{
        @Override
        protected int getSystemType(Hero hero){
            return hero.getBowId();
        }
    }

    private class TianjieEfficacy extends LegendCardEfficacy{
        @Override
        protected int getSystemType(Hero hero){
            return hero.getTianJieId();
        }
    }

    private class TianzuiEfficacy extends LegendCardEfficacy{
        @Override
        protected int getSystemType(Hero hero){
            return hero.getTianZuiId();
        }
    }
}
