package app.game.data;

import static com.mokylin.sink.util.Preconditions.checkArgument;

import java.util.List;

import app.game.data.goods.GoodsDatas;

import com.google.inject.Inject;
import com.mokylin.collection.IntHashMap;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class CouponDatas{

    private static final String LOCATION = "config/data/welfare/coupon.txt";

    private final IntHashMap<CouponData> datas;

    @Inject
    CouponDatas(GameObjects go, GoodsDatas goodsDatas){
        List<ObjectParser> data = go.loadFile(LOCATION);
        checkArgument(!data.isEmpty(), "激活码礼包没有配置，%s", LOCATION);

        datas = new IntHashMap<>();
        for (ObjectParser p : data){

            CouponData c = new CouponData(p, goodsDatas);
            datas.putUnique(c.id, c);
        }
    }

    public CouponData get(int id){
        return datas.get(id);
    }
}
