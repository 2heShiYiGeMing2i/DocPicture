package app.game.data.goods;

import static com.mokylin.sink.util.Preconditions.*;

import java.util.EnumMap;
import java.util.List;

import app.game.data.UpgradeData;
import app.game.shop.VendingMachine;
import app.protobuf.GoodsServerContent.GoodsType;
import app.protobuf.GoodsServerContent.Quality;

import com.google.common.collect.Maps;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class EquipmentForgeGroup{

    final String name;

    final EnumMap<Quality, EquipmentForgeData> forgeDataMap;

    EquipmentForgeGroup(String name, List<ObjectParser> list,
            GoodsDatas goodsDatas, VendingMachine systemShop){

        this.name = name;

        forgeDataMap = Maps.newEnumMap(Quality.class);
        for (ObjectParser p : list){
            int intQuality = p.getIntKey("quality");
            Quality quality = checkNotNull(Quality.valueOf(intQuality),
                    "%s 配置了无效的品质，quality: %s", this, intQuality);

            EquipmentForgeData data = new EquipmentForgeData(this, quality, p,
                    goodsDatas, systemShop);

            checkArgument(forgeDataMap.put(quality, data) == null,
                    "%s 配置了重复的品质，quality：%s", this, quality);
        }

        for (Quality quality : Quality.values()){
            checkNotNull(forgeDataMap.get(quality), "%s 配置中缺少 %s品质的数据", this,
                    quality);
        }
    }

    public EquipmentForgeData getForgeData(Quality quality){
        return forgeDataMap.get(quality);
    }

    public static class EquipmentForgeData{
//        private static final int DENOMINATOR = 100;

        final Quality quality;

//        // 锻造值
//        final int forgeAmount;
//
//        // 提升等级系数，分母100
//        final int upgradeCoefficient;

        final boolean isBroadcast;

        final UpgradeData upgradeData;

//        private transient final int upgradeDenominator;

        private EquipmentForgeData(Object master, Quality quality,
                ObjectParser p, GoodsDatas goodsDatas, VendingMachine systemShop){
            this.quality = quality;

//            forgeAmount = p.getIntKey("forge_amount");
//            checkArgument(forgeAmount > 0, "%s 配置的锻造值必须大于0", master);
//
//            upgradeCoefficient = p
//                    .getIntKey("upgrade_coefficient", DENOMINATOR);
//            checkArgument(upgradeCoefficient > 0
//                    && upgradeCoefficient <= DENOMINATOR,
//                    "%s 中存在无效的系数，必须>=0 && <=100，upgradeCoefficient: %s",
//                    master, upgradeCoefficient);

            isBroadcast = p.getBooleanKey("is_broadcast");

            upgradeData = new UpgradeData(master, p, goodsDatas, systemShop);

            checkArgument(upgradeData.getUpgradeMoneyCost() > 0,
                    "%s 中消耗物品没有配置银两消耗", master);

            if (upgradeData.getUpgradeGoods() != null){
                checkArgument(
                        upgradeData.getUpgradeGoods().getType() != GoodsType.EQUIPMENT,
                        "%s 中存在无效的消耗物品，不能是装备类型, %s", master,
                        upgradeData.getUpgradeGoods());
            }

            for (GoodsData goods : upgradeData.getSubstituteGoods()){
                checkArgument(goods.getType() != GoodsType.EQUIPMENT,
                        "%s 中存在无效的消耗替代物品，不能是装备类型, %s", master, goods);
            }

            checkArgument(upgradeData.getUpgradeMaxTimes() < 4096,
                    "装备升级最大进阶次数必须小于4096");

//            long maxDenominator = forgeAmount * DENOMINATOR;
//            checkArgument(maxDenominator > 0
//                    && maxDenominator <= Integer.MAX_VALUE,
//                    "%s 中配置的锻造值太大了, %s", master, forgeAmount);
//
//            upgradeDenominator = forgeAmount * DENOMINATOR;
        }

//        public boolean tryUpgrade(int forgeAmount){
//            long rate = 1L * forgeAmount * upgradeCoefficient; // 转成long，省的出现overflow
//            return RandomNumber.getRate(upgradeDenominator, true) < rate;
//        }

        public UpgradeData getUpgradeData(){
            return upgradeData;
        }

        public boolean isBroadcast(){
            return isBroadcast;
        }
    }
}
