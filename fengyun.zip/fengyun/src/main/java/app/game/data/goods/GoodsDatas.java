package app.game.data.goods;

import static com.mokylin.sink.util.Preconditions.*;

import java.util.Collection;
import java.util.List;

import app.game.data.GameObjects;
import app.game.data.PrizeConfigs;
import app.game.data.QualityRelatedDatas;
import app.game.data.SingleSpriteStats;
import app.game.data.scene.NormalSceneDatas;
import app.game.data.scene.Plunders;
import app.game.data.spell.FightStates;
import app.game.data.spell.Spells;
import app.game.shop.Shops;
import app.protobuf.GoodsContent.SpellBookDataProto.SpellType;
import app.utils.VariableConfig;

import com.google.inject.Inject;
import com.mokylin.collection.IntHashMap;
import com.mokylin.sink.util.parse.ObjectParser;

public class GoodsDatas{

    private final IntHashMap<GoodsData> goods;

    private final IntHashMap<EquipmentData> equipments;

    private final IntHashMap<MountEquipmentData> mountEquipments;

    private final IntHashMap<MedicineData> medicines;

    private final IntHashMap<TransportGoodsData> transports;

    private final IntHashMap<NormalGoodsData> normals;

    private final IntHashMap<TaskBookData> taskBooks;

    private final IntHashMap<SpellBookData> spellBooks;

    private final IntHashMap<PanelGoodsData> panels;

    private final IntHashMap<PackageData> packages;

    private final IntHashMap<SpellXinfaData> xinfas;

    private final IntHashMap<YuanbaoPackageData> yuanbaoPackages;

    private final IntHashMap<LegendCardData> legendCards;

    private final IntHashMap<CritCardData> critCards;

    // 神兵技能书
    private final SpellBookData[] superWeaponSpellBooks;

    // 宝石，1阶开始
    private final GemGoodsData[] gems;

    private final GoodsData perfectReliveGoods;

    private final GoodsData paidChatGoods;

    private final GoodsData assistTransportGoods;

    private final GoodsRandomer phoenixGoodsRandomer;

    @Inject
    GoodsDatas(GameObjects go, SingleSpriteStats spriteStats,
            FightStates fightStates, EquipmentAddedStatGroups addedStatGroups,
            QualityRelatedDatas qualityDatas, TaozDatas taozhuangs,
            VariableConfig config){
        goods = new IntHashMap<GoodsData>();

        // medicine
        List<ObjectParser> data = go.loadFile(MedicineData.LOCATION);
        medicines = new IntHashMap<MedicineData>(data.size());
        for (ObjectParser p : data){
            MedicineData m = new MedicineData(p, fightStates, spriteStats);
            checkArgument(goods.putIfAbsent(m.id, m) == null, "物品id冲突: %s %s",
                    m, goods.get(m.id));
            medicines.put(m.id, m); // 总物品表没冲突, 这里一定没冲突
        }

        // equipment
        equipments = new IntHashMap<EquipmentData>();
        data = go.loadFile(EquipmentData.HERO_LOCATION);
        for (ObjectParser p : data){
            EquipmentData e = new EquipmentData(p, spriteStats,
                    addedStatGroups, qualityDatas, taozhuangs);
            checkArgument(goods.putIfAbsent(e.id, e) == null, "物品id冲突: %s %s",
                    e, goods.get(e.id));
            equipments.put(e.id, e);
        }
        for (EquipmentData edata : equipments.values()){
            edata.initNextLevel(equipments);
        }

        data = go.loadFile(EquipmentData.MOUNT_LOCATION);
        mountEquipments = new IntHashMap<MountEquipmentData>(data.size());
        for (ObjectParser p : data){
            MountEquipmentData e = new MountEquipmentData(p, spriteStats,
                    addedStatGroups, qualityDatas);
            checkArgument(goods.putIfAbsent(e.id, e) == null, "物品id冲突: %s %s",
                    e, goods.get(e.id));
            mountEquipments.put(e.id, e);
        }

        // transportation
        data = go.loadFile(TransportGoodsData.LOCATION);
        transports = new IntHashMap<TransportGoodsData>(data.size());
        for (ObjectParser p : data){
            TransportGoodsData s = new TransportGoodsData(p);
            checkArgument(goods.putIfAbsent(s.id, s) == null, "物品id冲突: %s %s",
                    s, goods.get(s.id));
            transports.put(s.id, s);
        }

        // taskBooks
        data = go.loadFile(TaskBookData.LOCATION);
        taskBooks = new IntHashMap<TaskBookData>(data.size());
        for (ObjectParser p : data){
            TaskBookData s = new TaskBookData(p);
            checkArgument(goods.putIfAbsent(s.id, s) == null, "物品id冲突: %s %s",
                    s, goods.get(s.id));
            taskBooks.put(s.id, s);
        }

        // spellBooks
        data = go.loadFile(SpellBookData.LOCATION);
        spellBooks = new IntHashMap<SpellBookData>(data.size());
        for (ObjectParser p : data){
            SpellBookData s = new SpellBookData(p);
            checkArgument(goods.putIfAbsent(s.id, s) == null, "物品id冲突: %s %s",
                    s, goods.get(s.id));
            spellBooks.put(s.id, s);
        }

        // normal
        data = go.loadFile(NormalGoodsData.LOCATION);
        normals = new IntHashMap<NormalGoodsData>(data.size());
        for (ObjectParser p : data){
            NormalGoodsData s = new NormalGoodsData(p);
            checkArgument(goods.putIfAbsent(s.id, s) == null, "物品id冲突: %s %s",
                    s, goods.get(s.id));
            normals.put(s.id, s);
        }

        // panel
        data = go.loadFile(PanelGoodsData.LOCATION);
        panels = new IntHashMap<PanelGoodsData>(data.size());
        for (ObjectParser p : data){
            PanelGoodsData s = new PanelGoodsData(p);
            checkArgument(goods.putIfAbsent(s.id, s) == null, "物品id冲突: %s %s",
                    s, goods.get(s.id));
            panels.put(s.id, s);
        }

        // packages
        data = go.loadFile(PackageData.LOCATION);
        packages = new IntHashMap<PackageData>();
        for (ObjectParser p : data){
            PackageData s = new PackageData(p);
            checkArgument(goods.putIfAbsent(s.id, s) == null, "物品id冲突: %s %s",
                    s, goods.get(s.id));
            packages.put(s.id, s);
        }

        // xinfa
        data = go.loadFile(SpellXinfaData.LOCATION);
        xinfas = new IntHashMap<SpellXinfaData>();
        for (ObjectParser p : data){
            SpellXinfaData s = new SpellXinfaData(p);
            checkArgument(goods.putIfAbsent(s.id, s) == null, "物品id冲突: %s %s",
                    s, goods.get(s.id));
            xinfas.put(s.id, s);
        }

        // 元宝礼包
        data = go.loadFile(YuanbaoPackageData.LOCATION);
        yuanbaoPackages = new IntHashMap<YuanbaoPackageData>();
        for (ObjectParser p : data){
            YuanbaoPackageData s = new YuanbaoPackageData(p);
            checkArgument(goods.putIfAbsent(s.id, s) == null, "物品id冲突: %s %s",
                    s, goods.get(s.id));
            yuanbaoPackages.put(s.id, s);
        }

        // 传说卡
        data = go.loadFile(LegendCardData.LOCATION);
        legendCards = new IntHashMap<LegendCardData>();
        for (ObjectParser p : data){
            LegendCardData s = new LegendCardData(p);
            checkArgument(goods.putIfAbsent(s.id, s) == null, "物品id冲突: %s %s",
                    s, goods.get(s.id));
            legendCards.put(s.id, s);
        }

        // 暴击卡
        data = go.loadFile(CritCardData.LOCATION);
        critCards = new IntHashMap<CritCardData>();
        for (ObjectParser p : data){
            CritCardData s = new CritCardData(p, fightStates);
            checkArgument(goods.putIfAbsent(s.id, s) == null, "物品id冲突: %s %s",
                    s, goods.get(s.id));
            critCards.put(s.id, s);
        }

        // gems
        data = go.loadFile(GemGoodsData.LOCATION);
        checkArgument(data.size() < 15, "宝石个数不能超过15个，用4个bit表示阶数");
        gems = new GemGoodsData[data.size()];
        for (ObjectParser p : data){
            GemGoodsData s = new GemGoodsData(p);
            checkArgument(goods.putIfAbsent(s.id, s) == null, "物品id冲突: %s %s",
                    s, goods.get(s.id));

            checkArgument(s.gemLevel <= gems.length, "宝石 %s 的阶数比宝石总阶数还大", s);
            checkArgument(gems[s.gemLevel - 1] == null, "宝石阶数冲突，%s %s", s,
                    gems[s.gemLevel - 1]);
            gems[s.gemLevel - 1] = s;
        }

        perfectReliveGoods = checkNotNull(goods.get(config.GOODS_RELIVE_ID),
                "完美复活物品没找到, id: %s", config.GOODS_RELIVE_ID);

        paidChatGoods = checkNotNull(goods.get(config.PAID_CHAT_GOODS_ID),
                "喇叭物品没找到, id: %s", config.PAID_CHAT_GOODS_ID);

        assistTransportGoods = checkNotNull(
                goods.get(config.ASSIST_TRANSPORT_GOODS_ID), "飞鞋物品没找到, id: %s",
                config.ASSIST_TRANSPORT_GOODS_ID);

        phoenixGoodsRandomer = GoodsRandomer.newRandomer("凤血炼制",
                config.PHOENIX_REFINE_GOODS_CONFIG, this);

        // 神兵技能书
        superWeaponSpellBooks = new SpellBookData[VariableConfig.SUPER_WEAPON_COUNT];
        for (SpellBookData s : spellBooks.values()){
            if (s.type == SpellType.SUPER_WEAPON){
                checkArgument(
                        superWeaponSpellBooks[s.requiredObjectLevel - 1] == null,
                        "神兵技能书重复, %s, %s", s,
                        superWeaponSpellBooks[s.requiredObjectLevel - 1]);

                superWeaponSpellBooks[s.requiredObjectLevel - 1] = s;
            }
        }

        for (int i = 0; i < superWeaponSpellBooks.length; i++){
            checkNotNull(superWeaponSpellBooks[i], "神兵-%s 对应的技能书没有配置", i + 1);
        }
    }

    public GoodsData get(int id){
        return goods.get(id);
    }

    public EquipmentData getEquipment(int id){
        return equipments.get(id);
    }

    public MedicineData getMedicine(int id){
        return medicines.get(id);
    }

    public TransportGoodsData getTransportation(int id){
        return transports.get(id);
    }

    public TaskBookData getTaskBook(int id){
        return taskBooks.get(id);
    }

    public SpellBookData getSpellBook(int id){
        return spellBooks.get(id);
    }

    public NormalGoodsData getNormal(int id){
        return normals.get(id);
    }

    public PanelGoodsData getPanel(int id){
        return panels.get(id);
    }

    public YuanbaoPackageData getYuanbaoPackage(int id){
        return yuanbaoPackages.get(id);
    }

    public CritCardData getCritCard(int id){
        return critCards.get(id);
    }

    public GoodsData getPerfectReliveGoods(){
        return perfectReliveGoods;
    }

    public GoodsData getPaidChatGoods(){
        return paidChatGoods;
    }

    public GoodsData getAssistTransportGoods(){
        return assistTransportGoods;
    }

    public GemGoodsData getGem(int id){
        if (id > 0 && id <= gems.length)
            return gems[id - 1];

        return null;
    }

    public GemGoodsData[] getGems(){
        return gems;
    }

    public GoodsData getPhoenixGoods(){
        return phoenixGoodsRandomer.getData();
    }

    public GoodsRandomer getPhoenixGoodsRandomer(){
        return phoenixGoodsRandomer;
    }

    Collection<EquipmentData> getEquipments(){
        return equipments.values();
    }

    public SpellBookData getSuperWeaponSpellBook(int id){
        if (id > 0 && id <= superWeaponSpellBooks.length)
            return superWeaponSpellBooks[id - 1];
        return null;
    }

    // --------- init ----------

    public void doCheck(){
        for (GoodsData g : goods.values()){
            checkNotNull(g.getProtoBytes(), "%s 的ProtoBytes为null", g);
            checkNotNull(g.getGoodsReplyInfoMsg(),
                    "%s 的GoodsReplyInfoMsg为null", g);
        }
    }

    public void initDestData(NormalSceneDatas sceneDatas){
        for (TransportGoodsData data : transports.values()){
            data.initDestData(sceneDatas);
        }
    }

    public void initSpell(Spells spells){
        for (SpellBookData data : spellBooks.values()){
            data.initSpell(spells);
        }

        for (SpellXinfaData data : xinfas.values()){
            data.initXinfa(spells.getXinfaEffects());
        }
    }

    public void initPlunders(Plunders plunders){
        for (PackageData data : packages.values()){
            data.initPlunder(plunders);
        }

        for (LegendCardData data : legendCards.values()){
            data.initPlunder(plunders);
        }
    }

    public void initShops(Shops shops){
        for (int i = 1; i < gems.length; i++){
            gems[i - 1].init(gems[i], shops.getSystemShop());
        }
    }

    public void initPrizes(PrizeConfigs prizeConfigs){
        for (YuanbaoPackageData data : yuanbaoPackages.values()){
            data.initPrize(prizeConfigs);
        }
    }
}
