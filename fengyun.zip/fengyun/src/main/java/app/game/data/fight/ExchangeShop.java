package app.game.data.fight;

import static com.mokylin.sink.util.Preconditions.checkArgument;

import java.util.List;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.data.GameObjects;
import app.game.data.goods.GoodsDatas;
import app.game.data.goods.GoodsWrapper;
import app.game.module.ShopMessages;
import app.protobuf.ConfigContent.ExchangeShopGoodsProto;
import app.protobuf.ConfigContent.ExchangeShopProto;
import app.protobuf.ConfigContent.ExchangeShopType;

import com.mokylin.collection.IntHashMap;
import com.mokylin.sink.util.parse.ObjectParser;

public class ExchangeShop{

    private final ExchangeShopType shopType;
    private final ExchangeShopGoods[] goods;
    private final IntHashMap<ExchangeShopGoods> goodsMap;

    private final ChannelBuffer shopInfoMsg;

    public ExchangeShop(ExchangeShopType shopType, String location,
            GameObjects go, GoodsDatas goodsDatas){
        this.shopType = shopType;
        List<ObjectParser> data = go.loadFile(location);
        checkArgument(data.size() > 0, "兑换商店%s 没有配置，location: %s", shopType,
                location);

        goods = new ExchangeShopGoods[data.size()];
        this.goodsMap = new IntHashMap<>(data.size());

        for (int i = 0; i < data.size(); i++){
            ExchangeShopGoods g = new ExchangeShopGoods(shopType, data.get(i),
                    goodsDatas);
            goods[i] = g;

            goodsMap.putUnique(g.id, g);
        }

        ExchangeShopProto proto = encode();
        shopInfoMsg = ShopMessages.getExchangeShopMsg(proto);
    }

    public ExchangeShopGoods getGoods(int id){
        return goodsMap.get(id);
    }

    public ChannelBuffer getShopMsg(){
        return shopInfoMsg;
    }

    private ExchangeShopProto encode(){
        ExchangeShopProto.Builder builder = ExchangeShopProto.newBuilder();
        builder.setType(shopType);
        for (ExchangeShopGoods g : goods){
            builder.addGoods(g.encode());
        }

        return builder.build();
    }

    public static class ExchangeShopGoods{
        public final ExchangeShopType shopType;

        private final int id;

        public final GoodsWrapper goodsWrapper;

        public final int cost;

        public final int dailyLimit;

        private final String tabName;

        private ExchangeShopGoods(ExchangeShopType shopType, ObjectParser p,
                GoodsDatas goodsDatas){
            this.shopType = shopType;

            this.id = p.getIntKey("id");
            checkArgument(id > 0, "%s 商店里的id必须>0", shopType);

            String item = p.getKey("goods_item");
            this.goodsWrapper = GoodsWrapper.parse(shopType, goodsDatas, item);

            this.tabName = p.getKey("tab_name");

            this.cost = p.getIntKey("cost");
            this.dailyLimit = p.getIntKey("daily_limit");

            checkArgument(cost > 0, "%s 商店里的价格必须>0: %s", shopType, item);
            checkArgument(dailyLimit >= 0, "%s 商店里的物品每日兑换限制必须>=0: %s",
                    shopType, item);
        }

        private ExchangeShopGoodsProto encode(){
            ExchangeShopGoodsProto.Builder builder = ExchangeShopGoodsProto
                    .newBuilder();
            builder.setId(id);
            builder.setGoods(goodsWrapper.encode4Client());
            builder.setCost(cost);
            builder.setDailyLimit(dailyLimit);
            builder.setTabName(tabName);
            return builder.build();
        }
    }
}
