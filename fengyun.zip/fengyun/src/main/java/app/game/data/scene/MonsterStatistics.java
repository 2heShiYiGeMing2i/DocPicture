package app.game.data.scene;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.data.ServerData;
import app.game.module.scene.SceneMessages;
import app.game.service.WorldService;

import com.mokylin.sink.util.BufferUtil;
import com.mokylin.sink.util.Empty;
import com.mokylin.sink.util.annotation.SelfWriteMultiThreadRead;

/**
 * @author Liwei
 *
 */
public class MonsterStatistics{

    private static final int STATUS_NO_REFRESH = 0;

    private static final int STATUS_REFRESHED = 1;

    private static final int STATUS_KILLED = 2;

    public static MonsterStatistics newStatistics(WorldService worldService,
            ServerData serverData, SceneMonsterData monData, int lineNumber,
            boolean isDeadBroadcast){
        assert monData != null;
        return new MonsterStatistics(worldService, serverData, monData,
                lineNumber, isDeadBroadcast);
    }

    private final WorldService worldService;

    private final ServerData serverData;

    /**
     * MonsterData
     */
    private final SceneMonsterData monData;

    private final int lineNumber;

    private final boolean isDeadBroadcast;

    private volatile Statistics statistics;

    private MonsterStatistics(WorldService worldService, ServerData serverData,
            SceneMonsterData bossData, int lineNumber, boolean isDeadBroadcast){
        this.worldService = worldService;
        this.serverData = serverData;
        this.monData = bossData;
        this.lineNumber = lineNumber;
        this.isDeadBroadcast = isDeadBroadcast;
        statistics = new Statistics(0, STATUS_NO_REFRESH, Empty.BYTE_ARRAY);
    }

    public SceneMonsterData getMonsterData(){
        return monData;
    }

    public void writeTo(ChannelBuffer buffer){
        statistics.writeTo(buffer);
    }

    @SelfWriteMultiThreadRead
    public void onRefreshed(long refreshTime){
        statistics = statistics.newRefreshStatistics(refreshTime);
    }

    @SelfWriteMultiThreadRead
    public void onThisBeenKilled(long heroId, byte[] killerName){
        assert statistics.status == STATUS_REFRESHED;

        statistics = statistics.newKilledStatistics(killerName);

        if (isDeadBroadcast){
            // 广播消息，我被人干掉啦
            if (serverData == null){
                worldService.broadcast(SceneMessages.killWorldBossMsg(
                        monData.getMonsterData().id, lineNumber,
                        statistics.refreshTime, heroId, killerName));
            } else{
                worldService
                        .broadcastToEnteredFirstSceneHeroWithSameServerData(
                                SceneMessages.killWorldBossMsg(
                                        monData.getMonsterData().id,
                                        lineNumber, statistics.refreshTime,
                                        heroId, killerName), serverData, 0);
            }
        }
    }

    private static class Statistics{
        /**
         * 刷新时间
         */
        private final long refreshTime;

        /**
         * 状态，0-未刷新 1-已刷新（未被击杀） 2-已击杀
         */
        private final int status;

        /**
         * 状态为已击杀时有效，表示击杀者名字
         */
        private final byte[] killerName;

        private Statistics(long refreshTime, int status, byte[] killerName){
            this.refreshTime = refreshTime;
            this.status = status;
            this.killerName = killerName;
        }

        private void writeTo(ChannelBuffer buffer){
            BufferUtil.writeVarInt32(buffer, status);
            BufferUtil.writeVarInt64(buffer, refreshTime);
            if (status == STATUS_KILLED){
                BufferUtil.writeUTF(buffer, killerName);
            }
        }

        private Statistics newRefreshStatistics(long refreshTime){
            return new Statistics(refreshTime, STATUS_REFRESHED,
                    Empty.BYTE_ARRAY);
        }

        private Statistics newKilledStatistics(byte[] killerName){
            return new Statistics(refreshTime, STATUS_KILLED, killerName);
        }

    }
}
