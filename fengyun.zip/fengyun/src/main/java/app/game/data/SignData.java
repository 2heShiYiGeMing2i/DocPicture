package app.game.data;

import static com.mokylin.sink.util.Preconditions.checkArgument;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.module.WelfareMessages;

import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class SignData{

    final int id;

    final int signTimes;

    final Prize prize;

    private final ChannelBuffer collectPrizeMsg;

    SignData(int id, ObjectParser p, PrizeConfigs prizes){

        this.id = id;
        signTimes = p.getIntKey("sign_times");
        checkArgument(signTimes >= 1 && signTimes <= 28,
                "签到奖励中领取需要的签到次数无效，1 <= 次数 <= 28, signTimes: %s", signTimes);

        String prizeName = p.getKey("prize");
        PrizeConfig prizeConfig = prizes.get(prizeName);

        checkArgument(!prizeConfig.hasExipreTimeGoods(), "签到奖励中配置了有过期时间的物品");
        checkArgument(!prizeConfig.isVarPrize(), "签到奖励中配置了随机属性的物品");
        checkArgument(!prizeConfig.hasUnbindedGoods(), "签到奖励中配置了非绑定的物品");
        checkArgument(!prizeConfig.isRaceDiff(), "签到奖励中配置了跟职业相关的物品");

        prize = prizeConfig.random();

        collectPrizeMsg = WelfareMessages.collectSignPrizeMsg(id);
    }

    public int getId(){
        return id;
    }

    public int getSignTimes(){
        return signTimes;
    }

    public Prize getPrize(){
        return prize;
    }

    public ChannelBuffer getCollectPrizeMsg(){
        return collectPrizeMsg;
    }
}
