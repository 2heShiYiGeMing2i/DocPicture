package app.game.data;

import static com.mokylin.sink.util.Preconditions.*;

import java.util.EnumMap;
import java.util.List;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.module.HeroMiscMessages;
import app.protobuf.ConfigContent.ShengWangConfig;
import app.protobuf.ConfigContent.ShengWangType;

import com.google.inject.Inject;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class ShengWangDatas{

    private static final String TASK_LOCATION = "config/data/system/sheng_wang_task.txt";

    private static final String EXCHANGE_LOCATION = "config/data/system/sheng_wang_exchange.txt";

    private final ShengWangTaskData[] datas;

    private final EnumMap<ShengWangType, ShengWangTaskData> dataMap;

    private final ShengWangExchangeGoods[] exchangeGoods;

    @Inject
    ShengWangDatas(GameObjects go, PrizeConfigs prizeConfigs){

        List<ObjectParser> list = go.loadFile(TASK_LOCATION);
        checkArgument(list.size() > 0, "声望任务数据没有配置，%s", TASK_LOCATION);

        datas = new ShengWangTaskData[list.size()];
        dataMap = new EnumMap<>(ShengWangType.class);
        int i = 0;
        for (ObjectParser p : list){
            ShengWangTaskData data = new ShengWangTaskData(p);

            checkArgument(dataMap.put(data.type, data) == null, "声望类型重复，%s",
                    data.type);
            datas[i++] = data;
        }

        list = go.loadFile(EXCHANGE_LOCATION);
        checkArgument(list.size() > 0, "声望兑换物品数据没有配置，%s", EXCHANGE_LOCATION);
        checkArgument(list.size() <= 16, "声望兑换物品太多了，最多只能是16个，%s",
                EXCHANGE_LOCATION);
        exchangeGoods = new ShengWangExchangeGoods[list.size()];

        i = 0;
        int prevShengWang = 0;
        for (ObjectParser p : list){
            int shengWang = p.getIntKey("sheng_wang");
            checkArgument(prevShengWang < shengWang, "声望兑换物品所需的声望必须从小到大配置, %s",
                    EXCHANGE_LOCATION);

            String prizeName = p.getKey("prize");

            PrizeConfig prizeConfig = checkNotNull(prizeConfigs.get(prizeName),
                    "声望兑换奖励没找到, %s", prizeName);

            exchangeGoods[i] = new ShengWangExchangeGoods(i, shengWang,
                    prizeConfig.random());
            ++i;
        }
    }

    public ShengWangTaskData get(ShengWangType type){
        return dataMap.get(type);
    }

    public int getExchangeGoodsSize(){
        return exchangeGoods.length;
    }

    public ShengWangExchangeGoods getExchangeGoods(int pos){
        return exchangeGoods[pos];
    }

    public ShengWangConfig generateProto(){
        ShengWangConfig.Builder builder = ShengWangConfig.newBuilder();

        for (ShengWangTaskData data : datas){
            builder.addType(data.type);
            builder.addAmount(data.amount);
            builder.addMaxTimes(data.maxTimes);
        }

        for (ShengWangExchangeGoods goods : exchangeGoods){
            builder.addRequiredShengwang(goods.requiredShengWang);
            builder.addPrize(goods.prize.encode4Client());
        }

        return builder.build();
    }

    public static class ShengWangExchangeGoods{

        public final int requiredShengWang;

        public final Prize prize;

        public final ChannelBuffer buyGoodsMsg;

        private ShengWangExchangeGoods(int pos, int shengWang, Prize prize){
            super();
            this.requiredShengWang = shengWang;
            this.prize = prize;
            this.buyGoodsMsg = HeroMiscMessages.buyShengWangGoodsMsg(pos);
        }

    }
}
