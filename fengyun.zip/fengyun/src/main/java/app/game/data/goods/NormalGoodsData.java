/**
 * 
 */
package app.game.data.goods;

import app.game.data.GameObjects;
import app.protobuf.GoodsContent.GoodsDataProto;
import app.protobuf.GoodsServerContent.GoodsType;

import com.google.protobuf.ByteString;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * 普通物品
 * 
 * @author Liwei
 * 
 */
public class NormalGoodsData extends GoodsData{

    static final String LOCATION = GameObjects.GOODS_BASE_LOCATION
            + "normal.txt";

    private final GoodsDataProto proto;

    private final byte[] protoBytes;

    private final ByteString protoByteString;

    NormalGoodsData(ObjectParser p){
        super(p, GoodsType.NORMAL);

        proto = encode().build();
        protoBytes = processProtoBytes(proto.toByteArray());
        protoByteString = ByteString.copyFrom(protoBytes);
    }

    public GoodsDataProto getProto(){
        return proto;
    }

    @Override
    public byte[] getProtoBytes(){
        return protoBytes;
    }

    @Override
    public ByteString getProtoByteString(){
        return protoByteString;
    }

    @Override
    public int getAuctionType(){
        return 123;
    }
}
