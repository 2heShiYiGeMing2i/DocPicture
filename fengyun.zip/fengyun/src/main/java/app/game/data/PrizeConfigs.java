package app.game.data;

import static com.mokylin.sink.util.Preconditions.*;

import java.util.HashMap;
import java.util.List;

import app.game.data.goods.GoodsDatas;
import app.game.data.scene.PlunderGroups;
import app.utils.VariableConfig;

import com.google.common.collect.Maps;
import com.google.inject.Inject;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class PrizeConfigs{

    private static final String LOCATION = "config/data/prize.txt";

    private final HashMap<String, PrizeConfig> prizeConfigMap;

    private final PrizeConfig singleStoryPrize;

    @Inject
    PrizeConfigs(GameObjects go, GoodsDatas goodsDatas, PlunderGroups groups,
            VariableConfig config){
        List<ObjectParser> data = go.loadFile(LOCATION);

        prizeConfigMap = Maps.newHashMapWithExpectedSize(data.size());
        for (ObjectParser p : data){
            PrizeConfig prizeConfig = new PrizeConfig(p, goodsDatas, groups);

            checkArgument(
                    prizeConfigMap.put(prizeConfig.name, prizeConfig) == null,
                    "奖励name冲突: %s", prizeConfig.name);
        }

        singleStoryPrize = checkNotNull(
                prizeConfigMap.get(config.SINGLE_STORY_PRIZE),
                "新手剧情奖励没找到，name=%s", config.SINGLE_STORY_PRIZE);

        goodsDatas.initPrizes(this);
    }

    public PrizeConfig get(String name){
        return prizeConfigMap.get(name);
    }

    public PrizeConfig getSingleStoryPrize(){
        return singleStoryPrize;
    }
}
