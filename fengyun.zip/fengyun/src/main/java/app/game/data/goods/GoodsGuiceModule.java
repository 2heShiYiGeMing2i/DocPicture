package app.game.data.goods;

import app.game.data.QualityRelatedDatas;

import com.google.inject.AbstractModule;
import com.google.inject.Singleton;

public class GoodsGuiceModule extends AbstractModule{

    @Override
    protected void configure(){
        binder().requireExplicitBindings();
        bind(GoodsDatas.class).in(Singleton.class);
        bind(GoodsContainerUnlockDatas.class).in(Singleton.class);
        bind(EquipmentAddedStatGroups.class).in(Singleton.class);
        bind(QualityRelatedDatas.class).in(Singleton.class);
        bind(EquipmentForgeDatas.class).in(Singleton.class);
        bind(TaozDatas.class).in(Singleton.class);
    }

}
