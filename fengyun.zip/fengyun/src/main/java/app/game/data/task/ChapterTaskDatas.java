package app.game.data.task;

import static com.mokylin.sink.util.Preconditions.checkArgument;
import static com.mokylin.sink.util.Preconditions.checkNotNull;

import java.util.EnumMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.data.GameObjects;
import app.game.data.PrizeConfig;
import app.game.data.PrizeConfigs;
import app.game.data.goods.GoodsDatas;
import app.game.data.scene.CollectObjects;
import app.game.data.scene.MonsterData;
import app.game.data.scene.MonsterDatas;
import app.game.data.scene.Npcs;
import app.game.data.scene.SceneDatas;
import app.game.module.TaskMessages;
import app.protobuf.ConfigContent.TaskConfig;
import app.protobuf.HeroServerContent.RaceId;
import app.protobuf.TaskContent.TaskDataProto;
import app.protobuf.TaskContent.TaskRelatedFunction;

import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.google.protobuf.ByteString;
import com.mokylin.collection.IntHashMap;
import com.mokylin.collection.LeftIntPair;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class ChapterTaskDatas{

    static final String LOCATION = "config/data/task/chapter_task.txt";

    private final ChapterTaskData[][] chapterTasks;

    /**
     * 这个值在ConfigService中用过之后会清空，变成null
     */
    private ByteString[] chapterNames;

    private final LeftIntPair<ByteString[]> lastChapterTaskNames;

    private final ChapterTaskData firstChapterTask;

    private final ChapterTaskData lastChapterTask;

    final int maxUseTaskId;

    private final EnumMap<RaceId, ChannelBuffer[]> chapterTaskBufferMap;

    private final int chapterCount;

    private final EnumMap<TaskRelatedFunction, ChannelBuffer> funcMsgMap;

    ChapterTaskDatas(GameObjects go, Npcs npcs, GoodsDatas goodsDatas,
            MonsterDatas monsters, PrizeConfigs prizes,
            CollectObjects collectObjects, SceneDatas sceneDatas,
            IntHashMap<MonsterData> monLevelMap){

        for (TaskRelatedFunction func : TaskRelatedFunction.values()){
            checkArgument(func.getNumber() > 0 && func.getNumber() <= 64,
                    "新功能开启通过移位实现，最大不能超过64，如果确实有这么多个新功能，那么英雄保存一个long数组也可以");
        }

        List<ObjectParser> data = go.loadFile(LOCATION);

        IntHashMap<LinkedList<ObjectParser>> map = new IntHashMap<>();

        for (ObjectParser p : data){
            int chapter = p.getIntKey("chapter");
            checkArgument(chapter > 0, "剧情任务的章节存在非法数据，章节数<=0", chapter);

            LinkedList<ObjectParser> list = map.get(chapter);
            if (list == null){
                list = new LinkedList<>();
                map.put(chapter, list);
            }

            list.add(p);
        }

        checkArgument(!map.isEmpty(), "剧情任务数据没有配置");

        chapterTasks = new ChapterTaskData[map.size()][];
        chapterNames = new ByteString[map.size()];
        ByteString[][] chapterTaskNames = new ByteString[map.size()][];

        Set<String> nameSet = Sets.newHashSet();

        int taskIdCounter = 0;
        ChapterTaskData prevTask = null;
        for (int chapter = 1; chapter <= map.size(); chapter++){
            LinkedList<ObjectParser> list = checkNotNull(map.get(chapter),
                    "没有找到第%s章的剧情任务", chapter);

            int chapterIdx = chapter - 1;
            String chapterName = list.getLast().getKey("chapter_name");
            checkArgument(!chapterName.isEmpty(), "第%s章剧情任务的章节名称为空", chapter);
            chapterNames[chapterIdx] = ByteString.copyFromUtf8(chapterName);

            chapterTasks[chapterIdx] = new ChapterTaskData[list.size()];

            ByteString[] taskNames = chapterTaskNames[chapterIdx] = new ByteString[list
                    .size()];

            int index = 0;
            for (ObjectParser p : list){

                String taskName = p.getKey("task_name");

                taskNames[index] = ByteString.copyFromUtf8(taskName);

                String taskToStr = chapter + "章剧情任务-" + taskName;
                TaskData taskData = TaskData.newChapterTask(p, npcs, monsters,
                        goodsDatas, collectObjects, sceneDatas, monLevelMap,
                        taskToStr);

                checkArgument(nameSet.add(taskData.name), "剧情任务的名称重复，任务名称：%s",
                        taskData.name);

                String prizeName = p.getKey("prize");
                PrizeConfig prizeConfig = checkNotNull(prizes.get(prizeName),
                        "%s的奖励不存在， prize: %s", taskToStr, prizeName);

                checkArgument(!prizeConfig.hasExipreTimeGoods(),
                        "%s 奖励中配置了有过期时间的物品", taskToStr);
                checkArgument(!prizeConfig.isVarPrize(), "%s 奖励中配置了随机属性的物品",
                        taskToStr);
                checkArgument(!prizeConfig.hasUnbindedGoods(),
                        "%s 奖励中配置了非绑定的物品", taskToStr);

                int intFunc = p.getIntKey("function");

                prevTask = chapterTasks[chapterIdx][index] = new ChapterTaskData(
                        ++taskIdCounter, chapter, index, taskData, prizeConfig,
                        intFunc, prevTask, taskNames);

                index++;
            }
        }

        prevTask = null;
        funcMsgMap = Maps.newEnumMap(TaskRelatedFunction.class);
        for (ChapterTaskData[] taskArray : chapterTasks){
            for (ChapterTaskData task : taskArray){
                if (prevTask != null){
                    checkArgument(prevTask.getNextTask() == task);
                }

                if (task.func != null){
                    checkArgument(
                            funcMsgMap.put(task.func, task.newFunctionMsg) == null,
                            "%s 配置了重复的新功能开启ID", task);
                }

                prevTask = task;
            }
        }
        lastChapterTask = prevTask;

        for (TaskRelatedFunction f : TaskRelatedFunction.values()){
            checkArgument(funcMsgMap.containsKey(f), "剧情任务中没有配置 %s类型的开放新功能", f);
        }

        lastChapterTaskNames = new LeftIntPair<ByteString[]>(
                chapterTaskNames.length,
                chapterTaskNames[chapterTaskNames.length - 1]);

        firstChapterTask = chapterTasks[0][0];

        maxUseTaskId = taskIdCounter;

        chapterCount = chapterTasks.length;

        chapterTaskBufferMap = Maps.newEnumMap(RaceId.class);
        for (RaceId raceId : RaceId.values()){
            ChannelBuffer[] chapterTaskBuffers = new ChannelBuffer[chapterTasks.length];
            for (int i = 0; i < chapterTasks.length; i++){
                ChapterTaskData[] tasks = chapterTasks[i];

                TaskDataProto[] protoDatas = new TaskDataProto[tasks.length];
                for (int j = 0; j < tasks.length; j++){
                    TaskDataProto.Builder builder = tasks[j].getTaskProto(
                            raceId).toBuilder();

                    // 查看任务列表数据中不需要接受任务对白和完成任务对白
                    builder.clearAcceptDialog();
                    builder.clearCompleteDialog();

                    protoDatas[j] = builder.build();
                }

                chapterTaskBuffers[i] = TaskMessages
                        .getCompletedChapterTaskMsg(i + 1, protoDatas);
            }

            chapterTaskBufferMap.put(raceId, chapterTaskBuffers);
        }
    }

    public ChapterTaskData[][] getDatas(){
        return chapterTasks;
    }

    ChapterTaskData get(int chapter, int index){

        if (chapter > 0 && chapter <= chapterTasks.length){
            ChapterTaskData[] tasks = chapterTasks[chapter - 1];
            if (index >= 0 && index < tasks.length){
                return tasks[index];
            }

            if (index >= tasks.length){
                // 如果索引超过本章的所有的任务，则查看是否有下一章，有则返回下一章第一个任务，否则返回null
                if (chapter < chapterTasks.length){
                    return chapterTasks[chapter][0];
                }
            }
        }

        if (chapter == 0){
            // 防御性，正常不可能进来的
            return chapterTasks[0][0];
        }

        return null;
    }

    public ChapterTaskData getLastChapterTask(){
        return lastChapterTask;
    }

    public ChannelBuffer getFuncMsg(TaskRelatedFunction key){
        return funcMsgMap.get(key);
    }

    public ChannelBuffer getCompletedChapterTaskBuffer(int chapter,
            RaceId raceId){
        if (chapter > 0 && chapter <= chapterCount){
            return chapterTaskBufferMap.get(raceId)[chapter - 1];
        }

        return null;
    }

    ChapterTaskData getFirstChapterTask(){
        return firstChapterTask;
    }

    LeftIntPair<ByteString[]> getLastChapterTaskInfo(){
        return lastChapterTaskNames;
    }

    void generateProto(TaskConfig.Builder builder){

        for (ByteString name : chapterNames){
            builder.addChapterName(name);
        }
        chapterNames = null; // 清掉

        for (ChapterTaskData[] datas : chapterTasks){
            builder.addChapterTaskCountList(datas.length);
        }
    }
}
