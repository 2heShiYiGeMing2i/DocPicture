package app.game.data;

import static com.mokylin.sink.util.Preconditions.*;
import app.utils.VariableConfig;

import com.google.inject.Inject;

/**
 * @author Liwei
 *
 */
public class MicroLoginData{

    private final Prize firstLoginPrize;

    private final Prize dailyLoginPrize;

    @Inject
    MicroLoginData(PrizeConfigs prizes, VariableConfig config){

        PrizeConfig prizeConfig = checkNotNull(
                prizes.get(config.LOCAL_LOGIN_FIRST_PRIZE),
                "登录器首次登陆奖励没找到：[%s]", config.LOCAL_LOGIN_FIRST_PRIZE);

        checkArgument(!prizeConfig.hasExipreTimeGoods(),
                "登录器首次登陆奖励中配置了有过期时间的物品");
        checkArgument(!prizeConfig.isVarPrize(), "登录器首次登陆奖励中配置了随机属性的物品");
        checkArgument(!prizeConfig.hasUnbindedGoods(), "登录器首次登陆奖励中配置了非绑定的物品");
        checkArgument(!prizeConfig.isRaceDiff(), "登录器首次登陆奖励中配置了跟职业相关的物品");

        firstLoginPrize = prizeConfig.random();

        prizeConfig = checkNotNull(prizes.get(config.LOCAL_LOGIN_DAILY_PRIZE),
                "登录器每日登陆奖励没找到：[%s]", config.LOCAL_LOGIN_DAILY_PRIZE);

        checkArgument(!prizeConfig.hasExipreTimeGoods(),
                "登录器每日登陆奖励中配置了有过期时间的物品");
        checkArgument(!prizeConfig.isVarPrize(), "登录器每日登陆奖励中配置了随机属性的物品");
        checkArgument(!prizeConfig.hasUnbindedGoods(), "登录器每日登陆奖励中配置了非绑定的物品");
        checkArgument(!prizeConfig.isRaceDiff(), "登录器每日登陆奖励中配置了跟职业相关的物品");

        dailyLoginPrize = prizeConfig.random();
    }

    public Prize getFirstLoginPrize(){
        return firstLoginPrize;
    }

    public Prize getDailyLoginPrize(){
        return dailyLoginPrize;
    }

}
