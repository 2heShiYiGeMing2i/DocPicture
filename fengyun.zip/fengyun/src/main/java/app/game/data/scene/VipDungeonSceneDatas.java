package app.game.data.scene;

import java.util.Collection;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.data.GameObjects;
import app.game.data.goods.GoodsDatas;
import app.utils.VariableConfig;

import com.google.inject.Inject;
import com.mokylin.collection.IntHashMap;
import com.mokylin.sink.util.parse.ObjectParser;

public class VipDungeonSceneDatas{
    private static final Logger logger = LoggerFactory
            .getLogger(VipDungeonSceneDatas.class);

    public static final String LOCATION = GameObjects.SCENE_BASE_FOLDER
            + "vip_dungeon.txt";

    private final IntHashMap<VipDungeonSceneData> map;

    @Inject
    VipDungeonSceneDatas(GameObjects go, BlockInfos blocks,
            MonsterDatas monsters, Scripts scripts, Plunders plunders, Ais ais,
            SceneTransportDatas transports, GoodsDatas goodsDatas,
            VariableConfig variableConfig,
            SceneRemoveObjectMsgCache removeMsgCache){
        logger.debug("loading vip dungeon scenes");

        List<ObjectParser> data = go.loadFile(LOCATION);

        map = new IntHashMap<>(data.size());

        for (ObjectParser p : data){
            VipDungeonSceneData scene = new VipDungeonSceneData(go, p, blocks,
                    monsters, scripts, plunders, ais, transports, goodsDatas,
                    removeMsgCache);

            map.putUnique(scene.id, scene);
        }

        // TODO 检查
    }

    void putAll(IntHashMap<SceneData> totalMap){
        for (VipDungeonSceneData sceneData : map.values()){
            totalMap.putUnique(sceneData.id, sceneData);
        }
    }

    public VipDungeonSceneData get(int id){
        return map.get(id);
    }

    Collection<VipDungeonSceneData> getAll(){
        return map.values();
    }
}
