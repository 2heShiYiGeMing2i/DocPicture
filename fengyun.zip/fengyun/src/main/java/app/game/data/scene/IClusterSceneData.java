package app.game.data.scene;

import app.cluster.client.combat.scene.AbstractLocalScene;
import app.cluster.shared.scene.AbstractRemoteClusterScene;
import app.game.module.scene.IClusterLocalDungeonService;
import app.game.module.scene.IDungeonService;
import app.message.ISender;

public interface IClusterSceneData{

    public AbstractLocalScene newLocalClusterScene(int uuid,
            IClusterLocalDungeonService dungeonService, ISender combatClient,
            long heroID);

    public AbstractRemoteClusterScene newRemoteClusterScene(int uuid,
            IDungeonService dungeonService, long creator, ISender worker);

    public int newDungeonID();

    public SceneData getSceneData();
}
