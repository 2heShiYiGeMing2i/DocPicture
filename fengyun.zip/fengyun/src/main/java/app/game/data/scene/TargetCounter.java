package app.game.data.scene;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.annotations.VisibleForTesting;

public class TargetCounter{
    private static final Logger logger = LoggerFactory
            .getLogger(TargetCounter.class);

    private static final int DEFAULT_ENTRY_COUNT = 32;
    private static final int DEFAULT_ENTRY_COUNT_TO_MOD = DEFAULT_ENTRY_COUNT - 1;

    private volatile int currentCount;

    private final Entry[] entries;

    private TargetCounter(Builder builder){
        entries = new Entry[DEFAULT_ENTRY_COUNT];

        for (int i = 0; i < DEFAULT_ENTRY_COUNT; i++){
            Entry e = builder.entries[i];
            if (e != null){
                entries[i] = e.copy();
            }
        }

        this.currentCount = builder.count;
    }

    public static Builder newBuilder(){
        return new Builder();
    }

    /**
     * 减少id对应的数量
     * @param id
     * @return 返回减完之后的总数 (不是这个id的剩余数量) -1表示这个id不存在
     */
    public int decrement(int id){
        int index = hash(id);

        synchronized (this){
            Entry e = entries[index];
            while (e != null && e.id != id){
                e = e.next;
            }

            if (e == null){
                return -1;
            }

            if (e.count > 0){
                --e.count;
                return --currentCount; // 返回总的count
            }

            logger.error("TargetCounter.decrement时, 对应id的count<=0");
            return currentCount;
        }
    }

    public int getCount(int id){
        int index = hash(id);
        Entry e = entries[index];
        while (e != null && e.id != id){
            e = e.next;
        }

        if (e != null){
            return e.count;
        }

        return -1; // 不存在
    }

    public int getCurrentCount(){
        return currentCount;
    }

    private static class Entry{
        private final int id;
        private final Entry next;
        private int count;

        private Entry(int id, int count, Entry next){
            super();
            this.id = id;
            this.count = count;
            this.next = next;
        }

        private Entry copy(){
            if (next == null){
                return new Entry(id, count, null);
            }

            return new Entry(id, count, next.copy());
        }
    }

    public static class Builder{
        private final Entry[] entries;
        private int count;

        private Builder(){
            entries = new Entry[DEFAULT_ENTRY_COUNT];
        }

        public void increment(int id){
            int index = hash(id);
            Entry first = entries[index];
            Entry e = first;
            while (e != null && e.id != id){
                e = e.next;
            }

            if (e != null){
                e.count++;
            } else{
                entries[index] = new Entry(id, 1, first);
            }

            this.count++;
        }

        public TargetCounter build(){
            return new TargetCounter(this);
        }

        public int getTotalCount(){
            return count;
        }

        @VisibleForTesting
        int getCount(int id){
            int index = hash(id);
            Entry e = entries[index];
            while (e != null && e.id != id){
                e = e.next;
            }

            if (e != null){
                return e.count;
            }

            return -1; // 不存在
        }
    }

    private static int hash(int id){
        return id & DEFAULT_ENTRY_COUNT_TO_MOD;
    }
}
