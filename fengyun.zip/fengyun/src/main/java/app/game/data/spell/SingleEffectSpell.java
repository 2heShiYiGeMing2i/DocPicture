package app.game.data.spell;

import static com.mokylin.sink.util.Preconditions.checkArgument;
import static com.mokylin.sink.util.Preconditions.checkNotNull;

import java.util.Collection;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.data.SpriteStats;
import app.game.data.goods.Goods;
import app.game.data.goods.GoodsDatas;
import app.game.data.goods.SpellXinfaData;
import app.game.data.spell.FightState.FightStateWithRate;
import app.game.module.scene.SceneMessages;
import app.protobuf.ConfigContent.ActiveSpell;
import app.protobuf.GoodsContent.XinfaType;
import app.protobuf.HeroContent.CombineXinfaSpellProto;
import app.protobuf.HeroServerContent.CombineXinfaSpellServerProto;

import com.mokylin.collection.IntHashMap;
import com.mokylin.sink.util.parse.ObjectParser;

public class SingleEffectSpell extends Spell{

    public static final SingleEffectSpell[] EMPTY_ARRAY = new SingleEffectSpell[0];

    /**
     * 引发的公共cd
     */
    public final int gcd;

    /**
     * 英雄用于计算的cd，比配置的cd少128毫秒
     */
    public final int heroCooldown;

    /**
     * 英雄用于计算的公共cd，比配置的gcd少128毫秒
     */
    public final int heroGlobalCooldown;

    /**
     * 对目标伤害多少次
     */
    public final int maxHurtTimes;

    /**
     * 最大击中目标个数. 如果技能需要个目标, 则这个值预先会-1, 表示剩下能伤害到的人
     * 
     * 如果技能不需要目标, 释放在地面上, 则不预先-1
     */
    final int maxHurtCount;

    /**
     * 每次攻击之后产生的仇恨值
     */
    public final int hate;

    /**
     * 击退格子数
     */
    public final int beatDistance;

    /**
     * 施法距离
     */
    final int releaseRange;

    /**
     * 伤害的范围
     */
    final int hurtRange;

    final int angle;

    /**
     * 重复次数
     */
    public final int repeatTimes;

    /**
     * 每次间隔
     */
    public final int repeatInterval;

    /**
     * 技能伤害的倍率, 计算时, 按配置的数字/100
     */
    final float damageMultiple;

    final int damage;

    /**
     * 技能额外的命中率, 分母为1万
     */
    final int additionalHitRate;

    /**
     * 技能额外的暴击率, 分母为1万
     */
    final int additionalCritRate;

    /**
     * 击中目标时, 有可能给目标添加的状态
     */
    public final FightStateWithRate[] targetStates;

    /**
     * 释放技能时, 有可能给自己添加的状态
     */
    public final FightStateWithRate[] selfStates;

    /**
     * 熟练度需求
     */
    public final int freeUpgradeUseTime;

    /**
     * 技能表现形式id
     */
    public final int spellAnimationID;

    /**
     * 技能表现形式, 里面有同一技能不同等级中相同的部分
     */
    public final SpellAnimation spellAnimation;

    public final String sound;

    // 无视跳闪
    public final boolean ignoreJumpShield;

    public transient final boolean isAttack;

    private SingleEffectSpell nextLevel;

    private final ChannelBuffer releasedThisSpellMessage;

    private final transient int releaseRangeOrHurtRange;

    // 配套心法类型
    public final XinfaType xinfaType;

    private final IntHashMap<CombineXinfaSpell> xinfaSpellMap;

    private final CombineXinfaSpell emptyXinfaSpell;

    // 施法过程无敌，实现天赋技能的施法过程无敌
    public final boolean isCastingInvincible;

    SingleEffectSpell(ObjectParser p, SpriteStats ss, FightStates fs,
            SpellAnimations animations, GoodsDatas goodsDatas){
        super(p, goodsDatas);

        checkArgument(fightingAmount > 0, "技能 %s 没有配置战斗力 fighting_amount", this);

        sound = p.getKey("sound", "");

        this.gcd = p.getIntKey("gcd");
        this.heroCooldown = Math.max(0, cd - 144);
        this.heroGlobalCooldown = Math.max(0, gcd - 144);
        this.hate = p.getIntKey("hate");

        int tempMaxHurtCount = p.getIntKey("max_hurt_count");
        checkArgument(tempMaxHurtCount > 0,
                "技能 %s 的最大伤害人数 max_hurt_count 至少需要是1: %s", this,
                tempMaxHurtCount);

        this.beatDistance = p.getIntKey("beat_distance");
        this.releaseRange = p.getIntKey("release_range");
        this.hurtRange = p.getIntKey("hurt_range");

        int m = p.getIntKey("damage_multiple");
        checkArgument(m >= 0, "技能 %s 的伤害倍率必须>=0: %s", this, m);

        this.damageMultiple = m / 100f;
        this.damage = p.getIntKey("damage");
        checkArgument(damage >= 0, "技能 %s 的附加伤害必须>=0.: %s", this, m);

        this.additionalCritRate = p.getIntKey("additional_crit_rate");
        this.additionalHitRate = p.getIntKey("additional_hit_rate");

        checkArgument(additionalCritRate >= 0, "技能 %s 的技能额外暴击率必须>=0: %s", this,
                additionalCritRate);

        checkArgument(additionalHitRate > 0, "技能 %s 的技能额外命中率必须>0: %s", this,
                additionalHitRate);

        // 附加的状态
        String stateString = p.getKey("states");
        this.targetStates = parseStateString(stateString, fs);

        // 施法者自己的状态
        String selfStateString = p.getKey("self_states");
        this.selfStates = parseStateString(selfStateString, fs);

        this.freeUpgradeUseTime = p.getIntKey("free_upgrade_use_time");

        String ani = p.getKey("spell_animation");
        spellAnimation = checkNotNull(animations.get(ani),
                "没有找到技能 %s 配置的技能表现形式spell_animation: %s", this, ani);
        this.spellAnimationID = spellAnimation.id;
        isAttack = spellAnimation.isAttack;

        if (spellAnimation.isRageSpell){
            checkArgument(spellLevel == 1, "技能 %s 是怒气技能，怒气技能只能是一级技能，不能升级", this);
        }

        checkArgument(spellAnimation.castTime <= cd
                && spellAnimation.castTime <= gcd, "技能 %s 的施法时间比技能CD小", this);

        maxHurtTimes = spellAnimation.getHurtTimes();
        checkArgument(maxHurtTimes > 0,
                "技能 %s 的最大伤害次数max_hurt_times 至少需要是1: %s", this, maxHurtTimes);

        if (maxHurtTimes > 1){
            checkArgument(beatDistance == 0,
                    "技能 %s 可以打多次，不能配置击退（只有攻击一次的技能可以配置击退）", this);
        }

        if (spellAnimation.targetType == SpellAnimation.TARGET_TYPE_TARGET){
            this.maxHurtCount = tempMaxHurtCount - 1;

            if (maxHurtCount == 0){
                checkArgument(
                        hurtRange == 0,
                        "技能 %s 的targetType是%s, 表示需要个目标, 可击中目标数是1, 表示不能击中别的目标了, 那干嘛还要不是0的伤害范围hurt_range",
                        this, SpellAnimation.TARGET_TYPE_TARGET);
            }

            checkArgument(releaseRange > 0,
                    "技能 %s 的targetType是%s, 表示需要个目标, releaseRange必须大于0", this,
                    SpellAnimation.TARGET_TYPE_TARGET);

        } else{
            this.maxHurtCount = tempMaxHurtCount;

            if (hurtRange > 0){
                checkArgument(
                        maxHurtCount > 0,
                        "技能 %s 的伤害范围hurt_range为%s, 但是最大可伤害人数max_hurt_count为0, 有啥意义?",
                        this, hurtRange);
            }
        }

        if (spellAnimation.targetType == SpellAnimation.TARGET_TYPE_GROUND){
            checkArgument(hurtRange > 0,
                    "技能 %s 的目标类型是GROUND, 伤害范围hurt_range必须大于0", this);

            checkArgument(releaseRange == 0,
                    "技能 %s 的目标类型是GROUND, 伤害范围release_range必须等于0", this);
        }

        angle = p.getIntKey("angle");

        if (spellAnimation.targetType == SpellAnimation.TARGET_TYPE_SECTOR){
            checkArgument(hurtRange > 0,
                    "技能 %s 的目标类型是SECTOR, 伤害范围hurt_range必须大于0", this);

            checkArgument(releaseRange == 0,
                    "技能 %s 的目标类型是SECTOR, 伤害范围release_range必须等于0", this);

            checkArgument(angle > 23,
                    "技能 %s 的目标类型是SECTOR, 角度错误，[ 23 < angle <= 180]", this);
        }

        this.releasedThisSpellMessage = SceneMessages
                .yourSpellReleased(spellType);

        this.releaseRangeOrHurtRange = Math.max(releaseRange, hurtRange);

        // ---- 检查附带的状态 -----
        for (FightStateWithRate state : selfStates){
            checkArgument(state.getActualFightState().isBuff,
                    "技能 %s 释放成功后给自己添加的状态必须是buff: %s", this, state);
        }
        if (spellAnimation.isAttack){
            for (FightStateWithRate state : targetStates){
                checkArgument(!state.getActualFightState().isBuff,
                        "技能 %s 是个攻击技能, 释放成功后, 给目标添加的状态不能是buff: %s", this, state);
            }
        } else{
            for (FightStateWithRate state : targetStates){
                checkArgument(state.getActualFightState().isBuff,
                        "技能 %s 不是个攻击技能, 释放成功后, 给目标添加的状态必须是buff: %s", this,
                        state);
            }
        }

        // 附带心法
        emptyXinfaSpell = new CombineXinfaSpell(this,
                SpellXinfaEffect.EMPTY_XINFA);

        int intType = p.getIntKey("xinfa_type");
        if (intType > 0){
            xinfaType = checkNotNull(XinfaType.valueOf(intType),
                    "%s 没找到心法类型, %s", this, intType);
            xinfaSpellMap = new IntHashMap<>();
        } else{
            xinfaType = null;
            xinfaSpellMap = null;
        }

        ignoreJumpShield = p.getBooleanKey("ignore_jump_shield");

        repeatTimes = p.getIntKey("repeat_times");
        checkArgument(repeatTimes >= 0, "技能 %s 配置了无效的repeat_times", this);

        repeatInterval = p.getIntKey("repeat_interval");
        if (repeatTimes > 1){
            checkArgument(repeatTimes > 0,
                    "技能 %s 配置了重复释放次数，但是没有配置repeatInterval", this);
        }

        isCastingInvincible = p.getBooleanKey("is_casting_invincible", false);
    }

    private static FightStateWithRate[] parseStateString(String stateString,
            FightStates fs){
        if (stateString.length() == 0){
            return FightState.EMPTY_FightStateWithRate_ARRAY;
        }

        // stateID%100;stateID%20
        String[] str = stateString.split(";");
        FightStateWithRate[] result = new FightStateWithRate[str.length];
        for (int i = 0; i < str.length; i++){
            String[] idRate = str[i].split("%");
            checkArgument(idRate.length == 2,
                    "状态和概率的配置格式是: id1%概率;id2%概率:  %s", stateString);
            int stateID = Integer.parseInt(idRate[0]);
            FightState s = fs.get(stateID);
            checkNotNull(s, "没有找到要附带的状态: %s", stateID);
            int rate = Integer.parseInt(idRate[1]);
            checkArgument(rate > 0 && rate <= 100, "状态添加的概率是 1-100: %s", rate);

            result[i] = s.withRate(rate);
        }
        return result;
    }

    public int getReleaseRangeOrHurtRange(){
        return releaseRangeOrHurtRange;
    }

    void setNextLevelAndTotalLevel(int totalLevel, SingleEffectSpell spell){
        assert this.totalLevel == 0;
        assert this.nextLevel == null;

        this.totalLevel = totalLevel;
        this.nextLevel = spell;

        if (spell != null){
            checkArgument(spellAnimation == spell.spellAnimation,
                    "技能 %s 和它的下一级使用的竟然不是同一个技能表现形式spell_animation", this);
        }
    }

    void initXinfaSpell(Collection<SpellXinfaEffect> xinfaEffects){
        if (xinfaType == null)
            return;

        for (SpellXinfaEffect xinfa : xinfaEffects){
            if (xinfaType == xinfa.type
                    && spellLevel >= xinfa.requireSpellLevel){
                xinfaSpellMap.put(xinfa.id, new CombineXinfaSpell(this, xinfa));
            }
        }
    }

    public CombineXinfaSpell getEmptyXinfaSpell(){
        return emptyXinfaSpell;
    }

    private CombineXinfaSpell getXinfaSpell(int xinfaId){

        CombineXinfaSpell sp = null;
        if (xinfaSpellMap != null){
            sp = xinfaSpellMap.get(xinfaId);
        }

        if (sp != null){
            return sp;
        }

        return emptyXinfaSpell;
    }

    public SingleEffectSpellWithUsedTimes withUsedTimes(int time){
        return new SingleEffectSpellWithUsedTimes(time);
    }

    public ChannelBuffer getReleasedMessage(){
        return releasedThisSpellMessage;
    }

    @Override
    public SingleEffectSpell getNextLevel(){
        return nextLevel;
    }

    public boolean isRageSpell(){
        return spellAnimation.isRageSpell;
    }

    @Override
    protected void setSpecialSpellField(ActiveSpell.Builder builder){
        builder.setIsPassive(false);

        builder.setGcd(gcd).setFreeUpgradeUseTime(freeUpgradeUseTime)
                .setSpellAnimationId(spellAnimationID);

        if (releaseRange > 0){
            builder.setReleaseRange(releaseRange);
        }

        if (hurtRange > 0){
            builder.setHurtRange(hurtRange);
        }

        if (nextLevel != null){
            builder.setNextLevelDescription(nextLevel.description);
        }

        if (xinfaType != null){
            builder.setXinfaType(xinfaType);
        }

        if (clientCanLearnLevel == 1 && spellCategory == HERO_SPELL_CATEGORY){
            builder.setHurtCount(maxHurtCount);
            builder.setAngle(angle);
        }

        if (!sound.isEmpty()){
            builder.setSound(sound);
        }
    }

    public class SingleEffectSpellWithUsedTimes{

        private Goods xinfaGoods;

        private int usedTime;

        private CombineXinfaSpell spell;

        SingleEffectSpellWithUsedTimes(int usedTime){
            this.usedTime = usedTime;
            spell = emptyXinfaSpell;
        }

        public Goods getXinfaGoods(){
            return xinfaGoods;
        }

        public Goods setXinfa(Goods xinfaGoods){

            Goods old = this.xinfaGoods;
            this.xinfaGoods = xinfaGoods;

            if (xinfaGoods != null
                    && (xinfaGoods.getData() instanceof SpellXinfaData)){
                SpellXinfaData data = (SpellXinfaData) xinfaGoods.getData();

                spell = getXinfaSpell(data.xinfa);
            } else{
                spell = emptyXinfaSpell;
            }

            return old;
        }

        public int addUsedTime(){
            if (usedTime >= freeUpgradeUseTime){
                return freeUpgradeUseTime;
            }
            return ++usedTime;
        }

        public boolean isUsedTimeMax(){
            return usedTime >= freeUpgradeUseTime;
        }

        public int getUsedTime(){
            return usedTime;
        }

        public SingleEffectSpell getActualSpell(){
            return SingleEffectSpell.this;
        }

        public CombineXinfaSpell getCombineXinfaSpell(){
            return spell;
        }

        public CombineXinfaSpellProto encodeToSelfHeroOnLogin(){
            CombineXinfaSpellProto.Builder builder = CombineXinfaSpellProto
                    .newBuilder();

            builder.setActiveSpell(getProto()).setUsedTimes(usedTime);

            if (xinfaGoods != null){
                builder.setStaticData(xinfaGoods.getData().getProtoByteString());
                builder.setDynamicData(xinfaGoods.encodeByteString4Client());
            }

            return builder.build();
        }

        public CombineXinfaSpellServerProto encode(){
            CombineXinfaSpellServerProto.Builder builder = CombineXinfaSpellServerProto
                    .newBuilder();

            builder.setSpellId(id).setUsedTimes(usedTime);

            if (xinfaGoods != null){
                builder.setXinfa(xinfaGoods.encode());
            }

            return builder.build();
        }
    }
}
