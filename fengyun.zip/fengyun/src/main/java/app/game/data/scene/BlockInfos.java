package app.game.data.scene;

import java.util.Collection;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.data.GameObjects;

import com.google.common.collect.Lists;
import com.google.inject.Inject;
import com.google.protobuf.InvalidProtocolBufferException;
import com.mokylin.collection.Pair;
import com.mokylin.sink.util.pack.FileLoader;

public class BlockInfos{

    private static final Logger logger = LoggerFactory
            .getLogger(BlockInfos.class);

    public static final String LOCATION = GameObjects.SCENE_BASE_FOLDER
            + "block";

    private final List<BlockInfo> list;

    @Inject
    BlockInfos(FileLoader loader){
        Collection<Pair<String, byte[]>> data = loader
                .loadByteFilesInFolder(LOCATION);

        list = Lists.newArrayListWithCapacity(data.size());

        int maxWidth = 0;
        int maxHeight = 0;

        for (Pair<String, byte[]> pair : data){
            try{
                BlockInfo info = new BlockInfo(pair.left, pair.right);
                logger.debug("读到地块: {}", pair.left);
                list.add(info);

                maxWidth = Math.max(maxWidth, info.getWidth());
                maxHeight = Math.max(maxHeight, info.getHeight());
            } catch (InvalidProtocolBufferException | IllegalArgumentException e){
                throw new IllegalArgumentException("block文件格式错误: " + pair.left);
            }
        }

        BlockInfo.setGlobalMaxSize(maxWidth, maxHeight);
    }

    public BlockInfo get(String name){
        for (int i = list.size(); --i >= 0;){
            BlockInfo bi = list.get(i);
            if (bi.name.equals(name)){
                return bi;
            }
        }
        return null;
    }
}
