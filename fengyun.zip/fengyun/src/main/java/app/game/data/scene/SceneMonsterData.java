package app.game.data.scene;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.data.SpriteStat;
import app.game.module.scene.FightData;
import app.utils.VariableConfig;

/**
 * 在场景中的怪物, 包含怪物基础信息/坐标/ai/掉落
 * 
 * @author Timmy
 * 
 */
public class SceneMonsterData{

    public static final SceneMonsterData[] EMPTY_ARRAY = new SceneMonsterData[0];

    public final int id;

    private final MonsterData monsterData;

    private final Ai ai;

    private final boolean isMustDie;

    private final SpriteStat stat;

    private final int level;

    public final int originX;

    public final int originY;

    public final int sceneID;

    public transient final int normalSpellReleaseRangeOrHurtRangeIfHaveNormalSpell;

    public transient final int specialSpellCount;

    public final ChannelBuffer removeMeMessage;

    public final Plunder plunder;

    public final long reliveTime;

    SceneMonsterData(int id, int parentSceneID, MonsterGroupData groupData,
            int x, int y, SceneRemoveObjectMsgCache removeMsgCache){
        this.id = id;
        removeMeMessage = removeMsgCache.get(id);

        this.monsterData = groupData.monster;
        this.sceneID = parentSceneID;

        this.stat = monsterData.stat;
        this.level = monsterData.level;

        this.originX = x;
        this.originY = y;
        this.ai = groupData.ai;
        isMustDie = monsterData.isMustDie() && ai.isSingleLife;

        this.plunder = groupData.plunder;
        this.normalSpellReleaseRangeOrHurtRangeIfHaveNormalSpell = this.monsterData.normalSpell == null ? 0
                : this.monsterData.normalSpell.getReleaseRangeOrHurtRange();
        this.specialSpellCount = monsterData.specialSpellsCount;

        if (monsterData.isBoss()){
            reliveTime = Math.max(VariableConfig.MIN_BOSS_RELIVE_MILLIS,
                    ai.reliveTime);
        } else{
            reliveTime = ai.reliveTime;
        }
    }

    /**
     * 创建个新的, 属性/等级/掉落是新的
     * @param copy
     * @param newStat
     * @param newLevel
     * @param newPlunder
     */
    SceneMonsterData(SceneMonsterData copy, SpriteStat newStat, int newLevel,
            Plunder newPlunder){
        this.id = copy.id;
        this.monsterData = copy.monsterData;
        this.ai = copy.ai;
        this.isMustDie = copy.isMustDie;
        this.stat = newStat;
        this.level = newLevel;
        this.originX = copy.originX;
        this.originY = copy.originY;
        this.sceneID = copy.sceneID;
        this.normalSpellReleaseRangeOrHurtRangeIfHaveNormalSpell = copy.normalSpellReleaseRangeOrHurtRangeIfHaveNormalSpell;
        this.specialSpellCount = copy.specialSpellCount;
        this.removeMeMessage = copy.removeMeMessage;
        this.plunder = newPlunder;
        this.reliveTime = copy.reliveTime;
    }

    public FightData newFightData(){
        FightData result = new FightData(stat, level);
        result.setSceneIDAndPos(sceneID, originX, originY);
        return result;
    }

    public MonsterData getMonsterData(){
        return monsterData;
    }

    public Ai getAi(){
        return ai;
    }

    public long getID(){
        return id;
    }

    public byte[] getNameBytes(){
        return monsterData.clientDisplayName;
    }

    public boolean isMustDie(){
        return isMustDie;
    }
}
