/**
 * 
 */
package app.game.data.goods;

import app.game.data.SpriteStat;
import app.game.data.SpriteStatBuilder;
import app.game.data.goods.EquipmentAddedStatGroup.SingleAddedStat;
import app.game.module.scene.FightData;
import app.protobuf.GoodsContent.MountEquipmentProto;
import app.protobuf.GoodsServerContent.GoodsServerProto;
import app.protobuf.GoodsServerContent.MountEquipmentServerProto;
import app.protobuf.GoodsServerContent.Quality;
import app.protobuf.SpriteStatContent.StatType;

import com.google.protobuf.ByteString;

/**
 * 装备
 * 
 * @author Liwei
 * 
 */
public class MountEquipment extends Goods{

    private final MountEquipmentData data;

    final int refinedTimes;

    final int intStatType;

    final int intQuality;

    private transient final RefinedData refinedData;

    private transient final SingleAddedStat addedStat;

    /**
     * 装备总属性
     */
    private final SpriteStat totalStat;

    /**
     * 战斗值，当涉及到战斗值变化时，重新计算一遍
     */
    private final int fightingAmount;

    MountEquipment(MountEquipmentData data, long expireTime, int refinedTimes,
            int intStatType, int intQuality){
        super(data, expireTime);
        this.data = data;
        this.refinedTimes = refinedTimes;
        this.intStatType = intStatType;
        this.intQuality = intQuality;

        refinedData = data.getRefinedData(refinedTimes);

        StatType statType = StatType.valueOf(intStatType);
        Quality quality = Quality.valueOf(intQuality);

        if (quality == null)
            quality = Quality.WHITE;

        if (statType != null){
            addedStat = data.getAddedStat(statType, quality);
        } else{
            addedStat = data.getDefaultAddedStat(quality);
        }

        SpriteStatBuilder builder = SpriteStatBuilder.newBuilder();
        builder.add(data.getBaseStat(intQuality));
        builder.add(refinedData.getRefinedStat(intQuality));
        builder.add(addedStat.getTotalStat());

        totalStat = builder.build();
        fightingAmount = FightData.calculateFightingAmount(totalStat);
    }

    // for split
    private MountEquipment(MountEquipment copy){
        super(copy.data, copy.expireTime);
        data = copy.data;
        refinedTimes = copy.refinedTimes;
        intStatType = copy.intStatType;
        intQuality = copy.intQuality;

        refinedData = copy.refinedData;
        addedStat = copy.addedStat;

        totalStat = copy.totalStat;
        fightingAmount = copy.fightingAmount;
    }

    @Override
    public byte[] getDropName(){
        return refinedData.dropName;
    }

    @Override
    public Quality getQuality(){
        return addedStat.quality;
    }

    public int getRequireMountLevel(){
        return data.requireMountLevel;
    }

    public SpriteStat getTotalStat(){
        return totalStat;
    }

    public int getFightingAmount(){
        return fightingAmount;
    }

    @Override
    protected Goods split(){
        return new MountEquipment(this);
    }

    public MountEquipmentData getData(){
        return data;
    }

    public boolean isValidEquipPos(int equipPos){
        return data.isValidEquipPos(equipPos);
    }

    protected MountEquipmentProto cacheClientMountEquipmentProto;

    public MountEquipmentProto encode4ClientProto(){
        MountEquipmentProto proto = cacheClientMountEquipmentProto;
        if (proto == null || binded != proto.getBinded()){
            cacheClientMountEquipmentProto = proto = data
                    .encodeGoodsProto(this);
        }

        return proto;
    }

    @Override
    public byte[] encodeBytes4Client(){
        return encode4ClientProto().toByteArray();
    }

    @Override
    public ByteString encodeByteString4Client(){
        return encode4ClientProto().toByteString();
    }

    @Override
    protected GoodsServerProto.Builder doEncode(){
        GoodsServerProto.Builder baseBuilder = super.doEncode();

        baseBuilder.setExtension(MountEquipmentServerProto.goodsProto,
                encodeEquipmentServerProto());

        return baseBuilder;
    }

    private MountEquipmentServerProto encodeEquipmentServerProto(){
        MountEquipmentServerProto.Builder builder = MountEquipmentServerProto
                .newBuilder();

        if (refinedTimes > 0){
            builder.setRefinedTimes(refinedTimes);
        }

        if (intStatType > 0){
            builder.setAddedStatType(intStatType);
        }

        if (intQuality > 0){
            builder.setQuality(intQuality);
        }

        return builder.build();
    }

    @Override
    public long getGoodsIdentifier(){
        // 最右边28bit是统一的物品信息
        return data.getGoodsIdentifier(binded, intStatType, intQuality,
                refinedData.refinedTimes);
    }
}
