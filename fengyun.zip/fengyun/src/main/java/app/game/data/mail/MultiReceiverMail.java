package app.game.data.mail;

import java.util.List;

import app.game.data.goods.Goods;
import app.protobuf.MailContent.MailProto;
import app.protobuf.MailServerContent.MailServerProto;

import com.google.protobuf.ByteString;
import com.mokylin.sink.util.Empty;
import com.mokylin.sink.util.holder.LongIntHolder;

/**
 * @author Liwei
 *
 */
public class MultiReceiverMail{

    /**
     * 收件人数据
     */
    private final List<LongIntHolder> receiver;

    /**
     * 邮件发送时间
     */
    private final long sendTime;

    /**
     * 邮件正文
     */
    private final byte[] content;

    /**
     * 邮件附带银两
     */
    private final int money;

    /**
     * 邮件附带元宝
     */
    private final int yuanbao;

    /**
     * 绑定元宝
     */
    private final int bindedYuanbao;

    /**
     * 邮件附带物品
     */
    private final Goods[] goodsArray;

    public MultiReceiverMail(List<LongIntHolder> receiver, long sendTime,
            byte[] content, int money, int yuanbao, int bindedYuanbao,
            Goods[] goodsArray){
        this.receiver = receiver;
        this.sendTime = sendTime;
        this.content = content;
        this.money = money;
        this.yuanbao = yuanbao;
        this.bindedYuanbao = bindedYuanbao;
        this.goodsArray = goodsArray;
    }

    public List<LongIntHolder> getReceiver(){
        return receiver;
    }

    public long getSendTime(){
        return sendTime;
    }

    public byte[] getContent(){
        if (content == null){
            return Empty.BYTE_ARRAY;
        }

        return content;
    }

    public int getMoney(){
        return money;
    }

    public int getYuanbao(){
        return yuanbao;
    }

    public int getGoodsCount(){
        return goodsArray.length;
    }

    public Goods[] getGoodsArray(){
        return goodsArray;
    }

    public MailProto encode4Client(){
        MailProto.Builder builder = MailProto.newBuilder();

        if (content.length > 0){
            builder.setContent(ByteString.copyFrom(content));
        }

        if (money > 0){
            builder.setMoney(money);
        }

        if (yuanbao > 0 || bindedYuanbao > 0){
            builder.setYuanbao(yuanbao + bindedYuanbao);
        }

        for (Goods g : goodsArray){
            builder.addGoodsStaticData(g.getData().getProtoByteString());
            builder.addGoodsDynamicData(g.encodeByteString4Client());
        }

        return builder.build();
    }

    public MailServerProto encode(){
        MailServerProto.Builder builder = MailServerProto.newBuilder();

        if (money > 0){
            builder.setMoney(money);
        }

        if (yuanbao > 0){
            builder.setYuanbao(yuanbao);
        }

        if (bindedYuanbao > 0){
            builder.setBindedYuanbao(bindedYuanbao);
        }

        for (Goods g : goodsArray){
            builder.addGoods(g.encode());
        }

        return builder.build();
    }
}
