package app.game.data.scene;

import static com.mokylin.sink.util.Preconditions.checkArgument;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import app.game.data.goods.GoodsWrapper;
import app.protobuf.ConfigContent.WorldBossConfig;
import app.protobuf.ConfigContent.WorldBossProto;

import com.google.common.collect.Lists;
import com.google.inject.Inject;

/**
 * @author Liwei
 *
 */
public class WorldBoss{

    private final MonsterStatisticsData[] bossArray;

    private final MonsterStatisticsData[] eliteMonsterArray;

    @Inject
    WorldBoss(SceneDatas scenes){

        List<MonsterStatisticsData> bossList = Lists.newArrayList();
        List<MonsterStatisticsData> eliteMonsterList = Lists.newArrayList();

        for (NormalSceneData scene : scenes.getAllNormalSceneDatas()){

            if (scene.getBoss() != null){
                bossList.add(scene.getBoss());
            }

            if (scene.getEliteMonster() != null)
                eliteMonsterList.add(scene.getEliteMonster());
        }

        // Boss等级小的在前
        Collections.sort(bossList, new Comparator<MonsterStatisticsData>(){
            @Override
            public int compare(MonsterStatisticsData o1,
                    MonsterStatisticsData o2){
                return o1.monster.getMonsterData().level
                        - o2.monster.getMonsterData().level;
            }
        });

        bossArray = bossList.toArray(MonsterStatisticsData.EMPTY_ARRAY);

        eliteMonsterArray = eliteMonsterList
                .toArray(MonsterStatisticsData.EMPTY_ARRAY);
    }

    public MonsterStatisticsData[] getBossArray(){
        return bossArray;
    }

    public WorldBossConfig generateProto(){
        WorldBossConfig.Builder builder = WorldBossConfig.newBuilder();
        for (MonsterStatisticsData boss : bossArray){
            WorldBossProto.Builder bossBuilder = WorldBossProto.newBuilder()
                    .setId(boss.getMonsterId())
                    .setCanKillLevel(boss.scene.getCanEnterLevel());

            checkArgument(
                    !boss.monster.getMonsterData().introduction.isEmpty(),
                    "世界Boss的背景没有配置，%s", boss.monster.getMonsterData());

            bossBuilder
                    .setIntroduction(boss.monster.getMonsterData().introduction);

            for (GoodsWrapper g : boss.monster.getMonsterData().showGoods){
                bossBuilder.addShowGoods(g.encode4Client());
            }

            for (int hour : boss.refreshTime.getHours()){
                bossBuilder.addRefreshTime(hour);
            }

            builder.addBoss(bossBuilder.build());
        }

        for (MonsterStatisticsData eliteMonster : eliteMonsterArray){
            WorldBossProto.Builder eliteMonsterBuilder = WorldBossProto
                    .newBuilder().setId(eliteMonster.getMonsterId());

            for (int hour : eliteMonster.refreshTime.getHours()){
                eliteMonsterBuilder.addRefreshTime(hour);
            }

            builder.addEliteMonster(eliteMonsterBuilder.build());
        }

        return builder.build();
    }
}
