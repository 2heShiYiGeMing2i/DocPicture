package app.game.data.scene;

import static com.mokylin.sink.util.Preconditions.checkArgument;

import org.joda.time.DateTimeConstants;

import app.game.data.GameObjects;
import app.game.data.goods.GoodsDatas;
import app.game.data.goods.GoodsWrapper;
import app.game.module.scene.IDungeonService;
import app.game.service.log.LogService;
import app.protobuf.ConfigContent.DailyActivityType;
import app.protobuf.ConfigContent.JijianDungeonProto;
import app.protobuf.LogContent.LogEnum.SceneType;

import com.google.protobuf.ByteString;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class JijianSceneData extends DungeonSceneData{

    final int lineCapacity;

    // 开始时间，通过这个获取下一次时间
    final int startTime;

    final int startTimeHour;

    final int startTimeMinute;

    final int startTimeMillis;

    public final int JIJIAN_KEY;

    // 活动持续时间
    public final long activeInterval;

    // 全场景给奖励时间间隔
    public final long sceneRadiateInterval;

    public final int radiateExp;

    public final int radiateRealAir;

    // 英雄扩散时间
    public final int heroRadiateDelayTime;

    public final int heroRadiateDistance;

    // 收益倍率
    private final int multiple;

    transient int extraMultiple;

    // 蹭真气上限
    public final int maxFreeloadRealAir;

    // 排行榜额外奖励
    private final GoodsWrapper top1ExtraGoods;

    private final GoodsWrapper top2ExtraGoods;

    private final GoodsWrapper top3ExtraGoods;

    private final GoodsWrapper top20ExtraGoods;

    // 获得面板开放等级
    private final int openLevel;

    JijianSceneData(GameObjects go, ObjectParser p, BlockInfos blocks,
            MonsterDatas monsters, Scripts scripts, Plunders plunders, Ais ais,
            SceneTransportDatas transports,
            SceneRemoveObjectMsgCache removeMsgCache, GoodsDatas goodsDatas){
        super(go, p, blocks, monsters, scripts, plunders, ais, transports,
                removeMsgCache);

        lineCapacity = p.getIntKey("line_capacity", 100);
        checkArgument(lineCapacity > 0, "祭剑副本进入人数限制必须大于0", lineCapacity);

        startTime = p.getIntKey("start_time");
        startTimeHour = startTime / 100;
        startTimeMinute = startTime % 100;
        checkArgument(startTimeHour >= 0 && startTimeHour < 24
                && startTimeMinute >= 0 && startTimeMinute < 60,
                "祭剑开始时间配置无效, %s", startTime);
        startTimeMillis = startTimeHour * DateTimeConstants.MILLIS_PER_HOUR
                + startTimeMinute * DateTimeConstants.MILLIS_PER_MINUTE;

        JIJIAN_KEY = (DailyActivityType.DA_JIJIAN_VALUE << 12) | startTime;

        activeInterval = 1L * p.getIntKey("active_interval")
                * DateTimeConstants.MILLIS_PER_MINUTE;
        checkArgument(activeInterval > 0, "祭剑副本里配置的活动持续时间必须>0. %s", this);

        sceneRadiateInterval = 1L * p.getIntKey("scene_radiate_interval")
                * DateTimeConstants.MILLIS_PER_MINUTE;
        checkArgument(sceneRadiateInterval > 0
                && sceneRadiateInterval < activeInterval,
                "祭剑副本里配置的全场景奖励时间间隔必须>0，并且小于活动时间. %s", this);

        radiateExp = p.getIntKey("radiate_exp");
        checkArgument(radiateExp > 0, "祭剑副本里配置的全场景经验奖励必须>0. %s", this);

        radiateRealAir = p.getIntKey("radiate_real_air");
        checkArgument(radiateRealAir > 0, "祭剑副本里配置的全场景真气奖励必须>0. %s", this);

        heroRadiateDelayTime = p.getIntKey("hero_radiate_delay_time");
        checkArgument(heroRadiateDelayTime > 0, "祭剑副本里配置的扩散时间间隔必须>0. %s", this);

        heroRadiateDistance = p.getIntKey("hero_radiate_distance");
        checkArgument(heroRadiateDistance > 0, "祭剑副本里配置的扩散距离必须>0. %s", this);

        multiple = p.getIntKey("multiple");
        checkArgument(multiple > 0, "祭剑副本里配置的打坐倍率必须>0. %s", this);
        extraMultiple = multiple - 1;

        maxFreeloadRealAir = p.getIntKey("max_freeload_real_air");
        checkArgument(multiple > 0, "祭剑副本里配置的蹭真气最大值必须>0. %s", this);

        String goodsStr = p.getKey("top1_goods");
        top1ExtraGoods = GoodsWrapper.parse(this, goodsDatas, goodsStr);

        goodsStr = p.getKey("top2_goods");
        top2ExtraGoods = GoodsWrapper.parse(this, goodsDatas, goodsStr);

        goodsStr = p.getKey("top3_goods");
        top3ExtraGoods = GoodsWrapper.parse(this, goodsDatas, goodsStr);

        goodsStr = p.getKey("top20_goods");
        top20ExtraGoods = GoodsWrapper.parse(this, goodsDatas, goodsStr);

        openLevel = Math.max(p.getIntKey("open_level"), 1);
    }

    public int getStartTime(){
        return startTime;
    }

    public int getLineCapacity(){
        return lineCapacity;
    }

    public GoodsWrapper getRankPosGoods(int rankPos){
        if (rankPos > 0 && rankPos < 21){
            switch (rankPos){
                case 1:{
                    return top1ExtraGoods;
                }
                case 2:{
                    return top2ExtraGoods;
                }
                case 3:{
                    return top3ExtraGoods;
                }
                default:{
                    return top20ExtraGoods;
                }
            }
        }

        return null;
    }

    @Override
    public JijianScene newDungeon(int sceneID, IDungeonService dungeonService,
            LogService logService, long creator){
        throw new IllegalAccessError("JijianScene 不能直接创建");
    }

    @Override
    public int getIntType(){
        return SceneType.JI_JIAN_DUNGEON.getNumber();
    }

    public void generateProto(JijianDungeonProto.Builder builder){
        builder.setSceneId(id).setMap(blockName)
                .setName(ByteString.copyFrom(nameBytes)).setSound(sound);
        if (isHeroLevelProtect){
            builder.setIsHeroLevelProtect(true);
        }
        if (isNewHeroProtect){
            builder.setIsNewHeroProtect(true);
        }
        if (isDeathProtect){
            builder.setIsDeathProtect(true);
        }
        if (isNightAutoProtect){
            builder.setIsNightAutoProtect(true);
        }
        if (isJumpLimit){
            builder.setIsJumpLimit(true);
        }
        if (isMountLimit){
            builder.setIsMountLimit(true);
        }

        if (poet != null){
            String tp = poet.trim();
            if (tp.length() > 0){
                builder.setPoet(ByteString.copyFromUtf8(tp));
            }
        }
        if (fixedPkMode != null){
            builder.setFixedPkMode(fixedPkMode.getIntMode());
        }

        if (reliveOutOfDungeon){
            builder.setIsDeathReturnTown(true);
        }

        builder.setStartTime(startTime).setActiveInterval(activeInterval)
                .setMultiple(multiple).setRadiateDistance(heroRadiateDistance)
                .setRequiredLevel(requiredLevel)
                .setTop1Goods(top1ExtraGoods.encode4Client())
                .setTop2Goods(top2ExtraGoods.encode4Client())
                .setTop3Goods(top3ExtraGoods.encode4Client())
                .setTop20Goods(top20ExtraGoods.encode4Client());

        builder.setOpenLevel(openLevel);
    }
}
