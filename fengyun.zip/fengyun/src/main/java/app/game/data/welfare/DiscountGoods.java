package app.game.data.welfare;

import static com.mokylin.sink.util.Preconditions.checkArgument;
import app.game.data.goods.GoodsDatas;
import app.game.data.goods.GoodsWrapper;
import app.protobuf.ConfigContent.DiscountGoodsProto;

import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class DiscountGoods{

    private final GoodsWrapper goods;

    // 价格
    final int price;

    // 原价，元宝商城中必须配置
    final int showPrice;

    // 限购数量，0表示不限购
    private final int countLimit;

    // 折扣类型 0-无折扣 1-热销 2-折扣
    private final int promotion;

    private final int ratio;

    // 商品描述
    private final String desc;

    DiscountGoods(Object parent, ObjectParser p, GoodsDatas goodsDatas){

        String item = p.getKey("goods_item");
        goods = GoodsWrapper.parse(parent, goodsDatas, item);

        price = p.getIntKey("price");
        checkArgument(price > 0, "%s 的售价必须大于0，售价：%s", parent, price);

        showPrice = p.getIntKey("show_price", 0);

        countLimit = p.getIntKey("count_limit");
        checkArgument(countLimit >= 0, "%s 的限购数量必须>=0", parent);

        // 促销信息 (0无热销，1热销中，2折扣，3热销+折扣)
        promotion = p.getIntKey("promotion", 0);

        checkArgument(promotion >= 0 && promotion <= 3,
                "%s 配置了无效的促销信息(0无热销，1热销中，2折扣，3热销+折扣)，promotion: %s", parent,
                promotion);

        ratio = p.getIntKey("ratio", 0);

        if (promotion >= 2){
            checkArgument(ratio > 0, "%s 配置的打折折扣必须>0", parent);
        }

        desc = p.getKey("desc", "");
    }

    public int getPrice(){
        return price;
    }

    public int getCountLimit(){
        return countLimit;
    }

    public GoodsWrapper getWrapper(){
        return goods;
    }

    DiscountGoodsProto encode(){
        DiscountGoodsProto.Builder builder = DiscountGoodsProto.newBuilder();

        builder.setGoods(goods.encode4Client());
        builder.setPrice(price);
        if (showPrice > 0)
            builder.setShowPrice(showPrice);

        if (countLimit > 0)
            builder.setCountLimit(countLimit);

        if (promotion > 0)
            builder.setPromotion(promotion);

        if (ratio > 0)
            builder.setRatio(ratio);

        if (desc != null && !desc.isEmpty())
            builder.setDesc(desc);

        return builder.build();
    }
}
