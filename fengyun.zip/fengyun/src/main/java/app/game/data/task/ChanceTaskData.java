package app.game.data.task;

import static com.mokylin.sink.util.Preconditions.*;
import app.game.data.Prize;
import app.game.data.PrizeConfig;
import app.game.data.PrizeConfigs;
import app.game.data.QualityRelatedData;
import app.game.data.QualityRelatedDatas;
import app.game.data.goods.GoodsDatas;
import app.game.data.scene.CollectObjects;
import app.game.data.scene.MonsterData;
import app.game.data.scene.MonsterDatas;
import app.game.data.scene.Npcs;
import app.game.data.scene.SceneDatas;
import app.game.data.task.TaskDatas.TaskType;
import app.game.data.task.TaskTarget.TaskTargetProgress;
import app.protobuf.GoodsServerContent.Quality;
import app.protobuf.HeroServerContent.RaceId;
import app.protobuf.TaskContent.ChanceTaskProto;
import app.protobuf.TaskContent.TaskDataProto;
import app.utils.VariableConfig;

import com.mokylin.collection.IntHashMap;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class ChanceTaskData{

    static final ChanceTaskData[] EMPTY_ARRAY = new ChanceTaskData[0];

    final int id;

    final int minLevel;

    final int maxLevel;

    final Quality quality;

    final TaskData taskData;

    final String headImage;

    final QualityRelatedData relatedData;

    final transient int baseExp;

    final PrizeConfig prizeConfig;

    final Prize fixedPrize;

    final TaskDataProto taskProto;

    ChanceTaskData(ObjectParser p, Npcs npcs, GoodsDatas goodsDatas,
            MonsterDatas monsters, PrizeConfigs prizes,
            CollectObjects collectObjects, SceneDatas sceneDatas,
            IntHashMap<MonsterData> monLevelMap,
            QualityRelatedDatas relatedDatas){

        id = p.getIntKey("id");

        int intQuality = p.getIntKey("quality");
        quality = checkNotNull(Quality.valueOf(intQuality), "%s 中发现无效的品质, %s",
                this, intQuality);

        this.relatedData = checkNotNull(relatedDatas.get(quality),
                "%s 中没找到%s品质的QualityRelatedData, %s", this, quality);

        minLevel = p.getIntKey("min_level");
        maxLevel = p.getIntKey("max_level");
        checkArgument(
                minLevel > 0 && minLevel <= maxLevel
                        && maxLevel <= VariableConfig.HERO_MAX_LEVEL,
                "%s 配置的等级无效, minLevel > 0 && minLevel <= maxLevel && maxLevel <= HERO_MAX_LEVEL, minLevel: %s, maxLevel:%s, heroMaxLevel: %s",
                this, minLevel, maxLevel, VariableConfig.HERO_MAX_LEVEL);

        taskData = TaskData.newChanceTask(p, npcs, monsters, goodsDatas,
                collectObjects, sceneDatas, monLevelMap, this.toString());

        String prizeName = p.getKey("prize");
        prizeConfig = checkNotNull(prizes.get(prizeName),
                "%s的奖励不存在， prize: %s", this, prizeName);

        checkArgument(!prizeConfig.hasExipreTimeGoods(), "%s 奖励中配置了有过期时间的物品",
                this);

        // 配错物品，策划负责
        // checkArgument(!prizeConfig.hasUnbindedGoods(), "%s 奖励中配置了非绑定的物品", this);

        headImage = p.getKey("head_image");

        Prize fixedPrize = null;
        if (!prizeConfig.isVarPrize()){
            fixedPrize = prizeConfig.random();
        }
        this.fixedPrize = fixedPrize;

        taskProto = taskData.encodeData(fixedPrize);

        baseExp = prizeConfig.getExp();
    }

    public int getIntType(){
        return TaskType.CHANCE.getIntType();
    }

    ChanceTask newEmptyTask(int taskId, RaceId raceId){
        Prize p = fixedPrize != null ? fixedPrize : prizeConfig.random(raceId);

        return new ChanceTask(taskId, this, taskData.newEmptyProgress(taskId),
                p);
    }

    ChanceTaskProto encode4Client(int taskId, Prize chanceTaskPrize,
            TaskTargetProgress[] progress, int swallowPercent){

        ChanceTaskProto.Builder builder = ChanceTaskProto.newBuilder();

        TaskDataProto taskDataProto = taskProto;
        if (chanceTaskPrize != fixedPrize){
            taskDataProto = taskProto.toBuilder()
                    .setPrize(chanceTaskPrize.encode4Client()).build();
        }

        builder.setBaseTask(
                TaskData.encodeTaskProto(taskId, taskDataProto, progress))
                .setSwallowPercent(swallowPercent);

        builder.setQuality(quality.getNumber());
        builder.setHeadImage(headImage);

        return builder.build();
    }

    @Override
    public String toString(){
        return "机缘任务-" + id;
    }
}
