package app.game.data.divine;

import app.game.data.ConfigService;
import app.game.data.goods.GoodsData;
import app.protobuf.GoodsServerContent.GoodsServerProto;
import app.protobuf.HeroServerContent.DivineGlobalLogProto;

import com.google.protobuf.ByteString;

/**
 * @author Liwei
 *
 */
public class DivineGlobalLog{

    final long heroId;

    final byte[] heroName;

    final GoodsData data;

    final byte[] dynamicData;

    private final GoodsServerProto goodsServerProto;

    private DivineGlobalLogProto proto;

    public DivineGlobalLog(long heroId, byte[] heroName, GoodsData data,
            byte[] dynamicData, GoodsServerProto serverProto){
        this.heroId = heroId;
        this.heroName = heroName;
        this.data = data;
        this.dynamicData = dynamicData;
        this.goodsServerProto = serverProto;
    }

    DivineGlobalLogProto encode(){
        DivineGlobalLogProto p = proto;

        if (p == null){
            proto = p = DivineGlobalLogProto.newBuilder().setHeroId(heroId)
                    .setHeroName(ByteString.copyFrom(heroName))
                    .setGoods(goodsServerProto).build();
        }

        return p;
    }

    static DivineGlobalLog decode(DivineGlobalLogProto proto,
            ConfigService configService){

        int goodsId = proto.getGoods().getId();

        GoodsData data = configService.getGoods().get(goodsId);
        if (data == null){
            return null;
        }

        byte[] dynamicData = data.encodeGoodsProto(proto.getGoods())
                .toByteArray();

        DivineGlobalLog log = new DivineGlobalLog(proto.getHeroId(), proto
                .getHeroName().toByteArray(), data, dynamicData,
                proto.getGoods());

        log.proto = proto;

        return log;
    }
}
