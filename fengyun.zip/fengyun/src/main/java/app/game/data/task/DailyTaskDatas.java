package app.game.data.task;

import static com.mokylin.sink.util.Preconditions.checkArgument;
import static com.mokylin.sink.util.Preconditions.checkNotNull;

import java.util.List;

import app.game.data.GameObjects;
import app.game.data.Prize;
import app.game.data.PrizeConfigs;
import app.game.data.goods.GoodsData;
import app.game.data.goods.GoodsDatas;
import app.game.data.scene.CollectObjects;
import app.game.data.scene.MonsterData;
import app.game.data.scene.MonsterDatas;
import app.game.data.scene.Npcs;
import app.game.data.scene.SceneDatas;
import app.protobuf.ConfigContent.TaskConfig;
import app.utils.VariableConfig;

import com.google.common.collect.Lists;
import com.mokylin.collection.IntHashMap;
import com.mokylin.sink.util.RandomNumber;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class DailyTaskDatas{

    static final String LOCATION = "config/data/task/daily_task.txt";

    private static final int DIFFI_MAX_STAR = 10;

    static final int PRIZE_MAX_STAR = 10;

    private final DailyTaskData[][] levelTaskDatas;

    private final IntHashMap<DailyTaskGroup> taskGroupMap;

    private final Prize extraPrize;

//
//    DailyTaskDatas(GameObjects go, Npcs npcs, GoodsDatas goodsDatas,
//            MonsterDatas monsters, PrizeConfigs prizes,
//            DailyTaskPrizes dailyTaskPrizes, CollectObjects collectObjects,
//            IntHashMap<MonsterData> monLevelMap){
//
//        // 日常任务唯一ID，通过移位计算，diffiStar占4个bit
//        checkArgument(DIFFI_MAX_STAR < 16, "日常任务最大难度星级错误，最大只能是15，star: %s",
//                DIFFI_MAX_STAR);
//
//        // 日常任务唯一ID，通过移位计算，prizeStar占4个bit
//        checkArgument(PRIZE_MAX_STAR < 16, "日常任务最大奖励星级错误，最大只能是15，star: %s",
//                PRIZE_MAX_STAR);
//
//        List<ObjectParser> data = go.loadFile(LOCATION);
//        checkArgument(!data.isEmpty(), "日常任务没有配置");
//
//        IntHashMap<List<DailyTaskGroup>> map = new IntHashMap<>();
//        for (ObjectParser p : data){
//            int level = p.getIntKey("level");
//            checkArgument(level >= 1, "日常任务等级居然 <= 0");
//
//            List<DailyTaskGroup> list = map.get(level);
//            if (list == null){
//                list = Lists.newLinkedList();
//                map.put(level, list);
//            }
//
//            DailyTaskGroup group = new DailyTaskGroup(level, list.size(), p,
//                    npcs, monsters, goodsDatas, dailyTaskPrizes,
//                    collectObjects, monLevelMap);
//
//            list.add(group);
//        }
//
//        List<LevelDailyTasks> tasks = Lists.newLinkedList();
//        for (Entry<List<DailyTaskGroup>> entry : map.entrySet()){
//            tasks.add(new LevelDailyTasks(entry.getKey(), entry.getValue()));
//        }
//
//        taskMap = new IntHashMap<>();
//        for (LevelDailyTasks g : tasks){
//            for (DailyTaskData t : g.taskDatas){
//                checkArgument(taskMap.put(t.dailyTaskId, t) == null,
//                        "日常任务ID重复, id: %s", t.dailyTaskId);
//            }
//        }
//
//        Collections.sort(tasks, new Comparator<LevelDailyTasks>(){
//            @Override
//            public int compare(LevelDailyTasks o1, LevelDailyTasks o2){
//                // 根据level从低到高
//                return o1.level - o2.level;
//            }
//        });
//
//        levelTaskDatas = new LevelDailyTasks[VariableConfig.HERO_MAX_LEVEL];
//        for (int i = 0; i < VariableConfig.HERO_MAX_LEVEL; i++){
//            int level = i + 1;
//
//            LevelDailyTasks levelDailyTask = null;
//            for (LevelDailyTasks t : tasks){
//                levelDailyTask = t;
//                if (level < levelDailyTask.level)
//                    break;
//            }
//
//            levelTaskDatas[i] = levelDailyTask;
//        }
//
//        // 日常额外奖励
//        extraPrize = dailyTaskPrizes.getExtrPrize();
//    }

    DailyTaskDatas(GameObjects go, Npcs npcs, GoodsDatas goodsDatas,
            MonsterDatas monsters, PrizeConfigs prizes,
            DailyTaskPrizes dailyTaskPrizes, CollectObjects collectObjects,
            SceneDatas sceneDatas, IntHashMap<MonsterData> monLevelMap){

        List<ObjectParser> data = go.loadFile(LOCATION);
        checkArgument(!data.isEmpty(), "日常任务没有配置");

        taskGroupMap = new IntHashMap<>();
        for (ObjectParser p : data){
            DailyTaskGroup group = new DailyTaskGroup(p, npcs, monsters,
                    goodsDatas, dailyTaskPrizes, collectObjects, sceneDatas,
                    monLevelMap);

            taskGroupMap.putUnique(group.id, group);
        }

        IntHashMap<List<DailyTaskData>> taskLevelMap = new IntHashMap<>();
        for (DailyTaskGroup group : taskGroupMap.values()){
            for (int lv = group.minLevel; lv <= group.maxLevel; lv++){
                List<DailyTaskData> list = taskLevelMap.get(lv);
                if (list == null){
                    list = Lists.newLinkedList();
                    taskLevelMap.put(lv, list);
                }

                for (DailyTaskData taskData : group.taskDatas){
                    list.add(taskData);
                }
            }
        }

        List<DailyTaskData> acceptLevelTaskList = checkNotNull(
                taskLevelMap.get(VariableConfig.DAILY_TASK_ACCEPT_LEVEL),
                "日常任务开放等级为%s级，但是没有找到这个等级的日常任务",
                VariableConfig.DAILY_TASK_ACCEPT_LEVEL);

        DailyTaskData[] acceptLevelTasks = acceptLevelTaskList
                .toArray(DailyTaskData.EMPTY_ARRAY);

        levelTaskDatas = new DailyTaskData[VariableConfig.HERO_MAX_LEVEL][];
        for (int lv = 1; lv <= VariableConfig.HERO_MAX_LEVEL; lv++){
            List<DailyTaskData> taskList = taskLevelMap.get(lv);
            if (taskList == null){
                if (lv <= VariableConfig.DAILY_TASK_ACCEPT_LEVEL){
                    levelTaskDatas[lv - 1] = acceptLevelTasks;
                } else{
                    levelTaskDatas[lv - 1] = levelTaskDatas[lv - 2];
                }
                continue;
            }

            levelTaskDatas[lv - 1] = taskList
                    .toArray(DailyTaskData.EMPTY_ARRAY);
        }

        // 日常额外奖励
        extraPrize = dailyTaskPrizes.getExtrPrize();
    }

    public Prize getDailyTaskExtraPrize(){
        return extraPrize;
    }

    DailyTaskData random(int level){
        DailyTaskData[] taskDatas = null;

        if (level > 0 && level <= levelTaskDatas.length){
            taskDatas = levelTaskDatas[level - 1];
        } else if (level <= 0){
            taskDatas = levelTaskDatas[0];
        } else{
            taskDatas = levelTaskDatas[levelTaskDatas.length - 1];
        }

        return taskDatas[RandomNumber.getRate(taskDatas.length, true)];
    }

    DailyTaskData get(int id, int diffiStar, int prizeStar){
        DailyTaskGroup group = taskGroupMap.get(id);
        if (group != null){
            return group.get(diffiStar, prizeStar);
        }

        return null;
    }

    private static class DailyTaskGroup{

        private final int id;

        private final int minLevel;

        private final int maxLevel;

        private final DailyTaskData[] taskDatas;

        DailyTaskGroup(ObjectParser p, Npcs npcs, MonsterDatas monsters,
                GoodsDatas goodsDatas, DailyTaskPrizes prizes,
                CollectObjects collectObjects, SceneDatas sceneDatas,
                IntHashMap<MonsterData> monLevelMap){

            id = p.getIntKey("id");

            minLevel = p.getIntKey("min_level");
            maxLevel = p.getIntKey("max_level");
            checkArgument(
                    minLevel > 0 && minLevel <= maxLevel
                            && maxLevel <= VariableConfig.HERO_MAX_LEVEL,
                    "日常任务-%s 配置的最小等级无效, minLevel > 0 && minLevel <= maxLevel && maxLevel <= HERO_MAX_LEVEL, minLevel: %s, maxLevel:%s, heroMaxLevel: %s",
                    id, minLevel, maxLevel, VariableConfig.HERO_MAX_LEVEL);

            DailyTaskPrize prize = checkNotNull(prizes.get(p.getKey("prize")),
                    "日常任务-%s 奖励不存在， 奖励名称[%s]", id, p.getKey("prize"));

            // 任务目标
            TaskTarget[] taskTargets = getTaskTarget(p, npcs, monsters,
                    goodsDatas, collectObjects, sceneDatas, monLevelMap);

            taskDatas = new DailyTaskData[DIFFI_MAX_STAR * PRIZE_MAX_STAR];
            for (int diffiStar = 1; diffiStar <= DIFFI_MAX_STAR; diffiStar++){

                TaskTarget[] targets = new TaskTarget[]{taskTargets[diffiStar - 1]};

                for (int prizeStar = 1; prizeStar <= PRIZE_MAX_STAR; prizeStar++){
                    DailyTaskData task = new DailyTaskData(id, diffiStar,
                            prizeStar, targets, prize);

                    taskDatas[getIndex(diffiStar, prizeStar)] = task;
                }
            }

            // 设置满星奖励任务
            for (int diffiStar = 1; diffiStar <= DIFFI_MAX_STAR; diffiStar++){
                DailyTaskData fullStarPrizeTask = taskDatas[getIndex(diffiStar,
                        PRIZE_MAX_STAR)];
                for (int prizeStar = 1; prizeStar <= PRIZE_MAX_STAR; prizeStar++){
                    taskDatas[getIndex(diffiStar, prizeStar)]
                            .setFullStarPrizeTask(fullStarPrizeTask);
                }
            }

            // 设置一星难度任务
            for (int prizeStar = 1; prizeStar <= PRIZE_MAX_STAR; prizeStar++){
                DailyTaskData oneStarDiffiTask = taskDatas[getIndex(1,
                        prizeStar)];

                for (int diffiStar = 1; diffiStar <= DIFFI_MAX_STAR; diffiStar++){
                    taskDatas[getIndex(diffiStar, prizeStar)]
                            .setOneStarDiffiTask(oneStarDiffiTask);
                }
            }

            for (DailyTaskData task : taskDatas){
                checkNotNull(task.getOneStarDiffiTask(), "存在任务没有设置一星难度任务");
                checkNotNull(task.getFullStarPrizeTask(), "存在任务没有设置满星奖励任务");
            }
        }

        private DailyTaskData get(int diffiStar, int prizeStar){
            if (diffiStar > 0 && diffiStar <= DIFFI_MAX_STAR && prizeStar > 0
                    && prizeStar <= PRIZE_MAX_STAR){
                return taskDatas[getIndex(diffiStar, prizeStar)];
            }

            return null;
        }

        private int getIndex(int diffiStar, int prizeStar){
            return (diffiStar - 1) * PRIZE_MAX_STAR + (prizeStar - 1);
        }

        private TaskTarget[] getTaskTarget(ObjectParser p, Npcs npcs,
                MonsterDatas monsters, GoodsDatas goodsDatas,
                CollectObjects collectObjects, SceneDatas sceneDatas,
                IntHashMap<MonsterData> monLevelMap){

            String targetStr = p.getKey("target");

            checkArgument(targetStr.indexOf("#") < 0, "%s 配置了多个任务目标", this);

            TaskTarget t = TaskTarget.newTaskTarget(targetStr, npcs, monsters,
                    goodsDatas, collectObjects, sceneDatas, monLevelMap);

            // 如果日常任务可以配置跟NPC对话的任务，则需要在任务对话中进行处理
            checkArgument(!t.isReplyNpc(), "%s中配置了跟NPC对话的任务", this);

            // 如果日常任务可以配置升级任务，需要在英雄升级时检测日常任务是否可以完成
            checkArgument(!t.isUpgradeLevel(), "%s中配置了升级任务?", this);

            // 如果日常任务可以配置采集任务，需要在采集物品加入检测是否可以完成
            checkArgument(!t.isCollectGoods(), "%s中配置了采集物品任务?", this);

            // 如果日常任务可以配置进入副本任务，需要在进入副本加入检测是否可以完成
            checkArgument(!t.isEnterDungeon(), "%s中配置了采集物品任务?", this);

            String[] diffiParams = p.getStringArray("diffi_param");
            checkArgument(diffiParams.length == DIFFI_MAX_STAR,
                    "%s中diffi_param参数个数需要跟日常任务难度星级个数一致, 星级:%s", this,
                    DIFFI_MAX_STAR);

            TaskTarget[] targets = new TaskTarget[DIFFI_MAX_STAR];
            if (t.isKillMonster()){
                // 杀怪个数
                int previous = 0;
                for (int i = 0; i < diffiParams.length; i++){
                    String param = diffiParams[i];
                    int count = Integer.parseInt(param);
                    checkArgument(previous < count, "%s中%s星难度杀怪数量 < 下一难度杀怪数量",
                            this, i);

                    targets[i] = TaskTarget.newKillMonsterTarget(t.killMonster,
                            count);
                }
            } else if (t.isMonsterDropGoods()){
                // 收集掉落物品个数
                int previous = 0;
                for (int i = 0; i < diffiParams.length; i++){
                    String param = diffiParams[i];
                    int count = Integer.parseInt(param);
                    checkArgument(previous < count,
                            "%s中%s星难度收集怪物掉落物品数量 < 下一难度收集怪物掉落物品数量", this, i);
                    targets[i] = TaskTarget.newMonsterDropGoodsTarget(
                            t.dropGoodsMonster, t.dropGoodsName, count,
                            t.dropRate);
                }
            } else if (t.isCollectDepotGoods()){
                // 物品id
                for (int i = 0; i < diffiParams.length; i++){
                    String param = diffiParams[i];
                    String[] paramArray = param.split(";");
                    checkArgument(
                            paramArray.length == 1 || paramArray.length == 2,
                            "%s中%s星难度配置的收集背包物品的参数格式错误，格式[goodsId;count], params: %s",
                            this, i, param);

                    int goodsId = Integer.parseInt(paramArray[0]);
                    GoodsData goodsData = checkNotNull(goodsDatas.get(goodsId),
                            "%s中%s星难度配置的收集背包物品不存在, params: %s", this, i, param);

                    int count = 1;
                    if (paramArray.length > 1){
                        count = Integer.parseInt(paramArray[1]);
                        checkArgument(count > 0,
                                "%s中%s星难度配置的收集背包物品的收集数量<=0，参数: %s", this, i,
                                param);
                    }

                    targets[i] = TaskTarget.newDepotGoodsTarget(goodsData,
                            count);
                }
            } else{
                throw new IllegalArgumentException(this + "中配置了未知的任务类型");
            }

            return targets;
        }

        @Override
        public String toString(){
            return "日常任务-" + id;
        }
    }

    void generateProto(TaskConfig.Builder builder){
        builder.setDailyTaskMaxRound(VariableConfig.DAILY_TASK_MAX_ROUND);
        builder.setDailyTaskExtraPrize(extraPrize.encode4Client());
        builder.setDailyTaskReduceDiffiCost(VariableConfig.DAILY_TASK_REDUCE_DIFFI_COST);
        builder.setDailyTaskAddPrizeCost(VariableConfig.DAILY_TASK_ADD_PRIZE_COST);
        builder.setDailyTaskAutoCompleteCost(VariableConfig.DAILY_TASK_AUTO_COMPLETE_COST);
    }
}
