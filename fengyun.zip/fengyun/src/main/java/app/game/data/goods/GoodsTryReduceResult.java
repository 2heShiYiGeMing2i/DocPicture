package app.game.data.goods;

import com.mokylin.collection.IntArrayList;

/**
 * @author Liwei
 *
 */
public class GoodsTryReduceResult{

    public static GoodsTryReduceResult current(){
        return localObject.get();
    }

    private static final ThreadLocal<GoodsTryReduceResult> localObject = new ThreadLocal<GoodsTryReduceResult>(){
        protected GoodsTryReduceResult initialValue(){
            return new GoodsTryReduceResult();
        }
    };

    private boolean success;

    private final IntArrayList posCountList;

    private GoodsTryReduceResult(){
        posCountList = new IntArrayList();
    }

    public void clear(){
        success = false;
        posCountList.clear();
    }

    public boolean checkStatus(){
        return !success && posCountList.isEmpty();
    }

    public void setSuccess(){
        success = true;
    }

    public boolean isSuccess(){
        return success;
    }

    public IntArrayList getPosCountList(){
        return posCountList;
    }
}
