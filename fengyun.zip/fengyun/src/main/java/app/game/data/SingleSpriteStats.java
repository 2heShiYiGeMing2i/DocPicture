package app.game.data;

import java.util.List;

import com.google.common.annotations.VisibleForTesting;
import com.google.inject.Inject;
import com.mokylin.collection.IntHashMap;
import com.mokylin.sink.util.parse.ObjectParser;

public class SingleSpriteStats{

    public static final String LOCATION = "config/data/single_sprite_stat.txt";

    private final IntHashMap<SingleSpriteStat> globalMap;

    @Inject
    SingleSpriteStats(GameObjects go){
        List<ObjectParser> data = go.loadFile(LOCATION);
        globalMap = new IntHashMap<SingleSpriteStat>(data.size() + 1);

        for (ObjectParser p : data){
            SingleSpriteStat s = new SingleSpriteStat(p);
            globalMap.putUnique(s.id, s);
        }
    }

    public SingleSpriteStat get(int id){
        return globalMap.get(id);
    }

    @VisibleForTesting
    IntHashMap<SingleSpriteStat> getGlobalMap(){
        return globalMap;
    }

}
