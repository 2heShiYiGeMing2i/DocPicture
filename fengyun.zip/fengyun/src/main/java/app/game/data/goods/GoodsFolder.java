package app.game.data.goods;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mokylin.sink.util.Utils;

public class GoodsFolder{

    private static final Logger logger = LoggerFactory
            .getLogger(GoodsFolder.class);

    public static GoodsFolder current(){
        return localGoodsFolder.get();
    }

    private static final ThreadLocal<GoodsFolder> localGoodsFolder = new ThreadLocal<GoodsFolder>(){
        protected GoodsFolder initialValue(){
            return new GoodsFolder();
        }
    };

    private static final int length = 512;

    private static final int mask = length - 1;

    static{
        if (!Utils.isPowerOf2(length)){
            throw new RuntimeException("GoodsFolder的length不是2的n次方: " + length);
        }
    }

    final Header[] table;

    private GoodsFolder(){
        table = new Header[length];
        for (int i = 0; i < length; i++){
            table[i] = new Header();
        }
    }

    public Goods putIfNotSameGoods(Goods goods){
        // Makes sure the key is not already in the hashtable.
        Header tab[] = table;
        int index = getIndex(goods.getId());
        Header header = tab[index];
        Goods e = header.head;
        for (int i = 0; i < header.count; i++){
            if (e == null){
                logger.error("putIfNotSameGoods时有BUG，e == null的时候，进到循环里面去了");
                throw new RuntimeException(
                        "putIfNotSameGoods时有BUG，e == null的时候，进到循环里面去了");
            }

            if (e.isSameGoods(goods))
                return e;

            e = e.next;
        }

        // link entry.
        if (goods.next != null){
            logger.error("putIfNotSameGoods时有BUG，goods.next != null");
            throw new RuntimeException(
                    "putIfNotSameGoods时有BUG，goods.next != null");
        }

        goods.next = header.head;
        if (header.head != null){
            if (header.head.prev != null){
                logger.error("putIfNotSameGoods时有BUG，head.prev != null");
                throw new RuntimeException(
                        "putIfNotSameGoods时有BUG，head.prev != null");
            }

            header.head.prev = goods;
        }

        header.head = goods;
        header.count++;
        return null;
    }

    public void replace(Goods src, Goods toReplace){

        Goods next = src.next;
        if (next != null){
            toReplace.next = next;
            next.prev = toReplace;
        }

        Goods prev = src.prev;
        if (prev != null){
            toReplace.prev = prev;
            prev.next = toReplace;
        } else{
            // source 是head
            Header header = table[getIndex(src.getId())];
            if (header.head != src){
                logger.error("replace时有BUG，head != src");
                throw new RuntimeException("replace时有BUG，head != src");
            }

            header.head = toReplace;
        }

        src.prev = src.next = null;
    }

    public void remove(Goods goods){

        Header tab[] = table;
        int index = getIndex(goods.getId());
        Header header = tab[index];

        Goods prev = goods.prev;
        Goods next = goods.next;
        if (next != null){
            next.prev = prev;
        }

        if (prev != null){
            prev.next = next;
        } else{
            // source 是head
            if (header.head != goods){
                logger.error("remove时有BUG，head != goods");
                throw new RuntimeException("remove时有BUG，head != goods");
            }

            header.head = next;
        }

        goods.prev = goods.next = null;
        header.count--;
    }

    private int getIndex(int key){
        return key & mask;
    }

    public void beforeClear(){
        Header[] tab = table;
        for (Header header : tab){
            header.count = 0;
            header.head = null;
        }
    }

    public void afterClear(){
        Header[] tab = table;
        for (Header header : tab){
            Goods e = header.head;
            for (int index = 0; index < header.count; index++){
                if (e == null){
                    logger.error("afterClear时有BUG，e == null的时候，进到循环里面去了");
                    throw new RuntimeException(
                            "afterClear时有BUG，e == null的时候，进到循环里面去了");
                }

                Goods next = e.next;
                e.prev = e.next = null;
                e = next;
            }

            header.count = 0;
            header.head = null;
        }
    }

    static class Header{

        int count;

        Goods head;
    }
}
