package app.game.data;

import static com.mokylin.sink.util.Preconditions.checkArgument;
import static com.mokylin.sink.util.Preconditions.checkNotNull;

import java.util.EnumMap;
import java.util.List;

import app.game.data.goods.GoodsDatas;
import app.game.data.goods.GoodsRandomer;
import app.game.data.goods.GoodsWrapper;
import app.game.data.scene.PlunderGroup;
import app.game.data.scene.PlunderGroups;
import app.protobuf.HeroServerContent.RaceId;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.mokylin.collection.Pair;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class PrizeConfig{

    private static final String RACE = "RACE";

    private static final EnumMap<RaceId, GoodsRandomer[]> EMPTY_RACE_GOODS_MAP = Maps
            .newEnumMap(RaceId.class);

    private static final EnumMap<RaceId, PlunderGroup[]> EMPTY_RACE_GROUP_MAP = Maps
            .newEnumMap(RaceId.class);

    final String name;

    final int exp;

    final int realAir;

    final int guildLilian;

    final int money;

    final int honor;

    // 所有职业公共的
    final GoodsRandomer[] sharedGoods;

    final EnumMap<RaceId, GoodsRandomer[]> raceGoodsMap;

    // 所有职业都有的
    final PlunderGroup[] sharedGroups;

    final EnumMap<RaceId, PlunderGroup[]> raceGroupMap;

    // 有特殊职业物品
    final transient boolean isRaceDiff;

    final transient boolean hasExpireTimeGoods;

    final transient boolean hasDurationGoods;

    final transient boolean hasUnbindedGoods;

    final transient boolean isVarPrize;

    PrizeConfig(ObjectParser p, GoodsDatas goodsDatas, PlunderGroups groups){
        name = p.getKey("name");
        exp = p.getIntKey("exp");
        money = p.getIntKey("money");
        realAir = p.getIntKey("real_air");
        guildLilian = p.getIntKey("guild_lilian");
        honor = p.getIntKey("honor");

        checkArgument(exp >= 0, "%s中经验不能是负数", this);
        checkArgument(money >= 0, "%s中银两不能是负数", this);
        checkArgument(realAir >= 0, "%s中真气不能是负数", this);
        checkArgument(guildLilian >= 0, "%s中帮派历练不能是负数", this);
        checkArgument(honor >= 0, "%s中荣誉值不能是负数", this);

        // 奖励物品
        String[] goodsItems = p.getStringArray("goods_item");
        String[] goodsItemParams = p.getStringArray("goods_item_param");

        checkArgument(goodsItems.length == goodsItemParams.length,
                "%s参数goods_item与goods_item_param的个数不一致", this);

        List<Pair<RaceId, GoodsRandomer>> randomerList = Lists.newLinkedList();
        for (int i = 0; i < goodsItems.length; i++){
            String item = goodsItems[i];
            if (item.isEmpty())
                continue;

            int count = 1;
            RaceId raceId = null;
            String goodsParam = goodsItemParams[i];
            if (!goodsParam.isEmpty()){

                String[] params = goodsParam.split(";");
                count = Utils.parseInt(this, params[0]);

                for (int idx = 1; idx < params.length; idx++){
                    String[] pdata = params[idx].split("=");
                    switch (pdata[0]){
                        case RACE:{
                            if (pdata.length > 1){
                                raceId = checkNotNull(RaceId.valueOf(Utils
                                        .parseInt(this, pdata[1])),
                                        "%s 物品配置了无效的职业限制, %s", this, goodsParam);
                                break;
                            }

                            throw new IllegalArgumentException(this
                                    + "中goods_item_param字段配置了无效的参数，"
                                    + goodsParam);
                        }
                        default:{
                            throw new IllegalArgumentException(this
                                    + "中goods_item_param字段配置了无效的参数，"
                                    + goodsParam);
                        }
                    }
                }
            }

            checkArgument(count > 0, "%s中第%s个物品的个数<=0", this, (i + 1));

            GoodsRandomer randomer = GoodsRandomer.newRandomer(this, item,
                    goodsDatas, count);

            randomerList.add(Pair.of(raceId, randomer));
        }

        // 奖励组包
        String[] groupItems = p.getStringArray("group_item");
        String[] groupItemParams = p.getStringArray("group_item_param");

        checkArgument(groupItems.length == groupItemParams.length,
                "%s参数group_item与group_item_param的个数不一致", this);

        List<Pair<RaceId, PlunderGroup>> raceGroupList = Lists.newLinkedList();
        for (int i = 0; i < groupItems.length; i++){
            String item = groupItems[i];
            if (item.isEmpty())
                continue;

            RaceId raceId = null;
            String goodsParam = groupItemParams[i];
            if (!goodsParam.isEmpty()){

                String[] params = goodsParam.split(";");
                for (int idx = 0; idx < params.length; idx++){
                    String[] pdata = params[idx].split("=");
                    switch (pdata[0]){
                        case RACE:{
                            if (pdata.length > 1){
                                raceId = checkNotNull(RaceId.valueOf(Utils
                                        .parseInt(this, pdata[1])),
                                        "%s 组包配置了无效的职业限制, %s", this, goodsParam);
                                break;
                            }

                            throw new IllegalArgumentException(this
                                    + "中group_item_param字段配置了无效的参数，"
                                    + goodsParam);
                        }
                        default:{
                            throw new IllegalArgumentException(this
                                    + "中group_item_param字段配置了无效的参数，"
                                    + goodsParam);
                        }
                    }
                }
            }

            PlunderGroup group = checkNotNull(groups.get(item),
                    "%s 配置的组包没找到, %s", this, item);

            raceGroupList.add(Pair.of(raceId, group));
        }

        boolean hasGoodsRaceDiff = false;
        boolean hasExpireTimeGoods = false;
        boolean hasDurationGoods = false;
        boolean hasUnbindedGoods = false;
        boolean isVarPrize = false;

        // 物品
        for (Pair<RaceId, GoodsRandomer> pair : randomerList){
            if (pair.left != null){
                hasGoodsRaceDiff = true;
            }

            if (pair.right.getExpireTime() > 0){
                hasExpireTimeGoods = true;
            }

            if (pair.right.getDuration() > 0){
                hasDurationGoods = true;
            }

            if (!pair.right.isBinded()){
                hasUnbindedGoods = true;
            }

            if (pair.right.hasRandomProperties()){
                isVarPrize = true;
            }
        }

        List<GoodsRandomer> goodsList = Lists
                .newArrayListWithCapacity(randomerList.size());
        for (Pair<RaceId, GoodsRandomer> pair : randomerList){
            if (pair.left == null)
                goodsList.add(pair.right);
        }
        sharedGoods = goodsList.toArray(GoodsRandomer.EMPTY_ARRAY);

        if (hasGoodsRaceDiff){
            raceGoodsMap = Maps.newEnumMap(RaceId.class);
            for (RaceId raceId : RaceId.values()){
                goodsList.clear();

                for (Pair<RaceId, GoodsRandomer> pair : randomerList){
                    if (pair.left == raceId)
                        goodsList.add(pair.right);
                }

                checkArgument(!goodsList.isEmpty(), "%s 中没有配置%s 职业的奖励物品", this,
                        raceId);

                raceGoodsMap.put(raceId,
                        goodsList.toArray(GoodsRandomer.EMPTY_ARRAY));
            }

        } else{
            raceGoodsMap = EMPTY_RACE_GOODS_MAP;
        }

        // 组包
        boolean hasGroupRaceDiff = false;

        for (Pair<RaceId, PlunderGroup> pair : raceGroupList){
            if (pair.left != null){
                hasGroupRaceDiff = true;
            }

            for (GoodsRandomer randomer : pair.right.getGoodsRandomers()){
                if (randomer.getExpireTime() > 0){
                    hasExpireTimeGoods = true;
                }

                if (randomer.getDuration() > 0){
                    hasDurationGoods = true;
                }

                if (!randomer.isBinded()){
                    hasUnbindedGoods = true;
                }

                if (randomer.hasRandomProperties()){
                    isVarPrize = true;
                }
            }

            // 配置了掉落组包，说明奖励不是固定的
            isVarPrize = true;
        }

        List<PlunderGroup> groupList = Lists
                .newArrayListWithCapacity(randomerList.size());
        for (Pair<RaceId, PlunderGroup> pair : raceGroupList){
            if (pair.left == null)
                groupList.add(pair.right);
        }
        sharedGroups = groupList.toArray(PlunderGroup.EMPTY_ARRAY);

        if (hasGroupRaceDiff){
            raceGroupMap = Maps.newEnumMap(RaceId.class);
            for (RaceId raceId : RaceId.values()){
                groupList.clear();

                for (Pair<RaceId, PlunderGroup> pair : raceGroupList){
                    if (pair.left == raceId)
                        groupList.add(pair.right);
                }

                checkArgument(!groupList.isEmpty(), "%s 中没有配置%s 职业的奖励物品", this,
                        raceId);

                raceGroupMap.put(raceId,
                        groupList.toArray(PlunderGroup.EMPTY_ARRAY));
            }

        } else{
            raceGroupMap = EMPTY_RACE_GROUP_MAP;
        }

        this.isRaceDiff = hasGoodsRaceDiff || hasGroupRaceDiff;
        this.hasExpireTimeGoods = hasExpireTimeGoods;
        this.hasDurationGoods = hasDurationGoods;
        this.hasUnbindedGoods = hasUnbindedGoods;
        this.isVarPrize = isVarPrize;
    }

    public int getExp(){
        return exp;
    }

    public int getMoney(){
        return money;
    }

    public int getGuildLilian(){
        return guildLilian;
    }

    public int getRealAir(){
        return realAir;
    }

    public int getHonor(){
        return honor;
    }

    public boolean isRaceDiff(){
        return isRaceDiff;
    }

    public boolean hasExipreTimeGoods(){
        return hasExpireTimeGoods;
    }

    public boolean hasDurationGoods(){
        return hasDurationGoods;
    }

    public boolean hasUnbindedGoods(){
        return hasUnbindedGoods;
    }

    /**
     * true表示可变的奖励
     * @return
     */
    public boolean isVarPrize(){
        return isVarPrize;
    }

    public Prize random(){

        int goodsCount = sharedGoods.length + sharedGroups.length;

        GoodsWrapper[] wrappers = GoodsWrapper.EMPTY_ARRAY;
        if (goodsCount > 0){
            List<GoodsWrapper> list = Lists
                    .newArrayListWithCapacity(goodsCount);

            for (GoodsRandomer randomer : sharedGoods){
                list.add(randomer.getGoodsWrapper());
            }

            for (PlunderGroup group : sharedGroups){
                list.add(group.randomGoodsWrapper());
            }

            wrappers = list.toArray(GoodsWrapper.EMPTY_ARRAY);
        }

        return new Prize(exp, money, realAir, guildLilian, honor, wrappers);
    }

    public Prize random(RaceId raceId){

        int goodsCount = sharedGoods.length + sharedGroups.length;

        GoodsRandomer[] raceGoodsArray = raceGoodsMap.get(raceId);
        if (raceGoodsArray != null)
            goodsCount += raceGoodsArray.length;

        PlunderGroup[] raceGroupArray = raceGroupMap.get(raceId);
        if (raceGroupArray != null)
            goodsCount += raceGroupArray.length;

        GoodsWrapper[] wrappers = GoodsWrapper.EMPTY_ARRAY;
        if (goodsCount > 0){
            List<GoodsWrapper> list = Lists
                    .newArrayListWithCapacity(goodsCount);

            for (GoodsRandomer randomer : sharedGoods){
                list.add(randomer.getGoodsWrapper());
            }

            for (PlunderGroup group : sharedGroups){
                list.add(group.randomGoodsWrapper());
            }

            if (raceGoodsArray != null){
                for (GoodsRandomer randomer : raceGoodsArray){
                    list.add(randomer.getGoodsWrapper());
                }
            }

            if (raceGroupArray != null){
                for (PlunderGroup group : raceGroupArray){
                    list.add(group.randomGoodsWrapper());
                }
            }

            wrappers = list.toArray(GoodsWrapper.EMPTY_ARRAY);
        }

        return new Prize(exp, money, realAir, guildLilian, honor, wrappers);
    }

    @Override
    public String toString(){
        return "奖励-" + name;
    }
}
