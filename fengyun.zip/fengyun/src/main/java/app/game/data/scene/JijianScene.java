package app.game.data.scene;

import org.joda.time.DateTimeConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.entity.Hero;
import app.game.module.WelfareMessages;
import app.game.module.scene.AbstractDungeonScene;
import app.game.module.scene.AbstractHeroFightModule;
import app.game.module.scene.HeroFightModule;
import app.game.module.scene.IDungeonService;
import app.game.module.scene.IHeroThreadUpdateScene;
import app.game.module.scene.JijianMessages;
import app.game.module.scene.JijianModule.HeroRadiateObject;
import app.game.module.scene.JijianModule.JijianRankObject;
import app.game.service.log.LogService;
import app.protobuf.ConfigContent.ShengWangType;

import com.mokylin.collection.LongConcurrentHashMap;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.annotation.MultiThread;
import com.mokylin.sink.util.annotation.SelfThreadOnly;
import com.mokylin.sink.util.concurrent.PaddedAtomicInteger;

/**
 * @author Liwei
 *
 */
public class JijianScene extends AbstractDungeonScene implements
        IHeroThreadUpdateScene{

    private static final Logger logger = LoggerFactory
            .getLogger(JijianScene.class);

    public static final JijianScene[] EMPTY_ARRAY = new JijianScene[0];

    private final JijianSceneData sceneData;

    private final LongConcurrentHashMap<JijianRankObject> heroRankMap;

    private final long battleEndTime;

    private final long dungeonExpireTime;

    private final PaddedAtomicInteger counter;

    public JijianScene(JijianSceneData sceneData, int dungeonId,
            IDungeonService dungeonService, LogService logService,
            LongConcurrentHashMap<JijianRankObject> heroRankMap,
            long battleEndTime){
        super(sceneData, dungeonId, dungeonService, logService, 0, false);
        this.sceneData = sceneData;
        this.battleEndTime = battleEndTime;
        this.dungeonExpireTime = battleEndTime
                + DateTimeConstants.MILLIS_PER_MINUTE; // 一分钟后过期

        counter = new PaddedAtomicInteger();

        this.heroRankMap = heroRankMap;
    }

    public boolean tryEnter(){
        if (counter.get() < sceneData.lineCapacity){
            int c = counter.incrementAndGet();
            if (c <= sceneData.lineCapacity)
                return true;

            counter.decrementAndGet();
        }
        return false;
    }

    @Override
    @SelfThreadOnly
    public void addHero(AbstractHeroFightModule heroFightModule, long ctime,
            boolean isEnteringFirstScene){
        super.addHero(heroFightModule, ctime, isEnteringFirstScene);

        int result = heroFightModule.getHero().setDailyActivity(
                sceneData.JIJIAN_KEY, 0);
        if (result > 0){
            logger.warn("JijianScene.addHero时, 已经花钱参与过了");
            heroFightModule.doLeaveDungeon();
            return;
        } else if (result < 0){
            heroFightModule.sendMessage(WelfareMessages
                    .dailyActivityJoinedMsg(sceneData.JIJIAN_KEY));
        }

        heroFightModule.getHero().tryResetJijian(sceneID, battleEndTime);

        // 更新场景中的英雄状态
        JijianRankObject rankObject = heroRankMap.get(heroFightModule.getID());
        if (rankObject != null){
            rankObject.isInScene = true;
            rankObject.setSwordSacificeTimes(
                    heroFightModule.getHero().jijianYuanbaoTotalTimes,
                    heroFightModule.getHero().jijianUpdateTime);
        }

        if (heroFightModule instanceof HeroFightModule){
            ((HeroFightModule) heroFightModule).getHeroMiscModule()
                    .tryCompleteShengWangTask(ShengWangType.SW_JIJIAN, true, 1);
        } else{
            logger.error("祭剑副本中的居然不是 HeroFightModule");
        }
    }

    @Override
    public void removeHero(AbstractHeroFightModule heroFightModule,
            boolean removeHero){
        positionModule.remove(heroFightModule);

        // 更新场景中的英雄状态
        JijianRankObject rankObject = heroRankMap.get(heroFightModule.getID());
        if (rankObject != null){
            rankObject.isInScene = false;
            rankObject.setSwordSacificeTimes(
                    heroFightModule.getHero().jijianYuanbaoTotalTimes,
                    heroFightModule.getHero().jijianUpdateTime);
        }
    }

    public void tryGivePrize(long ctime){
        if (ctime >= battleEndTime){
            return;
        }

        for (AbstractHeroFightModule hfm : positionModule.getAllHeroObjects()){
            hfm.sendMessage(JijianMessages.SCENE_RADIATE_MSG);
            ((HeroFightModule) hfm).addSwordSacrificeRadiatePrize(sceneData);
        }
    }

    @Override
    public boolean heroThreadUpdate(HeroFightModule heroFightModule, long ctime){
        // 看下是否在活动时间之内，是则不管，否则传出副本
        if (ctime >= battleEndTime){
            heroFightModule.doLeaveDungeon();
            return false;
        }

        // 扩散真气
        HeroRadiateObject radiateObject = heroFightModule.radiateObject;
        if (radiateObject != null){
            if (radiateObject.sceneData != sceneData){
                heroFightModule.radiateObject = null; // 为什么呢
            } else{
                if (ctime > radiateObject.nextHeroRadiateTime){
                    heroFightModule.radiateObject = null; // 时间到，清掉这个对象

                    // 开始给周围的人加真气
                    int x1 = heroFightModule.getX();
                    int y1 = heroFightModule.getY();
                    for (AbstractHeroFightModule hfm : positionModule
                            .getAllHeroObjects()){
                        if (Utils.isInEasyRange(x1, y1, hfm.getX(), hfm.getY(),
                                sceneData.heroRadiateDistance)
                                && heroFightModule != hfm
                                && hfm.getHero().jijianAccFreeloadRealAir < sceneData.maxFreeloadRealAir){
                            ((HeroFightModule) hfm).addHeroRadiateRealAir(
                                    sceneData,
                                    radiateObject.nextHeroRadiateData);
                        }
                    }
                }
            }
        }

        return true;
    }

    @Override
    public float getMeditateMultiple(){
        return sceneData.extraMultiple;
    }

    @Override
    public void onAddMediateAmount(HeroFightModule hfm, int toAddExp,
            int toAddRealAir){
        hfm.getHero().jijianAccExp += toAddExp;
        hfm.getHero().jijianAccRealAir += toAddRealAir;
    }

    @MultiThread
    @Override
    public boolean markAboutEnter(long heroID){
        return true;
    }

    @MultiThread
    @Override
    public void markOfflineWhenLoading(long heroID){
        // 什么都不干
    }

    public void checkExpiration(long ctime){
        if (ctime >= dungeonExpireTime){

            for (AbstractHeroFightModule hfm : positionModule
                    .getAllHeroObjects()){
                try{
                    hfm.doLeaveDungeon();
                } catch (Throwable e){
                }
            }

            dungeonService.removeDungeon(sceneID);
            return;
        }
    }

    @Override
    public JijianSceneData getSceneData(){
        return sceneData;
    }

    public AbstractHeroFightModule getHero(long id){
        return positionModule.getHero(id);
    }

    public JijianRankObject getOrCreateRankObject(Hero hero){
        JijianRankObject obj = heroRankMap.get(hero.getID());
        if (obj == null){
            obj = new JijianRankObject(hero);
            JijianRankObject old = heroRankMap.putIfAbsent(hero.getID(),
                    new JijianRankObject(hero));

            if (old != null){
                return old;
            }
        }

        return obj;
    }

}
