package app.game.data.goods;

import static com.mokylin.sink.util.Preconditions.checkArgument;

import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import app.game.data.GameObjects;
import app.game.data.QualityRelatedDatas;
import app.game.data.SingleSpriteStats;
import app.protobuf.GoodsServerContent.Quality;
import app.protobuf.SpriteStatContent.StatType;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.inject.Inject;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class EquipmentAddedStatGroups{
    public static final String LOCATION = "config/data/goods/equipment_added_stat.txt";

    private final Map<String, EquipmentAddedStatGroup> map;

    @Inject
    EquipmentAddedStatGroups(GameObjects go, SingleSpriteStats spriteStats,
            QualityRelatedDatas qualityDatas){

        List<ObjectParser> data = go.loadFile(LOCATION);
        checkArgument(!data.isEmpty(), "装备强化数据没有配置");

        Map<String, List<ObjectParser>> m = Maps.newHashMap();
        int statLen = StatType.values().length;
        for (ObjectParser p : data){
            String name = p.getKey("name");
            checkArgument(!name.isEmpty(), "装备附加属性组中名字没有配置");

            List<ObjectParser> list = m.get(name);
            if (list == null){
                list = Lists.newArrayListWithCapacity(statLen);
                m.put(name, list);
            }

            list.add(p);
        }

        map = Maps.newHashMapWithExpectedSize(m.size());
        for (Entry<String, List<ObjectParser>> entry : m.entrySet()){
            EquipmentAddedStatGroup group = new EquipmentAddedStatGroup(
                    entry.getKey(), entry.getValue(), spriteStats, qualityDatas);

            map.put(group.name, group);
        }
    }

    public EquipmentAddedStatGroup get(String key){
        return map.get(key);
    }
}
