package app.game.data.scene;

import static com.mokylin.sink.util.Preconditions.*;

import org.jboss.netty.buffer.ChannelBuffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.data.Prize;
import app.game.data.goods.GoodsDatas;
import app.game.data.goods.GoodsWrapper;
import app.game.module.scene.DefenceDungeonMessages;
import app.game.module.scene.DefenceDungeonMonsterFightModule;
import app.game.module.scene.DefenceDungeonScene;
import app.game.module.scene.FightData;
import app.protobuf.DungeonContent.DungeonBatchInfoProto;

import com.mokylin.sink.util.BufferUtil;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.parse.ObjectParser;

public class DefenceBatchInfo{
    private static final Logger logger = LoggerFactory
            .getLogger(DefenceBatchInfo.class);

    /**
     * 第几波, 从1开始
     */
    public final int batch;

    private final MonsterData monsterData;

    public final int count;

    public final DefenceMonsterPosID[] monsters;

    /**
     * 原来是扣元宝，后面改成扣银两了
     */
    public final int autoFinishMoney;

    // 过期时间
    public final long expireDuration;

    // -- 奖励 --

    public final Prize prize;

    public final GoodsWrapper firstPassPrize;

    // -- 缓存描述信息 --
    private final DefenceBatchInfo next;

    private final ChannelBuffer batchMsg;

    // --- 累积的奖励 ---

    private Prize sumPrize;
    private DefenceCollectablePrize[] prizeDiff;
    private final byte[] errorPrizeDiffInfo;

    /**
     * 设置今日已通关关数消息
     */
    private final ChannelBuffer setTodayFinishBatchMsg;

    final int maxUsedMonsterID;

    DefenceBatchInfo(ObjectParser p, BlockInfo blockInfo,
            MonsterDatas monsterDatas, GoodsDatas goodsDatas,
            DefenceMonsterPosCalculator posCalculator,
            SceneRemoveObjectMsgCache removeMsgCache,
            DefenceDungeonSceneData sceneData, DefenceBatchInfo next){
        batch = p.getIntKey("batch");
        String monsterName = p.getKey("monster_name");
        count = p.getIntKey("count");
        this.monsterData = checkNotNull(monsterDatas.get(monsterName),
                "没有找到守护孔慈第 %s 波的怪物: %s", batch, monsterName);

        checkNotNull(monsterData.normalSpell, "孔慈副本里的怪物必须有默认技能: %s",
                monsterData);

        checkArgument(count > 0 && count <= 100,
                "守护孔慈第 %s 波的刷新数量非法. 必须是1-100之间: %s", batch, count);

        this.autoFinishMoney = p.getIntKey("auto_finish_yuanbao");
        checkArgument(autoFinishMoney > 0, "守护孔慈自动扫荡消耗auto_finish_yuanbao必须>0");

        this.expireDuration = p.getLongKey("expire_duration");
        checkArgument(expireDuration > 0, "守护孔慈%s 波的过期时间必须大于0", batch);

        this.setTodayFinishBatchMsg = DefenceDungeonMessages
                .setTodayFinishBatch(batch);

        // -- 怪物坐标/删除消息初始化 --
        int[] poses = posCalculator.get(count);

        this.monsterData.setScene(sceneData, new int[]{poses[0]});

        assert poses.length > 0;

        int maxMonID = 0;
        this.monsters = new DefenceMonsterPosID[poses.length];

        for (int i = 0; i < poses.length; i++){
            // 一个隔一个, 一个从2开始(1是孔慈), 接下来那个从61开始. 为了不要新刷出来的那波的id和前一波的id冲突.
            // 实在冲突也无所谓, 只是客户端看到技能刚出去, 没打到人, 就出了一波新的
            int id = ((batch & 1) == 1) ? (i + 2) : (i + 61);

            DefenceMonsterPosID mpi = new DefenceMonsterPosID(id,
                    removeMsgCache.get(id), Utils.getHighShort(poses[i]),
                    Utils.getLowShort(poses[i]));
            this.monsters[i] = mpi;
            maxMonID = id;
        }
        this.maxUsedMonsterID = maxMonID;

        // -- 通关奖励 --
        int prizeExp = p.getIntKey("prize_exp");
        checkArgument(prizeExp >= 0, "守护孔慈奖励经验必须>=0");

        int prizeRealAir = p.getIntKey("prize_real_air");
        checkArgument(prizeRealAir >= 0, "守护孔慈奖励真气必须>=0");

        int prizeMoney = p.getIntKey("prize_money");
        checkArgument(prizeMoney >= 0, "守护孔慈奖励银两必须>=0");

        // 首通奖励, 可以没有
        String firstPassPrizeStr = p.getKey("first_pass");
        if (firstPassPrizeStr.length() == 0){
            firstPassPrize = null;
        } else{
            firstPassPrize = GoodsWrapper.parse("守护孔慈奖励", goodsDatas,
                    firstPassPrizeStr);
        }

        // 奖励物品, 可以没有
        String[] prizeGoodsStr = p.getStringArray("prize_goods");
        GoodsWrapper[] prizeGoods = GoodsWrapper.parse("守护孔慈奖励", goodsDatas,
                prizeGoodsStr);
        this.prize = new Prize(prizeExp, prizeMoney, prizeRealAir, 0, 0,
                prizeGoods);

        // --- 缓存信息 ---
        // 出错时的完成奖励消息
        byte[] b = new byte[BufferUtil.computeVarInt32Size(batch)];
        BufferUtil.writeVarInt32(b, 0, batch);
        errorPrizeDiffInfo = Utils.zlibCompress(b);

        this.next = next;
        DungeonBatchInfoProto.Builder builder = DungeonBatchInfoProto
                .newBuilder();
        builder.setBatchNumber(batch).setCurrentMonsterTypeId(monsterData.id);
        if (next != null){
            builder.setNextMonsterTypeId(next.monsterData.id);
        }
        builder.setCurrentBatchPrize(prize.encode4Client());
        builder.setExpireDuration(expireDuration);

        this.batchMsg = DefenceDungeonMessages
                .currentBatchInfo(builder.build());
    }

    public ChannelBuffer getSetTodayFinishBatchMsg(){
        return setTodayFinishBatchMsg;
    }

    public ChannelBuffer getBatchMsg(){
        return batchMsg;
    }

    public DefenceBatchInfo getNext(){
        return next;
    }

    void calculateSum(DefenceBatchInfo previous){
        if (previous == null){
            this.sumPrize = prize;
            return;
        }

        this.sumPrize = prize.add(previous.sumPrize);
    }

    private DefenceBatchInfo[] batchs;

    void calculateDiff(DefenceBatchInfo[] batchs){
        prizeDiff = new DefenceCollectablePrize[batch];

        this.batchs = batchs;

        prizeDiff[0] = new DefenceCollectablePrize(0, batch, sumPrize);
    }

    public ChannelBuffer getAutoFinishMsg(int toReduceBatch){
        return getPrizeDiff(toReduceBatch).autoFinishMsg;
    }

    public DefenceCollectablePrize getPrizeDiff(int toReduceBatch){
        if (toReduceBatch >= batch || toReduceBatch < 0){
            logger.error(
                    "DefenceBatchInfo.getPrizeDiff时, 自己本身是{}波, 要去掉的是{}波的奖励",
                    batch, toReduceBatch);
            return null;
        }

        DefenceCollectablePrize prize = prizeDiff[toReduceBatch];
        if (prize != null){
            return prize;
        }

        // 到这里, toReduceBatch一定不为0
        Prize p = sumPrize.remove(batchs[toReduceBatch - 1].sumPrize);
        prize = prizeDiff[toReduceBatch] = new DefenceCollectablePrize(
                toReduceBatch, batch, p);

        return prize;
    }

    public byte[] getPrizeDiffInfo(int toReduceBatch){
        if (toReduceBatch >= batch || toReduceBatch < 0){
            logger.error(
                    "DefenceBatchInfo.getPrizeDiff时, 自己本身是{}波, 要去掉的是{}波的奖励",
                    batch, toReduceBatch);
            return errorPrizeDiffInfo;
        }

        return getPrizeDiff(toReduceBatch).prizeDiffInfo;
    }

    public DefenceCollectablePrize getDefenceCollectablePrize(int toReduceBatch){
        return getPrizeDiff(toReduceBatch);
    }

    public ChannelBuffer getAddCollectableMsg(int toReduceBatch){
        if (toReduceBatch >= batch || toReduceBatch < 0){
            logger.error(
                    "DefenceBatchInfo.getAddCollectableMsg时, 自己本身是{}波, 要去掉的是{}波的奖励",
                    batch, toReduceBatch);
            return null;
        }

        return getPrizeDiff(toReduceBatch).addCollectableMsg;
    }

    public class DefenceMonsterPosID{
        public final long id;
        public final ChannelBuffer removeMeMsg;
        public final int x;
        public final int y;

        public DefenceMonsterPosID(long id, ChannelBuffer removeMeMsg, int x,
                int y){
            super();
            this.id = id;
            this.removeMeMsg = removeMeMsg;
            this.x = x;
            this.y = y;
        }

        public DefenceDungeonMonsterFightModule newMonster(
                DefenceDungeonScene parent){
            FightData fightData = new FightData(monsterData.stat,
                    monsterData.level);
            fightData.setSceneIDAndPos(parent.getSceneID(), x, y);
            DefenceDungeonMonsterFightModule result = new DefenceDungeonMonsterFightModule(
                    id, monsterData, fightData, parent, removeMeMsg,
                    parent.getPositionModuleSharedSync());
            return result;
        }
    }
}
