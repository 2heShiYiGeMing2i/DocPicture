package app.game.data.platform;

import static com.mokylin.sink.util.Preconditions.checkNotNull;

import java.util.List;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.data.PrizeConfigs;
import app.game.module.pvip.PlatformVipMessages;
import app.protobuf.ConfigContent.PlatformVipConfig;
import app.utils.Operators;

import com.mokylin.collection.IntHashMap;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class PVipData{

    private final String name;

    private final Operators operators;

    private final int id;

    public final boolean isDailyPrize;

    public final boolean isChargeType;

    public final int vipType;

    private final IntHashMap<PVipPrize> dataMap;

    private final PVipPrize[] datas;

    private final ChannelBuffer dataMsg;

    PVipData(String name, int id, List<ObjectParser> list,
            PrizeConfigs prizeConfigs){
        this.name = name;
        this.id = id;

        int operatorID = getOperatorID(id);
        int sequence = getSequence(id);

        this.operators = checkNotNull(Operators.valueOf(operatorID),
                "平台Vip奖励中发现无效的运营商ID- %s", operatorID);

        this.isDailyPrize = isDailyType(id);
        this.isChargeType = isChargeType(id);

        vipType = operatorID * 100 + sequence;

        dataMap = new IntHashMap<PVipPrize>();
        datas = new PVipPrize[list.size()];
        int i = 0;
        for (ObjectParser p : list){
            PVipPrize prize = new PVipPrize(this, p, prizeConfigs);
            dataMap.putUnique(prize.id, prize);
            datas[i++] = prize;
        }

        PlatformVipConfig.Builder builder = PlatformVipConfig.newBuilder();
        builder.setId(id);
        for (PVipPrize p : datas){
            builder.addLevel(p.getID());
            builder.addPrize(p.getPrize().encode4Client());
        }

        dataMsg = PlatformVipMessages.getPlatformVipConfigMsg(builder.build());
    }

    public int getOperatorID(){
        return operators.operatorID;
    }

    public int getId(){
        return id;
    }

    public int getVipType(){
        return vipType;
    }

    public boolean isDailyPrize(){
        return isDailyPrize;
    }

    public PVipPrize get(int key){
        return dataMap.get(key);
    }

    public PVipPrize[] all(){
        return datas;
    }

    public ChannelBuffer getDataMsg(){
        return dataMsg;
    }

    public static int getId(int vipType, boolean isDaily, boolean isChargeType){
        return vipType * 100 + (isDaily ? 10 : 0) + (isChargeType ? 1 : 0);
    }

    public static int getVipType(int operatorID, int sequence){
        return operatorID * 100 + sequence;
    }

    private static int getOperatorID(int fileNum){
        return fileNum / 10000;
    }

    private static int getSequence(int fileNum){
        return (fileNum / 100) % 100;
    }

    private static boolean isChargeType(int fileNum){
        return fileNum % 10 > 0;
    }

    private static boolean isDailyType(int fileNum){
        return (fileNum % 100) / 10 > 0;
    }

    @Override
    public String toString(){
        return name;
    }
}
