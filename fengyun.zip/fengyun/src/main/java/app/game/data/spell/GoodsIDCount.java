package app.game.data.spell;

import app.game.data.goods.GoodsData;

public class GoodsIDCount{

    public static final GoodsIDCount[] EMPTY_ARRAY = new GoodsIDCount[0];

    public final int goodsID;

    public final byte[] goodsNameBytes;

    public final int goodsCount;

    public GoodsIDCount(GoodsData goodsData, int goodsCount){
        super();
        // TODO 根据物品id找到物品名字
        this.goodsID = goodsData.id;
        this.goodsNameBytes = goodsData.nameBytes;
        this.goodsCount = goodsCount;
    }
}
