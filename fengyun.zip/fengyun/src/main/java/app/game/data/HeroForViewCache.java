package app.game.data;

import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.FutureTask;

import app.game.entity.Hero;
import app.game.service.DBService;
import app.game.service.IThreadService;

import com.google.common.collect.Lists;
import com.google.inject.Inject;
import com.mokylin.collection.LongConcurrentSynchronizedHashMap;

/**
 * @author Liwei
 *
 */
public class HeroForViewCache{

    private DBService dbService;
    private IThreadService threadService;
    private LongConcurrentSynchronizedHashMap<Hero> cache;

    @Inject
    HeroForViewCache(DBService dbService, IThreadService threadService){
        this.dbService = dbService;
        this.threadService = threadService;
        cache = new LongConcurrentSynchronizedHashMap<>();
    }

    public Hero get(long id){
        Hero result = cache.get(id);
        if (result != null){
            return result;
        }

        try{
            result = dbService.getHeroForView(id);
        } catch (Throwable e){
            e.printStackTrace();
        }

        if (result == null)
            return null;

        Hero old = cache.putIfAbsent(id, result);
        if (old == null){
            return result;
        }
        return old;
    }

    public List<Hero> loadHeros(List<Long> heroIdList) throws Throwable{

        List<Hero> heroList = Lists.newArrayListWithCapacity(heroIdList.size());

        List<FutureTask<Hero>> tasks = Lists
                .newArrayListWithCapacity(heroIdList.size());
        for (int i = 0; i < heroIdList.size(); i++){
            final long heroId = heroIdList.get(i);

            Hero hero = cache.get(heroId);
            if (hero != null){
                heroList.add(hero);
                continue;
            }

            Callable<Hero> call = new Callable<Hero>(){

                @Override
                public Hero call() throws Exception{
                    return get(heroId);
                }
            };

            FutureTask<Hero> future = new FutureTask<Hero>(call);
            tasks.add(future);
            threadService.getDbExecutor().execute(future);
        }

        for (FutureTask<Hero> t : tasks){
            Hero hero = t.get();
            if (hero != null){
                heroList.add(hero);
            }
        }

        return heroList;
    }

    public void destroy(){
        dbService = null;
        threadService = null;
        cache = null;
    }
}
