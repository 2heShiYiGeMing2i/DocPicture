package app.game.data.pet;

import static com.mokylin.sink.util.Preconditions.*;

import java.util.List;

import app.game.data.GameObjects;
import app.game.data.SpriteStats;
import app.utils.VariableConfig;

import com.mokylin.collection.IntHashMap;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class PetLevelDatas{

    private static final String LOCATION = GameObjects.PET_BASE_FOLDER
            + "pet_level.txt";

    private final PetLevelData[] datas;

    private final int minLevel;

    final int[] spellOpenLevels;

    PetLevelDatas(GameObjects go, SpriteStats spriteStats){
        List<ObjectParser> data = go.loadFile(LOCATION);
        checkArgument(!data.isEmpty(), "宠物等级表没有配置数据");

        int minLevel = Integer.MAX_VALUE;
        IntHashMap<PetLevelData> map = new IntHashMap<>();
        for (ObjectParser p : data){
            PetLevelData d = new PetLevelData(p, spriteStats);
            map.putUnique(d.level, d);

            if (d.level < minLevel)
                minLevel = d.level;
        }
        this.minLevel = minLevel;

        datas = new PetLevelData[map.size()];
        spellOpenLevels = new int[VariableConfig.PET_SPELL_SLOT_MAX_COUNT];
        for (int i = 0; i < datas.length; i++){
            datas[i] = checkNotNull(map.get(minLevel + i),
                    "宠物等级表没有找到 %s级的数据，数据必须连续配置", minLevel + i);

            if (i > 0){
                checkArgument(
                        datas[i - 1].addedMaxLife <= datas[i].addedMaxLife,
                        "宠物 %s级的给主人附加最大血量居然比前一级的小", minLevel + i);

                checkArgument(
                        datas[i - 1].addedMaxAttack <= datas[i].addedMaxAttack,
                        "宠物 %s级的给主人附加最大攻击居然比前一级的小", minLevel + i);

                checkArgument(
                        datas[i - 1].addedMaxDefence <= datas[i].addedMaxDefence,
                        "宠物 %s级的给主人附加最大防御居然比前一级的小", minLevel + i);

                checkArgument(
                        datas[i - 1].spellSlotCount <= datas[i].spellSlotCount,
                        "宠物 %s级的开放技能格子居然比前一级的少", minLevel + i);

                if (datas[i - 1].spellSlotCount < datas[i].spellSlotCount){

                    int spellSlotCount = datas[i].spellSlotCount;
                    int level = datas[i].level;
                    for (int n = datas[i - 1].spellSlotCount; n < spellSlotCount; n++){
                        spellOpenLevels[n] = level;
                    }
                }
            } else{
                int spellSlotCount = datas[i].spellSlotCount;
                if (spellSlotCount > 0){
                    int level = datas[i].level;
                    for (int n = 0; n < spellSlotCount; n++){
                        spellOpenLevels[n] = level;
                    }
                }
            }

        }

        checkArgument(
                datas[datas.length - 1].spellSlotCount == VariableConfig.PET_SPELL_SLOT_MAX_COUNT,
                "宠物最高级数据的技能格子居然还没开完， 开放技能格子: %s",
                datas[datas.length - 1].spellSlotCount);
    }

    public PetLevelData get(int level){
        return Utils.getValidObject(datas, level - minLevel);
    }
}
