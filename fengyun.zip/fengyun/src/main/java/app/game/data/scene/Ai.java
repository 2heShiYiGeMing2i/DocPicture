package app.game.data.scene;

import static com.mokylin.sink.util.Preconditions.checkArgument;
import app.utils.VariableConfig;

import com.mokylin.sink.util.parse.ObjectParser;

public class Ai{

    /**
     * 被动攻击, 被打了才攻击
     */
    public static final int ACTION_TYPE_PASSIVE = 0;

    /**
     * 主动攻击, 进入视野就攻击
     */
    public static final int ACTION_TYPE_PROACTIVE = 1;

    /**
     * 木桩, 被打也不攻击
     */
    public static final int ACTION_TYPE_TREE = 2;

    /**
     * 被打就逃, 也不还手
     */
    public static final int ACTION_TYPE_ESCAPE = 3;

    /**
     * 攻击/行为方式
     */
    private final int actionType;

    /**
     * ai名字, 只供配置时用, 客户端不需要知道
     */
    public final String name;

    /**
     * 无法被击退
     */
    public final boolean canNotBeatBack;

    /**
     * 复活间隔
     */
    public final long reliveTime;

    /**
     * 搜敌范围
     */
    public final int searchRange;

    /**
     * 战斗范围, 超出多少格就不打返回刷新点
     */
    public final int fightRange;

    /**
     * 随机移动范围
     */
    public final int randomMoveRange;

    /**
     * 随机移动概率
     */
    public final int randomMoveRate;

    /**
     * 随即移动检测间隔
     */
    public final int randomMoveDelay;

    /**
     * 是否只有一条命
     */
    public final boolean isSingleLife;

    Ai(ObjectParser p){
        name = p.getKey("name");
        actionType = p.getIntKey("action_type");
        checkArgument(actionType >= 0 && actionType <= 3,
                "ai %s 的action_type非法, 只能是0-3: %s", this, actionType);

        this.canNotBeatBack = p.getBooleanKey("can_not_beat_back");

        if (actionType == ACTION_TYPE_TREE){
            // 木桩不能被击退, 不然可能击退出了fightRange. 不过也没关系, 反正木桩型的完全没有判断的
            checkArgument(canNotBeatBack, "ai %s 木桩型的一定不能被击退", this);
        }

        this.isSingleLife = p.getBooleanKey("is_single_life");
        if (!isSingleLife){
            this.reliveTime = Math.max(
                    VariableConfig.MIN_MONSTER_RELIVE_MILLIS,
                    p.getIntKey("relive_time"));
        } else{
            this.reliveTime = p.getIntKey("relive_time");
            checkArgument(reliveTime == 0, "ai %s 只有一条命, relive_time得是0", this);
        }
        this.searchRange = p.getIntKey("search_range");
        this.fightRange = p.getIntKey("fight_range");
        this.randomMoveRange = p.getIntKey("random_move_range");
        this.randomMoveRate = p.getIntKey("random_move_rate");
        this.randomMoveDelay = p.getIntKey("random_move_delay");

        checkArgument(randomMoveRange <= fightRange,
                "ai %s 随机移动范围 random_move_range 必须 <= 追击范围fight_range", this);
        checkArgument(searchRange <= fightRange,
                "ai %s 搜怪范围 search_range 必须 <= 追击范围 fight_range", this);

        if (actionType == ACTION_TYPE_PROACTIVE){
            checkArgument(searchRange > 0, "ai %s 是主动的, 搜索范围必须大于0", this);
        }
    }

    public int getActionType(){
        return actionType;
    }

    @Override
    public String toString(){
        return name;
    }

}
