package app.game.data;

import static com.mokylin.sink.util.Preconditions.*;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Set;

import org.joda.time.DateTime;
import org.joda.time.DateTimeConstants;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.mokylin.sink.util.Empty;
import com.mokylin.sink.util.Utils;

public class TimeData{

    public static TimeData parse(String input){
        checkNotNull(input);

        List<String> components = Lists.newArrayList();

        int startPos = -1;
        for (int i = 0; i < input.length(); i++){
            char c = input.charAt(i);
            if (c == '['){
                checkArgument(startPos == -1,
                        "时间格式不正确. 应该是 [2011][11][w1,w2,w5][18:05]: %s", input);
                startPos = i;
            } else if (c == ']'){
                checkArgument(startPos != -1,
                        "时间格式不正确. 应该是 [2011][11][w1,w2,w5][18:05]: %s", input);
                components.add(input.substring(startPos + 1, i).trim());
                startPos = -1;
            }
        }
        checkArgument(startPos == -1 && components.size() == 4,
                "时间格式不正确. 应该是 [2011][11][w1,w2,w5][18:05]: %s", input);

        return parse(components.toArray(Empty.STRING_ARRAY), input);
    }

    private static TimeData parse(String[] args, String input){
        assert args.length == 4;
        // 年
        String year = args[0];
        int yearLimit = 0;
        if ("*".equals(year)){
        } else{
            yearLimit = Integer.parseInt(year);
        }

        // 月
        String month = args[1];
        Set<Integer> monthLimits = Sets.newHashSet();
        if ("*".equals(month)){
        } else{
            String[] ms = month.split(",");
            for (String m : ms){
                m = m.trim();
                int mon = Integer.parseInt(m);
                checkArgument(mon >= 1 && mon <= 12, "月份必须为1-12: %s: %s", mon,
                        input);
                monthLimits.add(mon);
            }
            checkArgument(monthLimits.size() > 0, "月份必须填. 无月份限制填*: %s", input);
        }

        // 日
        String day = args[2];
        Set<Integer> dayLimits = Sets.newHashSet();
        Set<Integer> weekdayLimits = Sets.newHashSet();
        if ("*".equals(day)){
        } else{
            String[] ds = day.split(",");
            for (String d : ds){
                d = d.trim();
                if (d.startsWith("w")){
                    int weekday = Integer.parseInt(d.substring(1));
                    checkArgument(weekday >= 1 && weekday <= 7,
                            "星期几必须为1-7: %s: %s", d, input);
                    weekdayLimits.add(weekday);
                } else{
                    int dd = Integer.parseInt(d);
                    checkArgument(dd >= 1 && dd <= 31, "日期必须为1-31: %s: %s", d,
                            input);
                    dayLimits.add(dd);
                }

                checkArgument(dayLimits.size() > 0 || weekdayLimits.size() > 0,
                        "必须配置日期. 没有限制填*: %s", input);// 必须要有
                checkArgument(dayLimits.size() == 0
                        || weekdayLimits.size() == 0, "日期要么都是星期, 要么都是日期: %s",
                        input); // 只能有一个
            }
        }

        // 时间
        String time = args[3];
        Set<Integer> times = Sets.newHashSet();
        String[] ts = time.split(",");
        for (String t : ts){
            t = t.trim();
            int lpos = t.indexOf(":");
            checkArgument(lpos > 0, "时间格式错误, 必须是hh:mm : %s", input);
            int hour = Integer.parseInt(t.substring(0, lpos));
            int minute = Integer.parseInt(t.substring(lpos + 1));

            checkArgument(hour >= 0 && hour <= 23, "小时必须是 0-23: %s", input);
            checkArgument(minute >= 0 && minute <= 59, "分钟必须是0-59: %s", input);

            times.add(Utils.short2Int(hour, minute));
        }

        checkArgument(times.size() > 0, "必须配置时间, 格式 hh:mm,hh:mm");

        return new TimeData(input, yearLimit, monthLimits, weekdayLimits,
                dayLimits, times);
    }

    // -----------------------

    public final String input;

    private final int year;

    private final int[] month;

    private final int[] days;

    private final boolean isWeekday;

    private transient final boolean hasDayLimit;

    private transient final boolean hasMonthLimit;

    private final int[] hours;

    private transient final boolean isDailyTime;

    private TimeData(String input, int year, Collection<Integer> months,
            Collection<Integer> weekdays, Collection<Integer> monthDay,
            Collection<Integer> hourMinutes){
        this.input = input;
        this.year = year;

        this.month = toArray(months);
        this.hasMonthLimit = this.month.length > 0;

        if (weekdays.size() == 0){
            if (monthDay.size() == 0){
                hasDayLimit = false;
                days = Empty.INT_ARRAY;
                isWeekday = false;
            } else{
                days = toArray(monthDay);
                isWeekday = false;
                hasDayLimit = true;
            }
        } else{
            if (weekdays.size() == 7){
                // 7天都写了, 其实是没有限制的
                hasDayLimit = false;
                days = Empty.INT_ARRAY;
                isWeekday = false;
            } else{
                days = toArray(weekdays);
                isWeekday = true;
                hasDayLimit = true;
            }
        }

        this.hours = toArray(hourMinutes);

        // 检查, 不能是限制了月份, 又限制了日期, 但是是永远达不到的, 比如一定要2月30号. 或者一定要[2,4]的31号
        if (hasMonthLimit){
            if (hasDayLimit){
                if (!isWeekday){
                    int firstDay = days[0];
                    // 来问题了
                    switch (firstDay){
                        case 29:{
                            // 如果月份只有2, 则要么不限年, 要么这一年是有29号的
                            if (month.length == 1 && month[0] == 2){
                                if (this.year != 0){
                                    DateTime dt = new DateTime(this.year, 2, 1,
                                            0, 0);
                                    int dayLimit = dt.dayOfMonth()
                                            .getMaximumValue();
                                    checkArgument(dayLimit >= 29,
                                            "%s年 2月 没有 29号", this.year);
                                }
                            }
                            break;
                        }

                        case 30:{
                            // 月份不能只有2
                            checkArgument(month.length > 1 || month[0] != 2,
                                    "2月没有30号");
                            break;
                        }

                        case 31:{
                            // 月份不能只有 2, 4, 6, 9, 11
                            boolean valid = false;
                            for (int m : this.month){
                                if (isMonthCanHave31Days(m)){
                                    valid = true;
                                    break;
                                }
                            }
                            checkArgument(valid, "配置的月份都是没有31号的");
                            break;
                        }

                        default:{
                            break;
                        }
                    }
                }
            }
        }

        isDailyTime = year == 0 && !hasMonthLimit && !hasDayLimit && !isWeekday;
    }

    /**
     * 是否每天都有的，true表示是，false表示否
     * @return
     */
    public boolean isDailyTime(){
        return isDailyTime;
    }

    public int[] getHours(){
        return hours;
    }

    private static boolean isMonthCanHave31Days(int month){
        return month == 1 || month == 3 || month == 5 || month == 7
                || month == 8 || month == 10 || month == 12;
    }

    /**
     * 得到下一个符合要求的时间点. 没有就返回0
     * @param from
     * @return
     */
    public long getNextTime(long from){
        DateTime fromDateTime = new DateTime(from);

        int currentYear = fromDateTime.getYear();
        if (this.year != 0 && this.year > currentYear){
            // 需求的年还没到
            return getFirstTimeOfYear(this.year);
        }

        if (this.year != 0 && this.year < currentYear){
            // 当前这一年已经过了
            return Long.MAX_VALUE;
        }

        // 年数ok
        // 看下月份
        int currentMonth = fromDateTime.getMonthOfYear();

        if (hasMonthLimit){
            for (int monthConfig : this.month){
                if (monthConfig == currentMonth){
                    // 月份ok
                    long result = getNextTimeWithYearAndMonth(currentYear,
                            currentMonth, fromDateTime);
                    if (result != Long.MAX_VALUE){
                        // 这个月找到了
                        return result;
                    }
                    // 没找到
                    continue;
                }

                if (monthConfig > currentMonth){
                    // 找这个月的第一天
                    long result = getFirstOfYearMonth(currentYear, monthConfig); // 可能失败
                    if (result != Long.MAX_VALUE){
                        return result;
                    }
                }
            }

            // 今年没了, 看下明年行不行
            if (this.year != 0){
                // 年数已经固定了
                return Long.MAX_VALUE;
            }

            return getFirstTimeOfYear(currentYear + 1); // 返回明年第一个符合的日子
        } else{
            // 月份ok
            long result = getNextTimeWithYearAndMonth(currentYear,
                    currentMonth, fromDateTime);
            if (result != Long.MAX_VALUE){
                return result;
            }
            // 这个月没有, 找下个月
            for (int tryMonth = currentMonth + 1; tryMonth <= 12; tryMonth++){
                result = getFirstOfYearMonth(currentYear, tryMonth); // 可能失败
                if (result != Long.MAX_VALUE){
                    return result;
                }
            }
            // 今年没了, 看下明年行不行
            if (this.year != 0){
                // 年数已经固定了
                return Long.MAX_VALUE;
            }

            return getFirstTimeOfYear(currentYear + 1); // 返回明年第一个符合的日子
        }
    }

    /**
     * 找下这一年的这一个月里, 还有没有符合要求的. 没有的话返回0
     * @param currentYear
     * @param currentMonth
     * @param fromDateTime
     * @return
     */
    private long getNextTimeWithYearAndMonth(int currentYear, int currentMonth,
            DateTime fromDateTime){
        if (hasDayLimit){
            // 有日期要求
            if (isWeekday){
                // 是星期几的要求
                int currentDay = fromDateTime.getDayOfWeek();
                for (int dayConfig : this.days){
                    if (dayConfig == currentDay){
                        // 这一天ok
                        long result = getNextTimeWithYearAndMonthAndDay(fromDateTime);
                        if (result != Long.MAX_VALUE){
                            return result;
                        }
                        // 这一天里没有, 找下一天
                        continue;
                    }

                    if (dayConfig > currentDay){
                        // 看下这天是不是超过了这个月了
                        DateTime newTime = fromDateTime.plusDays(dayConfig
                                - currentDay);
                        if (newTime.getMonthOfYear() != currentMonth){
                            // 已经不是这个月的了
                            return Long.MAX_VALUE;
                        }
                        // 加了几天后, 还是这个月的
                        // 取这一天的第一个时间

                        int hour = this.hours[0];
                        newTime = newTime.withTime(Utils.getHighShort(hour),
                                Utils.getLowShort(hour), 0, 0);
                        return newTime.getMillis();
                    }
                }
                // 到这里, 这一周都没有, 看下下一周
                int diff = days[0] + 7 - currentDay;
                DateTime newTime = fromDateTime.plusDays(diff);
                if (newTime.getMonthOfYear() != currentMonth){
                    // 已经不是这个月的了
                    return Long.MAX_VALUE;
                }
                // 加了几天后, 还是这个月的
                // 取这一天的第一个时间

                int hour = this.hours[0];
                newTime = newTime.withTime(Utils.getHighShort(hour),
                        Utils.getLowShort(hour), 0, 0);
                return newTime.getMillis();
            } else{
                // 是日期要求
                int currentDay = fromDateTime.getDayOfMonth();
                for (int dayConfig : this.days){
                    if (dayConfig == currentDay){
                        // 这一天ok
                        long result = getNextTimeWithYearAndMonthAndDay(fromDateTime);
                        if (result != Long.MAX_VALUE){
                            return result;
                        }
                        // 这一天里没有了
                        continue;
                    }
                    if (dayConfig > currentDay){
                        // 直接取这一天的第一个时间
                        int hour = hours[0];
                        DateTime newTime = fromDateTime.withTime(
                                Utils.getHighShort(hour),
                                Utils.getLowShort(hour), 0, 0);
                        long diff = dayConfig - currentDay;
                        return newTime.getMillis()
                                + DateTimeConstants.MILLIS_PER_DAY * diff;
                    }
                }

                // 到这里都没有. 这个月没有了
                return Long.MAX_VALUE;
            }
        } else{
            // 无日期要求
            // 看下这一天里有没有符合的
            long result = getNextTimeWithYearAndMonthAndDay(fromDateTime);
            if (result != Long.MAX_VALUE){
                return result;
            }
            // 看下加一天, 还是不是这个月了
            DateTime newTime = fromDateTime.plusDays(1);
            if (newTime.getMonthOfYear() != currentMonth){
                return Long.MAX_VALUE; // 今天已经是这一天最后一天了
            }

            int hour = hours[0];
            newTime = newTime.withTime(Utils.getHighShort(hour),
                    Utils.getLowShort(hour), 0, 0);
            return newTime.getMillis();
        }
    }

    private long getNextTimeWithYearAndMonthAndDay(DateTime fromDateTime){
        int hour = fromDateTime.getHourOfDay();
        int minute = fromDateTime.getMinuteOfHour();
        int currentHour = Utils.short2Int(hour, minute);

        for (int hm : hours){
            if (hm > currentHour){
                // 今天后面还有. 算下时间

                int h = Utils.getHighShort(hm);
                int m = Utils.getLowShort(hm);
                int totalMillis = h * DateTimeConstants.MILLIS_PER_HOUR + m
                        * DateTimeConstants.MILLIS_PER_MINUTE; // 算出在这一天中的millis

                int fromDateTimeTotalMillis = fromDateTime.getMillisOfDay(); // 算出当前时间在这一天中的millis
                return fromDateTime.getMillis()
                        + (totalMillis - fromDateTimeTotalMillis);
            }
        }
        return Long.MAX_VALUE;
    }

    private long getFirstTimeOfYear(int currentYear){
        return doGetFirstTimeOfYear(currentYear, 0);
    }

    private long doGetFirstTimeOfYear(int currentYear, int level){
        if (level >= 8){
            return Long.MAX_VALUE; // 最多递归8层
        }

        if (hasMonthLimit){
            for (int tryMonth : month){
                long result = getFirstOfYearMonth(currentYear, tryMonth); // 如果没有, 则看下个月, 看完看下一年
                if (result != Long.MAX_VALUE){
                    return result;
                }
            }

            // 到这里都没有, 今年没了
            if (this.year == 0){
                return doGetFirstTimeOfYear(currentYear + 1, level + 1); // 递归, 可能完蛋
            } else{
                return Long.MAX_VALUE;
            }
        }
        return getFirstOfYearMonth(currentYear, 1); // 一定符合要求. 1月份肯定有31号
    }

    /**
     * 得到这一年, 这个月第一个符合要求的时间, 如果没有, 返回0. 一定要求日期, 而且这个日期这个月是没有的
     * @param currentYear
     * @param currentMonth
     * @return
     */
    private long getFirstOfYearMonth(int currentYear, int currentMonth){
        int hour = hours[0];
        if (!hasDayLimit){
            // 没有日期限制
            DateTime time = new DateTime(currentYear, currentMonth, 1,
                    Utils.getHighShort(hour), Utils.getLowShort(hour));

            return time.getMillis();
        }

        assert days.length > 0;
        if (!isWeekday){
            // 有日期限制, 但是是直接写的日期

            int day = days[0];
            if (day <= 28){
                // 一定有
                DateTime time = new DateTime(currentYear, currentMonth,
                        days[0], Utils.getHighShort(hour),
                        Utils.getLowShort(hour));
                return time.getMillis();
            } else{
                // 判断下这个月有没有这么大的日期
                DateTime time = new DateTime(currentYear, currentMonth, 1, 0, 0);
                int dayLimit = time.dayOfMonth().getMaximumValue();
                if (dayLimit >= day){
                    // 这一天在这个月是有的
                    return new DateTime(currentYear, currentMonth, day,
                            Utils.getHighShort(hour), Utils.getLowShort(hour))
                            .getMillis();
                } else{
                    // 这个月没有这一天
                    return Long.MAX_VALUE;
                }
            }
        }
        // 有日期限制, 而且是星期
        // 看下这个月第一天是星期几
        DateTime time = new DateTime(currentYear, currentMonth, 1,
                Utils.getHighShort(hour), Utils.getLowShort(hour));

        int dayOfWeek = time.getDayOfWeek();
        for (int dayConfig : this.days){
            if (dayConfig == dayOfWeek){
                return time.getMillis(); // 这一天是允许的
            }
            if (dayConfig > dayOfWeek){
                // 这个星期几刚好大于当前的星期几
                long diff = dayConfig - dayOfWeek; // 要延后几天
                return time.getMillis() + diff
                        * DateTimeConstants.MILLIS_PER_DAY;
            }
        }
        // 结束了, 没有配置的星期比当前的大, 到下一个星期
        int diff = days[0] + 7 - dayOfWeek;
        return time.getMillis() + diff * DateTimeConstants.MILLIS_PER_DAY;
    }

    @Override
    public int hashCode(){
        return Arrays.hashCode(new int[]{year, Arrays.hashCode(month),
                Arrays.hashCode(days), Arrays.hashCode(hours),
                isWeekday ? 0 : 1});
    }

    @Override
    public boolean equals(Object obj){
        if (obj instanceof TimeData){
            TimeData td = (TimeData) obj;

            if (year != td.year){
                return false;
            }

            if (!Arrays.equals(month, td.month)){
                return false;
            }

            if (!Arrays.equals(days, td.days)){
                return false;
            }

            if (isWeekday != td.isWeekday){
                return false;
            }

            if (hasDayLimit != td.hasDayLimit){
                return false;
            }

            if (hasMonthLimit != td.hasMonthLimit){
                return false;
            }

            if (!Arrays.equals(hours, td.hours)){
                return false;
            }

            return true;
        }
        return false;
    }

    private static int[] toArray(Collection<Integer> input){
        if (input.size() == 0){
            return Empty.INT_ARRAY;
        }

        int[] result = new int[input.size()];
        int index = 0;
        for (Integer i : input){
            result[index++] = i.intValue();
        }

        Arrays.sort(result);
        return result;
    }
}
