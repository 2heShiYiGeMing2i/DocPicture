package app.game.data.scene;

import app.game.data.ServerData;
import app.game.data.TimeData;
import app.game.module.scene.NormalScene;
import app.game.service.WorldService;

/**
 * @author Liwei
 *
 */
public class MonsterStatisticsData{

    static final MonsterStatisticsData[] EMPTY_ARRAY = new MonsterStatisticsData[0];

    final TimeData refreshTime;

    final SceneMonsterData monster;

    final NormalSceneData scene;

    final boolean isDeadBroadcast;

    private final transient int monsterId;

    MonsterStatisticsData(TimeData refreshTime, SceneMonsterData monster,
            NormalSceneData scene, boolean isDeadBroadcast){
        this.refreshTime = refreshTime;
        this.monster = monster;
        this.scene = scene;
        this.isDeadBroadcast = isDeadBroadcast;

        monsterId = monster.getMonsterData().id;
    }

    public MonsterStatistics newStatistics(WorldService worldService,
            ServerData serverData, int lineNumber){
        return MonsterStatistics.newStatistics(worldService, serverData,
                monster, lineNumber, isDeadBroadcast);
    }

    public int getMonsterId(){
        return monsterId;
    }

    public NormalScene[] getScenes(ServerData serverData){
        return scene.getNormalSceneContainer(serverData).getNormalScenes();
    }
}
