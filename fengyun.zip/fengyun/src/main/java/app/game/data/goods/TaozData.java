package app.game.data.goods;

import static com.mokylin.sink.util.Preconditions.*;
import app.game.data.SingleSpriteStat;
import app.game.data.SingleSpriteStats;
import app.game.data.SpriteStat;
import app.protobuf.ConfigContent.TaozProto;

import com.mokylin.collection.LeftIntPair;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class TaozData{

    public final int id;

    final String name;

    final int count;

    final LeftIntPair<SingleSpriteStat>[] stats;

    final LeftIntPair<SpriteStat>[] totalStats;

    TaozData(ObjectParser p, SingleSpriteStats spriteStats){

        id = p.getIntKey("id");
        name = p.getKey("name");

        String statStr = p.getKey("stat");
        String[] statArray = statStr.split(";");

        checkArgument(statArray.length > 0,
                "%s 没有配置stat，格式: 【件数#属性ID;件数#属性ID;...】", this);

        count = statArray.length;
        checkArgument(count <= 10, "%s 套装属性个数不能大于10", this);

        stats = LeftIntPair.newArray(count);
        totalStats = LeftIntPair.newArray(count);
        SpriteStat totalStat = SpriteStat.EMPTY_STAT;
        try{
            for (int i = 0; i < count; i++){
                int idx = statArray[i].indexOf("#");

                int count = Integer.parseInt(statArray[i].substring(0, idx));
                int statId = Integer.parseInt(statArray[i].substring(idx + 1));

                SingleSpriteStat s = checkNotNull(spriteStats.get(statId),
                        "%s 配置的stat中的属性ID找不到，statID: %s", this, statId);

                stats[i] = new LeftIntPair<SingleSpriteStat>(count, s);
                totalStat = totalStat.add(s);
                totalStats[i] = new LeftIntPair<SpriteStat>(count, totalStat);

                if (i > 0){
                    checkArgument(stats[i - 1].left < count,
                            "%s 配置的stat中，件数必须从小到大配置, %s", this, statStr);
                }
            }
        } catch (NumberFormatException e){
            throw new IllegalArgumentException(this
                    + " stat格式错误，格式: 【件数#属性ID;件数#属性ID;...】, " + statStr);
        }
    }

    public SpriteStat get(int c){

        SpriteStat prev = null;
        for (LeftIntPair<SpriteStat> pair : totalStats){
            if (c < pair.left)
                return prev;

            prev = pair.right;
        }

        return prev;
    }

    TaozProto generateProto(){
        TaozProto.Builder builder = TaozProto.newBuilder();

        builder.setId(id).setName(name);

        for (LeftIntPair<SingleSpriteStat> pair : stats){
            builder.addEffectCount(pair.left);
            builder.addEffectStat(pair.right.encode());
        }

        return builder.build();
    }

    @Override
    public String toString(){
        return id + "-" + name;
    }
}
