package app.game.data.scene;

import com.google.inject.AbstractModule;
import com.google.inject.Singleton;

public class SceneConfigGuiceModule extends AbstractModule{

    @Override
    protected void configure(){
        binder().requireExplicitBindings();
        bind(Ais.class).in(Singleton.class);
        bind(BlockInfos.class).in(Singleton.class);
        bind(MonsterDatas.class).in(Singleton.class);
        bind(Scripts.class).in(Singleton.class);
        bind(Plunders.class).in(Singleton.class);
        bind(PlunderGroups.class).in(Singleton.class);
        bind(SceneTransportDatas.class).in(Singleton.class);
        bind(SceneDatas.class).in(Singleton.class);
        bind(StoryDungeonSceneDatas.class).in(Singleton.class);
        bind(ChallengeDungeonSceneDatas.class).in(Singleton.class);
        bind(VipDungeonSceneDatas.class).in(Singleton.class);
        bind(DefenceDungeonSceneDatas.class).in(Singleton.class);
        bind(NormalSceneDatas.class).in(Singleton.class);
        bind(SouShenDungeonSceneDatas.class).in(Singleton.class);
        bind(SouShenShop.class).in(Singleton.class);
        bind(LingYunDungeonSceneDatas.class).in(Singleton.class);
        bind(LongMaiDungeonSceneDatas.class).in(Singleton.class);
        bind(PortalDungeonSceneDatas.class).in(Singleton.class);
        bind(HuoLinActivitySceneDatas.class).in(Singleton.class);
        bind(GroupDungeonsWithPrizeConfig.class).in(Singleton.class);
        bind(CollectObjects.class).in(Singleton.class);
        bind(WorldBoss.class).in(Singleton.class);
        bind(SceneRemoveObjectMsgCache.class).in(Singleton.class);
        bind(JijianCostDatas.class).in(Singleton.class);
        bind(JijianSceneDatas.class).in(Singleton.class);
    }

}
