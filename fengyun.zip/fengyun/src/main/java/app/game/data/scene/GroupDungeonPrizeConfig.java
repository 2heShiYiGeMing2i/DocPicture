package app.game.data.scene;

import static com.mokylin.sink.util.Preconditions.*;
import app.game.data.Prize;
import app.game.data.PrizeConfig;
import app.game.data.PrizeConfigs;
import app.game.data.goods.GoodsWrapper;
import app.protobuf.ConfigContent.GroupDungeonPrizeProto;

import com.mokylin.sink.util.parse.ObjectParser;

public class GroupDungeonPrizeConfig{

    public static final int SCORE_SSS = 0;
    public static final int SCORE_SS = 1;
    public static final int SCORE_S = 2;
    public static final int SCORE_A = 3;
    public static final int SCORE_B = 4;
    public static final int SCORE_C = 5;

    private static final int PRIZE_SHOWN_COUNT = 4;

    public final int sceneID;

    public final SceneData sceneData;

    public final Prize fixedPrize;

    public final PlunderGroup prizeS;

    public final PlunderGroup prizeV5;

    private final int timeSSS;

    private final int timeSS;

    private final int timeS;
    private final int timeA;

    GroupDungeonPrizeConfig(SceneData sceneData, ObjectParser p,
            PrizeConfigs prizes, PlunderGroups groups){
        this.sceneID = sceneData.id;
        this.sceneData = sceneData;

        this.timeSSS = p.getIntKey("time_sss");
        this.timeSS = p.getIntKey("time_ss");
        this.timeS = p.getIntKey("time_s");
        this.timeA = p.getIntKey("time_a");

        // 检查每个都要>0, 且大于前一等级的
        checkArgument(timeSSS > 0, "%s sss级评分的时间必须 > 0: %s", this, this.timeSSS);
        checkArgument(timeSS > timeSSS, "%s  ss级评分的时间必须 > sss的", this, this);
        checkArgument(timeS > timeSS, "%s s级评分的时间必须 > ss的", this, this);
        checkArgument(timeA > timeS, "%s A级评分的时间必须 > s的", this, this);
        // ---

        String fixedPrizeName = p.getKey("fixed_prize");
        PrizeConfig fixedPrizeConfig = checkNotNull(prizes.get(fixedPrizeName),
                "%s 配置的固定奖励没找到", this);

        checkArgument(!fixedPrizeConfig.hasExipreTimeGoods(),
                "%s 配置的固定奖励居然有过期时间", this);
        checkArgument(!fixedPrizeConfig.isRaceDiff(), "%s 配置的固定奖励居然跟职业相关的",
                this);
        checkArgument(!fixedPrizeConfig.isVarPrize(), "%s 配置的固定奖励居然是可变的", this);

        fixedPrize = fixedPrizeConfig.random();
        for (GoodsWrapper w : fixedPrize.getGoodsWrappers())
            w.cacheProto();

        // s级奖励
        String plunderGroupStr = p.getKey("prize_s");
        PlunderGroup prizeS = checkNotNull(groups.get(plunderGroupStr),
                "%s 的S级奖励组包没找到，%s", this, plunderGroupStr);
        this.prizeS = prizeS;

        checkArgument(prizeS.getGoodsRandomers().length >= PRIZE_SHOWN_COUNT,
                "%s 的s级奖励必须至少配%s个", this, PRIZE_SHOWN_COUNT);

        prizeS.initShowGoodsWrapper();

        // v5奖励
        plunderGroupStr = p.getKey("prize_v5");
        PlunderGroup prizeV5 = checkNotNull(groups.get(plunderGroupStr),
                "%s 的V5奖励组包没找到，%s", this, plunderGroupStr);

        this.prizeV5 = prizeV5;

        checkArgument(prizeV5.getGoodsRandomers().length >= PRIZE_SHOWN_COUNT,
                "%s 的V5奖励必须至少配%s个", this, PRIZE_SHOWN_COUNT);

        prizeV5.initShowGoodsWrapper();
    }

    public GoodsWrapper getRandomPrizeS(){
        return prizeS.randomGoodsWrapper();
    }

    public GoodsWrapper getRandomPrizeV5(){
        return prizeV5.randomGoodsWrapper();
    }

    public GoodsWrapper[] getRandomPrizeSAnd3More(){
        return prizeS.randomGoodsAndShowGoods(PRIZE_SHOWN_COUNT);
    }

    public GoodsWrapper[] getRandomPrizeV5And3More(){
        return prizeV5.randomGoodsAndShowGoods(PRIZE_SHOWN_COUNT);
    }

    public Prize getFixedPrize(){
        return fixedPrize;
    }

    public int calculateScore(int duration, int deadCount){
        // 计算时间得分
        final int timeScore;

        if (duration <= timeSSS){
            timeScore = SCORE_SSS;
        } else if (duration <= timeSS){
            timeScore = SCORE_SS;
        } else if (duration <= timeS){
            timeScore = SCORE_S;
        } else if (duration <= timeA){
            timeScore = SCORE_A;
        } else{
            timeScore = SCORE_B;
        }

        // 计算死亡次数得分
        final int deadScore;

        switch (deadCount){
            case 0:{
                deadScore = SCORE_SSS;
                break;
            }

            case 1:{
                deadScore = SCORE_A;
                break;
            }

            case 2:{
                deadScore = SCORE_B;
                break;
            }

            default:{
                deadScore = SCORE_C;
                break;
            }
        }

        return Math.max(timeScore, deadScore); // 越大分数越低
    }

    GroupDungeonPrizeProto encode(){
        GroupDungeonPrizeProto.Builder builder = GroupDungeonPrizeProto
                .newBuilder();
        if (fixedPrize.getExp() > 0){
            builder.setPrizeExp(fixedPrize.getExp());
        }
        if (fixedPrize.getMoney() > 0){
            builder.setPrizeMoney(fixedPrize.getMoney());
        }
        if (fixedPrize.getRealAir() > 0){
            builder.setPrizeRealAir(fixedPrize.getRealAir());
        }

        for (GoodsWrapper w : fixedPrize.getGoodsWrappers()){
            builder.addPrizeGoods(w.encode4Client());
        }

        return builder.build();
    }

    @Override
    public String toString(){
        return "组队副本-" + sceneID;
    }
}
