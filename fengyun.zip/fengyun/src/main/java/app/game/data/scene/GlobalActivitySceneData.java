package app.game.data.scene;

import static com.mokylin.sink.util.Preconditions.checkArgument;

import org.joda.time.DateTimeConstants;

import app.cluster.client.combat.scene.LocalGlobalActivityScene;
import app.cluster.combat.master.logic.scene.RemoteGlobalActivityScene;
import app.game.data.GameObjects;
import app.game.data.TimeData;
import app.game.module.scene.AbstractDungeonScene;
import app.game.module.scene.IClusterLocalDungeonService;
import app.game.module.scene.IDungeonService;
import app.game.service.log.LogService;
import app.message.ISender;
import app.utils.IDUtils;
import app.utils.VariableConfig;

import com.mokylin.sink.util.parse.ObjectParser;

/**
 * 全区服互通的活动场景
 * @author Timmy
 *
 */
public abstract class GlobalActivitySceneData extends ClusterDungeonSceneData{

    /**
     * 每个场景的英雄人数上限
     */
    public final int perSceneHeroLimit;

    /**
     * 活动开启的时间. 可以是每天, 也可以是每周
     */
    public final TimeData activityTime;

    /**
     * 每次活动的持续时间
     */
    public final long activityDurationMillis;

    /**
     * 配置文件中配置的活动时间
     */
    public final String timeConfig;

    GlobalActivitySceneData(GameObjects go, ObjectParser p, BlockInfos blocks,
            MonsterDatas monsters, Scripts scripts, Plunders plunders, Ais ais,
            SceneTransportDatas transports,
            SceneRemoveObjectMsgCache removeMsgCache){
        super(go, p, blocks, monsters, scripts, plunders, ais, transports,
                removeMsgCache);

        // 场景人数上限
        this.perSceneHeroLimit = p.getIntKey("per_scene_hero_limit");
        checkArgument(perSceneHeroLimit > 0 && perSceneHeroLimit <= 200,
                "跨服活动的per_scene_hero_limit的每场景人数上限必须为1-200之间: {} -> {}", this,
                perSceneHeroLimit);

        // 开启时间
        this.timeConfig = p.getKey("activity_time");
        this.activityTime = TimeData.parse(timeConfig);

        // 活动持续时间
        int activityTimeMinute = p.getIntKey("activity_duration_minute"); // 表里配的是分钟数
        checkArgument(activityTimeMinute > 0, "活动的持续分钟数必须>0: {} -> {}", this,
                activityTimeMinute);
        this.activityDurationMillis = activityTimeMinute
                * DateTimeConstants.MILLIS_PER_MINUTE;
    }

    /**
     * 跨服场景会重写这个id, 返回的sequence一定是SCENE_MAX_LINE_COUNT+1
     * @return
     */
    @Override
    public int newDungeonID(){
        return IDUtils.combineSceneID(id,
                VariableConfig.CLUSTER_DUNGEON_SEQUENCE);
    }

    @Override
    public AbstractDungeonScene newDungeon(int sceneID,
            IDungeonService dungeonService, LogService logService, long creator){
        throw new UnsupportedOperationException("跨服活动副本不该由newDungeon创建: "
                + toString());
    }

    @Override
    public abstract LocalGlobalActivityScene newLocalClusterScene(int uuid,
            IClusterLocalDungeonService dungeonService, ISender combatClient,
            long heroID);

    @Override
    public abstract RemoteGlobalActivityScene newRemoteClusterScene(int uuid,
            IDungeonService dungeonService, long creator, ISender worker);

}
