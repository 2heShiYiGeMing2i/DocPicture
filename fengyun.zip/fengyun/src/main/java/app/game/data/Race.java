package app.game.data;

import static com.mokylin.sink.util.Preconditions.checkNotNull;

import java.util.Arrays;
import java.util.List;

import app.game.data.spell.PassiveSpell;
import app.game.data.spell.SingleEffectSpell;
import app.game.data.spell.Spells;
import app.game.data.task.ChapterTaskData;
import app.game.data.task.TaskDatas;
import app.game.entity.Model;
import app.game.entity.SpellList;
import app.game.module.scene.FightData;
import app.game.service.TimeService;
import app.protobuf.HeroServerContent.RaceId;
import app.utils.VariableConfig;

import com.google.common.annotations.VisibleForTesting;
import com.google.protobuf.ByteString;
import com.mokylin.collection.IntHashMap;
import com.mokylin.collection.IntHashSet;
import com.mokylin.collection.LeftIntPair;
import com.mokylin.sink.util.Utils;

public class Race{

    public final RaceId raceId;

    // true为男银
    public final boolean isMale;

    // 职业名字
    public final String name;

    public final SpriteStat stat;

    public final HeroLevelData initialHeroLevelData;

    public final int initialHeroSceneID;

    public final int initialHeroX;

    public final int initialHeroY;

    private final Spells spells;

    // 主动学会的主动技能
    private final IntHashMap<SingleEffectSpell[]> autoLearnedSingleEffectSpell;

    private final SingleEffectSpell[] autoLearnedSingleEffectSpellAtLevel1;

    private final int[][] autoLearnedSingleEffectSpellType;

    // 主动学会的被动技能
    private final IntHashMap<PassiveSpell[]> autoLearnedPassiveSpell;

    private final PassiveSpell[] autoLearnedPassiveSpellAtLevel1;

    // 创建英雄时有的任务
    private final ChapterTaskData firstChapterTask;

    public final int maxUseTaskId;

    /**
     * 最后一章剧情任务（用于英雄完成所有剧情任务时展示任务列表）
     * int 表示第几章， ByteString[] 表示每个任务名称的列表
     */
    public final LeftIntPair<ByteString[]> lastChapterTaskInfo;

    public final int lotteryCount;

    private final TimeService timeService;

    private final int rageMaxAmount;

    Race(RaceId raceId, boolean isMale, String name, int initialHeroSceneID,
            int initialHeroX, int initialHeroY, HeroLevelDatas levelDatas,
            Spells spells, TaskDatas taskDatas, LotteryDatas lotteryDatas,
            TimeService timeService, int rageMaxAmount){
        this.raceId = raceId;
        this.isMale = isMale;
        this.name = name;

        this.initialHeroSceneID = initialHeroSceneID;
        this.initialHeroX = initialHeroX;
        this.initialHeroY = initialHeroY;

        this.initialHeroLevelData = checkNotNull(levelDatas.get(1),
                "没有找到英雄的一级等级数据: %s");

        stat = initialHeroLevelData.getBaseStat();

        this.spells = spells;

        // 初始化根据等级主动学会的技能
        autoLearnedSingleEffectSpell = new IntHashMap<>();
        List<SingleEffectSpell> ss = spells.getSingleEffectSpells()
                .getAutoLearnedSpellByRace(getId());
        for (SingleEffectSpell sp : ss){
            SingleEffectSpell[] sps = autoLearnedSingleEffectSpell
                    .get(sp.clientCanLearnLevel);
            if (sps == null){
                sps = new SingleEffectSpell[1];
                sps[0] = sp;
            } else{
                sps = Arrays.copyOf(sps, sps.length + 1);
                sps[sps.length - 1] = sp;
            }
            autoLearnedSingleEffectSpell.put(sp.clientCanLearnLevel, sps);
        }
        autoLearnedSingleEffectSpellAtLevel1 = autoLearnedSingleEffectSpell
                .get(1);

        autoLearnedSingleEffectSpellType = new int[VariableConfig.HERO_MAX_LEVEL][];
        IntHashSet spellTypes = new IntHashSet();
        for (int lv = 1; lv <= VariableConfig.HERO_MAX_LEVEL; lv++){
            int i = lv - 1;

            SingleEffectSpell[] sps = autoLearnedSingleEffectSpell.get(lv);
            if (sps == null){
                autoLearnedSingleEffectSpellType[i] = autoLearnedSingleEffectSpellType[i - 1];
                continue;
            }

            int c = spellTypes.size();
            for (SingleEffectSpell s : sps){
                spellTypes.add(s.spellType);
            }

            if (c == spellTypes.size()){
                autoLearnedSingleEffectSpellType[i] = autoLearnedSingleEffectSpellType[i - 1];
                continue;
            }

            int[] array = new int[spellTypes.size()];
            int n = 0;
            for (int v : spellTypes){
                array[n++] = v;
            }

            autoLearnedSingleEffectSpellType[i] = array;
        }

        // 被动技能
        autoLearnedPassiveSpell = new IntHashMap<>();
        List<PassiveSpell> ps = spells.getPassiveSpells()
                .getAutoLearnedSpellByRace(getId());
        for (PassiveSpell sp : ps){
            PassiveSpell[] sps = autoLearnedPassiveSpell
                    .get(sp.clientCanLearnLevel);
            if (sps == null){
                sps = new PassiveSpell[1];
                sps[0] = sp;
            } else{
                sps = Arrays.copyOf(sps, sps.length + 1);
                sps[sps.length - 1] = sp;
            }
            autoLearnedPassiveSpell.put(sp.clientCanLearnLevel, sps);
        }
        autoLearnedPassiveSpellAtLevel1 = autoLearnedPassiveSpell.get(1);

        firstChapterTask = taskDatas.getFirstChapterTask();
        maxUseTaskId = taskDatas.getMaxUseTaskId();
        lastChapterTaskInfo = taskDatas.getLastChapterTaskInfo();

        lotteryCount = lotteryDatas.getLotteryCount();
        this.timeService = timeService;
        this.rageMaxAmount = rageMaxAmount;
    }

    public int getId(){
        return raceId.getNumber();
    }

    public RaceId getRaceId(){
        return raceId;
    }

    public ChapterTaskData getFirstChapterTask(){
        return firstChapterTask;
    }

    public SingleEffectSpell[] getAutoLearnedSpellByLevel(int level){
        return autoLearnedSingleEffectSpell.get(level);
    }

    public PassiveSpell[] getAutoLearnedPassiveSpellByLevel(int level){
        return autoLearnedPassiveSpell.get(level);
    }

    public int[] getSpellType(int lv){
        return Utils.getValidObject(autoLearnedSingleEffectSpellType, lv - 1);
    }

    public SpellList newSpellList(){
        SpellList result = new SpellList(rageMaxAmount);
        if (autoLearnedSingleEffectSpellAtLevel1 != null){
            int i = 0;
            for (SingleEffectSpell sp : autoLearnedSingleEffectSpellAtLevel1){
                result.addSingleEffectSpell(sp.withUsedTimes(0));

                if (!sp.isRageSpell()){
                    // 只设置前5个
                    result.setShortcut(sp.spellType << 3, i++, 0);
                }
            }
        }
        if (autoLearnedPassiveSpellAtLevel1 != null){
            for (PassiveSpell sp : autoLearnedPassiveSpellAtLevel1){
                result.addPassiveSpell(sp);
            }
        }

        return result;
    }

    public FightData newFightDataForNewHero(){
        FightData result = new FightData(stat, 1);
        result.setJumpShield(VariableConfig.HERO_MAX_JUMP_SHIELD);
        result.setStaminaToMax();
        result.setSceneIDAndPos(initialHeroSceneID, initialHeroX, initialHeroY);

        return result;
    }

    public Model newModel(){
        return new Model(timeService);
    }

    @VisibleForTesting
    public Spells getSpells(){
        return spells;
    }
}
