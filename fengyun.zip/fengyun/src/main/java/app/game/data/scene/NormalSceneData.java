package app.game.data.scene;

import static com.mokylin.sink.util.Preconditions.*;

import java.util.Collection;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.jboss.netty.buffer.ChannelBuffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.data.GameObjects;
import app.game.data.Prize;
import app.game.data.PrizeConfig;
import app.game.data.PrizeConfigs;
import app.game.data.ServerData;
import app.game.data.TimeData;
import app.game.module.scene.NormalSceneModuleContainer;
import app.game.module.scene.SceneMessages;
import app.protobuf.ConfigContent.SingleScene;
import app.protobuf.LogContent.LogEnum.SceneType;
import app.utils.IndividualServerConfig;
import app.utils.VariableConfig;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.google.common.collect.HashMultimap;
import com.google.common.collect.Lists;
import com.google.common.collect.Multimap;
import com.google.protobuf.ByteString;
import com.mokylin.collection.IntArrayList;
import com.mokylin.sink.util.Empty;
import com.mokylin.sink.util.RandomNumber;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.parse.ObjectParser;

public class NormalSceneData extends SceneData{
    private static final Logger logger = LoggerFactory
            .getLogger(NormalSceneData.class);

    public static final NormalSceneData[] EMPTY_ARRAY = new NormalSceneData[0];
    private static final CacheBuilder<Object, Object> eliteMonsterMsgCacheBuilder = CacheBuilder
            .newBuilder().concurrencyLevel(1)
            .expireAfterWrite(5, TimeUnit.SECONDS).initialCapacity(8);

    // --- 每个联服一个, 如果本场景是跨服的, 则一定只有一个 ---

    private NormalSceneModuleContainer[] normalSceneModuleContainers;
    // ---

    public final int recommendLevel;
    private final int defaultLineCount;
    private final int maxLineCount;
    private final int lineCapacity;
    private final int lineCapacityIncrement;

    // ---- 死亡复活 -----
    public final int deathReturnSceneID;
    private NormalSceneData deathScene;
    protected int[] deathReturnPointArray;
    protected int deathReturnPointCount;

    // boss怪
    private final MonsterStatisticsData boss;
    // 精英怪
    private final MonsterStatisticsData eliteMonster;

    private final LoadingCache<ServerData, ChannelBuffer> eliteMonsterMsg;

    final SceneTransportData[] transports;

    final int[] enterPointArray;

    // --- 联服 ---
    /**
     * 是否是跨服场景
     */
    private final boolean isClustered;

    // --- 板块战 ---
    /**
     * 是否是板块战地图
     */
    public final boolean isTerritoryLand;

    /**
     * 板块战占领帮派可领取的奖励
     */
    public final Prize territoryPrize;

    /**
     * 板块战旗子位置
     */
    public final int territoryFlagPosX;
    public final int territoryFlagPosY;

    private final int attackRelivePosX;
    private final int attackRelivePosY;
    private final int attackReliveRadius;
    private final int[] attackRelivePosArray;
    public final int attackRelivePosCount;

    private final int defenceRelivePosX;
    private final int defenceRelivePosY;
    private final int defenceReliveRadius;
    private final int[] defenceRelivePosArray;
    public final int defenceRelivePosCount;

    // 动态刷新的怪物
    private final int maxDynamicMonID;
    public final MonsterGroupWithTimeData[] dynamicMonsterWithTime;

    NormalSceneData(GameObjects go, ObjectParser p, BlockInfos blocks,
            MonsterDatas monsters, Scripts scripts, Plunders plunders, Ais ais,
            SceneTransportDatas transports,
            SceneRemoveObjectMsgCache removeMsgCache, PrizeConfigs prizeConfigs){
        super(go, p, blocks, monsters, scripts, plunders, ais, transports,
                removeMsgCache);

        recommendLevel = p.getIntKey("recommend_level");
        deathReturnSceneID = p.getIntKey("death_return_scene_id");

        // 是个普通场景
        defaultLineCount = p.getIntKey("default_line_count");
        maxLineCount = p.getIntKey("max_line_count");
        lineCapacity = p.getIntKey("line_capacity");
        lineCapacityIncrement = p.getIntKey("line_capacity_increment");

        // --- 跨服 ---
        this.isClustered = p.getBooleanKey("is_clustered", false);

        // TODO 根据等级排行榜前500名的平均等级, 动态减少maxLineCount

        checkArgument(maxLineCount >= 1
                && maxLineCount <= VariableConfig.SCENE_MAX_LINE_COUNT,
                "场景的max_line_count必须是1-" + VariableConfig.SCENE_MAX_LINE_COUNT
                        + ": %s: %s", this, maxLineCount);

        checkArgument(
                defaultLineCount >= 1 && defaultLineCount <= maxLineCount,
                "场景%s的默认线数default_line_count的范围是1到最大线数: 1-%s. 当前是%s", this,
                maxLineCount, defaultLineCount);

        checkArgument(lineCapacity >= 1 && lineCapacity <= 100000,
                "场景的line_capacity必须是1-100000: %s: %s", this, lineCapacity);

        checkArgument(lineCapacityIncrement >= 1
                && lineCapacityIncrement <= 100000,
                "场景的line_capacity_increment必须是1-100000: %s: %s", this,
                lineCapacityIncrement);

        // --- 

        if (isClustered){
            NormalSceneModuleContainer container = new NormalSceneModuleContainer(
                    null, maxLineCount, lineCapacity, lineCapacityIncrement);
            normalSceneModuleContainers = new NormalSceneModuleContainer[]{container};
        } else{
            // 等SceneService初始化时, 传进来individualServerConfig, 知道有多少个联服之后, 再创建
        }

        // ---

        boss = initMonsterStatistics(MonsterData.TYPE_BOSS, true);
        if (boss != null){
            checkArgument(boss.isDeadBroadcast, "boss居然没有配置死亡广播");
        }

        eliteMonster = initMonsterStatistics(MonsterData.TYPE_ELITE_MONSTER,
                false);
        if (eliteMonster != null){
            checkArgument(!eliteMonster.isDeadBroadcast, "精英怪居然配置了死亡广播");
        }

        eliteMonsterMsg = eliteMonster == null ? null
                : eliteMonsterMsgCacheBuilder
                        .build(new CacheLoader<ServerData, ChannelBuffer>(){

                            @Override
                            public ChannelBuffer load(ServerData key)
                                    throws Exception{
                                return SceneMessages.requestEliteMonster(
                                        eliteMonster, key);
                            }
                        });

        // -------------------------- 设置传送门 ------------------------
        Collection<SceneTransportData> ts = transports
                .getTransportFromSourceScene(id);
        this.transports = ts.toArray(SceneTransportData.EMPTY_ARRAY);
        for (SceneTransportData t : ts){
            checkArgument(blockInfo.isWalkable(t.sourceX, t.sourceY),
                    "%s 场景的传送门在个不可行走的点上 <%s, %s>", this, t.sourceX, t.sourceY);

            checkArgument(id != t.getDestSceneID(), "%s场景的传送门是传送到同一个场景的", name);
        }

        // 场景传送进入点
        int enterX = p.getIntKey("enter_x");
        int enterY = p.getIntKey("enter_y");
        int enterRange = p.getIntKey("enter_random_range");
        IntArrayList enterPointsList = new IntArrayList();
        for (int x = enterX - enterRange; x <= enterX + enterRange; x++){
            for (int y = enterY - enterRange; y <= enterY + enterRange; y++){
                if (blockInfo.isWalkable(x, y)){
                    enterPointsList.add(Utils.short2Int(x, y));
                }
            }
        }
        checkArgument(enterPointsList.size() > 0,
                "场景%s 的传送进入坐标 <%s, %s>半径 %s内没有可走的坐标", this, enterX, enterY,
                enterRange);

        this.enterPointArray = enterPointsList.toArray();

        logger.debug("{} 读到 {} 个传送门", this, this.transports.length);

        // --- 板块战 ---
        this.isTerritoryLand = p.getBooleanKey("is_territory_land", false);
        String territoryPrizeConfig = p.getKey("territory_prize", "");
        territoryFlagPosX = p.getIntKey("territory_flag_x");
        territoryFlagPosY = p.getIntKey("territory_flag_y");

        if (isTerritoryLand){
            checkArgument(
                    territoryPrizeConfig != null
                            && territoryPrizeConfig.length() > 0,
                    "场景 %s 是板块战场景, 必须配置占领之后的奖励", this);
            PrizeConfig prizeConfig = checkNotNull(
                    prizeConfigs.get(territoryPrizeConfig),
                    "没有找到板块战场景 %s 的占领奖励: %s", this, territoryPrizeConfig);
            checkArgument(
                    !prizeConfig.isRaceDiff() && !prizeConfig.isVarPrize(),
                    "板块战 %s 的占领奖励 %s, 必须不能是变化的, 也不能是按职业不同的", this,
                    territoryPrizeConfig);

            territoryPrize = prizeConfig.random();

            checkArgument(
                    blockInfo.isWalkable(territoryFlagPosX, territoryFlagPosY),
                    "板块战 %s 的旗子初始位置<%s, %s> 不可走", this, territoryFlagPosX,
                    territoryFlagPosY);
        } else{
            checkArgument(
                    territoryPrizeConfig == null
                            || territoryPrizeConfig.length() == 0,
                    "场景 %s 不是板块战场景, 但是配置了占领之后的奖励. bug?", this);
            this.territoryPrize = null;
        }

        attackRelivePosX = p.getIntKey("attack_relive_pos_x");
        attackRelivePosY = p.getIntKey("attack_relive_pos_y");
        attackReliveRadius = p.getIntKey("attack_relive_radius");
        IntArrayList list = null;
        if (attackReliveRadius > 0){
            list = new IntArrayList();
            for (int x = attackRelivePosX - attackReliveRadius + 1; x < attackRelivePosX
                    + attackReliveRadius; x++){
                for (int y = attackRelivePosY - attackReliveRadius + 1; y < attackRelivePosY
                        + attackReliveRadius; y++){
                    if (blockInfo.isWalkable(x, y)){
                        list.add(Utils.short2Int(x, y));
                    }
                }
            }

            attackRelivePosCount = list.size();
            checkArgument(attackRelivePosCount > 0,
                    "%s 配置了攻击方的死亡复活半径，但是区域内一个可走的点都没有", this);
            attackRelivePosArray = list.toArray();
        } else{
            attackRelivePosArray = Empty.INT_ARRAY;
            attackRelivePosCount = 0;

            checkArgument(!isTerritoryLand, "%s 是板块战场景，但是没有配置进攻方复活点", this);
        }

        defenceRelivePosX = p.getIntKey("defencce_relive_pos_x");
        defenceRelivePosY = p.getIntKey("defencce_relive_pos_y");
        defenceReliveRadius = p.getIntKey("defencce_relive_radius");
        if (defenceReliveRadius > 0){
            if (list == null){
                list = new IntArrayList();
            } else{
                list.clear();
            }

            for (int x = defenceRelivePosX - defenceReliveRadius + 1; x < defenceRelivePosX
                    + defenceReliveRadius; x++){
                for (int y = defenceRelivePosY - defenceReliveRadius + 1; y < defenceRelivePosY
                        + defenceReliveRadius; y++){
                    if (blockInfo.isWalkable(x, y)){
                        list.add(Utils.short2Int(x, y));
                    }
                }
            }

            defenceRelivePosCount = list.size();
            checkArgument(defenceRelivePosCount > 0,
                    "%s 配置了防御方的死亡复活半径，但是区域内一个可走的点都没有", this);
            defenceRelivePosArray = list.toArray();
        } else{
            defenceRelivePosArray = Empty.INT_ARRAY;
            defenceRelivePosCount = 0;

            checkArgument(!isTerritoryLand, "%s 是板块战场景，但是没有配置防守方复活点", this);
        }

        // 动态怪物
        int monsterIDCounter = maxUseMonsterID;

        String monsterLocation = GameObjects.SCENE_BASE_FOLDER + "dynamic_mon/"
                + id + ".txt";
        List<ObjectParser> monsterGroupDataList = go.loadFile(monsterLocation);
        if (monsterGroupDataList.isEmpty()){
            maxDynamicMonID = monsterIDCounter;
            dynamicMonsterWithTime = MonsterGroupWithTimeData.EMPTY_ARRAY;
        } else{

            Multimap<TimeData, SceneMonsterData> monsterWithTime = HashMultimap
                    .create();

            // 固定时间刷的怪
            for (ObjectParser monGroupParser : monsterGroupDataList){
                MonsterGroupData groupData = new MonsterGroupData(
                        monGroupParser, monsters, plunders, ais, blockInfo);

                checkArgument(groupData.ai.isSingleLife,
                        "%s 配置的动态怪物的ai必须是一条命怪物", this);

                checkArgument(groupData.timeData != null, "%s 配置的动态怪物必须是定时刷新",
                        this);

                // 写给客户端
                groupData.monster.needEncodeToClient = true;

                int[] poses = groupData.getPos();

                for (int pos : poses){
                    SceneMonsterData mon = new SceneMonsterData(
                            ++monsterIDCounter, id, groupData,
                            Utils.getHighShort(pos), Utils.getLowShort(pos),
                            removeMsgCache);

                    monsterWithTime.put(groupData.timeData, mon);
                }
            }

            maxDynamicMonID = monsterIDCounter;

            checkArgument(monsterWithTime.size() > 0, "%s 配置了动态怪物，但是个数怎么好像是0呢");

            // 初始化有固定时间刷新的怪, 相同时间的都放在同一个MonsterGroupWithTimeData里

            List<MonsterGroupWithTimeData> monGroupList = Lists.newArrayList();

            for (TimeData timeData : monsterWithTime.keySet()){
                Collection<SceneMonsterData> mons = monsterWithTime
                        .get(timeData);
                SceneMonsterData[] sceneMons = mons
                        .toArray(SceneMonsterData.EMPTY_ARRAY);
                monGroupList.add(new MonsterGroupWithTimeData(timeData,
                        sceneMons));
            }

            this.dynamicMonsterWithTime = monGroupList
                    .toArray(MonsterGroupWithTimeData.EMPTY_ARRAY);
        }
    }

    @Override
    public int getMaxUsedMonsterID(){
        return maxDynamicMonID;
    }

    public boolean isInAttackReliveArea(int x, int y){
        return x > attackRelivePosX - attackReliveRadius
                && x < attackRelivePosX + attackReliveRadius
                && y > attackRelivePosY - attackReliveRadius
                && y < attackRelivePosY + attackReliveRadius;
    }

    public boolean isInDefenceReliveArea(int x, int y){
        return x > defenceRelivePosX - defenceReliveRadius
                && x < defenceRelivePosX + defenceReliveRadius
                && y > defenceRelivePosY - defenceReliveRadius
                && y < defenceRelivePosY + defenceReliveRadius;
    }

    public int randomAttackRelivePos(){
        if (attackRelivePosCount > 0){
            return attackRelivePosArray[RandomNumber.getRate(
                    attackRelivePosCount, true)];
        }

        return 0;
    }

    public int randomDefenceRelivePos(){
        if (defenceRelivePosCount > 0){
            return defenceRelivePosArray[RandomNumber.getRate(
                    defenceRelivePosCount, true)];
        }

        return 0;
    }

    public void initNormalSceneContainer(
            IndividualServerConfig individualServerConfig){
        /*
         * NormalSceneData不能依赖IndividualServerConfig, 不然跨服的两个服务也需要依赖IndividualServerConfig了
         */
        // 普通场景池
        // 如果是clustered, 则所有ServerData都共用一个NormalSceneModuleContainer
        if (!isClustered){
            ServerData[] serverDatas = individualServerConfig.getServerDatas();
            this.normalSceneModuleContainers = new NormalSceneModuleContainer[serverDatas.length];

            for (int i = 0; i < serverDatas.length; i++){
                normalSceneModuleContainers[i] = new NormalSceneModuleContainer(
                        serverDatas[i], maxLineCount, lineCapacity,
                        lineCapacityIncrement);
            }

        } else{
            // 如果是clustered, 已经在构造函数里搞定了
        }

        assert normalSceneModuleContainers != null;
    }

    public Prize getTerritoryPrize(){
        return territoryPrize;
    }

    /**
     * 是否是联服中立场景
     * @return
     */
    public boolean isClustered(){
        return isClustered;
    }

    public SceneTransportData getTransport(int x, int y){
        for (SceneTransportData t : transports){
            if (t.sourceX == x && t.sourceY == y){
                return t;
            }
        }
        return null;
    }

    public int randomEnterPoint(){
        return enterPointArray[RandomNumber.getRate(enterPointArray.length,
                true)];
    }

    public MonsterStatisticsData getBoss(){
        return boss;
    }

    public MonsterStatisticsData getEliteMonster(){
        return eliteMonster;
    }

    public ChannelBuffer getEliteMonsterMsg(ServerData serverData){
        return eliteMonsterMsg.getUnchecked(serverData);
    }

    public NormalSceneModuleContainer[] getNormalSceneContainers(){
        return normalSceneModuleContainers;
    }

    public NormalSceneModuleContainer getNormalSceneContainer(
            ServerData serverData){
        if (isClustered){
            return normalSceneModuleContainers[0];
        } else{
            return normalSceneModuleContainers[serverData.sequence];
        }
    }

    public int getDefaultLineCount(){
        return defaultLineCount;
    }

    public int getMaxLineCount(){
        return maxLineCount;
    }

    public int getLineCapacity(){
        return lineCapacity;
    }

    public int getLineCapacityIncrement(){
        return lineCapacityIncrement;
    }

    public void setDeathScene(NormalSceneData scene){
        this.deathScene = scene;
    }

    public NormalSceneData getDeathSceneData(){
        return deathScene;
    }

    public int getRandomDeathReturnPoint(){
        return deathReturnPointArray[RandomNumber
                .getRate(deathReturnPointCount)];
    }

    void setDeathPoints(SceneData sceneData){
        IntArrayList deathPointsList = new IntArrayList();
        for (int x = deathReturnX - deathReturnRandomRange; x <= deathReturnX
                + deathReturnRandomRange; x++){
            for (int y = deathReturnY - deathReturnRandomRange; y <= deathReturnY
                    + deathReturnRandomRange; y++){
                if (sceneData.blockInfo.isWalkable(x, y)){
                    deathPointsList.add(Utils.short2Int(x, y));
                }
            }
        }
        checkArgument(deathPointsList.size() > 0,
                "场景%s 的复活场景%s 的复活坐标 <%s, %s>半径 %s内没有可走的坐标", this, sceneData,
                deathReturnX, deathReturnY, deathReturnRandomRange);

        this.deathReturnPointArray = deathPointsList.toArray();
        deathReturnPointCount = this.deathReturnPointArray.length;
    }

    public SingleScene generateProto(){
        SingleScene.Builder builder = SingleScene.newBuilder();
        builder.setSceneId(id).setMap(blockName)
                .setName(ByteString.copyFrom(nameBytes)).setSound(sound)
                .setIsNormalScene(isNormalScene());

        if (isHeroLevelProtect){
            builder.setIsHeroLevelProtect(true);
        }
        if (isNewHeroProtect){
            builder.setIsNewHeroProtect(true);
        }
        if (isDeathProtect){
            builder.setIsDeathProtect(true);
        }
        if (isNightAutoProtect){
            builder.setIsNightAutoProtect(true);
        }
        if (isJumpLimit){
            builder.setIsJumpLimit(true);
        }
        if (isMountLimit){
            builder.setIsMountLimit(true);
        }

        if (isClustered){
            builder.setIsClustered(true);
        }

        if (poet != null){
            String tp = poet.trim();
            if (tp.length() > 0){
                builder.setPoet(ByteString.copyFromUtf8(tp));
            }
        }
        if (fixedPkMode != null){
            builder.setFixedPkMode(fixedPkMode.getIntMode());
        }

        builder.setRecommendLevel(recommendLevel);

        for (SceneTransportData t : transports){
            builder.addTransports(t.encode());
        }

        builder.setDeathReturnSceneId(deathReturnSceneID);

        if (isTerritoryLand){
            builder.setTerritoryPrize(territoryPrize.encode4Client());
        }

        if (territoryFlagPosX > 0){
            builder.setTerritoryFlagPosX(territoryFlagPosX);
        }
        if (territoryFlagPosY > 0){
            builder.setTerritoryFlagPosY(territoryFlagPosY);
        }

        return builder.build();
    }

    @Override
    public int getCanEnterLevel(){
        // 目标场景推荐等级 - 10级 才能进入
        return Math.max(1, recommendLevel - TRANSPORT_DIFF_LEVEL);
    }

    @Override
    public boolean isNormalScene(){
        return true;
    }

    @Override
    protected boolean canHaveMonsterWithTime(){
        return true;
    }

    @Override
    protected boolean canHaveRelivableMonster(){
        return true;
    }

    @Override
    public int getIntType(){
        return SceneType.NORMAL.getNumber();
    }

    private MonsterStatisticsData initMonsterStatistics(int monType,
            boolean isDeadBroadcast){
        assert monType == 1 || monType == 2;

        MonsterStatisticsData monster = null;
        for (MonsterGroupWithTimeData group : monsterWithTime){
            for (SceneMonsterData monData : group.monsters){
                if (monData.getMonsterData().type == monType){
                    checkArgument(
                            monster == null,
                            "普通场景%s 的同类特殊怪物个数大于1-_-!， type: %s (0普通怪, 1 精英怪, 2 boss)",
                            this, monType);

                    checkArgument(
                            group.timeData.getHours().length > 0,
                            "普通场景%s 的刷怪表中的定时刷新时间居然没有小时分钟 -_-!， type: %s (0普通怪, 1 精英怪, 2 boss)",
                            this, monType);

                    checkArgument(
                            group.timeData.isDailyTime(),
                            "普通场景%s 的刷怪表中的定时刷新时间不是每天都有的 -_-!， type: %s (0普通怪, 1 精英怪, 2 boss)",
                            this, monType);

                    monster = new MonsterStatisticsData(group.timeData,
                            monData, this, isDeadBroadcast);
                }
            }
        }

        return monster;
    }

}
