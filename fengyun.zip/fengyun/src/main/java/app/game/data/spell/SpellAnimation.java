package app.game.data.spell;

import static com.mokylin.sink.util.Preconditions.checkArgument;
import static com.mokylin.sink.util.Preconditions.checkNotNull;
import app.protobuf.ConfigContent.SingleSpellEffect;
import app.utils.VariableConfig;

import com.mokylin.sink.util.Empty;
import com.mokylin.sink.util.parse.ObjectParser;

public class SpellAnimation{

    public final int id;

    public final String name;

    /**
     * 技能图标id
     */
    public final String icon;

    public final boolean isRageSpell;

    public final String image;

    /**
     * 是否抖动屏幕
     */
    public final boolean shakeScreen;

    /**
     * 施法时间. 施法后多久不能移动
     */
    public final int castTime;

    // 真正的施法时间 减 32毫秒
    public transient final int heroCastTime;

    private final int[] motionCastTime;

    // 累计时间
    private final transient int[] motionTotalCastTime;

    /**
     * 不算飞行时间, 额外的受伤延时. 客户端从击中关键帧开始算起
     */
    public final int[] hurtDelay;

    // 是否随机攻击动作
    transient final boolean isRandomMotion;

    // ---------- 马下动作 ------------

    /**
     * 随机动作权重
     */
    private transient final int[] motionWeights;

    /**
     * 施法动作编号
     */
    public final int[] attackMotions;

    /**
     * 施法特效
     */
    public final Animation[] castAnimations;

    /**
     * 飞行特效
     */
    public final Animation flyAnimation;

    /**
     * 爆点特效
     */
    public final Animation[] hurtAnimations;

    /**
     * 目标点特效
     */
    public final Animation[] destAnimations;

    // ---------- 马上动作 ------------

    /**
     * 马上随机动作权重
     */
    private transient final int[] mountMotionWeights;

    /**
     * 马上施法动作编号
     */
    public final int[] mountAttackMotions;

    /**
     * 马上施法特效
     */
    public final Animation[] mountCastAnimations;

    /**
     * 马上飞行特效
     */
    public final Animation mountFlyAnimation;

    /**
     * 马上爆点特效
     */
    public final Animation[] mountHurtAnimations;

    /**
     * 马上目标点特效
     */
    public final Animation[] mountDestAnimations;

    // -------- end of 马上动作 ---------

    private final int hurtTimes;

    /**
     * 飞行特效的飞行速度, 单位 每秒飞行的像素值
     */
    public final int flySpeed;

    /**
     * 是否可被设置为默认技能
     */
    public final boolean canBeDefaultSpell;

    /**
     * 施法目标
     * 
     * 1. 自己
     * 
     * 2. 地面
     * 
     * 3. 需选目标
     * 
     * 4. 扇形区域
     */
    public final int targetType;

    /**
     * 是否是攻击性技能
     */
    public final boolean isAttack;

    public static final int TARGET_TYPE_SELF = 1;
    public static final int TARGET_TYPE_GROUND = 2;
    public static final int TARGET_TYPE_TARGET = 3;
    public static final int TARGET_TYPE_SECTOR = 4; // 扇形区域

    SpellAnimation(ObjectParser p, Animations animations){
        this.id = p.getIntKey("id");
        name = p.getKey("name");
        checkArgument(name.length() > 0, "技能效果的名字不能为空");

        this.icon = p.getKey("icon");
        this.image = p.getKey("image");

        this.shakeScreen = p.getBooleanKey("shake_screen");
        this.canBeDefaultSpell = p.getBooleanKey("can_be_default_spell");
        this.targetType = p.getIntKey("target_type");
        this.isAttack = p.getBooleanKey("is_attack");

        if (targetType == TARGET_TYPE_SELF){
            checkArgument(!isAttack,
                    "技能效果 %s 的targetType是0, 表示自己, 但是却是攻击性技能isAttack=1", this);
        }

        // 马下动作
        String attackMotionStr = p.getKey("attack_motion");
        String[] attackMotionArray = attackMotionStr.split(";");

        int attackMotionCount = attackMotionArray.length;
        checkArgument(attackMotionCount > 0, "技能效果%s 配置的动作个数必须大于0", this);

        attackMotions = new int[attackMotionCount];
        for (int i = 0; i < attackMotionCount; i++){
            attackMotions[i] = Integer.parseInt(attackMotionArray[i]);
        }

        String motionWeightStr = p.getKey("motion_weight");
        if (motionWeightStr.isEmpty()){
            motionWeights = Empty.INT_ARRAY;
        } else{
            String[] motionWeightArray = motionWeightStr.split(";");

            checkArgument(motionWeightArray.length == attackMotionCount,
                    "技能 %s 配置的动作随机权重个数跟动作个数不一致", this);

            motionWeights = new int[attackMotionCount];

            for (int i = 0; i < attackMotionCount; i++){
                motionWeights[i] = Integer.parseInt(motionWeightArray[i]);

                checkArgument(motionWeights[i] > 0, "技能 %s 配置的动作随机权重必须大于0, %s",
                        this, motionWeightStr);
            }
        }

        isRandomMotion = motionWeights.length > 0;
        if (isRandomMotion){
            castTime = p.getIntKey("cast_time");

            motionCastTime = new int[]{castTime};
            motionTotalCastTime = motionCastTime;
        } else{
            String castTimeStr = p.getKey("cast_time");
            String[] castTimeArray = castTimeStr.split(";");

            checkArgument(castTimeArray.length == attackMotionCount,
                    "技能 %s 配置的顺序释放时间个数跟动作个数不一致, %s", this);

            motionCastTime = new int[attackMotionCount];
            motionTotalCastTime = new int[attackMotionCount];

            int castTime = 0;
            for (int i = 0; i < attackMotionCount; i++){
                motionCastTime[i] = Integer.parseInt(castTimeArray[i]);

                checkArgument(motionCastTime[i] > 0, "技能 %s 配置的释放时间必须大于0, %s",
                        this, castTimeStr);

                castTime += motionCastTime[i];
                motionTotalCastTime[i] = castTime;
            }

            this.castTime = castTime;
        }

        heroCastTime = Math.max(0, castTime - 144);

        String hurtDelayStr = p.getKey("hurt_delay");

        if (hurtDelayStr.isEmpty()){
            hurtDelay = null;
        } else{
            String[] array = hurtDelayStr.split(";");
            checkArgument(array.length == attackMotionCount,
                    "技能效果%s 配置的hurt_delay跟attack_motion的个数不一致", this);

            hurtDelay = new int[attackMotionCount];
            for (int i = 0; i < attackMotionCount; i++){
                hurtDelay[i] = Integer.parseInt(array[i]);
            }
        }

        String castA = p.getKey("cast_animation");

        if (castA.isEmpty()){
            castAnimations = null;
        } else{
            String[] animaArray = castA.split(";");
            checkArgument(animaArray.length == attackMotionCount,
                    "技能效果%s 配置的cast_animation跟attack_motion的个数不一致", this);

            castAnimations = new Animation[attackMotionCount];
            for (int i = 0; i < attackMotionCount; i++){
                if (animaArray[i].isEmpty())
                    continue;

                castAnimations[i] = checkNotNull(animations.get(animaArray[i]),
                        "没有找到技能 %s 配置的施法特效: %s", this, animaArray[i]);
            }
        }

        String flyA = p.getKey("fly_animation");
        if (flyA.length() == 0){
            flyAnimation = null;
        } else{
            flyAnimation = checkNotNull(animations.get(flyA),
                    "没有找到技能 %s 配置的飞行特效: %s", this, flyA);

            checkArgument(attackMotionCount == 1, "技能效果%s 有多个动作，但是又配置了飞行特效",
                    this);
        }

        String hurtA = p.getKey("hurt_animation");
        if (hurtA.length() == 0){
            hurtAnimations = null;
        } else{
            String[] animaArray = hurtA.split(";");
            checkArgument(animaArray.length == attackMotionCount,
                    "技能效果%s 配置的hurt_animation跟attack_motion的个数不一致", this);

            hurtAnimations = new Animation[attackMotionCount];
            for (int i = 0; i < attackMotionCount; i++){
                if (animaArray[i].isEmpty())
                    continue;

                hurtAnimations[i] = checkNotNull(animations.get(animaArray[i]),
                        "没有找到技能 %s 配置的爆点特效: %s", this, animaArray[i]);
            }
        }

        String destA = p.getKey("dest_animation");
        if (destA.length() == 0){
            destAnimations = null;
        } else{

            String[] animaArray = destA.split(";");
            checkArgument(animaArray.length == attackMotionCount,
                    "技能效果%s 配置的dest_animation跟attack_motion的个数不一致", this);

            destAnimations = new Animation[attackMotionCount];
            for (int i = 0; i < attackMotionCount; i++){
                if (animaArray[i].isEmpty())
                    continue;

                destAnimations[i] = checkNotNull(animations.get(animaArray[i]),
                        "没有找到技能 %s 配置的目标点特效: %s", this, animaArray[i]);
            }
        }

        // ------ 马上动作 -------
        String mountAttackMotionStr = p.getKey("mount_attack_motion");
        if (mountAttackMotionStr.isEmpty()){
            // 没有马上动作
            mountAttackMotions = null;
            mountCastAnimations = null;
            mountFlyAnimation = null;
            mountHurtAnimations = null;
            mountDestAnimations = null;
            mountMotionWeights = Empty.INT_ARRAY;
        } else{
            String[] mountAmArray = mountAttackMotionStr.split(";");

//            mountMotionWeights
            int mountAttackMotionCount = mountAmArray.length;

            if (isRandomMotion){
                String mountMotionWeightStr = p.getKey("mount_motion_weight");
                checkArgument(!mountMotionWeightStr.isEmpty(),
                        "技能 %s 配置的马上动作随机权重没有配置");

                String[] motionWeightArray = mountMotionWeightStr.split(";");

                checkArgument(
                        motionWeightArray.length == mountAttackMotionCount,
                        "技能 %s 配置的马上动作随机权重个数跟动作个数不一致", this);

                mountMotionWeights = new int[mountAttackMotionCount];

                for (int i = 0; i < mountAttackMotionCount; i++){
                    mountMotionWeights[i] = Integer
                            .parseInt(motionWeightArray[i]);

                    checkArgument(mountMotionWeights[i] > 0,
                            "技能 %s 配置的动作随机权重必须大于0, %s", this,
                            mountMotionWeightStr);
                }
            } else{
                checkArgument(mountAttackMotionCount == attackMotionCount,
                        "技能效果%s 马下和马上技能动作个数不一致", this);

                mountMotionWeights = Empty.INT_ARRAY;
            }

            mountAttackMotions = new int[mountAttackMotionCount];
            for (int i = 0; i < mountAttackMotionCount; i++){
                mountAttackMotions[i] = Integer.parseInt(mountAmArray[i]);
            }

            String mountCastA = p.getKey("mount_cast_animation");

            if (mountCastA.isEmpty()){
                mountCastAnimations = null;
            } else{
                String[] animaArray = mountCastA.split(";");
                checkArgument(animaArray.length == mountAttackMotionCount,
                        "技能效果%s 配置的mount_cast_animation跟attack_motion的个数不一致",
                        this);

                mountCastAnimations = new Animation[mountAttackMotionCount];
                for (int i = 0; i < mountAttackMotionCount; i++){
                    if (animaArray[i].isEmpty())
                        continue;

                    mountCastAnimations[i] = checkNotNull(
                            animations.get(animaArray[i]),
                            "没有找到技能 %s 配置的施法特效: %s", this, animaArray[i]);
                }
            }

            String mountFlyA = p.getKey("mount_fly_animation");
            if (mountFlyA.length() == 0){
                checkArgument(flyAnimation == null, "技能 %s 马下有飞行特效，马上就没有飞行特效？",
                        this);

                mountFlyAnimation = null;
            } else{
                checkArgument(flyAnimation != null, "技能 %s 马下没有飞行特效，马上就有飞行特效？",
                        this);

                mountFlyAnimation = checkNotNull(animations.get(mountFlyA),
                        "没有找到技能 %s 配置的马上飞行特效: %s", this, mountFlyA);
            }

            String mountHurtA = p.getKey("mount_hurt_animation");
            if (mountHurtA.length() == 0){
                mountHurtAnimations = null;
            } else{
                String[] animaArray = mountHurtA.split(";");
                checkArgument(animaArray.length == mountAttackMotionCount,
                        "技能效果%s 配置的mount_hurt_animation跟attack_motion的个数不一致",
                        this);

                mountHurtAnimations = new Animation[mountAttackMotionCount];
                for (int i = 0; i < mountAttackMotionCount; i++){
                    if (animaArray[i].isEmpty())
                        continue;

                    mountHurtAnimations[i] = checkNotNull(
                            animations.get(animaArray[i]),
                            "没有找到技能 %s 配置的爆点特效: %s", this, animaArray[i]);
                }
            }

            String mountDestA = p.getKey("mount_dest_animation");
            if (mountDestA.length() == 0){
                mountDestAnimations = null;
            } else{

                String[] animaArray = mountDestA.split(";");
                checkArgument(animaArray.length == mountAttackMotionCount,
                        "技能效果%s 配置的mount_dest_animation跟attack_motion的个数不一致",
                        this);

                mountDestAnimations = new Animation[mountAttackMotionCount];
                for (int i = 0; i < mountAttackMotionCount; i++){
                    if (animaArray[i].isEmpty())
                        continue;

                    mountDestAnimations[i] = checkNotNull(
                            animations.get(animaArray[i]),
                            "没有找到技能 %s 配置的目标点特效: %s", this, animaArray[i]);
                }
            }
        }

        // ---- end of 马上动作 ----

        this.flySpeed = p.getIntKey("fly_speed");
        checkArgument(flySpeed >= 0, "技能 %s 配置的飞行速度不能小于0: %s", this, flySpeed);

        if (flySpeed == 0){
            checkArgument(flyAnimation == null, "技能 %s 配置了飞行特效, 但是飞行速度是0", this);
        } else{
            checkNotNull(flyAnimation, "技能 %s 配置了飞行速度, 但是没有配飞行特效", this);

            checkArgument(targetType != TARGET_TYPE_SECTOR,
                    "技能 %s 是飞行技能，但是配置了扇形攻击区域(你想朝哪个方向打扇形)", this);
        }

        isRageSpell = p.getBooleanKey("is_rage");

        hurtTimes = isRandomMotion ? 1 : attackMotions.length;
    }

    public int getCastTime(int m){
        if (m >= 0 && m < motionTotalCastTime.length){
            return motionTotalCastTime[m];
        }

        return castTime;
    }

    public int getHurtTimes(){
        return hurtTimes;
    }

    public SingleSpellEffect generateProto(){
        SingleSpellEffect.Builder builder = SingleSpellEffect.newBuilder();

        builder.setId(id).setTargetType(targetType).setIcon(icon);

        if (isRageSpell){
            builder.setIsRage(true);
        }

        for (int m : attackMotions){
            builder.addAttackMotionIdList(m);
        }

        if (castAnimations != null){
            for (Animation a : castAnimations){
                int id = a != null ? a.id : 0;
                builder.addCastAnimationList(id);
            }
        }

        if (flyAnimation != null){
            builder.setFlyAnimation(flyAnimation.id);
            builder.setFlySpeed(flySpeed);
        }

        if (hurtAnimations != null){
            for (Animation a : hurtAnimations){
                int id = a != null ? a.id : 0;
                builder.addHurtAnimationList(id);
            }
        }

        if (destAnimations != null){
            for (Animation a : destAnimations){
                int id = a != null ? a.id : 0;
                builder.addDestAnimationList(id);
            }
        }

        if (shakeScreen){
            builder.setShakeScreen(true);
        }

        if (hurtDelay != null){
            for (int d : hurtDelay){
                builder.addHurtDelayList(d);
            }
        }

        for (int t : motionCastTime){
            builder.addCastTimeList(t);
        }

        // 随机释放
        builder.setIsMotionRandom(isRandomMotion);
        for (int m : motionWeights){
            builder.addMotionWeight(m);
        }

        if (image != null && !image.isEmpty()){
            builder.setImage(image);
        }

        if (canBeDefaultSpell){
            builder.setCanBeDefaultSpell(true);
        }

        if (isAttack){
            builder.setIsAttack(true);
        }

        // 马上动作
        if (mountAttackMotions != null){

            for (int m : mountMotionWeights){
                builder.addMountMotionWeight(m);
            }

            for (int m : mountAttackMotions){
                builder.addMountAttackMotionIdList(m);
            }

            if (mountCastAnimations != null){
                for (Animation a : mountCastAnimations){
                    int id = a != null ? a.id : 0;
                    builder.addMountCastAnimationList(id);
                }
            }

            if (mountFlyAnimation != null){
                builder.setMountFlyAnimation(mountFlyAnimation.id);
            }

            if (mountHurtAnimations != null){
                for (Animation a : mountHurtAnimations){
                    int id = a != null ? a.id : 0;
                    builder.addMountHurtAnimationList(id);
                }
            }

            if (mountDestAnimations != null){
                for (Animation a : mountDestAnimations){
                    int id = a != null ? a.id : 0;
                    builder.addMountDestAnimationList(id);
                }
            }
        }

        return builder.build();
    }

    public long getSpellDelay(int x1, int y1, int x2, int y2){
        if (flySpeed != 0){
            double distance = Math.hypot(x1 - x2, y1 - y2);
            return (long) ((distance * VariableConfig.PIXEL_PER_BLOCK_MULTIPLE_1000) / flySpeed);
        }

        return 0;
    }

    @Override
    public String toString(){
        return id + "-" + name;
    }
}
