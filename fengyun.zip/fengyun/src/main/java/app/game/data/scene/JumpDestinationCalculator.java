package app.game.data.scene;


import com.google.common.annotations.VisibleForTesting;
import com.mokylin.sink.util.Utils;

public class JumpDestinationCalculator{

    private final BlockInfo blockInfo;
    private final int startX;
    private final int startY;
    private final int endX;
    private final int endY;

    public JumpDestinationCalculator(BlockInfo blockInfo, int startX,
            int startY, int endX, int endY){
        super();
        this.blockInfo = blockInfo;
        this.startX = startX;
        this.startY = startY;
        this.endX = endX - 1; // x最大能达到的值
        this.endY = endY - 1;
    }

    public int getValidJumpPoint(int x, int y, int jumpTargetX,
            int jumpTargetY, int jumpLimit){

        assert jumpLimit > 0;
        assert x == Utils.getPointWithRange(startX, endX, x); // x, y一定已经在范围内
        assert y == Utils.getPointWithRange(startY, endY, y);
        assert jumpTargetX == Utils
                .getPointWithRange(startX, endX, jumpTargetX);
        assert jumpTargetY == Utils
                .getPointWithRange(startY, endY, jumpTargetY);

        double distance = Math.hypot(x - jumpTargetX, y - jumpTargetY);

        if (distance > jumpLimit){
            // 找个正好是limit的点
            double percentage = jumpLimit / distance;
            jumpTargetX = x + (int) ((jumpTargetX - x) * percentage);
            jumpTargetY = y + (int) ((jumpTargetY - y) * percentage);
        }

        // 那个点与自己站的点距离小于限制
        if (blockInfo.isWalkable(jumpTargetX, jumpTargetY)){
            // 目标点可走
            return Utils.short2Int(jumpTargetX, jumpTargetY);
        }

        // 目标点不可走, 则在目标点到站立点中找一个可走的点
        return findFurthestWalkablePoint(x, y, jumpTargetX, jumpTargetY);
    }

    @VisibleForTesting
    int findFurthestWalkablePoint(int x, int y, int jumpTargetX, int jumpTargetY){

        int xDistance = Math.abs(jumpTargetX - x);
        int yDistance = Math.abs(jumpTargetY - y);
        int stepY = jumpTargetY > y ? 1 : (jumpTargetY < y ? -1 : 0);
        int stepX = jumpTargetX > x ? 1 : (jumpTargetX < x ? -1 : 0);

        if (xDistance == 0){
            int nowY = jumpTargetY;
            for (int i = 0; i < yDistance; i++){
                nowY -= stepY;
                if (blockInfo.isWalkable(x, nowY)){
                    return Utils.short2Int(x, nowY);
                }
            }
            // 一路上都没有可以走的
            return blockInfo.isWalkable(x, y) ? Utils.short2Int(x, y) : -1;
        }

        if (yDistance == 0){
            int nowX = jumpTargetX;
            for (int i = 0; i < xDistance; i++){
                nowX -= stepX;
                if (blockInfo.isWalkable(nowX, y)){
                    return Utils.short2Int(nowX, y);
                }
            }
        }

        if (xDistance == yDistance){
            int nowX = jumpTargetX;
            int nowY = jumpTargetY;

            for (int i = 0; i < xDistance; i++){
                nowX -= stepX;
                nowY -= stepY;
                if (blockInfo.isWalkable(nowX, nowY)){
                    return Utils.short2Int(nowX, nowY);
                }
            }
            return blockInfo.isWalkable(x, y) ? Utils.short2Int(x, y) : -1;
        }

        // 如果直线倾斜角度大于45°，则每次递增Y来画直线，否则递增X
        boolean steep = yDistance > xDistance;

        if (steep){
            int temp = x;
            x = y;
            y = temp;

            temp = jumpTargetX;
            jumpTargetX = jumpTargetY;
            jumpTargetY = temp;

            temp = stepX;
            stepX = stepY;
            stepY = temp;
        }

        // 直线方程 y=kx+b x=(y-b)/k
        float k = ((float) jumpTargetY - y) / (jumpTargetX - x);
        float b = jumpTargetY - k * jumpTargetX;

        float half = 0.5f;
        int currentX = jumpTargetX - stepX;
        int currentY = jumpTargetY;

        while (currentY != y){
            float halfY = currentY - half * stepY;
            float crossX = (halfY - b) / k;

            int endX;
            double fx = Math.floor(crossX);
            boolean centerCross = crossX - fx == half;
            if (!centerCross){
                endX = (int) Math.round(crossX);
            } else{
                if (stepX > 0){
                    endX = (int) Math.ceil(crossX);
                } else{
                    endX = (int) fx;
                }
            }

            while (currentX != endX){
                int tempX = steep ? currentY : currentX;
                int tempY = steep ? currentX : currentY;
                if (blockInfo.isWalkable(tempX, tempY)){
                    return Utils.short2Int(tempX, tempY);
                }
                currentX -= stepX;
            }

            // 处理endX
            if (!centerCross){
                int tempX = steep ? currentY : currentX;
                int tempY = steep ? currentX : currentY;
                if (blockInfo.isWalkable(tempX, tempY)){
                    return Utils.short2Int(tempX, tempY);
                }
            }

            currentY -= stepY;
        }

        while (currentX != x){
            int tempX = steep ? currentY : currentX;
            int tempY = steep ? currentX : currentY;
            if (blockInfo.isWalkable(tempX, tempY)){
                return Utils.short2Int(tempX, tempY);
            }
            currentX -= stepX;
        }

        if (steep){
            int temp = x;
            x = y;
            y = temp;
        }
        return blockInfo.isWalkable(x, y) ? Utils.short2Int(x, y) : -1;
    }

}
