package app.game.data.scene;

import static com.mokylin.sink.util.Preconditions.checkArgument;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.data.GameObjects;
import app.game.data.PrizeConfigs;
import app.game.data.SpriteStats;
import app.game.data.goods.GoodsDatas;

import com.google.inject.Inject;
import com.mokylin.collection.IntHashMap;
import com.mokylin.sink.util.parse.ObjectParser;

public class LingYunDungeonSceneDatas{
    private static final Logger logger = LoggerFactory
            .getLogger(LingYunDungeonSceneDatas.class);

    public static final String LOCATION = GameObjects.LING_YUN_SCENE_BASE_FOLDER
            + "ling_yun.txt";

    private final LingYunDungeonSceneData sceneData;

    @Inject
    LingYunDungeonSceneDatas(GameObjects go, SpriteStats spriteStats,
            BlockInfos blocks, MonsterDatas monsters, Scripts scripts,
            Plunders plunders, Ais ais, SceneTransportDatas transports,
            GoodsDatas goodsDatas, PlunderGroups groups, PrizeConfigs prizes,
            SceneRemoveObjectMsgCache removeMsgCache){

        logger.debug("loading ling yun dungeon scenes");

        List<ObjectParser> list = go.loadFile(LOCATION);

        checkArgument(list.size() == 1, "必须有且只有一条凌云窟的配置: %s", LOCATION);

        ObjectParser p = list.get(0);
        sceneData = new LingYunDungeonSceneData(go, p, spriteStats, blocks,
                monsters, scripts, plunders, ais, transports, goodsDatas,
                groups, prizes, removeMsgCache);
    }

    public LingYunDungeonSceneData getSceneData(){
        return sceneData;
    }

    void putAll(IntHashMap<SceneData> totalMap){
        totalMap.putUnique(sceneData.id, sceneData);
    }
}
