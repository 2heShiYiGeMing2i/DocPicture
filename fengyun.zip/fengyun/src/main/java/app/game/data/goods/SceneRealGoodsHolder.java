package app.game.data.goods;

import static app.protobuf.LogContent.LogEnum.OperateType.SCENE_GOODS_PICK_UP;

import org.jboss.netty.buffer.ChannelBuffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.entity.Hero;
import app.game.module.GoodsContainerModule;
import app.game.module.scene.HeroFightModule;
import app.game.module.scene.SceneMessages;

import com.mokylin.sink.util.BufferUtil;

/**
 * @author Liwei
 *
 */
public class SceneRealGoodsHolder implements SceneGoodsHolder{

    private static final Logger logger = LoggerFactory
            .getLogger(SceneRealGoodsHolder.class);

    public static SceneGoodsHolder newGoodsHolder(Goods g, boolean ignoreOwner){
        return new SceneRealGoodsHolder(g, ignoreOwner);
    }

    private final Goods goods;

    private final boolean ignoreOwner;

    SceneRealGoodsHolder(Goods g, boolean ignoreOwner){
        goods = g;
        this.ignoreOwner = ignoreOwner;
    }

    public Goods getGoods(){
        return goods;
    }

    @Override
    public boolean ignoreOwner(){
        return ignoreOwner;
    }

    @Override
    public boolean canAddTo(HeroFightModule hfm){
        Hero hero = hfm.getHero();
        if (!hero.getDepot().hasEnoughEmptyCount(1)){
            logger.debug("背包已满，不能拾取物品");
            hfm.getSender().sendMessage(
                    SceneMessages.ERR_PICK_UP_FAIL_DEPOT_FULL);
            return false;
        }

        return true;
    }

    @Override
    public void give(HeroFightModule hfm){
        GoodsContainerModule goodsModule = hfm.getServices().getModules().goodsModule;
        goodsModule.addGoods(hfm.getHero(), goods, hfm.getSender(),
                hfm.getHeroMiscModule(), SCENE_GOODS_PICK_UP, 0, hfm
                        .getServices().getTimeService().getCurrentTime());
    }

    @Override
    public void writeTo(ChannelBuffer buffer){
        BufferUtil.writeTrue(buffer);

        BufferUtil.writeUTF(buffer, goods.getDropName());
        BufferUtil.writeUTF(buffer, goods.getData().iconBytes);
        BufferUtil.writeVarInt32(buffer, goods.getIntQuality());
        BufferUtil.writeVarInt32(buffer, goods.getCount());
        BufferUtil.writeBoolean(buffer, goods.getData().dropBroadAround);
        BufferUtil.writeVarInt32(buffer, goods.getIntType());
    }

    @Override
    public boolean needLog(){
        return goods.getData().needLog;
    }

//    @Override
//    public void doLog(OperateType type, OperateLogEvent e){
//        if (goods instanceof Equipment){
//            Equipment equipment = (Equipment) goods;
//
//            e.setData(type, SCENE_GOODS, goods.getId(), goods.getCount(),
//                    equipment.getRefinedTimes(), equipment.getIntQuality(),
//                    goods.getGoodsIdentifier(), "", 0, 0, 0);
//        } else{
//            e.setData(type, SCENE_GOODS, goods.getId(), goods.getCount(), 0, 0,
//                    goods.getGoodsIdentifier(), "", 0, 0, 0);
//        }
//    }
}
