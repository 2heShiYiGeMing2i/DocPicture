package app.game.data.pet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.data.ConfigService;
import app.game.data.SingleSpriteStat;
import app.game.data.SpriteStat;
import app.game.data.SpriteStatBuilder;
import app.game.data.spell.PassiveSpell;
import app.game.module.scene.FightData;
import app.protobuf.HeroContent.PetProto;
import app.protobuf.HeroServerContent.PetServerProto;
import app.protobuf.SpriteStatContent.StatType;
import app.utils.VariableConfig;

import com.mokylin.collection.IntValueIntHashMap;
import com.mokylin.collection.IntValueIntHashMap.Entry;
import com.mokylin.sink.util.Utils;

/**
 * @author Liwei
 *
 */
public class HeroPet{

    private static final Logger logger = LoggerFactory.getLogger(HeroPet.class);

    private final PetLevelDatas datas;

    // 过期时间
    private long expireTime;

    private PetLevelData levelData;

    private int addedMaxLife;

    private int addedAttack;

    private int addedDefence;

    private SpriteStat masterAddedStat;

    private int fightingAmount;

    public transient int currentLife;

    public transient long reliveTime;

    /**
     * 宠物技能
     */
    private final PassiveSpell[] spells;

    private transient boolean hasSpell;

    private final IntValueIntHashMap goodsCountMap;

    public HeroPet(PetLevelDatas datas, int level, long expireTime){
        this.datas = datas;
        this.expireTime = expireTime;

        this.levelData = datas.get(level);
        masterAddedStat = levelData.addedFixedStat;
        fightingAmount = levelData.addedFixedFightAmount;

        spells = new PassiveSpell[VariableConfig.PET_SPELL_SLOT_MAX_COUNT];
        goodsCountMap = new IntValueIntHashMap();
    }

    public boolean hasExpiredTime(){
        return expireTime > 0;
    }

    public boolean isExpired(long ctime){
        return hasExpiredTime() && expireTime < ctime;
    }

    public void removeExpireTime(){
        expireTime = 0;
    }

    public PetLevelData getData(){
        return levelData;
    }

    public int getLevel(){
        return levelData.level;
    }

    public void onLevelChanged(int newLevel){
        levelData = datas.get(newLevel);
    }

    public FightData newFightData(int sceneID, int pos, SpriteStat masterStat){
        SpriteStat stat = calculatePetStat(masterStat);

        FightData result = new FightData(stat, levelData.level);
        result.setSceneIDAndPos(sceneID, Utils.getHighShort(pos),
                Utils.getLowShort(pos));

        if (currentLife > 0)
            result.setLife(Math.max(Math.min(currentLife, stat.maxLife), 1));
        else
            result.setLife(stat.maxLife);

        return result;
    }

    public SpriteStat calculatePetStat(SpriteStat masterStat){
        return masterStat.calculatePetStat(levelData.fixedStat);
    }

    public int getFightingAmount(){
        return fightingAmount;
    }

    public SpriteStat getMasterStat(){
        return masterAddedStat;
    }

    public int getCanAddMasterStat(StatType statType){

        switch (statType){
            case MAX_LIFE:{
                return levelData.addedMaxLife - addedMaxLife;
            }
            case ATTACK:{
                return levelData.addedMaxAttack - addedAttack;
            }
            case DEFENCE:{
                return levelData.addedMaxDefence - addedDefence;
            }
            default:{
                return 0;
            }
        }
    }

    public SingleSpriteStat addMasterStatGoods(MasterStatGoods goods, int count){

        int newCount = count;
        int useCount = goodsCountMap.get(goods.getId());
        if (useCount > 0){
            newCount += useCount;
        }
        goodsCountMap.put(goods.getId(), newCount);

        return addMasterStat(goods.getStatType(), goods.getAmount(count));
    }

    public SingleSpriteStat addMasterStat(StatType statType, int toAddAmount){

        int realToAdd = 0;
        switch (statType){
            case MAX_LIFE:{
                realToAdd = Math.max(Math.min(levelData.addedMaxLife
                        - addedMaxLife, toAddAmount), 0);

                addedMaxLife += toAddAmount;
                break;
            }
            case ATTACK:{
                realToAdd = Math.max(Math.min(levelData.addedMaxAttack
                        - addedAttack, toAddAmount), 0);

                addedAttack += toAddAmount;
                break;
            }
            case DEFENCE:{
                realToAdd = Math.max(Math.min(levelData.addedMaxDefence
                        - addedDefence, toAddAmount), 0);

                addedDefence += toAddAmount;
                break;
            }
            default:{
                logger.error("addMasterStat中发现无效的属性类型");
                return SingleSpriteStat.getEmptyStat(statType);
            }
        }

        if (realToAdd > 0){
            // 更新属性
            masterAddedStat = masterAddedStat.add(statType, realToAdd);
            fightingAmount = FightData.calculateFightingAmount(masterAddedStat);

            return new SingleSpriteStat(statType, realToAdd);
        }

        return SingleSpriteStat.getEmptyStat(statType);
    }

    public PassiveSpell replace(int pos, PassiveSpell spell){
        assert pos < spells.length;

        PassiveSpell toRemove = spells[pos];
        spells[pos] = spell;
        hasSpell = true;

        return toRemove;
    }

    public PassiveSpell[] getSpells(){
        return spells;
    }

    public boolean hasSpell(){
        return hasSpell;
    }

    public PetProto encode4client(){
        PetProto.Builder builder = PetProto.newBuilder().setData(
                levelData.getProto());

        if (addedAttack > 0)
            builder.setAddedAttack(addedAttack);

        if (addedDefence > 0)
            builder.setAddedDefence(addedDefence);

        if (addedMaxLife > 0)
            builder.setAddedMaxLife(addedMaxLife);

        if (reliveTime > 0)
            builder.setReliveTime(reliveTime);

        if (expireTime > 0){
            builder.setExpireTime(expireTime);
        }

        // 技能
        for (int i = 0; i < spells.length; i++){
            PassiveSpell s = spells[i];
            if (s != null){
                builder.addSpellPos(i).addSpells(s.getProto());
            }
        }

        return builder.build();
    }

    public PetServerProto encode(long ctime){
        PetServerProto.Builder builder = PetServerProto.newBuilder();
        builder.setLife(currentLife);

        long t = reliveTime - ctime;
        if (t > 0)
            builder.setReliveTime(t);

        if (!goodsCountMap.isEmpty()){
            for (Entry entry : goodsCountMap.entrySet()){
                builder.addStatGoodsId(entry.getKey());
                builder.addStatGoodsCount(entry.getValue());
            }
        }

        for (PassiveSpell s : spells){
            int id = s == null ? 0 : s.id;
            builder.addSpells(id);
        }

        if (expireTime > 0){
            builder.setExpireTime(expireTime);
        }

        return builder.build();
    }

    public static HeroPet decode(PetServerProto proto,
            ConfigService configService, int level, long ctime,
            HeroTianJie tianjie){

        long expireTime = proto.getExpireTime();

        HeroPet pet = new HeroPet(configService.getPet().getLevelDatas(),
                level, expireTime);
        pet.doDecode(proto, configService, ctime);
        return pet;
    }

    private void doDecode(PetServerProto proto, ConfigService configService,
            long ctime){

        currentLife = proto.getLife();

        if (proto.getReliveTime() > 0){
            reliveTime = ctime + proto.getReliveTime();
        }

        int c = Math.min(proto.getStatGoodsIdCount(),
                proto.getStatGoodsCountCount());
        for (int i = 0; i < c; i++){
            int goodsId = proto.getStatGoodsId(i);
            int count = proto.getStatGoodsCount(i);
            goodsCountMap.put(goodsId, count);

            MasterStatGoods goods = configService.getPet().getMasterStatGoods(
                    goodsId);
            if (goods == null)
                continue;

            switch (goods.getStatType()){
                case MAX_LIFE:{
                    addedMaxLife += goods.getAmount(count);
                    break;
                }
                case ATTACK:{
                    addedAttack += goods.getAmount(count);
                    break;
                }
                case DEFENCE:{
                    addedDefence += goods.getAmount(count);
                    break;
                }
                default:{
                }
            }
        }

        c = Math.min(spells.length, proto.getSpellsCount());
        for (int i = 0; i < c; i++){
            int id = proto.getSpells(i);
            if (id <= 0)
                continue;

            PassiveSpell ps = configService.getSpells().getPassiveSpells()
                    .get(id);
            if (ps == null){
                logger.error("decode pet, spell not found. spell={}", id);
                continue;
            }

            spells[i] = ps;
            hasSpell = true;
        }

        if (addedMaxLife > 0 || addedAttack > 0 || addedDefence > 0){
            SpriteStatBuilder builder = SpriteStatBuilder.newBuilder();
            builder.add(levelData.addedFixedStat);
            builder.add(StatType.MAX_LIFE, addedMaxLife);
            builder.add(StatType.ATTACK, addedAttack);
            builder.add(StatType.DEFENCE, addedDefence);
            masterAddedStat = builder.build();
            fightingAmount = FightData.calculateFightingAmount(masterAddedStat);
        }
    }
}
