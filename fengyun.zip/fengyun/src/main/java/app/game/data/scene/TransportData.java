/**
 * 
 */
package app.game.data.scene;

import static com.mokylin.sink.util.Preconditions.checkArgument;

import com.mokylin.collection.IntArrayList;
import com.mokylin.sink.util.RandomNumber;
import com.mokylin.sink.util.Utils;

/**
 * @author Liwei
 *
 */
public class TransportData{

    public static TransportData newTransportData(NormalSceneData sceneData,
            int destX, int destY, int randomDistance){
        return new TransportData(sceneData, destX, destY, randomDistance);
    }

//    public final int destSceneID;

    private final int destX;

    private final int destY;

    public final int destRandomDistance;

    public int requiredLevel;

    private NormalSceneData destSceneData;

    private int[] canRandomDestPoint;

    private int canRandomDestPointCount;

    private TransportData(NormalSceneData sceneData, int destX, int destY,
            int randomDistance){
//        this.destSceneID = destSceneID;
        this.destX = destX;
        this.destY = destY;
        this.destRandomDistance = randomDistance;

        this.destSceneData = sceneData;

        checkArgument(randomDistance < 10,
                "传送目的地-%s 的随机半径必须小于10, randomDistance: %s", this,
                randomDistance);

        this.requiredLevel = destSceneData.getCanEnterLevel();

        IntArrayList canRandomPoint = new IntArrayList();

        for (int x = destX - destRandomDistance; x <= destX
                + destRandomDistance; x++){
            for (int y = destY - destRandomDistance; y <= destY
                    + destRandomDistance; y++){
                if (destSceneData.blockInfo.isWalkable(x, y)){
                    canRandomPoint.add(Utils.short2Int(x, y));
                }
            }
        }
        checkArgument(canRandomPoint.size() > 0,
                "传送目标终点 <%s, %s> 范围 %s 格内一个可行走点都没有", destSceneData.id, destX,
                destY, destRandomDistance);
        canRandomDestPoint = canRandomPoint.toArray();
        canRandomDestPointCount = canRandomDestPoint.length;
    }

    public int getDestSceneID(){
        return destSceneData.id;
    }

    public int getRandomPoint(){
        return canRandomDestPoint[RandomNumber.getRate(canRandomDestPointCount)];
    }

    public NormalSceneData getSceneData(){
        return destSceneData;
    }

    @Override
    public String toString(){
        return destSceneData + "|" + destX + "," + destY;
    }
}
