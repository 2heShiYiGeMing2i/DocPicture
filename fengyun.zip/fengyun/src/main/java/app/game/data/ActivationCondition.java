package app.game.data;

import static com.mokylin.sink.util.Preconditions.checkArgument;

import org.joda.time.DateTimeConstants;

import com.mokylin.sink.util.parse.ObjectParser;

import app.game.entity.Hero;
import app.protobuf.ConfigContent.ActivationConditionProto;

/**
 * @author Liwei
 *
 */
public class ActivationCondition{

    private final int vipLevel;

    private final int rechargeYuanbao;

    private final int heroLevel;

    private final int signTimes;

    private final int loginDay;

    private final long totalOnlineTime;

    public static ActivationCondition newCondition(Object master, ObjectParser p){
        int vipLevel = p.getIntKey("vip_level", 0);
        int rechargeYuanbao = p.getIntKey("recharge_yuanbao", 0);
        int heroLevel = p.getIntKey("hero_level", 0);
        int signTimes = p.getIntKey("sign_times", 0);
        int loginDay = p.getIntKey("login_day", 0);
        long onlineMinutes = p.getLongKey("online_minutes", 0);

        return new ActivationCondition(master, vipLevel, rechargeYuanbao,
                heroLevel, signTimes, loginDay, onlineMinutes);
    }

    public ActivationCondition(Object master, int vipLevel,
            int rechargeYuanbao, int heroLevel, int signTimes, int loginDay,
            long onlineMinuts){
        super();
        this.vipLevel = vipLevel;
        this.rechargeYuanbao = rechargeYuanbao;
        this.heroLevel = heroLevel;
        this.signTimes = signTimes;
        this.loginDay = loginDay;
        this.totalOnlineTime = onlineMinuts
                * DateTimeConstants.MILLIS_PER_MINUTE;

        checkArgument(vipLevel > 0 || rechargeYuanbao > 0 || heroLevel > 0
                || signTimes > 0 || loginDay > 0 || totalOnlineTime > 0,
                "%s 配置的激活条件无效，至少需要有一激活条件", master);
    }

    public boolean isAllReached(Hero hero, long ctime){

        if (hero.getVipLevel() < vipLevel){
            return false;
        }

        if (hero.getTotalRechargeYuanbao() < rechargeYuanbao){
            return false;
        }

        if (hero.getLevel() < heroLevel){
            return false;
        }

        if (hero.getWelfare().getTotalSingTimes() < signTimes){
            return false;
        }

        if (hero.getLoginDay() < loginDay){
            return false;
        }

        if (hero.getTotalOnlineAccTime(ctime) < totalOnlineTime){
            return false;
        }

        return true;
    }

    public boolean isReachedAny(Hero hero, long ctime){

        if (vipLevel > 0 && hero.getVipLevel() >= vipLevel){
            return true;
        }

        if (rechargeYuanbao > 0
                && hero.getTotalRechargeYuanbao() >= rechargeYuanbao){
            return true;
        }

        if (heroLevel > 0 && hero.getLevel() >= heroLevel){
            return true;
        }

        if (signTimes > 0 && hero.getWelfare().getTotalSingTimes() >= signTimes){
            return true;
        }

        if (loginDay > 0 && hero.getLoginDay() >= loginDay){
            return true;
        }

        if (totalOnlineTime > 0
                && hero.getTotalOnlineAccTime(ctime) >= totalOnlineTime){
            return true;
        }

        return false;
    }

    public ActivationConditionProto encode(){
        ActivationConditionProto.Builder builder = ActivationConditionProto
                .newBuilder();

        if (vipLevel > 0){
            builder.setVipLevel(vipLevel);
        }

        if (rechargeYuanbao > 0){
            builder.setRechargeYuanbao(rechargeYuanbao);
        }

        if (heroLevel > 0){
            builder.setHeroLevel(heroLevel);
        }

        if (signTimes > 0){
            builder.setSignTimes(signTimes);
        }

        if (loginDay > 0){
            builder.setLoginDay(loginDay);
        }

        if (totalOnlineTime > 0){
            builder.setTotalOnlineTime(totalOnlineTime);
        }

        return builder.build();
    }
}
