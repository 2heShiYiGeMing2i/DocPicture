package app.game.data.gem;

import static com.mokylin.sink.util.Preconditions.checkArgument;
import static com.mokylin.sink.util.Preconditions.checkNotNull;

import java.util.EnumMap;
import java.util.List;

import app.game.data.GameObjects;
import app.game.data.SpriteStat;
import app.game.data.SpriteStats;
import app.game.data.goods.Equipment;
import app.game.data.goods.GemGoodsData;
import app.game.data.goods.GoodsDatas;
import app.game.module.scene.FightData;
import app.protobuf.ConfigContent.GemConfig;
import app.protobuf.ConfigContent.GemStatProto;
import app.protobuf.SpriteStatContent.StatType;
import app.utils.VariableConfig;

import com.google.common.collect.Maps;
import com.google.inject.Inject;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class GemData{

    private static final String STAT_LOCATION = "config/data/gem/gem_stat.txt";

    private final EnumMap<StatType, GemStatData> gemStatMap;

    final GemStatData[] partStats;

    // 同部位+5属性
    private final GemExtraData level5ExtraData;

    // 同部位+7属性
    private final GemExtraData level7ExtraData;

    // 同部位+10属性
    private final GemExtraData level10ExtraData;

    @Inject
    GemData(GameObjects go, SpriteStats spriteStats, GoodsDatas goodsDatas,
            VariableConfig config){

        List<ObjectParser> data = go.loadFile(STAT_LOCATION);
        checkArgument(!data.isEmpty(), "宝石属性表没有配置");

        gemStatMap = new EnumMap<>(StatType.class);
        partStats = new GemStatData[Equipment.HERO_EQUIPED_MAX_COUNT];
        for (ObjectParser p : data){
            GemStatData d = new GemStatData(p, goodsDatas.getGems().length);

            checkArgument(gemStatMap.put(d.statType, d) == null, "宝石属性 %s 重复",
                    d.statType);

            for (int part : d.parts){
                checkArgument(partStats[part] == null, "宝石部件-%s 重复", part);
                partStats[part] = d;
            }
        }

        for (int i = 0; i < partStats.length; i++){
            checkNotNull(partStats[i], "宝石部件-%s 没有配置", i);
        }

        GemExtraData prevData = null;

        SpriteStat spriteStat = checkNotNull(
                spriteStats.get(config.GEM_LEVEL5_STAT), "部件全5阶附加属性没找到, %s",
                config.GEM_LEVEL5_STAT);

        level5ExtraData = prevData = new GemExtraData(GemExtraType.LEVEL5,
                spriteStat, prevData);

        spriteStat = checkNotNull(spriteStats.get(config.GEM_LEVEL7_STAT),
                "部件全7阶附加属性没找到, %s", config.GEM_LEVEL7_STAT);

        level7ExtraData = prevData = new GemExtraData(GemExtraType.LEVEL7,
                spriteStat, prevData);

        spriteStat = checkNotNull(spriteStats.get(config.GEM_LEVEL10_STAT),
                "部件全10阶附加属性没找到, %s", config.GEM_LEVEL10_STAT);

        level10ExtraData = prevData = new GemExtraData(GemExtraType.LEVEL10,
                spriteStat, prevData);

        level5ExtraData.initDiffStats(level5ExtraData, level7ExtraData,
                level10ExtraData);
        level7ExtraData.initDiffStats(level5ExtraData, level7ExtraData,
                level10ExtraData);
        level10ExtraData.initDiffStats(level5ExtraData, level7ExtraData,
                level10ExtraData);

    }

    public GemStatData getStatData(int part){
        return partStats[part];
    }

    public GemExtraData getExtraData(final int level){

        if (level < 5)
            return null;

        switch (level){
            case 5:
            case 6:{
                return level5ExtraData;
            }
            case 7:
            case 8:
            case 9:{
                return level7ExtraData;
            }
            default:{
                return level10ExtraData;
            }
        }
    }

    public GemConfig generateProto(GoodsDatas goodsDatas){
        GemConfig.Builder builder = GemConfig.newBuilder();

        for (GemGoodsData gem : goodsDatas.getGems()){
            builder.addGems(gem.getProtoByteString());

            int price = 0;
            if (gem.getNextLevel() != null){
                price = gem.getNextLevel().getDepotGemUpgradeData()
                        .getUpgradeGoodsYuanbaoPrice();
            }
            builder.addGemYuanbaoPrice(price);
        }

        builder.setFuseCount(VariableConfig.GEM_FUSE_COUNT);

        for (GemStatData data : gemStatMap.values()){
            GemStatProto.Builder statBuilder = GemStatProto.newBuilder()
                    .setStatType(data.statType).setIcon(data.icon);

            for (int i = 1; i < data.spriteStats.length; i++){
                statBuilder.addStatAmount(data.spriteStats[i].getAmount());
            }

            builder.addGemStats(statBuilder.build());
        }

        for (GemStatData data : partStats){
            builder.addPartStatType(data.statType);
        }

        builder.setSlotCount(VariableConfig.GEM_PART_SLOT_COUNT);

        builder.setGemLevel5Stat(level5ExtraData.spriteStat.encode());
        builder.setGemLevel7Stat(level7ExtraData.spriteStat.encode());
        builder.setGemLevel10Stat(level10ExtraData.spriteStat.encode());

        return builder.build();
    }

    enum GemExtraType{
        LEVEL5, LEVEL7, LEVEL10;
    }

    public static class GemExtraData{

        final GemExtraType type;

        final SpriteStat spriteStat;

        final SpriteStat totalStat;

        final int fightingAmount;

        // 跟其他额外属性的差值
        private final EnumMap<GemExtraType, SpriteStat> diffStatMap;

        private GemExtraData(GemExtraType type, SpriteStat spriteStat,
                GemExtraData prevData){
            this.type = type;
            this.spriteStat = spriteStat;

            if (prevData == null){
                totalStat = spriteStat;
            } else{
                totalStat = prevData.totalStat.add(spriteStat);
            }

            fightingAmount = FightData.calculateFightingAmount(totalStat);

            diffStatMap = Maps.newEnumMap(GemExtraType.class);
            diffStatMap.put(type, SpriteStat.EMPTY_STAT);
        }

        private void initDiffStats(GemExtraData... datas){

            for (GemExtraData data : datas){
                if (data == this)
                    continue;

                if (totalStat == data.totalStat){
                    diffStatMap.put(data.type, SpriteStat.EMPTY_STAT);
                } else{
                    diffStatMap
                            .put(data.type, totalStat.remove(data.totalStat));
                }
            }

            for (GemExtraType type : GemExtraType.values()){
                checkNotNull(diffStatMap.get(type),
                        "%s 类型的diffStatMap中没有%s类型的差值", this.type, type);
            }
        }

        public int getFightingAmount(){
            return fightingAmount;
        }

        public SpriteStat getTotalStat(){
            return totalStat;
        }

        public SpriteStat getDiffStat(GemExtraType type){
            return diffStatMap.get(type);
        }
    }
}
