package app.game.data.scene;

import static com.mokylin.sink.util.Preconditions.checkArgument;
import static com.mokylin.sink.util.Preconditions.checkNotNull;

import java.util.Collections;
import java.util.List;
import java.util.Map;

import app.game.data.goods.SceneAmountGoodsHolder;
import app.game.data.goods.Goods;
import app.game.data.goods.GoodsDatas;
import app.game.data.goods.SceneGoodsHolder;
import app.game.data.goods.GoodsRandomer;
import app.game.data.goods.SceneRealGoodsHolder;
import app.game.entity.Hero;
import app.game.module.scene.HeroFightModule;
import app.protobuf.LogContent.LogEnum.OperateType;
import app.utils.VariableConfig;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.mokylin.sink.util.RandomNumber;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * 掉落
 * @author Timmy
 *
 */
public class Plunder{

    private static final String IGNORE_RATE_DECAY = "IGNORE_RATE_DECAY";
    private static final String IGNORE_OWNER = "IGNORE_OWNER";
    private static final String DROP_COUNT = "DROP_COUNT";
    private static final String RACE = "RACE";
    private static final String LEVEL = "LEVEL";
    private static final String VIP_LEVEL = "VIP_LEVEL";

    /**
     * 概率分母
     */
    private static final int SINGLE_RATE_DENOMINATOR = 100_0000;

    final String name;

    private final IPlunderItem[] items;

    public final int maxDropGoodsCount;

    Plunder(ObjectParser p, int maxVipLevel, GoodsDatas goodsDatas,
            PlunderGroups groups){

        this.name = p.getKey("name");

        List<IPlunderItem> itemList = Lists.newArrayList();

        String[] goodsItems = p.getStringArray("goods_item");
        String[] goodsItemParams = p.getStringArray("goods_item_param");

        checkArgument(goodsItems.length == goodsItemParams.length,
                "掉落-%s 中item个数和item_param个数不一致", name);

        for (int i = 0; i < goodsItems.length; i++){
            String goodsItem = goodsItems[i];
            if (goodsItem == null || goodsItem.isEmpty()){
                continue;
            }

            String params = goodsItemParams[i];
            checkArgument(!params.isEmpty(), "%s 中的goods_item_param字段没有配置, %s",
                    this, goodsItem);

            itemList.add(new GoodsPlunderItem(this, maxVipLevel, goodsItem,
                    params, goodsDatas));
        }

        String[] groupItems = p.getStringArray("group_item");
        String[] groupParams = p.getStringArray("group_item_rate");

        for (int i = 0; i < groupItems.length; i++){
            String groupItem = groupItems[i];
            if (groupItem == null || groupItem.isEmpty()){
                continue;
            }

            String params = groupParams[i];
            checkArgument(!params.isEmpty(), "%s 中的group_item_rate字段没有配置, %s",
                    this, groupItem);

            itemList.add(new GroupPlunderItem(this, maxVipLevel, groupItem,
                    params, groups));
        }

        checkArgument(groupItems.length == groupParams.length,
                "掉落-%s 中groupItem个数和group_param个数不一致", name);

        String moneyStr = p.getKey("money");
        String moneyParam = p.getKey("money_param");

        try{
            if (!moneyStr.isEmpty() && !moneyParam.isEmpty()){
                itemList.add(new AmountPlunderItem(this, maxVipLevel,
                        AmountPlunderType.MONEY, moneyStr, moneyParam));
            }
        } catch (Exception e){
            System.err.println("加载银两掉落错误, name: " + name);
            throw e;
        }

        checkArgument(!itemList.isEmpty(), "%s 中一个掉落物品都没有配置", this);

        items = itemList.toArray(IPlunderItem.EMPTY_ARRAY);

        int maxDropGoodsCount = 0;
        for (IPlunderItem item : items){
            maxDropGoodsCount += ((AbstractPlunderItem) item).maxDropCount;
        }

        this.maxDropGoodsCount = maxDropGoodsCount;
    }

    private static final List<SceneGoodsHolder> EMPTY_GOODS_HOLDER_LIST = Collections
            .emptyList();

    public List<SceneGoodsHolder> getDropGoods(long ctime, boolean isRateDecay,
            int race, int heroLevel, int vipLevel){

        List<SceneGoodsHolder> goodsList = EMPTY_GOODS_HOLDER_LIST;
        for (IPlunderItem item : items){
            if (item.isValid(isRateDecay, race, heroLevel, vipLevel)){
                int dropCount = item.getDropCount();
                if (dropCount > 0){
                    if (goodsList == EMPTY_GOODS_HOLDER_LIST){
                        goodsList = Lists.newArrayListWithCapacity(dropCount);
                    }
                    item.dropGoods(ctime, goodsList, dropCount);
                }
            }
        }

        return goodsList;
    }

    public int getEmptyPosCount(int race, int heroLevel, int vipLevel){
        int emptyPosCount = 0;
        for (IPlunderItem item : items){
            if (item.isValid(race, heroLevel, vipLevel)){
                emptyPosCount += item.getEmptyPosCount();
            }
        }

        return emptyPosCount;
    }

    public void give(HeroFightModule heroFightModule, long ctime,
            OperateType type, String iEventId){

        Hero hero = heroFightModule.getHero();
        int race = hero.getRaceId();
        int heroLevel = hero.getLevel();
        int vipLevel = hero.getVipLevel();

        List<Goods> goodsList = Lists.newArrayList();
        for (IPlunderItem item : items){
            if (item.isValid(race, heroLevel, vipLevel)){
                int dropCount = item.getDropCount();
                if (dropCount > 0){
                    item.putGoodsOrGiveAmount(heroFightModule, ctime,
                            goodsList, dropCount, type, iEventId);
                }
            }
        }

        if (goodsList.isEmpty())
            return;

        heroFightModule
                .getServices()
                .getModules()
                .getGoodsModule()
                .addGoodsListToEmptyPos(hero, goodsList,
                        heroFightModule.getSender(),
                        heroFightModule.getHeroMiscModule(), type, 0, ctime);
    }

    @Override
    public String toString(){
        return "掉落-" + name;
    }

    private static interface IPlunderItem{
        IPlunderItem[] EMPTY_ARRAY = new IPlunderItem[0];

        boolean isValid(int race, int heroLevel, int vipLevel);

        boolean isValid(boolean rateDecay, int race, int heroLevel, int vipLevel);

        int getDropCount();

        void dropGoods(long ctime, List<SceneGoodsHolder> goodsList,
                int dropCount);

        /**
         * 数值型物品，直接给，物品类放入List中
         * @param heroFightModule
         * @param ctime
         */
        void putGoodsOrGiveAmount(HeroFightModule heroFightModule, long ctime,
                List<Goods> goodsList, int dropCount, OperateType optype,
                String iEventId);

        int getEmptyPosCount();
    }

    static abstract class AbstractPlunderItem implements IPlunderItem{

        // 概率，分母为100万，暂时用不上
        private final int rate;

        private transient final boolean fullRate;

        // 有主之物
        protected final boolean ignoreOwner;

        // 无视爆率衰减
        protected final boolean ignoreRateDecay;

        // 掉落个数
        protected final int minDropCount;

        protected final int maxDropCount;

        // 职业限制
        protected final int requireRace;

        // 等级限制
        protected final int minHeroLevel;

        protected final int maxHeroLevel;

        // vip等级限制
        protected final int minVipLevel;

        protected final int maxVipLevel;

        private AbstractPlunderItem(Object master, int maxHeroVipLevel,
                String params){
            String[] paramArray = params.split(";");
            checkArgument(paramArray.length > 0, "%s 没有配置概率", master);

            rate = getRate(master, paramArray[0]);
            fullRate = rate >= SINGLE_RATE_DENOMINATOR;

            Map<String, String> paramMap = Maps.newHashMap();
            for (int i = 1; i < paramArray.length; i++){
                String[] pdata = paramArray[i].split("=");
                if (pdata.length > 1){
                    paramMap.put(pdata[0], pdata[1]);
                } else{
                    paramMap.put(pdata[0], pdata[0]);
                }
            }

            ignoreOwner = paramMap.containsKey(IGNORE_OWNER);
            ignoreRateDecay = paramMap.containsKey(IGNORE_RATE_DECAY);

            // 掉落个数
            String dropCountStr = paramMap.get(DROP_COUNT);
            if (dropCountStr == null){
                minDropCount = 0;
                maxDropCount = 1;
            } else{
                int idx = dropCountStr.indexOf("-");
                if (idx < 0){
                    minDropCount = 0;
                    maxDropCount = Utils.parseInt(master, dropCountStr);
                } else{
                    minDropCount = Utils.parseInt(master,
                            dropCountStr.substring(0, idx));
                    maxDropCount = Utils.parseInt(master,
                            dropCountStr.substring(idx + 1));
                }
            }

            checkArgument(minDropCount <= maxDropCount,
                    "%s 配置的最小掉落个数比最大掉落个数还大", master);
            checkArgument(maxDropCount > 0, "%s 配置的最大掉落个数为0", master);

            // 职业限制
            String raceStr = paramMap.get(RACE);
            if (raceStr == null){
                requireRace = 0;
            } else{
                requireRace = Utils.parseInt(master, raceStr);

                checkArgument(requireRace > 0 && requireRace <= 4,
                        "%s 配置的职业限制无效[1-4]，%s", master, requireRace);
            }

            // 英雄等级限制
            String levelStr = paramMap.get(LEVEL);
            if (levelStr == null){
                minHeroLevel = 1;
                maxHeroLevel = VariableConfig.HERO_MAX_LEVEL;
            } else{
                int idx = levelStr.indexOf("-");
                if (idx < 0){
                    minHeroLevel = Utils.parseInt(master, levelStr);
                    maxHeroLevel = VariableConfig.HERO_MAX_LEVEL;
                } else{
                    minHeroLevel = Utils.parseInt(master,
                            levelStr.substring(0, idx));
                    maxHeroLevel = Utils.parseInt(master,
                            levelStr.substring(idx + 1));
                }
            }

            checkArgument(minHeroLevel <= maxHeroLevel, "%s 配置的最小等级比最大等级还大",
                    master);
            checkArgument(maxHeroLevel > 0, "%s 配置的最大等级为0", master);

            // Vip等级限制
            String vipLevelStr = paramMap.get(VIP_LEVEL);
            if (vipLevelStr == null){
                minVipLevel = 0;
                maxVipLevel = maxHeroVipLevel;
            } else{
                int idx = vipLevelStr.indexOf("-");
                if (idx < 0){
                    minVipLevel = Utils.parseInt(master, vipLevelStr);
                    maxVipLevel = maxHeroVipLevel;
                } else{
                    minVipLevel = Utils.parseInt(master,
                            vipLevelStr.substring(0, idx));
                    maxVipLevel = Utils.parseInt(master,
                            vipLevelStr.substring(idx + 1));
                }
            }

            checkArgument(minVipLevel <= maxVipLevel,
                    "%s 配置的最小Vip等级比最大Vip等级还大", master);
        }

        @Override
        public boolean isValid(int race, int heroLevel, int vipLevel){

            if (requireRace > 0 && requireRace != race)
                return false;

            if (heroLevel < minHeroLevel || heroLevel > maxHeroLevel)
                return false;

            if (vipLevel < minVipLevel || vipLevel > maxVipLevel)
                return false;

            return true;
        }

        @Override
        public boolean isValid(boolean rateDecay, int race, int heroLevel,
                int vipLevel){

            if (rateDecay && !ignoreRateDecay)
                return false;

            return isValid(race, heroLevel, vipLevel);
        }

        @Override
        public void dropGoods(long ctime, List<SceneGoodsHolder> goodsList,
                int dropCount){

            for (int i = 0; i < dropCount; i++){
                SceneGoodsHolder holder = newGoodsHolder(ctime);
                if (holder != null)
                    goodsList.add(holder);
            }
        }

        @Override
        public int getDropCount(){
            if (fullRate){
                return maxDropCount;
            } else{
                int randomCount = 0;
                for (int i = minDropCount; i < maxDropCount; i++){
                    if (tryDrop())
                        randomCount++;
                }
                return minDropCount + randomCount;
            }
        }

        private boolean tryDrop(){
            return RandomNumber.getRate(SINGLE_RATE_DENOMINATOR) < rate;
        }

        protected abstract SceneGoodsHolder newGoodsHolder(long ctime);
    }

    static class AmountPlunderItem extends AbstractPlunderItem{

        private final AmountPlunderType type;

        private final int baseAmount;

        private final int maxAmount;

        private transient final int randomAmount;

        private transient final boolean hasRandomAmount;

        private AmountPlunderItem(Object master, int maxHeroVipLevel,
                AmountPlunderType type, String goodsItem, String params){
            super(master, maxHeroVipLevel, params);
            this.type = type;

            String[] amountArray = goodsItem.split("_");
            if (amountArray.length > 1){
                baseAmount = Utils.parseInt(master, amountArray[0]);
                maxAmount = Utils.parseInt(master, amountArray[1]);
                randomAmount = maxAmount - baseAmount + 1;
            } else{
                baseAmount = maxAmount = Utils.parseInt(master, amountArray[0]);
                randomAmount = 0;
            }

            hasRandomAmount = randomAmount > 1;
        }

        protected int randomAmount(){
            if (hasRandomAmount){
                return baseAmount + RandomNumber.getRate(randomAmount, true);
            } else{
                return baseAmount;
            }
        }

        @Override
        public void putGoodsOrGiveAmount(HeroFightModule heroFightModule,
                long ctime, List<Goods> goodsList, int dropCount,
                OperateType optype, String iEventId){

            int amount = randomAmount() * dropCount;

            if (amount > 0){
                type.giveAmount(heroFightModule, amount, optype, iEventId);
            }
        }

        @Override
        protected SceneGoodsHolder newGoodsHolder(long ctime){
            return type.newGoodsHolder(this);
        }

        @Override
        public int getEmptyPosCount(){
            return 0;
        }
    }

    static enum AmountPlunderType{
        MONEY {
            @Override
            SceneGoodsHolder newGoodsHolder(AmountPlunderItem item){
                return SceneAmountGoodsHolder.newMoneyHolder(
                        item.randomAmount(), item.ignoreOwner);
            }

            @Override
            void giveAmount(HeroFightModule heroFightModule, int amount,
                    OperateType type, String iEventId){
                // 给英雄加钱
                heroFightModule.getHeroMiscModule().addMoneyAnyway(amount,
                        type, iEventId);
            }
        };

        abstract SceneGoodsHolder newGoodsHolder(AmountPlunderItem item);

        abstract void giveAmount(HeroFightModule heroFightModule, int amount,
                OperateType type, String iEventId);
    }

    static class GoodsPlunderItem extends AbstractPlunderItem{

        private final GoodsRandomer goodsRandomer;

        private transient final int emptyPosCount;

        private GoodsPlunderItem(Object master, int maxHeroVipLevel,
                String goodsItem, String params, GoodsDatas goodsDatas){
            super(master, maxHeroVipLevel, params);

            this.goodsRandomer = GoodsRandomer.newRandomer(master, goodsItem,
                    goodsDatas);

            checkArgument(goodsRandomer.getDefaultCount() == 1,
                    "%s 中GoodsRandomer的count != 1", master);

            if (goodsRandomer.hasRandomProperties()){
                emptyPosCount = maxDropCount;
            } else{
                emptyPosCount = Utils.divide(maxDropCount, goodsRandomer
                        .getData().getMaxCount());
            }
        }

        @Override
        public void putGoodsOrGiveAmount(HeroFightModule heroFightModule,
                long ctime, List<Goods> goodsList, int dropCount,
                OperateType optype, String iEventId){
            assert dropCount > 0;

            if (goodsRandomer.hasRandomProperties()){
                for (int i = 0; i < dropCount; i++){
                    goodsList.add(goodsRandomer.create(ctime));
                }
            } else{
                goodsList.add(goodsRandomer.createWithCount(ctime, dropCount));
            }
        }

        @Override
        protected SceneGoodsHolder newGoodsHolder(long ctime){
            return SceneRealGoodsHolder.newGoodsHolder(
                    goodsRandomer.create(ctime), ignoreOwner);
        }

        @Override
        public int getEmptyPosCount(){
            return emptyPosCount;
        }
    }

    static class GroupPlunderItem extends AbstractPlunderItem{

        private final PlunderGroup group;

        private GroupPlunderItem(Object master, int maxHeroVipLevel,
                String goodsItem, String params, PlunderGroups groups){
            super(master, maxHeroVipLevel, params);

            this.group = checkNotNull(groups.get(goodsItem),
                    "%s 配置的掉落组包没找到，%s", master, goodsItem);
        }

        @Override
        public void putGoodsOrGiveAmount(HeroFightModule heroFightModule,
                long ctime, List<Goods> goodsList, int dropCount,
                OperateType optype, String iEventId){

            for (int i = 0; i < dropCount; i++){
                if (group.tryDrop())
                    goodsList.add(group.random(ctime));
            }
        }

        @Override
        protected SceneGoodsHolder newGoodsHolder(long ctime){
            if (group.tryDrop()){
                return SceneRealGoodsHolder.newGoodsHolder(group.random(ctime),
                        ignoreOwner);
            }

            return null;
        }

        @Override
        public int getEmptyPosCount(){
            return maxDropCount;
        }
    }

    private static int getRate(Object master, String rateStr){
        int rate;
        int idx = rateStr.indexOf("/");
        if (idx >= 0){
            rate = Integer.parseInt(rateStr.substring(0, idx));
            int denominator = Integer.parseInt(rateStr.substring(idx + 1));

            checkArgument(denominator > 0
                    && denominator <= SINGLE_RATE_DENOMINATOR
                    && SINGLE_RATE_DENOMINATOR % denominator == 0,
                    "%s 中items分母必须要可以被一百万整除", master);

            rate = rate * (SINGLE_RATE_DENOMINATOR / denominator);
        } else{
            rate = Integer.parseInt(rateStr);
        }

        checkArgument(rate > 0 && rate <= SINGLE_RATE_DENOMINATOR,
                "%s 中配置的概率不合法，概率取值范围 (0%, 100%] rate: %s", master, rate);

        return rate;
    }
}
