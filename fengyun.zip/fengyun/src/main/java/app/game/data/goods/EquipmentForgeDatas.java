package app.game.data.goods;

import static com.mokylin.sink.util.Preconditions.*;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import app.game.data.GameObjects;
import app.game.data.goods.EquipmentForgeGroup.EquipmentForgeData;
import app.game.shop.Shops;
import app.protobuf.GoodsServerContent.Quality;
import app.protobuf.SpriteStatContent.StatType;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.inject.Inject;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class EquipmentForgeDatas{

    public static final String REFINED_LOCATION = "config/data/goods/equipment_refined_forge.txt";

//    public static final String QUALITY_LOCATION = "config/data/goods/equipment_quality_forge.txt";

    public static final String LEVEL_LOCATION = "config/data/goods/equipment_level_forge.txt";

    private final Map<String, EquipmentRefinedForgeGroup> refinedGroupMap;

//    private final Map<String, EquipmentForgeGroup> qualityGroupMap;

    private final Map<String, EquipmentForgeGroup> levelGroupMap;

    @Inject
    EquipmentForgeDatas(GameObjects go, GoodsDatas goodsDatas, Shops shops){

        // 强化
        List<ObjectParser> data = go.loadFile(REFINED_LOCATION);
        checkArgument(!data.isEmpty(), "装备强化数据没有配置");

        Map<String, List<ObjectParser>> m = Maps.newHashMap();
        int statLen = StatType.values().length;
        for (ObjectParser p : data){
            String name = p.getKey("name");
            checkArgument(!name.isEmpty(), "装备附加属性组中名字没有配置");

            List<ObjectParser> list = m.get(name);
            if (list == null){
                list = Lists.newArrayListWithCapacity(statLen);
                m.put(name, list);
            }

            list.add(p);
        }

        refinedGroupMap = Maps.newHashMapWithExpectedSize(m.size());
        for (Entry<String, List<ObjectParser>> entry : m.entrySet()){
            EquipmentRefinedForgeGroup group = new EquipmentRefinedForgeGroup(
                    entry.getKey(), entry.getValue(), goodsDatas,
                    shops.getSystemShop());

            refinedGroupMap.put(group.name, group);
        }

        int qualityLen = Quality.values().length;

//        // 提示品质，锻造值
//        data = go.loadFile(QUALITY_LOCATION);
//        checkArgument(!data.isEmpty(), "装备品质锻造数据没有配置");
//
//        m = Maps.newHashMap();
//        for (ObjectParser p : data){
//            String name = p.getKey("name");
//            checkArgument(!name.isEmpty(), "装备品质锻造数据组中名字没有配置");
//
//            List<ObjectParser> list = m.get(name);
//            if (list == null){
//                list = Lists.newArrayListWithCapacity(qualityLen);
//                m.put(name, list);
//            }
//
//            list.add(p);
//        }
//
//        qualityGroupMap = Maps.newHashMapWithExpectedSize(m.size());
//        for (Entry<String, List<ObjectParser>> entry : m.entrySet()){
//            EquipmentForgeGroup group = new EquipmentForgeGroup(entry.getKey(),
//                    entry.getValue(), goodsDatas, shops.getSystemShop());
//
//            qualityGroupMap.put(group.name, group);
//        }

        // 提升等级
        data = go.loadFile(LEVEL_LOCATION);
        checkArgument(!data.isEmpty(), "装备等级锻造数据没有配置");

        m = Maps.newHashMap();
        for (ObjectParser p : data){
            String name = p.getKey("name");
            checkArgument(!name.isEmpty(), "装备等级锻造数据组中名字没有配置");

            List<ObjectParser> list = m.get(name);
            if (list == null){
                list = Lists.newArrayListWithCapacity(qualityLen);
                m.put(name, list);
            }

            list.add(p);
        }

        levelGroupMap = Maps.newHashMapWithExpectedSize(m.size());
        for (Entry<String, List<ObjectParser>> entry : m.entrySet()){
            EquipmentForgeGroup group = new EquipmentForgeGroup(entry.getKey(),
                    entry.getValue(), goodsDatas, shops.getSystemShop());

            for (EquipmentForgeData d : group.forgeDataMap.values()){
                d.upgradeData
                        .setCustomAuctionType(GoodsData.LEVEL_FORGE_AUCTION_TYPE);
            }

            levelGroupMap.put(group.name, group);
        }

        // 初始化锻造数据
        for (EquipmentData equipment : goodsDatas.getEquipments()){
            String refinedForgeGroupName = equipment.refinedForgeGroupName;
            if (!refinedForgeGroupName.isEmpty()){
                // 能强化
                EquipmentRefinedForgeGroup group = checkNotNull(
                        refinedGroupMap.get(refinedForgeGroupName),
                        "物品%s 配置强化Group数据没找到: %s", equipment,
                        refinedForgeGroupName);

                checkArgument(
                        equipment.refinedMaxTimes == group.maxRefinedTimes,
                        "物品%s 配置强化个数与强化升级Group中的升级数据个数不一致: %s，%s: %s",
                        equipment, equipment.refinedMaxTimes, group.name,
                        group.maxRefinedTimes);

                for (RefinedData d : equipment.refinedDatas){
                    if (d.refinedTimes > 0){
                        d.init(group.upgradeDatas[d.refinedTimes - 1],
                                group.isBroadcasts[d.refinedTimes - 1]);
                    }
                }
            }

            String levelForgeGroupName = equipment.levelForgeGroupName;
            if (!levelForgeGroupName.isEmpty()){
                equipment.levelForgeGroup = checkNotNull(
                        levelGroupMap.get(levelForgeGroupName),
                        "物品%s 配置等级Group数据没找到: %s", equipment,
                        levelForgeGroupName);
            }
        }
    }

    EquipmentRefinedForgeGroup getRefinedGroup(String key){
        return refinedGroupMap.get(key);
    }

//    EquipmentForgeGroup getQualityGroup(String key){
//        return qualityGroupMap.get(key);
//    }

    EquipmentForgeGroup getLevelGroup(String key){
        return levelGroupMap.get(key);
    }
}
