package app.game.data.task;

import static app.game.module.TaskMessages.getUpdateProgressMsg;
import static app.protobuf.LogContent.LogEnum.OperateType.TASK_REDUCE_GOODS;
import static com.mokylin.sink.util.Preconditions.*;
import app.game.data.goods.GoodsData;
import app.game.data.goods.GoodsDatas;
import app.game.data.scene.CollectObjectType;
import app.game.data.scene.CollectObjectType.CollectObject;
import app.game.data.scene.CollectObjects;
import app.game.data.scene.MonsterData;
import app.game.data.scene.MonsterDatas;
import app.game.data.scene.NormalSceneData;
import app.game.data.scene.Npc;
import app.game.data.scene.Npcs;
import app.game.data.scene.SceneData;
import app.game.data.scene.SceneDatas;
import app.game.entity.Hero;
import app.game.module.GoodsContainerModule;
import app.message.ISender;
import app.protobuf.GoodsServerContent.Quality;
import app.protobuf.TaskContent.TaskTargetProto;

import com.google.protobuf.ByteString;
import com.mokylin.collection.IntArrayList;
import com.mokylin.collection.IntHashMap;
import com.mokylin.sink.util.RandomNumber;
import com.mokylin.sink.util.Utils;

/**
 * @author Liwei
 *
 */
public class TaskTarget{
    /**
     * 概率分母
     */
    private static final int SINGLE_RATE_DENOMINATOR = 1000000;

    static TaskTarget newTaskTarget(String params, Npcs npcs,
            MonsterDatas monsters, GoodsDatas goodsDatas,
            CollectObjects collectObjects, SceneDatas sceneDatas,
            IntHashMap<MonsterData> monLevelMap){

        String[] paramArray = params.split(";");

        String targetTypeName = paramArray[0];

        if (TargetType.REPLY_NPC.name().equalsIgnoreCase(targetTypeName)){
            checkArgument(
                    paramArray.length == 2 || paramArray.length == 3,
                    "回复NPC任务目标配置参数格式错误，格式'REPLY_NPC;NPC名字(npc.txt);NPC对白（可选，没有就显示任务描述）'，参数: %s",
                    params);

            String npcName = paramArray[1];

            String npcDialog = "";
            if (paramArray.length == 3)
                npcDialog = paramArray[2];

            Npc npc = checkNotNull(npcs.get(npcName),
                    "回复Npc任务中配置的Npc不存在, npc: %s", npcName);
            return newReplyNpcTarget(npc, npcDialog);
        } else if (TargetType.KILL_MONSTER.name().equalsIgnoreCase(
                targetTypeName)){
            checkArgument(
                    paramArray.length == 3,
                    "杀怪任务目标配置参数格式错误，格式'KILL_MONSTER;怪物名称（monster.txt）;个数'，参数: %s",
                    params);

            String monsterName = paramArray[1];

            MonsterData monster = checkNotNull(monsters.get(monsterName),
                    "杀怪任务中配置的怪物不存在, monster: %s", monsterName);

            int count = Integer.parseInt(paramArray[2]);
            checkArgument(count > 0, "杀怪任务目标配置的杀怪数量<=0，参数: %s", params);

            return newKillMonsterTarget(monster, count);
        } else if (TargetType.MONSTER_DROP_GOODS.name().equalsIgnoreCase(
                targetTypeName)){
            checkArgument(
                    paramArray.length == 5,
                    "杀怪收集物品任务目标配置参数格式错误，格式'MONSTER_DROP_GOODS;怪物名称（monster.txt）;个数;掉落概率;收集物品名称'，参数: %s",
                    params);

            String monsterName = paramArray[1];

            MonsterData monster = checkNotNull(monsters.get(monsterName),
                    "杀怪收集物品任务中配置的怪物不存在, monster: %s", monsterName);

            int count = Integer.parseInt(paramArray[2]);
            checkArgument(count > 0, "杀怪收集物品任务配置的收集数量<=0，参数: %s", params);

            String rateStr = paramArray[3];

            int rate;
            int idx = rateStr.indexOf("/");
            if (idx >= 0){
                rate = Integer.parseInt(rateStr.substring(0, idx));
                int denominator = Integer.parseInt(rateStr.substring(idx + 1));

                checkArgument(denominator > 0
                        && denominator <= SINGLE_RATE_DENOMINATOR
                        && SINGLE_RATE_DENOMINATOR % denominator == 0,
                        "杀怪收集物品任务配置的掉落概率分母必须要可以被一百万整除，参数: %s", params);

                rate = rate * (SINGLE_RATE_DENOMINATOR / denominator);
            } else{
                rate = Integer.parseInt(rateStr);
            }

            checkArgument(rate > 0, "杀怪收集物品任务配置的概率 <= 0?");

            String dropGoodsName = paramArray[4];

            return newMonsterDropGoodsTarget(monster, dropGoodsName, count,
                    rate);
        } else if (TargetType.COLLECT_GOODS.name().equalsIgnoreCase(
                targetTypeName)){

            checkArgument(
                    paramArray.length == 3,
                    "采集物品任务目标配置参数格式错误，格式'COLLECT_GOODS;采集物品名称（collect_object.txt）;个数'，参数: %s",
                    params);

            String name = paramArray[1];
            CollectObjectType collectType = checkNotNull(
                    collectObjects.get(name), "采集物品任务中配置的采集物品不存在，param: %s",
                    params);

            int count = Integer.parseInt(paramArray[2]);
            checkArgument(count > 0, "采集物品任务配置的收集数量<=0，参数: %s", params);

            return newCollectGoodsTarget(collectType, count);
        } else if (TargetType.UPGRADE_LEVEL.name().equalsIgnoreCase(
                targetTypeName)){
            checkArgument(paramArray.length == 2,
                    "升级任务目标配置参数格式错误，格式'UPGRADE_LEVEL;目标等级'，参数: %s", params);

            int level = Integer.parseInt(paramArray[1]);

            MonsterData monster = checkNotNull(monLevelMap.get(level),
                    "升级任务目标中没有找到当前等级的怪物， level: %s", level);

            return newUpgradeLevelTarget(level, monster);
        } else if (TargetType.DEPOT_GOODS.name().equalsIgnoreCase(
                targetTypeName)){
            checkArgument(paramArray.length == 3,
                    "收集背包物品任务目标配置参数格式错误，格式'DEPOT_GOODS;物品ID（物品表）;个数'，参数: %s",
                    params);

            int goodsId = Integer.parseInt(paramArray[1]);
            GoodsData goodsData = checkNotNull(goodsDatas.get(goodsId),
                    "收集背包物品任务配置的物品不存在, params: %s", params);

            int count = Integer.parseInt(paramArray[2]);
            checkArgument(count > 0, "收集背包物品任务配置的收集数量<=0，参数: %s", params);

            return newDepotGoodsTarget(goodsData, count);
        } else if (TargetType.ENTER_DUNGEON.name().equalsIgnoreCase(
                targetTypeName)){
            checkArgument(paramArray.length == 2,
                    "进入副本任务目标配置参数格式错误，格式'ENTER_DUNGEON;副本ID'，参数: %s", params);

            int dungeonID = Integer.parseInt(paramArray[1]);
            SceneData sceneData = checkNotNull(sceneDatas.get(dungeonID),
                    "进入副本任务配置的副本不存在, params: %s", params);

            checkArgument(!sceneData.isNormalScene(),
                    "进入副本任务配置的场景是个普通场景, params: %s", params);

            return newEnterDungeonTarget(sceneData);
        }

        throw new IllegalArgumentException("无效的任务目标，参数：" + params);
    }

    final TargetType type;

    final TaskTransport taskTransport;

    // 回复NPC任务
    Npc npc;

    String npcDialog;

    // 杀怪任务
    MonsterData killMonster;

    int killCount;

    // 杀怪收集物品任务
    MonsterData dropGoodsMonster;

    String dropGoodsName;

    int dropGoodsCount;

    int dropRate; // 掉落概率，分母100万

    // 采集物品任务
    CollectObjectType collectType;

    int collectGoodsCount;

    // 升级任务
    int upgradeLevel;

    // 升级任务推荐击杀的怪物
    MonsterData upgradeRecommendMonster;

    // 扣背包物品任务
    GoodsData depotGoods;

    int depotGoodsCount;

    // 进入副本任务
    SceneData dungeonData;

    private TaskTarget(TargetType type, TaskTransport taskTransport){
        this.type = type;
        this.taskTransport = taskTransport;

        if (type != TargetType.DEPOT_GOODS && type != TargetType.ENTER_DUNGEON){
            checkArgument(taskTransport != null, "%s 任务没有设置任务传送数据", type);
        }
    }

    private static TaskTarget newReplyNpcTarget(Npc npc, String npcDialog){
        SceneData scene = npc.getSceneData();
        checkArgument(scene instanceof NormalSceneData,
                "回复NPC任务中配置的NPC所在场景不是普通场景, %s", npc);

        IntArrayList list = new IntArrayList();
        if (scene.blockInfo != null){
            for (int x = npc.getPosX() - 2; x <= npc.getPosX() + 2; x++){
                for (int y = npc.getPosY() - 2; y <= npc.getPosY() + 2; y++){
                    if (x == npc.getPosX() && y == npc.getPosY())
                        continue;

                    if (scene.blockInfo.isWalkable(x, y))
                        list.add(Utils.short2Int(x, y));
                }
            }
        }

        if (list.isEmpty())
            list.add(Utils.short2Int(npc.getPosX(), npc.getPosY()));

        TaskTransport taskTransport = new TaskTransport(
                (NormalSceneData) scene, list.toArray());

        TaskTarget target = new TaskTarget(TargetType.REPLY_NPC, taskTransport);
        target.npc = npc;
        target.npcDialog = npcDialog;

        return target;
    }

    static TaskTarget newKillMonsterTarget(MonsterData monster, int count){
        SceneData scene = monster.getScene();
        checkArgument(scene instanceof NormalSceneData,
                "杀怪任务中配置的怪物所在场景不是普通场景, %s", monster);

        TaskTransport taskTransport = new TaskTransport(
                (NormalSceneData) scene, monster.getNavigatePoses());

        TaskTarget target = new TaskTarget(TargetType.KILL_MONSTER,
                taskTransport);
        target.killMonster = monster;
        target.killCount = count;

        return target;
    }

    static TaskTarget newMonsterDropGoodsTarget(MonsterData monster,
            String dropGoodsName, int count, int rate){
        SceneData scene = monster.getScene();
        checkArgument(scene instanceof NormalSceneData,
                "杀怪收集物品任务中配置的怪物所在场景不是普通场景, %s", monster);
        TaskTransport taskTransport = new TaskTransport(
                (NormalSceneData) scene, monster.getNavigatePoses());

        TaskTarget target = new TaskTarget(TargetType.MONSTER_DROP_GOODS,
                taskTransport);
        target.dropGoodsMonster = monster;
        target.dropGoodsName = dropGoodsName;
        target.dropGoodsCount = count;
        target.dropRate = rate;

        checkArgument(monster.getScene() != null,
                "杀怪收集物品任务中配置的要杀的怪物没有配置到场景中，monter: %s", monster);

        return target;
    }

    private static TaskTarget newCollectGoodsTarget(
            CollectObjectType collectType, int count){
        SceneData scene = collectType.getScene();
        checkArgument(scene instanceof NormalSceneData,
                "采集任务中配置的采集物品所在场景不是普通场景, %s", collectType);
        CollectObject obj = collectType.getFirstObject();
        int point = Utils.short2Int(obj.getPosX(), obj.getPosY());
        TaskTransport taskTransport = new TaskTransport(
                (NormalSceneData) scene, new int[]{point});

        TaskTarget target = new TaskTarget(TargetType.COLLECT_GOODS,
                taskTransport);
        target.collectType = collectType;
        target.collectGoodsCount = count;

        return target;
    }

    private static TaskTarget newUpgradeLevelTarget(int level,
            MonsterData monster){
        SceneData scene = monster.getScene();
        checkArgument(scene instanceof NormalSceneData,
                "升级任务中配置的怪物所在场景不是普通场景, %s", monster);
        TaskTransport taskTransport = new TaskTransport(
                (NormalSceneData) scene, monster.getNavigatePoses());

        TaskTarget target = new TaskTarget(TargetType.UPGRADE_LEVEL,
                taskTransport);
        target.upgradeLevel = level;
        target.upgradeRecommendMonster = monster;

        return target;
    }

    static TaskTarget newDepotGoodsTarget(GoodsData goodsData, int count){

        TaskTarget target = new TaskTarget(TargetType.DEPOT_GOODS, null);
        target.depotGoods = goodsData;
        target.depotGoodsCount = count;

        goodsData.taskCollectGoods();
        checkArgument(goodsData.getQuality() == Quality.WHITE,
                "任务可以扣除的背包物品，品质居然不是白色的，goods: %s", goodsData);

        return target;
    }

    static TaskTarget newEnterDungeonTarget(SceneData sceneData){

        TaskTarget target = new TaskTarget(TargetType.ENTER_DUNGEON, null);
        target.dungeonData = sceneData;

        return target;
    }

    public TargetType getType(){
        return type;
    }

    public TaskTransport getTransport(){
        return taskTransport;
    }

    public boolean isReplyNpc(){
        return type == TargetType.REPLY_NPC;
    }

    public Npc getReplyNpc(){
        return npc;
    }

    public boolean isKillMonster(){
        return type == TargetType.KILL_MONSTER;
    }

    public boolean isMonsterDropGoods(){
        return type == TargetType.MONSTER_DROP_GOODS;
    }

    public boolean isCollectGoods(){
        return type == TargetType.COLLECT_GOODS;
    }

    public boolean isUpgradeLevel(){
        return type == TargetType.UPGRADE_LEVEL;
    }

    public boolean isCollectDepotGoods(){
        return type == TargetType.DEPOT_GOODS;
    }

    public boolean isEnterDungeon(){
        return type == TargetType.ENTER_DUNGEON;
    }

    public int getUpgradeLevel(){
        return upgradeLevel;
    }

    public int getIntType(){
        return type.intType;
    }

    TaskTargetProto encode(){
        TaskTargetProto.Builder builder = TaskTargetProto.newBuilder();

        builder.setType(getIntType());

        switch (type){
            case REPLY_NPC:{
                builder.setNpcId(npc.getId());

                if (npcDialog != null){
                    builder.setNpcDialog(ByteString.copyFromUtf8(npcDialog));
                }
                break;
            }
            case KILL_MONSTER:{
                builder.setKillMonsterId(killMonster.id);
                builder.setKillMonsterCount(killCount);
                break;
            }
            case MONSTER_DROP_GOODS:{
                builder.setDropGoodsMonsterId(dropGoodsMonster.id);
                builder.setDropGoodsCount(dropGoodsCount);
                builder.setDropGoodsName(ByteString.copyFromUtf8(dropGoodsName));
                break;
            }
            case COLLECT_GOODS:{
                builder.setCollectGoodsType(collectType.getType());
                builder.setCollectGoodsCount(collectGoodsCount);
                break;
            }
            case UPGRADE_LEVEL:{
                builder.setUpgradeLevel(upgradeLevel);
                builder.setUpgradeRecommendMonster(upgradeRecommendMonster.id);
                break;
            }
            case DEPOT_GOODS:{
                builder.setDepotGoodsData(depotGoods.getProtoByteString());
                builder.setDepotGoodsCount(depotGoodsCount);
                break;
            }
            case ENTER_DUNGEON:{
                builder.setDungeon(dungeonData.id);
                break;
            }
        }

        return builder.build();
    }

    TaskTargetProgress newProgress(int taskId, int index, int progress){
        return new TaskTargetProgress(taskId, index, progress);
    }

    public class TaskTargetProgress{

        final int taskId;

        // 任务目标列表，从0开始
        final int index;

        int progress;
        boolean isCompleted;

        TaskTargetProgress(int taskId, int index, int progress){
            this.taskId = taskId;
            this.index = index;
            this.progress = progress;
            checkCompleted();
        }

        private void checkCompleted(){

            if (isKillMonster()){
                if (progress >= killCount){
                    progress = killCount;
                    isCompleted = true;
                }
                return;
            }

            if (isMonsterDropGoods()){
                if (progress >= dropGoodsCount){
                    progress = dropGoodsCount;
                    isCompleted = true;
                }
                return;
            }

            if (isCollectGoods()){
                if (progress >= collectGoodsCount){
                    progress = collectGoodsCount;
                    isCompleted = true;
                }
                return;
            }

            if (isUpgradeLevel()){
                if (progress >= upgradeLevel){
                    progress = upgradeLevel;
                    isCompleted = true;
                }
                return;
            }

            if (isCollectDepotGoods()){
                if (progress >= depotGoodsCount){
                    progress = depotGoodsCount;
                    isCompleted = true;
                }
                return;
            }

            progress = 0;
        }

        public void init(Hero hero, ISender sender,
                GoodsContainerModule goodsContainerModule){
            if (isCompleted()){
                return;
            }

            if (isUpgradeLevel()){
                progress = hero.getLevel();
                if (progress >= upgradeLevel){
                    progress = upgradeLevel;
                    isCompleted = true;
                }
                return;
            }

            if (isCollectDepotGoods()){
                if (goodsContainerModule.tryReduceGoods(hero, depotGoodsCount,
                        depotGoods, sender, TASK_REDUCE_GOODS, 0)){
                    progress = depotGoodsCount;
                    isCompleted = true;

                    sender.sendMessage(getUpdateProgressMsg(taskId, index,
                            progress));
                }
                return;
            }
        }

        public boolean isCompleted(){
            return isCompleted;
        }

        public TaskTarget getTarget(){
            return TaskTarget.this;
        }

        public boolean onKillMonster(MonsterData monster, ISender sender,
                boolean isKiller){
            if (isCompleted()){
                return false;
            }

            if (isKillMonster()){
                if (killMonster == monster){
                    if (++progress >= killCount){
                        isCompleted = true;
                    }
                    sender.sendMessage(getUpdateProgressMsg(taskId, index,
                            progress));
                    return true;
                }
                return false;
            }

            if (isKiller && isMonsterDropGoods()){
                if (dropGoodsMonster == monster){
                    if (RandomNumber.getRate(SINGLE_RATE_DENOMINATOR, true) < dropRate){
                        if (++progress >= dropGoodsCount){
                            isCompleted = true;
                        }
                        sender.sendMessage(getUpdateProgressMsg(taskId, index,
                                progress));
                    }
                    // 虽然没有掉落物品，但是这个怪已经被消费了
                    return true;
                }
                return false;
            }

            return false;
        }

        public boolean onCollectObject(CollectObjectType type, ISender sender){
            if (isCompleted()){
                return false;
            }

            if (isCollectGoods()){
                if (collectType == type){
                    if (++progress >= collectGoodsCount){
                        isCompleted = true;
                    }
                    sender.sendMessage(getUpdateProgressMsg(taskId, index,
                            progress));
                    return true;
                }
            }

            return false;
        }

        public void onHeroLevelUp(int level){
            if (isUpgradeLevel()){
                progress = level;
                if (progress >= upgradeLevel){
                    progress = upgradeLevel;
                    isCompleted = true;
                }
            }
        }

        public boolean onAddGoods(GoodsData data, Hero hero, ISender sender,
                GoodsContainerModule goodsContainerModule){
            if (isCompleted()){
                return false;
            }

            if (isCollectDepotGoods()){
                if (depotGoods == data){
                    if (goodsContainerModule.tryReduceGoods(hero,
                            depotGoodsCount, depotGoods, sender,
                            TASK_REDUCE_GOODS, 0)){
                        progress = depotGoodsCount;
                        isCompleted = true;

                        sender.sendMessage(getUpdateProgressMsg(taskId, index,
                                progress));
                        return true;
                    }
                }
            }

            return false;
        }
    }

    public static enum TargetType{
        REPLY_NPC(0), KILL_MONSTER(1), MONSTER_DROP_GOODS(2), COLLECT_GOODS(3), UPGRADE_LEVEL(
                4), DEPOT_GOODS(5), ENTER_DUNGEON(6);

        final int intType;

        TargetType(int type){
            this.intType = type;
        }
    }

    public static class TaskTransport{
        private final NormalSceneData sceneData;

        private final int[] points;

        private final int pointCount;

        private TaskTransport(NormalSceneData sceneData, int[] points){
            super();
            this.sceneData = sceneData;
            this.points = points;
            this.pointCount = points.length;

            checkArgument(pointCount > 0, "TaskTransport 一个传送位置都没有");
        }

        public NormalSceneData getData(){
            return sceneData;
        }

        public int getPoint(long heroId){
            return points[(int) (heroId % pointCount)];
        }
    }
}
