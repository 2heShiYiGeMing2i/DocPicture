package app.game.data.scene;

import static com.mokylin.sink.util.Preconditions.checkArgument;

import java.util.ArrayList;
import java.util.List;

import app.cluster.client.combat.scene.LocalSouShenDungeonScene;
import app.cluster.combat.master.logic.scene.RemoteSouShenDungeonScene;
import app.game.data.GameObjects;
import app.game.data.goods.GoodsDatas;
import app.game.data.goods.GoodsWrapper;
import app.game.entity.Hero;
import app.game.module.scene.IClusterLocalDungeonService;
import app.game.module.scene.IDungeonService;
import app.message.ISender;
import app.protobuf.ConfigContent.SouShenBossProto;
import app.protobuf.ConfigContent.SouShenDungeonProto;
import app.protobuf.LogContent.LogEnum.SceneType;

import com.google.protobuf.ByteString;
import com.mokylin.collection.IntPair;
import com.mokylin.collection.LongHashMap;
import com.mokylin.sink.util.IntWeightedRandomer;
import com.mokylin.sink.util.parse.ObjectParser;

public class SouShenDungeonSceneData extends GroupDungeonSceneData{

    private final LongHashMap<SouShenBossPrize> bossPrizeBySceneID;

    private final GoodsWrapper lifeFirstPassPrize;

    private final int dailyFirstPassSouShenPoint;

    private final GoodsWrapper[] prizeToShow;

    SouShenDungeonSceneData(GameObjects go, ObjectParser p, BlockInfos blocks,
            MonsterDatas monsters, Scripts scripts, Plunders plunders, Ais ais,
            SceneTransportDatas transports, GoodsDatas goodsDatas,
            SceneRemoveObjectMsgCache removeMsgCache){
        super(go, p, blocks, monsters, scripts, plunders, ais, transports,
                removeMsgCache);

        // 第一次通过时给的物品奖励
        this.lifeFirstPassPrize = GoodsWrapper.parse("搜神宫首通奖励", goodsDatas,
                p.getKey("first_pass_goods"));

        // 每日通过奖励的搜神值
        this.dailyFirstPassSouShenPoint = p
                .getIntKey("daily_pass_sou_shen_point");
        checkArgument(dailyFirstPassSouShenPoint > 0,
                "搜神宫 %s 每日奖励的搜神值必须>0: %s", this,
                this.dailyFirstPassSouShenPoint);

        // 加载每个boss的随机奖励
        List<ObjectParser> prizes = go
                .loadFile(GameObjects.SOU_SHEN_SCENE_BASE_FOLDER + "prize_"
                        + id + ".txt");
        SceneMonsterData[] bosses = getSingleLifeMonsterDatas();

        checkArgument(prizes.size() == bosses.length,
                "搜神宫 %s 的boss个数和boss奖励个数不符. %s个boss, %s的奖励", this,
                bosses.length, prizes.size());

        bossPrizeBySceneID = new LongHashMap<>(prizes.size());
        for (int i = 0; i < prizes.size(); i++){
            SouShenBossPrize prize = new SouShenBossPrize(prizes.get(i));

            bossPrizeBySceneID.put(bosses[i].getID(), prize);
        }

        // 神宫宝藏, 仅供显示
        String[] prizeToShowList = p.getStringArray("prize_to_show");
        this.prizeToShow = GoodsWrapper.parse("搜神宫展示奖励", goodsDatas,
                prizeToShowList);
    }

    public int getDailyFirstPassSouShenPoint(){
        return dailyFirstPassSouShenPoint;
    }

    public GoodsWrapper getLifeFirstPassGoodsWrapper(){
        return lifeFirstPassPrize;
    }

    public SouShenBossPrize getBossPrize(long bossSceneID){
        return bossPrizeBySceneID.get(bossSceneID);
    }

    public int getHasPrizeBossCount(){
        return bossPrizeBySceneID.size();
    }

    @Override
    public boolean canHeroEnterToday(Hero hero){
        return true; // 搜神宫每日进入次数无限
    }

    @Override
    public LocalSouShenDungeonScene newLocalClusterScene(int uuid,
            IClusterLocalDungeonService dungeonService, ISender combatClient,
            long heroID){
        return new LocalSouShenDungeonScene(this, uuid, dungeonService,
                combatClient, heroID);
    }

    @Override
    public RemoteSouShenDungeonScene newRemoteClusterScene(int uuid,
            IDungeonService dungeonService, long creator, ISender worker){
        return new RemoteSouShenDungeonScene(this, uuid, dungeonService,
                creator, worker);
    }

    @Override
    public int getIntType(){
        return SceneType.SOU_SHEN_DUNGEON.getNumber();
    }

    public SouShenDungeonProto generateProto(){
        SouShenDungeonProto.Builder builder = SouShenDungeonProto.newBuilder();
        builder.setSceneId(id).setMap(blockName)
                .setName(ByteString.copyFrom(nameBytes)).setSound(sound);
        if (requiredLevel > 1){
            builder.setRequiredLevel(requiredLevel);
        }
        if (isHeroLevelProtect){
            builder.setIsHeroLevelProtect(true);
        }
        if (isNewHeroProtect){
            builder.setIsNewHeroProtect(true);
        }
        if (isDeathProtect){
            builder.setIsDeathProtect(true);
        }
        if (isNightAutoProtect){
            builder.setIsNightAutoProtect(true);
        }
        if (isJumpLimit){
            builder.setIsJumpLimit(true);
        }
        if (isMountLimit){
            builder.setIsMountLimit(true);
        }

        if (poet != null){
            String tp = poet.trim();
            if (tp.length() > 0){
                builder.setPoet(ByteString.copyFromUtf8(tp));
            }
        }
        if (fixedPkMode != null){
            builder.setFixedPkMode(fixedPkMode.getIntMode());
        }

        if (reliveOutOfDungeon){
            builder.setIsDeathReturnTown(true);
        }

        builder.setMinHeroCount(minHeroCount).setMaxHeroCount(maxHeroCount)
                .setRecommendedFightAmount(recommendedFightAmount)
                .setRequiredLevel(requiredLevel);

        // boss数据
        for (SceneMonsterData bossData : getSingleLifeMonsterDatas()){
            SouShenBossPrize prize = getBossPrize(bossData.getID());
            assert prize != null;

            builder.addBossInfo(prize.encode(bossData.getMonsterData().id,
                    bossData.originX, bossData.originY, bossData.getID()));
        }

        // 神宫宝藏显示数据
        for (GoodsWrapper gw : prizeToShow){
            builder.addPrizeToShow(gw.encode4Client());
        }

        builder.setLifeFirstPassPrize(lifeFirstPassPrize.encode4Client());
        builder.setDailyFirstPassSouShenPoint(dailyFirstPassSouShenPoint);

        return builder.build();
    }

    // -----------------

    /**
     * 每一个boss的数值掉落
     * @author Timmy
     *
     */
    public static class SouShenBossPrize{
        public final AmountConfig exp;
        public final AmountConfig realAir;
        public final AmountConfig money;
        public final AmountConfig souShenPoint;

        private SouShenBossPrize(ObjectParser p){
            // 经验
            int[] amount = p.getIntKeyArray("exp_amount");
            int[] weight = p.getIntKeyArray("exp_weight");
            this.exp = new AmountConfig(amount, weight);

            // 真气
            amount = p.getIntKeyArray("real_air_amount");
            weight = p.getIntKeyArray("real_air_weight");
            this.realAir = new AmountConfig(amount, weight);

            // 银两
            amount = p.getIntKeyArray("money_amount");
            weight = p.getIntKeyArray("money_weight");
            this.money = new AmountConfig(amount, weight);

            // 搜神值
            amount = p.getIntKeyArray("sou_shen_amount");
            weight = p.getIntKeyArray("sou_shen_weight");
            this.souShenPoint = new AmountConfig(amount, weight);
        }

        public int randomExp(){
            return exp.randomer.next();
        }

        public int randomRealAir(){
            return realAir.randomer.next();
        }

        public int randomMoney(){
            return money.randomer.next();
        }

        public int randomSouShenPoint(){
            return souShenPoint.randomer.next();
        }

        private SouShenBossProto encode(int monsterID, int x, int y,
                long sceneID){
            SouShenBossProto.Builder builder = SouShenBossProto.newBuilder();
            builder.setMonsterId(monsterID).setMonsterSceneId(sceneID);

            // exp
            for (IntPair pair : exp.randomer.values()){
                builder.addExpToRandom(pair.right);
            }

            // real air
            for (IntPair pair : realAir.randomer.values()){
                builder.addRealAirToRandom(pair.right);
            }

            // money
            for (IntPair pair : money.randomer.values()){
                builder.addMoneyToRandom(pair.right);
            }

            // sou shen point
            for (IntPair pair : souShenPoint.randomer.values()){
                builder.addSouShenPointToRandom(pair.right);
            }

            return builder.build();
        }
    }

    /**
     * 每一种数值的所有可能性
     * @author Timmy
     *
     */
    public static class AmountConfig{

        private final IntWeightedRandomer randomer;

        private AmountConfig(int[] amount, int[] weight){
            checkArgument(amount.length == weight.length,
                    "搜神宫boss奖励配置错误, 数值和权重各种不同");
            checkArgument(amount.length > 0, "搜神宫boss奖励必须每个部分都配");

            List<IntPair> list = new ArrayList<>(amount.length);
            for (int i = 0; i < amount.length; i++){
                int intAmount = amount[i];
                int intWeight = weight[i];

                checkArgument(intAmount > 0, "搜神宫boss奖励的数值必须>0: %s", intAmount);
                checkArgument(intWeight > 0, "搜神宫boss奖励的权重必须>0: %s", intWeight);

                IntPair p = new IntPair(intWeight, intAmount);
                list.add(p);
            }

            this.randomer = new IntWeightedRandomer(list);
        }
    }

    @Override
    public GroupDungeonPrizeConfig getPrizeConfig(){
        // 搜神宫不是统一的完成奖励, 返回null
        return null;
    }
}
