package app.game.data.scene;

import static com.mokylin.sink.util.Preconditions.checkArgument;

import java.util.List;
import java.util.Map;

import app.game.data.GameObjects;
import app.game.data.goods.GoodsDatas;

import com.google.common.collect.Maps;
import com.google.inject.Inject;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class PlunderGroups{

    private static final String LOCATION = GameObjects.SCENE_BASE_FOLDER
            + "plunder_group.txt";

    final Map<String, PlunderGroup> groupMap;

    @Inject
    PlunderGroups(GameObjects go, GoodsDatas goodsDatas){
        groupMap = Maps.newHashMap();

        List<ObjectParser> data = go.loadFile(LOCATION);
        for (ObjectParser p : data){
            PlunderGroup g = new PlunderGroup(p, goodsDatas);

            checkArgument(groupMap.put(g.name, g) == null, "掉落组包-%s 名称重复",
                    g.name);
        }
    }

    public PlunderGroup get(String name){
        return groupMap.get(name);
    }
}
