package app.game.data.spell;

import com.mokylin.sink.util.RandomNumber;

public class SingleEffectSpellWithRate{

    public static final SingleEffectSpellWithRate[] EMPTY_ARRAY = new SingleEffectSpellWithRate[0];

    public final int rate;

    public final float lifePercent;

    public final SingleEffectSpell spell;

    public SingleEffectSpellWithRate(int rate, float lifePercent,
            SingleEffectSpell spell){
        this.rate = rate;
        this.lifePercent = lifePercent;
        this.spell = spell;
    }

    public boolean tryRelease(){
        return RandomNumber.getRate() < rate;
    }
}
