package app.game.data.scene;

import static com.mokylin.sink.util.Preconditions.*;

import java.util.List;

import app.game.data.GameObjects;
import app.protobuf.ConfigContent.NpcTransportProto;

import com.google.common.collect.Lists;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class NpcTransportList{

    public static NpcTransportList newNpcTransportList(GameObjects go,
            String name, SceneDatas sceneDatas, Npc npc){

        String location = GameObjects.TP_LIST_BASE_LOCATION + name + ".txt";

        List<ObjectParser> data = go.loadFile(location);

        checkArgument(!data.isEmpty(), "Npc-%s 传送列表中一条数据都没有", name);

        return new NpcTransportList(npc, data, sceneDatas);
    }

    private final int count;

    private final NpcTransportEntry[] entries;

    private NpcTransportList(Npc npc, List<ObjectParser> parsers,
            SceneDatas sceneDatas){

        List<NpcTransportEntry> entryList = Lists.newLinkedList();

        for (ObjectParser p : parsers){
            int destSceneID = p.getIntKey("dest_scene_id");
            int destX = p.getIntKey("dest_x");
            int destY = p.getIntKey("dest_y");
            int destRandomDistance = p.getIntKey("random_distance");

            int cost = p.getIntKey("cost");
            checkArgument(cost > 0, "NPC-%s 传送列表配置的费用无效，cost: %s", npc, cost);

            NormalSceneData destScene = checkNotNull(
                    sceneDatas.getNormal(destSceneID),
                    "没有找到NPC-%s 的传送列表的目标场景. 必须是普通场景 %s", npc, destSceneID);

            entryList.add(new NpcTransportEntry(TransportData.newTransportData(
                    destScene, destX, destY, destRandomDistance), cost));
        }

        entries = entryList.toArray(new NpcTransportEntry[0]);
        count = entries.length;
    }

    public NpcTransportEntry getEntry(int index){
        if (index >= 0 && index < count){
            return entries[index];
        }
        return null;
    }

    public static class NpcTransportEntry{

        public final TransportData transportData;

        public final int cost;

        public NpcTransportEntry(TransportData transportData, int cost){
            this.transportData = transportData;
            this.cost = cost;
        }
    }

    NpcTransportProto encode(){
        NpcTransportProto.Builder builder = NpcTransportProto.newBuilder();

        for (NpcTransportEntry entry : entries){
            builder.addScenes(entry.transportData.getDestSceneID()).addCosts(
                    entry.cost);
        }

        return builder.build();
    }
}
