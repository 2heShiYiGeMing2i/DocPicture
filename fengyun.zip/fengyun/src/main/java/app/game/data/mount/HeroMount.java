package app.game.data.mount;

import org.jboss.netty.buffer.ChannelBuffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.data.ConfigService;
import app.game.data.SpriteStat;
import app.game.data.SpriteStatBuilder;
import app.game.data.goods.Goods;
import app.game.data.goods.MountEquipment;
import app.game.data.goods.MountEquipmentData;
import app.game.data.mount.MountAddedDatas.MountAddedData;
import app.game.data.mount.MountDatas.MountLevelData;
import app.game.data.spell.PassiveSpell;
import app.game.data.spell.PassiveSpells;
import app.protobuf.HeroContent.MountProto;
import app.protobuf.HeroServerContent.MountServerProto;
import app.utils.VariableConfig;

import com.mokylin.collection.IntValueLongHashMap;

/**
 * @author Liwei
 *
 */
public class HeroMount{

    private static final Logger logger = LoggerFactory
            .getLogger(HeroMount.class);

    /**
     * 最高级的马
     */
    private MountData data;

    private int level;

    private MountAddedData bestAddedData;

    private MountLevelData levelAddedData;

    /**
     * 购买坐骑的时间
     */
    private final long buyTime;

    /**
     * 坐骑装备
     */
    private final MountEquipment[] equipmentList;

    /**
     * 进阶次数
     */
    private int upgradeTimes;

    /**
     * 祝福值
     */
    private int blessAmount;

    /**
     * 历史最高祝福值
     */
    private int blessHisMaxAmount;

    /**
     * 祝福值清空时间
     */
    private long blessAmountClearTime;

    /**
     * 是否骑在马上
     */
    private boolean isRiding;

    /**
     * 下次可以上马的时间，英雄下马的时候设置
     */
    public transient long nextCanUpToMountTime;

    /**
     * 坐骑总属性
     */
    private SpriteStat mountStat;

    /**
     * 战斗力
     */
    private int fightingAmount;

    // 最后一次进阶时间
    private int mountUpgradeTime;

    /**
     * 坐骑技能
     */
    private final PassiveSpell[] spells;

    /**
     * 是否已经过期
     */
    private transient boolean isExpired;

    HeroMount(long buyTime, MountData bestMount, int level){
        assert bestMount != null;

        this.buyTime = buyTime;
        this.data = bestMount;
        this.level = level;

        equipmentList = new MountEquipment[MountEquipmentData.MOUNT_EQUIPED_MAX_COUNT];

        levelAddedData = bestMount.getLevelData(level);

        bestAddedData = bestMount.getAddedData(level);
//        ridingAddedData = this.ridingMount.getAddedData(level);

        spells = new PassiveSpell[VariableConfig.MOUNT_SPELL_SLOT_MAX_COUNT];

        mountUpgradeTime = (int) (buyTime / 1000); // 获得时间
    }

    /**
     * 返回英雄拥有的最高级的坐骑ID
     * @return
     */
    public int getBestMountId(){
        return data.id;
    }

    public int getBestMountFightingAmount(){
        return fightingAmount;
    }

    public int getMountUpdateTime(){
        return mountUpgradeTime;
    }

    /**
     * 返回英雄拥有的最高级的坐骑
     * @return
     */
    public MountData getBestMount(){
        return data;
    }

    /**
     * 是否有效，骑着未过期的马返回true
     * @return
     */
    public boolean isValid(){
        return isRiding && !isExpired;
    }

    public boolean isRiding(){
        return isRiding;
    }

    public boolean isExpired(){
        return isExpired;
    }

    public boolean checkExpired(long ctime){
        if (data.hasExpiredTime){
            isExpired = buyTime + data.duration < ctime;
        } else{
            isExpired = false;
        }

        return isExpired;
    }

    public void upToMount(){
        isRiding = true;
    }

    public void downFromMount(){
        isRiding = false;
    }

    public ChannelBuffer getUpdateAddedDataMsg(){
        return levelAddedData.updateAddedDataMsg;
    }

    public MountAddedData getAddedData(){
        return bestAddedData;
    }

    public SpriteStat getTotalStat(){
        return mountStat;
    }

    public MountEquipment[] getEquipmentList(){
        return equipmentList;
    }

    public int getFightingAmount(){
        return fightingAmount;
    }

    /**
     * 坐骑换装
     * @return
     */
    public int getMountResource(){
        return data.id;
    }

    public void onLevelChanged(int newLevel){
        level = newLevel;

        levelAddedData = data.getLevelData(level);

        MountAddedData addedData = bestAddedData;
        bestAddedData = data.getAddedData(level);
        if (addedData != bestAddedData){
            onStatChanged();
        }
    }

    public void onUpgradeMount(long ctime){

        MountData nextLevel = data.nextLevel;
        if (nextLevel == null){
            throw new RuntimeException("满级的坐骑还掉用升级方法");
        }

        data = nextLevel;

        bestAddedData = data.getAddedData(level);
        onStatChanged();

        mountUpgradeTime = (int) (ctime / 1000);

        blessAmountClearTime = upgradeTimes = blessAmount = blessHisMaxAmount = 0;
    }

    public boolean tryClearBlessTime(long ctime){
        if (blessAmountClearTime > 0 && ctime > blessAmountClearTime){
            blessAmountClearTime = upgradeTimes = blessAmount = 0;
            return true;
        }

        return false;
    }

    public int incrementUpgradeTimes(){
        return ++upgradeTimes;
    }

    public int getBlessAmount(){
        return blessAmount;
    }

    public int getBlessHisMaxAmount(){
        return blessHisMaxAmount;
    }

    public int addBlessAmount(int toAddBless){
        blessAmount += toAddBless;

        if (blessHisMaxAmount < blessAmount){
            blessHisMaxAmount = blessAmount;
        }

        return blessAmount;
    }

    public void setClearBlessTime(long clearTime){
        blessAmountClearTime = clearTime;
    }

    public SpriteStat getDiffStat(MountData sourceMountData,
            MountData targetMountData){
        return levelAddedData.getDiffStat(sourceMountData.id,
                targetMountData.id);
    }

    public void onStatChanged(){
        SpriteStatBuilder builder = SpriteStatBuilder.newBuilder();

        builder.add(bestAddedData.baseAndAddedStat);
        int fightingAmount = bestAddedData.baseAndAddedFightingAmount;

        for (MountEquipment e : equipmentList){
            if (e != null){
                builder.add(e.getTotalStat());
                fightingAmount += e.getFightingAmount();
            }
        }

        for (PassiveSpell spell : spells){
            if (spell == null){
                continue;
            }

            fightingAmount += spell.getFightingAmount();
            if (spell.isPropertyPassiveSpell()){
                builder.add(spell.getPropertyStat());
            }
        }

        mountStat = builder.build();
        this.fightingAmount = fightingAmount;
    }

    public PassiveSpell replace(int pos, PassiveSpell spell){
        assert pos < spells.length;

        PassiveSpell toRemove = spells[pos];
        spells[pos] = spell;

        if (toRemove != spell){
            // 如果有加属性的被动技能
            if (spell.isPropertyPassiveSpell()
                    || (toRemove != null && toRemove.isPropertyPassiveSpell())){
                onStatChanged();
            } else{
                // 只改变战斗力
                int toRemoveFightingAmount = 0;
                if (toRemove != null){
                    toRemoveFightingAmount = toRemove.getFightingAmount();
                }

                if (toRemoveFightingAmount != spell.getFightingAmount()){
                    fightingAmount += spell.getFightingAmount()
                            - toRemoveFightingAmount;
                }
            }
        }

        return toRemove;
    }

    public PassiveSpell[] getSpellList(){
        return spells;
    }

    public MountProto encode4Client(){
        MountProto.Builder builder = MountProto.newBuilder();

        builder.setBestMount(data.id).setRidingMount(data.id)
                .setBuyTime(buyTime).setIsRide(isRiding);

        // 祝福值
        if (blessAmount > 0){
            builder.setBlessAmount(blessAmount);

            if (blessAmountClearTime > 0)
                builder.setBlessAmountClearTime(blessAmountClearTime);
        }

        builder.setAddedData(levelAddedData.proto);

        // 装备
        for (int i = 0; i < equipmentList.length; i++){
            MountEquipment e = equipmentList[i];
            if (e != null){
                builder.addEquipmentPos(i);
                builder.addEquipmentStaticData(e.getData().getProtoByteString());
                builder.addEquipmentDynamicData(e.encodeByteString4Client());
            }
        }

        // 技能
        for (int i = 0; i < spells.length; i++){
            PassiveSpell s = spells[i];
            if (s != null){
                builder.addSpellPos(i).addSpells(s.getProto());
            }
        }

        return builder.build();
    }

    public MountServerProto encode(){
        MountServerProto.Builder builder = MountServerProto.newBuilder();
        builder.setBestMount(data.id).setBuyTime(buyTime)
                .setMountUpgradeTime(mountUpgradeTime);

        if (isRiding){
            builder.setIsRiding(true);
        }

        if (upgradeTimes > 0)
            builder.setUpgradeTimes(upgradeTimes);

        if (blessAmount > 0){
            builder.setBlessAmount(blessAmount);

            if (blessAmountClearTime > 0)
                builder.setClearTime(blessAmountClearTime);
        }

        if (blessHisMaxAmount > 0)
            builder.setBlessHisMaxAmount(blessHisMaxAmount);

        for (PassiveSpell s : spells){
            int id = s == null ? 0 : s.id;
            builder.addSpells(id);
        }

        for (int i = 0; i < equipmentList.length; i++){
            MountEquipment equipment = equipmentList[i];
            if (equipment != null){
                builder.addEquipedPos(i).addEquipments(equipment.encode());
            }
        }

        return builder.build();
    }

    public static HeroMount decode(int level, MountServerProto proto,
            long ctime, ConfigService configService,
            IntValueLongHashMap goodsCountMap){

        long buyTime = proto.getBuyTime();
        int bestMountId = proto.getBestMount();

        MountData bestMount = configService.getMounts().get(bestMountId);
        if (bestMount.id != bestMountId){
            logger.error("坐骑DECODE时，坐骑ID不一致，best:{} decide:{}", bestMountId,
                    bestMount.id);
        }

        HeroMount mount = new HeroMount(buyTime, bestMount, level);

        mount.isRiding = proto.getIsRiding();
        mount.upgradeTimes = proto.getUpgradeTimes();
        mount.blessAmount = proto.getBlessAmount();
        mount.blessHisMaxAmount = proto.getBlessHisMaxAmount();
        mount.blessAmountClearTime = proto.getClearTime();
        mount.mountUpgradeTime = proto.getMountUpgradeTime();

        // 技能
        PassiveSpells passiveSpells = configService.getSpells()
                .getPassiveSpells();

        PassiveSpell[] spells = mount.spells;
        for (int i = 0; i < proto.getSpellsCount(); i++){

            int spellId = proto.getSpells(i);
            if (spellId <= 0){
                continue;
            }

            PassiveSpell spell = passiveSpells.get(spellId);
            if (spell == null){
                continue;
            }

            if (i < spells.length){
                spells[i] = spell;
            } else{
                // 从前找一个空位放进去
                for (int s = 0; s < spells.length; s++){
                    if (spells[s] == null){
                        spells[s] = spell;
                        break;
                    }
                }
            }
        }

        // 装备
        int count = Math.min(proto.getEquipedPosCount(),
                proto.getEquipmentsCount());
        for (int i = 0; i < count; i++){
            int pos = proto.getEquipedPos(i);
            Goods g = Goods.decode(proto.getEquipments(i), configService,
                    goodsCountMap);

            if (g == null){
                continue;
            }

            if (pos < 0 || pos >= mount.equipmentList.length
                    || !(g instanceof MountEquipment)
                    || mount.equipmentList[pos] != null){
                continue;
            }

            mount.equipmentList[pos] = (MountEquipment) g;
        }

        mount.onStatChanged();
        mount.tryClearBlessTime(ctime);

        long holdTime = bestMount.getUpgradeData().getBlessHoldTime();
        if (holdTime > 0){
            if (mount.blessAmountClearTime <= 0){
                mount.blessAmountClearTime = ctime + holdTime;
            } else{
                mount.tryClearBlessTime(ctime);
            }
        } else{
            mount.blessAmountClearTime = 0;
        }

        // 过期
        mount.checkExpired(ctime);

        return mount;
    }
}
