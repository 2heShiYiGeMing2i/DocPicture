package app.game.data.goods;

import static com.mokylin.sink.util.Preconditions.*;

import org.jboss.netty.buffer.ChannelBuffer;
import org.joda.time.DateTimeConstants;

import app.game.data.GameObjects;
import app.game.data.spell.FightState;
import app.game.data.spell.FightState.FightStateInstance;
import app.game.data.spell.FightStates;
import app.game.module.scene.HeroFightModule;
import app.game.module.scene.SceneMessages;
import app.protobuf.GoodsContent.GoodsDataProto;
import app.protobuf.GoodsServerContent.GoodsType;

import com.google.protobuf.ByteString;
import com.mokylin.sink.util.RandomNumber;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class CritCardData extends GoodsData{

    static final String LOCATION = GameObjects.GOODS_BASE_LOCATION
            + "crit_card.txt";

    public static final int MOUNT = 1;
    public static final int BOW = 2;
    public static final int TIAN_JIE = 3;
    public static final int TIAN_ZUI = 4;

    private final int cardType;

    private final long duration;

    private final int blessMinAmount;

    private final int blessMaxAmount;

    private final FightState state;

    private final GoodsDataProto proto;

    private final byte[] protoBytes;

    private final ByteString protoByteString;

    private final Efficacy efficacy;

    CritCardData(ObjectParser p, FightStates fightStates){
        super(p, GoodsType.PACKAGE);

        cardType = p.getIntKey("card_type");

        switch (cardType){
            case MOUNT:
            case BOW:
            case TIAN_JIE:
            case TIAN_ZUI:{
                break;
            }
            default:{
                System.err.println("暴击卡发现无效的card_type: " + cardType);
                throw new RuntimeException("暴击卡发现无效的card_type: " + cardType);
            }
        }

        efficacy = new CritCardEfficacy();

        duration = p.getLongKey("duration")
                * DateTimeConstants.MILLIS_PER_MINUTE;
        checkArgument(duration > 0, "%s 配置的持续时间必须大于0, duration", this);

        blessMinAmount = p.getIntKey("bless_min_amount");
        blessMaxAmount = p.getIntKey("bless_max_amount");
        checkArgument(
                0 <= blessMinAmount && blessMinAmount <= blessMaxAmount
                        && blessMaxAmount > 0,
                "%s 暴击卡持续祝福值错误, 0 <= blessMinAmount && blessMinAmount <= blessMaxAmount && blessMaxAmount > 0",
                this);

        proto = encode().build();
        protoBytes = processProtoBytes(proto.toByteArray());
        protoByteString = ByteString.copyFrom(protoBytes);

        int stateId = p.getIntKey("buff");
        state = checkNotNull(fightStates.get(stateId),
                "暴击卡-%s 的使用效果Buff不存在，stateId: %s", this, stateId);
    }

    @Override
    public byte[] getProtoBytes(){
        return protoBytes;
    }

    @Override
    public ByteString getProtoByteString(){
        return protoByteString;
    }

    @Override
    public int getAuctionType(){
        return 123;
    }

    @Override
    public Efficacy getEfficacy(){
        return efficacy;
    }

    public ChannelBuffer newBuffMsg(long heroId, long endTime){
        FightStateInstance fsi = state.newInstanceWithDisappearTime(endTime
                - duration, endTime);

        return SceneMessages.addFightStateMsg(heroId, fsi);
    }

    private class CritCardEfficacy implements Efficacy{

        @Override
        public int useTo(HeroFightModule heroFightModule, int useCount,
                long ctime, String iEventId){

            long endTime = ctime + duration;
            CritCardBuff buff = newBuff(endTime);
            heroFightModule.getHero().putCritCardBuff(buff);

            heroFightModule.sendMessage(newBuffMsg(heroFightModule.getID(),
                    endTime));

            return 1;
        }
    }

    public CritCardBuff newBuff(long endTime){
        return new CritCardBuff(endTime);
    }

    public class CritCardBuff{

        public final long endTime;

        public CritCardBuff(long endTime){
            this.endTime = endTime;
        }

        public int getId(){
            return CritCardData.this.id;
        }

        public int getType(){
            return CritCardData.this.cardType;
        }

        public ChannelBuffer newBuffMsg(long heroId){
            return CritCardData.this.newBuffMsg(heroId, endTime);
        }

        public int randomBless(long ctime){
            if (ctime < endTime){
                if (blessMaxAmount > 0 && blessMinAmount >= 0){
                    int rand = blessMaxAmount - blessMinAmount;
                    if (rand <= 0){
                        return blessMinAmount;
                    }
                    return blessMinAmount
                            + RandomNumber.getRate(rand + 1, true);
                }
            }

            return 0;
        }
    }
}
