package app.game.data;

import static com.mokylin.sink.util.Preconditions.*;
import app.game.data.goods.Equipment;
import app.protobuf.GoodsServerContent.Quality;

import com.mokylin.sink.util.RandomNumber;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class QualityRelatedData{

    public final Quality quality;

    // 装备

    public final float addedStatCoefficient;

    public final int addedStatCount;

    // 任务

    public final int autoCompleteCost;

    public final int autoCompleteLimit;

    public final int swallowMinPercent;

    public final int swallowMaxPercent;

    private final transient int swallowRandomPercent;

    QualityRelatedData(ObjectParser p, SpriteStats spriteStats){
        int intQuality = p.getIntKey("quality");
        quality = checkNotNull(Quality.valueOf(intQuality),
                "装备品质数据遇到无效数据[0白，1绿，2蓝，3紫，4橙]，%s", intQuality);

        int intCoefficient = p.getIntKey("coefficient");
        checkArgument(intCoefficient > 0, "%s 品质配置的附加属性系数必须大于0, %s", quality,
                intCoefficient);

        addedStatCoefficient = intCoefficient / 10000f;

        addedStatCount = p.getIntKey("added_stat_count");
        checkArgument(addedStatCount >= 0
                && addedStatCount <= Equipment.DEFAULT_ADDED_STAT_COUNT,
                "%s装备默认附加属性条数无效: %s，取值范围: [0, %s]", quality, addedStatCount,
                Equipment.DEFAULT_ADDED_STAT_COUNT);

        // 任务

        autoCompleteCost = p.getIntKey("auto_complete_cost");
        autoCompleteLimit = p.getIntKey("auto_complete_limit");
        swallowMinPercent = p.getIntKey("swallow_min_percent");
        swallowMaxPercent = p.getIntKey("swallow_max_percent");

        checkArgument(autoCompleteCost > 0, "%s机缘任务秒杀消耗必须大于0", quality);
        checkArgument(autoCompleteLimit >= 0, "%s机缘任务秒杀次数限制必须 >=0", quality);
        checkArgument(swallowMinPercent > 0, "%s机缘任务吞噬获得奖励最低百分比必须 > 0", quality);
        checkArgument(swallowMaxPercent > swallowMinPercent,
                "%s机缘任务吞噬获得奖励最高百分比必须 > 最低百分比", quality);
        checkArgument(swallowMaxPercent < 100, "%s机缘任务吞噬获得奖励最高百分比居然 >= 100",
                quality);

        swallowRandomPercent = swallowMaxPercent - swallowMinPercent;
    }

    public int randomSwallowPercent(){
        return swallowMinPercent + RandomNumber.getRate(swallowRandomPercent);
    }
}
