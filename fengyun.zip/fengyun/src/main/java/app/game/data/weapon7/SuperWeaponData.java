package app.game.data.weapon7;

import static com.mokylin.sink.util.Preconditions.*;

import java.util.List;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.data.ActivationCondition;
import app.game.data.GameObject;
import app.game.data.GameObjects;
import app.game.data.SingleSpriteStats;
import app.game.data.SpriteStat;
import app.game.data.SpriteStats;
import app.game.data.goods.GoodsDatas;
import app.game.data.goods.SpellBookData;
import app.game.data.goods.SpellBookData.LearnSuperWeaponSpellEfficacy;
import app.game.data.spell.PassiveSpell;
import app.game.data.spell.Spell;
import app.game.data.spell.Spells;
import app.game.entity.Hero;
import app.game.module.SuperWeaponMessages;
import app.game.module.scene.FightData;
import app.protobuf.ConfigContent.SuperWeaponDataProto;
import app.protobuf.ConfigContent.WeaponUpgradeGroup;
import app.protobuf.HeroServerContent.TriggerType;

import com.mokylin.sink.util.RandomNumber;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class SuperWeaponData extends GameObject{

    private static final String UPGRADE_DATA_LOCATION = "config/data/super_weapon/upgrade_weapon_";

//    private static final String UPGRADE_SOUL_LOCATION = "config/data/super_weapon/upgrade_soul_";

    // 技能概率分母
    private static final int SPELL_RATE_DENOMINATOR = 10000;

    private final String desc;

    // 神兵图标
    private final String icon;

    private final ActivationCondition condition;

//    private final UpgradeData upgradeData;

    // 基础属性
    final SpriteStat baseStat;

    final int fightingAmount;

    final PassiveSpell spell;

    private final ChannelBuffer spellTriggeredMsg;

    // 每一级有多少个步骤
    private final int stepPerLevel;

    private final int spellMaxLevel;

    private transient final ChannelBuffer[] upgradeDataMsgs;

    // 兵魂最大等级
    private final int weaponSoulMaxLevel;

    private final int[] antiRates;

    private final SoulUpgradeData[] upgradeDatas;

    private final SoulUpgradeData firstLevelUpgradeLevel;

    private transient final int diffLevelIndexOffset;

    private final int[] diffLevelRates;

    private transient final ChannelBuffer weaponOnMsg;

    private final String soulName;

    private final String soulDesc;

    private final String soulIcon;

    private final SpellBookData spellBook;

    SuperWeaponData(GameObjects go, ObjectParser p,
            SingleSpriteStats singleSpriteStats, SpriteStats spriteStats,
            Spells spells, GoodsDatas goodsDatas){
        super(p);

        desc = p.getKey("desc");
        condition = ActivationCondition.newCondition(this, p);
//        upgradeData = new UpgradeData(this, p, goodsDatas);
//
//        upgradeData.setCustomAuctionType(GoodsData.SUPER_WEAPON_AUCTION_TYPE);

        int baseStatId = p.getIntKey("base_stat");
        baseStat = checkNotNull(spriteStats.get(baseStatId),
                "%s 配置的基础属性找不到, %s", this, baseStatId);
        int statFightingAmount = FightData.calculateFightingAmount(baseStat);

        stepPerLevel = p.getIntKey("step_per_level");
        checkArgument(stepPerLevel > 0, "%s 配置的每级升级个数必须>0", this);

        int spellId = p.getIntKey("spell");
        spell = checkNotNull(spells.getPassiveSpells().get(spellId),
                "%s 配置的技能找不到, %s", this, spellId);

        checkArgument(spell.spellCategory == Spell.SUPER_WEAPON_SPELL_CATEGORY,
                "%s 配置的被动技能不是神兵技能类型");

        checkArgument(spell.getTriggerType() == TriggerType.ATTACK_OTHER,
                "%s 被动技能只能是击中别人触发类型，不能配置其他触发类型的被动技能，%s", this,
                spell.getTriggerType());

        spellMaxLevel = p.getIntKey("spell_max_level", 1);

        checkArgument(spellMaxLevel == spell.getTotalLevel(),
                "%s 配置的技能最大等级与技能表中的最大等级不一致", this);

        checkArgument(spell.cd > 0, "%s 没有配置触发CD，在被动技能表中配置cd字段, spell: %s",
                this, spell);

        spellTriggeredMsg = SuperWeaponMessages.getSpellTriggeredMsg(id);

        fightingAmount = statFightingAmount + spell.getFightingAmount();

        // 兵魂
        weaponSoulMaxLevel = p.getIntKey("weapon_soul_max_level");
        checkArgument(weaponSoulMaxLevel > 0, "%s 的兵魂最大等级必须>0", this);
        diffLevelIndexOffset = weaponSoulMaxLevel - 1;

        List<ObjectParser> upgradeParsers = go.loadFile(UPGRADE_DATA_LOCATION
                + id + ".txt");
        checkArgument(upgradeParsers.size() == weaponSoulMaxLevel
                * stepPerLevel,
                "%s 升级数据表的数据条数不对，需要配置(maxLevel * stepPerLevel)条数据", this);

        upgradeDatas = new SoulUpgradeData[weaponSoulMaxLevel * stepPerLevel
                + 1];
        firstLevelUpgradeLevel = upgradeDatas[0] = new SoulUpgradeData(id,
                baseStat);

        SoulUpgradeData prevLevel = firstLevelUpgradeLevel;
        for (ObjectParser parser : upgradeParsers){
            SoulUpgradeData upgradeData = new SoulUpgradeData(id, stepPerLevel,
                    weaponSoulMaxLevel, parser, singleSpriteStats, goodsDatas,
                    prevLevel);

            checkArgument(prevLevel.index + 1 == upgradeData.index); // 防御性
            checkArgument(prevLevel.nextLevel == upgradeData); // 防御性
            checkNotNull(upgradeData.totalStat); // 防御性

            checkArgument(prevLevel.realLevel <= upgradeData.realLevel,
                    "%s 的神兵等级比上一级的神兵等级还小", upgradeData);

            checkArgument(upgradeDatas[upgradeData.index] == null, "%s 存在重复数据",
                    upgradeData);

            upgradeDatas[upgradeData.index] = upgradeData;

            prevLevel = upgradeData;
        }

        checkArgument(prevLevel.nextLevel == null);

        String spellAntiRateString = p.getKey("spell_anti_rate");
        String[] spellAntiRateArray = spellAntiRateString.split(";");

        checkArgument(spellAntiRateArray.length == weaponSoulMaxLevel,
                "%s 配置的抵抗几率（显示用）个数无效，必须跟心法总阶数一致", this);

        antiRates = new int[weaponSoulMaxLevel];
        for (int i = 0; i < weaponSoulMaxLevel; i++){
            antiRates[i] = Integer.parseInt(spellAntiRateArray[i]);
        }

        upgradeDataMsgs = new ChannelBuffer[weaponSoulMaxLevel];
        for (int lv = 0; lv < weaponSoulMaxLevel; lv++){

            WeaponUpgradeGroup.Builder builder = WeaponUpgradeGroup
                    .newBuilder().setId(id).setLevel(lv)
                    .setBaseStat(upgradeDatas[lv * stepPerLevel].accStatProto);

            int startPos = lv * stepPerLevel + 1;
            for (int c = 0; c < stepPerLevel; c++){
                int pos = startPos + c;

                checkArgument(upgradeDatas[pos].page == lv);
                builder.addSingleStat(upgradeDatas[pos].singleStatProto);
            }

            upgradeDataMsgs[lv] = SuperWeaponMessages.getUpgradeDataMsg(builder
                    .build());
        }

//        List<ObjectParser> soulParsers = go.loadFile(UPGRADE_SOUL_LOCATION + id
//                + ".txt");
//        checkArgument(!soulParsers.isEmpty(), "%s 的兵魂数据没有配置", this);
//
//        checkArgument(soulParsers.size() == weaponSoulMaxLevel,
//                "%s 的兵魂升级数据表的数据条数不对，数据条数应该==兵魂最大等级", this);
//
//        weaponSoulDatas = new WeaponSoulData[soulParsers.size()];
//        for (ObjectParser soulParser : soulParsers){
//            WeaponSoulData soulData = new WeaponSoulData(id, soulParser,
//                    goodsDatas);
//
//            checkArgument(
//                    soulData.level > 0 && soulData.level <= soulParsers.size(),
//                    "%s 等级无效，必须符合 [1-maxLevel]", soulData);
//
//            checkArgument(weaponSoulDatas[soulData.level - 1] == null,
//                    "%s 数据存在重复", soulData);
//
//            weaponSoulDatas[soulData.level - 1] = soulData;
//        }
//
//        firstSoulData = weaponSoulDatas[0];
//
//        for (int i = 1; i < weaponSoulDatas.length; i++){
//            checkArgument(weaponSoulDatas[i - 1].nextLevel == null,
//                    "%s 的下一级数据已经被设置了", weaponSoulDatas[i - 1]);
//
//            weaponSoulDatas[i - 1].nextLevel = weaponSoulDatas[i]; // 设置下一级数据
//
//            checkArgument(weaponSoulDatas[i - 1].upgradeData
//                    .getUpgradeMoneyCost() <= weaponSoulDatas[i].upgradeData
//                    .getUpgradeMoneyCost(), "%s 的%s级兵魂升级银两消耗居然比前一级的小", this,
//                    i + 1);
//
//            checkArgument(weaponSoulDatas[i - 1].upgradeData
//                    .getUpgradeRealAirCost() <= weaponSoulDatas[i].upgradeData
//                    .getUpgradeRealAirCost(), "%s 的%s级兵魂升级真气消耗居然比前一级的小", this,
//                    i + 1);
//        }

        // 技能概率
        String lessDiffLevelRate = p.getKey("less_diff_level_rate");
        String[] lessDiffLevelRateArray = lessDiffLevelRate.split(";");
        checkArgument(lessDiffLevelRateArray.length == weaponSoulMaxLevel,
                "%s 配置的负等级差（含0）概率个数必须跟兵魂最大等级一致", this);

        String greaterDiffLevelRate = p.getKey("greater_diff_level_rate");
        String[] greaterDiffLevelRateArray = greaterDiffLevelRate.split(";");
        checkArgument(greaterDiffLevelRateArray.length == spellMaxLevel,
                "%s 配置的正等级差（不含0）概率个数必须跟技能最大等级一致", this);

        diffLevelRates = new int[weaponSoulMaxLevel + spellMaxLevel];
        for (int i = 0; i < diffLevelRates.length; i++){
            int rate;
            if (i < lessDiffLevelRateArray.length){
                rate = Utils.parseInt(this, lessDiffLevelRateArray[i]);
            } else{
                rate = Utils.parseInt(this, greaterDiffLevelRateArray[i
                        - lessDiffLevelRateArray.length]);
            }

            diffLevelRates[i] = rate;

            checkArgument(rate >= 0 && rate <= SPELL_RATE_DENOMINATOR,
                    "%s 第%s个概率无效[0, 10000], %s", this, i + 1, rate);

            if (i > 0){
                checkArgument(diffLevelRates[i - 1] <= diffLevelRates[i],
                        "%s 第%s个概率居然小于前一个概率", this, i + 1);
            }
        }

        weaponOnMsg = SuperWeaponMessages.superWeaponOnMsg(id);

        soulName = p.getKey("weapon_soul_name");
        soulDesc = p.getKey("weapon_soul_desc");
        soulIcon = p.getKey("weapon_soul_icon");

        icon = p.getKey("icon");
        spellBook = checkNotNull(goodsDatas.getSuperWeaponSpellBook(id),
                "神兵-%s 对应的技能书没找到", id);
        ((LearnSuperWeaponSpellEfficacy) spellBook.getEfficacy())
                .initSuperWeapon(this);

        checkArgument(id < 16 && spellMaxLevel < 16,
                "神兵排行榜中通过位移处理神兵数据，需要同时修改神兵排行榜");
    }

    public int getId(){
        return id;
    }

    public int getFightingAmount(){
        return fightingAmount;
    }

    public PassiveSpell getSpell(){
        return spell;
    }

    SoulUpgradeData getWeaponUpgradeData(int index){
        return Utils.getValidObject(upgradeDatas, index);
    }

//    WeaponSoulData getSoulData(int soulLevel){
//        if (soulLevel <= 0){
//            return null;
//        }
//        return Utils.getValidObject(weaponSoulDatas, soulLevel - 1);
//    }

    public boolean isReached(Hero hero, long ctime){
        return condition.isReachedAny(hero, ctime);
    }

//    public UpgradeData getUpgradeData(){
//        return upgradeData;
//    }

    public HeroSuperWeapon newWeapon(){
        HeroSuperWeapon weapon = new HeroSuperWeapon(this,
                firstLevelUpgradeLevel);
        return weapon;
    }

    public ChannelBuffer getWeaponOnMsg(){
        return weaponOnMsg;
    }

    public ChannelBuffer getUpgradeMsg(int level){
        if (level >= 0 && level < upgradeDataMsgs.length){
            return upgradeDataMsgs[level];
        }

        return null;
    }

    public ChannelBuffer gerSpellTriggeredMsg(){
        return spellTriggeredMsg;
    }

    public boolean tryRelease(int diffLevel){
        int rate = Utils.getValidInteger(diffLevelRates, diffLevel
                + diffLevelIndexOffset);

        switch (rate){
            case 0:{
                return false;
            }
            case SPELL_RATE_DENOMINATOR:{
                return true;
            }
            default:{
                return RandomNumber.getRate(SPELL_RATE_DENOMINATOR, true) < rate;
            }
        }
    }

    SuperWeaponDataProto encode(){
        SuperWeaponDataProto.Builder builder = SuperWeaponDataProto
                .newBuilder();

        builder.setId(id).setName(name).setDesc(desc)
                .setTotalStat(baseStat.encode()).setSpell(spell.getProto())
                .setSoulMaxLevel(weaponSoulMaxLevel)
                .setStepPerLevel(stepPerLevel)
                .setCondition(condition.encode())
//                .setUpgradeData(upgradeData.getProto())
                .setWeaponSoulName(soulName).setWeaponSoulDesc(soulDesc)
                .setWeaponSoulIcon(soulIcon).setIcon(icon)
                .setSpellBook(spellBook.getProtoByteString());

        for (int r : antiRates){
            builder.addAntiRate(r);
        }

        builder.setFightingAmount(fightingAmount);
        builder.setCd(spell.cd);

        return builder.build();
    }
}
