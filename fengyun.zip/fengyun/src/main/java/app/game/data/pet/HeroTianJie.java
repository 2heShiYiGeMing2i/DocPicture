package app.game.data.pet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.data.ConfigService;
import app.game.data.SpriteStat;
import app.game.data.SpriteStatBuilder;
import app.game.data.scene.MonsterData;
import app.game.data.spell.PassiveSpell;
import app.game.data.spell.PassiveSpells;
import app.protobuf.HeroContent.TianJieProto;
import app.protobuf.HeroServerContent.TianJieServerProto;
import app.utils.VariableConfig;

/**
 * @author Liwei
 *
 */
public class HeroTianJie{

    private static final Logger logger = LoggerFactory
            .getLogger(HeroTianJie.class);

    private TianJieData data;

    /**
     * 进阶次数
     */
    private int upgradeTimes;

    /**
     * 祝福值
     */
    private int blessAmount;

    /**
     * 历史最高祝福值
     */
    private int blessHisMaxAmount;

    /**
     * 祝福值清空时间
     */
    private long blessAmountClearTime;

    /**
     * 总属性
     */
    private SpriteStat totalStat;

    /**
     * 战斗力
     */
    private int fightingAmount;

    /**
     * 技能
     */
    private final PassiveSpell[] spells;

    /**
     * 进阶时间
     * 秒数
     */
    private int lastUpgradeTime;

    HeroTianJie(TianJieData data){

        this.data = data;
        spells = new PassiveSpell[VariableConfig.MOUNT_SPELL_SLOT_MAX_COUNT];
        fightingAmount = data.fightingAmount;
    }

    public int getId(){
        return data.id;
    }

    public TianJieData getData(){
        return data;
    }

    public MonsterData getMonster(){
        return data.getMonster();
    }

    public SpriteStat getTotalStat(){
        return totalStat;
    }

    public int getFightingAmount(){
        return fightingAmount;
    }

    // 给跨服设置数据
    public void setData(TianJieData data){
        this.data = data;
    }

    public void onUpgrade(long ctime){

        TianJieData nextLevel = data.nextLevel;
        if (nextLevel == null){
            throw new RuntimeException("满级的天劫还掉用升级方法");
        }

        data = nextLevel;
        onStatChanged();

        blessAmountClearTime = upgradeTimes = blessAmount = blessHisMaxAmount = 0;

        setUpgradeTime(ctime);
    }

    public void setUpgradeTime(long ctime){
        lastUpgradeTime = (int) (ctime / 1000);
    }

    public int getUpgradeTime(){
        return lastUpgradeTime;
    }

    public boolean tryClearBlessTime(long ctime){
        if (blessAmountClearTime > 0 && ctime > blessAmountClearTime){
            blessAmountClearTime = upgradeTimes = blessAmount = 0;
            return true;
        }

        return false;
    }

    public int incrementUpgradeTimes(){
        return ++upgradeTimes;
    }

    public int getBlessAmount(){
        return blessAmount;
    }

    public int getBlessHisMaxAmount(){
        return blessHisMaxAmount;
    }

    public int addBlessAmount(int toAddBless){
        blessAmount += toAddBless;

        if (blessHisMaxAmount < blessAmount)
            blessHisMaxAmount = blessAmount;

        return blessAmount;
    }

    public void setClearBlessTime(long clearTime){
        blessAmountClearTime = clearTime;
    }

    public void onStatChanged(){
        SpriteStatBuilder builder = SpriteStatBuilder.newBuilder();

        builder.add(data.baseStat);
        int fightingAmount = data.fightingAmount;

        for (PassiveSpell spell : spells){
            if (spell == null)
                continue;

            fightingAmount += spell.getFightingAmount();
            if (spell.isPropertyPassiveSpell()){
                builder.add(spell.getPropertyStat());
            }
        }

        totalStat = builder.build();
        this.fightingAmount = fightingAmount;
    }

    public PassiveSpell replace(int pos, PassiveSpell spell){
        assert pos < spells.length;

        PassiveSpell toRemove = spells[pos];

        if (toRemove != spell){
            spells[pos] = spell;

            // 如果有加属性的被动技能
            if (spell.isPropertyPassiveSpell()
                    || (toRemove != null && toRemove.isPropertyPassiveSpell())){
                onStatChanged();
            } else{
                // 只改变战斗力
                int toRemoveFightingAmount = 0;
                if (toRemove != null){
                    toRemoveFightingAmount = toRemove.getFightingAmount();
                }

                if (toRemoveFightingAmount != spell.getFightingAmount()){
                    fightingAmount += spell.getFightingAmount()
                            - toRemoveFightingAmount;
                }
            }
        }

        return toRemove;
    }

    public PassiveSpell[] getSpellList(){
        return spells;
    }

    public TianJieProto encode4client(){
        TianJieProto.Builder builder = TianJieProto.newBuilder();

        builder.setId(data.id);

        // 祝福值
        if (blessAmount > 0){
            builder.setBlessAmount(blessAmount);

            if (blessAmountClearTime > 0){
                builder.setBlessAmountClearTime(blessAmountClearTime);
            }
        }

        // 技能
        for (int i = 0; i < spells.length; i++){
            PassiveSpell s = spells[i];
            if (s != null){
                builder.addSpellPos(i).addSpells(s.getProto());
            }
        }

        return builder.build();
    }

    public TianJieServerProto encode(){
        TianJieServerProto.Builder builder = TianJieServerProto.newBuilder();
        builder.setId(data.id);

        if (upgradeTimes > 0)
            builder.setUpgradeTimes(upgradeTimes);

        if (blessAmount > 0){
            builder.setBlessAmount(blessAmount);

            if (blessAmountClearTime > 0)
                builder.setClearTime(blessAmountClearTime);
        }

        if (blessHisMaxAmount > 0)
            builder.setBlessHisMaxAmount(blessHisMaxAmount);

        builder.setLastUpgradeTime(lastUpgradeTime);

        for (PassiveSpell s : spells){
            int id = s == null ? 0 : s.id;
            builder.addSpells(id);
        }

        return builder.build();
    }

    public static HeroTianJie decode(TianJieServerProto proto, long ctime,
            ConfigService configService){

        TianJieData data = configService.getPet().getTianJie(proto.getId());
        if (proto.getId() != data.id){
            logger.error("坐骑DECODE时，坐骑ID不一致，data:{} decode:{}", data.id,
                    proto.getId());
        }

        HeroTianJie tianjie = new HeroTianJie(data);

        tianjie.upgradeTimes = proto.getUpgradeTimes();
        tianjie.blessAmount = proto.getBlessAmount();
        tianjie.blessHisMaxAmount = proto.getBlessHisMaxAmount();
        tianjie.blessAmountClearTime = proto.getClearTime();
        tianjie.lastUpgradeTime = proto.getLastUpgradeTime();

        // 技能
        PassiveSpells passiveSpells = configService.getSpells()
                .getPassiveSpells();

        PassiveSpell[] spells = tianjie.spells;
        for (int i = 0; i < proto.getSpellsCount(); i++){

            int spellId = proto.getSpells(i);
            if (spellId <= 0)
                continue;

            PassiveSpell spell = passiveSpells.get(spellId);
            if (spell == null)
                continue;

            if (i < spells.length){
                spells[i] = spell;
            } else{
                // 从前找一个空位放进去
                for (int s = 0; s < spells.length; s++){
                    if (spells[s] == null){
                        spells[s] = spell;
                        break;
                    }
                }
            }
        }

        tianjie.onStatChanged();

        long holdTime = data.getUpgradeData().getBlessHoldTime();
        if (holdTime > 0){
            if (tianjie.blessAmountClearTime <= 0){
                tianjie.blessAmountClearTime = ctime + holdTime;
            } else{
                tianjie.tryClearBlessTime(ctime);
            }
        } else{
            tianjie.blessAmountClearTime = 0;
        }

        return tianjie;
    }
}