package app.game.data.goods;

import static app.game.module.GoodsContainerMessages.*;
import static app.game.module.HeroMiscMessages.*;
import static app.protobuf.LogContent.LogEnum.OperateType.GOODS_USE;
import static com.mokylin.sink.util.Preconditions.*;
import app.game.data.GameObjects;
import app.game.data.HeroLevelData;
import app.game.data.SingleSpriteStat;
import app.game.data.SingleSpriteStats;
import app.game.data.spell.FightState;
import app.game.data.spell.FightState.FightStateInstance;
import app.game.data.spell.FightStates;
import app.game.entity.Hero;
import app.game.module.guild.Guild;
import app.game.module.guild.GuildMember;
import app.game.module.guild.GuildModule.ManualAddContributionResult;
import app.game.module.scene.HeroFightModule;
import app.message.ISender;
import app.protobuf.GoodsContent.MedicineDataProto;
import app.protobuf.GoodsServerContent.GoodsType;
import app.protobuf.GoodsServerContent.MedicineEfficacy;
import app.utils.VariableConfig;

import com.google.protobuf.ByteString;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.parse.ObjectParser;

public class MedicineData extends GoodsData{

    public static final String LOCATION = GameObjects.GOODS_BASE_LOCATION
            + "medicine.txt";

    private final MedicineDataProto proto;

    private final byte[] protoBytes;

    private final ByteString protoByteString;

    private final MedicineEfficacy efficacyType;

    private final Efficacy efficacy;

    private final boolean bulkUseable;

    MedicineData(ObjectParser p, FightStates fightStates,
            SingleSpriteStats spriteStats){
        super(p, GoodsType.MEDICINE);

        bulkUseable = p.getBooleanKey("bulk_useable");

        String efficacyStr = p.getKey("efficacy");
        String[] efficacyArray = efficacyStr.split(";");
        checkArgument(efficacyArray.length > 1, "物品%s-%s 配置的使用效果格式错误，类型参数: %s",
                id, name, efficacyStr);

        MedicineEfficacy effiType = null;
        for (MedicineEfficacy type : MedicineEfficacy.values()){
            if (type.name().equalsIgnoreCase(efficacyArray[0])){
                effiType = type;
                break;
            }
        }

        efficacyType = checkNotNull(effiType, "%s 配置了无效的使用效果类型, efficacy: %s",
                this, efficacyStr);

        Efficacy efficacy = null;
        switch (efficacyType){
            case LIFE:{
                checkArgument(
                        efficacyArray.length == 2,
                        "物品%s-%s 配置的Buff效果格式错误，格式：LIFE:状态ID（state.txt表中的ID）;参数: %s",
                        id, name, efficacyStr);

                BuffEfficacy buffEfficacy = new BuffEfficacy(this,
                        efficacyArray[1], fightStates);
                efficacy = buffEfficacy;

                checkArgument(buffEfficacy.state.affectsState,
                        "物品%s-%s 的使用效果居然不加血，state: %s", id, name,
                        buffEfficacy.state.name);
                break;
            }
            case BUFF:{
                checkArgument(
                        efficacyArray.length == 2,
                        "物品%s-%s 配置的Buff效果格式错误，格式：BUFF;状态ID（state.txt表中的ID）;参数: %s",
                        id, name, efficacyStr);

                efficacy = new BuffEfficacy(this, efficacyArray[1], fightStates);
                break;
            }
            case PK_AMOUNT:{
                checkArgument(efficacyArray.length == 2,
                        "物品%s-%s 配置的减少PkAmount效果格式错误，格式：PK_AMOUNT;减少的值;参数: %s",
                        id, name, efficacyStr);

                efficacy = new ReducePkAmountEfficacy(this, efficacyArray[1]);
                break;
            }
            case EXP:{
                checkArgument(efficacyArray.length == 2,
                        "物品%s-%s 配置的经验丹效果格式错误，格式：EXP;经验值   %s", id, name,
                        efficacyStr);

                efficacy = new ExpEfficacy(this, efficacyArray[1]);
                break;
            }
            case REAL_AIR:{
                checkArgument(efficacyArray.length == 2,
                        "物品%s-%s 配置的真气丹效果格式错误，格式：REAL_AIR;值   %s", id, name,
                        efficacyStr);

                efficacy = new RealAirEfficacy(this, efficacyArray[1]);
                break;
            }
            case ADD_MONEY:{
                checkArgument(efficacyArray.length == 2,
                        "物品%s-%s 配置的银两物品效果格式错误，格式：ADD_MONEY;值   %s", id, name,
                        efficacyStr);

                efficacy = new MoneyEfficacy(this, efficacyArray[1]);
                break;
            }
            case ADD_LIJIN:{
                checkArgument(efficacyArray.length == 2,
                        "物品%s-%s 配置的礼金物品效果格式错误，格式：ADD_LIJIN;值   %s", id, name,
                        efficacyStr);

                efficacy = new LijinEfficacy(this, efficacyArray[1]);
                break;
            }
            case GUILD_LILIAN:{
                checkArgument(efficacyArray.length == 2,
                        "物品%s-%s 配置的江湖历练丹效果格式错误，格式：GUILD_LILIAN;值   %s", id,
                        name, efficacyStr);

                efficacy = new GuildLilianEfficacy(this, efficacyArray[1]);
                break;
            }
            case GUILD_CONTRIBUTION:{
                checkArgument(efficacyArray.length == 2,
                        "物品%s-%s 配置的加帮贡物品效果格式错误，格式：GUILD_CONTRIBUTION;值   %s",
                        id, name, efficacyStr);

                efficacy = new GuildContributionEfficacy(this, efficacyArray[1]);
                break;
            }
            case STAMINA:{
                checkArgument(efficacyArray.length == 2,
                        "物品%s-%s 配置的加体力物品效果格式错误，格式：STAMINA;值   %s", id, name,
                        efficacyStr);

                efficacy = new StaminaEfficacy(this, efficacyArray[1]);
                break;
            }
            case JUMP_SHIELD:{
                checkArgument(efficacyArray.length == 2,
                        "物品%s-%s 配置的加跳闪值物品效果格式错误，格式：JUMP_SHIELD;值   %s", id,
                        name, efficacyStr);

                efficacy = new JumpShieldEfficacy(this, efficacyArray[1]);
                break;
            }
            case ADD_STAT:{
                checkArgument(efficacyArray.length == 3,
                        "物品%s-%s 配置的属性丹效果格式错误，格式：ADD_STAT;属性ID;限制使用个数   %s",
                        id, name, efficacyStr);

                efficacy = new StatEfficacy(this, spriteStats,
                        efficacyArray[1], efficacyArray[2]);
                break;
            }
            case ADD_LEVEL:{
                checkArgument(efficacyArray.length == 2,
                        "物品%s-%s 配置的大还丹(提升一级)效果格式错误，格式：ADD_LEVEL;限制使用个数   %s",
                        id, name, efficacyStr);

                efficacy = new UpgradeLevelEfficacy(this, efficacyArray[1]);
                break;
            }
            default:{
                throw new IllegalArgumentException(this
                        + "配置了无效的使用效果类型, efficacy: " + efficacyStr);
            }
        }
        this.efficacy = checkNotNull(efficacy,
                "物品%s-%s 的 efficacy == null，参数：%s", id, name, efficacyStr);

        proto = build();
        protoBytes = processProtoBytes(proto.toByteArray());
        protoByteString = ByteString.copyFrom(protoBytes);
    }

    @Override
    public boolean bulkUseable(){
        return bulkUseable;
    }

    private MedicineDataProto build(){
        MedicineDataProto.Builder builder = MedicineDataProto.newBuilder()
                .setBaseData(encode()).setEfficacy(efficacyType.getNumber());

        return builder.build();
    }

    public MedicineDataProto getProto(){
        return proto;
    }

    @Override
    public byte[] getProtoBytes(){
        return protoBytes;
    }

    @Override
    public ByteString getProtoByteString(){
        return protoByteString;
    }

    @Override
    public int getAuctionType(){

        switch (efficacyType){
            case BUFF:{
                return ((BuffEfficacy) efficacy).auctionType;
            }
            default:{
                return 123;
            }
        }
    }

    @Override
    public Efficacy getEfficacy(){
        return efficacy;
    }

    private static class BuffEfficacy implements Efficacy{

        private final FightState state;

        private final int auctionType;

        BuffEfficacy(MedicineData data, String param, FightStates fightStates){
            checkArgument(data.cd >= 1000 || data.gcd >= 1000,
                    "使用后获得Buff的物品，CD必须大于等于1秒，%s", data);

            state = checkNotNull(fightStates.get(Integer.parseInt(param)),
                    "物品%s-%s 的使用效果Buff不存在，stateId: %s", data.id, data.name,
                    param);

            checkArgument(state.isBuff, "物品%s-%s 的使用效果居然不是一个Buff，state: %s",
                    data.id, data.name, state.name);

            switch (state.stackType){
                case FightState.STACK_TYPE_NO_STACK_EFFECT_JUST_REFRESH_TIME:{
                    checkArgument(!data.bulkUseable(),
                            "%s 加的Buff是只刷新时间不能叠加的，但是居然配置成批量使用的了", data);
                    break;
                }
                case FightState.STACK_TYPE_NO_SUBSTITUTE:{
                    checkArgument(!data.bulkUseable(),
                            "%s 加的Buff是不能覆盖的，但是居然配置成批量使用的了", data);
                    break;
                }
            }

            auctionType = state.expMultiple > 0 ? 125
                    : (state.isAffectStat() ? 121 : 123);
        }

        @Override
        public int useTo(HeroFightModule heroFightModule, int useCount,
                long ctime, String iEventId){

            ISender sender = heroFightModule.getSender();

            // 给英雄加Buff
            FightStateInstance fsi = heroFightModule.addHeroFightState(state,
                    ctime, useCount);

            if (!state.isSingleEffective() && fsi == null){
                // logger.debug("使用物品时，Buff已满，无法再给英雄添加Buff");
                sender.sendMessage(ERR_USE_MEDICINE_FAIL_BUFF_FULL);
                return 0;
            }

            return useCount;
        }
    }

    private static class ReducePkAmountEfficacy implements Efficacy{

        private final int amount;

        ReducePkAmountEfficacy(MedicineData data, String param){
            amount = Integer.parseInt(param);
            checkArgument(amount > 0, "物品%s-%s 减少的PK值<=0， PkAmount: %s",
                    data.id, data.name, amount);

            long maxAmount = ((long) amount) * data.getMaxCount();

            checkArgument(maxAmount > 0 && maxAmount <= Integer.MAX_VALUE,
                    "物品%s-%s 的整堆减少PK值越界了", data.id, data.name);
        }

        @Override
        public int useTo(HeroFightModule heroFightModule, int useCount,
                long ctime, String iEventId){

            Hero hero = heroFightModule.getHero();
            ISender sender = heroFightModule.getSender();

            if (hero.getPkAmount() <= 0){
                logger.warn("英雄PK值<=0，但是收到了使用减少PK值物品");
                sender.sendMessage(ERR_USE_MEDICINE_FAIL_ZERO_PK_AMOUNT);
                return 0;
            }

            int maxUseCount = Utils.divide(hero.getPkAmount(), amount);

            int realUseCount = Math.min(maxUseCount, useCount);

            int newPkAmount = hero.reducePkAmount(amount * realUseCount);

            if (newPkAmount <= 0){
                hero.setNextReducePkAmountTime(0);
            }

            // 发消息
            heroFightModule
                    .selfThreadBroadcastAroundAndSelf(changePkAmountMsg(
                            hero.getID(), newPkAmount,
                            hero.getNextReducePkAmountTime()));

            return realUseCount;
        }
    }

    private static class ExpEfficacy implements Efficacy{

        private final MedicineData data;

        private final int amount;

        ExpEfficacy(MedicineData data, String param){
            this.data = data;

            amount = Integer.parseInt(param);
            checkArgument(amount > 0, "物品%s 增加的经验值必须大于0， amount: %s", data,
                    amount);

            long maxAmount = ((long) amount) * data.getMaxCount();

            checkArgument(maxAmount > 0 && maxAmount <= Integer.MAX_VALUE,
                    "物品%s 的整堆增加的经验值越界了", data);
        }

        @Override
        public int useTo(HeroFightModule heroFightModule, int useCount,
                long ctime, String iEventId){

            ISender sender = heroFightModule.getSender();

            if (heroFightModule.getHero().isMaxLevel()){
                logger.warn("英雄已经满级了，还是要经验丹?");
                sender.sendMessage(ERR_USE_EXP_MEDICINE_FAIL_LEVEL_FULL);
                return 0;
            }

            assert useCount <= data.getMaxCount();
            int toAdd = Utils.multiplyMoney(amount, useCount);

            heroFightModule.addExperience(toAdd, GOODS_USE, iEventId);

            return useCount;
        }
    }

    private static class RealAirEfficacy implements Efficacy{

        private final MedicineData data;

        private final int amount;

        RealAirEfficacy(MedicineData data, String param){
            this.data = data;

            amount = Integer.parseInt(param);
            checkArgument(amount > 0, "物品%s 增加的真气值必须大于0， amount: %s", data,
                    amount);

            long maxAmount = ((long) amount) * data.getMaxCount();

            checkArgument(maxAmount > 0
                    && maxAmount <= VariableConfig.REAL_AIR_MAX_AMOUNT,
                    "物品%s 的整堆增加的真气值越界了", data);
        }

        @Override
        public int useTo(HeroFightModule heroFightModule, int useCount,
                long ctime, String iEventId){

            assert useCount <= data.getMaxCount();
            int toAdd = amount * useCount;

            if (!heroFightModule.getHeroMiscModule().addRealAir(toAdd,
                    GOODS_USE, iEventId)){
                logger.debug("英雄真气已经满了，还使用真气丹");
                heroFightModule
                        .sendMessage(ERR_USE_MEDICINE_FAIL_REAL_AIR_FULL);
                return 0;
            }

            return useCount;
        }
    }

    private static class MoneyEfficacy implements Efficacy{

        private final MedicineData data;

        private final int amount;

        MoneyEfficacy(MedicineData data, String param){
            this.data = data;

            amount = Integer.parseInt(param);
            checkArgument(amount > 0, "物品%s 增加的银两必须大于0， amount: %s", data,
                    amount);

            long maxAmount = ((long) amount) * data.getMaxCount();

            checkArgument(maxAmount > 0
                    && maxAmount <= VariableConfig.MONEY_MAX_AMOUNT,
                    "物品%s 的整堆增加的银两越界了", data);
        }

        @Override
        public int useTo(HeroFightModule heroFightModule, int useCount,
                long ctime, String iEventId){

            assert useCount <= data.getMaxCount();
            int toAdd = amount * useCount;

            if (!heroFightModule.getHeroMiscModule().addMoney(toAdd, GOODS_USE,
                    iEventId)){
                logger.debug("英雄银两已经满了，还使用银两物品");
                heroFightModule.sendMessage(ERR_USE_MEDICINE_FAIL_MONEY_FULL);
                return 0;
            }

            return useCount;
        }
    }

    private static class LijinEfficacy implements Efficacy{

        private final MedicineData data;

        private final int amount;

        LijinEfficacy(MedicineData data, String param){
            this.data = data;

            amount = Integer.parseInt(param);
            checkArgument(amount > 0, "物品%s 增加的礼金必须大于0， amount: %s", data,
                    amount);

            long maxAmount = ((long) amount) * data.getMaxCount();

            checkArgument(maxAmount > 0
                    && maxAmount <= VariableConfig.LIJIN_MAX_AMOUNT,
                    "物品%s 的整堆增加的礼金越界了", data);
        }

        @Override
        public int useTo(HeroFightModule heroFightModule, int useCount,
                long ctime, String iEventId){

            assert useCount <= data.getMaxCount();
            int toAdd = amount * useCount;

            if (!heroFightModule.getHeroMiscModule().addLijin(toAdd, GOODS_USE,
                    iEventId)){
                logger.debug("英雄礼金已经满了，还使用礼金物品");
                heroFightModule.sendMessage(ERR_USE_MEDICINE_FAIL_LIJIN_FULL);
                return 0;
            }

            return useCount;
        }
    }

//    private static class YuanbaoEfficacy implements Efficacy{
//
//        private final MedicineData data;
//
//        private final int amount;
//
//        YuanbaoEfficacy(MedicineData data, String param){
//            this.data = data;
//
//            amount = Integer.parseInt(param);
//            checkArgument(amount > 0, "物品%s 增加的元宝必须大于0， amount: %s", data,
//                    amount);
//
//            long maxAmount = ((long) amount) * data.getMaxCount();
//
//            checkArgument(maxAmount > 0
//                    && maxAmount <= VariableConfig.LIJIN_MAX_AMOUNT,
//                    "物品%s 的整堆增加的元宝越界了", data);
//        }
//
//        @Override
//        public int useTo(HeroFightModule heroFightModule, int useCount,
//                long ctime, String iEventId){
//
//            assert useCount <= data.getMaxCount();
//            int toAdd = amount * useCount;
//
//            if (!heroFightModule.getHeroMiscModule().addYuanbao(toAdd,
//                    GOODS_USE, iEventId)){
//                logger.debug("英雄元宝已经满了，还使用元宝物品");
//                heroFightModule.sendMessage(ERR_USE_MEDICINE_FAIL_LIJIN_FULL);
//                return 0;
//            }
//
//            heroFightModule.getHero().setHasRecharged();
//            heroFightModule.getServices().getModules().getVipModule()
//                    .addVipExp(heroFightModule, toAdd);
//
//            // 加充值
//            heroFightModule.getHeroMiscModule().addRechargeYuanbao(toAdd);
//
//            return useCount;
//        }
//    }

    private static class GuildLilianEfficacy implements Efficacy{

        private final MedicineData data;

        private final int amount;

        GuildLilianEfficacy(MedicineData data, String param){
            this.data = data;

            amount = Integer.parseInt(param);
            checkArgument(amount > 0, "物品%s 增加的帮派历练必须大于0， amount: %s", data,
                    amount);

            long maxAmount = ((long) amount) * data.getMaxCount();

            checkArgument(maxAmount > 0
                    && maxAmount <= VariableConfig.JIANGHU_EXP_MAX_AMOUNT,
                    "物品%s 的整堆增加的帮派历练越界了", data);
        }

        @Override
        public int useTo(HeroFightModule heroFightModule, int useCount,
                long ctime, String iEventId){

            assert useCount <= data.getMaxCount();
            int toAdd = amount * useCount;

            if (!heroFightModule.getHeroMiscModule().addGuildLilian(toAdd,
                    GOODS_USE, iEventId)){
                logger.debug("英雄帮派历练已经满了，还使用帮派历练物品");
                heroFightModule
                        .sendMessage(ERR_USE_MEDICINE_FAIL_GUILD_LILIAN_FULL);
                return 0;
            }

            return useCount;
        }
    }

    private static class GuildContributionEfficacy implements Efficacy{

        private final MedicineData data;

        private final int amount;

        GuildContributionEfficacy(MedicineData data, String param){
            this.data = data;

            amount = Integer.parseInt(param);
            checkArgument(amount > 0, "物品%s 增加的帮派必须大于0， amount: %s", data,
                    amount);

            long maxAmount = ((long) amount) * data.getMaxCount();

            checkArgument(
                    maxAmount > 0
                            && maxAmount <= VariableConfig.GUILD_CONTRIBUTION_UPPER_LIMIT,
                    "物品%s 的整堆增加的帮派贡献越界了", data);
        }

        @Override
        public int useTo(HeroFightModule heroFightModule, int useCount,
                long ctime, String iEventId){
            assert useCount <= data.getMaxCount();
            int toAdd = amount * useCount;

            GuildMember selfMember = heroFightModule.getHero().getGuildMember();

            Guild guild = selfMember.getGuild();
            if (guild == null){
                logger.warn("英雄没有帮派，还使用增加帮贡物品");
                heroFightModule.sendMessage(ERR_USE_MEDICINE_FAIL_NOT_IN_GUILD);
                return 0;
            }

            ManualAddContributionResult result = heroFightModule.getServices()
                    .getModules().getGuildModule()
                    .tryManualAddContribution(guild, selfMember, toAdd);
            switch (result){
                case NOT_IN_GUILD:{
                    heroFightModule
                            .sendMessage(ERR_USE_MEDICINE_FAIL_NOT_IN_GUILD);
                    return 0;
                }
                case SUCCESS:{
                    break;
                }
            }

            // 帮贡改变消息
            heroFightModule.sendMessage(changeGuildContributionMsg(selfMember
                    .getContribution()));

            return useCount;
        }
    }

    private static class StaminaEfficacy implements Efficacy{

        private final int amount;

        StaminaEfficacy(MedicineData data, String param){

            checkArgument(data.cd >= 0 || data.gcd >= 0, "使用后加体力的物品，必须配置CD，%s",
                    data);

            checkArgument(!data.bulkUseable, "使用后加体力的物品，居然可以批量使用？，%s", data);

            amount = Integer.parseInt(param);
            checkArgument(amount > 0, "物品%s 增加的体力值必须大于0， amount: %s", data,
                    amount);
        }

        @Override
        public int useTo(HeroFightModule heroFightModule, int useCount,
                long ctime, String iEventId){

            heroFightModule.addStaminaAndBroadcast(amount);

            return 1;
        }
    }

    private static class JumpShieldEfficacy implements Efficacy{

        private final int amount;

        JumpShieldEfficacy(MedicineData data, String param){

            checkArgument(data.cd >= 0 || data.gcd >= 0,
                    "使用后加跳闪值的物品，必须配置CD，%s", data);

            checkArgument(!data.bulkUseable, "使用后加跳闪值的物品，居然可以批量使用？，%s", data);

            amount = Integer.parseInt(param);
            checkArgument(amount > 0, "物品%s 增加的跳闪值必须大于0， amount: %s", data,
                    amount);
        }

        @Override
        public int useTo(HeroFightModule heroFightModule, int useCount,
                long ctime, String iEventId){

            // TODO 如果在个跨服场景, 通知服务器, 让服务器改变跳闪值, 再通知本地改变

            heroFightModule.addJumpShield(amount);

            return 1;
        }
    }

    public static class StatEfficacy implements Efficacy{

        private final MedicineData data;

        private final int countLimit;

        private final SingleSpriteStat spriteStat;

        private transient final SingleSpriteStat[] cacheStats;

        StatEfficacy(MedicineData data, SingleSpriteStats stats,
                String statIdStr, String countLimitStr){
            this.data = data;

            int statId = Integer.parseInt(statIdStr);
            spriteStat = checkNotNull(stats.get(statId), "%s 中附加属性没有找到, %s",
                    data, statIdStr);

            checkArgument(spriteStat.getAmount() > 0, "%s 配置的附加属性无效， %s", data,
                    spriteStat);

            countLimit = Integer.parseInt(countLimitStr);
            checkArgument(countLimit > 0,
                    "物品%s 是增加属性的物品，使用个数限制必须大于0， countLimit: %s", data,
                    countLimit);

            long maxAmount = ((long) spriteStat.getAmount())
                    * data.getMaxCount();

            checkArgument(maxAmount > 0 && maxAmount <= Integer.MAX_VALUE,
                    "物品%s 的整堆增加的属性越界了", data);

            cacheStats = new SingleSpriteStat[countLimit + 1];
            cacheStats[0] = SingleSpriteStat.getEmptyStat(spriteStat
                    .getStatType());
            for (int i = 1; i <= countLimit; i++){
                cacheStats[i] = spriteStat.multiply(i);
            }
        }

        @Override
        public int useTo(HeroFightModule heroFightModule, int useCount,
                long ctime, String iEventId){
            assert useCount <= data.getMaxCount();

            int alreadyUsedCount = heroFightModule.getHero().getGoodsUseCount(
                    data.id);

            int realUseCount = Math
                    .min(useCount, countLimit - alreadyUsedCount);

            if (realUseCount <= 0){
                logger.debug("英雄使用加属性的物品，但是使用次数已超过最大值");
                heroFightModule.sendMessage(ERR_USE_MEDICINE_FAIL_COUNT_LIMIT);
                return 0;
            }

            // 修改数据
            int newCount = alreadyUsedCount + realUseCount;
            heroFightModule.getHero().putGoodsUseCount(data, newCount);

            // 加属性
            SingleSpriteStat toAdd = getSpriteStat(realUseCount);

            heroFightModule.changeBaseStat(true, toAdd, ctime);

            // 更新战斗力
            heroFightModule.updateFightingAmount();

            return realUseCount;
        }

        public SingleSpriteStat getSpriteStat(int count){
            return Utils.getValidObject(cacheStats, count);
        }
    }

    private static class UpgradeLevelEfficacy implements Efficacy{

        private final MedicineData data;

        private final int countLimit;

        UpgradeLevelEfficacy(MedicineData data, String countLimitStr){
            this.data = data;

            countLimit = Integer.parseInt(countLimitStr);
            checkArgument(countLimit > 0,
                    "物品%s 是增加属性的物品，使用个数限制必须大于0， countLimit: %s", data,
                    countLimit);
        }

        @Override
        public int useTo(HeroFightModule heroFightModule, int useCount,
                long ctime, String iEventId){

            Hero hero = heroFightModule.getHero();
            if (hero.isMaxLevel()){
                logger.warn("英雄已经满级了，还是要经验丹?");
                heroFightModule
                        .sendMessage(ERR_USE_LEVEL_MEDICINE_FAIL_LEVEL_FULL);
                return 0;
            }

            int alreadyUsedCount = heroFightModule.getHero().getGoodsUseCount(
                    data.id);

            int canUseCount = Math.min(useCount, countLimit - alreadyUsedCount);

            if (canUseCount <= 0){
                logger.debug("英雄使用提升等级的物品，但是使用次数已超过最大值");
                heroFightModule.sendMessage(ERR_USE_MEDICINE_FAIL_COUNT_LIMIT);
                return 0;
            }

            int realUseCount = Math.min(canUseCount,
                    VariableConfig.HERO_MAX_LEVEL - hero.getLevel());
            assert realUseCount > 0;

            int newCount = alreadyUsedCount + realUseCount;
            heroFightModule.getHero().putGoodsUseCount(data, newCount);

            HeroLevelData oldLevelData = hero.getLevelData();

            for (int i = 0; i < realUseCount; i++){
                heroFightModule
                        .getServices()
                        .getLogService()
                        .getRoleExpLogProcessor()
                        .addLogEvent(hero.getOperatorId(), iEventId,
                                hero.getServerId(), hero.getUin(),
                                hero.getUserId(), hero.getName(),
                                hero.getRaceId(), hero.getLevel(),
                                hero.getLevelData().getUpgradeExp(), 100,
                                GOODS_USE.getNumber());

                hero.onLevelUp();
            }

            heroFightModule.onLevelChanged(oldLevelData, GOODS_USE, iEventId);

            return realUseCount;
        }
    }
}
