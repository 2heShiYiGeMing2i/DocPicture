package app.game.data.weapon7;

import static com.mokylin.sink.util.Preconditions.*;

import java.util.List;

import app.game.data.GameObjects;
import app.game.data.SingleSpriteStats;
import app.game.data.SpriteStats;
import app.game.data.goods.GoodsDatas;
import app.game.data.spell.Spells;
import app.protobuf.ConfigContent.SuperWeaponConfig;
import app.utils.VariableConfig;

import com.google.inject.Inject;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class SuperWeaponDatas{

    private static final String LOCATION = "config/data/super_weapon/super_weapon.txt";

    private final SuperWeaponData[] datas;

    // VIP 专属神兵
    private final SuperWeaponData vipSuperWeapon;

    @Inject
    SuperWeaponDatas(GameObjects go, SingleSpriteStats singleSpriteStats,
            SpriteStats spriteStats, Spells spells, GoodsDatas goodsDatas,
            VariableConfig config){

        List<ObjectParser> parsers = go.loadFile(LOCATION);
        checkArgument(parsers.size() == VariableConfig.SUPER_WEAPON_COUNT,
                "神兵数据个数错误，必须配置7把神兵数据");

        datas = new SuperWeaponData[parsers.size()];
        for (ObjectParser p : parsers){
            SuperWeaponData data = new SuperWeaponData(go, p,
                    singleSpriteStats, spriteStats, spells, goodsDatas);

            checkArgument(data.id > 0 && data.id <= parsers.size(),
                    "神兵ID无效，必须从1开始连续配置");

            checkArgument(datas[data.id - 1] == null, "神兵Id存在重复, %s", data);

            datas[data.id - 1] = data;
        }

        checkArgument(config.VIP_SUPER_WEAPON_ID > 0
                && config.VIP_SUPER_WEAPON_ID <= datas.length);

        vipSuperWeapon = checkNotNull(get(config.VIP_SUPER_WEAPON_ID),
                "VIP专属神兵没找到，id-%s", config.VIP_SUPER_WEAPON_ID);
    }

    public SuperWeaponData get(int id){
        if (id > 0 && id <= datas.length){
            return datas[id - 1];
        }

        return null;
    }

    public SuperWeaponData getVipSuperWeapon(){
        return vipSuperWeapon;
    }

    public SuperWeaponConfig generateProto(){
        SuperWeaponConfig.Builder builder = SuperWeaponConfig.newBuilder();

        for (SuperWeaponData data : datas){
            builder.addWeapons(data.encode());
        }

        builder.setVipSuperWeapon(vipSuperWeapon.id);

        return builder.build();
    }
}
