package app.game.data.scene;

import static com.mokylin.sink.util.Preconditions.checkArgument;
import static com.mokylin.sink.util.Preconditions.checkNotNull;

import java.util.Collection;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.data.GameObjects;
import app.game.data.PrizeConfigs;
import app.game.data.goods.GoodsDatas;
import app.utils.VariableConfig;

import com.google.inject.Inject;
import com.mokylin.collection.IntHashMap;
import com.mokylin.sink.util.parse.ObjectParser;

public class StoryDungeonSceneDatas{

    private static final Logger logger = LoggerFactory
            .getLogger(StoryDungeonSceneDatas.class);

    public static final String LOCATION = GameObjects.SCENE_BASE_FOLDER
            + "story.txt";

    private final IntHashMap<StoryDungeonSceneData> storyDungeonMap;

    @Inject
    StoryDungeonSceneDatas(GameObjects go, BlockInfos blocks,
            MonsterDatas monsters, Scripts scripts, Plunders plunders, Ais ais,
            SceneTransportDatas transports, GoodsDatas goodsDatas,
            PlunderGroups groups, PrizeConfigs prizes,
            VariableConfig variableConfig,
            SceneRemoveObjectMsgCache removeMsgCache){

        logger.debug("loading story dungeon scenes");

        // 加载剧情副本
        List<ObjectParser> data = go.loadFile(LOCATION);

        storyDungeonMap = new IntHashMap<>(data.size());
        for (ObjectParser p : data){
            StoryDungeonSceneData scene = new StoryDungeonSceneData(go, p,
                    blocks, monsters, scripts, plunders, ais, transports,
                    goodsDatas, groups, prizes, removeMsgCache);
            storyDungeonMap.putUnique(scene.id, scene);
        }

        // 检查sequence
        StoryDungeonSceneData[] sequenceArray = new StoryDungeonSceneData[storyDungeonMap
                .size()];
        for (StoryDungeonSceneData story : storyDungeonMap.values()){
            checkArgument(story.sequence >= 1
                    && story.sequence <= sequenceArray.length,
                    "剧情副本 %s 的sequence必须是从1开始连续的: %s", story, story.sequence);

            checkArgument(sequenceArray[story.sequence - 1] == null,
                    "剧情副本的sequence冲突: %s", story.sequence);
            sequenceArray[story.sequence - 1] = story;
        }

        // 检查前置副本id是否存在
        for (StoryDungeonSceneData story : storyDungeonMap.values()){
            int prerequisite = story.prerequisite;
            if (prerequisite != 0){
                checkArgument(prerequisite != story.id, "剧情副本的前置副本id不能是自己: %s",
                        story);

                checkNotNull(storyDungeonMap.get(prerequisite),
                        "剧情副本 %s 的前置副本没找到: %s", story, prerequisite);
            }
        }
    }

    public StoryDungeonSceneData get(int sceneID){
        return storyDungeonMap.get(sceneID);
    }

    void putAll(IntHashMap<SceneData> map){
        for (StoryDungeonSceneData sceneData : storyDungeonMap.values()){
            map.putUnique(sceneData.id, sceneData);
        }
    }

    Collection<StoryDungeonSceneData> getAll(){
        return storyDungeonMap.values();
    }
}
