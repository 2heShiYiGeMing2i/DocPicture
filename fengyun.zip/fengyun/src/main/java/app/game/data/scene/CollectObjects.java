package app.game.data.scene;

import static com.mokylin.sink.util.Preconditions.checkArgument;

import java.util.List;
import java.util.Map;

import app.game.data.GameObjects;
import app.game.data.scene.CollectObjectType.CollectObject;
import app.protobuf.ConfigContent.CollectObjectConfig;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.inject.Inject;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class CollectObjects{
    public static final String LOCATION = GameObjects.SCENE_BASE_FOLDER
            + "collect_object.txt";

    private static final int START_TYPE_ID = 1;

    private final int START_ID;

    private final int END_ID;

    public final int maxUseCollectObjectId;

    private final CollectObject[] collectObjects;

    private final Map<String, CollectObjectType> collectGroupMap;

    // 作为临时变量使用，生成完Proto之后，释放掉
    private List<CollectObjectType> groups;

    @Inject
    CollectObjects(GameObjects go, SceneDatas sceneDatas){
        List<ObjectParser> data = go.loadFile(LOCATION);

        List<CollectObject> list = Lists.newLinkedList();

        collectGroupMap = Maps.newHashMapWithExpectedSize(data.size());
        groups = Lists.newLinkedList();

        int typeCounter = START_TYPE_ID;
        int maxObjectId = sceneDatas.maxUseSceneObjectID;
        for (ObjectParser p : data){
            maxObjectId++;
            CollectObjectType group = new CollectObjectType(p, typeCounter++,
                    maxObjectId, sceneDatas);

            groups.add(group);
            checkArgument(collectGroupMap.put(group.name, group) == null,
                    "采集物体- %s 名字存在重复", group.name);

            for (CollectObject obj : group.objects){
                list.add(obj);

                checkArgument(maxObjectId <= obj.id, "采集物体- %s的ID生成错误",
                        obj.getType().name);
                maxObjectId = obj.id;
            }
        }

        collectObjects = list.toArray(new CollectObject[0]);
        START_ID = sceneDatas.maxUseSceneObjectID + 1;
        maxUseCollectObjectId = sceneDatas.maxUseSceneObjectID = END_ID = START_ID
                + collectObjects.length;

        if (collectObjects.length > 0){
            checkArgument(
                    collectObjects[collectObjects.length - 1].id < END_ID,
                    "采集物体的结束ID错误");
        }
    }

    public CollectObject get(int id){
        if (id >= START_ID && id < END_ID){
            return collectObjects[id - START_ID];
        }

        return null;
    }

    public CollectObjectType get(String name){
        return collectGroupMap.get(name);
    }

    public CollectObjectConfig generateProto(){
        CollectObjectConfig.Builder builder = CollectObjectConfig.newBuilder();

        builder.setStartTypeId(START_TYPE_ID);
        for (CollectObjectType group : groups){
            builder.addCollectObjects(group.encode());
        }
        groups = null; // 用完释放掉

        return builder.build();
    }
}
