package app.game.data;

import static com.mokylin.sink.util.Preconditions.*;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.module.VipMessages;
import app.protobuf.ConfigContent.VipProto;

import com.mokylin.sink.util.parse.ObjectParser;

public class Vip{

    public final int level;

    public final int exp;

    private final String desc;

    /**
     * 补签次数
     */
    final int replenishSignTimes;

    /**
     * 是否可以领取2倍经验
     */
    final boolean canCollectOfflineExp2;

    /**
     * 是否可以领取3倍经验
     */
    final boolean canCollectOfflineExp3;

    /**
     * 剧情副本能否领取额外礼包
     */
    final boolean hasStoryExtraPrize;

    /**
     * 剧情副本扫荡是否只要一半时间
     */
    final boolean isStoryAutoFinishHalveTime;

    /**
     * 剧情副本扫荡是否立刻完成
     */
    final boolean isStoryAutoFinishZeroTime;

    /**
     * 是否能一键自动扫荡副本
     */
    final boolean canStoryAutoFinishAll;

//    /**
//     * 知天命额外次数，-1表示不限次数
//     */
//    final int divineExtraTimes;
//
//    transient final int divineMaxTimes;
//
//    /**
//     * 知天命批量次数
//     */
//    final int divineBatchTimes;

    /**
     * 地图传送
     */
    final boolean canMapTransport;

    /**
     * 任务面板传送
     */
    final boolean canTaskTransport;

    /**
     * 援助转送
     */
    final boolean canAssistTransport;

    /**
     * 孔慈每日重置次数
     */
    final int defenceResetCount;

    /**
     * vip礼包
     */
    final Prize vipPrize;

    private transient final ChannelBuffer collectVipPrizeMsg;

    /**
     * 每周礼包
     */
    final Prize weeklyPrize;

    /**
     * Vip专属神兵,true表示可以领取
     */
    final boolean canCollectVipSuperWeapon;

    // 经验倍率，分母是100
    private final int expExtraIntMultiple;

    /**
     * 经验倍率，包括打怪和挂机
     */
    final float expExtraMultiple;

    // 真气倍率，分母是100
    private final int realAirExtraIntMultiple;

    /**
     * 真气倍率，包括挂机
     */
    final float realAirExtraMultiple;

    /**
     * 机缘任务额外吞噬次数
     */
    final int chanceTaskExtraSwallowCount;

    /**
     * 机缘任务额外接受次数
     */
    final int chanceTaskExtraAcceptCount;

    /**
     * 一键完成日常任务，true表示可以
     */
    final boolean canFastCompleteDailyTask;

    /**
     * 一键完成帮派任务，true表示可以
     */
    final boolean canFastCompleteGuildTask;

    /**
     * 免费喇叭次数
     */
    final int freeChatTimes;

    // 背包开格子加速，分母100
    final int depotOpenSlotSpeed;

    // 仓库开格子加速，分母100
    final int storageOpenSlotSpeed;

    // 领取宠物，true表示可以
    final boolean canCollectPet;

    Vip(ObjectParser p, int level, PrizeConfigs prizes){
        this.level = level;
        this.exp = p.getIntKey("exp");

        checkArgument(exp > 0, "vip所需经验必须>0: %s级: %s", level, exp);

        desc = p.getKey("desc");

        // -- 补签 --
        this.replenishSignTimes = p.getIntKey("replenish_sign_times");
        checkArgument(replenishSignTimes >= 0, "vip补签次数必须>=0: %s级: %s", level,
                replenishSignTimes);

        // -- 离线经验 --
        canCollectOfflineExp2 = p.getBooleanKey("collect_offline_exp_2");
        canCollectOfflineExp3 = p.getBooleanKey("collect_offline_exp_3");

        // -- 剧情副本 --
        this.hasStoryExtraPrize = p.getBooleanKey("has_story_extra_prize");
        this.isStoryAutoFinishHalveTime = p
                .getBooleanKey("is_story_auto_finish_halve_time");
        this.isStoryAutoFinishZeroTime = p
                .getBooleanKey("is_story_auto_finish_zero_time");
        this.canStoryAutoFinishAll = p
                .getBooleanKey("can_story_auto_finish_all");

//        // -- 知天命 --
//        divineExtraTimes = p.getIntKey("divine_extra_times");
//
//        if (divineExtraTimes >= 0){
//            divineMaxTimes = divineExtraTimes
//                    + VariableConfig.DIVINE_DAILY_TIMES;
//            checkArgument(divineMaxTimes > 0, "%s 配置的知天命额外次数太大了", this);
//        } else{
//            divineMaxTimes = Integer.MAX_VALUE;
//        }
//
//        int divineBatchTimes = p.getIntKey("divine_batch_times");
//        if (divineBatchTimes <= 0)
//            divineBatchTimes = 1;
//
//        checkArgument(divineBatchTimes >= 0, "%s 的知天命批量次数必须>=0", this);
//
//        this.divineBatchTimes = divineBatchTimes;

        canMapTransport = p.getBooleanKey("can_map_transport");
        canTaskTransport = p.getBooleanKey("can_task_transport");
        canAssistTransport = p.getBooleanKey("can_assist_transport");

        // --- 孔慈 ---
        defenceResetCount = p.getIntKey("defence_reset_count", 0);
        checkArgument(defenceResetCount >= 0,
                "vip配置中defence_reset_count不能为负: %s", defenceResetCount);

        String prizeName = p.getKey("weekly_prize");

        PrizeConfig prizeConfig = checkNotNull(prizes.get(prizeName),
                "%s 配置的周礼包奖励没找到", this);

        checkArgument(!prizeConfig.hasExipreTimeGoods(),
                "%s 配置的周礼包奖励中配置了有过期时间的物品", this);
        checkArgument(!prizeConfig.isVarPrize(), "%s 配置的周礼包奖励中配置了随机属性的物品", this);
        checkArgument(!prizeConfig.hasUnbindedGoods(), "%s 配置的周礼包奖励中配置了非绑定的物品",
                this);
        checkArgument(!prizeConfig.isRaceDiff(), "%s 配置的周礼包奖励中配置了跟职业相关的物品",
                this);

        weeklyPrize = prizeConfig.random();

        prizeName = p.getKey("vip_prize");

        prizeConfig = checkNotNull(prizes.get(prizeName), "%s 配置的vip礼包奖励没找到",
                this);

        checkArgument(!prizeConfig.hasExipreTimeGoods(),
                "%s 配置的vip礼包奖励中配置了有过期时间的物品", this);
        checkArgument(!prizeConfig.isVarPrize(), "%s 配置的vip礼包奖励中配置了随机属性的物品",
                this);
        checkArgument(!prizeConfig.hasUnbindedGoods(),
                "%s 配置的vip礼包奖励中配置了非绑定的物品", this);
        checkArgument(!prizeConfig.isRaceDiff(), "%s 配置的vip礼包奖励中配置了跟职业相关的物品",
                this);

        vipPrize = prizeConfig.random();

        collectVipPrizeMsg = VipMessages.collectVipPrizeMsg(level);

        canCollectVipSuperWeapon = p
                .getBooleanKey("can_collect_vip_super_weapon");

        expExtraIntMultiple = p.getIntKey("exp_extra_multiple");
        expExtraMultiple = expExtraIntMultiple / 100f;
        checkArgument(expExtraMultiple >= 0, "%s 配置的vip经验倍率（杀怪，打坐）必须 >= 0",
                this);

        realAirExtraIntMultiple = p.getIntKey("real_air_extra_multiple");
        realAirExtraMultiple = realAirExtraIntMultiple / 100f;
        checkArgument(realAirExtraMultiple >= 0, "%s 配置的vip真气倍率（打坐）必须 >= 0",
                this);

        // -- 机缘任务 --
        chanceTaskExtraSwallowCount = p
                .getIntKey("chance_task_extra_swallow_count");
        checkArgument(chanceTaskExtraSwallowCount >= 0, "%s 的机缘任务吞噬额外次数必须>=0",
                this);

        chanceTaskExtraAcceptCount = p
                .getIntKey("chance_task_extra_accept_count");
        checkArgument(chanceTaskExtraAcceptCount >= 0, "%s 的机缘任务接受额外次数必须>=0",
                this);

        canFastCompleteDailyTask = p
                .getBooleanKey("can_fast_complete_daily_task");

        canFastCompleteGuildTask = p
                .getBooleanKey("can_fast_complete_guild_task");

        freeChatTimes = p.getIntKey("free_chat_times");
        checkArgument(freeChatTimes >= 0, "%s 配置的免费喇叭次数必须 >= 0", this);

        depotOpenSlotSpeed = p.getIntKey("depot_open_slot_speed");
        checkArgument(depotOpenSlotSpeed >= 0, "%s 配置的背包开格子加速必须 >= 0", this);

        storageOpenSlotSpeed = p.getIntKey("storage_open_slot_speed");
        checkArgument(storageOpenSlotSpeed >= 0, "%s 配置的仓库开格子加速必须 >= 0", this);

        canCollectPet = p.getBooleanKey("can_collect_pet");
    }

    public int getDefenceResetCount(){
        return defenceResetCount;
    }

    public boolean canStoryAutoFinishAll(){
        return canStoryAutoFinishAll;
    }

    public boolean isStoryAutoFinishHalveTime(){
        return isStoryAutoFinishHalveTime;
    }

    public boolean isStoryAutoFinishZeroTime(){
        return isStoryAutoFinishZeroTime;
    }

    public boolean hasStoryExtraPrize(){
        return hasStoryExtraPrize;
    }

    public int getReplenishSignTimes(){
        return replenishSignTimes;
    }

    public int getChanceTaskExtraSwallowCount(){
        return chanceTaskExtraSwallowCount;
    }

    public int getChanceTaskExtraAcceptCount(){
        return chanceTaskExtraAcceptCount;
    }

    public boolean canCollectOfflineExp2(){
        return canCollectOfflineExp2;
    }

    public boolean canCollectOfflineExp3(){
        return canCollectOfflineExp3;
    }

//    public int getDivineMaxTimes(){
//        return divineMaxTimes;
//    }
//
//    public int getDivineBatchTimes(){
//        return divineBatchTimes;
//    }

    public boolean canMapTransport(){
        return canMapTransport;
    }

    public boolean canTaskTransport(){
        return canTaskTransport;
    }

    public boolean canAssistTransport(){
        return canAssistTransport;
    }

    public Prize getWeeklyPrize(){
        return weeklyPrize;
    }

    public Prize getVipPrize(){
        return vipPrize;
    }

    public ChannelBuffer getCollectVipPrizeMsg(){
        return collectVipPrizeMsg;
    }

    public boolean canCollectVipSuperWeapon(){
        return canCollectVipSuperWeapon;
    }

    public float getExpMultiple(){
        return expExtraMultiple;
    }

    public float getRealAirMultiple(){
        return realAirExtraMultiple;
    }

    public boolean canFastCompleteDailyTask(){
        return canFastCompleteDailyTask;
    }

    public boolean canFastCompleteGuildTask(){
        return canFastCompleteGuildTask;
    }

    public int getFreeChatTimes(){
        return freeChatTimes;
    }

    public int getDepotOpenSlotSpeed(){
        return depotOpenSlotSpeed;
    }

    public int getStorageOpenSlotSpeed(){
        return storageOpenSlotSpeed;
    }

    public boolean canCollectPet(){
        return canCollectPet;
    }

    public VipProto encode(){
        VipProto.Builder builder = VipProto.newBuilder();

        builder.setExp(exp).setDesc(desc);
        builder.setReplenishSignTimes(replenishSignTimes);

        if (canCollectOfflineExp2){
            builder.setCanCollectOfflineExp2(true);
        }

        if (canCollectOfflineExp3){
            builder.setCanCollectOfflineExp3(true);
        }

        // -- 剧情副本 --
        if (hasStoryExtraPrize){
            builder.setHasStoryExtraPrize(true);
        }
        if (isStoryAutoFinishHalveTime){
            builder.setIsStoryAutoFinishHalveTime(true);
        }
        if (isStoryAutoFinishZeroTime){
            builder.setIsStoryAutoFinishZeroTime(true);
        }
        if (canStoryAutoFinishAll){
            builder.setCanStoryAutoFinishAll(true);
        }

        if (chanceTaskExtraSwallowCount > 0){
            builder.setChanceTaskExtraSwallowCount(chanceTaskExtraSwallowCount);
        }

//        if (divineExtraTimes < 0){
////            builder.setDivineExtraTimes(0);
//        } else{
//            builder.setDivineExtraTimes(divineExtraTimes + 1);
//        }
//
//        if (divineBatchTimes > 1){
//            builder.setDivineBatchTimes(divineBatchTimes);
//        }

        if (canMapTransport){
            builder.setCanMapTransport(true);
        }

        if (canTaskTransport){
            builder.setCanTaskTransport(true);
        }

        if (canAssistTransport){
            builder.setCanAssistTransport(true);
        }

        if (defenceResetCount > 0){
            builder.setDefenceResetCount(defenceResetCount);
        }

        builder.setVipPrize(vipPrize.encode4Client());
        builder.setWeeklyPrize(weeklyPrize.encode4Client());

        if (canCollectVipSuperWeapon){
            builder.setCanCollectVipSuperWeapon(true);
        }

        if (expExtraIntMultiple > 0){
            builder.setExpMultiple(expExtraIntMultiple);
        }

        if (realAirExtraIntMultiple > 0){
            builder.setRealAirMultiple(realAirExtraIntMultiple);
        }

        if (canFastCompleteDailyTask){
            builder.setCanFastCompleteDailyTask(true);
        }

        if (canFastCompleteGuildTask){
            builder.setCanFastCompleteGuildTask(true);
        }

        if (freeChatTimes > 0){
            builder.setFreeChatTimes(freeChatTimes);
        }

        if (depotOpenSlotSpeed > 0){
            builder.setDepotOpenSlotSpeed(depotOpenSlotSpeed);
        }

        if (storageOpenSlotSpeed > 0){
            builder.setStorageOpenSlotSpeed(storageOpenSlotSpeed);
        }

        if (chanceTaskExtraAcceptCount > 0){
            builder.setChanceTaskExtraAcceptCount(chanceTaskExtraAcceptCount);
        }

        if (canCollectPet){
            builder.setCanCollectPet(true);
        }

        return builder.build();
    }

    @Override
    public String toString(){
        return "VIP-" + level;
    }
}
