package app.game.data.goods;

import static com.mokylin.sink.util.Preconditions.*;

public class GoodsDataWithCount{

    public final int goodsID;

    public final GoodsData goodsData;

    public final int count;

    public GoodsDataWithCount(GoodsData goodsData, int count){
        this.goodsData = goodsData;
        this.count = count;
        this.goodsID = goodsData.id;
    }

    public static GoodsDataWithCount parse(GoodsDatas goodsDatas, String input,
            String separator){
        if (input == null || (input = input.trim()).length() == 0){
            return null;
        }

        String[] arg = input.split(separator);
        checkArgument(arg.length == 2, "配置物品和数量时格式错误, 应该是 物品id%s数量: %s",
                separator, input);

        final int goodsID;
        final int count;
        try{
            goodsID = Integer.parseInt(arg[0]);
            count = Integer.parseInt(arg[1]);
        } catch (Throwable ex){
            throw new RuntimeException("配置物品和数量时格式错误, 应该是 物品id" + separator
                    + "数量: " + input);
        }
        GoodsData goodsData = checkNotNull(goodsDatas.get(goodsID),
                "没有找到需要的物品: %s", input);
        checkArgument(count > 0, "物品所需的个数必须>0: %s", count);
        return new GoodsDataWithCount(goodsData, count);
    }
}
