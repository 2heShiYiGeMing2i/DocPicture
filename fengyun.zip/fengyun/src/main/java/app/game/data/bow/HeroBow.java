package app.game.data.bow;

import app.game.data.ConfigService;
import app.game.data.SpriteStat;
import app.game.data.spell.PassiveSpell;
import app.protobuf.HeroContent.BowProto;
import app.protobuf.HeroServerContent.BowServerProto;

/**
 * @author Liwei
 *
 */
public class HeroBow{

    /**
     * 凤舞弓数据
     */
    private BowData bowData;

    /**
     * 当前装备的凤舞弓造型
     */
    private int resource;

    /**
     * 进阶次数
     */
    private int bowUpgradeTimes;

    /**
     * 祝福值
     */
    private int bowBlessAmount;

    /**
     * 历史最高祝福值
     */
    private int blessHisMaxAmount;

    /**
     * 祝福值清空时间
     */
    private long blessAmountClearTime;

    /**
     * 弓进阶时间
     * 秒数
     */
    private int bowUpdateTime;

    HeroBow(BowData bowData){
        this.bowData = bowData;
        resource = bowData.id;
    }

    public int getBowId(){
        return bowData.id;
    }

    public SpriteStat getBaseStat(){
        return bowData.baseStat;
    }

    public int getFightingAmount(){
        return bowData.fightingAmount;
    }

    public BowData getBowData(){
        return bowData;
    }

    // 远程服务器设置英雄的弓箭
    public void setBowData(BowData data){
        bowData = data;
    }

    public int changeBowResource(int res){
        if (res >= 0 && res <= bowData.id){
            this.resource = res;
        }

        return resource;
    }

    public int getBowResource(){
        return resource;
    }

    // 升阶

    public void upgradeBow(long ctime){

        if (bowData.nextLevel == null){
            return;
        }

        bowData = bowData.nextLevel;
        bowUpgradeTimes = bowBlessAmount = blessHisMaxAmount = 0;
        blessAmountClearTime = 0;

        bowUpdateTime = (int) (ctime / 1000);
        resource = bowData.id;
    }

    public void setBowUpdateTime(long ctime){
        bowUpdateTime = (int) (ctime / 1000);
    }

    public int getBowUpdateTime(){
        return bowUpdateTime;
    }

    public int incrementUpgradeTimes(){
        return ++bowUpgradeTimes;
    }

    public int getBlessAmount(){
        return bowBlessAmount;
    }

    public int addBlessAmount(int toAddBless){
        bowBlessAmount += toAddBless;

        if (blessHisMaxAmount < bowBlessAmount){
            blessHisMaxAmount = bowBlessAmount;
        }

        return bowBlessAmount;
    }

    public void setClearBlessTime(long clearTime){
        blessAmountClearTime = clearTime;
    }

    public boolean tryClearBlessTime(long ctime){
        if (blessAmountClearTime > 0 && ctime > blessAmountClearTime){
            blessAmountClearTime = bowUpgradeTimes = bowBlessAmount = 0;
            return true;
        }

        return false;
    }

    // 技能

    private long spellVersion;

    private PassiveSpell[] spells = PassiveSpell.EMPTY_ARRAY;

    public PassiveSpell[] getTrigSpells(long ctime){

        BowData bowData = this.bowData;
        if (bowData.openSpellCount <= bowData.trigSpellCount){
            return bowData.bowSpells;
        }

        if (spellVersion == ctime){
            return spells;
        }

        spellVersion = ctime;

        // 生成一份新的数据
        spells = bowData.spellRandomers[bowData.trigSpellCount - 1].getSpell();

        return spells;
    }

    public BowProto encode4Client(){
        BowProto.Builder builder = BowProto.newBuilder();

        builder.setBow(bowData.id);

        if (bowBlessAmount > 0){
            builder.setBlessAmount(bowBlessAmount);

            if (blessAmountClearTime > 0){
                builder.setBlessAmountClearTime(blessAmountClearTime);
            }
        }

        if (resource > 0){
            builder.setResource(resource);
        }

        return builder.build();
    }

    public BowServerProto encode(){
        BowServerProto.Builder builder = BowServerProto.newBuilder();

        builder.setBow(bowData.id).setBowUpdateTime(bowUpdateTime);

        if (bowUpgradeTimes > 0){
            builder.setUpgradeTimes(bowUpgradeTimes);
        }

        if (bowBlessAmount > 0){
            builder.setBlessAmount(bowBlessAmount);
            if (blessAmountClearTime > 0)
                builder.setBlessAmountClearTime(blessAmountClearTime);
        }

        if (blessHisMaxAmount > 0){
            builder.setBlessHisMaxAmount(blessHisMaxAmount);
        }

        if (resource > 0){
            builder.setResource(resource);
        }

        return builder.build();
    }

    public static HeroBow decode(BowServerProto proto,
            ConfigService configService, long ctime){

        if (proto == null){
            return null;
        }

        BowData bowData = configService.getBows().getBow(proto.getBow());

        HeroBow bow = new HeroBow(bowData);

        bow.bowUpgradeTimes = proto.getUpgradeTimes();
        bow.bowBlessAmount = proto.getBlessAmount();
        bow.blessAmountClearTime = proto.getBlessAmountClearTime();
        bow.blessHisMaxAmount = proto.getBlessHisMaxAmount();
        bow.bowUpdateTime = proto.getBowUpdateTime();
        bow.resource = proto.getResource();

        long holdTime = bowData.getUpgradeData().getBlessHoldTime();
        if (holdTime > 0){
            if (bow.blessAmountClearTime <= 0){
                bow.blessAmountClearTime = ctime + holdTime;
            } else{
                bow.tryClearBlessTime(ctime);
            }
        } else{
            bow.blessAmountClearTime = 0;
        }

        return bow;
    }
}
