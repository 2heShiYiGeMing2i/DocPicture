/**
 * 
 */
package app.game.data;

import static com.mokylin.sink.util.Preconditions.checkArgument;
import static com.mokylin.sink.util.Preconditions.checkNotNull;

import org.jboss.netty.buffer.ChannelBuffer;
import org.joda.time.DateTimeConstants;

import app.game.module.WelfareMessages;
import app.game.module.scene.FightData;
import app.utils.VariableConfig;

import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 * 
 */
public class HeroLevelData{

    public final int level;

    // 升级经验
    private final long upgradeExp;

    /**
     * 每一分钟获得的离线经验
     */
    private final int offlineExp;

    // 单人打坐
    private final int meditateExp;

    private final int meditateRealAir;

    // 崇拜收益
    private final int admireExp;

    private final int admireRealAir;

    // 基础属性
    private final SpriteStat baseStat;

    public HeroLevelData nextLevel;

    private transient final int fightAmount;

    // 凤血炼制经验
    private final int phoenixMoneyRefineExp;

    private final int phoenixLijinRefineRealAir;

    private final int phoenixYuanbaoRefineExp;

    private final int phoenixYuanbaoRefineRealAir;

    private transient final ChannelBuffer phoenixRefineDataMsg;

    public HeroLevelData(ObjectParser p, SpriteStats spriteStats,
            VariableConfig config){
        level = p.getIntKey("level");

        checkArgument(level > 0 && level <= VariableConfig.HERO_MAX_LEVEL,
                "英雄等级数据配置中存在无效的等级，level: %s", level);

        // 升级经验
        upgradeExp = p.getLongKey("upgrade_exp");
        checkArgument(upgradeExp > 0
                && upgradeExp < VariableConfig.CLIENT_MAX_LONG,
                "英雄%s 级的升级经验无效，upgradeExp: %s", level, upgradeExp);

        // 离线经验
        offlineExp = p.getIntKey("offline_exp");
        checkArgument(offlineExp > 0, "英雄%s 级的离线经验无效，offlineExp: %s", level,
                offlineExp);
        long offlineExp72Hours = 1L
                * offlineExp
                * (config.OFFLINE_EXP_ACCUMULATION_LIMIT / DateTimeConstants.MILLIS_PER_MINUTE);
        checkArgument(offlineExp72Hours <= Integer.MAX_VALUE,
                "英雄%s 级的72小时累计离线经验超过了21亿，offlineExp: %s", level, offlineExp);

        long offlineExp72Hours3Multiple = offlineExp72Hours * 3;
        checkArgument(offlineExp72Hours3Multiple <= Integer.MAX_VALUE,
                "英雄%s 级的72小时累计离线3倍经验超过了21亿，offlineExp: %s", level, offlineExp);

        // 打坐经验
        meditateExp = p.getIntKey("meditate_exp");
        checkArgument(meditateExp > 0, "英雄%s 级的打坐经验无效，meditateExp: %s", level,
                meditateExp);

        meditateRealAir = p.getIntKey("meditate_real_air");
        checkArgument(meditateRealAir > 0, "英雄%s 级的打坐真气无效，meditateRealAir: %s",
                level, meditateRealAir);

        // 崇拜经验和真气
        admireExp = p.getIntKey("admire_exp");
        checkArgument(admireExp > 0, "英雄%s 级的崇拜经验无效，admireExp: %s", level,
                admireExp);

        admireRealAir = p.getIntKey("admire_real_air");
        checkArgument(admireRealAir > 0, "英雄%s 级的崇拜真气无效，admireRealAir: %s",
                level, admireRealAir);

        // 基础属性
        int baseStatId = p.getIntKey("base_stat");

        baseStat = checkNotNull(spriteStats.get(baseStatId),
                "没有找到英雄 %s 级的初始属性: %s", level, baseStatId);

        fightAmount = FightData.calculateFightingAmount(baseStat);

        phoenixMoneyRefineExp = p.getIntKey("phoenix_money_refine_exp");
        checkArgument(phoenixMoneyRefineExp > 0,
                "英雄%s 级的凤血银两炼制经验无效，phoenix_money_refine_exp: %s", level,
                phoenixMoneyRefineExp);

        phoenixLijinRefineRealAir = p.getIntKey("phoenix_lijin_refine_realair");
        checkArgument(phoenixLijinRefineRealAir > 0,
                "英雄%s 级的凤血礼金炼制真气无效，phoenix_lijin_refine_realair: %s", level,
                phoenixLijinRefineRealAir);

        phoenixYuanbaoRefineExp = p.getIntKey("phoenix_yuanbao_refine_exp");
        checkArgument(phoenixYuanbaoRefineExp > 0,
                "英雄%s 级的凤血元宝炼制经验无效，phoenix_yuanbao_refine_exp: %s", level,
                phoenixYuanbaoRefineExp);

        phoenixYuanbaoRefineRealAir = p
                .getIntKey("phoenix_yuanbao_refine_realair");
        checkArgument(phoenixYuanbaoRefineRealAir > 0,
                "英雄%s 级的凤血元宝炼制真气无效，phoenix_yuanbao_refine_realair: %s", level,
                phoenixYuanbaoRefineRealAir);

        phoenixRefineDataMsg = WelfareMessages.phoenixRefineInfoMsg(
                phoenixMoneyRefineExp, phoenixLijinRefineRealAir,
                phoenixYuanbaoRefineExp, phoenixYuanbaoRefineRealAir);
    }

    public long getUpgradeExp(){
        return upgradeExp;
    }

    public int getOfflineExp(){
        return offlineExp;
    }

    public int getMeditateExp(){
        return meditateExp;
    }

    public int getMeditateRealAir(){
        return meditateRealAir;
    }

    public int getAdmireExp(){
        return admireExp;
    }

    public int getAdmireRealAir(){
        return admireRealAir;
    }

    public SpriteStat getBaseStat(){
        return baseStat;
    }

    public int getFightAmount(){
        return fightAmount;
    }

    public int getPhoenixMoneyRefineExp(){
        return phoenixMoneyRefineExp;
    }

    public int getPhoenixLijinRefineRealAir(){
        return phoenixLijinRefineRealAir;
    }

    public int getPhoenixYuanbaoRefineExp(){
        return phoenixYuanbaoRefineExp;
    }

    public int getPhoenixYuanbaoRefineRealAir(){
        return phoenixYuanbaoRefineRealAir;
    }

    public ChannelBuffer getPhoenixRefineDataMsg(){
        return phoenixRefineDataMsg;
    }
}
