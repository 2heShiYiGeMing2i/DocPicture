package app.game.data.fight;

import static com.mokylin.sink.util.Preconditions.*;
import app.game.data.Prize;
import app.game.data.PrizeConfig;
import app.game.data.PrizeConfigs;
import app.protobuf.ConfigContent.FightPosDiffProto;
import app.utils.VariableConfig;

import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class FightPosDiffData{

    // inclusive
    public final int startPos;

    // exclusive
    public final int endPos;

    public final Prize challengeWinPrize;

    public final Prize challengeLosePrize;

    public final Prize hourlyPrize;

    public final Prize dailyPrize;

    public final int diffPos;

    FightPosDiffData(int startPos, int endPos, ObjectParser p,
            PrizeConfigs prizeConfigs){
        this.startPos = startPos;
        this.endPos = endPos;

        diffPos = p.getIntKey("diff_pos");
        checkArgument(diffPos > 0, "名次-%s 配置的位置差必须大于0", startPos);

        if (startPos <= VariableConfig.ONE_ON_ONE_CHALLENGE_LIST_COUNT){
            checkArgument(diffPos == 1, "名次-%s 名次差无效，前7名的名次，名次差必须为1", startPos);
        } else{
            int firstCanChallengePos = startPos - diffPos
                    * (VariableConfig.ONE_ON_ONE_CHALLENGE_LIST_COUNT - 3);

            checkArgument(firstCanChallengePos >= 1,
                    "名次-%s 名次差无效，可挑战的最前名次居然小于1", startPos);
        }

        String name = p.getKey("challenge_win_prize");
        PrizeConfig prizeConfig = checkNotNull(prizeConfigs.get(name),
                "名次-%s 的挑战成功奖励没找到, name: %s", startPos, name);
        challengeWinPrize = prizeConfig.random();
        checkArgument(!challengeWinPrize.hasGoods(), "名次-%s 的挑战成功奖励不能配置物品, %s",
                startPos);

        name = p.getKey("challenge_lose_prize");
        prizeConfig = checkNotNull(prizeConfigs.get(name),
                "名次-%s 的挑战失败奖励没找到, name: %s", startPos, name);
        challengeLosePrize = prizeConfig.random();
        checkArgument(!challengeLosePrize.hasGoods(),
                "名次-%s 的挑战失败奖励不能配置物品, %s", startPos);

        name = p.getKey("hourly_prize");
        prizeConfig = checkNotNull(prizeConfigs.get(name),
                "名次-%s 的整点奖励没找到, name: %s", startPos, name);
        hourlyPrize = prizeConfig.random();
        checkArgument(!hourlyPrize.hasGoods(), "名次-%s 的整点奖励不能配置物品, %s",
                startPos);

        name = p.getKey("daily_prize");
        prizeConfig = checkNotNull(prizeConfigs.get(name),
                "名次-%s 的每日奖励没找到, name: %s", startPos, name);
        dailyPrize = prizeConfig.random();
        checkArgument(!dailyPrize.hasGoods(), "名次-%s 的每日奖励不能配置物品, %s", startPos);
    }

    public boolean isInRange(int pos){
        return pos >= startPos && pos < endPos;
    }

    FightPosDiffProto encode(){
        FightPosDiffProto.Builder builder = FightPosDiffProto.newBuilder();

        builder.setStartPos(startPos);
        if (endPos < Integer.MAX_VALUE)
            builder.setEndPos(endPos);
        builder.setChallengeWinPrize(challengeWinPrize.encode4Client());
        builder.setChallengeLosePrize(challengeLosePrize.encode4Client());
        builder.setHourlyPrize(hourlyPrize.encode4Client());
        builder.setDailyPrize(dailyPrize.encode4Client());

        return builder.build();
    }

    @Override
    public int hashCode(){
        return startPos;
    }

    @Override
    public boolean equals(Object obj){
        return this == obj;
    }
}
