package app.game.data.scene;

import static com.mokylin.sink.util.Preconditions.checkArgument;
import app.cluster.client.combat.scene.LocalHuoLinActivityScene;
import app.cluster.combat.master.logic.scene.RemoteHuoLinActivityScene;
import app.game.data.GameObjects;
import app.game.data.goods.GoodsWrapper;
import app.game.module.scene.IClusterLocalDungeonService;
import app.game.module.scene.IDungeonService;
import app.message.ISender;
import app.protobuf.ConfigContent.HuoLinActivityProto;
import app.protobuf.ConfigContent.HuoLinBossConfig;
import app.protobuf.ConfigContent.HuoLinBossProto;
import app.protobuf.LogContent.LogEnum.SceneType;

import com.google.protobuf.ByteString;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.parse.ObjectParser;

public class HuoLinActivitySceneData extends GlobalActivitySceneData{

    /**
     * 打坐收益额外倍率
     */
    private final float mediateExtraMultiple;

    /**
     * 每隔5秒加多少经验
     */
    public final int eachAddExpAmount;

    /**
     * 每隔5秒加多少经验
     */
    public final int eachAddRealAirAmount;

    public final HuoLinBossConfig bossConfig;

    public final byte[] compressBossConfigBytes;

    HuoLinActivitySceneData(GameObjects go, ObjectParser p, BlockInfos blocks,
            MonsterDatas monsters, Scripts scripts, Plunders plunders, Ais ais,
            SceneTransportDatas transports,
            SceneRemoveObjectMsgCache removeMsgCache){
        super(go, p, blocks, monsters, scripts, plunders, ais, transports,
                removeMsgCache);

        // 额外收益倍率
        int multiple = p.getIntKey("mediate_multiple");
        checkArgument(multiple > 0, "火麟洞里配置的打坐倍率必须>0: %s", this);
        this.mediateExtraMultiple = multiple - 1;

        // 每隔5秒的收益
        this.eachAddExpAmount = p.getIntKey("each_add_exp_amount");
        this.eachAddRealAirAmount = p.getIntKey("each_add_real_air_amount");

        checkArgument(eachAddExpAmount >= 0 && eachAddRealAirAmount >= 0,
                "火麟洞每5分钟给的经验和真气必须>0");

        // Boss数据缓存
        bossConfig = encodeBossConfig();
        compressBossConfigBytes = Utils.zlibCompress(bossConfig.toByteArray());
    }

    private HuoLinBossConfig encodeBossConfig(){
        HuoLinBossConfig.Builder builder = HuoLinBossConfig.newBuilder();

        for (MonsterGroupWithTimeData group : getMonsterWithTimes()){

            for (SceneMonsterData m : group.monsters){
                HuoLinBossProto.Builder b = HuoLinBossProto.newBuilder();

                MonsterData monData = m.getMonsterData();
                b.setMon(monData.id);
                b.setMonsterId(m.getID());
                b.setTimeConfig(group.timeData.input);

                for (GoodsWrapper w : monData.showGoods){
                    b.addShowGoods(w.encode4Client());
                }

                builder.addBoss(b.build());
            }
        }

        return builder.build();
    }

    public float getMeditateMultiple(){
        return mediateExtraMultiple;
    }

    @Override
    public int getIntType(){
        return SceneType.HUO_LIN_DUNGEON.getNumber();
    }

    @Override
    protected boolean canHaveMonsterWithTime(){
        return true;
    }

    @Override
    protected boolean canHaveRelivableMonster(){
        return true;
    }

    @Override
    public LocalHuoLinActivityScene newLocalClusterScene(int uuid,
            IClusterLocalDungeonService dungeonService, ISender combatClient,
            long heroID){
        return new LocalHuoLinActivityScene(this, uuid, dungeonService,
                combatClient, heroID);
    }

    @Override
    public RemoteHuoLinActivityScene newRemoteClusterScene(int uuid,
            IDungeonService dungeonService, long creator, ISender worker){
        return new RemoteHuoLinActivityScene(this, uuid, dungeonService,
                creator, worker);
    }

    HuoLinActivityProto generateProto(){
        HuoLinActivityProto.Builder builder = HuoLinActivityProto.newBuilder();
        builder.setSceneId(id).setMap(blockName)
                .setName(ByteString.copyFrom(nameBytes)).setSound(sound);
        if (requiredLevel > 1){
            builder.setRequiredLevel(requiredLevel);
        }
        if (isHeroLevelProtect){
            builder.setIsHeroLevelProtect(true);
        }
        if (isNewHeroProtect){
            builder.setIsNewHeroProtect(true);
        }
        if (isDeathProtect){
            builder.setIsDeathProtect(true);
        }
        if (isNightAutoProtect){
            builder.setIsNightAutoProtect(true);
        }
        if (isJumpLimit){
            builder.setIsJumpLimit(true);
        }
        if (isMountLimit){
            builder.setIsMountLimit(true);
        }

        if (poet != null){
            String tp = poet.trim();
            if (tp.length() > 0){
                builder.setPoet(ByteString.copyFromUtf8(tp));
            }
        }
        if (fixedPkMode != null){
            builder.setFixedPkMode(fixedPkMode.getIntMode());
        }

        if (reliveOutOfDungeon){
            builder.setIsDeathReturnTown(true);
        }

        builder.setRequiredLevel(requiredLevel);

        return builder.build();
    }

}
