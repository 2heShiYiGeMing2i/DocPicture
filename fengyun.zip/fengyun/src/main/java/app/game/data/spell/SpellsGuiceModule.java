package app.game.data.spell;

import com.google.inject.AbstractModule;
import com.google.inject.Singleton;

public class SpellsGuiceModule extends AbstractModule{

    @Override
    protected void configure(){
        binder().requireExplicitBindings();
        bind(FightStates.class).in(Singleton.class);
        bind(SingleEffectSpells.class).in(Singleton.class);
        bind(PassiveSpells.class).in(Singleton.class);
        bind(Auras.class).in(Singleton.class);
        bind(Spells.class).in(Singleton.class);
        bind(Animations.class).in(Singleton.class);
        bind(SpellAnimations.class).in(Singleton.class);
        bind(SpellXinfaEffects.class).in(Singleton.class);
    }
}
