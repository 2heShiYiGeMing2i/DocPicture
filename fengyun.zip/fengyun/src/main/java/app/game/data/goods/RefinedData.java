package app.game.data.goods;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.data.SingleSpriteStat;
import app.game.data.UpgradeData;
import app.game.module.EquipmentMessages;
import app.game.module.scene.FightData;
import app.protobuf.ConfigContent.EquipmentRefinedForgeProto;
import app.protobuf.GoodsServerContent.Quality;
import app.protobuf.SpriteStatContent.SingleStatProto;

import com.mokylin.sink.util.StringEncoder;
import com.mokylin.sink.util.Utils;

/**
 * @author Liwei
 *
 */
public class RefinedData{

    final int equipmentId;

    final int refinedTimes;

    final int len;

    private final SingleSpriteStat[] refinedStat;

    private final int[] refinedFightingAmount;

//    transient final SpriteStat baseRefinedStat;
//
//    transient final int baseRefinedFightingAmount;

    transient final byte[] dropName;

    private transient final SingleStatProto[] refinedStatProto;

    final RefinedData nextLevel;

    RefinedData(int equipmentId, String name, int refinedTimes,
            SingleSpriteStat[] refinedStat, RefinedData nextLevel){
        this.equipmentId = equipmentId;
        this.refinedTimes = refinedTimes;
        this.refinedStat = refinedStat;
        this.nextLevel = nextLevel;

        len = refinedStat.length;

        refinedFightingAmount = new int[len];
        refinedStatProto = new SingleStatProto[len];
        for (int i = 0; i < len; i++){
            refinedFightingAmount[i] = FightData
                    .calculateFightingAmount(refinedStat[i]);
            refinedStatProto[i] = refinedStat[i].encode();
        }

//        SingleSpriteStat singleBaseRefinedStat = baseStat.add(refinedStat);
//
//        baseRefinedStat = SpriteStat.EMPTY_STAT.add(singleBaseRefinedStat);
//
//        baseRefinedFightingAmount = baseFightingAmount + refinedFightingAmount;

        dropName = StringEncoder.encode(refinedTimes > 0 ? name + "+"
                + refinedTimes : name);

    }

    public int getRefinedTimes(){
        return refinedTimes;
    }

    public SingleSpriteStat getRefinedStat(int quality){
        return Utils.getValidObject(refinedStat, quality);
    }

    public int getRefinedFightingAmount(int quality){
        return Utils.getValidInteger(refinedFightingAmount, quality);
    }

    public SingleStatProto getRefinedStatProto(int quality){
        return Utils.getValidObject(refinedStatProto, quality);
    }

    // 强化升级

    private UpgradeData upgradeData;

    private boolean isBroadcast;

    private transient byte[][] protoData;

    private transient ChannelBuffer[] upgradeDataMsg;

    void init(UpgradeData upgradeData, boolean isBradcast){

        if (refinedTimes > 0){
            this.upgradeData = upgradeData;
            this.isBroadcast = isBradcast;

            int len = Quality.values().length;

            protoData = new byte[len][];
            upgradeDataMsg = new ChannelBuffer[len];
            for (Quality q : Quality.values()){
                int i = q.getNumber();

                int idx = Math.min(i, refinedStat.length - 1);
                EquipmentRefinedForgeProto proto = EquipmentRefinedForgeProto
                        .newBuilder().setId(equipmentId)
                        .setRefinedTimes(refinedTimes)
                        .setRefinedStat(refinedStat[idx].encode())
                        .setRefinedFightingAmount(refinedFightingAmount[idx])
                        .setQuality(i).setCost(upgradeData.getProto()).build();

                protoData[i] = proto.toByteArray();
                upgradeDataMsg[i] = EquipmentMessages.getRefinedDataMsg(proto);
            }
        }
    }

    public UpgradeData getUpgradeData(){
        return upgradeData;
    }

    public boolean isBroadcast(){
        return isBroadcast;
    }

    public byte[] getUpgradeProtoData(int quality){
        return Utils.getValidObject(protoData, quality);
    }

    public ChannelBuffer getUpgradeDataMsg(int quality){
        return Utils.getValidObject(upgradeDataMsg, quality);
    }
}
