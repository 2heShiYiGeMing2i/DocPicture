package app.game.data.scene;

import static com.mokylin.sink.util.Preconditions.checkArgument;

import java.util.Collection;
import java.util.List;

import app.game.data.GameObjects;

import com.google.common.collect.HashMultimap;
import com.google.common.collect.Multimap;
import com.google.inject.Inject;
import com.mokylin.sink.util.parse.ObjectParser;

public class SceneTransportDatas{

    public static final String LOCATION = GameObjects.SCENE_BASE_FOLDER
            + "scene_transport.txt";

    private final Multimap<Integer, SceneTransportData> multimap;

    @Inject
    SceneTransportDatas(GameObjects go){
        List<ObjectParser> data = go.loadFile(LOCATION);
        multimap = HashMultimap.create();

        for (ObjectParser p : data){
            SceneTransportData t = new SceneTransportData(p);
            boolean unique = multimap.put(t.sourceSceneID, t);
            checkArgument(
                    unique,
                    "不能有2个传送门的起始坐标相同 source_scene_id: %s, source_x: %s, source_y: %s",
                    t.sourceSceneID, t.sourceX, t.sourceY);
        }
    }

    public Collection<SceneTransportData> getTransportFromSourceScene(
            int sceneID){
        return multimap.get(sceneID);
    }
}
