package app.game.data.scene;

import static com.mokylin.sink.util.Preconditions.checkArgument;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.module.scene.SceneMessages;

import com.mokylin.collection.IntArrayList;
import com.mokylin.collection.IntHashMap;
import com.mokylin.collection.LongHashMap;
import com.mokylin.sink.util.Utils;

public class DefenceMonsterPosCalculator{
    private final BlockInfo blockInfo;
    private final int centerX;
    private final int centerY;
    private final int range;
    private final int[] walkablePoses;

    private final IntHashMap<int[]> cache;

    DefenceMonsterPosCalculator(BlockInfo blockInfo, int centerX, int centerY,
            int range){
        this.blockInfo = blockInfo;
        this.cache = new IntHashMap<>(256);

        this.centerX = centerX;
        this.centerY = centerY;
        this.range = range;

        checkArgument(centerX >= 0 && centerX < blockInfo.getWidth(),
                "守护孔慈出怪的中心点x必须在0-%s之间: %s", blockInfo.getWidth(), centerX);
        checkArgument(centerY >= 0 && centerY < blockInfo.getHeight(),
                "守护孔慈出怪的中心点y必须在0-%s之间: %s", blockInfo.getHeight(), centerY);

        // 得到所有可走坐标

        IntArrayList pos = new IntArrayList();
        if (blockInfo.isWalkable(centerX, centerY)){
            pos.add(Utils.short2Int(centerX, centerY));
        }
        for (int delta = 1; delta <= range; delta++){
            // 上条
            int y = centerY - delta;
            int x;
            for (x = centerX - delta; x < centerX + delta; x++){
                if (blockInfo.isWalkable(x, y)){
                    pos.add(Utils.short2Int(x, y));
                }
            }

            // 右条
            x = centerX + delta;
            for (y = centerY - delta; y < centerY + delta; y++){
                if (blockInfo.isWalkable(x, y)){
                    pos.add(Utils.short2Int(x, y));
                }
            }

            // 下条
            y = centerY + delta;
            for (x = centerX + delta; x > centerX - delta; x--){
                if (blockInfo.isWalkable(x, y)){
                    pos.add(Utils.short2Int(x, y));
                }
            }

            // 左条
            x = centerX - delta;
            for (y = centerY + delta; y > centerY - delta; y--){
                if (blockInfo.isWalkable(x, y)){
                    pos.add(Utils.short2Int(x, y));
                }
            }
        }

        walkablePoses = pos.toArray();
        checkArgument(walkablePoses.length > 0,
                "守护孔慈出怪点<%s, %s>, 周围%s格内没有可走坐标", centerX, centerY, range);
    }

    int[] get(int count){
        int[] result = cache.get(count);
        if (result != null){
            return result;
        }

        result = doGet(count);
        cache.put(count, result);
        return result;
    }

    private int[] doGet(int count){
        int[] result = new int[count];
        float diff = ((float) walkablePoses.length) / count;

        for (int i = 0; i < count; i++){
            result[i] = walkablePoses[(int) (i * diff)];
        }
        return result;
    }

}
