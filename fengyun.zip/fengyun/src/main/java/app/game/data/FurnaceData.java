package app.game.data;

import static com.mokylin.sink.util.Preconditions.*;
import app.game.data.goods.EquipmentData;
import app.game.data.goods.Goods;
import app.game.data.goods.GoodsRandomer;
import app.game.data.scene.PlunderGroup;
import app.game.data.scene.PlunderGroups;
import app.protobuf.HeroServerContent.RaceId;
import app.utils.VariableConfig;

import com.google.inject.Inject;
import com.mokylin.sink.util.RandomNumber;
import com.mokylin.sink.util.Utils;

/**
 * 熔炉配置
 * @author Liwei
 *
 */
public class FurnaceData{

    private static final int DENOMINATOR = 10000;

    private final int meltMaxAmount;

    private final PlunderGroup[] groupArray;

    private final int raceCount;

    private final int selfRaceGoodsRate;

    @Inject
    FurnaceData(VariableConfig config, PlunderGroups groups){

        meltMaxAmount = config.MELT_MAX_AMOUNT;
        checkArgument(meltMaxAmount > 0, "熔炼最大值必须大于0");

        raceCount = RaceId.values().length;

        String[] array = config.MELT_PLUNDER_GROUP_ARRAY.split(";");
        checkArgument(array.length == raceCount,
                "熔炉装备掉落组包配置的个数不对，必须一个职业一个，职业个数:%s plunder:%s",
                RaceId.values().length, config.MELT_PLUNDER_GROUP_ARRAY);

        groupArray = new PlunderGroup[raceCount];
        for (int i = 0; i < array.length; i++){
            groupArray[i] = checkNotNull(groups.get(array[i]),
                    "熔炉装备掉落组包没找到，%s", array[i]);

            for (GoodsRandomer goods : groupArray[i].getGoodsRandomers()){
                checkArgument(goods.getData() instanceof EquipmentData,
                        "熔炉装备掉落组包-%s 中配置有不是装备的物品, goods: %s", array[i],
                        goods.getData());

                checkArgument(goods.getDefaultCount() == 1,
                        "熔炉装备掉落组包-%s 中配置的个数居然不是1", array[i]);
            }
        }

        selfRaceGoodsRate = config.MELT_SELF_RACE_RATE;
        checkArgument(selfRaceGoodsRate >= 0
                && selfRaceGoodsRate <= DENOMINATOR,
                "熔炉装备掉落自己职业装备的概率无效，[0-10000], rate: %s", selfRaceGoodsRate);
    }

    public int getMeltMaxAmount(){
        return meltMaxAmount;
    }

    public Goods random(long ctime, int race){
        assert race > 0 && race <= raceCount: "randomHelper invalid race";

        // 先看下是不是自己职业的
        int raceIndex = race - 1;
        if (RandomNumber.getRate(DENOMINATOR, true) >= selfRaceGoodsRate){
            // 其他职业
            int index = RandomNumber.getRate(raceCount - 1, true);
            if (index >= raceIndex)
                ++index;

            raceIndex = index;
        }

        return Utils.getValidObject(groupArray, raceIndex).random(ctime);
    }
}
