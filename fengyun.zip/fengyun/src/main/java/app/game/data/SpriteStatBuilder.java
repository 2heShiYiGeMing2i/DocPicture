/**
 * 
 */
package app.game.data;

import app.protobuf.SpriteStatContent.SpriteStatProto;
import app.protobuf.SpriteStatContent.StatType;

/**
 * @author Liwei
 * 
 */
public class SpriteStatBuilder{

    public static SpriteStatBuilder newBuilder(){
        return new SpriteStatBuilder();
    }

    /**
     * 最大血量
     */
    private int maxLife;

    /**
     * 体力
     */
    private int maxStamina;

    /**
     * 攻击
     */
    private int attack;

    /**
     * 防御
     */
    private int defence;

    /**
     * 暴击值
     */
    private int crit;

    /**
     * 韧性值(降低被暴击几率)
     */
    private int antiCrit;

    /**
     * 命中值
     */
    private int hit;

    /**
     * 闪避值
     */
    private int dodge;

    /**
     * 移动速度
     */
    private int moveSpeed;

    private float maxLifePer;

    private float staminaPer;

    private float attackPer;

    private float defencePer;

    private float critPer;

    private float antiCritPer;

    private float hitPer;

    private float dodgePer;

    private float moveSpeedPer;

    private boolean isZeroPer;

    private SpriteStatBuilder(){
        isZeroPer = true;
    }

    public void add(SpriteStat toAdd){
        maxLife += toAdd.maxLife;
        maxStamina += toAdd.maxStamina;
        attack += toAdd.attack;
        defence += toAdd.defence;
        crit += toAdd.crit;
        antiCrit += toAdd.antiCrit;
        hit += toAdd.hit;
        dodge += toAdd.dodge;
        moveSpeed += toAdd.moveSpeed;

        if (!toAdd.isZeroPer){
            maxLifePer += toAdd.maxLifePer;
            staminaPer += toAdd.maxStaminaPer;
            attackPer += toAdd.attackPer;
            defencePer += toAdd.defencePer;
            critPer += toAdd.critPer;
            antiCritPer += toAdd.antiCritPer;
            hitPer += toAdd.hitPer;
            dodgePer += toAdd.dodgePer;
            moveSpeedPer += toAdd.moveSpeedPer;

            isZeroPer = false;
        }
    }

    public void remove(SpriteStat toRemove){
        maxLife -= toRemove.maxLife;
        maxStamina -= toRemove.maxStamina;
        attack -= toRemove.attack;
        defence -= toRemove.defence;
        crit -= toRemove.crit;
        antiCrit -= toRemove.antiCrit;
        hit -= toRemove.hit;
        dodge -= toRemove.dodge;
        moveSpeed -= toRemove.moveSpeed;

        if (!toRemove.isZeroPer){
            maxLifePer -= toRemove.maxLifePer;
            staminaPer -= toRemove.maxStaminaPer;
            attackPer -= toRemove.attackPer;
            defencePer -= toRemove.defencePer;
            critPer -= toRemove.critPer;
            antiCritPer -= toRemove.antiCritPer;
            hitPer -= toRemove.hitPer;
            dodgePer -= toRemove.dodgePer;
            moveSpeedPer -= toRemove.moveSpeedPer;

            isZeroPer = false;
        }
    }

    public void add(SpriteStat toAdd, int precent){
        add(toAdd, precent / 100f);
    }

    public void add(SpriteStat toAdd, float amount){
        if (amount == 0){
            return;
        } else if (amount == 1){
            add(toAdd);
            return;
        }

        maxLife += toAdd.maxLife * amount;
        maxStamina += toAdd.maxStamina * amount;
        attack += toAdd.attack * amount;
        defence += toAdd.defence * amount;
        crit += toAdd.crit * amount;
        antiCrit += toAdd.antiCrit * amount;
        hit += toAdd.hit * amount;
        dodge += toAdd.dodge * amount;
        moveSpeed += toAdd.moveSpeed * amount;

        if (!toAdd.isZeroPer){
            maxLifePer += toAdd.maxLifePer * amount;
            staminaPer += toAdd.maxStaminaPer * amount;
            attackPer += toAdd.attackPer * amount;
            defencePer += toAdd.defencePer * amount;
            critPer += toAdd.critPer * amount;
            antiCritPer += toAdd.antiCritPer * amount;
            hitPer += toAdd.hitPer * amount;
            dodgePer += toAdd.dodgePer * amount;
            moveSpeedPer += toAdd.moveSpeedPer * amount;

            isZeroPer = false;
        }
    }

    public void add(SingleSpriteStat toAdd){
        add(toAdd.getStatType(), toAdd.getAmount());
    }

    public void add(StatType statType, int amount){

        if (amount == 0){
            return;
        }

        switch (statType){
            case MAX_LIFE:{
                maxLife += amount;
                break;
            }
            case MAX_STAMINA:{
                maxStamina += amount;
                break;
            }
            case ATTACK:{
                attack += amount;
                break;
            }
            case DEFENCE:{
                defence += amount;
                break;
            }
            case CRIT:{
                crit += amount;
                break;
            }
            case ANTI_CRIT:{
                antiCrit += amount;
                break;
            }
            case HIT:{
                hit += amount;
                break;
            }
            case DODGE:{
                dodge += amount;
                break;
            }
            case MOVE_SPEED:{
                moveSpeed += amount;
                break;
            }
        }
    }

    public void remove(SingleSpriteStat toRemove){

        if (toRemove.amount == 0){
            return;
        }

        switch (toRemove.statType){
            case MAX_LIFE:{
                maxLife -= toRemove.amount;
                break;
            }
            case MAX_STAMINA:{
                maxStamina -= toRemove.amount;
                break;
            }
            case ATTACK:{
                attack -= toRemove.amount;
                break;
            }
            case DEFENCE:{
                defence -= toRemove.amount;
                break;
            }
            case CRIT:{
                crit -= toRemove.amount;
                break;
            }
            case ANTI_CRIT:{
                antiCrit -= toRemove.amount;
                break;
            }
            case HIT:{
                hit -= toRemove.amount;
                break;
            }
            case DODGE:{
                dodge -= toRemove.amount;
                break;
            }
            case MOVE_SPEED:{
                moveSpeed -= toRemove.amount;
                break;
            }
        }
    }

    public SpriteStat build(){
        return new SpriteStat(maxLife, maxStamina, attack, defence, crit,
                antiCrit, hit, dodge, moveSpeed, maxLifePer, staminaPer,
                attackPer, defencePer, critPer, antiCritPer, hitPer, dodgePer,
                moveSpeedPer, isZeroPer);
    }

    public SpriteStatProto encode(){
        SpriteStatProto.Builder builder = SpriteStatProto.newBuilder();

        if (maxLife != 0)
            builder.setMaxLife(maxLife);

        if (maxStamina != 0)
            builder.setMaxStamina(maxStamina);

        if (attack != 0)
            builder.setAttack(attack);

        if (defence != 0)
            builder.setDefence(defence);

        if (crit != 0)
            builder.setCrit(crit);

        if (antiCrit != 0)
            builder.setAntiCrit(antiCrit);

        if (hit != 0)
            builder.setHit(hit);

        if (dodge != 0)
            builder.setDodge(dodge);

        if (moveSpeed != 0)
            builder.setMoveSpeed(moveSpeed);

        return builder.build();
    }
}
