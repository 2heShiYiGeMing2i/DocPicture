package app.game.data.goods;

import static com.mokylin.sink.util.Preconditions.checkNotNull;
import app.game.data.SpriteStat;
import app.game.data.SpriteStats;
import app.protobuf.ConfigContent.Config;
import app.utils.VariableConfig;

import com.google.inject.Inject;

/**
 * @author Liwei
 *
 */
public class EquipmentExtraStats{

    private final EquipmentExtraStat purpleExtraStat;

    private final EquipmentExtraStat purpleExtraRefined7Stat;

    private final EquipmentExtraStat purpleExtraRefined10Stat;

    private final int maxRefinedTimes;

    @Inject
    EquipmentExtraStats(VariableConfig config, SpriteStats spriteStats){
        SpriteStat spriteStat = checkNotNull(
                spriteStats.get(config.PURPLE_EXTRA_STAT), "没找到全身紫色附加属性-%s",
                config.PURPLE_EXTRA_STAT);

        purpleExtraStat = new EquipmentExtraStat(0, spriteStat, null);

        spriteStat = checkNotNull(
                spriteStats.get(config.PURPLE_EXTRA_REFINED_7_STAT),
                "没找到全身紫色+7附加属性-%s", config.PURPLE_EXTRA_REFINED_7_STAT);

        purpleExtraRefined7Stat = new EquipmentExtraStat(7, spriteStat,
                purpleExtraStat.getTotalStat());

        spriteStat = checkNotNull(
                spriteStats.get(config.PURPLE_EXTRA_REFINED_10_STAT),
                "没找到全身紫色+10附加属性-%s", config.PURPLE_EXTRA_REFINED_10_STAT);

        maxRefinedTimes = 10;

        purpleExtraRefined10Stat = new EquipmentExtraStat(maxRefinedTimes,
                spriteStat, purpleExtraRefined7Stat.getTotalStat());
    }

    public int getMaxRefinedTimes(){
        return maxRefinedTimes;
    }

    public EquipmentExtraStat getExtraStat(int refinedTimes){

        if (refinedTimes >= purpleExtraRefined10Stat.refinedTimes){
            return purpleExtraRefined10Stat;
        }

        if (refinedTimes >= purpleExtraRefined7Stat.refinedTimes){
            return purpleExtraRefined7Stat;
        }

        return purpleExtraStat;
    }

    public void encode(Config.Builder builder){
        builder.addEquipmentExtraStat(purpleExtraStat.spriteStat.encode());
        builder.addEquipmentExtraStat(purpleExtraRefined7Stat.spriteStat
                .encode());
        builder.addEquipmentExtraStat(purpleExtraRefined10Stat.spriteStat
                .encode());
    }
}
