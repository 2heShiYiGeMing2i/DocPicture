package app.game.data.gem;

import static com.mokylin.sink.util.Preconditions.checkArgument;
import static com.mokylin.sink.util.Preconditions.checkNotNull;
import app.game.data.SingleSpriteStat;
import app.game.data.goods.Equipment;
import app.protobuf.SpriteStatContent.StatType;

import com.mokylin.sink.util.Empty;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class GemStatData{

    final StatType statType;

    final String icon;

    // 一阶到满阶所加的属性
    final SingleSpriteStat[] spriteStats;

    // 部件
    final int[] parts;

    GemStatData(ObjectParser p, int gemMaxLevel){
        int intStatType = p.getIntKey("stat_type");

        statType = checkNotNull(StatType.valueOf(intStatType),
                "宝石属性中配置的属性类型不存在，statType: %s", intStatType);

        icon = p.getKey("icon");
        checkArgument(!icon.isEmpty(), "宝石属性 %s 没有配置icon", statType);

        String statStr = p.getKey("sprite_stat");
        String[] statArray = statStr.split(";");

        checkArgument(statArray.length == gemMaxLevel,
                "宝石属性 %s 配置的属性个数跟宝石总阶数不一致", statType);

        spriteStats = new SingleSpriteStat[gemMaxLevel + 1];
        spriteStats[0] = SingleSpriteStat.getEmptyStat(statType);
        for (int i = 1; i <= gemMaxLevel; i++){
            int amount = Integer.parseInt(statArray[i - 1]);

            checkArgument(amount > 0, "宝石属性 %s 配置的 %s 阶属性居然<=0", statType,
                    i + 1);

            checkArgument(spriteStats[i - 1].getAmount() < amount,
                    "宝石属性 %s 配置的 %s 阶属性值居然不比前一阶大", statType, i + 1);

            spriteStats[i] = new SingleSpriteStat(statType, amount);
        }

        String partStr = p.getKey("parts");
        if (partStr.isEmpty()){
            parts = Empty.INT_ARRAY;
        } else{
            String[] partArray = partStr.split(";");
            parts = new int[partArray.length];

            for (int i = 0; i < partArray.length; i++){
                parts[i] = Integer.parseInt(partArray[i]);

                checkArgument(
                        parts[i] >= 0
                                && parts[i] < Equipment.HERO_EQUIPED_MAX_COUNT,
                        "宝石部件 配置的part无效, 0-武器 1-戒指 2-项链 3-护腕 4-玉佩 5-头盔 6-衣服 7-腰带 8-裤子 9-鞋子, part: %s",
                        parts[i]);
            }
        }

    }

    SingleSpriteStat getSpriteStat(int gemLevel){
        return Utils.getValidObject(spriteStats, gemLevel);
    }
}
