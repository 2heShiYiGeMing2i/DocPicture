package app.game.data.scene;

import static com.mokylin.sink.util.Preconditions.*;

import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;

import org.joda.time.DateTimeConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.data.ActivityPayback;
import app.game.data.ActivityPaybacks;
import app.game.data.GameObjects;
import app.game.data.HorizontalConfigLoader;
import app.game.data.TimeData;
import app.game.data.goods.GoodsDatas;
import app.protobuf.ConfigContent.DailyActivityType;
import app.protobuf.ConfigContent.HuoLinConfigProto;

import com.google.inject.Inject;
import com.mokylin.collection.IntHashMap;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.parse.ObjectParser;

public class HuoLinActivitySceneDatas{
    private static final Logger logger = LoggerFactory
            .getLogger(HuoLinActivitySceneDatas.class);

    public static final String LOCATION = GameObjects.HUO_LIN_SCENE_BASE_FOLDER
            + "huo_lin.txt";

    private final IntHashMap<HuoLinActivitySceneData> map;

    private final int[] sortedSceneLevel;

    private final HuoLinActivitySceneData[] sortedSceneData;

    public final int lowestLevel;

    public final TimeData activityTimeData;

    public final long activityDuration;

    @Inject
    HuoLinActivitySceneDatas(GameObjects go,
            HorizontalConfigLoader hConfigLoader, BlockInfos blocks,
            MonsterDatas monsters, Scripts scripts, Plunders plunders, Ais ais,
            SceneTransportDatas transports, GoodsDatas goodsDatas,
            PlunderGroups groups, ActivityPaybacks paybacks,
            SceneRemoveObjectMsgCache removeMsgCache){
        logger.debug("加载火麟洞配置");

        List<ObjectParser> data = go.loadFile(LOCATION);

        map = new IntHashMap<>(data.size());

        for (ObjectParser p : data){
            HuoLinActivitySceneData scene = new HuoLinActivitySceneData(go, p,
                    blocks, monsters, scripts, plunders, ais, transports,
                    removeMsgCache);

            map.putUnique(scene.id, scene);
        }

        checkArgument(data.size() > 0, "没有配置火麟洞: " + LOCATION);

        // 检查所有的场景的time一样, 且没有相同的等级限制
        for (HuoLinActivitySceneData scene : map.values()){
            for (HuoLinActivitySceneData other : map.values()){
                if (scene == other){
                    continue;
                }

                checkArgument(scene.activityTime.equals(other.activityTime),
                        "不同等级的火麟洞开启时间必须相同: {} -> {}", scene, other);
                checkArgument(
                        scene.activityDurationMillis == other.activityDurationMillis,
                        "不同等级的火麟洞持续时间必须相同: {} -> {}", scene, other);

                checkArgument(scene.requiredLevel != other.requiredLevel,
                        "多个火麟洞必须有不同的等级限制: {} -> {}", scene, other);
            }
        }

        // 根据等级排序
        this.sortedSceneData = map.values().toArray(
                new HuoLinActivitySceneData[0]);
        Arrays.sort(sortedSceneData, new Comparator<HuoLinActivitySceneData>(){

            @Override
            public int compare(HuoLinActivitySceneData o1,
                    HuoLinActivitySceneData o2){
                return o1.requiredLevel - o2.requiredLevel;
            }
        });
        this.sortedSceneLevel = new int[sortedSceneData.length];
        for (int i = 0; i < sortedSceneData.length; i++){
            sortedSceneLevel[i] = sortedSceneData[i].requiredLevel;
        }

        // 检查代码bug, 是否真的从小到大排序了
        checkArgument(sortedSceneData.length == map.size());
        int lastLevel = -1;
        for (HuoLinActivitySceneData sceneData : sortedSceneData){
            checkArgument(sceneData.requiredLevel > lastLevel);
            lastLevel = sceneData.requiredLevel;
            checkArgument(map.get(sceneData.id) == sceneData); // 检查是不是每个scene都在array中了
        }

        lowestLevel = sortedSceneLevel[0];

        // 之前已经检查过每个场景的配置都是相同的
        this.activityTimeData = sortedSceneData[0].activityTime;
        this.activityDuration = sortedSceneData[0].activityDurationMillis;

        ActivityPayback payback = checkNotNull(
                paybacks.get(DailyActivityType.DA_HUO_LIN), "火麟洞活动买回没有配置");
        payback.setTimeData(activityTimeData);
    }

    void putAll(IntHashMap<SceneData> totalMap){
        for (HuoLinActivitySceneData sceneData : map.values()){
            totalMap.putUnique(sceneData.id, sceneData);
        }
    }

    public HuoLinActivitySceneData get(int id){
        return map.get(id);
    }

    /**
     * 获得这个等级该进的场景
     * @param heroLevel
     * @return
     */
    public HuoLinActivitySceneData getByHeroLevel(int heroLevel){
        int index = Utils.binarySearchForFloorKey(sortedSceneLevel, heroLevel);
        return sortedSceneData[index];
    }

    public Collection<HuoLinActivitySceneData> getAll(){
        return map.values();
    }

    HuoLinConfigProto generateProto(){
        HuoLinConfigProto.Builder builder = HuoLinConfigProto.newBuilder();

        builder.setDurationInMinute(
                activityDuration / DateTimeConstants.MILLIS_PER_MINUTE)
                .setTimeConfig(sortedSceneData[0].timeConfig)
                .setMinLevel(lowestLevel);

        for (HuoLinActivitySceneData sceneData : sortedSceneData){
            builder.addSceneProto(sceneData.generateProto());
        }

        return builder.build();
    }
}
