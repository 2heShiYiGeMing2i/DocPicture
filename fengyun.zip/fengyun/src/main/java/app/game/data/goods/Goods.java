/**
 *
 */
package app.game.data.goods;

import java.util.Comparator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.data.ConfigService;
import app.game.service.TimeService;
import app.protobuf.GoodsContent.GoodsProto;
import app.protobuf.GoodsServerContent.GoodsServerProto;
import app.protobuf.GoodsServerContent.GoodsType;
import app.protobuf.GoodsServerContent.Quality;

import com.google.common.base.Objects;
import com.google.protobuf.ByteString;
import com.mokylin.collection.IntValueLongHashMap;
import com.mokylin.sink.util.Utils;

/**
 * 物品，包含GoodsData和count
 *
 * @author Liwei
 *
 */
public class Goods{

    public static final Goods[] EMPTY_GOODS_ARRAY = new Goods[0];

    private static final Logger logger = LoggerFactory.getLogger(Goods.class);

    public static final Comparator<Goods> SORT_OUT_COMP = new Comparator<Goods>(){
        @Override
        public int compare(Goods o1, Goods o2){
            // null last (物品类型，物品id，绑定在前，过期时间早的在前，堆叠数量多的在前)

            if (o1 == o2){
                return 0; // TimSort 需要这个判断
            }

            if (o1 == null){
                return 1; // put o2 before o1
            }
            if (o2 == null){
                // o1 != null
                return -1;
            }

            if (o1.getType() != o2.getType()){
                return o1.getIntType() - o2.getIntType();
            } else if (o1.data.id != o2.data.id){
                return o1.data.id - o2.data.id;
            } else if (o1.binded != o2.binded){
                return o1.binded ? -1 : 1;
            } else if (o1.expireTime > o2.expireTime){
                return 1;
            } else if (o1.expireTime < o2.expireTime){
                return -1;
            } else{
                // same id
                return o2.getCount() - o1.getCount();
            }
        }
    };

    public boolean isSameGoods(Goods g){
        return g.isSameGoods(data, binded, expireTime);
    }

    boolean isSameGoods(GoodsData targetData, boolean targetBinded,
            long targetExpireTime){
        if (this.data == targetData && this.binded == targetBinded
                && this.expireTime == targetExpireTime){
            return true;
        }

        return false;
    }

    /**
     * 检查是否可以将物品source堆叠到target上
     *
     * @param source
     * @param target
     * @return
     */
    public boolean canFold(Goods target){
        if (target.notFull() && this.isSameGoods(target)){
            return true;
        }

        return false;
    }

    private final GoodsData data;

    private int count;

    protected boolean binded;

    protected final long expireTime;

    protected transient final int intExpireTime;

    /**
     * 此字段用于辅助整理背包，
     * 标示整理之前物品所在背包或仓库中的位置
     */
    public transient int pos;

    /**
     * 此字段用于辅助整理背包，
     * 做链表使用
     */
    transient Goods prev;

    /**
     * 此字段用于辅助整理背包，
     * 做链表使用
     */
    transient Goods next;

    /**
     * 此字段用于辅助扣除物品扣除，判断物品是否重复消耗
     */
    public transient long version;

    Goods(GoodsData data, long expireTime){
        this.data = data;
        this.count = 1;
        this.binded = false;
        this.expireTime = expireTime;
        intExpireTime = (int) (expireTime / 1000);
    }

    // for decode
    Goods(GoodsData data, int realCount, GoodsServerProto proto){
        this.data = data;
        this.binded = proto.getBinded();
        this.expireTime = proto.getExpireTime();
        intExpireTime = (int) (expireTime / 1000);
        this.count = Math.max(1, realCount);

        cacheServerProto = proto;
    }

    public boolean isBinded(){
        return binded;
    }

    public void bind(){
        this.binded = true;
    }

    public boolean isExpired(long currentTime){
        return expireTime > 0 && expireTime < currentTime;
    }

    public boolean isExpired(TimeService timeService){
        return expireTime > 0 && expireTime < timeService.getCurrentTime();
    }

    public boolean hasExpireTime(){
        return expireTime > 0;
    }

    public long getExpireTime(){
        return expireTime;
    }

    public GoodsData getData(){
        return data;
    }

    public boolean isTaskCollectGoods(){
        return data.isTaskCollectGoods();
    }

    /**
     * 品质0-白色;1-绿色;2-蓝色;3-紫色;4-橙色
     *
     * 大部分物品都读取物品本身quality，装备重写这个方法（根据附加属性条数决定）
     * @return
     */
    public Quality getQuality(){
        return data.quality;
    }

    /**
     * 品质0-白色;1-绿色;2-蓝色;3-紫色;4-橙色
     *
     * 大部分物品都读取物品本身quality，装备重写这个方法（根据附加属性条数决定）
     * @return
     */
    public int getIntQuality(){
        return getQuality().getNumber();
    }

    /**
     * 物品扔到地上的名字
     *
     * 大部分物品都读取物品本身的name，
     * @return
     */
    public byte[] getDropName(){
        return data.nameBytes;
    }

    public int getCd(){
        return data.cd;
    }

    public int getCdType(){
        return data.cdType;
    }

    public int getGcd(){
        return data.gcd;
    }

    public GoodsType getType(){
        return data.getType();
    }

    public int getIntType(){
        return data.getIntType();
    }

    void setCount(int c){
        assert c > 0 && c <= data.getMaxCount(): "物品setCount不合法";

        count = c;
    }

    void addCount(int c){
        count = Math.min(data.getMaxCount(), count + c);
    }

    public int reduceCount(int c){
        return count = Math.max(1, count - c);
    }

    /**
     * 移除物品，该物品的count清0
     */
    public void removed(){
        count = 0;
    }

    public boolean isFoldable(){
        return data.isFoldable();
    }

    public boolean notFull(){
        return count < data.getMaxCount();
    }

    public boolean useable(){
        return data.useable();
    }

    public boolean bulkUseable(){
        return data.bulkUseable();
    }

    public int getSellPrice(){
        return Utils.multiplyMoney(data.getSellPrice(), count);
    }

    public boolean hasCooldown(){
        return data.hasCooldown();
    }

    public void foldTo(Goods g){
        assert this.isSameGoods(g)
                && g.getCount() + getCount() <= data.getMaxCount();

        g.addCount(getCount());
        count = 0;
    }

    /**
     * A堆叠到B，则调用 A.fold(B, count)，此时A减少数量，B增加数量
     *
     * @param g
     */
    public void foldTo(Goods g, int c){
        assert this.isSameGoods(g) && c > 0 && c <= getCount()
                && g.getCount() + c <= data.getMaxCount();

        reduceCount(c);
        g.addCount(c);
    }

    public Goods split(int count){
        assert count > 0 && count < getCount();

        reduceCount(count);

        Goods goods = split();
        goods.count = count;
        goods.binded = binded;

        return goods;
    }

    protected Goods split(){
        return data.newGoods(expireTime);
    }

    public int getId(){
        return data.id;
    }

    public int getCount(){
        return count;
    }

    public int getMaxCount(){
        return data.getMaxCount();
    }

    @Override
    public String toString(){
        return Objects.toStringHelper("Goods").add("id", getId())
                .add("name", getData().name).add("count", count).toString();
    }

    /**
     * 包含特殊属性的物品，重写这个方法
     * @return
     */
    public byte[] encodeBytes4Client(){
        return encodeGoodsProto().toByteArray();
    }

    /**
     * 包含特殊属性的物品，重写这个方法
     * @return
     */
    public ByteString encodeByteString4Client(){
        return encodeGoodsProto().toByteString();
    }

    protected GoodsProto cacheClientProto;

    protected GoodsProto encodeGoodsProto(){
        GoodsProto proto = cacheClientProto;
        if (proto == null || binded != proto.getBinded()
                || count != proto.getCount()){
            cacheClientProto = proto = (GoodsProto) data.encodeGoodsProto(this);
        }

        return proto;
    }

    protected GoodsServerProto cacheServerProto;

    public GoodsServerProto encode(){
        GoodsServerProto proto = cacheServerProto;
        if (proto == null || binded != proto.getBinded()
                || count != proto.getCount()){
            cacheServerProto = proto = doEncode().build();
        }

        return proto;
    }

    protected GoodsServerProto.Builder doEncode(){
        GoodsServerProto.Builder builder = GoodsServerProto.newBuilder()
                .setId(data.id).setCount(count);

        if (binded){
            builder.setBinded(true);
        }

        if (expireTime > 0){
            builder.setExpireTime(expireTime);
        }

        return builder;
    }

    public static Goods decodeDontCheck(GoodsServerProto proto, ConfigService cs){
        return decode(proto, cs, null);
    }

    public static Goods decode(GoodsServerProto proto, ConfigService cs,
            IntValueLongHashMap goodsCountMap){

        int id = proto.getId();

        GoodsData data = cs.getGoods().get(id);
        if (data == null){
            logger.error("decode Goods 时候，根据proto中的ID找不到GoodsData，id: {}", id);
            return null;
        }

        return data.decode(proto, goodsCountMap);
    }

    // --- 物品 记录 ---

    /**
     * 获取物品的标示. 用在GoodsOwnership中. 装备重写了此方法
     * 不同的物品必须返回的不一样. 同 = 一模一样. encode成二进制是完全一样的
     * 不一定需要每个long能解出这个物品. 只需要不同的物品是不同的long就行
     *
     * @return
     */
    public long getGoodsIdentifier(){
        // 最右bit, 是否绑定
        // 接下来20位, 物品id
        // 7位物品类型
        // 以上28位是固定的, 每个物品都是这样
        // 再上面, 普通物品就是个过期时间（单位秒）
        return data.getGoodsIdentifier(binded, intExpireTime);
    }

    /**
     * 是否需要记录英雄物品的来龙去脉
     * @return
     */
    public boolean needLog(){
        return getData().needLog;
    }

    // --- 检测bug用. 用户得到物品后, 设置owner ---
    private long owner;

    public long getOwner(){
        return owner;
    }

    public void setOwner(long owner){
        if (this.owner != 0){
            logger.error("Goods.setOwner时, 物品的owner不为0. {}",
                    Utils.getStackTrace());
        }
        this.owner = owner;
    }

    public void clearOwner(){
        this.owner = 0;
    }
}
