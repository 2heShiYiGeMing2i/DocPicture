package app.game.data.weapon7;

import app.game.data.ConfigService;
import app.game.data.SpriteStat;
import app.game.data.spell.PassiveSpell;
import app.protobuf.HeroContent.SuperWeaponProto;
import app.protobuf.HeroServerContent.SuperWeaponServerProto;

/**
 * @author Liwei
 *
 */
public class HeroSuperWeapon{

    private final SuperWeaponData weaponData;

    // 是否解锁神兵
    private boolean hasUnlockWeapon;

    private SoulUpgradeData soulUpgradeData;

    private int weaponUpgradeTimes;

    // 是否已经解锁兵魂，使用技能书解锁
    private boolean hasUnlockSoul;

    HeroSuperWeapon(SuperWeaponData weaponData,
            SoulUpgradeData weaponUpgradeData){
        this.weaponData = weaponData;
        this.soulUpgradeData = weaponUpgradeData;
    }

    public int getId(){
        return weaponData.id;
    }

    public SuperWeaponData getData(){
        return weaponData;
    }

    public PassiveSpell getSpell(){
        return weaponData.spell;
    }

    public SpriteStat getWeaponStat(){
        return weaponData.baseStat;
    }

    public SpriteStat getTotalStat(){
        return soulUpgradeData.getTotalStat(hasUnlockWeapon);
    }

    public int getFightingAmount(){
        return hasUnlockWeapon ? weaponData.getFightingAmount() : 0;
    }

    public int getXinfaFightingAmount(){
        return soulUpgradeData.getFightingAmount();
    }

    public SoulUpgradeData getWeaponUpgradeData(){
        return soulUpgradeData;
    }

    public int incrementWeaponUpgradeTimes(){
        return ++weaponUpgradeTimes;
    }

    public void upgrade(){
        if (soulUpgradeData.nextLevel == null){
            throw new RuntimeException("神兵心法满级了还调用升级方法");
        }

        soulUpgradeData = soulUpgradeData.nextLevel;
        weaponUpgradeTimes = 0;
    }

    public SoulUpgradeData getNextLevel(){
        return soulUpgradeData.nextLevel;
    }

    public int getSoulLevel(){
        return soulUpgradeData.realLevel;
    }

    public boolean hasUnlockWeapon(){
        return hasUnlockWeapon;
    }

    public void setUnlockWeapon(){
        hasUnlockWeapon = true;
    }

    public boolean hasUnlockSoul(){
        return hasUnlockSoul;
    }

    public void setUnlockSoul(){
        hasUnlockSoul = true;
    }

    public SuperWeaponProto encode4Client(){
        SuperWeaponProto.Builder builder = SuperWeaponProto.newBuilder();
        builder.setId(weaponData.id).setUpgradePos(soulUpgradeData.index)
                .setHasUnlockWeapon(hasUnlockWeapon)
                .setHasUnlockSoul(hasUnlockSoul);

        if (soulUpgradeData.nextLevel != null){
            builder.setNextUpgradeData(soulUpgradeData.nextLevel.upgradeData
                    .getProto());
        }

        return builder.build();
    }

    public SuperWeaponServerProto encode(){
        SuperWeaponServerProto.Builder builder = SuperWeaponServerProto
                .newBuilder();

        builder.setId(weaponData.id).setUpgradePos(soulUpgradeData.index)
                .setUpgradeTimes(weaponUpgradeTimes)
                .setHasUnlockWeapon(hasUnlockWeapon)
                .setHasUnlockSoul(hasUnlockSoul);

        return builder.build();
    }

    public static HeroSuperWeapon decode(SuperWeaponServerProto proto,
            ConfigService configService){

        SuperWeaponData weaponData = configService.getSuperWeapons().get(
                proto.getId());

        if (weaponData == null)
            return null;

        SoulUpgradeData weaponUpgradeData = weaponData
                .getWeaponUpgradeData(proto.getUpgradePos());

        HeroSuperWeapon weapon = new HeroSuperWeapon(weaponData,
                weaponUpgradeData);

        weapon.weaponUpgradeTimes = proto.getUpgradeTimes();

        weapon.hasUnlockWeapon = proto.getHasUnlockWeapon();

        weapon.hasUnlockSoul = proto.getHasUnlockSoul();

        return weapon;
    }
}
