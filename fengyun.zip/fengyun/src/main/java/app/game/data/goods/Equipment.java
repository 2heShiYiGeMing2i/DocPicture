/**
 * 
 */
package app.game.data.goods;

import app.game.data.SpriteStat;
import app.game.data.SpriteStatBuilder;
import app.game.data.goods.EquipmentAddedStatGroup.SingleAddedStat;
import app.game.module.scene.FightData;
import app.protobuf.GoodsContent.EquipmentProto;
import app.protobuf.GoodsServerContent.EquipmentServerProto;
import app.protobuf.GoodsServerContent.GoodsServerProto;
import app.protobuf.GoodsServerContent.Quality;
import app.protobuf.SpriteStatContent.StatType;

import com.google.protobuf.ByteString;
import com.mokylin.sink.util.Utils;

/**
 * 装备
 * 
 * @author Liwei
 * 
 */
public class Equipment extends Goods{

    // 英雄装备

    /**
     * 武器
     */
    public static final int EQUIPMENT_TYPE_WEAPON = 0;

    /**
     * 戒指
     */
    public static final int EQUIPMENT_TYPE_RING = 1;

    /**
     * 项链
     */
    public static final int EQUIPMENT_TYPE_NECKLACE = 2;

    /**
     * 手套
     */
    public static final int EQUIPMENT_TYPE_GLOVE = 3;

    /**
     * 玉佩
     */
    public static final int EQUIPMENT_TYPE_JADE = 4;

    /**
     * 头盔
     */
    public static final int EQUIPMENT_TYPE_HELMET = 5;

    /**
     * 衣服
     */
    public static final int EQUIPMENT_TYPE_ARMOR = 6;

    /**
     * 腰带
     */
    public static final int EQUIPMENT_TYPE_WAIST = 7;

    /**
     * 裤子
     */
    public static final int EQUIPMENT_TYPE_TROUSERS = 8;

    /**
     * 鞋子
     */
    public static final int EQUIPMENT_TYPE_SHOES = 9;

    /**
     * 英雄部件装备个数
     */
    public static final int HERO_EQUIPED_MAX_COUNT = 10;

    /**
     * 默认最大强化等级
     */
    public static final int DEFAULT_REFINED_MAX_TIMES = 10;

    public static final int DEFAULT_ADDED_STAT_COUNT = 6;

    private final EquipmentData data;

    // false表示可以熔炼，true表示不能熔炼
    private final boolean isUnmeltable;

    final int refinedTimes;

    final int intStatType;

    final int intQuality;

    private transient final RefinedData refinedData;

    private final SingleAddedStat addedStat;

    /**
     * 装备总属性
     */
    private final SpriteStat totalStat;

    /**
     * 战斗值，当涉及到战斗值变化时，重新计算一遍
     */
    private final int fightingAmount;

    /**
     * 当前强化等级强化了多少次
     * 
     * 最多12个bit, 4095
     */
    private int refinedUpgradeTimes;

    Equipment(EquipmentData data, long expireTime, boolean isUnmeltable,
            int refinedTimes, int intStatType, int intQuality){
        this(data, expireTime, isUnmeltable, refinedTimes, intStatType,
                intQuality, 0);
    }

    Equipment(EquipmentData data, long expireTime, boolean isUnmeltable,
            int refinedTimes, int intStatType, int intQuality,
            int refinedUpgradeTimes){
        super(data, expireTime);
        this.data = data;
        this.isUnmeltable = isUnmeltable;
        this.refinedTimes = refinedTimes;
        this.intStatType = intStatType;
        this.intQuality = intQuality;

        this.refinedUpgradeTimes = refinedUpgradeTimes;

        refinedData = data.getRefinedData(refinedTimes);

        StatType statType = StatType.valueOf(intStatType);
        Quality quality = Quality.valueOf(intQuality);

        if (quality == null)
            quality = Quality.WHITE;

        if (statType != null){
            addedStat = data.getAddedStat(statType, quality);
        } else{
            addedStat = data.getDefaultAddedStat(quality);
        }

        SpriteStatBuilder builder = SpriteStatBuilder.newBuilder();
        builder.add(data.getBaseStat(intQuality));
        builder.add(refinedData.getRefinedStat(intQuality));
        builder.add(addedStat.getTotalStat());

        totalStat = builder.build();
        fightingAmount = FightData.calculateFightingAmount(totalStat);
    }

    // for split
    private Equipment(Equipment copy){
        super(copy.data, copy.expireTime);
        data = copy.data;
        isUnmeltable = copy.isUnmeltable;
        refinedTimes = copy.refinedTimes;
        intStatType = copy.intStatType;
        intQuality = copy.intQuality;

        refinedUpgradeTimes = copy.refinedUpgradeTimes;

        refinedData = copy.refinedData;
        addedStat = copy.addedStat;

        totalStat = copy.totalStat;
        fightingAmount = copy.fightingAmount;
    }

    public EquipmentData getData(){
        return data;
    }

    public boolean isUnmeltable(){
        return isUnmeltable;
    }

    @Override
    public byte[] getDropName(){
        return refinedData.dropName;
    }

    /**
     * 品质0-白色;1-绿色;2-蓝色;3-紫色;4-橙色
     * 装备根据附加属性条数决定
     */
    @Override
    public Quality getQuality(){
        return addedStat.quality;
    }

    public SpriteStat getTotalStat(){
        return totalStat;
    }

    public int getFightingAmount(){
        return fightingAmount;
    }

    public RefinedData getRefinedData(){
        return refinedData;
    }

    public RefinedData getNextRefinedData(){
        return refinedData.nextLevel;
    }

    public boolean isMaxRefinedTimes(){
        return refinedData.nextLevel == null;
    }

    public int getAddedStatCount(){
        return addedStat.addedStatCount;
    }

    SingleAddedStat getAddedStat(){
        return addedStat;
    }

    public EquipmentData getNextLevelEquipment(){
        return data.getNextLevelEquipment();
    }

    public boolean isValidEquipPos(int equipPos){
        return data.isValidEquipPos(equipPos);
    }

    public int getEquipType(){
        return data.getEquipType();
    }

    public boolean isWeapon(){
        return data.getEquipType() == EQUIPMENT_TYPE_WEAPON;
    }

    public boolean isArmor(){
        return data.getEquipType() == EQUIPMENT_TYPE_ARMOR;
    }

    protected Goods split(){
        return new Equipment(this);
    }

    public int getRefinedTimes(){
        return refinedData.refinedTimes;
    }

    public StatType getStatType(){
        return addedStat.getStatType();
    }

    // ---- 锻造 ----

    public int incrementRefinedUpgradeTimes(){
        return ++refinedUpgradeTimes;
    }

    public Equipment newRefinedEquipment(){
        assert expireTime == 0; // 强化的装备没有过期时间 TODO

        RefinedData newRefinedData = refinedData.nextLevel;
        if (newRefinedData == null){
            throw new RuntimeException("神马情况，满级了还强化");
        }

        Equipment equipment = new Equipment(data, 0, isUnmeltable,
                refinedTimes + 1, intStatType, intQuality);

        if (isBinded()){
            equipment.bind();
        }

        return equipment;
    }

//    public Equipment newQualityEquipment(){
//        assert expireTime == 0; // 提升品质装备没有过期时间 TODO
//
//        AddedData newAddedData = addedData.nextLevel;
//        if (newAddedData == null){
//            throw new RuntimeException("神马情况，最高品质了还提升品质");
//        }
//
//        Equipment equipment = new Equipment(data, 0, refinedData, newAddedData,
//                0);
//        if (isBinded()){
//            equipment.bind();
//        }
//
//        return equipment;
//    }

    public Equipment newLevelEquipment(){
        assert expireTime == 0; // 提升等级装备没有过期时间 TODO

        EquipmentData newEquipmentData = data.getNextLevelEquipment();
        if (newEquipmentData == null){
            throw new RuntimeException("神马情况，装备不能升级还提升等级");
        }

        Equipment equipment = newEquipmentData.newEquipment(0, isUnmeltable,
                refinedData.refinedTimes, getStatType().getNumber(),
                getQuality().getNumber());
        if (isBinded()){
            equipment.bind();
        }

        return equipment;
    }

    public void clearRefinedUpgradeTimes(){
        refinedUpgradeTimes = 0;
    }

    // ---- proto ----

    protected EquipmentProto cacheClientEquipmentProto;

    public EquipmentProto encode4ClientProto(){
        EquipmentProto proto = cacheClientEquipmentProto;
        if (proto == null || binded != proto.getBinded()){
            cacheClientEquipmentProto = proto = (EquipmentProto) data
                    .encodeGoodsProto(this);
        }

        return proto;
    }

    @Override
    public byte[] encodeBytes4Client(){
        return encode4ClientProto().toByteArray();
    }

    @Override
    public ByteString encodeByteString4Client(){
        return encode4ClientProto().toByteString();
    }

    @Override
    public GoodsServerProto encode(){
        GoodsServerProto oldProto = cacheServerProto;

        GoodsServerProto proto = super.encode();
        if (proto == oldProto){
            EquipmentServerProto equipmentProto = proto
                    .getExtension(EquipmentServerProto.goodsProto);

            if (equipmentProto == null
                    || refinedUpgradeTimes != equipmentProto
                            .getRefinedUpgradeTimes()){
                cacheServerProto = proto = doEncode().build();
            }
        }

        return proto;
    }

    @Override
    protected GoodsServerProto.Builder doEncode(){
        GoodsServerProto.Builder baseBuilder = super.doEncode();

        EquipmentServerProto equipmentProto = encodeEquipmentServerProto();
        baseBuilder.setExtension(EquipmentServerProto.goodsProto,
                equipmentProto);

        return baseBuilder;
    }

    private EquipmentServerProto encodeEquipmentServerProto(){
        EquipmentServerProto.Builder builder = EquipmentServerProto
                .newBuilder();

        if (refinedTimes > 0){
            builder.setRefinedTimes(refinedTimes);
        }

        if (intStatType > 0){
            builder.setAddedStatType(intStatType);
        }

        if (intQuality > 0){
            builder.setQuality(intQuality);
        }

        if (refinedUpgradeTimes > 0){
            builder.setRefinedUpgradeTimes(refinedUpgradeTimes);
        }

        if (isUnmeltable){
            builder.setIsUnmeltable(true);
        }

        return builder.build();
    }

    @Override
    public long getGoodsIdentifier(){
        // 最右边28bit是统一的物品信息
        return data.getGoodsIdentifier(binded, intStatType, intQuality,
                refinedTimes, refinedUpgradeTimes);
    }

    //基础熔炼值
    private static final int MELT_BASE_AMOUNT = 10;

    //    装备品质    白   绿   蓝   紫   橙
    //    品质系数    1   2   4   8   16
    private static final int[] MELT_QUALITY_COEFFICIENT = {1, 2, 4, 8, 16};

    //    装备等级    等级系数
    //    1   1
    //    20  1.5
    //    40  2.25
    //    60  3.375
    //    80  5.0625
    //    100 7.59375
    //    120 11.390625
    private static final float[] MELT_LEVEL_COEFFICIENT = {1, 1.5f, 2.25f,
            3.375f, 5.0625f, 7.59375f, 11.390625f};

    /**
     * 熔炼值
     * @return
     */
    public int getMeltAmount(){

        // 装备熔炼值=INT(基础值*品质系数*等级系数）
        return (int) (MELT_BASE_AMOUNT
                * Utils.getValidInteger(MELT_QUALITY_COEFFICIENT,
                        getIntQuality()) * Utils.getValidFloat(
                MELT_LEVEL_COEFFICIENT, data.getRequireLevel() / 20));
    }
}
