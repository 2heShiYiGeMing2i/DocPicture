package app.game.data.welfare;

import static com.mokylin.sink.util.Preconditions.*;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.data.Prize;
import app.game.data.PrizeConfig;
import app.game.data.PrizeConfigs;
import app.game.module.WelfareMessages;

import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class PlatformOneTimesPrizeData{

    public final int id;

    public final int operatorID;

    public final Prize prize;

    public final ChannelBuffer showPrizeMsg;

    public final ChannelBuffer collectPrizeMsg;

    PlatformOneTimesPrizeData(ObjectParser p, PrizeConfigs prizeConfigs){

        id = p.getIntKey("id");
        checkArgument(id > 0 && id < 32, "%s 的id必须0 < id < 32", this);

        operatorID = p.getIntKey("operator_id");

        String prizename = p.getKey("prize");

        PrizeConfig prizeConfig = checkNotNull(prizeConfigs.get(prizename),
                "%s 配置的奖励没找到", this);

        prize = prizeConfig.random();

        showPrizeMsg = WelfareMessages.getShowPlatformPrizeMsg(id, prize
                .encode4Client().toByteArray());

        collectPrizeMsg = WelfareMessages.collectPlatformPrizeMsg(id);
    }

    public String toString(){
        return "平台奖励-" + operatorID + "-" + id;
    }
}
