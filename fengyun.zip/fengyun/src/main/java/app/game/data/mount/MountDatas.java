package app.game.data.mount;

import static com.mokylin.sink.util.Preconditions.*;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.data.GameObjects;
import app.game.data.SpriteStat;
import app.game.data.SpriteStats;
import app.game.data.goods.GoodsDatas;
import app.game.data.mount.MountAddedDatas.MountAddedData;
import app.game.module.MountMessages;
import app.game.shop.Shops;
import app.protobuf.ConfigContent.MountConfig;
import app.protobuf.ConfigContent.ServiceConfig;
import app.protobuf.HeroContent.MountAddedDataProto;
import app.utils.VariableConfig;

import com.google.common.collect.Maps;
import com.google.inject.Inject;
import com.mokylin.collection.IntHashMap;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class MountDatas{

    private static final String MOUNT_DATA_LOCATION = GameObjects.MOUNT_BASE_FOLDER
            + "mount.txt";

    private static final String MOUNT_LEVEL_DATA_LOCATION = GameObjects.MOUNT_BASE_FOLDER
            + "mount_level.txt";

    private final MountData[] datas;

    private final MountData firstMountData;

    private final MountData maxLevelMountData;

    @Inject
    MountDatas(GameObjects go, SpriteStats spriteStats, GoodsDatas goodsDatas,
            Shops shops){

        List<ObjectParser> data = go.loadFile(MOUNT_LEVEL_DATA_LOCATION);
        checkArgument(!data.isEmpty(), "坐骑等级附加属性表没有配置数据");

        Map<String, IntHashMap<SpriteStat>> addedStatMap = Maps.newHashMap();
        for (ObjectParser p : data){
            String name = p.getKey("name");

            IntHashMap<SpriteStat> map = addedStatMap.get(name);
            if (map == null){
                map = new IntHashMap<>();
                addedStatMap.put(name, map);
            }

            int level = p.getIntKey("level");
            int statId = p.getIntKey("sprite_stat");
            SpriteStat addedStat = checkNotNull(spriteStats.get(statId),
                    "%s 坐骑第%s级数据没找到", name, level);
            map.putUnique(level, addedStat);
        }

        Map<String, MountAddedDatas> levelDataMap = Maps.newHashMap();
        for (Entry<String, IntHashMap<SpriteStat>> entry : addedStatMap
                .entrySet()){
            levelDataMap.put(entry.getKey(), new MountAddedDatas(
                    entry.getKey(), entry.getValue()));
        }

        data = go.loadFile(MOUNT_DATA_LOCATION);
        checkArgument(!data.isEmpty(), "坐骑表没有配置数据");

        datas = new MountData[data.size()];

        Map<String, MountData> mountMap = Maps.newHashMap();
        int idCounter = 1;
        for (ObjectParser p : data){
            MountData mountData = new MountData(idCounter++, p, spriteStats,
                    goodsDatas, levelDataMap, shops.getSystemShop());

            checkArgument(mountMap.put(mountData.name, mountData) == null,
                    "坐骑表中配置了重名的坐骑，name: %s", mountData.name);

            datas[mountData.id - 1] = mountData;

        }

        firstMountData = datas[0];
        maxLevelMountData = datas[datas.length - 1];

        MountLevelDatas levelAddedDatas = new MountLevelDatas(datas);

        MountData prev = null;
        for (MountData mountData : datas){
            mountData.levelAddedDatas = levelAddedDatas;

            if (prev != null)
                prev.nextLevel = mountData;

            prev = mountData;
        }

        // 检查参数
        prev = null;
        for (MountData mountData : datas){
            if (prev != null){
                checkArgument(
                        !mountData.baseStat.hasAnyFieldLessThan(prev.baseStat),
                        "坐骑-%s 的基础属性字段中居然存在比前一阶坐骑低的字段", mountData.name);

                checkArgument(
                        prev.addedDatas.maxLevel <= mountData.addedDatas.maxLevel,
                        "坐骑-%s 的附加属性最大等级居然小于比前一阶的附加属性最大等级", mountData.name);

                checkArgument(prev.spellSlotCount <= mountData.spellSlotCount,
                        "坐骑-%s 的技能开放个数居然小于比前一阶的技能开放个数", mountData.name);

                checkArgument(
                        prev.upgradeData.getUpgradeGoodsCount() <= mountData.upgradeData
                                .getUpgradeGoodsCount(),
                        "坐骑-%s 的进阶消耗物品个数居然小于前一阶", mountData.name);

                checkArgument(
                        prev.upgradeData.getUpgradeMoneyCost() <= mountData.upgradeData
                                .getUpgradeMoneyCost(), "坐骑-%s 的进阶消耗银两居然小于前一阶",
                        mountData.name);

                checkArgument(
                        prev.upgradeData.getUpgradeMaxBless() <= mountData.upgradeData
                                .getUpgradeMaxBless(), "坐骑-%s 的最大祝福值居然小于前一阶",
                        mountData.name);

                checkArgument(
                        prev.upgradeData.getBlessHoldTime() <= mountData.upgradeData
                                .getBlessHoldTime(), "坐骑-%s 的祝福值保留时间居然小于前一阶",
                        mountData.name);

                checkArgument(prev.openMountTime <= mountData.openMountTime,
                        "坐骑-%s 的开放时间居然小于前一阶", mountData.name);

                checkNotNull(mountData.levelAddedDatas);

                checkArgument(!prev.isMaxLevel(), "坐骑-%s 的居然是最高等级坐骑", prev.name);

                for (MountAddedData addedData : mountData.addedDatas.datas){
                    checkNotNull(addedData);
                }
            }
            prev = mountData;
        }
        checkArgument(prev.isMaxLevel(), "坐骑-%s 的居然不是最高等级坐骑", prev.name);

    }

    public MountData getFirstMount(){
        return firstMountData;
    }

    public MountData get(int id){

        if (id > 0 && id <= datas.length){
            return datas[id - 1];
        }

        if (id <= 0){
            return firstMountData;
        }

        return maxLevelMountData;
    }

    public void setMountOpenTime(ServiceConfig.Builder builder,
            long startServiceTime){
        for (MountData data : datas){
            if (data.openMountTime > 0){
                builder.addMountOpenTime(data.openMountTime + startServiceTime);
            } else{
                builder.addMountOpenTime(0);
            }
        }
    }

    public MountConfig generateProto(VariableConfig variableConfig){
        MountConfig.Builder builder = MountConfig.newBuilder();

        for (MountData data : datas){
            builder.addMounts(data.encode());
        }

        builder.setCollectMountLevel(variableConfig.COLLECT_FREE_MOUNT_LEVEL);

        return builder.build();
    }

    public static class MountLevelDatas{

        private final int maxLevel;

        final MountLevelData[] levelDatas;

        /**
         * 一级数据
         */
        final transient MountLevelData oneLevelData;

        /**
         * 最高级数据
         */
        final transient MountLevelData maxLevelData;

        MountLevelDatas(MountData[] datas){

            maxLevel = VariableConfig.HERO_MAX_LEVEL;
            levelDatas = new MountLevelData[maxLevel];

            int mountCount = datas.length;
            for (int lv = 1; lv <= maxLevel; lv++){
                MountAddedData[] addedDatas = new MountAddedData[mountCount];
                for (int i = 0; i < mountCount; i++){
                    addedDatas[i] = checkNotNull(datas[i].getAddedData(lv));
                }

                levelDatas[lv - 1] = new MountLevelData(lv, addedDatas);
            }

            oneLevelData = levelDatas[0];
            maxLevelData = levelDatas[maxLevel - 1];
        }

        public MountLevelData getLevelData(int level){
            if (level > 0 && level <= maxLevel){
                return levelDatas[level - 1];
            }

            if (level > maxLevel){
                return maxLevelData;
            }

            return oneLevelData;
        }
    }

    /**
     * 每一级
     * @author Liwei
     *
     */
    public static class MountLevelData{

        private final int mountCount;

        final int level;

        final MountAddedData[] addedDatas;

        final transient MountAddedDataProto proto;

        /**
         * 缓存每一个坐骑与其他坐骑之间的属性差值，
         * 用于在切换坐骑的时候不用去计算属性差，这里先计算好
         * 
         * 数值下标: (sourceMountId - 1) * 坐骑总数 + (targetMountId - 1)
         */
        final SpriteStat[] mountStatDiffArray;

        final transient ChannelBuffer updateAddedDataMsg;

        MountLevelData(int level, MountAddedData[] addedDatas){
            mountCount = addedDatas.length;

            this.level = level;
            this.addedDatas = addedDatas;

            mountStatDiffArray = new SpriteStat[mountCount * mountCount];
            for (int sourceMountId = 1; sourceMountId <= mountCount; sourceMountId++){
                SpriteStat sourceMountStat = addedDatas[sourceMountId - 1].baseAndAddedStat;
                for (int targetMountId = 1; targetMountId <= mountCount; targetMountId++){
                    if (sourceMountId == targetMountId){
                        mountStatDiffArray[getDiffStatIndex(sourceMountId,
                                targetMountId)] = SpriteStat.EMPTY_STAT;
                    } else{
                        SpriteStat targetMountStat = addedDatas[targetMountId - 1].baseAndAddedStat;

                        mountStatDiffArray[getDiffStatIndex(sourceMountId,
                                targetMountId)] = targetMountStat
                                .remove(sourceMountStat);
                    }
                }
            }

            for (int i = 0; i < mountStatDiffArray.length; i++){
                checkNotNull(mountStatDiffArray[i]);
            }

            proto = encode();

            updateAddedDataMsg = MountMessages.updateMountAddedDataMsg(proto);
        }

        public SpriteStat getDiffStat(int sourceMountId, int targetMountId){
            assert sourceMountId > 0 && sourceMountId <= mountCount;
            assert targetMountId > 0 && targetMountId <= mountCount;
            assert sourceMountId != targetMountId;

            return mountStatDiffArray[getDiffStatIndex(sourceMountId,
                    targetMountId)];
        }

        private int getDiffStatIndex(int sourceMountId, int targetMountId){
            return (sourceMountId - 1) * mountCount + (targetMountId - 1);
        }

        private MountAddedDataProto encode(){
            MountAddedDataProto.Builder builder = MountAddedDataProto
                    .newBuilder();

            for (MountAddedData data : addedDatas){
                builder.addAddedStat(data.addedStatProto);
                builder.addAddedFightingAmount(data.addedFightingAmount);
            }

            return builder.build();
        }
    }
}
