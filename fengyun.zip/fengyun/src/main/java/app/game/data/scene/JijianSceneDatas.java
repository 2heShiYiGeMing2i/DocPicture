package app.game.data.scene;

import static com.mokylin.sink.util.Preconditions.*;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.data.ActivityPayback;
import app.game.data.ActivityPaybacks;
import app.game.data.GameObjects;
import app.game.data.TimeData;
import app.game.data.goods.GoodsDatas;
import app.protobuf.ConfigContent.DailyActivityType;
import app.protobuf.ConfigContent.JijianDungeonProto;

import com.google.inject.Inject;
import com.mokylin.collection.IntHashMap;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class JijianSceneDatas{

    private static final Logger logger = LoggerFactory
            .getLogger(JijianSceneDatas.class);

    public static final String LOCATION = GameObjects.JI_JIAN_SCENE_BASE_FOLDER
            + "jijian_dungeon.txt";

    private final JijianSceneData sceneData;

    private final TimeData timeData;

    @Inject
    JijianSceneDatas(GameObjects go, BlockInfos blocks, MonsterDatas monsters,
            Scripts scripts, Plunders plunders, Ais ais,
            SceneTransportDatas transports,
            SceneRemoveObjectMsgCache removeMsgCache, GoodsDatas goodsDatas,
            ActivityPaybacks paybacks){
        logger.debug("loading sword_sacrifice dungeon scenes");

        List<ObjectParser> list = go.loadFile(LOCATION);

        checkArgument(list.size() == 1, "必须有且只有一条祭剑副本的配置: %s", LOCATION);

        ObjectParser p = list.get(0);

        sceneData = new JijianSceneData(go, p, blocks, monsters, scripts,
                plunders, ais, transports, removeMsgCache, goodsDatas);

        timeData = TimeData.parse("[*][*][*][" + sceneData.startTimeHour + ":"
                + sceneData.startTimeMinute + "]");

        ActivityPayback payback = checkNotNull(
                paybacks.get(DailyActivityType.DA_JIJIAN), "祭剑活动买回没有配置");
        payback.setTimeData(timeData);
    }

    public TimeData getTimeData(){
        return timeData;
    }

    public JijianSceneData getSceneData(){
        return sceneData;
    }

    void putAll(IntHashMap<SceneData> totalMap){
        totalMap.putUnique(sceneData.id, sceneData);
    }

    public JijianDungeonProto generateProto(){
        JijianDungeonProto.Builder builder = JijianDungeonProto.newBuilder();
        sceneData.generateProto(builder);

        return builder.build();
    }
}
