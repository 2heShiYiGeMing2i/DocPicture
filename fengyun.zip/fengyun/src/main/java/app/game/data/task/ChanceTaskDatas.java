package app.game.data.task;

import static com.mokylin.sink.util.Preconditions.*;

import java.util.EnumMap;
import java.util.List;

import app.game.data.GameObjects;
import app.game.data.PrizeConfigs;
import app.game.data.QualityRelatedData;
import app.game.data.QualityRelatedDatas;
import app.game.data.goods.GoodsDatas;
import app.game.data.scene.CollectObjects;
import app.game.data.scene.MonsterData;
import app.game.data.scene.MonsterDatas;
import app.game.data.scene.Npcs;
import app.game.data.scene.SceneDatas;
import app.protobuf.ConfigContent.TaskConfig;
import app.protobuf.GoodsServerContent.Quality;
import app.utils.VariableConfig;

import com.google.common.collect.Lists;
import com.mokylin.collection.IntHashMap;
import com.mokylin.sink.util.RandomNumber;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class ChanceTaskDatas{

    static final String LOCATION = "config/data/task/chance_task.txt";

    public static final int QUALITY_COUNT = 5;

    private final IntHashMap<ChanceTaskData> chanceTaskMap;

    private final EnumMap<Quality, ChanceTaskGroup> qualityTaskMap;

    private final ChanceTaskGroup compensateTaskGroup;

    ChanceTaskDatas(GameObjects go, Npcs npcs, GoodsDatas goodsDatas,
            MonsterDatas monsters, PrizeConfigs prizes,
            CollectObjects collectObjects, SceneDatas sceneDatas,
            IntHashMap<MonsterData> monLevelMap,
            QualityRelatedDatas relatedDatas){

        List<ObjectParser> data = go.loadFile(LOCATION);
        checkArgument(!data.isEmpty(), "机缘任务没有配置");

        chanceTaskMap = new IntHashMap<>();
        for (ObjectParser p : data){
            ChanceTaskData task = new ChanceTaskData(p, npcs, goodsDatas,
                    monsters, prizes, collectObjects, sceneDatas, monLevelMap,
                    relatedDatas);

            chanceTaskMap.putUnique(task.id, task);
        }

        EnumMap<Quality, List<ChanceTaskData>> map = new EnumMap<>(
                Quality.class);
        for (ChanceTaskData task : chanceTaskMap.values()){
            List<ChanceTaskData> list = map.get(task.quality);
            if (list == null){
                list = Lists.newLinkedList();
                map.put(task.quality, list);
            }

            list.add(task);
        }

        qualityTaskMap = new EnumMap<>(Quality.class);
        for (Quality quality : Quality.values()){
            if (quality == Quality.ORANGE){
                // 橙色机缘任务可能是没有的，所以在这里如果没有配置橙色任务，就不检查这一项了
                if (map.get(quality) == null)
                    continue;

                // 有的话还是检查以下
            }

            List<ChanceTaskData> tasks = checkNotNull(map.get(quality),
                    "品质-%s 的机缘任务没有配置", quality);

            qualityTaskMap.put(quality, new ChanceTaskGroup(quality, tasks));
        }

        compensateTaskGroup = checkNotNull(qualityTaskMap.get(Quality.PURPLE),
                "机缘任务补偿列表不存在，品质：%s", Quality.PURPLE);
    }

    ChanceTaskData get(int id){
        return chanceTaskMap.get(id);
    }

    ChanceTaskData randomCompensateTask(int level){
        return compensateTaskGroup.random(level);
    }

    ChanceTaskData random(Quality quality, int level){

        ChanceTaskGroup group = qualityTaskMap.get(quality);

        if (group == null){
            return null;
        }

        return group.random(level);
    }

    private static class ChanceTaskGroup{

        final ChanceTaskData[][] levelTaskDatas;

        ChanceTaskGroup(Quality quality, List<ChanceTaskData> tasks){

            IntHashMap<List<ChanceTaskData>> taskLevelMap = new IntHashMap<>();
            for (ChanceTaskData task : tasks){
                checkArgument(task.quality == quality, "机缘任务初始化时发现品质不对");

                for (int lv = task.minLevel; lv <= task.maxLevel; lv++){
                    List<ChanceTaskData> list = taskLevelMap.get(lv);
                    if (list == null){
                        list = Lists.newLinkedList();
                        taskLevelMap.put(lv, list);
                    }

                    list.add(task);
                }
            }

            levelTaskDatas = new ChanceTaskData[VariableConfig.HERO_MAX_LEVEL][];
            for (int lv = 1; lv <= VariableConfig.HERO_MAX_LEVEL; lv++){
                List<ChanceTaskData> taskList = taskLevelMap.get(lv);
                if (taskList == null){
                    if (lv <= 1)
                        throw new IllegalArgumentException("没有找到" + lv
                                + "级的机缘任务");

                    levelTaskDatas[lv - 1] = levelTaskDatas[lv - 2];
                    continue;
                }

                levelTaskDatas[lv - 1] = taskList
                        .toArray(ChanceTaskData.EMPTY_ARRAY);
            }
        }

        ChanceTaskData random(int level){
            ChanceTaskData[] taskDatas = null;

            if (level > 0 && level <= levelTaskDatas.length){
                taskDatas = levelTaskDatas[level - 1];
            } else if (level <= 0){
                taskDatas = levelTaskDatas[0];
            } else{
                taskDatas = levelTaskDatas[levelTaskDatas.length - 1];
            }

            return taskDatas[RandomNumber.getRate(taskDatas.length, true)];
        }
    }

    void generateProto(TaskConfig.Builder builder,
            QualityRelatedDatas relatedDatas){

        builder.setChanceTaskAcceptableCount(VariableConfig.CHANCE_TASK_ACCEPTABLE_COUNT);
        builder.setChanceTaskMaxCount(VariableConfig.CHANCE_TASK_MAX_COUNT);
        builder.setChanceTaskSwallowableCount(VariableConfig.CHANCE_TASK_SWALLOWABLE_COUNT);
        builder.setChanceTaskSwallowableVipAddCount(VariableConfig.CHANCE_TASK_SWALLOWABLE_VIP_ADD_COUNT);
        builder.setChanceTaskSwallowCost(VariableConfig.CHANCE_TASK_SWALLOW_COST);

        for (Quality quality : relatedDatas.qualityLevelArray){
            QualityRelatedData data = relatedDatas.get(quality);

            builder.addAutoCompleteCost(data.autoCompleteCost);
            builder.addAutoCompleteLimit(data.autoCompleteLimit);
            builder.addSwallowMinPercent(data.swallowMinPercent);
            builder.addSwallowMaxPercent(data.swallowMaxPercent);
        }
    }
}
