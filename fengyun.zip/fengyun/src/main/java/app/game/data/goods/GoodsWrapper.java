package app.game.data.goods;

import java.util.ArrayList;
import java.util.List;

import app.game.data.ConfigService;
import app.game.data.goods.GoodsRandomer.ExpireTimeType;
import app.protobuf.GoodsContent.GoodsWrapperProto;
import app.protobuf.HeroServerContent.GoodsWrapperServerProto;

import com.google.protobuf.ByteString;
import com.mokylin.sink.util.Utils;

/**
 * @author Liwei
 *
 */
public class GoodsWrapper{

    public static final GoodsWrapper[] EMPTY_ARRAY = new GoodsWrapper[0];

    private final GoodsData data;

    private final boolean binded;

    private final int count;

    private transient final int needEmptyPosCount;

    private final long expireTime;

    private final int duration;

    // 装备特有
    private final boolean isUnmeltable;

    private final int refinedTimes;

    private final int statType;

    // 装备的品质
    private final int quality;

    // 用于展示
    private final ByteString dynamicData;

    private transient GoodsWrapperProto clientProto;

    private transient GoodsWrapperServerProto serverProto;

    protected transient final ExpireTimeType type;

    // 0-无特殊标签 1-全服唯一标签 2-非卖品 3-稀有
    private final int tab;

    private GoodsWrapper(GoodsWrapper copy, int count){
        this.data = copy.data;
        this.binded = copy.binded;
        this.count = count;
        this.expireTime = copy.expireTime;
        this.duration = copy.duration;
        this.isUnmeltable = copy.isUnmeltable;
        this.refinedTimes = copy.refinedTimes;
        this.statType = copy.statType;
        this.quality = copy.quality;
        this.dynamicData = copy.dynamicData;
        this.type = copy.type;
        this.tab = copy.tab;

        needEmptyPosCount = Utils.divide(count, data.getMaxCount());
    }

    private GoodsWrapper(GoodsData data, GoodsWrapperServerProto proto){
        this.data = data;

        this.binded = proto.getBinded();
        this.count = proto.getCount();
        this.expireTime = proto.getExpireTime();
        this.duration = proto.getDuration();
        this.isUnmeltable = proto.getIsUnmeltable();
        this.refinedTimes = proto.getRefinedTimes();
        this.statType = proto.getAddedStatType();
        this.quality = proto.getQuality();
        this.tab = 0;

        needEmptyPosCount = Utils.divide(count, data.getMaxCount());

        if (expireTime > 0){
            type = ExpireTimeType.EXPIRE_TIME;
        } else if (duration > 0){
            type = ExpireTimeType.DURATION;
        } else{
            type = ExpireTimeType.NEVER;
        }

        if (data instanceof EquipmentData){
            dynamicData = ((EquipmentData) data).encodeGoodsProto(binded,
                    expireTime, refinedTimes, quality, statType).toByteString();
        } else if (data instanceof MountEquipmentData){
            dynamicData = ((MountEquipmentData) data).encodeGoodsProto(binded,
                    expireTime, refinedTimes, quality, statType).toByteString();
        } else{
            dynamicData = data.encodeGoodsProto(count, binded, expireTime)
                    .toByteString();
        }
    }

    GoodsWrapper(GoodsData data, boolean binded, int count, long expireTime,
            int duration, int tab){
        this(data, binded, count, expireTime, duration, false, 0, 0, 0, tab);
    }

    public GoodsWrapper(GoodsData data, boolean binded, int count,
            long expireTime, int duration, boolean isUnmeltable,
            int refinedTimes, int quality, int statType, int tab){
        this.data = data;
        this.binded = binded;
        this.count = count;
        this.expireTime = expireTime;
        this.duration = duration;
        this.isUnmeltable = isUnmeltable;
        this.refinedTimes = refinedTimes;
        this.statType = statType;
        this.quality = quality;
        this.tab = tab;

        needEmptyPosCount = Utils.divide(count, data.getMaxCount());

        if (expireTime > 0){
            type = ExpireTimeType.EXPIRE_TIME;
        } else if (duration > 0){
            type = ExpireTimeType.DURATION;
        } else{
            type = ExpireTimeType.NEVER;
        }

        if (data instanceof EquipmentData){
            dynamicData = ((EquipmentData) data).encodeGoodsProto(binded,
                    expireTime, refinedTimes, quality, statType).toByteString();
        } else if (data instanceof MountEquipmentData){
            dynamicData = ((MountEquipmentData) data).encodeGoodsProto(binded,
                    expireTime, refinedTimes, quality, statType).toByteString();
        } else{
            dynamicData = data.encodeGoodsProto(count, binded, expireTime)
                    .toByteString();
        }

//        if (expireTime > 0 || duration > 0){
//            checkArgument(data.dropable || data.canSell(),
//                    "%s 不能丢不能卖，但是配置了过期时间，真是太过分了", data);
//        }
    }

    public GoodsWrapper setCount(int count){
        assert count > 0;
        if (this.count == count){
            return this;
        }
        return new GoodsWrapper(this, count);
    }

    /**
     * 两个GoodsWrapper是否能叠加. 即除了count其他是否都相同
     * @param other
     * @return
     */
    public boolean canStack(GoodsWrapper other){
        return data == other.data && binded == other.binded
                && expireTime == other.expireTime && duration == other.duration
                && refinedTimes == other.refinedTimes
                && statType == other.statType && quality == other.quality;
    }

    public static GoodsWrapper[] parse(Object parent, GoodsDatas goodsDatas,
            String[] prizeGoodsStr){
        if (prizeGoodsStr.length == 0){
            return GoodsWrapper.EMPTY_ARRAY;
        }

        List<GoodsWrapper> result = new ArrayList<>(prizeGoodsStr.length);
        for (String s : prizeGoodsStr){
            if (s.length() == 0){
                continue;
            }
            GoodsRandomer gr = GoodsRandomer.newRandomer(parent, s, goodsDatas);
            result.add(gr.getGoodsWrapper());
        }

        return result.toArray(GoodsWrapper.EMPTY_ARRAY);
    }

    public static GoodsWrapper parse(Object parent, GoodsDatas goodsDatas,
            String prizeGoodsStr){
        GoodsRandomer gr = GoodsRandomer.newRandomer(parent, prizeGoodsStr,
                goodsDatas);
        return gr.getGoodsWrapper();
    }

    public GoodsData getData(){
        return data;
    }

    public int getNeedEmptyPosCount(){
        return needEmptyPosCount;
    }

    public int getCount(){
        return count;
    }

    public boolean isBinded(){
        return binded;
    }

    public long getExpireTime(){
        return expireTime;
    }

//    Goods create(long ctime){
//        assert count > 0 && count <= data.getMaxCount(): "GoodsWrapper创建物品时，count无效";
//
//        return create(ctime, count);
//    }

    private Goods create(long ctime, int count){
        assert count >= 0 && count <= data.maxCount;

        Goods g = null;
        if (data instanceof EquipmentData){
            g = ((EquipmentData) data).newEquipment(getGoodsExpireTime(ctime),
                    isUnmeltable, refinedTimes, statType, quality);
        } else if (data instanceof MountEquipmentData){
            g = ((MountEquipmentData) data).newEquipment(
                    getGoodsExpireTime(ctime), refinedTimes, statType, quality);
        } else{
            g = data.newGoods(getGoodsExpireTime(ctime));
        }
        g.setCount(count);

        if (binded)
            g.bind();

        return g;
    }

    public long getGoodsIdentifier(long ctime){
        if (data instanceof EquipmentData){
            return ((EquipmentData) data).getGoodsIdentifier(binded, statType,
                    quality, refinedTimes, 0);
        } else if (data instanceof MountEquipmentData){
            return ((MountEquipmentData) data).getGoodsIdentifier(binded,
                    statType, quality, refinedTimes);
        }

        return data.getGoodsIdentifier(binded,
                (int) (getGoodsExpireTime(ctime) / 1000));
    }

    private long getGoodsExpireTime(long ctime){
        switch (type){
            case EXPIRE_TIME:{
                return expireTime;
            }
            case DURATION:{
                return ctime + duration;
            }
            default:{
                return 0;
            }
        }
    }

    public void cacheProto(){
        clientProto = doEncode4Client();
    }

    public GoodsWrapperProto encode4Client(){
        return clientProto != null ? clientProto : doEncode4Client();
    }

    private GoodsWrapperProto doEncode4Client(){
        GoodsWrapperProto.Builder builder = GoodsWrapperProto.newBuilder();

        builder.setStaticData(data.getProtoByteString())
                .setDynamicData(dynamicData).setCount(count);

        if (binded){
            builder.setBinded(true);
        }

        if (expireTime > 0){
            builder.setExpireTime(expireTime);
        }

        if (duration > 0){
            builder.setDuration(duration);
        }

        if (tab > 0){
            builder.setTab(tab);
        }

        return builder.build();
    }

    public GoodsWrapperServerProto encode(){
        if (serverProto == null){
            serverProto = doEncode();
        }
        return serverProto;
    }

    private GoodsWrapperServerProto doEncode(){
        GoodsWrapperServerProto.Builder builder = GoodsWrapperServerProto
                .newBuilder();

        builder.setId(data.getId());

        if (count > 0){
            builder.setCount(count);
        }

        if (binded){
            builder.setBinded(true);
        }

        if (expireTime > 0){
            builder.setExpireTime(expireTime);
        }

        if (duration > 0){
            builder.setDuration(duration);
        }

        if (isUnmeltable){
            builder.setIsUnmeltable(isUnmeltable);
        }

        if (refinedTimes > 0){
            builder.setRefinedTimes(refinedTimes);
        }

        if (quality > 0){
            builder.setQuality(quality);
        }

        if (statType > 0){
            builder.setAddedStatType(statType);
        }

        return builder.build();
    }

    public static GoodsWrapper decode(GoodsWrapperServerProto proto,
            ConfigService configService){

        GoodsData data = configService.getGoods().get(proto.getId());
        if (data == null){
            return null;
        }

        return new GoodsWrapper(data, proto);
    }

    @Override
    public int hashCode(){
        return data.id;
    }

    @Override
    public boolean equals(Object obj){
        if (obj instanceof GoodsWrapper){
            GoodsWrapper other = (GoodsWrapper) obj;
            return canStack(other);
        }
        return false;
    }

    public GoodsAddHelper newHelper(long ctime){
        return newHelper(ctime, count);
    }

    public GoodsAddHelper newHelper(long ctime, int count){
        return new WrapGoodsAddHelper(this, count, ctime);
    }

    private static class WrapGoodsAddHelper extends GoodsAddHelper{

        private final GoodsWrapper goodsWrapper;

        private final long ctime;

        private WrapGoodsAddHelper(GoodsWrapper goodsWrapper, int count,
                long ctime){
            super(goodsWrapper.getData(), count, goodsWrapper.binded,
                    goodsWrapper.getGoodsExpireTime(ctime));
            this.goodsWrapper = goodsWrapper;
            this.ctime = ctime;
        }

        @Override
        public Goods create(){
            assert count > 0: "ShopGoodsHolder的count<=0，还调用create()";

            if (count <= 0){
                return null; // 防御性
            }

            int c = data.getMaxCount();
            if (count > data.getMaxCount()){
                count -= data.getMaxCount();
            } else{
                c = count;
                count = 0;
            }

            return goodsWrapper.create(ctime, c);
        }

        public long getGoodsIdentifier(){
            return goodsWrapper.getGoodsIdentifier(ctime);
        }
    }
}
