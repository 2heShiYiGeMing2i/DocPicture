package app.game.data.spell;

import static com.mokylin.sink.util.Preconditions.checkArgument;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import app.game.data.GameObjects;
import app.protobuf.ConfigContent.AnimationConfig;

import com.google.inject.Inject;
import com.mokylin.sink.util.parse.ObjectParser;

public class Animations{

    public static final String LOCATION = GameObjects.SPELL_BASE_FOLDER
            + "animation.txt";

    private final Map<String, Animation> map;

    @Inject
    Animations(GameObjects go){
        List<ObjectParser> list = go.loadFile(LOCATION);

        map = new HashMap<String, Animation>(list.size());

        int idCounter = 0;
        for (ObjectParser p : list){
            Animation animation = new Animation(++idCounter, p);
            checkArgument(map.put(animation.name, animation) == null,
                    "特效的名字重复: %s", animation.name);
        }
    }

    public Animation get(String name){
        return map.get(name);
    }

    public AnimationConfig generateProto(){
        AnimationConfig.Builder builder = AnimationConfig.newBuilder();
        for (Animation a : map.values()){
            builder.addAnimations(a.generateProto());
        }
        return builder.build();
    }
}
