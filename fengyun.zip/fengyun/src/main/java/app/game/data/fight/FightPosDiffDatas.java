package app.game.data.fight;

import static com.mokylin.sink.util.Preconditions.checkArgument;

import java.util.List;

import app.game.data.GameObjects;
import app.game.data.PrizeConfigs;
import app.protobuf.ConfigContent.FightConfig;

import com.google.inject.Inject;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class FightPosDiffDatas{

    private static final String LOCATION = "config/data/fight/fight_prize.txt";

    private final FightPosDiffData[] datas;

    private final FightPosDiffData lastData;

    @Inject
    FightPosDiffDatas(GameObjects go, PrizeConfigs prizeConfigs){
        List<ObjectParser> data = go.loadFile(LOCATION);
        checkArgument(!data.isEmpty(), "个人竞技场奖励数据表没有配置数据");

        datas = new FightPosDiffData[data.size() - 1];

        int prevPos = 0;
        ObjectParser prevParser = null;
        int i = 0;
        for (ObjectParser p : data){
            int pos = p.getIntKey("pos");
            checkArgument(pos > prevPos,
                    "个人竞技场奖励数据表配置的居然比前一个还大，pos:%s  prev: %s", pos, prevPos);

            if (prevParser == null){
                prevPos = pos;
                prevParser = p;
                checkArgument(pos == 1,
                        "个人竞技场奖励数据表配置的第一个数据居然不是第一名的奖励, pos: %s", pos);
                continue;
            }

            datas[i++] = new FightPosDiffData(prevPos, pos, prevParser,
                    prizeConfigs);

            prevPos = pos;
            prevParser = p;
        }

        lastData = new FightPosDiffData(prevPos, Integer.MAX_VALUE, prevParser,
                prizeConfigs);
    }

    public FightPosDiffData get(int pos){

        if (pos <= 0 || pos >= lastData.startPos)
            return lastData;

        for (FightPosDiffData p : datas){
            if (pos >= p.startPos && pos < p.endPos){
                return p;
            }
        }

        return lastData;
    }

    public FightPosDiffData getLastPosDiffData(){
        return lastData;
    }

    public void encode(FightConfig.Builder builder){

        for (FightPosDiffData data : datas){
            builder.addDiffData(data.encode());
        }
        builder.addDiffData(lastData.encode());
    }
}
