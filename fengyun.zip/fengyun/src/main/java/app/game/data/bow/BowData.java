package app.game.data.bow;

import static com.mokylin.sink.util.Preconditions.*;

import java.util.Arrays;
import java.util.List;

import org.jboss.netty.buffer.ChannelBuffer;
import org.joda.time.DateTimeConstants;

import app.game.data.SpriteStat;
import app.game.data.SpriteStats;
import app.game.data.UpgradeData;
import app.game.data.goods.GoodsData;
import app.game.data.goods.GoodsDatas;
import app.game.data.spell.PassiveSpell;
import app.game.module.BowMessages;
import app.game.module.scene.FightData;
import app.game.shop.VendingMachine;
import app.protobuf.ConfigContent.BowDataProto;

import com.google.common.collect.Lists;
import com.mokylin.collection.IntHashMap;
import com.mokylin.sink.util.RandomNumber;
import com.mokylin.sink.util.parse.ObjectParser;

/**
 * @author Liwei
 *
 */
public class BowData{

    /**
     * 阶级，1阶为1,2阶为2
     */
    public final int id;

    /**
     * 名字
     */
    final String name;

    /**
     * 基础属性
     */
    final SpriteStat baseStat;

    /**
     * 基础战斗力
     */
    final transient int fightingAmount;

    /**
     * 进阶数据
     */
    final UpgradeData upgradeData;

    /**
     * 进阶成功后是否广播全服
     */
    final boolean isUpgradeBroadcast;

    /**
     * 技能开放个数
     */
    final int openSpellCount;

    /**
     * 触发技能个数
     */
    final int trigSpellCount;

    /**
     * 效果图标
     */
    final String effectIcon;

    /**
     * 效果名称
     */
    final String effectName;

    /**
     * 效果描述
     */
    final String effectDesc;

    /**
     * 开放弓箭时间
     */
    volatile long openBowTime;

    private transient final ChannelBuffer upgradeMsg;

    transient final PassiveSpell[] bowSpells;

    transient final BowSpellRandomer[] spellRandomers;

    private transient final ChannelBuffer changeResourceMsg;

    BowData nextLevel;

    BowData(ObjectParser p, SpriteStats spriteStats, GoodsDatas goodsDatas,
            VendingMachine systemShop, BowSpell spell){
        this.id = p.getIntKey("id");
        checkArgument(id < 16, "在凤舞排行榜中用了位移处理ID，因此如果阶数超过15阶，需要同时修改排行榜");

        name = p.getKey("name");
        checkArgument(!name.isEmpty(), "凤舞弓 %s 的名字没有配置", this);

        int statId = p.getIntKey("base_stat");
        baseStat = checkNotNull(spriteStats.get(statId),
                "凤舞箭 %s 配置的基础属性没找到, %s", this, statId);
        int fightingAmount = FightData.calculateFightingAmount(baseStat);

        upgradeData = new UpgradeData(this, p, goodsDatas, systemShop);
        upgradeData.setCustomAuctionType(GoodsData.BOW_AUCTION_TYPE);

        checkArgument(upgradeData.getUpgradeGoodsYuanbaoPrice() > 0,
                "凤舞弓 %s 的升级物品没有配置元宝价格", this);

        isUpgradeBroadcast = p.getBooleanKey("is_upgrade_broadcast");

        openSpellCount = p.getIntKey("spell_count");

        checkArgument(openSpellCount <= spell.spellCount,
                "凤舞弓 %s 开放的技能个数比弓箭技能总个数还多？", this);

        trigSpellCount = p.getIntKey("trigger_spell_count");
        checkArgument(trigSpellCount <= spell.spellCount,
                "凤舞弓 %s 的触发技能个数比弓箭技能总个数还多？", this);

        effectIcon = p.getKey("effect_icon");
        effectName = p.getKey("effect_name");
        effectDesc = p.getKey("effect_desc");

        checkArgument(!effectIcon.isEmpty(), "凤舞箭 %s 的效果icon没有配置", this);
        checkArgument(!effectName.isEmpty(), "凤舞箭 %s 的效果名称没有配置", this);
        checkArgument(!effectDesc.isEmpty(), "凤舞箭 %s 的效果描述没有配置", this);

        int openInterval = p.getIntKey("open_interval");
        checkArgument(openInterval >= 0, "凤舞弓 %s 配置的开放时间必须大于等级0", this);

        openBowTime = ((long) openInterval)
                * DateTimeConstants.MILLIS_PER_MINUTE;

        upgradeMsg = BowMessages.upgradeBowSuccess(id);

        changeResourceMsg = BowMessages.changeBowResourceMsg(id);

        bowSpells = Arrays.copyOf(spell.spellList, openSpellCount);
        for (PassiveSpell ps : bowSpells){
            fightingAmount += ps.getFightingAmount();
        }
        this.fightingAmount = fightingAmount;

        // 缓存所有的技能组合
        spellRandomers = new BowSpellRandomer[openSpellCount];
        if (openSpellCount > 1){

            // 二进制1表示技能存在
            int maxValue = (1 << openSpellCount) - 1;

            // 不包含maxValue，maxValue就是全1，只有一种情况
            IntHashMap<List<PassiveSpell[]>> map = new IntHashMap<>();

            List<PassiveSpell> pslist = Lists.newArrayList();
            for (int i = 1; i < maxValue; i++){
                int bitCount = Integer.bitCount(i);

                List<PassiveSpell[]> list = map.get(bitCount);
                if (list == null){
                    list = Lists.newArrayList();
                    map.put(bitCount, list);
                }

                for (int o = 0; o < openSpellCount; o++){
                    if (((i >> o) & 1) == 1){
                        pslist.add(bowSpells[o]);
                    }
                }
                list.add(pslist.toArray(PassiveSpell.EMPTY_ARRAY));

                checkArgument(pslist.size() == bitCount);
                pslist.clear();
            }

            checkArgument(map.size() == openSpellCount - 1);
            for (int i = 1; i < openSpellCount; i++){
                List<PassiveSpell[]> list = checkNotNull(map.get(i));

                for (PassiveSpell[] arr : list){
                    checkArgument(arr.length == i);
                    for (PassiveSpell ps : arr){
                        checkArgument(ps != null);
                    }
                }

                if (list.size() == 1){
                    spellRandomers[i - 1] = new SingleBowSpellRandomer(
                            list.get(0));
                } else{
                    spellRandomers[i - 1] = new MultiBowSpellRandomer(list);
                }
            }

            checkArgument(spellRandomers[openSpellCount - 1] == null);
            spellRandomers[openSpellCount - 1] = new SingleBowSpellRandomer(
                    bowSpells);
        }

    }

    public int getId(){
        return id;
    }

    public HeroBow newBow(){
        return new HeroBow(this);
    }

    public long getOpenTime(long startServiceTime){
        if (openBowTime > 0){
            return startServiceTime + openBowTime;
        }
        return 0;
    }

    public UpgradeData getUpgradeData(){
        return upgradeData;
    }

    public boolean isUpgradeBroadcast(){
        return isUpgradeBroadcast;
    }

    public BowData getNextLevel(){
        return nextLevel;
    }

    public ChannelBuffer getUpgradeMsg(){
        return upgradeMsg;
    }

    public ChannelBuffer getChangeResourceMsg(){
        return changeResourceMsg;
    }

    @Override
    public String toString(){
        return id + "-" + name;
    }

    BowDataProto encode(){
        BowDataProto.Builder builder = BowDataProto.newBuilder();

        builder.setName(name);
        builder.setUpgradeData(upgradeData.getProto());
        builder.setOpenSpellCount(openSpellCount);

        builder.setBaseStat(baseStat.encode());
        builder.setFightingAmount(fightingAmount);
        builder.setEffectIcon(effectIcon);
        builder.setEffectName(effectName);
        builder.setEffectDesc(effectDesc);

        return builder.build();
    }

    static interface BowSpellRandomer{
        PassiveSpell[] getSpell();
    }

    private static class SingleBowSpellRandomer implements BowSpellRandomer{
        private final PassiveSpell[] spells;

        SingleBowSpellRandomer(PassiveSpell[] spells){
            this.spells = spells;
        }

        @Override
        public PassiveSpell[] getSpell(){
            return spells;
        }
    }

    private static class MultiBowSpellRandomer implements BowSpellRandomer{
        private final PassiveSpell[][] spells;

        private final int count;

        MultiBowSpellRandomer(List<PassiveSpell[]> spellList){
            checkArgument(spellList.size() > 0);

            this.spells = new PassiveSpell[spellList.size()][];

            for (int i = 0; i < spellList.size(); i++){
                spells[i] = spellList.get(i);
            }

            count = spells.length;
        }

        @Override
        public PassiveSpell[] getSpell(){
            return spells[RandomNumber.getRate(count, true)];
        }
    }
}
