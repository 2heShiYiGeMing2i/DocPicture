package app.game.data.scene;

import static com.mokylin.sink.util.Preconditions.*;

import java.util.Collection;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.data.scene.SouShenShop.SouShenShopGoods;
import app.protobuf.ConfigContent.SceneConfig;
import app.utils.VariableConfig;

import com.google.inject.Inject;
import com.mokylin.collection.IntArrayList;
import com.mokylin.collection.IntHashMap;
import com.mokylin.sink.util.RandomNumber;
import com.mokylin.sink.util.Utils;

public class SceneDatas{

    private static final Logger logger = LoggerFactory
            .getLogger(SceneDatas.class);

    private final IntHashMap<SceneData> map;

    private final NormalSceneDatas normalSceneDatas;
    private final StoryDungeonSceneDatas storyDungeonSceneDatas;
    private final ChallengeDungeonSceneDatas challengeDungeonSceneDatas;
    private final VipDungeonSceneDatas vipDungeonDatas;
    private final DefenceDungeonSceneDatas defenceDungeonSceneDatas;
    private final SouShenDungeonSceneDatas souShenDungeonSceneDatas;
    private final SouShenShop souShenShop;
    private final LingYunDungeonSceneDatas lingYunSceneDatas;
    private final LongMaiDungeonSceneDatas longMaiDungeonSceneDatas;
    private final JijianSceneDatas jijianSceneDatas;
    private final PortalDungeonSceneDatas portalDungeonSceneDatas;
    private final HuoLinActivitySceneDatas huoLinActivitySceneDatas;

    /**
     * 最大的场景id
     */
    public final int maxSceneID;

    public int maxUseSceneObjectID;

    private final int mediteSceneId;
    private final int mediteSceneX;
    private final int mediteSceneY;
    private final int mediteSceneRadius;

    private final NormalSceneData mediteScene;
    private final int[] meditePoints;

    // --- 出生场景 ---

    private final NormalSceneData heroFirstSceneData; // 第一个场景必须是普通场景, 不然英雄出副本, 没找到进副本前的场景, 就不知道该传去哪里了

    private final int heroFirstSceneX;

    private final int heroFirstSceneY;

    @Inject
    SceneDatas(NormalSceneDatas normalSceneDatas,
            StoryDungeonSceneDatas storyDungeonSceneDatas,
            ChallengeDungeonSceneDatas challengeDungeonSceneDatas,
            VipDungeonSceneDatas vipDungeonDatas,
            DefenceDungeonSceneDatas defenceDungeonSceneDatas,
            SouShenDungeonSceneDatas souShenDungeonSceneDatas,
            SouShenShop souShenShop,
            LingYunDungeonSceneDatas lingYunSceneDatas,
            LongMaiDungeonSceneDatas longMaiDungeonSceneDatas,
            JijianSceneDatas jijianSceneDatas,
            PortalDungeonSceneDatas portalDungeonSceneDatas,
            HuoLinActivitySceneDatas huoLinActivitySceneDatas,
            MonsterDatas monsters, VariableConfig variableConfig,
            SceneRemoveObjectMsgCache removeMsgCache){
        removeMsgCache.destroy(); // 删掉缓存, 释放内存

        this.normalSceneDatas = normalSceneDatas;
        this.storyDungeonSceneDatas = storyDungeonSceneDatas;
        this.challengeDungeonSceneDatas = challengeDungeonSceneDatas;
        this.vipDungeonDatas = vipDungeonDatas;
        this.defenceDungeonSceneDatas = defenceDungeonSceneDatas;
        this.souShenDungeonSceneDatas = souShenDungeonSceneDatas;
        this.souShenShop = souShenShop;
        this.lingYunSceneDatas = lingYunSceneDatas;
        this.longMaiDungeonSceneDatas = longMaiDungeonSceneDatas;
        this.jijianSceneDatas = jijianSceneDatas;
        this.portalDungeonSceneDatas = portalDungeonSceneDatas;
        this.huoLinActivitySceneDatas = huoLinActivitySceneDatas;

        // -- 加载 --
        map = new IntHashMap<>(256);

        normalSceneDatas.putAll(map);
        storyDungeonSceneDatas.putAll(map);
        challengeDungeonSceneDatas.putAll(map);
        vipDungeonDatas.putAll(map);
        defenceDungeonSceneDatas.putAll(map);
        souShenDungeonSceneDatas.putAll(map);
        lingYunSceneDatas.putAll(map);
        longMaiDungeonSceneDatas.putAll(map);
        jijianSceneDatas.putAll(map);
        portalDungeonSceneDatas.putAll(map);
        huoLinActivitySceneDatas.putAll(map);

        monsters.initNavigatePoses();

        // -- 处理 --
        int maxID = 0;
        int maxMonsterId = 0;
        for (SceneData scene : map.values()){
            maxID = Math.max(maxID, scene.id);
            maxMonsterId = Math.max(maxMonsterId, scene.getMaxUsedMonsterID());
        }

        maxSceneID = maxID;
        maxUseSceneObjectID = maxMonsterId;

        mediteSceneId = variableConfig.MEDITE_SCENE_ID;
        mediteSceneX = variableConfig.MEDITE_SCENE_X;
        mediteSceneY = variableConfig.MEDITE_SCENE_Y;
        mediteSceneRadius = variableConfig.MEDITE_RADIUS;

        mediteScene = checkNotNull(normalSceneDatas.get(mediteSceneId),
                "推荐打坐挂机场景没找到，场景ID：%s", mediteSceneId);

        IntArrayList safePosList = new IntArrayList();
        for (int x = mediteSceneX - mediteSceneRadius; x <= mediteSceneX
                + mediteSceneRadius; x++){
            for (int y = mediteSceneY - mediteSceneRadius; y <= mediteSceneY
                    + mediteSceneRadius; y++){
                if (mediteScene.blockInfo.isSafe(x, y)){
                    safePosList.add(Utils.short2Int(x, y));
                }
            }
        }

        // 检查安全区域
        checkArgument(!safePosList.isEmpty(), "推荐打坐挂机配置中居然没有一个安全区域的位置");
        meditePoints = safePosList.toArray();

        // 英雄出生场景
        SceneData first = get(variableConfig.INITIAL_SCENE_ID);
        checkNotNull(first, "英雄出生场景没找到: %s", variableConfig.INITIAL_SCENE_ID);
        checkArgument(first instanceof NormalSceneData, "英雄出生场景必须是个普通场景: %s",
                first);
        this.heroFirstSceneData = (NormalSceneData) first;

        heroFirstSceneX = variableConfig.INITIAL_SCENE_X;
        heroFirstSceneY = variableConfig.INITIAL_SCENE_Y;

        checkArgument(heroFirstSceneData.blockInfo.isWalkable(heroFirstSceneX,
                heroFirstSceneY), "新建英雄的坐标不可走 %s 场景的 <%s, %s>",
                heroFirstSceneData, heroFirstSceneX, heroFirstSceneY);
    }

    public NormalSceneData getHeroFirstSceneData(){
        return heroFirstSceneData;
    }

    public int getHeroFirstSceneX(){
        return heroFirstSceneX;
    }

    public int getHeroFirstSceneY(){
        return heroFirstSceneY;
    }

    public StoryDungeonSceneData getStory(int id){
        return storyDungeonSceneDatas.get(id);
    }

    public NormalSceneData getNormal(int id){
        return normalSceneDatas.get(id);
    }

    public ChallengeDungeonSceneData getChallenge(int id){
        return challengeDungeonSceneDatas.get(id);
    }

    public VipDungeonSceneData getVip(int id){
        return vipDungeonDatas.get(id);
    }

    public DefenceDungeonSceneData getDefence(){
        return defenceDungeonSceneDatas.getSceneData();
    }

    public HuoLinActivitySceneDatas getHuoLinAcitivitySceneDatas(){
        return huoLinActivitySceneDatas;
    }

    public SceneData get(int id){
        return map.get(id);
    }

    public StoryDungeonSceneDatas getStoryDungeonSceneDatas(){
        return storyDungeonSceneDatas;
    }

    public Collection<SceneData> getAll(){
        return map.values();
    }

    public Collection<NormalSceneData> getAllNormalSceneDatas(){
        return normalSceneDatas.getAll();
    }

    public NormalSceneData getMediteScene(){
        return mediteScene;
    }

    public int randomMeditePoint(){
        return meditePoints[RandomNumber.getRate(meditePoints.length, true)];
    }

    public JijianSceneData getJijianSceneData(){
        return jijianSceneDatas.getSceneData();
    }

    public SceneConfig generateProto(){
        SceneConfig.Builder builder = SceneConfig.newBuilder();
        for (NormalSceneData data : normalSceneDatas.getAll()){
            builder.addScenes(data.generateProto());
        }

        for (StoryDungeonSceneData data : storyDungeonSceneDatas.getAll()){
            builder.addStoryDungeon(data.generateProto());
        }

        for (ChallengeDungeonSceneData data : challengeDungeonSceneDatas
                .getAll()){
            builder.addChallengeDungeon(data.generateProto());
        }
        builder.setChallengeDungeonDailyTimes(challengeDungeonSceneDatas.challengeMaxTimes);
        builder.setChallengeDungeonAssistTimes(challengeDungeonSceneDatas.assistMaxTimes);

        for (VipDungeonSceneData data : vipDungeonDatas.getAll()){
            builder.addVipDungeon(data.generateProto());
        }

        // 挑战孔慈
        builder.setDefenceDungeon(defenceDungeonSceneDatas.getSceneData()
                .generateProto());

        // 搜神宫
        for (SouShenDungeonSceneData data : souShenDungeonSceneDatas.getAll()){
            builder.addSouShenDungeon(data.generateProto());
        }

        // 搜神宫商店
        for (SouShenShopGoods goods : souShenShop.getGoods()){
            builder.addSouShenShopGoods(goods.encode());
        }

        // 凌云窟
        builder.setLingYunDungeon(lingYunSceneDatas.getSceneData()
                .generateProto());

        // 守护龙脉
        builder.setLongMaiDungeon(longMaiDungeonSceneDatas.getSceneData()
                .generateProto());

        // 无绝神阵
        builder.setWuJueDungeon(portalDungeonSceneDatas.getSceneData()
                .generateProto());

        builder.setRecommendMediteSceneId(mediteSceneId);
        builder.setRecommendMediteScenePos(Utils.short2Int(mediteSceneX,
                mediteSceneY));
        builder.setRecommendMediteRadius(mediteSceneRadius);

        // 祭剑
        builder.setJijianDungeon(jijianSceneDatas.generateProto());

        // 火麟洞
        builder.setHuoLinActivity(huoLinActivitySceneDatas.generateProto());

        return builder.build();
    }
}
