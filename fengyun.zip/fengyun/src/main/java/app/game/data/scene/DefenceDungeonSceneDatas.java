package app.game.data.scene;

import static com.mokylin.sink.util.Preconditions.checkArgument;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.data.GameObjects;
import app.game.data.goods.GoodsDatas;
import app.utils.ServerType;
import app.utils.VariableConfig;

import com.google.inject.Inject;
import com.mokylin.collection.IntHashMap;
import com.mokylin.sink.util.parse.ObjectParser;

public class DefenceDungeonSceneDatas{

    private static final Logger logger = LoggerFactory
            .getLogger(DefenceDungeonSceneDatas.class);

    public static final String LOCATION = GameObjects.DEFENCE_SCENE_BASE_FOLDER
            + "config.txt";

    private final DefenceDungeonSceneData sceneData;

    @Inject
    DefenceDungeonSceneDatas(GameObjects go, BlockInfos blocks,
            MonsterDatas monsters, Scripts scripts, Plunders plunders, Ais ais,
            SceneTransportDatas transports, GoodsDatas goodsDatas,
            VariableConfig variableConfig,
            SceneRemoveObjectMsgCache removeMsgCache, ServerType serverType){
        logger.debug("loading defence dungeon scenes");

        List<ObjectParser> list = go.loadFile(LOCATION);

        checkArgument(list.size() == 1, "必须有且只有一条守护孔慈的场景配置: %s", LOCATION);

        ObjectParser p = list.get(0);

        sceneData = new DefenceDungeonSceneData(go, p, blocks, monsters,
                scripts, plunders, ais, transports, goodsDatas, removeMsgCache,
                serverType);
    }

    public DefenceDungeonSceneData getSceneData(){
        return sceneData;
    }

    void putAll(IntHashMap<SceneData> totalMap){
        totalMap.putUnique(sceneData.id, sceneData);
    }

}
