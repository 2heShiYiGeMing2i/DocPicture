package app.game.data.task;

import static com.mokylin.sink.util.Preconditions.checkArgument;

import java.util.List;

import org.apache.commons.lang.StringUtils;

import app.game.data.Prize;
import app.game.data.goods.GoodsDatas;
import app.game.data.scene.CollectObjects;
import app.game.data.scene.MonsterData;
import app.game.data.scene.MonsterDatas;
import app.game.data.scene.Npcs;
import app.game.data.scene.SceneDatas;
import app.game.data.task.TaskTarget.TaskTargetProgress;
import app.protobuf.TaskContent.TaskCompleteDialogProto;
import app.protobuf.TaskContent.TaskDataProto;
import app.protobuf.TaskContent.TaskProto;

import com.google.protobuf.ByteString;
import com.mokylin.collection.IntHashMap;
import com.mokylin.sink.util.parse.ObjectParser;

public class TaskData{

    static TaskData newChapterTask(ObjectParser p, Npcs npcs,
            MonsterDatas monsters, GoodsDatas goodsDatas,
            CollectObjects collectObjects, SceneDatas sceneDatas,
            IntHashMap<MonsterData> monLevelMap, String taskToStr){
        String name = p.getKey("task_name");
        checkArgument(!name.isEmpty(), "%s的任务名称没有配置", taskToStr);

        String desc = p.getKey("task_desc");
        checkArgument(!desc.isEmpty(), "%s的任务描述没有配置", taskToStr);

        String acceptDialog = p.getKey("accept_dialog");

        CompleteDialog completeDialog = null;
        String completeDialogStr = p.getKey("complete_dialog");
        if (!completeDialogStr.isEmpty()){
            String[] array = completeDialogStr.split(";");
            checkArgument(array.length == 3,
                    "%s的完成任务对白配置的格式错误，格式分为3部分，用英文分号隔开，如 'NPC名字;资源;对白'",
                    taskToStr);
            String npcName = array[0];
            String res = array[1];
            String dialog = array[2];

            checkArgument(!npcName.isEmpty(), "%s的完成任务对白中NPC名字没有配置", taskToStr);
            checkArgument(!res.isEmpty(), "%s的完成任务对白中头像资源没有配置", taskToStr);
            checkArgument(!dialog.isEmpty(), "%s的完成任务对白中说的话没有配置", taskToStr);

            completeDialog = CompleteDialog.newCompleteDialog(npcName, res,
                    dialog);
        }

        TaskTarget[] targets;

        String targetStr = p.getKey("target");
        if (targetStr.indexOf("#") < 0){
            targets = new TaskTarget[1];
            targets[0] = TaskTarget.newTaskTarget(targetStr, npcs, monsters,
                    goodsDatas, collectObjects, sceneDatas, monLevelMap);
        } else{
            String[] targetArray = targetStr.split("#");

            targets = new TaskTarget[targetArray.length];

            for (int i = 0; i < targetArray.length; i++){
                TaskTarget t = targets[i] = TaskTarget.newTaskTarget(
                        targetArray[i], npcs, monsters, goodsDatas,
                        collectObjects, sceneDatas, monLevelMap);

                checkArgument(!t.isReplyNpc(),
                        "剧情任务中存在多任务目标的任务，但是其中第%s个任务目标是回复NPC", (i + 1));

                checkArgument(!t.isEnterDungeon(),
                        "剧情任务中存在多任务目标的任务，但是其中第%s个任务目标是进入副本", (i + 1));
            }
        }

        return new TaskData(name, desc, acceptDialog, completeDialog, targets);
    }

    static TaskData newChanceTask(ObjectParser p, Npcs npcs,
            MonsterDatas monsters, GoodsDatas goodsDatas,
            CollectObjects collectObjects, SceneDatas sceneDatas,
            IntHashMap<MonsterData> monLevelMap, String taskToStr){
        String acceptDialog = p.getKey("accept_dialog");

        TaskTarget[] targets;

        String targetStr = p.getKey("target");
        String[] targetArray = targetStr.split("#");

        targets = new TaskTarget[targetArray.length];

        for (int i = 0; i < targetArray.length; i++){
            TaskTarget t = targets[i] = TaskTarget.newTaskTarget(
                    targetArray[i], npcs, monsters, goodsDatas, collectObjects,
                    sceneDatas, monLevelMap);

            // 如果机缘任务可以不是杀怪任务，那么需要在完成回复NPC任务，升级任务中加入检测机缘任务
            checkArgument(t.isKillMonster(), "机缘任务中配置的任务目标居然不是杀怪任务");
        }

        return new TaskData(null, null, acceptDialog, null, targets);
    }

    static TaskData newDailyTask(TaskTarget[] targets){
        return new TaskData(null, null, null, null, targets);
    }

    static TaskData newGuildTask(int taskId, ObjectParser p, Npcs npcs,
            MonsterDatas monsters, GoodsDatas goodsDatas,
            CollectObjects collectObjects, SceneDatas sceneDatas,
            IntHashMap<MonsterData> monLevelMap){

        String targetStr = p.getKey("target");

        checkArgument(targetStr.indexOf("#") < 0,
                "帮派任务-%s 居然配置了多个任务目标, target: %s", taskId, targetStr);

        TaskTarget[] targets = new TaskTarget[1];
        targets[0] = TaskTarget.newTaskTarget(targetStr, npcs, monsters,
                goodsDatas, collectObjects, sceneDatas, monLevelMap);

        // 如果帮派任务可以是升级任务，那么需要在英雄升级处理中加入检测
        checkArgument(!targets[0].isUpgradeLevel(), "帮派任务-%s 中配置的任务目标居然是升级任务",
                taskId);

        // 如果帮派任务可以配置采集任务，需要在采集物品加入检测是否可以完成
        checkArgument(!targets[0].isCollectGoods(), "帮派任务-%s 中配置了采集物品任务?",
                taskId);

        // 如果帮派任务可以配置进入副本任务，需要在进入副本加入检测是否可以完成
        checkArgument(!targets[0].isEnterDungeon(), "帮派任务-%s 中配置了进入副本任务?",
                taskId);

        return new TaskData(null, null, null, null, targets);

    }

    // 任务名称
    final String name;

    // 任务描述
    final String desc;

    // 接受任务对白
    final String acceptDialog;

    // 完成任务对白
    final CompleteDialog completeDialog;

    // 任务目标
    final TaskTarget[] targets;

    private TaskData(String name, String desc, String acceptDialog,
            CompleteDialog completeDialog, TaskTarget[] targets){
        this.name = name;
        this.desc = desc;
        this.acceptDialog = acceptDialog;
        this.completeDialog = completeDialog;
        this.targets = targets;

        checkArgument(targets.length <= 4, "任务的任务目标不能超过4个");
    }

    final TaskDataProto encodeData(Prize prize){
        TaskDataProto.Builder builder = TaskDataProto.newBuilder();

        if (StringUtils.isNotEmpty(name)){
            builder.setName(ByteString.copyFromUtf8(name));
        }

        if (StringUtils.isNotEmpty(desc)){
            builder.setDesc(ByteString.copyFromUtf8(desc));
        }

        if (StringUtils.isNotEmpty(acceptDialog)){
            builder.setAcceptDialog(ByteString.copyFromUtf8(acceptDialog));
        }

        if (completeDialog != null){
            builder.setCompleteDialog(completeDialog.encode());
        }

        for (TaskTarget target : targets){
            builder.addTarget(target.encode());
        }

        if (prize != null){
            builder.setPrize(prize.encode4Client());
        }

        return builder.build();
    }

    final int[] newIntProgress(){
        return new int[targets.length];
    }

    final TaskTargetProgress[] newProgress(int taskId,
            List<Integer> progressList){

        if (progressList == null || targets.length != progressList.size()){
            return newEmptyProgress(taskId);
        }

        TaskTargetProgress[] progress = new TaskTargetProgress[targets.length];

        for (int i = 0; i < progressList.size(); i++){
            TaskTarget target = targets[i];
            progress[i] = target.newProgress(taskId, i, progressList.get(i));
        }

        return progress;
    }

    final TaskTargetProgress[] newEmptyProgress(int taskId){

        TaskTargetProgress[] progress = new TaskTargetProgress[targets.length];

        for (int i = 0; i < targets.length; i++){
            progress[i] = targets[i].newProgress(taskId, i, 0);
        }

        return progress;
    }

    final TaskTargetProgress[] newProgress(int taskId,
            TaskTargetProgress[] progress){
        if (progress.length != targets.length){
            return newEmptyProgress(taskId);
        }

        TaskTargetProgress[] newProgress = new TaskTargetProgress[targets.length];

        for (int i = 0; i < targets.length; i++){
            newProgress[i] = targets[i].newProgress(taskId, i,
                    progress[i].progress);
        }

        return newProgress;
    }

    static TaskProto encodeTaskProto(int taskId, TaskDataProto dataProto,
            TaskTargetProgress[] progress){
        TaskProto.Builder builder = TaskProto.newBuilder().setId(taskId)
                .setData(dataProto);

        for (TaskTargetProgress p : progress){
            builder.addProgress(p.progress);
        }

        return builder.build();
    }

    static class CompleteDialog{

        static CompleteDialog newCompleteDialog(String npcName, String res,
                String dialog){
            return new CompleteDialog(npcName, res, dialog);
        }

        // 说话人的名字
        final String name;

        // 说话人的资源
        final String res;

        // 说的话
        final String dialog;

        CompleteDialog(String name, String res, String dialog){
            this.name = name;
            this.res = res;
            this.dialog = dialog;
        }

        TaskCompleteDialogProto encode(){
            TaskCompleteDialogProto.Builder builder = TaskCompleteDialogProto
                    .newBuilder();

            if (StringUtils.isNotEmpty(name)){
                builder.setName(ByteString.copyFromUtf8(name));
            }

            if (StringUtils.isNotEmpty(res)){
                builder.setRes(res);
            }

            if (StringUtils.isNotEmpty(dialog)){
                builder.setDialog(ByteString.copyFromUtf8(dialog));
            }

            return builder.build();
        }
    }
}
