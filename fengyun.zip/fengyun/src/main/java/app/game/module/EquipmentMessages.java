/**
 * 
 */
package app.game.module;

import static com.mokylin.sink.util.BufferUtil.*;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.data.goods.Goods;
import app.game.data.goods.RefinedData;
import app.game.module.EquipmentModule.UpgradeLevelData;
import app.protobuf.ConfigContent.EquipmentLevelForgeProto;
import app.protobuf.ConfigContent.EquipmentRefinedForgeProto;

import com.mokylin.sink.util.BufferUtil;
import com.mokylin.sink.util.Empty;

/**
 * 装备模块消息
 * 
 * @author Liwei
 * 
 */
public class EquipmentMessages{
    static final int MODULE_ID = Modules.EQUIPMENT_MODULE_ID;

    private EquipmentMessages(){
    }

    /**
     * 移动装备，包括穿装备，脱装备，替换装备，发送C2S_MOVE_EQUIPMENT，附带以下信息
     * varint32 背包位置
     * varint32 装备位置，0-武器 1-戒指 2-项链 3-护腕 4-玉佩 5-头盔 6-衣服 7-腰带 8-裤子 9-鞋子
     * 成功返回S2C_MOVE_EQUIPMENT，附带以下信息
     * varint32 背包位置
     * varint32 装备位置
     * 
     * 客户端根据背包位置和装备位置，互换2个位置的物品，如果其中一个位置没有物品，则将物品从原来的位置移到另一边
     * 注意：如果背包中的装备是没有绑定，则穿上后，客户端将该装备设置成已绑定物品，服务器不会发消息通知
     * 
     * 装备成功后服务器会发送一条英雄属性变更消息，更新英雄的最新属性，消息内容参考人物属性文档
     * 
     * 失败返回S2C_MOVE_EQUIPMENT_FAIL，附带byte错误码，错误码后面有详细说明
     */
    static final int C2S_MOVE_EQUIPMENT = 0;

    static final int S2C_MOVE_EQUIPMENT = 1;

    static final int S2C_MOVE_EQUIPMENT_FAIL = 2;

    static enum MOVE_EQUIPMENT_RESULT{
        SUCCESS,

        /**
         * 客户端发送的背包位置无效
         */
        DEPOT_POS_INVALID(1),

        /**
         * 客户端发送的装备位置无效
         */
        EQUIPMENT_POS_INVALID(2),

        /**
         * 背包位置和装备位置上面都没有装备
         */
        EQUIPMENT_NOT_FOUND(3),

        /**
         * 背包位置已经被锁定，比如正在交易
         */
        DEPOT_POS_LOCKED(4),

        /**
         * 背包位置中的物品不是装备，或者不是对应的部件（比如将鞋子装备到头部），
         * 或者需求等级需求不足（30级英雄想穿40级装备），或者职业需求不同（步惊云穿楚楚的衣服）
         */
        DEPOT_EQUIPMENT_INVALID(5);

        private final ChannelBuffer errBuffer;

        private MOVE_EQUIPMENT_RESULT(){
            errBuffer = null;
        }

        private MOVE_EQUIPMENT_RESULT(int code){
            errBuffer = onlySendHeadAndAByteMessage(MODULE_ID,
                    S2C_MOVE_EQUIPMENT_FAIL, code);
        }

        public ChannelBuffer getMessage(){
            return errBuffer;
        }

        public ChannelBuffer getMessage(int depotPos, int equipPos){
            if (errBuffer == null){
                return successMsg(depotPos, equipPos);
            }

            return errBuffer;
        }

        private ChannelBuffer successMsg(int depotPos, int equipPos){
            ChannelBuffer buffer = newFixedSizeMessage(
                    MODULE_ID,
                    S2C_MOVE_EQUIPMENT,
                    BufferUtil.computeVarInt32Size(depotPos)
                            + BufferUtil.computeVarInt32Size(equipPos));
            BufferUtil.writeVarInt32(buffer, depotPos);
            BufferUtil.writeVarInt32(buffer, equipPos);
            return buffer;
        }
    }

    /**
     * 换装资源改变，附带以下信息
     * varint64 英雄Id
     * varint32 换装资源
     */
    static final int S2C_EQUIPMENT_RESOURCES_CHANGED = 3;

    public static ChannelBuffer getEquipmentResourcesChanged(long id,
            int equipmentResources){
        ChannelBuffer buffer = newFixedSizeMessage(
                MODULE_ID,
                S2C_EQUIPMENT_RESOURCES_CHANGED,
                BufferUtil.computeVarInt64Size(id)
                        + BufferUtil.computeVarInt32Size(equipmentResources));
        BufferUtil.writeVarInt64(buffer, id);
        BufferUtil.writeVarInt32(buffer, equipmentResources);

        return buffer;
    }

    /**
     * 坐骑装备穿戴，附带以下信息
     * varint32 背包位置
     * varint32 装备位置，0-鞍具 1-缰绳 2-蹬具 3-蹄铁
     */
    static final int C2S_MOVE_MOUNT_EQUIPMENT = 4;

    /**
     * 坐骑装备穿戴成功，附带以下信息
     * varint32 背包位置
     * varint32 装备位置，0-鞍具 1-缰绳 2-蹬具 3-蹄铁
     * 
     * 客户端根据背包位置和装备位置，互换2个位置的物品，如果其中一个位置没有物品，则将物品从原来的位置移到另一边
     * 注意：如果背包中的装备是没有绑定，则穿上后，客户端将该装备设置成已绑定物品，服务器不会发消息通知
     * 
     * 装备成功后，如果英雄此时在马上，服务器会发送一条英雄属性变更消息，更新英雄的最新属性，消息内容参考人物属性文档
     * 否则不会发送属性更新的消息
     */
    static final int S2C_MOVE_MOUNT_EQUIPMENT = 5;

    /**
     * 坐骑装备穿戴失败返回S2C_MOVE_EQUIPMENT_FAIL，附带byte错误码
     * 1、英雄还没有坐骑
     * 2、背包位置无效
     * 3、装备位置无效
     * 4、背包位置已锁定（正在交易）
     * 5、物品无效（背包中的物品不是坐骑装备，英雄等级不足）
     * 6、背包位置上没有物品
     * 7、坐骑阶数不足
     */
    static final int S2C_MOVE_MOUNT_EQUIPMENT_FAIL = 6;

    static final ChannelBuffer ERR_MOVE_MOUNT_EQ_FAIL_NOT_MOUNT = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_MOVE_MOUNT_EQUIPMENT_FAIL, 1);

    static final ChannelBuffer ERR_MOVE_MOUNT_EQ_FAIL_INVALID_DEPOT_POS = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_MOVE_MOUNT_EQUIPMENT_FAIL, 2);

    static final ChannelBuffer ERR_MOVE_MOUNT_EQ_FAIL_INVALID_EQ_POS = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_MOVE_MOUNT_EQUIPMENT_FAIL, 3);

    static final ChannelBuffer ERR_MOVE_MOUNT_EQ_FAIL_DEPOT_POS_LOCKED = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_MOVE_MOUNT_EQUIPMENT_FAIL, 4);

    static final ChannelBuffer ERR_MOVE_MOUNT_EQ_FAIL_INVALID_GOODS = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_MOVE_MOUNT_EQUIPMENT_FAIL, 5);

    static final ChannelBuffer ERR_MOVE_MOUNT_EQ_FAIL_EQ_NOT_FOUND = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_MOVE_MOUNT_EQUIPMENT_FAIL, 6);

    static final ChannelBuffer ERR_MOVE_MOUNT_EQ_FAIL_MOUNT_LEVEL_NOT_ENOUGH = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_MOVE_MOUNT_EQUIPMENT_FAIL, 7);

    // 装备强化

    /**
     * 请求装备强化数据
     * varint32 装备ID
     * varint32 强化目标等级，+1 -> +2 发送2
     * varint32 装备品质
     * 
     * 要强化到几级，就发送几级
     */
    static final int C2S_EQUIPMENT_GET_REFINED_DATA = 7;

    /**
     * 返回装备强化数据
     * bytes EquipmentRefinedForgeProto
     * 
     * 客户端收到此消息后，缓存已请求过的数据，在下次需要装备强化数据时，优先从缓存中读取
     */
    static final int S2C_EQUIPMENT_GET_REFINED_DATA = 8;

    /**
     * 请求数据失败，返回byte错误码
     * 1、装备ID无效，找不到对应的装备
     * 2、强化目标等级无效，比如11，系统没有+11的装备
     * 3、装备不能强化
     */
    static final int S2C_EQUIPMENT_GET_REFINED_DATA_FAIL = 9;

    static final ChannelBuffer ERR_REFINED_DATA_FAIL_EQUIPMENT_NOT_FOUND = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_EQUIPMENT_GET_REFINED_DATA_FAIL, 1);

    static final ChannelBuffer ERR_REFINED_DATA_FAIL_REFINED_INVALID = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_EQUIPMENT_GET_REFINED_DATA_FAIL, 2);

    static final ChannelBuffer ERR_REFINED_DATA_FAIL_EQUIPMENT_CANT_REFINED = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_EQUIPMENT_GET_REFINED_DATA_FAIL, 3);

    /**
     * 强化装备
     * varint32 装备位置
     * 
     * varint32 进阶类型 0-全物品，1-物品不够礼金购买，2-物品不够元宝购买
     * while(availiable)
     *     varint32 pos 物品在背包中的位置
     *     varint32 count 在这个位置扣除多少个
     */
    static final int C2S_EQUIPMENT_REFINED = 10;

    /**
     * 强化成功
     * varint32 装备位置
     * if (byteArray.available)
     *     bytes EquipmentRefinedForgeProto // 还有数据，就再读取下一级的强化数据，否则说明已经是最高级了
     *     
     * 根据消息中的位置，到缓存数据中获取强化后的装备数据，更新装备
     */
    static final int S2C_EQUIPMENT_REFINED_SUCCESS = 11;

    /**
     * 强化失败
     */
    static final int S2C_EQUIPMENT_REFINED_FAIL = 12;

    static final ChannelBuffer REFINED_FAIL_MSG = onlySendHeaderMessage(
            MODULE_ID, S2C_EQUIPMENT_REFINED_FAIL);

    /**
     * 强化消息错误，附带byte错误码
     * 1、客户端发送的位置没有装备
     * 2、装备不能强化
     * 3、银两不足
     * 4、礼金购买，但是礼金不够
     * 5、元宝购买，但是元宝不够
     * 6、客户端消息附带的物品位置或者扣除个数无效（空物品位置，物品已过期，不是升阶物品，物品个数不足）
     * 7、物品不够，但是没有选择礼金购买或者元宝购买
     * 8、会过期的装备不能锻造
     * 9、只能强化紫色品质以上的装备
     */
    static final int S2C_EQUIPMENT_REFINED_ERROR = 13;

    static final ChannelBuffer ERR_REFINED_FAIL_EQUIPMENT_NOT_FOUND = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_EQUIPMENT_REFINED_ERROR, 1);

    static final ChannelBuffer ERR_REFINED_FAIL_EQUIPMENT_CANT_REFINED = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_EQUIPMENT_REFINED_ERROR, 2);

    static final ChannelBuffer ERR_REFINED_FAIL_MONEY_NOT_ENOUGH = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_EQUIPMENT_REFINED_ERROR, 3);

    static final ChannelBuffer ERR_REFINED_FAIL_LIJIN_NOT_ENOUGH = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_EQUIPMENT_REFINED_ERROR, 4);

    static final ChannelBuffer ERR_REFINED_FAIL_YUANBAO_NOT_ENOUGH = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_EQUIPMENT_REFINED_ERROR, 5);

    static final ChannelBuffer ERR_REFINED_FAIL_INVALID_POS = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_EQUIPMENT_REFINED_ERROR, 6);

    static final ChannelBuffer ERR_REFINED_FAIL_GOODS_NOT_ENOUGH = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_EQUIPMENT_REFINED_ERROR, 7);

    static final ChannelBuffer ERR_REFINED_FAIL_EQUIPMENT_WILL_EXPIRED = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_EQUIPMENT_REFINED_ERROR, 8);

    static final ChannelBuffer ERR_REFINED_FAIL_QUALITY_NOT_ENOUGH = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_EQUIPMENT_REFINED_ERROR, 9);

//    /**
//     * 请求装备提示品质数据
//     * varint32 装备ID
//     * varint32 目标品质，白色升绿色，发送绿色的品质ID
//     * varint32 附加属性类型
//     */
//    static final int C2S_EQUIPMENT_UPGRADE_QUALITY_DATA = 14;
//
//    /**
//     * 提升品质数据
//     * bytes EquipmentQualityForgeProto
//     * 
//     * 客户端收到此消息后，缓存已请求过的数据，在下次需要装备提升品质数据时，优先从缓存中读取
//     * 
//     * 特殊处理，如果装备的附加属性条数为0（即还没有附加属性），则此时显示特殊的面板，不要显示真实的数据
//     */
//    static final int S2C_EQUIPMENT_UPGRADE_QUALITY_DATA = 15;
//
//    /**
//     * 获取提升品质数据失败，附带byte错误码
//     * 1、装备ID无效，找不到对应的装备
//     * 2、装备不能提升品质
//     * 3、目标品质无效
//     * 4、附加属性类型无效
//     */
//    static final int S2C_EQUIPMENT_UPGRADE_QUALITY_DATA_FAIL = 16;
//
//    static final ChannelBuffer ERR_UPGRADE_QUALITY_DATA_FAIL_EQUIPMENT_NOT_FOUND = onlySendHeadAndAByteMessage(
//            MODULE_ID, S2C_EQUIPMENT_UPGRADE_QUALITY_DATA_FAIL, 1);
//
//    static final ChannelBuffer ERR_UPGRADE_QUALITY_DATA_FAIL_CANT_UPGRADE_QUALITY = onlySendHeadAndAByteMessage(
//            MODULE_ID, S2C_EQUIPMENT_UPGRADE_QUALITY_DATA_FAIL, 2);
//
//    static final ChannelBuffer ERR_UPGRADE_QUALITY_DATA_FAIL_INVALID_QUALITY = onlySendHeadAndAByteMessage(
//            MODULE_ID, S2C_EQUIPMENT_UPGRADE_QUALITY_DATA_FAIL, 3);
//
//    static final ChannelBuffer ERR_UPGRADE_QUALITY_DATA_FAIL_INVALID_STAT_TYPE = onlySendHeadAndAByteMessage(
//            MODULE_ID, S2C_EQUIPMENT_UPGRADE_QUALITY_DATA_FAIL, 4);
//
//    /**
//     * 装备提升品质
//     * varint32 位置，下面有说明
//     * varint32 count 需求装备个数
//     * for
//     *     varint32 pos 需求装备在背包的位置
//     * 
//     * varint32 进阶类型 0-全物品，1-物品不够礼金购买，2-物品不够元宝购买
//     * while(availiable)
//     *     varint32 pos 物品在背包中的位置
//     *     varint32 count 在这个位置扣除多少个
//     *     
//     * 位置合成:
//     * 装备在背包，位置 = depotPos << 1
//     * 装备在身上，位置 = (equipPos << 1) || 1
//     */
//    static final int C2S_EQUIPMENT_UPGRADE_QUALITY = 17;
//
//    /**
//     * 装备提升品质成功
//     * varint32 位置，下面有说明
//     * if (byteArray.available)
//     *     bytes EquipmentQualityForgeProto // 还有数据，就再读取下一级的提升品质数据，否则说明已经是最高级了
//     *     
//     * 根据消息中的位置，到缓存数据中获取装备提升品质后的数据，更新装备
//     * 
//     * 位置解析：
//     * int pos = read() // 从消息读取位置
//     * boolean isDepotGoods = (pos & 1) == 0; // true表示物品在背包，false表示物品在身上
//     * int realPos = pos >>> 1; // 如果是在背包，则表示背包的位置，如果是身上的装备，表示装备的位置
//     */
//    static final int S2C_EQUIPMENT_UPGRADE_QUALITY_SUCCESS = 18;
//
//    /**
//     * 提升品质失败
//     */
//    static final int S2C_EQUIPMENT_UPGRADE_QUALITY_FAIL = 19;
//
//    static final ChannelBuffer UPGRADE_QUALITY_FAIL_MSG = onlySendHeaderMessage(
//            MODULE_ID, S2C_EQUIPMENT_UPGRADE_QUALITY_FAIL);
//
//    /**
//     * 提升品质错误，附带byte错误码
//     * 1、提品装备没找到
//     * 2、装备不能提升品质
//     * 3、银两不足
//     * 4、礼金购买，但是礼金不够
//     * 5、元宝购买，但是元宝不够
//     * 6、客户端消息附带的物品位置或者扣除个数无效（空物品位置，物品已过期，不是升阶物品，物品个数不足）
//     * 7、物品不够，但是没有选择礼金购买或者元宝购买
//     * 
//     * 8、需求装备无效，包括以下几种情况(没有找到需求装备、需求装备存在重复、需求装备锻造值为0、
//     *    需求装备等级大于源装备、需求装备个数无效，必须 count > 0 && count <= 4)
//     *    
//     * 9、会过期的装备不能锻造
//     * 10、需求装备不能是会过期的物品
//     */
//    static final int S2C_EQUIPMENT_UPGRADE_QUALITY_ERROR = 20;
//
//    static final ChannelBuffer ERR_UPGRADE_QUALITY_FAIL_EQUIPMENT_NOT_FOUND = onlySendHeadAndAByteMessage(
//            MODULE_ID, S2C_EQUIPMENT_UPGRADE_QUALITY_ERROR, 1);
//
//    static final ChannelBuffer ERR_UPGRADE_QUALITY_FAIL_CANT_UPGRADE = onlySendHeadAndAByteMessage(
//            MODULE_ID, S2C_EQUIPMENT_UPGRADE_QUALITY_ERROR, 2);
//
//    static final ChannelBuffer ERR_UPGRADE_QUALITY_FAIL_MONEY_NOT_ENOUGH = onlySendHeadAndAByteMessage(
//            MODULE_ID, S2C_EQUIPMENT_UPGRADE_QUALITY_ERROR, 3);
//
//    static final ChannelBuffer ERR_UPGRADE_QUALITY_FAIL_LIJIN_NOT_ENOUGH = onlySendHeadAndAByteMessage(
//            MODULE_ID, S2C_EQUIPMENT_UPGRADE_QUALITY_ERROR, 4);
//
//    static final ChannelBuffer ERR_UPGRADE_QUALITY_FAIL_YUANBAO_NOT_ENOUGH = onlySendHeadAndAByteMessage(
//            MODULE_ID, S2C_EQUIPMENT_UPGRADE_QUALITY_ERROR, 5);
//
//    static final ChannelBuffer ERR_UPGRADE_QUALITY_FAIL_INVALID_POS = onlySendHeadAndAByteMessage(
//            MODULE_ID, S2C_EQUIPMENT_UPGRADE_QUALITY_ERROR, 6);
//
//    static final ChannelBuffer ERR_UPGRADE_QUALITY_FAIL_GOODS_NOT_ENOUGH = onlySendHeadAndAByteMessage(
//            MODULE_ID, S2C_EQUIPMENT_UPGRADE_QUALITY_ERROR, 7);
//
//    static final ChannelBuffer ERR_UPGRADE_QUALITY_FAIL_INVALID_REQUIRED_EQUIPMENT = onlySendHeadAndAByteMessage(
//            MODULE_ID, S2C_EQUIPMENT_UPGRADE_QUALITY_ERROR, 8);
//
//    static final ChannelBuffer ERR_UPGRADE_QUALITY_FAIL_EQUIPMENT_WILL_EXIPRED = onlySendHeadAndAByteMessage(
//            MODULE_ID, S2C_EQUIPMENT_UPGRADE_QUALITY_ERROR, 9);
//
//    static final ChannelBuffer ERR_UPGRADE_QUALITY_FAIL_REQUIRED_EQUIPMENT_WILL_EXIPRED = onlySendHeadAndAByteMessage(
//            MODULE_ID, S2C_EQUIPMENT_UPGRADE_QUALITY_ERROR, 10);

    /**
     * 请求装备提示等级数据
     * varint32 装备ID
     * varint32 强化等级
     * varint32 目标品质
     * varint32 附加属性类型
     */
    static final int C2S_EQUIPMENT_UPGRADE_LEVEL_DATA = 21;

    /**
     * 提升等级数据
     * bytes EquipmentLevelForgeProto
     * 
     * 客户端收到此消息后，缓存已请求过的数据，在下次需要装备提升等级数据时，优先从缓存中读取
     */
    static final int S2C_EQUIPMENT_UPGRADE_LEVEL_DATA = 22;

    /**
     * 获取提升等级数据失败，附带byte错误码
     * 1、装备ID无效，找不到对应的装备
     * 2、装备不能提升等级
     * 3、目标品质无效
     * 4、附加属性类型无效
     * 5、强化等级无效
     */
    static final int S2C_EQUIPMENT_UPGRADE_LEVEL_DATA_FAIL = 23;

    static final ChannelBuffer ERR_UPGRADE_LEVEL_DATA_FAIL_EQUIPMENT_NOT_FOUND = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_EQUIPMENT_UPGRADE_LEVEL_DATA_FAIL, 1);

    static final ChannelBuffer ERR_UPGRADE_LEVEL_DATA_FAIL_CANT_UPGRADE_LEVEL = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_EQUIPMENT_UPGRADE_LEVEL_DATA_FAIL, 2);

    static final ChannelBuffer ERR_UPGRADE_LEVEL_DATA_FAIL_INVALID_QUALITY = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_EQUIPMENT_UPGRADE_LEVEL_DATA_FAIL, 3);

    static final ChannelBuffer ERR_UPGRADE_LEVEL_DATA_FAIL_INVALID_STAT_TYPE = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_EQUIPMENT_UPGRADE_LEVEL_DATA_FAIL, 4);

    static final ChannelBuffer ERR_UPGRADE_LEVEL_DATA_FAIL_INVALID_REFINED = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_EQUIPMENT_UPGRADE_LEVEL_DATA_FAIL, 5);

    /**
     * 装备提升等级
     * varint32 装备位置
     * 
     * varint32 进阶类型 0-全物品，1-物品不够礼金购买，2-物品不够元宝购买
     * while(availiable)
     *     varint32 pos 物品在背包中的位置
     *     varint32 count 在这个位置扣除多少个
     */
    static final int C2S_EQUIPMENT_UPGRADE_LEVEL = 24;

    /**
     * 装备提升等级成功
     * varint32 装备位置
     * if (byteArray.available)
     *     bytes EquipmentLevelForgeProto // 还有数据，就再读取下一级的提升等级数据，否则说明已经是最高级了
     *     
     * 根据消息中的位置，到缓存数据中获取装备提升等级后的数据，更新装备
     */
    static final int S2C_EQUIPMENT_UPGRADE_LEVEL_SUCCESS = 25;

    /**
     * 提升等级失败
     */
    static final int S2C_EQUIPMENT_UPGRADE_LEVEL_FAIL = 26;

    static final ChannelBuffer UPGRADE_LEVEL_FAIL_MSG = onlySendHeaderMessage(
            MODULE_ID, S2C_EQUIPMENT_UPGRADE_LEVEL_FAIL);

    /**
     * 提升等级错误，附带byte错误码
     * 1、装备没找到
     * 2、装备不能提升等级
     * 3、银两不足
     * 4、礼金购买，但是礼金不够
     * 5、元宝购买，但是元宝不够
     * 6、客户端消息附带的物品位置或者扣除个数无效（空物品位置，物品已过期，不是升阶物品，物品个数不足）
     * 7、物品不够，但是没有选择礼金购买或者元宝购买
     * 
     * 8、需求装备无效，包括以下几种情况(没有找到需求装备、需求装备存在重复、需求装备锻造值为0、
     *    需求装备等级大于源装备、需求装备个数无效，必须 count > 0 && count <= 4)（已过时）
     *    
     * 9、会过期的装备不能锻造
     * 10、需求装备不能是会过期的物品（已过时）
     * 11、装备品质比紫色品质小
     * 12、装备没有达到最高强化等级
     */
    static final int S2C_EQUIPMENT_UPGRADE_LEVEL_ERROR = 27;

    static final ChannelBuffer ERR_UPGRADE_LEVEL_FAIL_EQUIPMENT_NOT_FOUND = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_EQUIPMENT_UPGRADE_LEVEL_ERROR, 1);

    static final ChannelBuffer ERR_UPGRADE_LEVEL_FAIL_CANT_UPGRADE = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_EQUIPMENT_UPGRADE_LEVEL_ERROR, 2);

    static final ChannelBuffer ERR_UPGRADE_LEVEL_FAIL_MONEY_NOT_ENOUGH = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_EQUIPMENT_UPGRADE_LEVEL_ERROR, 3);

    static final ChannelBuffer ERR_UPGRADE_LEVEL_FAIL_LIJIN_NOT_ENOUGH = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_EQUIPMENT_UPGRADE_LEVEL_ERROR, 4);

    static final ChannelBuffer ERR_UPGRADE_LEVEL_FAIL_YUANBAO_NOT_ENOUGH = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_EQUIPMENT_UPGRADE_LEVEL_ERROR, 5);

    static final ChannelBuffer ERR_UPGRADE_LEVEL_FAIL_INVALID_POS = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_EQUIPMENT_UPGRADE_LEVEL_ERROR, 6);

    static final ChannelBuffer ERR_UPGRADE_LEVEL_FAIL_GOODS_NOT_ENOUGH = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_EQUIPMENT_UPGRADE_LEVEL_ERROR, 7);

//    static final ChannelBuffer ERR_UPGRADE_LEVEL_FAIL_INVALID_REQUIRED_EQUIPMENT = onlySendHeadAndAByteMessage(
//            MODULE_ID, S2C_EQUIPMENT_UPGRADE_LEVEL_ERROR, 8);

    static final ChannelBuffer ERR_UPGRADE_LEVEL_FAIL_EQUIPMENT_WILL_EXIPRED = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_EQUIPMENT_UPGRADE_LEVEL_ERROR, 9);

//    static final ChannelBuffer ERR_UPGRADE_LEVEL_FAIL_REQUIRED_EQUIPMENT_WILL_EXIPRED = onlySendHeadAndAByteMessage(
//            MODULE_ID, S2C_EQUIPMENT_UPGRADE_LEVEL_ERROR, 10);

    static final ChannelBuffer ERR_UPGRADE_LEVEL_FAIL_QUALITY_NOT_ENOUGH = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_EQUIPMENT_UPGRADE_LEVEL_ERROR, 11);

    static final ChannelBuffer ERR_UPGRADE_LEVEL_FAIL_NOT_MAX_REFINED_TIMES = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_EQUIPMENT_UPGRADE_LEVEL_ERROR, 12);

    /**
     * 强化成功广播
     * UTF 英雄名
     * UTF 装备名称
     * varint32 品质 0-白 1-绿 2-蓝 3-紫 4-橙
     * varint32 强化等级
     * 
     * 恭喜[XXX玩家名]将 [XXX装备名]强化至+X
     * 装备名称需要根据品质展示颜色
     */
    static final int S2C_EQUIPMENT_REFINED_BROADCAST = 28;

    /**
     * 提升品质成功广播
     * UTF 英雄名
     * UTF 装备名称
     * varint32 新装备的品质（老装备品质根据新装备计算）
     * 
     * “恭喜[XXX玩家名]将 [XXX装备名]提品至[XXX装备名]”
     * 装备名称需要根据品质展示颜色
     */
    static final int S2C_EQUIPMENT_UPGRADE_QUALITY_BROADCAST = 29;

    /**
     * 提升等级成功广播
     * UTF 英雄名
     * UTF 老装备名称
     * UTF 新装备名称
     * varint32 品质
     * 
     * “恭喜[XXX玩家名]将 [XXX装备名]提品至[XXX装备名]”
     * 装备名称需要根据品质展示颜色
     */
    static final int S2C_EQUIPMENT_UPGRADE_LEVEL_BROADCAST = 30;

    /**
     * 熔炼装备
     * varint32 装备在背包的位置
     */
    static final int C2S_EQUIPMENT_MELTING = 31;

    /**
     * 熔炼装备成功
     * varint32 装备在背包的位置
     * varint32 增加的熔炉值
     * varint32 最新的熔炉值
     * if (byteArray.available)
     *     varint32 物品静态数据长度
     *     bytes 物品静态数据
     *     bytes 物品动态数据
     *     
     * 如果读取到有物品，则此时将新物品放入到消失的那个装备的格子里
     */
    static final int S2C_EQUIPMENT_MELTING = 32;

    /**
     * 熔炼装备失败，附带byte错误码
     * 1、熔炉功能还未开放
     * 2、背包位置无效，或者这个位置上没装备
     * 3、装备不能熔炼
     */
    static final int S2C_EQUIPMENT_MELTING_FAIL = 33;

    static final ChannelBuffer ERR_MELTING_FAIL_NOT_OPEN = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_EQUIPMENT_MELTING_FAIL, 1);

    static final ChannelBuffer ERR_MELTING_FAIL_INVALID_POS = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_EQUIPMENT_MELTING_FAIL, 2);

    static final ChannelBuffer ERR_MELTING_FAIL_CANT_MELT = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_EQUIPMENT_MELTING_FAIL, 3);

    /**
     * 熔炼装备广播
     * varint64 heroId
     * UTF 英雄名字
     * varint32 装备品质
     * bytes 装备名称
     */
    static final int S2C_MELTING_BROADCAST = 34;

    static ChannelBuffer meltingBroadcast(long heroId, byte[] heroName,
            int quality, byte[] equipment){
        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID,
                S2C_MELTING_BROADCAST, computeVarInt64Size(heroId) + 2
                        + heroName.length + computeVarInt32Size(quality)
                        + equipment.length);

        writeVarInt64(buffer, heroId);
        writeUTF(buffer, heroName);
        writeVarInt32(buffer, quality);
        buffer.writeBytes(equipment);

        return buffer;
    }

    // ------------ end of 消息 --------------

    static ChannelBuffer moveMountEquipment(int depotPos, int equipPos){
        return onlySendHeadAnd2VarInt32Message(MODULE_ID,
                S2C_MOVE_MOUNT_EQUIPMENT, depotPos, equipPos);
    }

    public static ChannelBuffer getRefinedDataMsg(
            EquipmentRefinedForgeProto proto){
        return newProtobufMessage(MODULE_ID, S2C_EQUIPMENT_GET_REFINED_DATA,
                proto);
    }

    static ChannelBuffer refinedEquipmentMsg(int pos,
            RefinedData nextRefinedData, int intQuality){

        byte[] protoBytes = Empty.BYTE_ARRAY;
        if (nextRefinedData != null){
            protoBytes = nextRefinedData.getUpgradeProtoData(intQuality);
        }

        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID,
                S2C_EQUIPMENT_REFINED_SUCCESS,
                BufferUtil.computeVarInt32Size(pos) + protoBytes.length);
        BufferUtil.writeVarInt32(buffer, pos);

        if (nextRefinedData != null){
            buffer.writeBytes(protoBytes);
        }

        return buffer;
    }

//    public static ChannelBuffer getUpgradeQualityDataMsg(
//            EquipmentQualityForgeProto proto){
//        return newProtobufMessage(MODULE_ID,
//                S2C_EQUIPMENT_UPGRADE_QUALITY_DATA, proto);
//    }
//
//    static ChannelBuffer upgradeEquipmentQualityMsg(int pos, AddedData nextLevel){
//
//        int nextLevelLen = 0;
//        if (nextLevel != null){
//            nextLevelLen = nextLevel.getUpgradeQualityData().length;
//        }
//
//        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID,
//                S2C_EQUIPMENT_UPGRADE_QUALITY_SUCCESS,
//                BufferUtil.computeVarInt32Size(pos) + nextLevelLen);
//        BufferUtil.writeVarInt32(buffer, pos);
//
//        if (nextLevel != null){
//            buffer.writeBytes(nextLevel.getUpgradeQualityData());
//        }
//
//        return buffer;
//    }

    public static ChannelBuffer getUpgradeLevelDataMsg(
            EquipmentLevelForgeProto proto){
        return newProtobufMessage(MODULE_ID, S2C_EQUIPMENT_UPGRADE_LEVEL_DATA,
                proto);
    }

    static ChannelBuffer upgradeEquipmentLevelMsg(int pos,
            UpgradeLevelData nextLevel){

        int nextLevelLen = 0;
        if (nextLevel != null){
            nextLevelLen = nextLevel.getUpgradeLevelData().length;
        }

        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID,
                S2C_EQUIPMENT_UPGRADE_LEVEL_SUCCESS,
                BufferUtil.computeVarInt32Size(pos) + nextLevelLen);
        BufferUtil.writeVarInt32(buffer, pos);

        if (nextLevel != null){
            buffer.writeBytes(nextLevel.getUpgradeLevelData());
        }

        return buffer;
    }

    static ChannelBuffer refinedBroadcastMsg(byte[] heroName, byte[] equipment,
            int quality, int refinedTimes){

        ChannelBuffer buffer = newFixedSizeMessage(
                MODULE_ID,
                S2C_EQUIPMENT_REFINED_BROADCAST,
                4 + heroName.length + equipment.length
                        + BufferUtil.computeVarInt32Size(quality)
                        + BufferUtil.computeVarInt32Size(refinedTimes));

        BufferUtil.writeUTF(buffer, heroName);
        BufferUtil.writeUTF(buffer, equipment);
        BufferUtil.writeVarInt32(buffer, quality);
        BufferUtil.writeVarInt32(buffer, refinedTimes);

        return buffer;
    }

    static ChannelBuffer upgradeQualityBroadcastMsg(byte[] heroName,
            byte[] equipment, int quality){

        ChannelBuffer buffer = newFixedSizeMessage(
                MODULE_ID,
                S2C_EQUIPMENT_UPGRADE_QUALITY_BROADCAST,
                4 + heroName.length + equipment.length
                        + BufferUtil.computeVarInt32Size(quality));

        BufferUtil.writeUTF(buffer, heroName);
        BufferUtil.writeUTF(buffer, equipment);
        BufferUtil.writeVarInt32(buffer, quality);

        return buffer;
    }

    static ChannelBuffer upgradeLevelBroadcastMsg(byte[] heroName,
            byte[] equipment, byte[] newEquipment, int quality){

        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID,
                S2C_EQUIPMENT_UPGRADE_LEVEL_BROADCAST,
                6 + heroName.length + equipment.length + newEquipment.length
                        + BufferUtil.computeVarInt32Size(quality));

        BufferUtil.writeUTF(buffer, heroName);
        BufferUtil.writeUTF(buffer, equipment);
        BufferUtil.writeUTF(buffer, newEquipment);
        BufferUtil.writeVarInt32(buffer, quality);

        return buffer;
    }

    static ChannelBuffer meltEquipmentMsg(int pos, int toAdd, int newAmount){
        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID,
                S2C_EQUIPMENT_MELTING, computeVarInt32Size(pos)
                        + computeVarInt32Size(toAdd)
                        + computeVarInt32Size(newAmount));

        writeVarInt32(buffer, pos);
        writeVarInt32(buffer, toAdd);
        writeVarInt32(buffer, newAmount);
        return buffer;
    }

    static ChannelBuffer meltEquipmentMsg(int pos, int toAdd, int newAmount,
            Goods e){

        byte[] staticData = e.getData().getProtoBytes();
        byte[] dynamicData = e.encodeBytes4Client();

        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID,
                S2C_EQUIPMENT_MELTING, computeVarInt32Size(pos)
                        + computeVarInt32Size(toAdd)
                        + computeVarInt32Size(newAmount)
                        + computeVarInt32Size(staticData.length)
                        + staticData.length + dynamicData.length);

        writeVarInt32(buffer, pos);
        writeVarInt32(buffer, toAdd);
        writeVarInt32(buffer, newAmount);

        writeVarInt32(buffer, staticData.length);
        buffer.writeBytes(staticData);
        buffer.writeBytes(dynamicData);

        return buffer;
    }
}
