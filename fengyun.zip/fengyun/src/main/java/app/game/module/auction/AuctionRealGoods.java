package app.game.module.auction;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.data.goods.Equipment;
import app.game.data.goods.Goods;
import app.game.data.goods.GoodsData;
import app.game.entity.User;
import app.game.module.GoodsContainerModule;
import app.game.module.HeroController;
import app.protobuf.GoodsServerContent.GoodsServerProto;
import app.protobuf.LogContent.LogEnum.OperateType;

import com.google.protobuf.InvalidProtocolBufferException;
import com.mokylin.sink.util.BufferUtil;

class AuctionRealGoods extends AuctionRealItem{

    final Goods goods;

    final byte[] goodsServerProto;

    AuctionRealGoods(GoodsData goodsData, byte[] goodsServerProto, int cost,
            long sellerID, byte[] sellerNameBytes)
            throws InvalidProtocolBufferException{
        super(sellerID, sellerNameBytes, cost);

        this.goodsServerProto = goodsServerProto;
        GoodsServerProto proto = GoodsServerProto.parseFrom(goodsServerProto,
                User.extensionRegistry);

        this.goods = goodsData.decodeDontCheck(proto);
    }

    @Override
    int getItemId(){
        return goods.getId();
    }

    @Override
    String getItemName(){
        return goods.getData().name;
    }

    @Override
    int getItemCount(){
        return goods.getCount();
    }

    @Override
    boolean canHold(HeroController hc, boolean ifYuanbaoReduceTax){
        return hc.getDepot().hasEnoughEmptyCount(1);
    }

    @Override
    void doGive(HeroController hc, GoodsContainerModule goodsContainerModule,
            boolean ifYuanbaoReduceTax, OperateType type, String iEventId,
            long ctime){
        if (type == OperateType.SALE_BUY && goods instanceof Equipment){
            ((Equipment) goods).clearRefinedUpgradeTimes();
        }

        goodsContainerModule.addGoods(hc.getHero(), goods, hc.getSender(),
                hc.getHeroMiscModule(), type, 0, ctime);
    }

    @Override
    void writeGoods(ChannelBuffer buffer, boolean isYuanbaoReduceTax){
        byte[] staticInfo = goods.getData().getProtoBytes();
        byte[] dynamicInfo = goods.encodeBytes4Client();

        BufferUtil.writeVarInt32(buffer, staticInfo.length);
        buffer.writeBytes(staticInfo);
        BufferUtil.writeVarInt32(buffer, dynamicInfo.length);
        buffer.writeBytes(dynamicInfo);
    }

    @Override
    AuctionLog toAuctionLog(long buyerID, byte[] buyerName, long time,
            int collectableExp){
        return new AuctionLog(time, sellerHeroID, sellerNameBytes, buyerID,
                buyerName, cost, sellerCollectableMoney(),
                sellerCollectableYuanbao(), collectableExp, goods.getData()
                        .getRealAuctionType(), goodsServerProto, goods, 0);
    }

    @Override
    int sellerCollectableMoney(){
        return 0;
    }

    @Override
    int sellerCollectableYuanbao(){
        return cost - calculateTax(cost);
    }

    @Override
    int sellerCollectableConcurrency(){
        return sellerCollectableYuanbao();
    }

    @Override
    int sellerTax(){
        return calculateTax(cost);
    }

    @Override
    int buyerTax(){
        return 0;
    }
}
