package app.game.module;

import static app.game.module.ExamMessages.*;

import java.util.Arrays;
import java.util.Comparator;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.jboss.netty.buffer.ChannelBuffer;
import org.joda.time.DateTime;
import org.joda.time.DateTimeConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.data.exam.ExamDatas;
import app.game.data.exam.ExamQuestionData.ExamQuestion;
import app.game.data.goods.Goods;
import app.game.data.mail.Mail;
import app.game.entity.Hero;
import app.game.service.DelayedEventService;
import app.game.service.IThreadService;
import app.game.service.TimeService;
import app.game.service.WorldService;
import app.i18n.I18NConfig;
import app.i18n.I18NConfigs;
import app.i18n.MESSAGE_ENUM;
import app.protobuf.ConfigContent.ExamQuestionProto;
import app.protobuf.ConfigContent.ShengWangType;
import app.protobuf.LogContent.LogEnum.OperateType;
import app.utils.VariableConfig;

import com.google.inject.Inject;
import com.google.protobuf.ByteString;
import com.mokylin.collection.IntArrayList;
import com.mokylin.collection.LongConcurrentHashMap;
import com.mokylin.sink.util.BufferUtil;
import com.mokylin.sink.util.delay.DelayedEvent;

/**
 * @author Liwei
 *
 */
public class ExamModule{

    private static final Logger logger = LoggerFactory
            .getLogger(ExamModule.class);

    private final TimeService timeService;

    private final WorldService worldService;

    private final DelayedEventService delayedService;

    private final MailModule mailModule;

    private final ExamDatas examDatas;

    private final VariableConfig config;

    private final I18NConfig i18nConfig;

    private volatile ExamDoingQuestion question;

    // 排行榜数据
    private final LongConcurrentHashMap<HeroExamObject> heroExamObjectMap;

    @Inject
    ExamModule(final TimeService timeService, IThreadService threadService,
            WorldService worldService, DelayedEventService delayedService,
            final ExamDatas examDatas, VariableConfig config,
            MailModule mailModule, I18NConfigs i18nConfigs){
        this.timeService = timeService;
        this.worldService = worldService;
        this.delayedService = delayedService;
        this.examDatas = examDatas;
        this.config = config;
        this.mailModule = mailModule;
        this.i18nConfig = i18nConfigs.getI18N();

        heroExamObjectMap = new LongConcurrentHashMap<>();

        long ctime = timeService.getCurrentTime();

        // 定时开启活动，每日一次
        long startTime = new DateTime(ctime).withTimeAtStartOfDay()
                .plusMinutes(examDatas.startHour * 60 + examDatas.startMinute)
                .getMillis();

        if (startTime < ctime && startTime + examDatas.duration >= ctime){
            startExam(startTime, ctime); // 处于等待状态，初始化今日的考题
        }

        // 初始化考题
        long initialDelay = startTime - ctime;
        if (initialDelay < 0){
            initialDelay += DateTimeConstants.MILLIS_PER_DAY;
        }

        threadService.getScheduledExecutorService().scheduleAtFixedRate(
                new Runnable(){
                    @Override
                    public void run(){
                        try{
                            long ctime = timeService.getCurrentTime();
                            long startTime = new DateTime(ctime)
                                    .withTimeAtStartOfDay()
                                    .plusMinutes(
                                            examDatas.startHour * 60
                                                    + examDatas.startMinute)
                                    .getMillis();

                            startExam(startTime, ctime);
                        } catch (Throwable ex){
                            logger.error("ExamModule.ExamModule 定时开始答题出错", ex);
                        }
                    }
                }, initialDelay, DateTimeConstants.MILLIS_PER_DAY,
                TimeUnit.MILLISECONDS);

        // 每题结束统计排行榜，更新考题

        // 1min / answer-show / answer-show
        // imin-answer / show-answer / ...
    }

    void startExam(long startTime, long ctime){
        logger.debug("答题开始，{}", startTime);

        IntArrayList indexList = new IntArrayList();

        long seed = (startTime >>> 1) + 9850;

        // 保证所有服统一
        Random random = new Random(seed);

        // 开始答题，初始化本次所有题目
        ExamQuestion[] questions = examDatas.randomQuestion(random, indexList);

        long time = startTime + VariableConfig.EXAM_WAIT_TIME;
        // 初始化第一题数据
        final ExamDoingQuestion doingQuestion = ExamDoingQuestion
                .newExamDoingQuestion(time, questions, ctime);
        if (doingQuestion == null){
            logger.error("ExamModule出题的时候，没有找到第一题?");
            return;
        }

        // 广播题目已更新消息
        this.question = doingQuestion;
        worldService.broadcast(EXAM_QUESTION_UPDATE);

        // 提交第一题答题结束的DelayEvent
        final long endTime = doingQuestion.endTime + 128;
        delayedService.addDelayedEvent(new DelayedEvent(){

            @Override
            public void handle(long ctime){
                updateNextQuestion(ctime, doingQuestion);
            }

            @Override
            public long getEventTime(){
                return endTime;
            }
        });
    }

    private void updateNextQuestion(long ctime, ExamDoingQuestion prev){
        ExamDoingQuestion question = this.question;
        if (question != prev){
            logger.error("updateNextQuestion() prev != question，什么情况，多线程操作吗？");
            return;
        }

        logger.debug("刷新下一题答题，{}", question.index);

        // 刷新排行榜
        final HeroExamObject[] rankedHeros = doRank();

        if (question.index + 1 < examDatas.getExamCountPerTimes()){
            // 设置下一题
            final ExamDoingQuestion doingQuestion = question
                    .nextQuestion(rankedHeros);

            // 广播题目已更新消息
            this.question = doingQuestion;
            worldService.broadcast(EXAM_QUESTION_UPDATE);

            // 提交下一题答题结束的DelayEvent
            final long endTime = doingQuestion.endTime + 128;
            delayedService.addDelayedEvent(new DelayedEvent(){

                @Override
                public void handle(long ctime){
                    updateNextQuestion(ctime, doingQuestion);
                }

                @Override
                public long getEventTime(){
                    return endTime;
                }
            });

            return;
        }

        // 最后一题
        this.question = null;
        if (rankedHeros.length > 0){
            // 前3奖励
            int c = Math.min(rankedHeros.length,
                    VariableConfig.EXAM_RANK_MAX_COUNT);
            for (int i = 0; i < c; i++){
                HeroExamObject obj = rankedHeros[i];
                obj.rankPos = i + 1;

                byte[] scoreBytes = String.valueOf(obj.score).getBytes();
                byte[] rankPosBytes = String.valueOf(obj.rankPos).getBytes();

                Goods prizeGoods = examDatas.newTopPrize(i, ctime);

                Mail mail = Mail
                        .newMail(obj.heroId, ctime, i18nConfig.getMessage(
                                MESSAGE_ENUM.EXAM_RANK_PRIZE, scoreBytes,
                                rankPosBytes), 0, 0, 0, new Goods[]{prizeGoods});

                mailModule.addMailEvent(mail);
            }

            worldService.broadcast(examFinishedMsg(rankedHeros[0].heroId,
                    rankedHeros[0].heroName));
        } else{
            worldService.broadcast(EMPTY_EXAM_FINISHED_MSG);
        }

        // 一分钟后清掉这个数据
        final long endTime = ctime + 60000;
        delayedService.addDelayedEvent(new DelayedEvent(){

            @Override
            public void handle(long ctime){
                heroExamObjectMap.clear(); // 给完奖励，清掉这个
            }

            @Override
            public long getEventTime(){
                return endTime;
            }
        });
    }

    private HeroExamObject[] doRank(){
        HeroExamObject[] array = heroExamObjectMap.values().toArray(
                HeroExamObject.EMPTY_ARRAY);

        for (HeroExamObject o : array){
            o.score4Rank = o.score;
            o.answerCostTime4Rank = o.answerCostTime;
        }

        Arrays.sort(array, HeroExamObject.COMP);

        return array;
    }

    public void onMessage(int sequenceID, ChannelBuffer buffer,
            HeroController hc){
        switch (sequenceID){
            case C2S_EXAM_GET_QUESTION:{
                onGetQuestion(hc, buffer);
                return;
            }
            case C2S_EXAM_ANSWER_QUESTION:{
                onAnswerQuestion(hc, buffer);
                return;
            }
            case C2S_EXAM_REMOVE_WRONG_ANSWER:{
                onRemoveWrongAnswer(hc, buffer);
                return;
            }
            case C2S_EXAM_SELF_DATA:{
                onGetSelfData(hc, buffer);
                return;
            }
            case C2S_EXAM_DIALOG_MSG:{
                onGetDialogMsg(hc, buffer);
                return;
            }
            default:{
                logger.error("ExamModule模块收到未知消息: {}", sequenceID);
            }
        }
    }

    private void onGetDialogMsg(HeroController hc, ChannelBuffer buffer){

        HeroExamObject obj = heroExamObjectMap.get(hc.getID());
        if (obj == null){
            hc.sendMessage(EMPTY_DIALOG_MSG);
            return;
        }

        hc.sendMessage(getDialogMsg(obj.score, obj.rankPos, obj.accExp,
                obj.accMoney, obj.accRealAir));
    }

    private void onGetQuestion(HeroController hc, ChannelBuffer buffer){

        if (hc.getHero().getLevel() < config.EXAM_REQUIRE_LEVEL){
            hc.sendMessage(ERR_EXAM_GET_QUESTION_FAIL_LEVEL_NOT_ENOUGH);
            return;
        }

        ExamDoingQuestion question = this.question;
        if (question != null){
            hc.sendMessage(question.examMsg);
            return;
        }

        hc.sendMessage(ERR_EXAM_GET_QUESTION_FAIL_UNACTIVE);
    }

    private void onAnswerQuestion(HeroController hc, ChannelBuffer buffer){
        if (hc.getHero().getLevel() < config.EXAM_REQUIRE_LEVEL){
            hc.sendMessage(ERR_ANSWER_QUESTION_FAIL_LEVEL_NOT_ENOUGH);
            return;
        }

        int result = hc.getHero().setDailyActivity(examDatas.EXAM_KEY, 0);
        if (result > 0){
            logger.warn("ExamModule.onAnswerQuestion时, 已经花钱参与过了");
            hc.sendMessage(ERR_ANSWER_QUESTION_FAIL_PAYBACK);
            return;
        } else if (result < 0){
            hc.sendMessage(WelfareMessages
                    .dailyActivityJoinedMsg(examDatas.EXAM_KEY));
        }

        long ctime = timeService.getCurrentTime();
        ExamDoingQuestion question = this.question;
        if (question == null || !question.isAnswerTime(ctime)){
            hc.sendMessage(ERR_ANSWER_QUESTION_FAIL_INVALID_ANSWER_TIME);
            return;
        }

        HeroExamObject obj = getOrCreateExamObject(hc);
        // answeredQuestion的0表示一题都没有答，question.index的0表示第一题
        if (obj.answeredQuestion > question.index){
            logger.warn("答题提交答案，但是这道题已经答过了");
            hc.sendMessage(ERR_ANSWER_QUESTION_FAIL_ANSWERED);
            return;
        }

        int answer = BufferUtil.readVarInt32(buffer);

        int answerIndex = answer >>> 1;
        if (answerIndex >= VariableConfig.ANSWER_COUNT){
            logger.warn("答题提交答案，但是答案索引无效");
            hc.sendMessage(ERR_ANSWER_QUESTION_FAIL_CANT_INVALID_ANSWER);
            return;
        }

        obj.answeredQuestion = question.index + 1;

        long answerCostTime = Math.max(Math.min(question.endTime - ctime,
                VariableConfig.EXAM_ANSWER_TIME), 0);
        obj.answerCostTime += answerCostTime;

        if (answerIndex == question.getCorrectIndex()){
            boolean isDoubleScore = false;
            if ((answer & 1) > 0){
                if (obj.useDoubleScoreTimes < config.EXAM_DOUBLE_SCORE_MAX_TIMES){
                    ++obj.useDoubleScoreTimes;
                    isDoubleScore = true;
                } else{
                    // 这里打个警告日志，客户端发消息有问题
                    logger.warn("答题使用双倍积分，但是次数已经用完了");
                }

                hc.sendMessage(useDoubleScoreTimesMsg(obj.useDoubleScoreTimes));
            }

            int second = (int) ((answerCostTime + 999) / 1000); // 答题花了多少秒
            double c = Math.pow(second, 0.25d);

            // 回答正确
            int scoreToAdd = second;
            int expToAdd = (int) Math.max(80000, 80000 * c);
            int moneyToAdd = (int) Math.max(20000, 20000 * c);
            int realAirToAdd = (int) Math.max(500, 500 * c);
            if (isDoubleScore){
                scoreToAdd *= 2;
                expToAdd *= 2;
                moneyToAdd *= 2;
                realAirToAdd *= 2;
            }

            obj.score += scoreToAdd; // 积分
            obj.accExp += expToAdd; // 累计获得经验
            obj.accMoney += moneyToAdd; // 累计获得银两
            obj.accRealAir += realAirToAdd; // 累计获得真气

            // 给奖励
            hc.getHeroFightModule().addExperience(expToAdd, OperateType.EXAM,
                    null);
            hc.getHeroMiscModule().addMoneyAnyway(moneyToAdd, OperateType.EXAM,
                    null);
            hc.getHeroMiscModule().addRealAirAnyway(realAirToAdd,
                    OperateType.EXAM, null);

            hc.sendMessage(answerQuestionMsg(obj.score, expToAdd, moneyToAdd,
                    realAirToAdd));
        } else{
            hc.sendMessage(ANSWER_WRONG_MSG);
        }

        // 声望
        hc.getHeroMiscModule().tryCompleteShengWangTask(ShengWangType.SW_EXAM,
                true, 1);
    }

    private void onRemoveWrongAnswer(HeroController hc, ChannelBuffer buffer){
        if (hc.getHero().getLevel() < config.EXAM_REQUIRE_LEVEL){
            hc.sendMessage(ERR_REMOVE_WRONG_ANSWER_FAIL_LEVEL_NOT_ENOUGH);
            return;
        }

        int result = hc.getHero().setDailyActivity(examDatas.EXAM_KEY, 0);
        if (result > 0){
            logger.warn("ExamModule.onRemoveWrongAnswer时, 已经花钱参与过了");
            hc.sendMessage(ERR_REMOVE_WRONG_ANSWER_FAIL_PAYBACK);
            return;
        } else if (result < 0){
            hc.sendMessage(WelfareMessages
                    .dailyActivityJoinedMsg(examDatas.EXAM_KEY));
        }

        long ctime = timeService.getCurrentTime();
        ExamDoingQuestion question = this.question;
        if (question == null || !question.isAnswerTime(ctime)){
            hc.sendMessage(ERR_REMOVE_WRONG_ANSWER_FAIL_INVALID_ANSWER_TIME);
            return;
        }

        HeroExamObject obj = getOrCreateExamObject(hc);
        // answeredQuestion的0表示一题都没有答，question.index的0表示第一题
        if (obj.answeredQuestion > question.index){
            logger.warn("答题移除错误答案，但是这道题已经答过了");
            hc.sendMessage(ERR_REMOVE_WRONG_ANSWER_FAIL_ANSWERED);
            return;
        }

        if (obj.removeWrongAnswerTimes >= config.EXAM_REMOVE_WRONG_ANSWERT_MAX_TIMES){
            logger.warn("答题移除错误答案，但是次数已经用完了");
            hc.sendMessage(ERR_REMOVE_WRONG_ANSWER_FAIL_CANT_REMOVE_WRONG);
            return;
        }

        ++obj.removeWrongAnswerTimes;
        hc.sendMessage(REMOVE_WRONG_ANSWER);
    }

    private HeroExamObject getOrCreateExamObject(HeroController hc){

        HeroExamObject obj = heroExamObjectMap.get(hc.getID());
        if (obj == null){
            obj = new HeroExamObject(hc.getHero());
            HeroExamObject oldObject = heroExamObjectMap.putIfAbsent(
                    hc.getID(), obj);

            if (oldObject != null){
                return oldObject;
            }
        }

        return obj;
    }

    private void onGetSelfData(HeroController hc, ChannelBuffer buffer){

        if (hc.getHero().getLevel() < config.EXAM_REQUIRE_LEVEL){
            hc.sendMessage(ERR_EXAM_SELF_DATA_FAIL_LEVEL_NOT_ENOUGH);
            return;
        }

        int result = hc.getHero().setDailyActivity(examDatas.EXAM_KEY, 0);
        if (result > 0){
            logger.warn("ExamModule.onGetSelfData时, 已经花钱参与过了");
            hc.sendMessage(ERR_EXAM_SELF_DATA_FAIL_PAYBACK);
            return;
        } else if (result < 0){
            hc.sendMessage(WelfareMessages
                    .dailyActivityJoinedMsg(examDatas.EXAM_KEY));
        }

        ExamDoingQuestion question = this.question;
        if (question == null){
            hc.sendMessage(ERR_EXAM_SELF_DATA_FAIL_UNACTIVE);
            return;
        }

        HeroExamObject obj = heroExamObjectMap.get(hc.getID());
        if (obj == null){
            hc.sendMessage(EMPTY_SELF_DATA_MSG);
            return;
        }

        hc.sendMessage(getSelfDataMsg(obj.answeredQuestion,
                obj.useDoubleScoreTimes, obj.removeWrongAnswerTimes, obj.score));
    }

    private static class HeroExamObject{

        static final HeroExamObject[] EMPTY_ARRAY = new HeroExamObject[0];

        static final Comparator<HeroExamObject> COMP = new Comparator<HeroExamObject>(){

            @Override
            public int compare(HeroExamObject o1, HeroExamObject o2){

                // 分数大的在前
                if (o1.score4Rank != o2.score4Rank){
                    return o2.score4Rank - o1.score4Rank;
                }

                // 时间小的在前
                if (o1.answerCostTime4Rank == o2.answerCostTime4Rank){
                    return 0;
                }

                return o1.answerCostTime4Rank < o2.answerCostTime4Rank ? -1 : 1;
            }
        };

        private final long heroId;

        private final byte[] heroName;

        private final ByteString heroNameString;

        // 答到第几题，0表示一题都没回答
        private int answeredQuestion;

        // 双倍积分使用次数
        private int useDoubleScoreTimes;

        // 排错使用次数
        private int removeWrongAnswerTimes;

        // 答题积分
        private int score;

        // 答题花费的时间
        private long answerCostTime;

        // 排名，从1开始，0表示未上榜
        private int rankPos;

        // 累计获得奖励
        private int accExp;
        private int accMoney;
        private int accRealAir;

        private int score4Rank;

        private long answerCostTime4Rank;

        HeroExamObject(Hero hero){
            this.heroId = hero.getID();
            this.heroName = hero.getNameBytes();
            this.heroNameString = hero.getNameByteString();
        }
    }

    private static class ExamDoingQuestion{

        static ExamDoingQuestion newExamDoingQuestion(long startTime,
                ExamQuestion[] allQuestions, long ctime){

            int t = VariableConfig.EXAM_ANSWER_TIME
                    + VariableConfig.EXAM_SHOW_ANSWER_TIME;
            long stime = startTime - VariableConfig.EXAM_SHOW_ANSWER_TIME;

            int index = -1;
            for (int i = 1; i <= allQuestions.length; i++){
                if (stime + (t * i) > ctime){
                    index = i - 1;
                    break;
                }
            }

            if (index < 0){
                // 比最后一题都大...
                return null;
            }

            long realStartTime = startTime + t * index;

            ExamQuestion question = allQuestions[index];
            ChannelBuffer buffer = getExamQuestionMsg(getQuestionProto(index,
                    question, null, realStartTime));

            return new ExamDoingQuestion(realStartTime, allQuestions, index,
                    question, buffer);
        }

        public boolean isAnswerTime(long ctime){
            return ctime >= startTime && ctime <= endTime;
        }

        // 本次答题所有问题
        private final ExamQuestion[] allQuestions;

        // 开始答题时间
        private final long startTime;

        // 答题结束时间
        private final long endTime;

        // 当前是第几题，从0开始
        private final int index;

        private final ExamQuestion doingQuestion;

        private final ChannelBuffer examMsg;

        private ExamDoingQuestion(long startTime, ExamQuestion[] allQuestions,
                int index, ExamQuestion doingQuestion, ChannelBuffer examMsg){
            assert allQuestions[index] == doingQuestion;

            this.allQuestions = allQuestions;
            this.index = index;
            this.doingQuestion = doingQuestion;
            this.examMsg = examMsg;

            this.startTime = startTime;
            endTime = startTime + VariableConfig.EXAM_ANSWER_TIME;
        }

        ExamDoingQuestion nextQuestion(HeroExamObject[] rankedHeros){

            int index = this.index + 1;
            if (index < allQuestions.length){
                long nextStartTime = endTime
                        + VariableConfig.EXAM_SHOW_ANSWER_TIME;

                ExamQuestion question = allQuestions[index];
                ChannelBuffer buffer = getExamQuestionMsg(getQuestionProto(
                        index, question, rankedHeros, nextStartTime));

                return new ExamDoingQuestion(nextStartTime, allQuestions,
                        index, question, buffer);
            }

            return null;
        }

        int getCorrectIndex(){
            return doingQuestion.getCorrectIndex();
        }
    }

    static ExamQuestionProto getQuestionProto(int index, ExamQuestion question,
            HeroExamObject[] rankedHeros, long startTime){
        ExamQuestionProto.Builder builder = ExamQuestionProto.newBuilder()
                .setIndex(index).setStartTime(startTime);

        if (question != null){
            question.encode(builder);
        }

        if (rankedHeros != null){
            int c = Math.min(rankedHeros.length, VariableConfig.EXAM_TOP_COUNT);
            for (int i = 0; i < c; i++){
                HeroExamObject obj = rankedHeros[i];
                builder.addTopHeroId(obj.heroId);
                builder.addTopHeroNameBytes(obj.heroNameString);
                builder.addTopHeroScore(obj.score);
            }

            if (rankedHeros.length > VariableConfig.EXAM_TOP_COUNT){
                c = Math.min(rankedHeros.length,
                        VariableConfig.EXAM_RANK_MAX_COUNT);

                for (int i = VariableConfig.EXAM_TOP_COUNT; i < c; i++){
                    builder.addRankedHeroId(rankedHeros[i].heroId);
                }
            }
        }

        return builder.build();
    }
}
