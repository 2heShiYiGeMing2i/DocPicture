package app.game.module.guild;

import java.util.List;

import app.game.data.GameObjects;
import app.game.data.goods.GoodsDatas;
import app.protobuf.ConfigContent.GuildConfig;

import com.google.inject.Inject;
import com.mokylin.collection.IntHashMap;
import com.mokylin.sink.util.parse.ObjectParser;

public class GuildContributionGoodsShop{

    public static final String LOCATION = "config/data/guild/contribution_goods.txt";

    private final GuildContributionGoods[] goods;

    /**
     * 对应位置的GuildContributionGoods的id, 用来存在数据库中. 不是物品的id
     */
    private final int[] ids;

    final int goodsCount;

    @Inject
    GuildContributionGoodsShop(GameObjects go, GoodsDatas goodsDatas){
        List<ObjectParser> data = go.loadFile(LOCATION);

        this.goodsCount = data.size();
        IntHashMap<GuildContributionGoods> idMap = new IntHashMap<>(goodsCount);
        this.goods = new GuildContributionGoods[goodsCount];
        this.ids = new int[goodsCount];

        int index = 0;
        for (ObjectParser p : data){
            GuildContributionGoods g = new GuildContributionGoods(p,
                    goodsDatas, index);

            this.ids[index] = g.id;

            this.goods[index++] = g;

            idMap.putUnique(g.id, g);
        }
    }

    int[] getIDs(){
        return ids;
    }

    GuildContributionGoods getGoodsByID(int id){
        for (GuildContributionGoods g : goods){
            if (g.id == id){
                return g;
            }
        }
        return null;
    }

    GuildContributionGoods getGoods(int index){
        if (index >= 0 && index < goods.length){
            return goods[index];
        }
        return null;
    }

    public void encodeGoods(GuildConfig.Builder config){
        for (GuildContributionGoods g : goods){
            config.addContributionGoodsProto(g.encode());
        }
    }
}
