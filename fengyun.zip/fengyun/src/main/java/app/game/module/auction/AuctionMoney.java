package app.game.module.auction;

import org.jboss.netty.buffer.ChannelBuffer;

import app.protobuf.GoodsServerContent.GoodsType;

import com.mokylin.sink.util.BufferUtil;

class AuctionMoney extends AuctionItem{

    private static final int GOODS_TYPE = GoodsType.MONEY_GOODS.getNumber();

    private static final int GOODS_TYPE_VARINT32_LEN = BufferUtil
            .computeVarInt32Size(GOODS_TYPE);

    private final int amount;

    AuctionMoney(long id, int amount, int yuanbao, long combineId,
            byte[] heroName){
        super(id, combineId, heroName, yuanbao);

        this.amount = amount;
    }

    @Override
    public void writeGoods(ChannelBuffer buffer){
        BufferUtil.writeVarInt32(
                buffer,
                GOODS_TYPE_VARINT32_LEN
                        + BufferUtil.computeVarInt32Size(amount));
        BufferUtil.writeVarInt32(buffer, GOODS_TYPE);
        BufferUtil.writeVarInt32(buffer, amount);
    }
}
