package app.game.module;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.annotations.VisibleForTesting;
import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;

public class BugLogger{
    private static final Logger logger = LoggerFactory
            .getLogger(BugLogger.class);

    private final Cache<String, Boolean> cache;

    public BugLogger(){
        cache = CacheBuilder.newBuilder().concurrencyLevel(4).maximumSize(4096)
                .initialCapacity(512).build();
    }

    public void add(String str){
        Boolean present = cache.getIfPresent(str);
        if (present != null){
            return;
        }

        cache.put(str, Boolean.TRUE);
        log(str);
    }

    @VisibleForTesting
    void log(String str){
        logger.error("BugLogger: {}", str);
    }
}
