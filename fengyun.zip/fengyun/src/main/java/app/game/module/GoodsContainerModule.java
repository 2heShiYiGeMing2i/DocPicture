/**
 *
 */
package app.game.module;

import static app.game.module.GoodsContainerMessages.*;
import static app.game.module.MiscModule.DisconnectReason.INTERNAL_ERROR_SORT_ERROR;
import static app.protobuf.LogContent.LogEnum.OperateType.*;

import java.util.ArrayDeque;
import java.util.List;

import org.jboss.netty.buffer.ChannelBuffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.data.SpriteStat;
import app.game.data.SpriteStatBuilder;
import app.game.data.Vip;
import app.game.data.goods.Goods;
import app.game.data.goods.GoodsAddHelper;
import app.game.data.goods.GoodsContainerUnlockData;
import app.game.data.goods.GoodsData;
import app.game.data.goods.GoodsData.Efficacy;
import app.game.data.goods.GoodsTryAddResult;
import app.game.data.goods.YuanbaoPackageData;
import app.game.data.task.TaskCallbackModule;
import app.game.entity.Depot;
import app.game.entity.GoodsContainer;
import app.game.entity.GoodsSorter;
import app.game.entity.Hero;
import app.game.entity.Storage;
import app.game.entity.record.goods.GoodsOwnership;
import app.game.entity.record.goods.IllegalGoodsCountException;
import app.game.module.GoodsContainerMessages.CLEAN_GOODS_RESULT;
import app.game.module.GoodsContainerMessages.MOVE_GOODS_RESULT;
import app.game.module.GoodsContainerMessages.ReduceCooldownGoodsResult;
import app.game.module.GoodsContainerMessages.SPLIT_GOODS_RESULT;
import app.game.module.scene.IScene;
import app.game.module.scene.NormalScene;
import app.game.service.TimeService;
import app.game.service.log.LogService;
import app.message.ISender;
import app.protobuf.LogContent.LogEnum.OperateType;
import app.utils.VariableConfig;

import com.google.common.annotations.VisibleForTesting;
import com.google.common.collect.Lists;
import com.google.inject.Inject;
import com.mokylin.collection.IntArrayList;
import com.mokylin.collection.LongArrayList;
import com.mokylin.sink.util.BufferUtil;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.annotation.SelfThreadOnly;

/**
 * 物品模块，包含物品使用、移动、整理等操作
 *
 * @author Liwei
 *
 */
public class GoodsContainerModule{
    private static final Logger logger = LoggerFactory
            .getLogger(GoodsContainerModule.class);

    private final TimeService timeService;

    private final MailModule mailModule;

    private final LogService logService;

    private GoodsSorter goodsSorter;

    private TaskCallbackModule taskCallbackModule;

    @Inject
    public GoodsContainerModule(TimeService timeService, MailModule mailModule,
            LogService logService){
        this(timeService, mailModule, logService, GoodsSorter.FAST_SORTER);
    }

    @VisibleForTesting
    GoodsContainerModule(TimeService timeService, MailModule mailModule,
            LogService logService, GoodsSorter goodsSorter){
        this.timeService = timeService;
        this.mailModule = mailModule;
        this.logService = logService;
        this.goodsSorter = goodsSorter;
    }

    public void setTaskCallbackModule(TaskCallbackModule module){
        taskCallbackModule = module;
    }

    @VisibleForTesting
    GoodsSorter getGoodsSorter(){
        return goodsSorter;
    }

    public void onMessage(int sequenceID, ChannelBuffer buffer,
            HeroController hc){
        switch (sequenceID){
            case C2S_DEPOT_STORAGE_OPEN_SLOT:{
                processOpenSlot(hc, buffer);
                return;
            }
            case C2S_MOVE_GOODS:{
                processGoodsMove(hc, buffer);
                return;
            }
            case C2S_SPLIT_GOODS:{
                processGoodsSplit(hc, buffer);
                return;
            }
            case C2S_CLEAN:{
                processClean(hc, buffer);
                return;
            }
            case C2S_DEPOT_STORAGE_GET_DATA:{
                processGetStorageData(hc, buffer);
                return;
            }
            case C2S_USE_GOODS:{
                processUseGoods(hc, buffer);
                return;
            }
            case C2S_DROP_GOODS:{
                processDropGoods(hc, buffer);
                return;
            }
            case C2S_YUANBAO_PACKAGE_SHOW_GOODS:{
                processGetYuanbaoPackageShowGoods(hc, buffer);
                return;
            }
            default:{
                logger.warn("GoodsContainerModule模块收到未知消息: {}", sequenceID);
            }
        }
    }

    private void processOpenSlot(HeroController hc, ChannelBuffer buffer){

        int type = buffer.readUnsignedByte();
        int unlockPos = BufferUtil.readVarInt32(buffer);

        GoodsContainer gc = null;
        int openSlotSpeed = 0;
        switch (type){
            case 0:{
                gc = hc.getDepot();

                if (hc.getHero().getVip() != null){
                    openSlotSpeed = hc.getHero().getVip()
                            .getDepotOpenSlotSpeed();
                }
                break;
            }
            case 1:{
                gc = hc.getStorage();

                if (gc == null){
                    logger.warn("没有仓库，还发送仓库解锁消息？");
                    hc.sendMessage(ERR_OPEN_SLOT_FAIL_STORAGE_NOT_OPEN);
                    return;
                }

                if (hc.getHero().getVip() != null){
                    openSlotSpeed = hc.getHero().getVip()
                            .getStorageOpenSlotSpeed();
                }
                break;
            }
            default:{
                logger.warn("手动解锁格子，无效的类型，type: {}", type);
                hc.sendMessage(ERR_OPEN_SLOT_FAIL_TYPE_INVALID);
                return;
            }
        }

        if (gc.isInvalidUnlockPos(unlockPos)){
            logger.warn("手动解锁格子，无效的位置，type: {}", type);
            hc.sendMessage(ERR_OPEN_SLOT_FAIL_UNLOCK_POS_INVALID);
            return;
        }

        // 计算出解锁格子的ID
        int unlockId = unlockPos - gc.getInitSize() + 1;

        GoodsContainerUnlockData unlockingData = gc.getUnlockingData();
        if (unlockingData == null){
            hc.sendMessage(ERR_OPEN_SLOT_FAIL_SLOT_ALL_UNLOCKED);
            return;
        }

        // 先计算正在解锁的格子的花费 openedId + 1
        long ctime = timeService.getCurrentTime();
        long accOpenTime = gc.getAccOpenTime(ctime);

        // vip时间加成
        if (openSlotSpeed > 0){
            accOpenTime = accOpenTime + accOpenTime / 100 * openSlotSpeed;
        }

        int cost = 0;
        int exp = unlockingData.exp;
        SpriteStat sp = unlockingData.spriteStat;
        if (accOpenTime < unlockingData.unlockTime){
            long worseOpenTime = unlockingData.unlockTime - accOpenTime;

            cost += Math.max(1, unlockingData.unlockCost * worseOpenTime
                    / unlockingData.unlockTime);
        }

        SpriteStat toAdds;
        if (unlockingData.openSlotCount < unlockId){
            SpriteStatBuilder builder = SpriteStatBuilder.newBuilder();
            builder.add(sp);
            for (int i = unlockingData.openSlotCount; i < unlockId; i++){
                GoodsContainerUnlockData nextLevel = unlockingData.nextLevel;
                if (nextLevel == null){
                    // 防御性
                    logger.error("手动开格子时候，发现nextLevel=null");
                    return;
                }

                cost += nextLevel.unlockCost;
                exp += nextLevel.exp;
                builder.add(nextLevel.spriteStat);
                unlockingData = nextLevel;
            }
            toAdds = builder.build();
        } else{
            toAdds = sp;
        }

        // 扣元宝
        if (!hc.heroMiscModule.tryReduceBindedYuanbaoOrYuanbao(
                Math.max(cost, 1), OPEN_GRID, null)){
            logger.debug("手动解锁格子，元宝不足");
            hc.sendMessage(ERR_OPEN_SLOT_FAIL_YUANBAO_NOT_ENOUGH);
            return;
        }

        // 加经验
        hc.heroFightModule.addExperience(exp, OPEN_GRID, null);

        // 加属性
        hc.heroFightModule.changeBaseStat(true, toAdds, ctime);

        // 开格
        gc.unlockSlot(unlockingData, ctime);
        hc.sendMessage(manualOpenSlotMsg(type, unlockPos, cost,
                unlockingData.nextLevel, unlockingData.accStatData, ctime));

        // 更新战斗力
        hc.getHeroFightModule().updateFightingAmount();
    }

    public void autoOpenSlot(HeroController hc, long ctime){

        Vip vip = hc.getHero().getVip();

        int depotOpenSlotSpeed = 0;
        int storageOpenSlotSpeed = 0;
        if (vip != null){
            depotOpenSlotSpeed = vip.getDepotOpenSlotSpeed();
            storageOpenSlotSpeed = vip.getStorageOpenSlotSpeed();
        }

        doAutoOpenSlot(hc, ctime, hc.getDepot(), depotOpenSlotSpeed);

        Storage storage = hc.getStorage();
        if (storage != null){
            doAutoOpenSlot(hc, ctime, storage, storageOpenSlotSpeed);
        }

    }

    private void doAutoOpenSlot(HeroController hc, long ctime,
            GoodsContainer gc, int openSlotSpeed){

        GoodsContainerUnlockData unlockingData = gc.getUnlockingData();

        if (unlockingData == null){
            // 已经开完了
            return;
        }

        long accOpenTime = gc.getAccOpenTime(ctime);

        // vip时间加成
        if (openSlotSpeed > 0){
            accOpenTime = accOpenTime + accOpenTime / 100 * openSlotSpeed;
        }

        if (accOpenTime < unlockingData.unlockTime){
            // 时间还未到
            return;
        }

        // 加经验
        hc.heroFightModule.addExperience(unlockingData.exp, OPEN_GRID, null);

        // 加属性
        hc.heroFightModule
                .changeBaseStat(true, unlockingData.spriteStat, ctime);

        // 开格
        int unlockPos = gc.size();
        gc.unlockSlot(unlockingData, ctime);

        hc.sendMessage(autoOpenSlotMsg(gc.getType(), unlockPos,
                unlockingData.nextLevel, unlockingData.accStatData, ctime));

        // 更新战斗力
        hc.heroFightModule.updateFightingAmount();

//        logger.debug("自动开格子，type:{} pos:{}", gc.getType(), unlockPos);
    }

    private void processGoodsMove(HeroController hc, ChannelBuffer buffer){
        int type = buffer.readUnsignedByte();
        int spos = BufferUtil.readVarInt32(buffer);
        int tpos = BufferUtil.readVarInt32(buffer);

        GoodsContainer sgc;
        GoodsContainer tgc;
        switch (type){
            case 0:{
                // 背包 -> 背包
                if (spos == tpos){
                    logger.warn("移动物品（背包），位置一样");
                    hc.sendMessage(MOVE_GOODS_RESULT.SOURCE_POS_EQUAL_TARGET_POS
                            .getMessage());
                    return;
                }

                sgc = tgc = hc.getDepot();
                break;
            }
            case 1:{
                // 仓库 -> 仓库
                if (spos == tpos){
                    logger.warn("移动物品（仓库），位置一样");
                    hc.sendMessage(MOVE_GOODS_RESULT.SOURCE_POS_EQUAL_TARGET_POS
                            .getMessage());
                    return;
                }

                sgc = tgc = hc.getStorage();
                if (tgc == null){
                    logger.warn("移动物品（仓库），仓库还未开放");
                    hc.sendMessage(MOVE_GOODS_RESULT.STORAGE_NOT_OPEN
                            .getMessage());
                    return;
                }
                break;
            }
            case 2:{
                // 背包 -> 仓库
                sgc = hc.getDepot();
                tgc = hc.getStorage();

                if (tgc == null){
                    logger.warn("移动物品（仓库），仓库还未开放");
                    hc.sendMessage(MOVE_GOODS_RESULT.STORAGE_NOT_OPEN
                            .getMessage());
                    return;
                }
                break;
            }
            case 3:{
                // 仓库 -> 背包
                sgc = hc.getStorage();
                tgc = hc.getDepot();

                if (sgc == null){
                    logger.warn("移动物品（仓库），仓库还未开放");
                    hc.sendMessage(MOVE_GOODS_RESULT.STORAGE_NOT_OPEN
                            .getMessage());
                    return;
                }
                break;
            }
            default:{
                logger.warn("移动物品，类型无效，type: {}", type);
                hc.sendMessage(MOVE_GOODS_RESULT.TYPE_INVALID.getMessage());
                return;
            }
        }

        if (sgc.isInvalidPos(spos)){
            logger.warn("移动物品，源位置无效，pos: {}", spos);
            hc.sendMessage(MOVE_GOODS_RESULT.SOURCE_POS_INVALID.getMessage());
            return;
        }

        if (tgc.isInvalidPos(tpos)){
            logger.warn("移动物品，目标位置无效，pos: {}", tpos);
            hc.sendMessage(MOVE_GOODS_RESULT.TARGET_POS_INVALID.getMessage());
            return;
        }

        if (sgc.isLocked(spos)){
            logger.debug("移动物品，源位置已被锁定，pos: {}", spos);
            hc.sendMessage(MOVE_GOODS_RESULT.SOURCE_POS_LOCKED.getMessage());
            return;
        }

        if (tgc.isLocked(tpos)){
            logger.debug("移动物品，目标位置已被锁定，pos: {}", tpos);
            hc.sendMessage(MOVE_GOODS_RESULT.TARGET_POS_LOCKED.getMessage());
            return;
        }

        final Goods sgoods = sgc.get(spos);
        if (sgoods == null){
            logger.debug("移动物品，源位置没有物品，pos: {}", spos);
            hc.sendMessage(MOVE_GOODS_RESULT.SOURCE_POS_GOODS_NOT_FOUND
                    .getMessage());
            return;
        }

        final Goods tgoods = tgc.get(tpos);
        if (tgoods == null){
            // 位置交换
            sgc.set(spos, tgc.set(tpos, sgoods));
            hc.sendMessage(MOVE_GOODS_RESULT.SUCCESS.getMessage(type, spos,
                    tpos, 0));
            return;

        }

        if (sgoods.canFold(tgoods)){
            // 可以堆叠
            int foldCount = Math.min(sgoods.getCount(), tgoods.getData()
                    .getMaxCount() - tgoods.getCount());

            if (foldCount < sgoods.getCount()){
                sgoods.foldTo(tgoods, foldCount);
            } else{
                sgc.remove(spos);
                sgoods.foldTo(tgoods);
            }

            hc.sendMessage(MOVE_GOODS_RESULT.SUCCESS.getMessage(type, spos,
                    tpos, foldCount));
        } else{
            // 交换位置
            sgc.set(spos, tgc.set(tpos, sgoods));
            hc.sendMessage(MOVE_GOODS_RESULT.SUCCESS.getMessage(type, spos,
                    tpos, 0));
        }

        // 先让客户端完成移动物品的操作，然后再检测任务是否可以完成
        if (type != 2 && type != 3){
            // 2 背包 -> 仓库
            // 3 仓库 -> 背包
            Goods depotGoods = type == 2 ? sgoods : tgoods;
            if (depotGoods != null){
                taskCallbackModule.tryCompleteTaskOnGoodsAdded(
                        depotGoods.getData(), hc.getHero(), hc.getSender(),
                        hc.getHeroMiscModule());
            }

            return;
        }
    }

    private void processGoodsSplit(HeroController hc, ChannelBuffer buffer){
        int type = buffer.readUnsignedByte();
        int spos = BufferUtil.readVarInt32(buffer);
        int tpos = BufferUtil.readVarInt32(buffer);
        int splitCount = BufferUtil.readVarInt32(buffer);

        GoodsContainer goodsContainer = null;
        switch (type){
            case 0:{
                goodsContainer = hc.getDepot();
                break;
            }
            case 1:{
                Storage storage = hc.getStorage();
                if (storage == null){
                    logger.warn("拆分物品，仓库还没开放");
                    hc.sendMessage(SPLIT_GOODS_RESULT.STORAGE_NOT_OPEN
                            .getMessage());
                    return;
                }
                goodsContainer = storage;
                break;
            }
            default:{
                logger.warn("拆分物品，类型无效，type: {}", type);
                hc.sendMessage(SPLIT_GOODS_RESULT.TYPE_INVALID.getMessage());
                return;
            }
        }

        if (spos == tpos){
            logger.debug("拆分物品，源位置与目标位置一样, pos: {}", spos);
            hc.sendMessage(SPLIT_GOODS_RESULT.SOURCE_POS_EQUAL_TARGET_POS
                    .getMessage());
            return;
        }

        if (goodsContainer.isInvalidPos(spos)){
            logger.debug("拆分物品，源位置无效, pos: {}", spos);
            hc.sendMessage(SPLIT_GOODS_RESULT.SOURCE_POS_INVALID.getMessage());
            return;
        }

        if (goodsContainer.isLocked(spos)){
            logger.debug("拆分物品，源位置已锁定, pos: {}", spos);
            hc.sendMessage(SPLIT_GOODS_RESULT.SOURCE_POS_LOCKED.getMessage());
            return;
        }

        Goods goods = goodsContainer.get(spos);
        if (goods == null){
            logger.debug("拆分物品，源位置物品不存在, pos: {}", spos);
            hc.sendMessage(SPLIT_GOODS_RESULT.SOURCE_POS_GOODS_NOT_FOUND
                    .getMessage());
            return;
        }

        if (splitCount <= 0 || splitCount >= goods.getCount()){
            logger.debug("拆分物品，拆分数量无效, count: {}", splitCount);
            hc.sendMessage(SPLIT_GOODS_RESULT.SPLIT_COUNT_INVALID.getMessage());
            return;
        }

        if (goodsContainer.isInvalidPos(tpos)){
            logger.debug("拆分物品，目标位置无效, pos: {}", tpos);
            hc.sendMessage(SPLIT_GOODS_RESULT.TARGET_POS_INVALID.getMessage());
            return;
        }

        if (goodsContainer.get(tpos) != null){
            logger.debug("拆分物品，目标位置物品已存在, pos: {}", tpos);
            hc.sendMessage(SPLIT_GOODS_RESULT.TARGET_POS_GOODS_EXIST
                    .getMessage());
            return;
        }

        if (goodsContainer.hasReservedPos()
                && !goodsContainer.hasEnoughEmptyCount(1)){
            logger.debug("拆分物品, 空格子都被交易暂时征用了");
            hc.sendMessage(SPLIT_GOODS_RESULT.TARGET_POS_GOODS_EXIST
                    .getMessage());
            return;
        }

        goodsContainer.set(tpos, goods.split(splitCount));
        hc.sendMessage(SPLIT_GOODS_RESULT.SUCCESS.getMessage(type, spos, tpos,
                splitCount));
    }

    private void processClean(HeroController hc, ChannelBuffer buffer){

        int type = buffer.readUnsignedByte();

        GoodsContainer goodsContainer = null;
        switch (type){
            case 0:{
                // 背包
                Depot depot = hc.getDepot();

                if (hc.getTrade() != null){
                    logger.debug("背包物品整理，正在交易中");
                    hc.sendMessage(CLEAN_GOODS_RESULT.DEPOT_LOCKED.getMessage());
                    return;
                }
                goodsContainer = depot;
                break;
            }
            case 1:{
                // 仓库
                goodsContainer = hc.getStorage();
                if (goodsContainer == null){
                    logger.warn("仓库物品整理，仓库还未开放");
                    hc.sendMessage(CLEAN_GOODS_RESULT.STORAGE_NOT_OPEN
                            .getMessage());
                    return;
                }
                break;
            }
            default:{
                logger.warn("物品整理，类型无效，type: {}", type);
                hc.sendMessage(CLEAN_GOODS_RESULT.TYPE_INVALID.getMessage());
                return;
            }
        }

        long currentTime = timeService.getCurrentTime();
        if (goodsContainer.nextCanCleanTime > currentTime){
            logger.debug("物品整理，下次整理时间未到");
            hc.sendMessage(CLEAN_GOODS_RESULT.DEPOT_CLEAN_TIME_NOT_REACHED
                    .getMessage());
            return;
        }

        goodsContainer.nextCanCleanTime = currentTime
                + VariableConfig.CLEAN_GOODS_CONTAINER_INTERVAL;

        cleanGoodsContainer(hc, goodsContainer);
    }

    void cleanGoodsContainer(HeroController hc, GoodsContainer goodsContainer){
        try{
            goodsSorter.sort(goodsContainer);

            hc.sendMessage(CLEAN_GOODS_RESULT.SUCCESS.getMessage(
                    goodsContainer.getType(), goodsContainer.nextCanCleanTime,
                    goodsContainer));

        } catch (Throwable e){
            logger.error("背包仓库整理出错，严重错误", e);

            if (goodsSorter == GoodsSorter.FAST_SORTER){
                logger.error("开始切换到DEFAULT_SORTER");

                goodsSorter = GoodsSorter.DEFAULT_SORTER;

                logger.error("切换到DEFAULT_SORTER完成");
            }

            // 将英雄T下线
            hc.disconnect(INTERNAL_ERROR_SORT_ERROR);
        }
    }

    public void cleanGoodsArray(HeroController hc, Goods[] goodsArray){
        try{
            goodsSorter.sort(goodsArray, goodsArray.length);
        } catch (Throwable e){
            logger.error("背包仓库整理出错，严重错误", e);

            if (goodsSorter == GoodsSorter.FAST_SORTER){
                logger.error("开始切换到DEFAULT_SORTER");

                goodsSorter = GoodsSorter.DEFAULT_SORTER;

                logger.error("切换到DEFAULT_SORTER完成");
            }

            // 将英雄T下线
            hc.disconnect(INTERNAL_ERROR_SORT_ERROR);
        }
    }

    private void processGetStorageData(HeroController hc, ChannelBuffer buffer){
        Storage storage = hc.getStorage();
        if (storage == null){
            logger.warn("获取仓库数据，仓库还未开放");
            hc.sendMessage(STORAGE_NOT_OPEN);
            return;
        }

        if (!hc.storageProcessed){
            hc.storageProcessed = true;
            hc.sendMessage(getStorageDataMsg(hc.getStorage().encode4Client()
                    .toByteArray()));
        } else{
            logger.warn("收到客户端多次发送请求仓库数据");
        }
    }

    public void processOpenStorage(HeroController hc){

        if (hc.getHero().openStorage(timeService.getCurrentTime())){
            hc.sendMessage(OPEN_STORAGE_MESSAGE);
            return;
        }

        logger.warn("仓库已经开放，还收到开放仓库消息");
    }

    private void processUseGoods(HeroController hc, ChannelBuffer buffer){

        if (!hc.heroFightModule.isAlive()){
            logger.warn("挂了，不能使用物品");
            hc.sendMessage(ERR_USE_GOODS_YOU_ARE_DEAD);
            return;
        }

        int pos = BufferUtil.readVarInt32(buffer);
        int useCount = BufferUtil.readVarInt32(buffer);

        Depot depot = hc.getDepot();

        if (depot.isInvalidPos(pos)){
            logger.warn("使用物品，位置无效");
            hc.sendMessage(ERR_USE_GOODS_POS_INVALID);
            return;
        }

        if (depot.isLocked(pos)){
            logger.warn("使用物品，位置已被锁定，pos: {}", pos);
            hc.sendMessage(ERR_USE_GOODS_POS_LOCKED);
            return;
        }

        Goods goods = depot.get(pos);
        if (goods == null){
            logger.warn("使用物品，物品不存在");
            hc.sendMessage(ERR_USE_GOODS_NOT_FOUND);
            return;
        }

        Efficacy efficacy = goods.getData().getEfficacy();
        if (efficacy == null){
            logger.warn("物品-{} 不能使用", goods.getData().name);
            hc.sendMessage(ERR_USE_GOODS_CAN_NOT_TO_USE);
            return;
        }

        useCount = Math.max(1, useCount);

        if (useCount > 1 && !goods.bulkUseable()){
            logger.warn("物品不能批量使用，但是使用个数大于1");
            hc.sendMessage(ERR_USE_GOODS_CAN_NOT_BULK_USE);
            return;
        }

        if (useCount > goods.getCount()){
            logger.warn("物品个数不足，个数小于客户端发送的使用个数");
            hc.sendMessage(ERR_USE_GOODS_COUNT_NOT_ENOUGH);
            return;
        }

        GoodsOwnership ownership = hc.getHero().getGoodsOwnership();
        long identifier = goods.getGoodsIdentifier();
        ownership.checkGoodsEnough(identifier, useCount);

        if (goods.getData().getRequireLevel() > hc.hero.getLevel()){
            logger.warn("等级不够，不能使用物品-{}", goods.getData().name);
            hc.sendMessage(ERR_USE_GOODS_LEVEL_NOT_ENOUGH);
            return;
        }

        long ctime = timeService.getCurrentTime();
        if (goods.isExpired(ctime)){
            logger.warn("物品已过期，不能使用物品-{}", goods.getData().name);
            hc.sendMessage(ERR_USE_GOODS_EXPIRED);
            return;
        }

        if (goods.hasCooldown()){
            if (goods.getCd() > 0
                    && hc.hero.getGoodsCoolDown(goods.getId()) > ctime){
                logger.warn("物品冷却时间未到，不能使用-{}", goods.getData().name);
                hc.sendMessage(ERR_USE_GOODS_COOL_DOWN);
                return;
            }

            if (goods.getCdType() > 0
                    && hc.hero.getGoodsTypeCoolDown(goods.getCdType()) > ctime){
                logger.warn("物品公共冷却时间未到，不能使用-{}", goods.getData().name);
                hc.sendMessage(ERR_USE_GOODS_COOL_DOWN);
                return;
            }
        }

        String iEventId = logService.newTodoEventId();
        // TODO 日志

        int realUseCount = efficacy.useTo(hc.heroFightModule, useCount, ctime,
                iEventId);
        if (realUseCount <= 0){
            // 已经在里面把错误消息发出去了
            return;
        }

        if (goods.getCount() < realUseCount){
            logger.error(
                    "processUseGoods 物品个数小于使用扣除的个数, hero:{} identifier:{} use:{} count:{}",
                    hc.getID(), identifier, realUseCount, goods.getCount());
        }

        ownership.removeGoods(identifier, realUseCount, GOODS_USE, 0, ctime,
                goods.needLog());

        // 加物品CD
        if (goods.hasCooldown()){

            Hero hero = hc.getHero();
            if (goods.getCd() > 0){
                hero.putGoodsCoolDown(goods.getId(), ctime + goods.getCd());
                hc.sendMessage(goodsCooldownMsg(goods.getId(), goods.getCd()));
            }

            if (goods.getGcd() > 0){
                hero.putGoodsTypeCoolDown(goods.getCdType(),
                        ctime + goods.getGcd());
                hc.sendMessage(goodsTypeCooldownMsg(goods.getCdType(),
                        goods.getGcd()));
            }
        }

        // 扣物品
        int newCount;
        if (goods.getCount() > realUseCount){
            newCount = goods.reduceCount(realUseCount);
        } else{
            depot.remove(pos);
            goods.removed();
            newCount = 0;
        }

        // 发消息
        hc.sendMessage(useGoodsMsg(pos, newCount));
    }

    private void processDropGoods(HeroController hc, ChannelBuffer buffer){
        if (!hc.heroFightModule.isAlive()){
            logger.debug("挂了，不能扔物品");
            hc.sendMessage(ERR_DROP_GOODS_FAIL_YOU_ARE_DEAD);
            return;
        }

        if (hc.heroFightModule.isJumping()){
            logger.debug("跳跃中不能扔物品");
            hc.sendMessage(ERR_DROP_GOODS_FAIL_JUMPING);
            return;
        }

        int pos = BufferUtil.readVarInt32(buffer);

        Depot depot = hc.getDepot();

        if (depot.isInvalidPos(pos)){
            logger.warn("丢弃物品时，背包位置无效");
            hc.sendMessage(ERR_DROP_GOODS_FAIL_INVALID_POS);
            return;
        }

        if (depot.isLocked(pos)){
            logger.debug("丢弃物品，位置已被锁定，pos: {}", pos);
            hc.sendMessage(ERR_DROP_GOODS_FAIL_GOODS_LOCKED);
            return;
        }

        Goods g = depot.get(pos);

        if (g == null){
            logger.debug("丢弃物品时，背包位置上没有物品");
            hc.sendMessage(ERR_DROP_GOODS_FAIL_GOODS_NOT_FOUND);
            return;
        }

        int goodsId = BufferUtil.readVarInt32(buffer);

        if (g.getId() != goodsId){
            logger.debug("丢弃物品时，物品ID不对");
            hc.sendMessage(ERR_DROP_GOODS_FAIL_INVALID_GOODS_ID);
            return;
        }

        if (!g.getData().dropable){
            logger.debug("丢弃物品时，物品不能丢弃");
            hc.sendMessage(ERR_DROP_GOODS_FAIL_GOODS_CAN_NOT_DROP);
            return;
        }

        if (g.isBinded()){
            logger.debug("丢弃物品时，物品是绑定的");
            hc.sendMessage(ERR_DROP_GOODS_FAIL_GOODS_LOCKED);
            return;
        }

        // 检查安全区域
        if (hc.heroFightModule.isInSafeArea()){
            logger.debug("安全区域不能扔物品");
            hc.sendMessage(ERR_DROP_GOODS_FAIL_SAFE_AREA);
            return;
        }

        IScene p = hc.heroFightModule.getParent();
        if (p instanceof NormalScene
                && ((NormalScene) p).getSceneData().isClustered()){
            logger.debug("连服场景不能扔物品");
            hc.sendMessage(ERR_DROP_GOODS_FAIL_IN_CLUSTER);
            return;
        }

        if (p.isLocalClusterScene()){
            logger.debug("跨服区域不能扔物品");
            hc.sendMessage(ERR_DROP_GOODS_FAIL_IN_CLUSTER);
            return;
        }

        // 正在跳跃
        if (hc.heroFightModule.isJumping()){
            logger.debug("跳跃中不能扔物品");
            hc.sendMessage(ERR_DROP_GOODS_FAIL_JUMPING);
            return;
        }

        long ctime = timeService.getCurrentTime();
        if (g.isExpired(ctime)){
            logger.debug("丢弃物品时，物品已经过期");
            hc.sendMessage(ERR_DROP_GOODS_FAIL_EXPIRED);
            return;
        }

        GoodsOwnership ownership = hc.getHero().getGoodsOwnership();
        long identifier = g.getGoodsIdentifier();
        ownership.removeGoods(identifier, g.getCount(), SCENE_GOODS_DROP, 0,
                ctime, g.needLog());

        Goods dropGoods = depot.remove(pos);
        if (dropGoods != g){
            depot.set(pos, dropGoods); // 防御性
            ownership.addGoods(identifier, g.getCount(), SCENE_GOODS_DROP, 0,
                    ctime, g.needLog());

            logger.error("丢物品时, 真正remove的不是之前get的");
            hc.sendMessage(ERR_DROP_GOODS_FAIL_GOODS_NOT_FOUND);
            return;
        }

        hc.heroFightModule.dropGoods(dropGoods, ctime);

        // 发消息
        hc.sendMessage(DROP_GOODS_SUCCESS);
    }

    @SelfThreadOnly
    public void addBuyBackGoods(Hero hero, int pos, Goods toAdd,
            ISender sender, HeroMiscModule heroMiscModule, OperateType type){
        assert !hero.getDepot().isInvalidPos(pos)
                && hero.getDepot().get(pos) == null && toAdd != null;

        assert heroMiscModule.isHeroThread(Thread.currentThread()): "addBuyBackGoods不是英雄线程调用";
        long identifier = toAdd.getGoodsIdentifier();
        hero.getGoodsOwnership().addGoods(identifier, toAdd.getCount(), type,
                0, timeService.getCurrentTime(), toAdd.needLog());

        GoodsData data = toAdd.getData();
        Goods o = hero.getDepot().set(pos, toAdd);

        taskCallbackModule.tryCompleteTaskOnGoodsAdded(data, hero, sender,
                heroMiscModule);

        if (o != null){
            logger.error(
                    "addBuyBackGoods中发现背包位置上有物品, hero:{} identifier:{} count:{}",
                    hero.getID(), o.getGoodsIdentifier(), o.getCount());
        }
    }

    public void addBatchGoods(GoodsAddHelper toAdd, GoodsTryAddResult result,
            Hero hero, ISender sender, HeroMiscModule heroMiscModule,
            OperateType type, long misc, long ctime){
        assert heroMiscModule.isHeroThread(Thread.currentThread()): "addBatchGoods不是英雄线程";

        if (!result.isSuccess()){
            // 防御性
            logger.error("GoodsContainerModule.addBatchGoods时，发现helper.isSuccess()为false");
            return;
        }

        Depot depot = hero.getDepot();
        GoodsOwnership ownership = hero.getGoodsOwnership();
        long identifier = toAdd.getGoodsIdentifier();
        // 先一次性加上，如果后面发现不行再扣
        ownership.addGoods(identifier, toAdd.getCount(), type, misc, ctime,
                toAdd.needLog());

        LongArrayList foldPosCountList = result.getFoldPosCountList();

        if (!foldPosCountList.isEmpty()){
            // 堆叠到已有的堆上
            ChannelBuffer buffer = getSetGoodsCountBuffer(depot.getType(),
                    foldPosCountList.size());

            for (int i = 0; i < foldPosCountList.size(); i++){
                long foldPosCount = foldPosCountList.get(i);

                int foldCount = (int) (foldPosCount & 0xffff);
//                int toAddPos = (int) (foldPosCount >>> 16 & 0xffff);
                int goodsPos = (int) (foldPosCount >>> 32 & 0xffff);

                // 这些参数就不校验了，下面的这些方法都有assert

//                GoodsAddHelper toAdd = toAdds.get(toAddPos);
                Goods g = depot.get(goodsPos);

                if (g == null || !toAdd.canFold(g)){
                    logger.error("foldPosCount错误，获取到的物品不能堆叠");
                    continue; // 防御性
                }

                toAdd.foldTo(g, foldCount);

                BufferUtil.writeVarInt32(buffer, goodsPos);
                BufferUtil.writeVarInt32(buffer, g.getCount());
            }

            sender.sendMessage(buffer);
        }

        // 放入空位
        if (toAdd.getCount() > 0){

            ArrayDeque<Integer> emptyPosList = result.getEmptyPosList();
            int c = Math.min(emptyPosList.size(), toAdd.getNeedEmptyPosCount());
            for (int i = 0; i < c; i++){
                int emptyPos = emptyPosList.pollFirst();
                assert emptyPos >= 0 && emptyPos < depot.size(): "helper中的emptyPos无效";

                if (depot.get(emptyPos) != null){
                    logger.error("helper中的emptyPos上存在物品，什么情况");
                    continue;
                }

                Goods g = toAdd.create();
                depot.set(emptyPos, g);
                sender.sendMessage(addGoodsMsg(0, emptyPos, g));
            }
        }

        if (toAdd.getCount() < toAdd.getOriginalToAddCount()){
            // 检查是否有任务要完成
            taskCallbackModule.tryCompleteTaskOnGoodsAdded(toAdd.getData(),
                    hero, sender, heroMiscModule);
        }

        if (toAdd.getCount() > 0){
            logger.error("doAddBatchGoods helper中没有找到足够的空位置，什么情况");
            // 有物品没加进去，扣回来
            ownership.removeGoods(identifier, toAdd.getCount(), type, misc,
                    ctime, toAdd.needLog());

            // 没有全放进去
            int c = toAdd.getNeedEmptyPosCount();
            List<Goods> goodsArray = Lists.newArrayListWithCapacity(c);

            for (int i = 0; i < c; i++){
                goodsArray.add(toAdd.create());
            }

            mailModule.newMailOnDepotEmptyPosNotEnough(hero,
                    goodsArray.toArray(Goods.EMPTY_GOODS_ARRAY));

            assert toAdd.getCount() <= 0: "addBatchGoods本来就没有全放进去，还TM有错";
        }

        result.clear(); // 清理一次
    }

    public void addBatchGoodsList(List<GoodsAddHelper> toAdds,
            GoodsTryAddResult result, Hero hero, ISender sender,
            HeroMiscModule heroMiscModule, OperateType type, long misc,
            long ctime){
        assert heroMiscModule.isHeroThread(Thread.currentThread()): "addBatchGoodsList不是英雄线程";
        addBatchGoodsArray(toAdds.toArray(GoodsAddHelper.EMPTY_ARRAY), result,
                hero, sender, heroMiscModule, type, misc, ctime);
    }

    public void addBatchGoodsArray(GoodsAddHelper[] toAdds,
            GoodsTryAddResult result, Hero hero, ISender sender,
            HeroMiscModule heroMiscModule, OperateType type, long misc,
            long ctime){
        assert heroMiscModule.isHeroThread(Thread.currentThread()): "addBatchGoodsArray不是英雄线程";

        if (!result.isSuccess()){
            // 防御性
            logger.error("GoodsContainerModule.addBatchGoodsArray时，发现helper.isSuccess()为false");
            return;
        }

        Depot depot = hero.getDepot();
        GoodsOwnership ownership = hero.getGoodsOwnership();
        // 先一次性加上，如果后面发现不行再扣
        for (GoodsAddHelper g : toAdds){
            ownership.addGoods(g.getGoodsIdentifier(), g.getCount(), type,
                    misc, ctime, g.needLog());
        }

        LongArrayList foldPosCountList = result.getFoldPosCountList();

        if (!foldPosCountList.isEmpty()){
            // 堆叠到已有的堆上
            ChannelBuffer buffer = getSetGoodsCountBuffer(depot.getType(),
                    foldPosCountList.size());

            for (int i = 0; i < foldPosCountList.size(); i++){
                long foldPosCount = foldPosCountList.get(i);

                int foldCount = (int) (foldPosCount & 0xffff);
                int toAddPos = (int) (foldPosCount >>> 16 & 0xffff);
                int goodsPos = (int) (foldPosCount >>> 32 & 0xffff);

                // 这些参数就不校验了，下面的这些方法都有assert

                GoodsAddHelper toAdd = toAdds[toAddPos];
                Goods g = depot.get(goodsPos);

                if (toAdd == null || g == null || !toAdd.canFold(g)){
                    logger.error("foldPosCount错误，获取到的物品不能堆叠");
                    continue; // 防御性
                }

                toAdd.foldTo(g, foldCount);

                BufferUtil.writeVarInt32(buffer, goodsPos);
                BufferUtil.writeVarInt32(buffer, g.getCount());
            }

            sender.sendMessage(buffer);
        }

        ArrayDeque<Integer> emptyPosList = result.getEmptyPosList();
        for (GoodsAddHelper toAdd : toAdds){
            if (toAdd.getCount() <= 0){
                // 检查是否有任务要完成
                taskCallbackModule.tryCompleteTaskOnGoodsAdded(toAdd.getData(),
                        hero, sender, heroMiscModule);
                continue;
            }

            int c = Math.min(emptyPosList.size(), toAdd.getNeedEmptyPosCount());
            for (int i = 0; i < c; i++){
                int emptyPos = emptyPosList.pollFirst();
                assert emptyPos >= 0 && emptyPos < depot.size(): "helper中的emptyPos无效";

                if (depot.get(emptyPos) != null){
                    logger.error("helper中的emptyPos上存在物品，什么情况");
                    continue;
                }

                Goods g = toAdd.create();
                depot.set(emptyPos, g);
                sender.sendMessage(addGoodsMsg(0, emptyPos, g));
            }

            if (toAdd.getCount() < toAdd.getOriginalToAddCount()){
                // 检查是否有任务要完成
                taskCallbackModule.tryCompleteTaskOnGoodsAdded(toAdd.getData(),
                        hero, sender, heroMiscModule);
            }

            if (toAdd.getCount() > 0){
                logger.error("doAddBatchGoods helper中没有找到足够的空位置，什么情况");
                // 有物品没加进去，扣回来
                ownership.removeGoods(toAdd.getGoodsIdentifier(),
                        toAdd.getCount(), type, misc, ctime, toAdd.needLog());

                // 没有全放进去
                c = toAdd.getNeedEmptyPosCount();
                List<Goods> goodsArray = Lists.newArrayListWithCapacity(c);

                for (int i = 0; i < c; i++){
                    goodsArray.add(toAdd.create());
                }

                mailModule.newMailOnDepotEmptyPosNotEnough(hero,
                        goodsArray.toArray(Goods.EMPTY_GOODS_ARRAY));

                assert toAdd.getCount() <= 0: "addBatchGoods本来就没有全放进去，还TM有错";
            }
        }

        result.clear(); // 清理一次
    }

    /**
     * 找空位放入物品
     * @param hero
     * @param toAdd
     * @param sender
     * @param heroMiscModule
     */
    public void addGoodsListToEmptyPos(Hero hero, List<Goods> toAdds,
            ISender sender, HeroMiscModule heroMiscModule, OperateType type,
            long misc, long ctime){
        assert heroMiscModule.isHeroThread(Thread.currentThread()): "addGoodsListToEmptyPos不是英雄线程";
        addGoodsArrayToEmptyPos(hero, toAdds.toArray(Goods.EMPTY_GOODS_ARRAY),
                sender, heroMiscModule, type, misc, ctime);
    }

    /**
     * 找空位放入物品
     * @param hero
     * @param toAdd
     * @param sender
     * @param heroMiscModule
     */
    public void addGoodsArrayToEmptyPos(Hero hero, Goods[] toAdds,
            ISender sender, HeroMiscModule heroMiscModule, OperateType type,
            long misc, long ctime){
        assert heroMiscModule.isHeroThread(Thread.currentThread()): "addGoodsArrayToEmptyPos不是英雄线程";
        if (toAdds.length <= 0){
            // 防御性
            return;
        }

        Depot depot = hero.getDepot();
        GoodsOwnership ownership = hero.getGoodsOwnership();
        // 先一次性加上，如果后面发现不行再扣
        for (Goods g : toAdds){
            ownership.addGoods(g.getGoodsIdentifier(), g.getCount(), type,
                    misc, ctime, g.needLog());
        }

        IntArrayList emptyPosList = depot.getEmptyPos(toAdds.length);
        int posCount = emptyPosList.size();

        for (int i = 0; i < posCount; i++){
            int pos = emptyPosList.get(i);
            Goods g = toAdds[i];

            Goods o = depot.set(pos, g);
            sender.sendMessage(addGoodsMsg(0, pos, g));

            assert o == null: "addGoodsToEmptyPos时找到的空位置上面有物品";
        }

        if (emptyPosList.size() < toAdds.length){
            logger.error("addGoodsToEmptyPos时没有找到足够的空位");

            Goods[] goodsArray = new Goods[toAdds.length - posCount];
            for (int i = 0; i < goodsArray.length; i++){
                Goods g = toAdds[posCount + i];
                ownership.removeGoods(g.getGoodsIdentifier(), g.getCount(),
                        type, misc, ctime, g.needLog());

                goodsArray[i] = g;
            }

            mailModule.newMailOnDepotEmptyPosNotEnough(hero, goodsArray);
        }

        // 一定要先将所有物品放进去，在检测任务是否完成，因为任务完成可能会添加新的物品进来
        for (int i = 0; i < posCount; i++){
            Goods g = toAdds[i];
            taskCallbackModule.tryCompleteTaskOnGoodsAdded(g.getData(), hero,
                    sender, heroMiscModule);
        }
    }

    public void addGoods(Hero hero, Goods toAdd, ISender sender,
            HeroMiscModule heroMiscModule, OperateType type, long misc,
            long ctime){
        assert heroMiscModule.isHeroThread(Thread.currentThread()): "addGoods不是英雄线程";
        if (toAdd == null){
            // 防御性
            return;
        }
        GoodsData data = toAdd.getData();

        doAddGoods(hero, toAdd, sender, type, misc, ctime);
        taskCallbackModule.tryCompleteTaskOnGoodsAdded(data, hero, sender,
                heroMiscModule);
    }

    /**
     * 添加物品，堆叠到已有的物品上面，此方法中会改变toAdd.count
     * @return
     */
    private void doAddGoods(Hero hero, Goods toAdd, ISender sender,
            OperateType type, long misc, long ctime){
        Depot depot = hero.getDepot();
        GoodsOwnership ownership = hero.getGoodsOwnership();
        // 先一次性加上，如果后面发现不行再扣
        long identifier = toAdd.getGoodsIdentifier();
        ownership.addGoods(identifier, toAdd.getCount(), type, misc, ctime,
                toAdd.needLog());

        // 别搞这么复杂，先确认有空格，保证就是不能堆叠也能放进去
        int maxCount = toAdd.getData().getMaxCount();
        assert depot.hasEnoughEmptyCount(Utils.divide(toAdd.getCount(),
                maxCount));

        if (toAdd.isFoldable()){
            // 从头开始依次找相同的物品，堆叠上去
            int size = depot.size();
            for (int i = 0; i < size; i++){
                if (depot.isLocked(i)){
                    continue;
                }

                Goods g = depot.get(i);
                if (g != null && toAdd.canFold(g)){
                    if (g.getCount() + toAdd.getCount() > maxCount){
                        int moveCount = maxCount - g.getCount();
                        toAdd.foldTo(g, moveCount);
                        sender.sendMessage(setGoodsCountMsg(0, i, g.getCount()));
                    } else{
                        // 全部堆叠进去
                        toAdd.foldTo(g);
                        sender.sendMessage(setGoodsCountMsg(0, i, g.getCount()));
                        return;
                    }
                }
            }
        }

        assert toAdd.getCount() > 0;

        // 还有没有堆叠的，加入到空位置上
        int emptyCount = Utils.divide(toAdd.getCount(), maxCount);
        IntArrayList emptyPosList = depot.getEmptyPos(emptyCount);
        assert emptyPosList.size() <= emptyCount;

        for (int i = 0; i < emptyPosList.size(); i++){
            int pos = emptyPosList.get(i);

            Goods g = toAdd.getCount() > maxCount ? toAdd.split(maxCount)
                    : toAdd;

            Goods o = depot.set(pos, g);
            sender.sendMessage(addGoodsMsg(0, pos, g));

            assert o == null: "doAddGoods时找到的空位置上面有物品";

            if (g == toAdd){
                return; // 全部放完了
            }
        }

        logger.error("addGoods有Bug，东西没放进去");
        // 将物品扣回来
        ownership.removeGoods(identifier, toAdd.getCount(), type, misc, ctime,
                toAdd.needLog());

        // 发邮件
        if (toAdd.getCount() <= maxCount){
            mailModule.newMailOnDepotEmptyPosNotEnough(hero, toAdd);
        } else{
            int goodsCount = Utils.divide(toAdd.getCount(), maxCount);
            Goods[] goodsArray = new Goods[goodsCount];

            int loopCount = goodsCount - 1;
            for (int i = 0; i < loopCount; i++){
                goodsArray[i] = toAdd.split(maxCount);
            }
            goodsArray[loopCount] = toAdd;

            mailModule.newMailOnDepotEmptyPosNotEnough(hero, goodsArray);
        }
    }

    public IntArrayList addGoods(Hero hero, GoodsAddHelper toAdd,
            ISender sender, HeroMiscModule heroMiscModule, OperateType type,
            long misc, long ctime){
        assert heroMiscModule.isHeroThread(Thread.currentThread()): "addGoods不是英雄线程";
        GoodsData data = toAdd.getData();

        IntArrayList result = doAddGoods(hero, toAdd, sender, type, misc, ctime);
        taskCallbackModule.tryCompleteTaskOnGoodsAdded(data, hero, sender,
                heroMiscModule);

        return result;
    }

    /**
     * 添加商店购买的物品，优先堆叠到已有的堆上，剩下的放到空位上，返回放入空位的位置
     * @param hero
     * @param toAdd
     * @param sender
     * @return
     */
    private IntArrayList doAddGoods(Hero hero, GoodsAddHelper toAdd,
            ISender sender, OperateType type, long misc, long ctime){

        Depot depot = hero.getDepot();
        GoodsOwnership ownership = hero.getGoodsOwnership();
        // 先一次性加上，如果后面发现不行再扣
        long identifier = toAdd.getGoodsIdentifier();
        ownership.addGoods(identifier, toAdd.getCount(), type, misc, ctime,
                toAdd.needLog());

        // 别搞这么复杂，先确认有空格，保证就是不能堆叠也能放进去
        assert depot.hasEnoughEmptyCount(toAdd.getNeedEmptyPosCount());

        if (toAdd.isFoldable()){
            // 从头开始依次找相同的物品，堆叠上去
            int size = depot.size();

            for (int i = 0; i < size; i++){
                if (depot.isLocked(i)){
                    continue;
                }

                Goods g = depot.get(i);
                if (g != null && toAdd.canFold(g)){

                    int foldCount = toAdd.getCount();
                    if (g.getCount() + foldCount > g.getMaxCount()){
                        foldCount = g.getMaxCount() - g.getCount();
                    }

                    toAdd.foldTo(g, foldCount);

                    sender.sendMessage(setGoodsCountMsg(0, i, g.getCount()));

                    if (toAdd.getCount() <= 0){
                        return null;
                    }
                }
            }
        }

        assert toAdd.getCount() > 0;

        // 还有没有堆叠的，加入到空位置上
        int emptyCount = toAdd.getNeedEmptyPosCount();
        IntArrayList emptyPosList = depot.getEmptyPos(emptyCount);
        assert emptyPosList.size() <= emptyCount;

        for (int i = 0; i < emptyPosList.size(); i++){
            int pos = emptyPosList.get(i);

            Goods g = toAdd.create();
            Goods o = depot.set(pos, g);
            sender.sendMessage(addGoodsMsg(0, pos, g));

            assert o == null: "doAddGoods时找到的空位置上面有物品";
        }

        // 检查是否全放进去了
        if (toAdd.getCount() > 0){
            logger.error("doAddGoods有Bug，东西没放进去");
            // 将物品扣回来
            ownership.removeGoods(identifier, toAdd.getCount(), type, misc,
                    ctime, toAdd.needLog());

            // 发邮件
            int goodsCount = toAdd.getNeedEmptyPosCount();
            Goods[] goodsArray = new Goods[goodsCount];

            for (int i = 0; i < goodsCount; i++){
                goodsArray[i] = toAdd.create();
            }

            assert toAdd.getCount() <= 0: "doAddGoods，物品创建完后，个数还大于0";

            mailModule.newMailOnDepotEmptyPosNotEnough(hero, goodsArray);
        }

        return emptyPosList;
    }

    public ReduceCooldownGoodsResult tryReduceCooldownGoods(Hero hero,
            int suggestedPos, GoodsData goodsData, ISender sender,
            OperateType type, long misc, long ctime){

        int goodsId = goodsData.id;

        // 检查CD
        if (goodsData.hasCooldown()){

            if (goodsData.getCd() > 0
                    && hero.getGoodsCoolDown(goodsData.id) > ctime){
                logger.debug("物品冷却时间未到，不能使用-{}", goodsData.name);
                return ReduceCooldownGoodsResult.COOL_DOWN;
            }

            if (goodsData.getCdType() > 0
                    && hero.getGoodsTypeCoolDown(goodsData.getCdType()) > ctime){
                logger.debug("物品公共冷却时间未到，不能使用-{}", goodsData.name);
                return ReduceCooldownGoodsResult.COOL_DOWN;
            }
        }

        Depot depot = hero.getDepot();

        Goods target = null;
        int pos = suggestedPos;
        if (!depot.isInvalidPos(pos) && !depot.isLocked(pos)){
            Goods g = depot.get(pos);
            if (g != null && g.getId() == goodsId && !g.isExpired(ctime)){
                target = g;
            }
        }

        if (target == null){
            // 遍历背包，找到足够的物品扣除
            int size = depot.size();
            for (int i = 0; i < size; i++){
                if (depot.isLocked(i)){
                    continue;
                }

                Goods g = depot.get(i);
                if (g != null && g.getId() == goodsId && !g.isExpired(ctime)){
                    target = g;
                    pos = i;
                    break;
                }
            }

            if (target == null){
                return ReduceCooldownGoodsResult.GOODS_NOT_FOUND;
            }
        }

        assert target != null;

        if (goodsData.hasCooldown()){
            if (goodsData.getCd() > 0){
                hero.putGoodsCoolDown(goodsData.getId(),
                        ctime + goodsData.getCd());
                sender.sendMessage(goodsCooldownMsg(goodsData.getId(),
                        goodsData.getCd()));
            }

            if (goodsData.getGcd() > 0){
                hero.putGoodsTypeCoolDown(goodsData.getId(),
                        ctime + goodsData.getGcd());
                sender.sendMessage(goodsTypeCooldownMsg(goodsData.getCdType(),
                        goodsData.getGcd()));
            }
        }

        hero.getGoodsOwnership().removeGoods(target.getGoodsIdentifier(), 1,
                type, misc, ctime, target.needLog());

        if (target.getCount() > 1){
            int newCount = target.reduceCount(1);
            sender.sendMessage(setGoodsCountMsg(0, pos, newCount));
        } else{
            Goods g = depot.remove(pos);
            if (g != null){
                g.removed();
            }
            sender.sendMessage(removeGoodsMsg(0, pos));
        }

        return ReduceCooldownGoodsResult.SUCCESS;
    }

    public boolean tryReduceGoods(Hero hero, int count, GoodsData data,
            ISender sender, OperateType type, long misc){
        return tryReduceGoods(hero, -1, count, data, sender, type, misc);
    }

    /**
     * 尝试在pos位置扣除count个物品（goodsId），如果失败则遍历背包格子，
     * 尝试扣除物品，失败返回false，成功返回true
     * @param pos
     * @param count
     * @param goodsId
     * @return
     */
    public boolean tryReduceGoods(Hero hero, int pos, int count,
            GoodsData data, ISender sender, OperateType type, long misc){
        return tryReduceGoods(hero, pos, count, data, sender,
                timeService.getCurrentTime(), type, misc);
    }

    private static final ThreadLocal<IntArrayList> localReducePosCountList = new ThreadLocal<IntArrayList>(){
        @Override
        protected IntArrayList initialValue(){
            return new IntArrayList();
        }
    };

    public boolean tryReduceGoods(Hero hero, int pos, int count,
            GoodsData data, ISender sender, long ctime, OperateType type,
            long misc){
        if (count <= 0){
            return true;
        }

        Depot depot = hero.getDepot();

        IntArrayList posCountList = localReducePosCountList.get();
        posCountList.clear();

        int reducedCount = 0;
        if (!depot.isInvalidPos(pos) && !depot.isLocked(pos)){
            Goods g = depot.get(pos);
            if (g != null && g.getData() == data && !g.isExpired(ctime)){
                reducedCount = Math.min(count, g.getCount());

                posCountList.add(pos);
                posCountList.add(count);
            }
        }

        if (reducedCount >= count){
            // 真正扣物品
            reduceGoodsListAnyway(posCountList, hero, sender, type, misc, ctime);
            return true;
        }

        // 遍历背包，找到足够的物品扣除
        int size = depot.size();
        for (int i = 0; i < size; i++){
            if (i == pos || depot.isLocked(i)){
                continue;
            }

            Goods g = depot.get(i);
            if (g != null && g.getData() == data && !g.isExpired(ctime)){

                int c = Math.min((count - reducedCount), g.getCount());
                posCountList.add(i);
                posCountList.add(c);

                reducedCount += c;
                if (reducedCount >= count){
                    break;
                }
            }
        }

        if (reducedCount < count){
            // 没找到足够的数量
            return false;
        }

        // 真正扣物品
        reduceGoodsListAnyway(posCountList, hero, sender, type, misc, ctime);
        return true;
    }

    /**
     * 根据位置，扣除数量列表，扣除背包物品
     * @param posCountList pos1, count1, pos2, count2, ...
     * @param hero
     * @param sender
     * @return
     */
    public void reduceGoodsListAnyway(IntArrayList posCountList, Hero hero,
            ISender sender, OperateType type, long misc, long ctime){
        if (posCountList.isEmpty()){
            return;
        }

        Depot depot = hero.getDepot();
        GoodsOwnership ownership = hero.getGoodsOwnership();
        // 先一次性扣掉，有问题再加上
        int loopCount = posCountList.size() / 2;
        for (int i = 0; i < loopCount; i++){
            int pos = posCountList.get(i * 2);
            int count = posCountList.get(i * 2 + 1);

            Goods g = depot.get(pos);
            if (g == null){
                logger.error("reduceGoodsListAnyway从背包获取的Goods == null");
                continue;
            }

            if (g.getCount() < count){
                logger.error("reduceGoodsListAnyway从背包中获取的物品个数小于要扣的个数");
            }

            try{
                ownership.removeGoods(g.getGoodsIdentifier(), count, type,
                        misc, ctime, g.needLog());
            } catch (IllegalGoodsCountException e){

                // 我去，将之前扣掉的再加回去
                for (int n = 0; n < i; n++){
                    pos = posCountList.get(n * 2);
                    count = posCountList.get(n * 2 + 1);
                    g = depot.get(pos);
                    if (g == null){
                        continue;
                    }

                    ownership.addGoods(g.getGoodsIdentifier(), count, type,
                            misc, ctime, g.needLog());
                }

                throw e;
            }
        }

        boolean reduced = false;
        ChannelBuffer buffer = getSetGoodsCountBuffer(depot.getType(),
                loopCount);

        for (int i = 0; i < loopCount; i++){
            int pos = posCountList.get(i * 2);
            int count = posCountList.get(i * 2 + 1);

            Goods g = depot.get(pos);
            if (g == null){
                continue;
            }

            reduced = true;
            if (g.getCount() <= count){
                depot.remove(pos);
                BufferUtil.writeVarInt32(buffer, pos);
                BufferUtil.writeVarInt32(buffer, 0);
            } else{
                int newCount = g.reduceCount(count);
                BufferUtil.writeVarInt32(buffer, pos);
                BufferUtil.writeVarInt32(buffer, newCount);
            }
        }

        if (reduced){
            sender.sendMessage(buffer);
        }
    }

    private void processGetYuanbaoPackageShowGoods(HeroController hc,
            ChannelBuffer buffer){

        int goodsId = BufferUtil.readVarInt32(buffer);

        YuanbaoPackageData data = hc.getServices().getConfigService()
                .getGoods().getYuanbaoPackage(goodsId);

        if (data == null){
            logger.warn("获取元宝礼包物品，无效的id");
            return;
        }

        hc.sendMessage(data.getShowGoodsMsg(hc.getHero().getRaceId()));
    }
}
