package app.game.module.guild;

import java.util.Iterator;

import org.jboss.netty.buffer.ChannelBuffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.entity.Hero;
import app.game.entity.Model;
import app.game.module.HeroID;
import app.game.service.TimeService;
import app.message.IDroppableSender;
import app.message.ISender;
import app.protobuf.GuildContent.GuildMemberProto;
import app.utils.VariableConfig;

import com.google.protobuf.ByteString;
import com.mokylin.sink.util.Empty;
import com.mokylin.sink.util.annotation.MultiThread;
import com.mokylin.sink.util.annotation.SelfThreadOnly;
import com.mokylin.sink.util.concurrent.PaddedAtomicReference;

public class GuildMember implements IGuildMember{

    private static final Logger logger = LoggerFactory
            .getLogger(GuildMember.class);

    final HeroID heroID;

    public final long id;

    public final byte[] heroNameBytes;

    final ByteString heroNameByteString;

    private final PaddedAtomicReference<Guild> guild;

    // ----- 帮派模块改变 -----
    /**
     * 入帮时间
     */
    private long enterGuildTime;

    /**
     * 帮贡
     */
    private int contributionPoint;

    /**
     * 昵称
     */
    private ByteString nickName;

    /**
     * 分组头衔
     */
    private ByteString groupName;

    // ----- 历史帮贡 -----

    private int historyGiftGoods1;
    private int historyGiftGoods2;
    private int historyGiftGoods3;
    private int historyGiftGoods4;
    private long historyGiftMoney;

    // ----- 个人资料, 英雄线程自己改变 -----

    /**
     * 职业
     */
    final int race;

    /**
     * 等级
     */
    private int level;

    /**
     * 战斗力
     */
    private int fightAmount;

    /**
     * 换装
     */
    Model model;

    /**
     * 当前是否在在线
     */
    private boolean isOnline;

    /**
     * 上次在线时间
     */
    private long lastOfflineTime;

    /**
     * 坐骑等级
     */
    private int mountLevel;

    /**
     * 凤舞等级
     */
    private int fengWuLevel;

    private int tianjieLevel;

    private int tianzuiLevel;

    /**
     * 所在场景
     */
    private int actualSceneID;
    private int sceneUUID;

    private boolean isAutoAcceptGuildInvite;

    /**
     * 是否 禁止别人邀请我加人帮派
     * 在线的时候才要使用这个字段;如果不在线，不需要判断这个字段，直接就禁止别人邀请我加人帮派
     */
    private boolean isForbidOtherInviteMeJoinGuild;

    private IDroppableSender sender;

    // 挑战侠士援助次数
    private int challengeAssistTimes;

    // 挑战侠士已通关序号
    private int challengeSequence;

    public GuildMember(HeroID heroID, Hero hero, IDroppableSender sender){
        this.guild = new PaddedAtomicReference<Guild>(null);
        this.heroID = heroID;
        this.id = hero.getID();
        this.heroNameBytes = hero.getNameBytes();
        this.heroNameByteString = hero.getNameByteString();
        this.sender = sender;

        this.race = hero.getRaceId();
        this.level = hero.getLevel();
        this.fightAmount = hero.getFightingAmount();
        this.model = hero.getModel();
        this.lastOfflineTime = hero.getLastLogoutTime();
        this.actualSceneID = hero.getFightData().getActualSceneID();

        this.isAutoAcceptGuildInvite = hero.isGuildAutoAcceptInvite();
        this.isForbidOtherInviteMeJoinGuild = hero
                .isForbidOtherInviteMeJoinGuild();

        // 坐骑
        this.mountLevel = hero.getBestMountId();

        // 凤舞
        this.fengWuLevel = hero.getBowId();

        this.tianjieLevel = hero.getTianJieId();
        this.tianzuiLevel = hero.getTianZuiId();

        this.challengeAssistTimes = hero.getChallengeDungeonAssistTimes();
        this.challengeSequence = hero.getFinishedChallengeDungeonSequence();
    }

    private GuildMember(GuildMemberProto proto, TimeService timeService){
        this.guild = new PaddedAtomicReference<Guild>(null);
        this.id = proto.getId();
        this.heroID = new HeroID(this.id);
        this.heroNameBytes = proto.getName().toByteArray();
        this.heroNameByteString = proto.getName();

        this.enterGuildTime = proto.getEnterGuildTime();
        this.contributionPoint = proto.getContributionPoint();
        this.race = proto.getRace();
        this.level = proto.getLevel();
        this.fightAmount = proto.getFightAmount();
        this.model = new Model(timeService);
        model.setOriginalResourceWithBestMountBow(proto.getEquipmentResource());
        this.lastOfflineTime = proto.getLastOfflineTime();

        this.mountLevel = proto.getMountLevel();
        this.fengWuLevel = proto.getFengWuLevel();
        this.tianjieLevel = proto.getTianjie();
        this.tianzuiLevel = proto.getTianzui();

        if (proto.hasNickName()){
            this.nickName = proto.getNickName();
        }

        if (proto.hasGroupName()){
            this.groupName = proto.getGroupName();
        }

        this.historyGiftGoods1 = proto.getHistoryGiftGoods1();
        this.historyGiftGoods2 = proto.getHistoryGiftGoods2();
        this.historyGiftGoods3 = proto.getHistoryGiftGoods3();
        this.historyGiftGoods4 = proto.getHistoryGiftGoods4();
        this.historyGiftMoney = proto.getHistoryGiftMoney();

        this.challengeAssistTimes = proto.getChallengeAssistTimes();
        this.challengeSequence = proto.getChallengeSequence();
    }

    public long getId(){
        return id;
    }

    public int getResource(){
        return model.getResourceWithBestMountBow();
    }

    public Model getModel(){
        return model;
    }

    public int getActualSceneID(){
        return actualSceneID;
    }

    // ---- 帮派package使用 ----
    boolean hasGuild(){
        Guild g = getGuild();
        if (g == null){
            return false;
        }

        if (g == Guild.OFFLINE_GUILD){
            return false;
        }

        return true;
    }

    int getLevel(){
        return level;
    }

    public long getEnterGuildTime(){
        return enterGuildTime;
    }

    boolean isAutoAcceptInvite(){
        return isAutoAcceptGuildInvite;
    }

    void setAutoAcceptInvite(boolean v){
        this.isAutoAcceptGuildInvite = v;
    }

    public boolean isForbidOtherInviteMeJoinGuild(){
        return isForbidOtherInviteMeJoinGuild;
    }

    public void setForbidOtherInviteMeJoinGuild(
            boolean isForbidOtherInviteMeJoinGuild){
        this.isForbidOtherInviteMeJoinGuild = isForbidOtherInviteMeJoinGuild;
    }

    void setEnterGuildTime(long ctime){
        this.enterGuildTime = ctime;
        contributionPoint = 0;
        historyGiftGoods1 = 0;
        historyGiftGoods2 = 0;
        historyGiftGoods3 = 0;
        historyGiftGoods4 = 0;
        historyGiftMoney = 0;

        setNickname(null);
        setGroupname(null);
    }

    void setNickname(byte[] newNickname){
        if (newNickname == null || newNickname.length == 0){
            this.nickName = null;
        } else{
            this.nickName = ByteString.copyFrom(newNickname);
        }
    }

    void setGroupname(byte[] newGroupname){
        if (newGroupname == null || newGroupname.length == 0){
            this.groupName = null;
        } else{
            this.groupName = ByteString.copyFrom(newGroupname);
        }
    }

    public boolean isOnline(){
        return isOnline;
    }

    int getFightAmount(){
        return fightAmount;
    }

    void sendDroppableMessage(ChannelBuffer buffer){
        IDroppableSender s = sender;
        if (s != null){
            s.sendDroppableMessage(buffer);
        }
    }

    void sendMessage(ChannelBuffer buffer){
        ISender s = sender;
        if (s != null){
            s.sendMessage(buffer);
        }
    }

    void setModel(Model model){
        this.model = model;
    }

    void setSender(IDroppableSender sender){
        this.sender = sender;
    }

    /**
     * called under lock
     * @param amount
     * @return
     */
    public int addContribution(int amount){
        assert amount > 0;

        if ((contributionPoint += amount) < 0
                || contributionPoint > VariableConfig.GUILD_CONTRIBUTION_UPPER_LIMIT){
            // overflow
            contributionPoint = VariableConfig.GUILD_CONTRIBUTION_UPPER_LIMIT;
        }

        return contributionPoint;
    }

    @SelfThreadOnly
    public int reduceContribution(int amount){
        assert amount > 0;

        return contributionPoint = Math.max(contributionPoint - amount, 0);
    }

    void addHistoryGiftGoods1(int count){
        assert count > 0;

        if ((historyGiftGoods1 += count) < 0
                || historyGiftGoods1 > VariableConfig.GUILD_HISTORY_GIVE_LIMIT){
            historyGiftGoods1 = VariableConfig.GUILD_HISTORY_GIVE_LIMIT;
        }
    }

    void addHistoryGiftGoods2(int count){
        assert count > 0;

        if ((historyGiftGoods2 += count) < 0
                || historyGiftGoods2 > VariableConfig.GUILD_HISTORY_GIVE_LIMIT){
            historyGiftGoods2 = VariableConfig.GUILD_HISTORY_GIVE_LIMIT;
        }
    }

    void addHistoryGiftGoods3(int count){
        assert count > 0;

        if ((historyGiftGoods3 += count) < 0
                || historyGiftGoods3 > VariableConfig.GUILD_HISTORY_GIVE_LIMIT){
            historyGiftGoods3 = VariableConfig.GUILD_HISTORY_GIVE_LIMIT;
        }
    }

    void addHistoryGiftGoods4(int count){
        assert count > 0;

        if ((historyGiftGoods4 += count) < 0
                || historyGiftGoods4 > VariableConfig.GUILD_HISTORY_GIVE_LIMIT){
            historyGiftGoods4 = VariableConfig.GUILD_HISTORY_GIVE_LIMIT;
        }
    }

    void addHistoryGiftMoney(int count){
        assert count > 0;

        if ((historyGiftMoney += count) < 0
                || historyGiftMoney > VariableConfig.GUILD_HISTORY_GIVE_LIMIT){
            historyGiftMoney = VariableConfig.GUILD_HISTORY_GIVE_LIMIT;
        }
    }

    public boolean leaveGuild(Guild oldGuild){
        enterGuildTime = 0;
        contributionPoint = 0;
        historyGiftGoods1 = 0;
        historyGiftGoods2 = 0;
        historyGiftGoods3 = 0;
        historyGiftGoods4 = 0;
        historyGiftMoney = 0;

        setNickname(null);
        setGroupname(null);
        if (setGuildWhenSame(oldGuild, null)){
            return true;
        } else{
            logger.error("GuildMember.leaveGuild时, 英雄的guild并不是传进来的帮派");
            return false;
        }
    }

    // ---- public ----
    public int getContribution(){
        return contributionPoint;
    }

    public boolean setGuildWhenNull(Guild g){
        return guild.compareAndSet(null, g);
    }

    public boolean setGuildWhenSame(Guild oldGuild, Guild newGuild){
        return guild.compareAndSet(oldGuild, newGuild);
    }

    @Override
    public byte[] getGuildName(){
        Guild g = guild.get();
        if (g != null){
            return g.name;
        }

        return Empty.BYTE_ARRAY;
    }

    @Override
    public Guild getGuild(){
        return guild.get();
    }

    public void setOnline(int actualSceneID, boolean isAutoAccept,
            boolean isForbidOtherInviteMeJoinGuild){
        this.isAutoAcceptGuildInvite = isAutoAccept;
        this.isForbidOtherInviteMeJoinGuild = isForbidOtherInviteMeJoinGuild;
        this.actualSceneID = actualSceneID;
        isOnline = true;

        Guild g = guild.get();
        if (g != null){
            g.addActiveDegree(id); // 加帮派活跃度

            int dismissLevel = g.getDismissLevel();
            if (dismissLevel >= VariableConfig.GUILD_DISMISS_WARNING_DAYS){
                sendMessage(GuildMessages
                        .lowActivityWarning(VariableConfig.GUILD_DISMISS_LEVEL_LIMIT
                                - dismissLevel));
            }

            if (g.getLeader() == this){
                // 我是帮主, 上线了
                // 看下有没有别人加我为敌对帮派的
                Guild targetGuild;
                for (Iterator<Guild> ite = g.getBeenAddedEnemyHaveNotNotified()
                        .iterator(); ite.hasNext();){
                    targetGuild = ite.next();
                    ite.remove();

                    sendMessage(GuildMessages.otherAddedYouAsEnemy(
                            targetGuild.getFlagLevel(), targetGuild.name));
                }

                // 有没有把我从敌对帮派里删除的
                for (Iterator<Guild> ite = g
                        .getBeenRemovedEnemyHaveNotNotified().iterator(); ite
                        .hasNext();){
                    targetGuild = ite.next();
                    ite.remove();

                    sendMessage(GuildMessages.otherRemovedYouAsEnemy(
                            targetGuild.getFlagLevel(), targetGuild.name));
                }

                // 有没有把我从盟帮里删除的
                for (Iterator<Guild> ite = g
                        .getBeenRemovedFriendHaveNotNotified().iterator(); ite
                        .hasNext();){
                    targetGuild = ite.next();
                    ite.remove();

                    sendMessage(GuildMessages.otherRemovedYouAsFriend(
                            targetGuild.getFlagLevel(), targetGuild.name));
                }
            }
        }
    }

    public int getSceneUUID(){
        return sceneUUID;
    }

    public void setSceneID(int uuid, int actualSceneID){
        this.sceneUUID = uuid;
        this.actualSceneID = actualSceneID;
    }

    public void setOffline(long offlineTime){
        this.sender = null;
        this.lastOfflineTime = offlineTime;
        isOnline = false;
    }

    public void setFightAmount(int newAmount){
        this.fightAmount = newAmount;
    }

    public void setLevel(int newLevel){
        this.level = newLevel;
    }

    public void setMountLevel(int newMountLevel){
        this.mountLevel = newMountLevel;
    }

    public void setBowLevel(int newBowLevel){
        this.fengWuLevel = newBowLevel;
    }

    public void setTianJieLevel(int newTianjieLevel){
        this.tianjieLevel = newTianjieLevel;
    }

    public void setTianZuiLevel(int newTianzuiLevel){
        this.tianzuiLevel = newTianzuiLevel;
    }

    public void setChallengeAssistTimes(int assistTimes){
        this.challengeAssistTimes = assistTimes;
    }

    public void setChallengeSequence(int sequence){
        this.challengeSequence = sequence;
    }

    /**
     * 服务器保存以及发送给客户端时, 都用这个
     *
     * @return
     */
    @MultiThread
    GuildMemberProto encode(boolean toServer){
        GuildMemberProto.Builder builder = GuildMemberProto.newBuilder();
        builder.setId(id).setName(heroNameByteString)
                .setEnterGuildTime(enterGuildTime)
                .setContributionPoint(contributionPoint).setLevel(level)
                .setFightAmount(fightAmount).setRace(race)
                .setLastOfflineTime(lastOfflineTime).setMountLevel(mountLevel)
                .setFengWuLevel(fengWuLevel)
                .setChallengeAssistTimes(challengeAssistTimes)
                .setChallengeSequence(challengeSequence)
                .setTianjie(tianjieLevel).setTianzui(tianzuiLevel);

        if (toServer){
            builder.setEquipmentResource(model
                    .getOriginalResourceWithBestMountBow());
        } else{
            // client
            builder.setEquipmentResource(model.getResourceWithBestMountBow());
        }

        if (isOnline){
            builder.setIsOnline(true).setSceneId(actualSceneID); // 只能是服务器不关心, 但是客户端只有在在线时才需要知道的
        }

        ByteString nn = nickName;
        if (nn != null){
            builder.setNickName(nn);
        }

        nn = groupName;
        if (nn != null){
            builder.setGroupName(nn);
        }

        // ---- 历史帮派贡献 ----
        if (historyGiftGoods1 > 0){
            builder.setHistoryGiftGoods1(historyGiftGoods1);
        }

        if (historyGiftGoods2 > 0){
            builder.setHistoryGiftGoods2(historyGiftGoods2);
        }

        if (historyGiftGoods3 > 0){
            builder.setHistoryGiftGoods3(historyGiftGoods3);
        }

        if (historyGiftGoods4 > 0){
            builder.setHistoryGiftGoods4(historyGiftGoods4);
        }

        if (historyGiftMoney > 0){
            builder.setHistoryGiftMoney(historyGiftMoney);
        }

        return builder.build();
    }

    static GuildMember decode(GuildMemberProto proto, TimeService timeService){
        return new GuildMember(proto, timeService);
    }

    @Override
    public boolean isGuildLeader(){
        Guild g = getGuild();
        if (g != null){
            return g.getLeader() == this;
        }
        return false;
    }
}
