/**
 * 
 */
package app.game.module;

import static app.game.module.EquipmentMessages.*;
import static app.protobuf.LogContent.LogEnum.OperateType.*;

import org.jboss.netty.buffer.ChannelBuffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.data.FurnaceData;
import app.game.data.SpriteStat;
import app.game.data.UpgradeData;
import app.game.data.UpgradeData.ReduceCostResult;
import app.game.data.goods.Equipment;
import app.game.data.goods.EquipmentData;
import app.game.data.goods.EquipmentExtraStat;
import app.game.data.goods.EquipmentExtraStats;
import app.game.data.goods.EquipmentForgeGroup;
import app.game.data.goods.EquipmentForgeGroup.EquipmentForgeData;
import app.game.data.goods.Goods;
import app.game.data.goods.GoodsDatas;
import app.game.data.goods.MountEquipment;
import app.game.data.goods.RefinedData;
import app.game.data.goods.TaozData;
import app.game.data.mount.HeroMount;
import app.game.entity.Depot;
import app.game.entity.Hero;
import app.game.entity.Model.ModelType;
import app.game.entity.record.goods.GoodsOwnership;
import app.game.module.EquipmentMessages.MOVE_EQUIPMENT_RESULT;
import app.game.service.TimeService;
import app.game.service.WorldService;
import app.game.service.log.LogService;
import app.protobuf.ConfigContent.EquipmentLevelForgeProto;
import app.protobuf.GoodsServerContent.Quality;
import app.protobuf.SpriteStatContent.StatType;
import app.protobuf.TaskContent.TaskRelatedFunction;

import com.google.inject.Inject;
import com.mokylin.collection.LongConcurrentHashMap;
import com.mokylin.sink.util.BufferUtil;

/**
 * 装备模块
 * 
 * @author Liwei
 * 
 */
public class EquipmentModule{

    private static final Logger logger = LoggerFactory
            .getLogger(EquipmentModule.class);

    private final TimeService timeService;

    private final WorldService worldService;

    private final GoodsContainerModule goodsContainerModule;

    private final GoodsDatas goodsDatas;

    private final FurnaceData furnaceData;

    private final LogService logService;

    private final LongConcurrentHashMap<UpgradeLevelData> levelForgeDataMap;

    private final EquipmentExtraStats extraStats;

    @Inject
    public EquipmentModule(TimeService timeService, WorldService worldService,
            GoodsContainerModule goodsContainerModule, GoodsDatas goodsDatas,
            FurnaceData furnaceData, EquipmentExtraStats extraStats,
            LogService logService){
        this.timeService = timeService;
        this.worldService = worldService;
        this.goodsContainerModule = goodsContainerModule;
        this.goodsDatas = goodsDatas;
        this.furnaceData = furnaceData;
        this.extraStats = extraStats;
        this.logService = logService;

        levelForgeDataMap = new LongConcurrentHashMap<>();
    }

    public void onMessage(int sequenceID, ChannelBuffer buffer,
            HeroController hc){
        switch (sequenceID){
            case C2S_MOVE_EQUIPMENT:{
                processMoveEquipment(hc, buffer);
                return;
            }
            case C2S_MOVE_MOUNT_EQUIPMENT:{
                processMoveMountEquipment(hc, buffer);
                return;
            }
            case C2S_EQUIPMENT_GET_REFINED_DATA:{
                processGetRefinedData(hc, buffer);
                return;
            }
            case C2S_EQUIPMENT_REFINED:{
                processRefinedEquipment(hc, buffer);
                return;
            }
//            case C2S_EQUIPMENT_UPGRADE_QUALITY_DATA:{
//                processGetUpgradeQualityData(hc, buffer);
//                return;
//            }
//            case C2S_EQUIPMENT_UPGRADE_QUALITY:{
//                processUpgradeQuality(hc, buffer);
//                return;
//            }
            case C2S_EQUIPMENT_UPGRADE_LEVEL_DATA:{
                processGetUpgradeLevelData(hc, buffer);
                return;
            }
            case C2S_EQUIPMENT_UPGRADE_LEVEL:{
                processUpgradeLevel(hc, buffer);
                return;
            }
            case C2S_EQUIPMENT_MELTING:{
                processEquipmentMelting(hc, buffer);
                return;
            }
            default:{
                logger.error("EquipmentModule模块收到未知消息: {}", sequenceID);
            }
        }
    }

    private void processMoveEquipment(HeroController hc, ChannelBuffer buffer){
        int depotPos = BufferUtil.readVarInt32(buffer);
        int equipPos = BufferUtil.readVarInt32(buffer);

        Hero hero = hc.getHero();

        Depot depot = hero.getDepot();

        if (depot.isInvalidPos(depotPos)){
            logger.debug("装备穿戴，无效的背包位置，pos: {}", depotPos);
            hc.sendMessage(MOVE_EQUIPMENT_RESULT.DEPOT_POS_INVALID.getMessage());
            return;
        }

        if (depot.isLocked(depotPos)){
            logger.debug("装备穿戴，背包位置已锁定，pos: {}", depotPos);
            hc.sendMessage(MOVE_EQUIPMENT_RESULT.DEPOT_POS_LOCKED.getMessage());
            return;
        }

        Equipment[] euipmentList = hero.getEquipmentList();

        if (equipPos < 0 || equipPos >= euipmentList.length){
            logger.debug("装备穿戴，无效的装备位置，pos: {}", equipPos);
            hc.sendMessage(MOVE_EQUIPMENT_RESULT.EQUIPMENT_POS_INVALID
                    .getMessage());
            return;
        }

        Goods depotGoods = depot.get(depotPos);
        Equipment toRemove = euipmentList[equipPos];

        long ctime = timeService.getCurrentTime();

        Equipment toAdd = null;
        if (depotGoods == null){
            if (toRemove == null){
                logger.debug("装备穿戴，装备位置和背包位置都没有物品");
                hc.sendMessage(MOVE_EQUIPMENT_RESULT.EQUIPMENT_NOT_FOUND
                        .getMessage());
                return;
            }
        } else{
            if (depotGoods.isExpired(ctime)){
                logger.debug("装备穿戴，背包中的物品已经过期");
                hc.sendMessage(MOVE_EQUIPMENT_RESULT.DEPOT_EQUIPMENT_INVALID
                        .getMessage());
                return;
            }

            if (!(depotGoods instanceof Equipment)){
                // 背包物品不是装备
                logger.debug("装备穿戴，背包中的物品不是装备");
                hc.sendMessage(MOVE_EQUIPMENT_RESULT.DEPOT_EQUIPMENT_INVALID
                        .getMessage());
                return;
            }

            toAdd = (Equipment) depotGoods;

            if (!toAdd.isValidEquipPos(equipPos)){
                // 装备不是对应的部件
                logger.debug("装备穿戴，背包中的装备部件类型错误");
                hc.sendMessage(MOVE_EQUIPMENT_RESULT.DEPOT_EQUIPMENT_INVALID
                        .getMessage());
                return;
            }

            if (!toAdd.getData().isValidRace(hero.getRace().getId())){
                // 装备不是对应的职业需求
                logger.debug("装备穿戴，背包中的装备职业错误");
                hc.sendMessage(MOVE_EQUIPMENT_RESULT.DEPOT_EQUIPMENT_INVALID
                        .getMessage());
                return;
            }

            if (toAdd.getData().getRequireLevel() > hero.getLevel()){
                // 装备等级需求不足
                logger.debug("装备穿戴，背包中的装备等级不够");
                hc.sendMessage(MOVE_EQUIPMENT_RESULT.DEPOT_EQUIPMENT_INVALID
                        .getMessage());
                return;
            }

            if (!toAdd.isBinded()){
                // 装备穿上后即绑定
                long oldIdentifier = toAdd.getGoodsIdentifier();
                toAdd.bind();
                hero.getGoodsOwnership().changeIdentifier(oldIdentifier,
                        toAdd.getGoodsIdentifier(), toAdd.getCount(),
                        BIND_ON_EQUIP, ctime, toAdd.needLog());
            }
        }

        // 互换装备位置
        euipmentList[equipPos] = toAdd;
        depot.set(depotPos, toRemove);

        hc.sendMessage(MOVE_EQUIPMENT_RESULT.SUCCESS.getMessage(depotPos,
                equipPos));

        replaceHeroEquipment(hc, equipPos, toRemove, toAdd, ctime);
    }

    private void processMoveMountEquipment(HeroController hc,
            ChannelBuffer buffer){
        int depotPos = BufferUtil.readVarInt32(buffer);
        int equipPos = BufferUtil.readVarInt32(buffer);

        Hero hero = hc.getHero();

        HeroMount mount = hero.getMount();
        if (mount == null){
            logger.debug("坐骑装备穿戴，英雄还没有坐骑");
            hc.sendMessage(ERR_MOVE_MOUNT_EQ_FAIL_NOT_MOUNT);
            return;
        }

        Depot depot = hero.getDepot();

        if (depot.isInvalidPos(depotPos)){
            logger.debug("坐骑装备穿戴，无效的背包位置，pos: {}", depotPos);
            hc.sendMessage(ERR_MOVE_MOUNT_EQ_FAIL_INVALID_DEPOT_POS);
            return;
        }

        if (depot.isLocked(depotPos)){
            logger.debug("坐骑装备穿戴，背包位置已锁定，pos: {}", depotPos);
            hc.sendMessage(ERR_MOVE_MOUNT_EQ_FAIL_DEPOT_POS_LOCKED);
            return;
        }

        MountEquipment[] euipmentList = mount.getEquipmentList();

        if (equipPos < 0 || equipPos >= euipmentList.length){
            logger.debug("坐骑装备穿戴，无效的装备位置，pos: {}", equipPos);
            hc.sendMessage(ERR_MOVE_MOUNT_EQ_FAIL_INVALID_EQ_POS);
            return;
        }

        Goods depotGoods = depot.get(depotPos);
        MountEquipment equipment = euipmentList[equipPos];

        long ctime = timeService.getCurrentTime();

        if (depotGoods == null){
            if (equipment == null){
                logger.debug("坐骑装备穿戴，装备位置和背包位置都没有物品");
                hc.sendMessage(ERR_MOVE_MOUNT_EQ_FAIL_EQ_NOT_FOUND);
                return;
            }

            // 脱装备
            euipmentList[equipPos] = null;
            depot.set(depotPos, equipment);

            mount.onStatChanged();
            hc.getHeroFightModule().getRankObject().onMountUpdate(hero);
            if (mount.isValid()){
                // 变更属性
                hc.heroFightModule.changeBaseStat(false,
                        equipment.getTotalStat(), ctime);

                // 更新战斗力
                hc.getHeroFightModule().updateFightingAmount();
            }
        } else{
            if (depotGoods.isExpired(ctime)){
                logger.debug("装备穿戴，背包中的物品已经过期");
                hc.sendMessage(MOVE_EQUIPMENT_RESULT.DEPOT_EQUIPMENT_INVALID
                        .getMessage());
                return;
            }

            if (!(depotGoods instanceof MountEquipment)){
                // 背包物品不是装备
                logger.debug("坐骑装备穿戴，背包中的物品不是装备");
                hc.sendMessage(ERR_MOVE_MOUNT_EQ_FAIL_INVALID_GOODS);
                return;
            }

            MountEquipment depotEquipment = (MountEquipment) depotGoods;

            if (!depotEquipment.isValidEquipPos(equipPos)){
                // 装备不是对应的部件
                logger.debug("坐骑装备穿戴，背包中的装备部件类型错误");
                hc.sendMessage(ERR_MOVE_MOUNT_EQ_FAIL_INVALID_GOODS);
                return;
            }

            if (depotEquipment.getData().getRequireLevel() > hero.getLevel()){
                // 装备等级需求不足
                logger.debug("坐骑装备穿戴，背包中的装备等级不够");
                hc.sendMessage(ERR_MOVE_MOUNT_EQ_FAIL_INVALID_GOODS);
                return;
            }

            if (depotEquipment.getRequireMountLevel() > mount.getBestMountId()){
                // 坐骑等级需求不足
                logger.debug("坐骑装备穿戴，坐骑阶数不足");
                hc.sendMessage(ERR_MOVE_MOUNT_EQ_FAIL_MOUNT_LEVEL_NOT_ENOUGH);
                return;
            }

            // 互换装备位置
            euipmentList[equipPos] = depotEquipment;
            depot.set(depotPos, equipment);

            mount.onStatChanged();
            hc.getHeroFightModule().getRankObject().onMountUpdate(hero);
            if (mount.isValid()){
                // 变更属性
                if (equipment == null){
                    // 穿装备
                    hc.heroFightModule.changeBaseStat(true,
                            depotEquipment.getTotalStat(), ctime);
                } else{
                    // 互换装备
                    hc.heroFightModule.changeBaseStat(equipment.getTotalStat(),
                            depotEquipment.getTotalStat(), ctime);
                }

                // 更新战斗力

                hc.getHeroFightModule().updateFightingAmount();
            }

            if (!depotEquipment.isBinded()){
                // 装备穿上后即绑定
                long oldIdentifier = depotEquipment.getGoodsIdentifier();
                depotEquipment.bind();
                hero.getGoodsOwnership().changeIdentifier(oldIdentifier,
                        depotEquipment.getGoodsIdentifier(),
                        depotEquipment.getCount(), BIND_ON_EQUIP, ctime,
                        depotEquipment.needLog());
            }
        }

        hc.sendMessage(moveMountEquipment(depotPos, equipPos));
    }

    private void processGetRefinedData(HeroController hc, ChannelBuffer buffer){
        int id = BufferUtil.readVarInt32(buffer);

        EquipmentData equipmentData = goodsDatas.getEquipment(id);

        if (equipmentData == null){
            logger.warn("请求装备强化数据，但是装备没找到");
            hc.sendMessage(ERR_REFINED_DATA_FAIL_EQUIPMENT_NOT_FOUND);
            return;
        }

        if (!equipmentData.canRefined()){
            logger.warn("请求装备强化数据，但是装备不能强化");
            hc.sendMessage(ERR_REFINED_DATA_FAIL_EQUIPMENT_CANT_REFINED);
            return;
        }

        int refinedTimes = BufferUtil.readVarInt32(buffer);
        if (refinedTimes <= 0){
            logger.warn("请求装备强化数据，但是强化等级<=0");
            hc.sendMessage(ERR_REFINED_DATA_FAIL_REFINED_INVALID);
            return;
        }

        RefinedData refinedData = equipmentData.getRefinedData(refinedTimes);

        if (refinedData.getRefinedTimes() != refinedTimes){
            logger.warn("请求装备强化数据，但是强化等级无效");
            hc.sendMessage(ERR_REFINED_DATA_FAIL_REFINED_INVALID);
            return;
        }

        int intQuality = 0;
        if (buffer.readable()){
            intQuality = BufferUtil.readVarInt32(buffer);
        }

        hc.sendMessage(refinedData.getUpgradeDataMsg(intQuality));
    }

    private void processRefinedEquipment(HeroController hc, ChannelBuffer buffer){
        int equipmentPos = BufferUtil.readVarInt32(buffer);

//        if (isDepotPos){
//            logger.warn("装备强化，不能强化背包中的装备");
//            hc.sendMessage(ERR_REFINED_FAIL_DEPOT_EQUIPMENT);
//            return;
//
//            Depot depot = hc.getDepot();
//            if (depot.isInvalidPos(realPos)){
//                logger.warn("装备强化，背包中位置无效");
//                hc.sendMessage(ERR_REFINED_FAIL_EQUIPMENT_NOT_FOUND);
//                return;
//            }
//
//            if (depot.isLocked(realPos)){
//                logger.warn("装备强化，背包中位置已锁定");
//                hc.sendMessage(ERR_REFINED_FAIL_EQUIPMENT_NOT_FOUND);
//                return;
//            }
//
//            Goods goods = depot.get(realPos);
//            if (goods == null || !(goods instanceof Equipment)){
//                logger.warn("装备强化，背包中位置中的物品无效");
//                hc.sendMessage(ERR_REFINED_FAIL_EQUIPMENT_NOT_FOUND);
//                return;
//            }
//
//            equipment = (Equipment) goods;
//
//        } else{
//            // 穿在身上
//            Equipment[] list = hc.getHero().getEquipmentList();
//
//            if (realPos < 0 || realPos >= list.length){
//                logger.warn("装备强化，英雄身上的装备位置无效");
//                hc.sendMessage(ERR_REFINED_FAIL_EQUIPMENT_NOT_FOUND);
//                return;
//            }
//
//            equipment = list[realPos];
//            if (equipment == null){
//                logger.warn("装备强化，英雄身上的装备位置为空");
//                hc.sendMessage(ERR_REFINED_FAIL_EQUIPMENT_NOT_FOUND);
//                return;
//            }
//        }

        // 穿在身上
        Equipment[] list = hc.getHero().getEquipmentList();

        if (equipmentPos < 0 || equipmentPos >= list.length){
            logger.warn("装备强化，英雄身上的装备位置无效");
            hc.sendMessage(ERR_REFINED_FAIL_EQUIPMENT_NOT_FOUND);
            return;
        }

        Equipment equipment = list[equipmentPos];
        if (equipment == null){
            logger.warn("装备强化，英雄身上的装备位置为空");
            hc.sendMessage(ERR_REFINED_FAIL_EQUIPMENT_NOT_FOUND);
            return;
        }

        if (equipment.getQuality().getNumber() < Quality.PURPLE.getNumber()){
            logger.warn("装备强化，装备品质比紫色小");
            hc.sendMessage(ERR_REFINED_FAIL_QUALITY_NOT_ENOUGH);
            return;
        }

        long oldIdentifier = equipment.getGoodsIdentifier();
        hc.getGoodsOwnership().checkGoodsEnough(oldIdentifier,
                equipment.getCount());

        if (equipment.hasExpireTime()){
            logger.warn("装备强化，装备有过期时间");
            hc.sendMessage(ERR_REFINED_FAIL_EQUIPMENT_WILL_EXPIRED);
            return;
        }

        RefinedData refinedData = equipment.getNextRefinedData();
        if (refinedData == null){
            logger.warn("装备强化，装备已经是最高级了");
            hc.sendMessage(ERR_REFINED_FAIL_EQUIPMENT_CANT_REFINED);
            return;
        }

        UpgradeData upgradeData = refinedData.getUpgradeData();

        if (upgradeData == null){
            logger.warn("装备强化，装备不能强化");
            hc.sendMessage(ERR_REFINED_FAIL_EQUIPMENT_CANT_REFINED);
            return;
        }

        long ctime = timeService.getCurrentTime();
        String iEventId = logService.newTodoEventId(); // TODO 加日志
        ReduceCostResult result = upgradeData.tryReduceCostAllowBindedYuanbao(
                "装备强化", hc.getHeroMiscModule(), ctime, hc.getHero(),
                hc.getSender(), buffer, goodsContainerModule, REFINED_FORGE,
                iEventId);

        switch (result.getStatus()){
            case GOODS_NOT_ENOUGH:{
                hc.sendMessage(ERR_REFINED_FAIL_GOODS_NOT_ENOUGH);
                return;
            }
            case LIJIN_NOT_ENOUGH:{
                hc.sendMessage(ERR_REFINED_FAIL_LIJIN_NOT_ENOUGH);
                return;
            }
            case YUANBAO_NOT_ENOUGH:{
                hc.sendMessage(ERR_REFINED_FAIL_YUANBAO_NOT_ENOUGH);
                return;
            }
            case INVALID_POS_COUNT:{
                hc.sendMessage(ERR_REFINED_FAIL_INVALID_POS);
                return;
            }
            case SUCCESS:{
                break;
            }
            case MONEY_NOT_ENOUGH:{
                hc.sendMessage(ERR_REFINED_FAIL_MONEY_NOT_ENOUGH);
                return;
            }
            case REAL_AIR_NOT_ENOUGH:{
                hc.sendMessage(ERR_REFINED_FAIL_GOODS_NOT_ENOUGH);
                return;
            }
            default:{
                logger.error("装备强化，遇到未知的失败类型，{}", result);
                hc.sendMessage(ERR_REFINED_FAIL_GOODS_NOT_ENOUGH);
                return;
            }
        }

        // 开始升级
        int upgradeTimes = equipment.incrementRefinedUpgradeTimes();

        if (!upgradeData.tryUpgrade(upgradeTimes)){
            // 失败，老装备需要变成绑定状态
            if (result.hasBindedGoods()){
                equipment.bind();
            }

            hc.getGoodsOwnership().changeIdentifier(oldIdentifier,
                    equipment.getGoodsIdentifier(), equipment.getCount(),
                    REFINED_FORGE, ctime, equipment.needLog());

            hc.sendMessage(REFINED_FAIL_MSG);

            logService.todo();
//            logService.writeOperateLog(REFINED_FORGE, EQUIPMENT,
//                    equipment.getId(), upgradeTimes,
//                    equipment.getRefinedTimes(), equipment.getIntQuality(), 0,
//                    hc.getHero());
            return;
        }

        // 成功
        equipment.clearRefinedUpgradeTimes();

        Equipment newEquipment = equipment.newRefinedEquipment();
        if (result.hasBindedGoods()){
            newEquipment.bind();
        }

        hc.getGoodsOwnership().changeIdentifier(oldIdentifier,
                newEquipment.getGoodsIdentifier(), newEquipment.getCount(),
                REFINED_FORGE, ctime, newEquipment.needLog());

        // 成功消息
        hc.sendMessage(refinedEquipmentMsg(equipmentPos, newEquipment
                .getNextRefinedData(), equipment.getQuality().getNumber()));

        // 更新装备
        replaceHeroEquipment(hc, equipmentPos, equipment, newEquipment, ctime);
//        if (isDepotPos){
//            hc.getDepot().set(realPos, newEquipment);
//        } else{
//            replaceHeroEquipment(hc, realPos, equipment, newEquipment, ctime);
//        }

        if (refinedData.isBroadcast()){
            // 强化成功广播
            worldService.broadcastToEnteredFirstSceneHeroWithSameServerData(
                    refinedBroadcastMsg(hc.getHero().getNameBytes(),
                            newEquipment.getData().nameBytes,
                            newEquipment.getIntQuality(),
                            newEquipment.getRefinedTimes()),
                    hc.getServerData(), 0);
        }

        logService.todo();
//        logService.writeOperateLog(REFINED_FORGE, EQUIPMENT,
//                newEquipment.getId(), 0, newEquipment.getRefinedTimes(),
//                newEquipment.getIntQuality(), 0, hc.getHero());
    }

//    private void processGetUpgradeQualityData(HeroController hc,
//            ChannelBuffer buffer){
//        int id = BufferUtil.readVarInt32(buffer);
//
//        EquipmentData equipmentData = goodsDatas.getEquipment(id);
//
//        if (equipmentData == null){
//            logger.warn("请求装备提升品质数据，但是装备没找到");
//            hc.sendMessage(ERR_UPGRADE_QUALITY_DATA_FAIL_EQUIPMENT_NOT_FOUND);
//            return;
//        }
//
//        if (!equipmentData.canUpgradeQuality()){
//            logger.warn("请求装备提升品质数据，但是装备不能提升品质");
//            hc.sendMessage(ERR_UPGRADE_QUALITY_DATA_FAIL_CANT_UPGRADE_QUALITY);
//            return;
//        }
//
//        int intQuality = BufferUtil.readVarInt32(buffer);
//        Quality quality = Quality.valueOf(intQuality);
//        if (quality == null){
//            logger.warn("请求装备提升品质数据，品质无效");
//            hc.sendMessage(ERR_UPGRADE_QUALITY_DATA_FAIL_INVALID_QUALITY);
//            return;
//        }
//
//        int intStatType = BufferUtil.readVarInt32(buffer);
//        StatType statType = StatType.valueOf(intStatType);
//        if (statType == null){
//            logger.warn("请求装备提升品质数据，附加属性类型无效");
//            hc.sendMessage(ERR_UPGRADE_QUALITY_DATA_FAIL_INVALID_STAT_TYPE);
//            return;
//        }
//
//        AddedData addedType = equipmentData.getAddedData(statType, quality);
//        if (addedType.getStatType() != statType){
//            logger.warn("请求装备提升品质数据，附加属性不存在");
//            hc.sendMessage(ERR_UPGRADE_QUALITY_DATA_FAIL_INVALID_STAT_TYPE);
//            return;
//        }
//
//        hc.sendMessage(addedType.getUpgradeQualityDataMsg());
//    }
//
//    private void processUpgradeQuality(HeroController hc, ChannelBuffer buffer){
//        int equipmentPos = BufferUtil.readVarInt32(buffer);
//
//        boolean isDepotPos = (equipmentPos & 1) == 0;
//        int realPos = equipmentPos >>> 1;
//
//        Equipment equipment = null;
//        Depot depot = hc.getDepot();
//        if (isDepotPos){
//            if (depot.isInvalidPos(realPos)){
//                logger.warn("装备提升品质，背包中位置无效");
//                hc.sendMessage(ERR_UPGRADE_QUALITY_FAIL_EQUIPMENT_NOT_FOUND);
//                return;
//            }
//
//            if (depot.isLocked(realPos)){
//                logger.warn("装备提升品质，背包中位置已锁定");
//                hc.sendMessage(ERR_UPGRADE_QUALITY_FAIL_EQUIPMENT_NOT_FOUND);
//                return;
//            }
//
//            Goods goods = depot.get(realPos);
//            if (goods == null || !(goods instanceof Equipment)){
//                logger.warn("装备提升品质，背包中位置中的物品无效");
//                hc.sendMessage(ERR_UPGRADE_QUALITY_FAIL_EQUIPMENT_NOT_FOUND);
//                return;
//            }
//
//            equipment = (Equipment) goods;
//
//        } else{
//            // 穿在身上
//            Equipment[] list = hc.getHero().getEquipmentList();
//
//            if (realPos < 0 || realPos >= list.length){
//                logger.warn("装备提升品质，英雄身上的装备位置无效");
//                hc.sendMessage(ERR_UPGRADE_QUALITY_FAIL_EQUIPMENT_NOT_FOUND);
//                return;
//            }
//
//            equipment = list[realPos];
//            if (equipment == null){
//                logger.warn("装备提升品质，英雄身上的装备位置为空");
//                hc.sendMessage(ERR_UPGRADE_QUALITY_FAIL_EQUIPMENT_NOT_FOUND);
//                return;
//            }
//        }
//
//        assert equipment != null;
//
//        long oldIdentifier = equipment.getGoodsIdentifier();
//        hc.getGoodsOwnership().checkGoodsEnough(oldIdentifier,
//                equipment.getCount());
//
//        if (equipment.hasExpireTime()){
//            logger.warn("装备提升品质，装备有过期时间");
//            hc.sendMessage(ERR_UPGRADE_QUALITY_FAIL_EQUIPMENT_WILL_EXIPRED);
//            return;
//        }
//
//        AddedData addedData = equipment.getNextAddedData();
//        if (addedData == null){
//            logger.warn("装备提升品质，装备品质已经是最高级了");
//            hc.sendMessage(ERR_UPGRADE_QUALITY_FAIL_CANT_UPGRADE);
//            return;
//        }
//
//        EquipmentForgeData forgeData = addedData.getForgeData();
//        if (forgeData == null){
//            logger.warn("装备提升品质，装备不能提升品质");
//            hc.sendMessage(ERR_UPGRADE_QUALITY_FAIL_CANT_UPGRADE);
//            return;
//        }
//
//        // 消耗装备
//        int equipmentCostCount = BufferUtil.readVarInt32(buffer);
//        if (equipmentCostCount <= 0 || equipmentCostCount > 4){
//            logger.warn("装备提升品质，消耗的装备数量无效, [1, 4] ");
//            hc.sendMessage(ERR_UPGRADE_QUALITY_FAIL_INVALID_REQUIRED_EQUIPMENT);
//            return;
//        }
//
//        long ctime = timeService.getCurrentTime();
//        equipment.version = ctime;
//
//        int totalForgeAmount = 0;
//        IntArrayList equipmentPosCountList = new IntArrayList();
//        for (int i = 0; i < equipmentCostCount; i++){
//            int pos = BufferUtil.readVarInt32(buffer);
//
//            if (depot.isInvalidPos(pos)){
//                logger.warn("装备提升品质，消耗装备的物品位置无效 ");
//                hc.sendMessage(ERR_UPGRADE_QUALITY_FAIL_INVALID_REQUIRED_EQUIPMENT);
//                return;
//            }
//
//            if (depot.isLocked(pos)){
//                logger.warn("装备提升品质，消耗装备的物品位置已被锁定 ");
//                hc.sendMessage(ERR_UPGRADE_QUALITY_FAIL_INVALID_REQUIRED_EQUIPMENT);
//                return;
//            }
//
//            Goods g = depot.get(pos);
//            if (g == null){
//                logger.warn("装备提升品质，消耗装备的物品位置是null");
//                hc.sendMessage(ERR_UPGRADE_QUALITY_FAIL_INVALID_REQUIRED_EQUIPMENT);
//                return;
//            }
//
//            if (!(g instanceof Equipment)){
//                logger.warn("装备提升品质，消耗装备位置上的物品不是装备");
//                hc.sendMessage(ERR_UPGRADE_QUALITY_FAIL_INVALID_REQUIRED_EQUIPMENT);
//                return;
//            }
//
//            if (g.hasExpireTime()){
//                logger.warn("装备提升品质，消耗装备有过期时间");
//                hc.sendMessage(ERR_UPGRADE_QUALITY_FAIL_REQUIRED_EQUIPMENT_WILL_EXIPRED);
//                return;
//            }
//
////            if (g.isExpired(ctime)){
////                logger.warn("装备提升品质，消耗装备已过期");
////                hc.sendMessage(ERR_UPGRADE_QUALITY_FAIL_INVALID_REQUIRED_EQUIPMENT);
////                return;
////            }
//
//            Equipment costEquipment = (Equipment) g;
//            if (costEquipment.getForgeAmount() <= 0){
//                logger.warn("装备提升品质，消耗装备没有锻造值");
//                hc.sendMessage(ERR_UPGRADE_QUALITY_FAIL_INVALID_REQUIRED_EQUIPMENT);
//                return;
//            }
//
//            if (costEquipment.getData().getRequireLevel() > equipment.getData()
//                    .getRequireLevel()){
//                logger.warn("装备提升品质，消耗装备的等级大于源装备");
//                hc.sendMessage(ERR_UPGRADE_QUALITY_FAIL_INVALID_REQUIRED_EQUIPMENT);
//                return;
//            }
//
//            // 防止客户端相同的装备位置上来
//            if (costEquipment.version == ctime){
//                logger.warn("装备提升品质，消耗装备重复了？");
//                hc.sendMessage(ERR_UPGRADE_QUALITY_FAIL_INVALID_REQUIRED_EQUIPMENT);
//                return;
//            }
//            costEquipment.version = ctime;
//
//            totalForgeAmount += costEquipment.getForgeAmount();
//            equipmentPosCountList.add(pos);
//            equipmentPosCountList.add(costEquipment.getCount());
//        }
//
//        UpgradeData upgradeData = forgeData.getUpgradeData();
//
//        // 消耗其他物品
//        ReduceCostResult result = upgradeData.tryReduceCost("装备提升品质",
//                hc.getHeroMiscModule(), ctime, hc.getHero(), hc.getSender(),
//                buffer, goodsContainerModule, QUALITY_FORGE, 0, 0);
//
//        switch (result.getStatus()){
//            case GOODS_NOT_ENOUGH:{
//                hc.sendMessage(ERR_UPGRADE_QUALITY_FAIL_GOODS_NOT_ENOUGH);
//                return;
//            }
//            case LIJIN_NOT_ENOUGH:{
//                hc.sendMessage(ERR_UPGRADE_QUALITY_FAIL_LIJIN_NOT_ENOUGH);
//                return;
//            }
//            case YUANBAO_NOT_ENOUGH:{
//                hc.sendMessage(ERR_UPGRADE_QUALITY_FAIL_YUANBAO_NOT_ENOUGH);
//                return;
//            }
//            case INVALID_POS_COUNT:{
//                hc.sendMessage(ERR_UPGRADE_QUALITY_FAIL_INVALID_POS);
//                return;
//            }
//            case SUCCESS:{
//                break;
//            }
//            case MONEY_NOT_ENOUGH:{
//                hc.sendMessage(ERR_UPGRADE_QUALITY_FAIL_MONEY_NOT_ENOUGH);
//                return;
//            }
//            case REAL_AIR_NOT_ENOUGH:{
//                hc.sendMessage(ERR_UPGRADE_QUALITY_FAIL_GOODS_NOT_ENOUGH);
//                return;
//            }
//            default:{
//                logger.error("装备提升品质，遇到未知的失败类型，{}", result);
//                hc.sendMessage(ERR_UPGRADE_QUALITY_FAIL_GOODS_NOT_ENOUGH);
//                return;
//            }
//        }
//
//        // 扣消耗的装备
//        goodsContainerModule.reduceGoodsListAnyway(equipmentPosCountList,
//                hc.getHero(), hc.getSender(), QUALITY_FORGE, 0, ctime);
//
//        // 开始升级
//        if (!forgeData.tryUpgrade(totalForgeAmount)){
//            // 失败
//            hc.sendMessage(UPGRADE_QUALITY_FAIL_MSG);
//
//            logService.writeOperateLog(QUALITY_FORGE, EQUIPMENT,
//                    equipment.getId(), 1, equipment.getRefinedTimes(),
//                    equipment.getIntQuality(), 0, hc.getHero());
//            return;
//        }
//
//        // 成功
//        Equipment newEquipment = equipment.newQualityEquipment();
//
//        hc.getGoodsOwnership().changeIdentifier(oldIdentifier,
//                newEquipment.getGoodsIdentifier(), newEquipment.getCount(),
//                QUALITY_FORGE, ctime, newEquipment.needLog());
//
//        // 成功消息
//        hc.sendMessage(upgradeEquipmentQualityMsg(equipmentPos,
//                newEquipment.getNextAddedData()));
//
//        // 更新装备
//        if (isDepotPos){
//            hc.getDepot().set(realPos, newEquipment);
//        } else{
//            replaceHeroEquipment(hc, realPos, equipment, newEquipment, ctime);
//        }
//
//        if (forgeData.isBroadcast()){
//            // 提升品质成功广播
//            worldService.broadcastToEnteredFirstSceneHero(
//                    upgradeQualityBroadcastMsg(hc.getHero().getNameBytes(),
//                            newEquipment.getData().nameBytes,
//                            newEquipment.getIntQuality()), 0);
//        }
//
//        logService.writeOperateLog(QUALITY_FORGE, EQUIPMENT,
//                newEquipment.getId(), 0, newEquipment.getRefinedTimes(),
//                newEquipment.getIntQuality(), 0, hc.getHero());
//    }

    private void processGetUpgradeLevelData(HeroController hc,
            ChannelBuffer buffer){
        int id = BufferUtil.readVarInt32(buffer);

        EquipmentData equipmentData = goodsDatas.getEquipment(id);

        if (equipmentData == null){
            logger.warn("请求装备提升等级数据，但是装备没找到");
            hc.sendMessage(ERR_UPGRADE_LEVEL_DATA_FAIL_EQUIPMENT_NOT_FOUND);
            return;
        }

        EquipmentForgeGroup levelForgeGroup = equipmentData
                .getLevelForgeGroup();

        if (levelForgeGroup == null){
            logger.warn("请求装备提升等级数据，但是装备不能提升等级");
            hc.sendMessage(ERR_UPGRADE_LEVEL_DATA_FAIL_CANT_UPGRADE_LEVEL);
            return;
        }

        int refinedTimes = BufferUtil.readVarInt32(buffer);
        if (!equipmentData.isValidRefinedTimes(refinedTimes)){
            logger.warn("请求装备提升等级数据，强化等级无效");
            hc.sendMessage(ERR_UPGRADE_LEVEL_DATA_FAIL_INVALID_REFINED);
            return;
        }

        int intQuality = BufferUtil.readVarInt32(buffer);
        Quality quality = Quality.valueOf(intQuality);
        if (quality == null){
            logger.warn("请求装备提升等级数据，品质无效");
            hc.sendMessage(ERR_UPGRADE_LEVEL_DATA_FAIL_INVALID_QUALITY);
            return;
        }

        EquipmentForgeData forgeData = levelForgeGroup.getForgeData(quality);
        if (forgeData == null){
            logger.warn("请求装备提升等级数据，但是这种品质不能升级");
            hc.sendMessage(ERR_UPGRADE_LEVEL_DATA_FAIL_CANT_UPGRADE_LEVEL);
            return;
        }

        int intStatType = BufferUtil.readVarInt32(buffer);
        StatType statType = StatType.valueOf(intStatType);
        if (statType == null){
            logger.warn("请求装备提升等级数据，附加属性类型无效");
            hc.sendMessage(ERR_UPGRADE_LEVEL_DATA_FAIL_INVALID_STAT_TYPE);
            return;
        }

        UpgradeLevelData data = getUpgradeLevelData(equipmentData, statType,
                quality, refinedTimes, forgeData);
        if (data == null){
            logger.warn("请求装备提升等级数据，附加属性不存在");
            hc.sendMessage(ERR_UPGRADE_LEVEL_DATA_FAIL_INVALID_STAT_TYPE);
            return;
        }

        hc.sendMessage(data.getUpgradeLevelMsg());
    }

    private void processUpgradeLevel(HeroController hc, ChannelBuffer buffer){
        int equipmentPos = BufferUtil.readVarInt32(buffer);

//        boolean isDepotPos = (equipmentPos & 1) == 0;
//        int realPos = equipmentPos >>> 1;
//
//        Equipment equipment = null;
//        Depot depot = hc.getDepot();
//        if (isDepotPos){
//            if (depot.isInvalidPos(realPos)){
//                logger.warn("装备提升等级，背包中位置无效");
//                hc.sendMessage(ERR_UPGRADE_LEVEL_FAIL_EQUIPMENT_NOT_FOUND);
//                return;
//            }
//
//            if (depot.isLocked(realPos)){
//                logger.warn("装备提升等级，背包中位置已锁定");
//                hc.sendMessage(ERR_UPGRADE_LEVEL_FAIL_EQUIPMENT_NOT_FOUND);
//                return;
//            }
//
//            Goods goods = depot.get(realPos);
//            if (goods == null || !(goods instanceof Equipment)){
//                logger.warn("装备提升等级，背包中位置中的物品无效");
//                hc.sendMessage(ERR_UPGRADE_LEVEL_FAIL_EQUIPMENT_NOT_FOUND);
//                return;
//            }
//
//            equipment = (Equipment) goods;
//
//        } else{
//            // 穿在身上
//            Equipment[] list = hc.getHero().getEquipmentList();
//
//            if (realPos < 0 || realPos >= list.length){
//                logger.warn("装备提升等级，英雄身上的装备位置无效");
//                hc.sendMessage(ERR_UPGRADE_LEVEL_FAIL_EQUIPMENT_NOT_FOUND);
//                return;
//            }
//
//            equipment = list[realPos];
//            if (equipment == null){
//                logger.warn("装备提升等级，英雄身上的装备位置为空");
//                hc.sendMessage(ERR_UPGRADE_LEVEL_FAIL_EQUIPMENT_NOT_FOUND);
//                return;
//            }
//        }

        // 穿在身上
        Equipment[] list = hc.getHero().getEquipmentList();

        if (equipmentPos < 0 || equipmentPos >= list.length){
            logger.warn("装备提升等级，英雄身上的装备位置无效");
            hc.sendMessage(ERR_UPGRADE_LEVEL_FAIL_EQUIPMENT_NOT_FOUND);
            return;
        }

        Equipment equipment = list[equipmentPos];
        if (equipment == null){
            logger.warn("装备提升等级，英雄身上的装备位置为空");
            hc.sendMessage(ERR_UPGRADE_LEVEL_FAIL_EQUIPMENT_NOT_FOUND);
            return;
        }

        Quality quality = equipment.getQuality();
        if (quality.getNumber() < Quality.PURPLE.getNumber()){
            logger.warn("装备提升等级，装备品质比紫色小");
            hc.sendMessage(ERR_UPGRADE_LEVEL_FAIL_QUALITY_NOT_ENOUGH);
            return;
        }

        if (!equipment.isMaxRefinedTimes()){
            logger.warn("装备提升等级，装备品质比紫色小");
            hc.sendMessage(ERR_UPGRADE_LEVEL_FAIL_NOT_MAX_REFINED_TIMES);
            return;
        }

        long oldIdentifier = equipment.getGoodsIdentifier();
        hc.getGoodsOwnership().checkGoodsEnough(oldIdentifier,
                equipment.getCount());

        if (equipment.hasExpireTime()){
            logger.warn("装备提升等级，装备有过期时间");
            hc.sendMessage(ERR_UPGRADE_LEVEL_FAIL_EQUIPMENT_WILL_EXIPRED);
            return;
        }

        EquipmentData newEquipmentData = equipment.getNextLevelEquipment();
        if (newEquipmentData == null){
            logger.warn("装备提升等级，没有下一等级的装备");
            hc.sendMessage(ERR_UPGRADE_LEVEL_FAIL_CANT_UPGRADE);
            return;
        }

        if (hc.getHero().getLevel() < newEquipmentData.getRequireLevel()){
            logger.warn("装备提升等级，升级后的装备需求等级比英雄当前等级高");
            hc.sendMessage(ERR_UPGRADE_LEVEL_FAIL_CANT_UPGRADE);
            return;
        }

        int refinedTimes = equipment.getRefinedTimes();
        StatType statType = equipment.getStatType();

        EquipmentForgeGroup levelForgeGroup = newEquipmentData
                .getLevelForgeGroup();

        if (levelForgeGroup == null){
            logger.warn("装备提升等级，但是装备没有升级数据");
            hc.sendMessage(ERR_UPGRADE_LEVEL_FAIL_CANT_UPGRADE);
            return;
        }

        EquipmentForgeData forgeData = levelForgeGroup.getForgeData(quality);
        if (forgeData == null){
            logger.warn("装备提升等级，但是这种品质不能升级");
            hc.sendMessage(ERR_UPGRADE_LEVEL_FAIL_CANT_UPGRADE);
            return;
        }

//        UpgradeLevelData upgradeLevelData = getUpgradeLevelData(
//                newEquipmentData, statType, quality, refinedTimes, forgeData);
//        if (upgradeLevelData == null){
//            logger.warn("装备提升等级，没有找到目标装备不能提升等级数据");
//            hc.sendMessage(ERR_UPGRADE_LEVEL_FAIL_CANT_UPGRADE);
//            return;
//        }
//
        // 消耗装备
//        int equipmentCostCount = BufferUtil.readVarInt32(buffer);
//        if (equipmentCostCount <= 0 || equipmentCostCount > 4){
//            logger.warn("装备提升等级，消耗的装备数量无效, [1, 4] ");
//            hc.sendMessage(ERR_UPGRADE_LEVEL_FAIL_INVALID_REQUIRED_EQUIPMENT);
//            return;
//        }
//
//        long ctime = timeService.getCurrentTime();
//        equipment.version = ctime;
//
//        int totalForgeAmount = 0;
//        IntArrayList equipmentPosCountList = new IntArrayList();
//        for (int i = 0; i < equipmentCostCount; i++){
//            int pos = BufferUtil.readVarInt32(buffer);
//
//            if (depot.isInvalidPos(pos)){
//                logger.warn("装备提升等级，消耗装备的物品位置无效 ");
//                hc.sendMessage(ERR_UPGRADE_LEVEL_FAIL_INVALID_REQUIRED_EQUIPMENT);
//                return;
//            }
//
//            if (depot.isLocked(pos)){
//                logger.warn("装备提升等级，消耗装备的物品位置已被锁定 ");
//                hc.sendMessage(ERR_UPGRADE_LEVEL_FAIL_INVALID_REQUIRED_EQUIPMENT);
//                return;
//            }
//
//            Goods g = depot.get(pos);
//            if (g == null){
//                logger.warn("装备提升等级，消耗装备的物品位置是null");
//                hc.sendMessage(ERR_UPGRADE_LEVEL_FAIL_INVALID_REQUIRED_EQUIPMENT);
//                return;
//            }
//
//            if (!(g instanceof Equipment)){
//                logger.warn("装备提升等级，消耗装备位置上的物品不是装备");
//                hc.sendMessage(ERR_UPGRADE_LEVEL_FAIL_INVALID_REQUIRED_EQUIPMENT);
//                return;
//            }
//
//            if (g.hasExpireTime()){
//                logger.warn("装备提升等级，消耗装备有过期时间");
//                hc.sendMessage(ERR_UPGRADE_LEVEL_FAIL_REQUIRED_EQUIPMENT_WILL_EXIPRED);
//                return;
//            }
//
////            if (g.isExpired(ctime)){
////                logger.warn("装备提升等级，消耗装备已过期");
////                hc.sendMessage(ERR_UPGRADE_LEVEL_FAIL_INVALID_REQUIRED_EQUIPMENT);
////                return;
////            }
//
//            Equipment costEquipment = (Equipment) g;
//            if (costEquipment.getForgeAmount() <= 0){
//                logger.warn("装备提升等级，消耗装备没有锻造值");
//                hc.sendMessage(ERR_UPGRADE_LEVEL_FAIL_INVALID_REQUIRED_EQUIPMENT);
//                return;
//            }
//
//            if (costEquipment.getData().getRequireLevel() > equipment.getData()
//                    .getRequireLevel()){
//                logger.warn("装备提升等级，消耗装备的等级大于源装备");
//                hc.sendMessage(ERR_UPGRADE_LEVEL_FAIL_INVALID_REQUIRED_EQUIPMENT);
//                return;
//            }
//
//            // 防止客户端相同的装备位置上来
//            if (costEquipment.version == ctime){
//                logger.warn("装备提升等级，消耗装备重复了？");
//                hc.sendMessage(ERR_UPGRADE_LEVEL_FAIL_INVALID_REQUIRED_EQUIPMENT);
//                return;
//            }
//            costEquipment.version = ctime;
//
//            totalForgeAmount += costEquipment.getForgeAmount();
//            equipmentPosCountList.add(pos);
//            equipmentPosCountList.add(costEquipment.getCount());
//        }

        UpgradeData upgradeData = forgeData.getUpgradeData();

        long ctime = timeService.getCurrentTime();
        String iEventId = logService.newTodoEventId(); // TODO 加日志
        ReduceCostResult result = upgradeData.tryReduceCostAllowBindedYuanbao(
                "装备提升等级", hc.getHeroMiscModule(), ctime, hc.getHero(),
                hc.getSender(), buffer, goodsContainerModule, LEVEL_FORGE,
                iEventId);

        switch (result.getStatus()){
            case GOODS_NOT_ENOUGH:{
                hc.sendMessage(ERR_UPGRADE_LEVEL_FAIL_GOODS_NOT_ENOUGH);
                return;
            }
            case LIJIN_NOT_ENOUGH:{
                hc.sendMessage(ERR_UPGRADE_LEVEL_FAIL_LIJIN_NOT_ENOUGH);
                return;
            }
            case YUANBAO_NOT_ENOUGH:{
                hc.sendMessage(ERR_UPGRADE_LEVEL_FAIL_YUANBAO_NOT_ENOUGH);
                return;
            }
            case INVALID_POS_COUNT:{
                hc.sendMessage(ERR_UPGRADE_LEVEL_FAIL_INVALID_POS);
                return;
            }
            case SUCCESS:{
                break;
            }
            case MONEY_NOT_ENOUGH:{
                hc.sendMessage(ERR_UPGRADE_LEVEL_FAIL_MONEY_NOT_ENOUGH);
                return;
            }
            case REAL_AIR_NOT_ENOUGH:{
                hc.sendMessage(ERR_UPGRADE_LEVEL_FAIL_GOODS_NOT_ENOUGH);
                return;
            }
            default:{
                logger.error("装备提升等级，遇到未知的失败类型，{}", result);
                hc.sendMessage(ERR_UPGRADE_LEVEL_FAIL_GOODS_NOT_ENOUGH);
                return;
            }
        }

//        // 扣消耗的装备
//        goodsContainerModule.reduceGoodsListAnyway(equipmentPosCountList,
//                hc.getHero(), hc.getSender(), LEVEL_FORGE, 0, ctime);

        // 开始升级
        int upgradeTimes = equipment.incrementRefinedUpgradeTimes();
        if (!upgradeData.tryUpgrade(upgradeTimes)){
            // 失败
            hc.sendMessage(UPGRADE_LEVEL_FAIL_MSG);

            hc.getGoodsOwnership().changeIdentifier(oldIdentifier,
                    equipment.getGoodsIdentifier(), equipment.getCount(),
                    LEVEL_FORGE, ctime, equipment.needLog());

            logService.todo();
//            logService.writeOperateLog(LEVEL_FORGE, EQUIPMENT,
//                    equipment.getId(), 1, equipment.getRefinedTimes(),
//                    equipment.getIntQuality(), 0, hc.getHero());
            return;
        }

        // 成功
        Equipment newEquipment = equipment.newLevelEquipment();
        hc.getGoodsOwnership().changeIdentifier(oldIdentifier,
                newEquipment.getGoodsIdentifier(), newEquipment.getCount(),
                LEVEL_FORGE, ctime, newEquipment.needLog());

        UpgradeLevelData nextUpgradeLevelData = null;
        if (newEquipment.getNextLevelEquipment() != null){
            levelForgeGroup = newEquipmentData.getNextLevelEquipment()
                    .getLevelForgeGroup();
            if (levelForgeGroup != null){
                EquipmentForgeData nextForgeData = levelForgeGroup
                        .getForgeData(quality);
                if (nextForgeData != null){
                    nextUpgradeLevelData = getUpgradeLevelData(
                            newEquipmentData.getNextLevelEquipment(), statType,
                            quality, refinedTimes, nextForgeData);
                }
            }
        }

        // 成功消息
        hc.sendMessage(upgradeEquipmentLevelMsg(equipmentPos,
                nextUpgradeLevelData));

        // 更新装备
        replaceHeroEquipment(hc, equipmentPos, equipment, newEquipment, ctime);
//        if (isDepotPos){
//            hc.getDepot().set(realPos, newEquipment);
//        } else{
//            replaceHeroEquipment(hc, realPos, equipment, newEquipment, ctime);
//        }

        if (forgeData.isBroadcast()){
            // 提升等级成功广播
            worldService.broadcastToEnteredFirstSceneHeroWithSameServerData(
                    upgradeLevelBroadcastMsg(hc.getHero().getNameBytes(),
                            equipment.getData().nameBytes,
                            newEquipment.getData().nameBytes,
                            newEquipment.getIntQuality()), hc.getServerData(),
                    0);
        }

        logService.todo();
//        logService.writeOperateLog(LEVEL_FORGE, EQUIPMENT, equipment.getId(),
//                0, newEquipment.getRefinedTimes(),
//                newEquipment.getIntQuality(), newEquipment.getId(),
//                hc.getHero());
    }

    public void replaceHeroEquipment(HeroController hc, int realPos,
            Equipment toRemove, Equipment toAdd, long ctime){
        assert toRemove != null || toAdd != null: "替换装备方法调用必须有一个装备不是null";

        Hero hero = hc.getHero();
        Equipment[] list = hero.getEquipmentList();
        list[realPos] = toAdd;

        int equipType = 0;
        int toRemoveResource = 0;
        SpriteStat toRemoveStat = SpriteStat.EMPTY_STAT;
        TaozData toRemoteTaoz = null;
        if (toRemove != null){
            equipType = toRemove.getEquipType();
            toRemoveResource = toRemove.getData().getResource();
            toRemoveStat = toRemove.getTotalStat();
            toRemoteTaoz = toRemove.getData().getTaoz();
        }

        int toAddResource = 0;
        SpriteStat toAddStat = SpriteStat.EMPTY_STAT;
        TaozData toAddTaoz = null;
        if (toAdd != null){
            equipType = toAdd.getEquipType();
            toAddResource = toAdd.getData().getResource();
            toAddStat = toAdd.getTotalStat();
            toAddTaoz = toAdd.getData().getTaoz();
        }

        if (toRemoveResource != toAddResource){
            // 换装
            switch (equipType){
                case Equipment.EQUIPMENT_TYPE_WEAPON:{
                    hero.replaceEquipmentResources(ModelType.WEAPON,
                            toAddResource);

                    hc.heroFightModule.onEquipmentResourcesChanged();
                    break;
                }
                case Equipment.EQUIPMENT_TYPE_ARMOR:{
                    hero.replaceEquipmentResources(ModelType.ARMOR,
                            toAddResource);
                    hc.heroFightModule.onEquipmentResourcesChanged();
                    break;
                }
            }
        }

        // +10附加属性
        if (toAdd == null || toAdd.getIntQuality() < Quality.PURPLE_VALUE){
            // 如果原来有，直接移除
            EquipmentExtraStat oldExtraData = hero.clearEquipmentExtraStat();
            if (oldExtraData != null){
                toRemoveStat = toRemoveStat.add(oldExtraData.getTotalStat());
            }
        } else{
            EquipmentExtraStat oldExtraData = hero.getEquipmentExtraStat();

            EquipmentExtraStat newExtraData = hero
                    .checkEquipmentExtraStat(extraStats);

            if (oldExtraData != null){
                toRemoveStat = toRemoveStat.add(oldExtraData.getTotalStat());
            }

            if (newExtraData != null){
                toAddStat = toAddStat.add(newExtraData.getTotalStat());
            }
        }

        if (toRemoteTaoz != toAddTaoz){
            if (toRemoteTaoz != null){
                SpriteStat oldTaozStat = hero.getTaozStat(toRemoteTaoz.id);
                SpriteStat newTaozStat = hero.checkTaozStat(toRemoteTaoz,
                        oldTaozStat);

                if (oldTaozStat != newTaozStat){
                    if (oldTaozStat != null){
                        toRemoveStat = toRemoveStat.add(oldTaozStat);
                    }

                    if (newTaozStat != null){
                        toAddStat = toAddStat.add(newTaozStat);
                    }
                }
            }

            if (toAddTaoz != null){
                SpriteStat oldTaozStat = hero.getTaozStat(toAddTaoz.id);
                SpriteStat newTaozStat = hero.checkTaozStat(toAddTaoz,
                        oldTaozStat);

                if (oldTaozStat != newTaozStat){
                    if (oldTaozStat != null){
                        toRemoveStat = toRemoveStat.add(oldTaozStat);
                    }

                    if (newTaozStat != null){
                        toAddStat = toAddStat.add(newTaozStat);
                    }
                }
            }
        }

        hc.heroFightModule.changeBaseStat(toRemoveStat, toAddStat, ctime);

        // 更新战斗力
        hc.heroFightModule.updateFightingAmount();
    }

    private void processEquipmentMelting(HeroController hc, ChannelBuffer buffer){

        Hero hero = hc.getHero();
        if (!hero.isTaskFuncOpened(TaskRelatedFunction.FUNC_MELTING)){
            logger.warn("熔炼装备，功能未开放");
            hc.sendMessage(ERR_MELTING_FAIL_NOT_OPEN);
            return;
        }

        int pos = BufferUtil.readVarInt32(buffer);

        Depot depot = hc.getDepot();

        if (depot.isInvalidPos(pos)){
            logger.warn("熔炼装备，背包位置无效");
            hc.sendMessage(ERR_MELTING_FAIL_INVALID_POS);
            return;
        }

        if (depot.isLocked(pos)){
            logger.warn("熔炼装备，背包位置已被锁定");
            hc.sendMessage(ERR_MELTING_FAIL_INVALID_POS);
            return;
        }

        Goods g = depot.get(pos);
        if (!(g instanceof Equipment)){
            logger.warn("熔炼装备，背包物品不是装备");
            hc.sendMessage(ERR_MELTING_FAIL_INVALID_POS);
            return;
        }

        Equipment equipment = (Equipment) g;
        if (equipment.isUnmeltable()){
            logger.warn("熔炼装备，该装备不能熔炼");
            hc.sendMessage(ERR_MELTING_FAIL_CANT_MELT);
            return;
        }

        long ctime = timeService.getCurrentTime();

        GoodsOwnership ownership = hero.getGoodsOwnership();
        ownership.removeGoods(g.getGoodsIdentifier(), g.getCount(), MELT, 0,
                ctime, g.needLog());

        depot.remove(pos); // 将装备移除掉

        int toAdd = equipment.getMeltAmount();

        if (toAdd <= 0){
            hc.sendMessage(meltEquipmentMsg(pos, 0, hero.meltAmount));
            return;
        }

        int currentAmount = hero.meltAmount;
        if ((hero.meltAmount = hero.meltAmount + toAdd) < 0){
            hero.meltAmount = currentAmount; // 让他亏
        }

        String iEventId = logService.getEquipmentMeltingProcessor().newEventID(
                hc.getID());
        logService.getEquipmentMeltingProcessor().addLogEvent(
                hero.getOperatorId(), iEventId, hero.getServerId(),
                hero.getUin(), hero.getUserId(), hero.getName(),
                hero.meltAmount, toAdd, equipment.getId(),
                equipment.getData().name, equipment.getRefinedTimes(),
                equipment.getIntQuality(), equipment.getStatType().getNumber());

        if (hero.meltAmount >= furnaceData.getMeltMaxAmount()){

            // 有装备
            Goods newGoods = furnaceData.random(ctime, hero.getRaceId());
            hero.getGoodsOwnership().addGoods(newGoods.getGoodsIdentifier(),
                    newGoods.getCount(), MELT, 0, ctime, newGoods.needLog());
            depot.set(pos, newGoods);

            hero.meltAmount -= furnaceData.getMeltMaxAmount();

            int newRefinedTimes = 0;
            int newIntQuality = 0;
            int newStatType = 0;
            if (newGoods instanceof Equipment){
                Equipment newE = (Equipment) newGoods;
                newRefinedTimes = newE.getRefinedTimes();
                newIntQuality = newE.getIntQuality();
                newStatType = newE.getStatType().getNumber();
            }
            logService.getEquipmentMeltingProcessor().addLogEvent(
                    hero.getOperatorId(), iEventId, hero.getServerId(),
                    hero.getUin(), hero.getUserId(), hero.getName(),
                    hero.meltAmount, -furnaceData.getMeltMaxAmount(),
                    newGoods.getId(), newGoods.getData().name, newRefinedTimes,
                    newIntQuality, newStatType);

            hc.sendMessage(meltEquipmentMsg(pos, toAdd, hero.meltAmount,
                    newGoods));

            if (newGoods.getIntQuality() >= Quality.PURPLE_VALUE){
                // 紫色装备以上
                worldService.broadcast(meltingBroadcast(hero.getID(),
                        hero.getNameBytes(), newGoods.getIntQuality(),
                        newGoods.getData().nameBytes));
            }
        } else{
            hc.sendMessage(meltEquipmentMsg(pos, toAdd, hero.meltAmount));
        }
    }

    UpgradeLevelData getUpgradeLevelData(EquipmentData equipmentData,
            StatType statType, Quality quality, int refinedTimes,
            EquipmentForgeData forgeData){
        long identifier = equipmentData.getGoodsIdentifier(false,
                statType.getNumber(), quality.getNumber(), refinedTimes, 0);

        UpgradeLevelData data = levelForgeDataMap.get(identifier);
        if (data == null){
            EquipmentLevelForgeProto proto = equipmentData
                    .getLevelForgeProto(refinedTimes, quality, statType,
                            forgeData.getUpgradeData());

            if (proto == null){
                return null;
            }

            data = new UpgradeLevelData(identifier, proto);
            levelForgeDataMap.put(identifier, data);
        }

        return data;
    }

    static class UpgradeLevelData{
        final long identifier;

        transient final byte[] levelProtoData;

        transient final ChannelBuffer upgradeLevelMsg;

        private UpgradeLevelData(long identifier, EquipmentLevelForgeProto proto){
            this.identifier = identifier;

            levelProtoData = proto.toByteArray();
            upgradeLevelMsg = getUpgradeLevelDataMsg(proto);
        }

        public byte[] getUpgradeLevelData(){
            return levelProtoData;
        }

        public ChannelBuffer getUpgradeLevelMsg(){
            return upgradeLevelMsg;
        }
    }
}
