package app.game.module.dbrank;

import static app.game.module.dbrank.RankUtil.combineLevelAndFightAmount;
import static com.mokylin.sink.util.BufferUtil.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.data.ServerData;
import app.game.data.bow.HeroBow;
import app.game.data.mount.HeroMount;
import app.game.data.pet.HeroTianJie;
import app.game.data.pet.HeroTianZui;
import app.game.data.spell.PassiveSpell;
import app.game.entity.Hero;
import app.utils.VariableConfig;

import com.mokylin.sink.util.Empty;

public class DBRankObject{
    private static final Logger logger = LoggerFactory
            .getLogger(DBRankObject.class);

    private final DBRankQueue rankQueue;

    // --- 固定数据 ---
    public final long combineID;

    private final byte[] heroName;
    private final int race;
    private final int serverSequence;

    // --- 等级 ---
    private int level;
    private int levelReachSecond;

    // --- 坐骑 ---
    private int mount;
    private int mountFightAmount;
    private int mountReachSecond;
    private byte[] mountInfo;

    // --- 凤舞弓 ---
    private int bow;
    private int bowFightAmount;
    private int bowReachSecond;

    // --- 战斗力 ---
    private int fightAmount;

    // --- 天劫 ---
    private int tianjie;
    private int tianjieFightAmount;
    private int tianjieReachSecond;
    private byte[] tianjieInfo;

    // --- 天罪 ---
    private int tianzui;
    private int tianzuiFightAmount;
    private int tianzuiReachSecond;
    private byte[] tianzuiInfo;

    // --- 换装 ---
    private int res;

    /**
     * 当前是否已经到了最低上榜等级
     */
    private boolean isInRank;

    public DBRankObject(DBRankQueue rankQueue, Hero hero, ServerData serverData){
        this.rankQueue = rankQueue;

        this.combineID = hero.getID();
        this.heroName = hero.getNameBytes();
        this.race = hero.getRaceId();
        this.serverSequence = serverData.sequence;

        updateLevel(hero);
        updateMount(hero);
        updateFightAmount(hero);
        updateRes(hero);
        updateBow(hero);
        updateTianjie(hero);
        updateTianzui(hero);

        isInRank = hero.getLevel() >= VariableConfig.RANK_MIN_LEVEL_ON_RANK;
    }

    public void onBowUpdate(Hero hero){
        updateBow(hero);

        onUpdated();
    }

    public void onFightAmountUpdate(Hero hero){
        updateFightAmount(hero);

        onUpdated();
    }

    public void onResUpdate(Hero hero){
        if (updateRes(hero)){
            onUpdated();
        }
    }

    public void onMountUpdate(Hero hero){
        updateMount(hero);

        onUpdated();
    }

    public void onLevelUpdate(Hero hero){
        updateLevel(hero);
        updateFightAmount(hero);

        if (isInRank){
            rankQueue.update(this);
        } else{
            // 之前不在榜上, 看下现在上榜了吗
            isInRank = hero.getLevel() >= VariableConfig.RANK_MIN_LEVEL_ON_RANK;

            if (isInRank){
                logger.debug("新上榜: {}", combineID);
                rankQueue.add(this);
            }
        }
    }

    public void onTianjieUpdate(Hero hero){
        updateTianjie(hero);
        updateFightAmount(hero);

        onUpdated();
    }

    public void onTianzuiUpdate(Hero hero){
        updateTianzui(hero);
        updateFightAmount(hero);

        onUpdated();
    }

    // --- 私有方法 ---
    private void onUpdated(){
        if (isInRank){
            rankQueue.update(this);
        }
    }

    private void updateBow(Hero hero){
        HeroBow b = hero.getBow();
        if (b != null){
            this.bow = b.getBowId();
            this.bowFightAmount = b.getFightingAmount();
            this.bowReachSecond = b.getBowUpdateTime();
        }
    }

    private void updateTianjie(Hero hero){
        HeroTianJie b = hero.getTianJie();
        if (b != null){
            int id = b.getId();
            this.tianjie = id;
            this.tianjieFightAmount = b.getFightingAmount();
            this.tianjieReachSecond = b.getUpgradeTime();

            // --- 预先准备好要写给客户端的信息 ---
            int len = 0;
            int spellBits = 0;
            PassiveSpell[] ps = b.getSpellList();
            PassiveSpell p;
            for (int i = 0; i < ps.length; i++){
                p = ps[i];
                if (p != null){
                    spellBits |= (1 << i);
                    len += computeVarInt32Size(p.spellType);
                }
            }
            int combineIDSpellBits = id | (spellBits << 4);
            len += computeVarInt32Size(combineIDSpellBits);

            byte[] info = new byte[len];
            int index = 0;
            index = writeVarInt32(info, index, combineIDSpellBits);

            for (int i = 0; i < ps.length; i++){
                p = ps[i];
                if (p != null){
                    index = writeVarInt32(info, index, p.spellType);
                }
            }

            tianjieInfo = info;
        } else{
            tianjieInfo = Empty.BYTE_ARRAY;
        }
    }

    private void updateTianzui(Hero hero){
        HeroTianZui b = hero.getTianZui();
        if (b != null){
            int id = b.getId();
            this.tianzui = id;
            this.tianzuiFightAmount = b.getFightingAmount();
            this.tianzuiReachSecond = b.getUpgradeTime();

            // --- 预先准备好要写给客户端的信息 ---
            int len = 0;
            int spellBits = 0;
            PassiveSpell[] ps = b.getSpellList();
            PassiveSpell p;
            for (int i = 0; i < ps.length; i++){
                p = ps[i];
                if (p != null){
                    spellBits |= (1 << i);
                    len += computeVarInt32Size(p.spellType);
                }
            }
            int combineIDSpellBits = id | (spellBits << 4);
            len += computeVarInt32Size(combineIDSpellBits);

            byte[] info = new byte[len];
            int index = 0;
            index = writeVarInt32(info, index, combineIDSpellBits);

            for (int i = 0; i < ps.length; i++){
                p = ps[i];
                if (p != null){
                    index = writeVarInt32(info, index, p.spellType);
                }
            }

            tianzuiInfo = info;
        } else{
            tianzuiInfo = Empty.BYTE_ARRAY;
        }
    }

    /**
     * 返回是否有变化
     * @param hero
     * @return
     */
    private boolean updateRes(Hero hero){
        int newRes = hero.getModel().getResourceWithBestMountBow();
        if (newRes == res){
            return false;
        }

        res = newRes;
        return true;
    }

    private void updateFightAmount(Hero hero){
        this.fightAmount = hero.getFightingAmount();
    }

    private void updateLevel(Hero hero){
        this.level = hero.getLevel();
        this.levelReachSecond = hero.getLevelUpdateTime();
    }

    private void updateMount(Hero hero){
        HeroMount m = hero.getMount();
        if (m != null){
            mount = m.getBestMountId();
            mountFightAmount = m.getBestMountFightingAmount();
            mountReachSecond = m.getMountUpdateTime();

            // --- 预先准备好要写给客户端的信息 ---
            int len = 0;
            int mountSpellBits = 0;
            PassiveSpell[] ps = m.getSpellList();
            PassiveSpell p;
            for (int i = 0; i < ps.length; i++){
                p = ps[i];
                if (p != null){
                    mountSpellBits |= (1 << i);
                    len += computeVarInt32Size(p.spellType);
                }
            }
            int mountIDCombineSpellBits = mount | (mountSpellBits << 4);
            len += computeVarInt32Size(mountIDCombineSpellBits);

            byte[] info = new byte[len];
            int index = 0;
            index = writeVarInt32(info, index, mountIDCombineSpellBits);

            for (int i = 0; i < ps.length; i++){
                p = ps[i];
                if (p != null){
                    index = writeVarInt32(info, index, p.spellType);
                }
            }
            this.mountInfo = info;
        } else{
            this.mountInfo = Empty.BYTE_ARRAY;
        }
    }

    // --- getter ---

    public long getCombineID(){
        return combineID;
    }

    public byte[] getHeroName(){
        return heroName;
    }

    public int getRace(){
        return race;
    }

    public int getServerSequence(){
        return serverSequence;
    }

    public int getLevel(){
        return level;
    }

    public int getLevelReachSecond(){
        return levelReachSecond;
    }

    public int getFightAmount(){
        return fightAmount;
    }

    public int getRes(){
        return res;
    }

    // --- 坐骑 ---

    public int getMountReachSecond(){
        return mountReachSecond;
    }

    public int combineMountLevelAndFightAmount(){
        return combineLevelAndFightAmount(mount, mountFightAmount);
    }

    public byte[] getMountInfo(){
        return mountInfo;
    }

    // --- bow 天劫 ---

    public int combineBowLevelAndFightAmount(){
        return combineLevelAndFightAmount(bow, bowFightAmount);
    }

    public int getBowReachSecond(){
        return bowReachSecond;
    }

    // --- 天罪 ---

    public int combineTianzuiLevelAndFightAmount(){
        return combineLevelAndFightAmount(tianzui, tianzuiFightAmount);
    }

    public int getTianzuiReachSecond(){
        return tianzuiReachSecond;
    }

    public byte[] getTianzuiInfo(){
        return tianzuiInfo;
    }

    // --- 战甲 ---

    public int combineTianjieLevelAndFightAmount(){
        return combineLevelAndFightAmount(tianjie, tianjieFightAmount);
    }

    public int getTianjieReachSecond(){
        return tianjieReachSecond;
    }

    public byte[] getTianjieInfo(){
        return tianjieInfo;
    }

    // ---
}
