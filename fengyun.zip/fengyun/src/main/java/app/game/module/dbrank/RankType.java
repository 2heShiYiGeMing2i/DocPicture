package app.game.module.dbrank;

import static com.mokylin.sink.util.BufferUtil.*;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.module.guild.GuildMember;
import app.game.module.guild.GuildModule;
import app.utils.VariableConfig;

import com.mokylin.sink.util.Empty;

public enum RankType{
    /**
     * 等级
     */
    LEVEL {
        private final String SELECT_SQL_WITHOUT_SERVER_SEQUENCE = SHARED_SELECT_SQL
                + ", level, res from rank where level_rank_all > 0 order by level_rank_all asc limit ?,"
                + VariableConfig.RANK_PER_PAGE;

        private final String SELECT_SQL_WITH_SERVER_SEQUENCE = SHARED_SELECT_SQL
                + ", level, res from rank where server_sequence=? and level_rank > 0 order by level_rank asc limit ?,"
                + VariableConfig.RANK_PER_PAGE;

        @Override
        public String getSelectSql(boolean hasServerSequence){
            return hasServerSequence ? SELECT_SQL_WITH_SERVER_SEQUENCE
                    : SELECT_SQL_WITHOUT_SERVER_SEQUENCE;
        }

        // ---
        @Override
        public void writeResult(ResultSet rs, ChannelBuffer buffer,
                GuildModule guildModule) throws SQLException{
            writeSharedResult(rs, buffer, guildModule);
            int level = rs.getInt(5);
            int res = rs.getInt(6);

            writeVarInt32(buffer, level);
            writeVarInt32(buffer, res);
        }

        // ---
        private final String SELF_RANK_SQL_WITHOUT_SERVER_SEQUENCE = "select level_rank_all from rank where combine_id=?";
        private final String SELF_RANK_SQL_WITH_SERVER_SEQUENCE = "select level_rank from rank where combine_id=?";

        @Override
        public String getSelfRankSql(boolean hasServerSequence){
            return hasServerSequence ? SELF_RANK_SQL_WITH_SERVER_SEQUENCE
                    : SELF_RANK_SQL_WITHOUT_SERVER_SEQUENCE;
        }

        // ---  search ---

        private final String SEARCH_RANK_SQL_WITHOUT_SERVER_SEQUENCE = SHARED_SELECT_SQL
                + ", level, res, level_rank_all from rank where level_rank_all > ? and name like ? order by level_rank_all asc limit "
                + VariableConfig.RANK_PER_PAGE;

        private final String SEARCH_RANK_SQL_WITH_SERVER_SEQUENCE = SHARED_SELECT_SQL
                + ", level, res, level_rank from rank where level_rank > ? and server_sequence=? and name like ? order by level_rank asc limit "
                + VariableConfig.RANK_PER_PAGE;

        @Override
        public String getSearchRankSql(boolean hasServerSequence){
            return hasServerSequence ? SEARCH_RANK_SQL_WITH_SERVER_SEQUENCE
                    : SEARCH_RANK_SQL_WITHOUT_SERVER_SEQUENCE;
        }

        @Override
        public void writeSearchRank(ResultSet rs, ChannelBuffer buffer)
                throws SQLException{
            int rank = rs.getInt(7);
            writeVarInt32(buffer, rank);
        }
    },

    /**
     * 战斗力
     */
    FIGHT_AMOUNT {

        private final String SELECT_SQL_WITHOUT_SERVER_SEQUENCE = SHARED_SELECT_SQL
                + ", fight_amount, res from rank where fight_amount_rank_all > 0 order by fight_amount_rank_all asc limit ?,"
                + VariableConfig.RANK_PER_PAGE;

        private final String SELECT_SQL_WITH_SERVER_SEQUENCE = SHARED_SELECT_SQL
                + ", fight_amount, res from rank where server_sequence=? and fight_amount_rank > 0 order by fight_amount_rank asc limit ?,"
                + VariableConfig.RANK_PER_PAGE;

        @Override
        public String getSelectSql(boolean hasServerSequence){
            return hasServerSequence ? SELECT_SQL_WITH_SERVER_SEQUENCE
                    : SELECT_SQL_WITHOUT_SERVER_SEQUENCE;
        }

        // ---
        @Override
        public void writeResult(ResultSet rs, ChannelBuffer buffer,
                GuildModule guildModule) throws SQLException{
            writeSharedResult(rs, buffer, guildModule);
            int fightAmount = rs.getInt(5);
            int res = rs.getInt(6);
            writeVarInt32(buffer, fightAmount);
            writeVarInt32(buffer, res);
        }

        // ---

        private final String SELF_RANK_SQL_WITHOUT_SERVER_SEQUENCE = "select fight_amount_rank_all from rank where combine_id=?";
        private final String SELF_RANK_SQL_WITH_SERVER_SEQUENCE = "select fight_amount_rank from rank where combine_id=?";

        @Override
        public String getSelfRankSql(boolean hasServerSequence){
            return hasServerSequence ? SELF_RANK_SQL_WITH_SERVER_SEQUENCE
                    : SELF_RANK_SQL_WITHOUT_SERVER_SEQUENCE;
        }

        // --- search

        private final String SEARCH_RANK_SQL_WITHOUT_SERVER_SEQUENCE = SHARED_SELECT_SQL
                + ", fight_amount, res, fight_amount_rank_all from rank where fight_amount_rank_all > ? and name like ? order by fight_amount_rank_all asc limit "
                + VariableConfig.RANK_PER_PAGE;

        private final String SEARCH_RANK_SQL_WITH_SERVER_SEQUENCE = SHARED_SELECT_SQL
                + ", fight_amount, res, fight_amount_rank from rank where fight_amount_rank > ? and server_sequence=? and name like ? order by fight_amount_rank asc limit "
                + VariableConfig.RANK_PER_PAGE;

        @Override
        public String getSearchRankSql(boolean hasServerSequence){
            return hasServerSequence ? SEARCH_RANK_SQL_WITH_SERVER_SEQUENCE
                    : SEARCH_RANK_SQL_WITHOUT_SERVER_SEQUENCE;
        }

        @Override
        public void writeSearchRank(ResultSet rs, ChannelBuffer buffer)
                throws SQLException{
            int rank = rs.getInt(7);
            writeVarInt32(buffer, rank);
        }
    },

    /**
     * 坐骑
     */
    MOUNT {

        private final String SELECT_SQL_WITHOUT_SERVER_SEQUENCE = SHARED_SELECT_SQL
                + ", mount_info from rank where mount_rank_all > 0 order by mount_rank_all asc limit ?,"
                + VariableConfig.RANK_PER_PAGE;
        private final String SELECT_SQL_WITH_SERVER_SEQUENCE = SHARED_SELECT_SQL
                + ", mount_info from rank where server_sequence=? and mount_rank>0 order by mount_rank asc limit ?,"
                + VariableConfig.RANK_PER_PAGE;

        @Override
        public String getSelectSql(boolean hasServerSequence){
            return hasServerSequence ? SELECT_SQL_WITH_SERVER_SEQUENCE
                    : SELECT_SQL_WITHOUT_SERVER_SEQUENCE;
        }

        // ---
        @Override
        public void writeResult(ResultSet rs, ChannelBuffer buffer,
                GuildModule guildModule) throws SQLException{
            writeSharedResult(rs, buffer, guildModule);
            byte[] mountInfo = rs.getBytes(5);
            buffer.writeBytes(mountInfo);
        }

        // ---
        private final String SELF_RANK_SQL_WITHOUT_SERVER_SEQUENCE = "select mount_rank_all from rank where combine_id=?";
        private final String SELF_RANK_SQL_WITH_SERVER_SEQUENCE = "select mount_rank from rank where combine_id=?";

        @Override
        public String getSelfRankSql(boolean hasServerSequence){
            return hasServerSequence ? SELF_RANK_SQL_WITH_SERVER_SEQUENCE
                    : SELF_RANK_SQL_WITHOUT_SERVER_SEQUENCE;
        }

        // --- search

        private final String SEARCH_RANK_SQL_WITHOUT_SERVER_SEQUENCE = SHARED_SELECT_SQL
                + ", mount_info, mount_rank_all from rank where mount_rank_all > ? and name like ? order by mount_rank_all asc limit "
                + VariableConfig.RANK_PER_PAGE;

        private final String SEARCH_RANK_SQL_WITH_SERVER_SEQUENCE = SHARED_SELECT_SQL
                + ", mount_info, mount_rank from rank where mount_rank > ? and server_sequence=? and name like ? order by mount_rank asc limit "
                + VariableConfig.RANK_PER_PAGE;

        @Override
        public String getSearchRankSql(boolean hasServerSequence){
            return hasServerSequence ? SEARCH_RANK_SQL_WITH_SERVER_SEQUENCE
                    : SEARCH_RANK_SQL_WITHOUT_SERVER_SEQUENCE;
        }

        @Override
        public void writeSearchRank(ResultSet rs, ChannelBuffer buffer)
                throws SQLException{
            int rank = rs.getInt(6);
            writeVarInt32(buffer, rank);
        }
    },

    /**
     * 凤舞弓
     */
    BOW {

        private final String SELECT_SQL_WITHOUT_SERVER_SEQUENCE = SHARED_SELECT_SQL
                + ", bow from rank where bow_rank_all>0 order by bow_rank_all asc limit ?,"
                + VariableConfig.RANK_PER_PAGE;
        private final String SELECT_SQL_WITH_SERVER_SEQUENCE = SHARED_SELECT_SQL
                + ", bow from rank where server_sequence=? and bow_rank>0 order by bow_rank asc limit ?,"
                + VariableConfig.RANK_PER_PAGE;

        @Override
        public String getSelectSql(boolean hasServerSequence){
            return hasServerSequence ? SELECT_SQL_WITH_SERVER_SEQUENCE
                    : SELECT_SQL_WITHOUT_SERVER_SEQUENCE;
        }

        // ---
        @Override
        public void writeResult(ResultSet rs, ChannelBuffer buffer,
                GuildModule guildModule) throws SQLException{
            writeSharedResult(rs, buffer, guildModule);
            int bowCombined = rs.getInt(5);
            int bow = RankUtil.getLevel(bowCombined);
            writeVarInt32(buffer, bow);
        }

        // ---
        private final String SELF_RANK_SQL_WITHOUT_SERVER_SEQUENCE = "select bow_rank_all from rank where combine_id=?";
        private final String SELF_RANK_SQL_WITH_SERVER_SEQUENCE = "select bow_rank from rank where combine_id=?";

        @Override
        public String getSelfRankSql(boolean hasServerSequence){
            return hasServerSequence ? SELF_RANK_SQL_WITH_SERVER_SEQUENCE
                    : SELF_RANK_SQL_WITHOUT_SERVER_SEQUENCE;
        }

        // --- search

        private final String SEARCH_RANK_SQL_WITHOUT_SERVER_SEQUENCE = SHARED_SELECT_SQL
                + ", bow, bow_rank_all from rank where bow_rank_all>? and name like ? order by bow_rank_all asc limit "
                + VariableConfig.RANK_PER_PAGE;

        private final String SEARCH_RANK_SQL_WITH_SERVER_SEQUENCE = SHARED_SELECT_SQL
                + ", bow, bow_rank from rank where bow_rank>? and server_sequence=? and name like ? order by bow_rank asc limit "
                + VariableConfig.RANK_PER_PAGE;

        @Override
        public String getSearchRankSql(boolean hasServerSequence){
            return hasServerSequence ? SEARCH_RANK_SQL_WITH_SERVER_SEQUENCE
                    : SEARCH_RANK_SQL_WITHOUT_SERVER_SEQUENCE;
        }

        @Override
        public void writeSearchRank(ResultSet rs, ChannelBuffer buffer)
                throws SQLException{
            int rank = rs.getInt(6);
            writeVarInt32(buffer, rank);
        }
    },

    /**
     * 崇拜
     */
    ADMIRE {

        private final String SELECT_SQL_WITHOUT_SERVER_SEQUENCE = SHARED_SELECT_SQL
                + ", res from rank where admire_rank_all>0 order by admire_rank_all asc limit ?,"
                + VariableConfig.RANK_PER_PAGE;

        private final String SELECT_SQL_WITH_SERVER_SEQUENCE = SHARED_SELECT_SQL
                + ", res from rank where server_sequence=? and admire_rank>0 order by admire_rank asc limit ?,"
                + VariableConfig.RANK_PER_PAGE;

        @Override
        public String getSelectSql(boolean hasServerSequence){
            return hasServerSequence ? SELECT_SQL_WITH_SERVER_SEQUENCE
                    : SELECT_SQL_WITHOUT_SERVER_SEQUENCE;
        }

        // ---
        @Override
        public void writeResult(ResultSet rs, ChannelBuffer buffer,
                GuildModule guildModule) throws SQLException{
            writeSharedResult(rs, buffer, guildModule);
            int res = rs.getInt(5);
            writeVarInt32(buffer, res);
        }

        // ---
        private final String SELF_RANK_SQL_WITHOUT_SERVER_SEQUENCE = "select admire_rank_all from rank where combine_id=?";
        private final String SELF_RANK_SQL_WITH_SERVER_SEQUENCE = "select admire_rank from rank where combine_id=?";

        @Override
        public String getSelfRankSql(boolean hasServerSequence){
            return hasServerSequence ? SELF_RANK_SQL_WITH_SERVER_SEQUENCE
                    : SELF_RANK_SQL_WITHOUT_SERVER_SEQUENCE;
        }

        // --- search

        private final String SEARCH_RANK_SQL_WITHOUT_SERVER_SEQUENCE = SHARED_SELECT_SQL
                + ", res, admire_rank_all from rank where admire_rank_all > ? and name like ? order by admire_rank_all asc limit "
                + VariableConfig.RANK_PER_PAGE;
        private final String SEARCH_RANK_SQL_WITH_SERVER_SEQUENCE = SHARED_SELECT_SQL
                + ", res, admire_rank from rank where admire_rank>? and server_sequence=? and name like ? order by admire_rank asc limit "
                + VariableConfig.RANK_PER_PAGE;

        @Override
        public String getSearchRankSql(boolean hasServerSequence){
            return hasServerSequence ? SEARCH_RANK_SQL_WITH_SERVER_SEQUENCE
                    : SEARCH_RANK_SQL_WITHOUT_SERVER_SEQUENCE;
        }

        @Override
        public void writeSearchRank(ResultSet rs, ChannelBuffer buffer)
                throws SQLException{
            int rank = rs.getInt(6);
            writeVarInt32(buffer, rank);
        }
    },
    /**
     * 天罪
     */
    TIAN_ZUI {

        private final String SELECT_SQL_WITHOUT_SERVER_SEQUENCE = SHARED_SELECT_SQL
                + ", tianzui_info from rank where tianzui_rank_all>0 order by tianzui_rank_all asc limit ?,"
                + VariableConfig.RANK_PER_PAGE;
        private final String SELECT_SQL_WITH_SERVER_SEQUENCE = SHARED_SELECT_SQL
                + ", tianzui_info from rank where tianzui_rank>0 and server_sequence=? order by tianzui_rank asc limit ?,"
                + VariableConfig.RANK_PER_PAGE;

        @Override
        public String getSelectSql(boolean hasServerSequence){
            return hasServerSequence ? SELECT_SQL_WITH_SERVER_SEQUENCE
                    : SELECT_SQL_WITHOUT_SERVER_SEQUENCE;
        }

        // ---
        @Override
        public void writeResult(ResultSet rs, ChannelBuffer buffer,
                GuildModule guildModule) throws SQLException{
            writeSharedResult(rs, buffer, guildModule);
            byte[] info = rs.getBytes(5);
            buffer.writeBytes(info);
        }

        // ---
        private final String SELF_RANK_SQL_WITHOUT_SERVER_SEQUENCE = "select tianzui_rank_all from rank where combine_id=?";
        private final String SELF_RANK_SQL_WITH_SERVER_SEQUENCE = "select tianzui_rank from rank where combine_id=?";

        @Override
        public String getSelfRankSql(boolean hasServerSequence){
            return hasServerSequence ? SELF_RANK_SQL_WITH_SERVER_SEQUENCE
                    : SELF_RANK_SQL_WITHOUT_SERVER_SEQUENCE;
        }

        // --- search

        private final String SEARCH_RANK_SQL_WITHOUT_SERVER_SEQUENCE = SHARED_SELECT_SQL
                + ", tianzui_info, tianzui_rank_all from rank where tianzui_rank_all>? and name like ? order by tianzui_rank_all asc limit "
                + VariableConfig.RANK_PER_PAGE;

        private final String SEARCH_RANK_SQL_WITH_SERVER_SEQUENCE = SHARED_SELECT_SQL
                + ", tianzui_info, tianzui_rank from rank where tianzui_rank>? and server_sequence=? and name like ? order by tianzui_rank asc limit "
                + VariableConfig.RANK_PER_PAGE;

        @Override
        public String getSearchRankSql(boolean hasServerSequence){
            return hasServerSequence ? SEARCH_RANK_SQL_WITH_SERVER_SEQUENCE
                    : SEARCH_RANK_SQL_WITHOUT_SERVER_SEQUENCE;
        }

        @Override
        public void writeSearchRank(ResultSet rs, ChannelBuffer buffer)
                throws SQLException{
            int rank = rs.getInt(6);
            writeVarInt32(buffer, rank);
        }
    },
    /**
     * 天劫(战甲)
     */
    TIAN_JIE {

        private final String SELECT_SQL_WITHOUT_SERVER_SEQUENCE = SHARED_SELECT_SQL
                + ", tianjie_info from rank where tianjie_rank_all>0 order by tianjie_rank_all asc limit ?,"
                + VariableConfig.RANK_PER_PAGE;
        private final String SELECT_SQL_WITH_SERVER_SEQUENCE = SHARED_SELECT_SQL
                + ", tianjie_info from rank where tianjie_rank>0 and server_sequence=? order by tianjie_rank asc limit ?,"
                + VariableConfig.RANK_PER_PAGE;

        @Override
        public String getSelectSql(boolean hasServerSequence){
            return hasServerSequence ? SELECT_SQL_WITH_SERVER_SEQUENCE
                    : SELECT_SQL_WITHOUT_SERVER_SEQUENCE;
        }

        // ---
        @Override
        public void writeResult(ResultSet rs, ChannelBuffer buffer,
                GuildModule guildModule) throws SQLException{
            writeSharedResult(rs, buffer, guildModule);
            byte[] info = rs.getBytes(5);
            buffer.writeBytes(info);
        }

        // ---
        private final String SELF_RANK_SQL_WITHOUT_SERVER_SEQUENCE = "select tianjie_rank_all from rank where combine_id=?";
        private final String SELF_RANK_SQL_WITH_SERVER_SEQUENCE = "select tianjie_rank from rank where combine_id=?";

        @Override
        public String getSelfRankSql(boolean hasServerSequence){
            return hasServerSequence ? SELF_RANK_SQL_WITH_SERVER_SEQUENCE
                    : SELF_RANK_SQL_WITHOUT_SERVER_SEQUENCE;
        }

        // --- search

        private final String SEARCH_RANK_SQL_WITHOUT_SERVER_SEQUENCE = SHARED_SELECT_SQL
                + ", tianjie_info, tianjie_rank_all from rank where tianjie_rank_all>? and name like ? order by tianjie_rank_all asc limit "
                + VariableConfig.RANK_PER_PAGE;

        private final String SEARCH_RANK_SQL_WITH_SERVER_SEQUENCE = SHARED_SELECT_SQL
                + ", tianjie_info, tianjie_rank from rank where tianjie_rank>? and server_sequence=? and name like ? order by tianjie_rank asc limit "
                + VariableConfig.RANK_PER_PAGE;

        @Override
        public String getSearchRankSql(boolean hasServerSequence){
            return hasServerSequence ? SEARCH_RANK_SQL_WITH_SERVER_SEQUENCE
                    : SEARCH_RANK_SQL_WITHOUT_SERVER_SEQUENCE;
        }

        @Override
        public void writeSearchRank(ResultSet rs, ChannelBuffer buffer)
                throws SQLException{
            int rank = rs.getInt(6);
            writeVarInt32(buffer, rank);
        }
    };

    public static final String SHARED_SELECT_SQL = "select combine_id, name, race, admire";

    protected void writeSharedResult(ResultSet rs, ChannelBuffer buffer,
            GuildModule guildModule) throws SQLException{
        long id = rs.getLong(1);
        byte[] name = rs.getBytes(2);
        int race = rs.getInt(3);
        int admire = rs.getInt(4);

        GuildMember gm = guildModule.getGuildMember(id);
        byte[] guildName = gm == null ? Empty.BYTE_ARRAY : gm.getGuildName();
        writeVarInt64(buffer, id);
        writeVarUTF(buffer, name);
        writeVarUTF(buffer, guildName);
        writeVarInt32(buffer, (admire << 3) | race);
    }

    public abstract String getSelectSql(boolean hasServerSequence);

    public abstract void writeResult(ResultSet rs, ChannelBuffer buffer,
            GuildModule guildModule) throws SQLException;

    /**
     * 只写排名
     * @param rs
     * @param buffer
     * @param guildModule
     * @throws SQLException
     */
    public abstract void writeSearchRank(ResultSet rs, ChannelBuffer buffer)
            throws SQLException;

    public abstract String getSelfRankSql(boolean hasServerSequence);

    /**
     * 有serverSequence 1. serverSequence, 2. name, 3. startIndex
     * 没有 1. name, 2. startIndex
     * @param hasServerSequence
     * @return
     */
    public abstract String getSearchRankSql(boolean hasServerSequence);
}
