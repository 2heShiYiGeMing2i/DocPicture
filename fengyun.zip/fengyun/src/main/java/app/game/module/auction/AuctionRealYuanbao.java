package app.game.module.auction;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.module.GoodsContainerModule;
import app.game.module.HeroController;
import app.protobuf.GoodsServerContent.GoodsType;
import app.protobuf.LogContent.LogEnum.OperateType;

import com.mokylin.sink.util.BufferUtil;

class AuctionRealYuanbao extends AuctionRealItem{

    private static final int GOODS_TYPE = GoodsType.YUANBAO_GOODS.getNumber();

    private static final int GOODS_TYPE_VARINT32_LEN = BufferUtil
            .computeVarInt32Size(GOODS_TYPE);

    final int amount;

    AuctionRealYuanbao(int amount, int cost, long sellerID,
            byte[] sellerNameBytes){
        super(sellerID, sellerNameBytes, cost);

        this.amount = amount;
    }

    @Override
    int getItemId(){
        return GOODS_TYPE;
    }

    @Override
    String getItemName(){
        return GoodsType.YUANBAO_GOODS.name();
    }

    @Override
    int getItemCount(){
        return amount;
    }

    @Override
    boolean canHold(HeroController hc, boolean ifYuanbaoReduceTax){
        if (ifYuanbaoReduceTax){
            return hc.getHeroMiscModule().canAddYuanbao(
                    amount - calculateTax(amount));
        }
        return hc.getHeroMiscModule().canAddYuanbao(amount);
    }

    @Override
    void doGive(HeroController hc, GoodsContainerModule goodsContainerModule,
            boolean ifYuanbaoReduceTax, OperateType type, String iEventId,
            long ctime){
        if (ifYuanbaoReduceTax){
            hc.getHeroMiscModule().addYuanbaoAnyway(
                    amount - calculateTax(amount), type, iEventId);
        } else{
            hc.getHeroMiscModule().addYuanbaoAnyway(amount, type, iEventId);
        }
    }

    @Override
    void writeGoods(ChannelBuffer buffer, boolean isYuanbaoReduceTax){
        BufferUtil.writeVarInt32(
                buffer,
                GOODS_TYPE_VARINT32_LEN
                        + BufferUtil.computeVarInt32Size(amount));
        BufferUtil.writeVarInt32(buffer, GOODS_TYPE);
        BufferUtil.writeVarInt32(buffer,
                isYuanbaoReduceTax ? (amount - calculateTax(amount)) : amount);
    }

    @Override
    AuctionLog toAuctionLog(long buyerID, byte[] buyerName, long time,
            int collectableExp){
        return new AuctionLog(time, sellerHeroID, sellerNameBytes, buyerID,
                buyerName, cost, sellerCollectableMoney(),
                sellerCollectableYuanbao(), collectableExp, 99, null, null,
                amount);
    }

    @Override
    int sellerCollectableMoney(){
        return cost;
    }

    @Override
    int sellerCollectableYuanbao(){
        return 0;
    }

    @Override
    int sellerCollectableConcurrency(){
        return sellerCollectableMoney();
    }

    @Override
    int sellerTax(){
        return 0;
    }

    @Override
    int buyerTax(){
        return calculateTax(amount);
    }

}
