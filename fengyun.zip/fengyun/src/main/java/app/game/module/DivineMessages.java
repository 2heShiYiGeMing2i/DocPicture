package app.game.module;

import static com.mokylin.sink.util.BufferUtil.newDynamicMessage;
import static com.mokylin.sink.util.BufferUtil.newFixedSizeMessage;
import static com.mokylin.sink.util.BufferUtil.onlySendHeadAndAByteMessage;
import static com.mokylin.sink.util.BufferUtil.onlySendHeaderMessage;

import java.util.Deque;
import java.util.List;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.data.divine.DivineGlobalLogs;
import app.game.data.goods.Goods;
import app.game.data.goods.GoodsShowData;

import com.mokylin.collection.IntArrayList;
import com.mokylin.sink.util.BufferUtil;

/**
 * @author Liwei
 *
 */
public class DivineMessages{

    public static final int MODULE_ID = Modules.DIVINE_MODULE_ID;

    /**
     * 知天命，附带
     * varint32 知天命次数
     * varint32 进阶类型 0-全物品，1-物品不够礼金购买，2-物品不够元宝购买
     * while(byteArray.available)
     *     varint32 火猴精血背包位置
     *     varint32 个数
     */
    static final int C2S_DIVINE_TRY = 0;

    /**
     * 知天命成功，附带
     * varint32 最新的吉运值
     * varint32 方位，1-生门，2-惊门，3-开门，4-杜门，5-休门，6-伤门，7-景门，8-死门
     * varint64 time
     * while(byteArray.available)
     *     varint32 物品静态属性长度
     *     bytes 物品静态属性
     *     varint32 物品动态属性
     *     bytes 物品动态属性
     *     
     * 在英雄知天命日志中加入本条信息（加入头部），如果超过日志最大条数，将最早的那条数据顶掉（最底部的数据）
     * (如果收到这个消息时，英雄知天命日志还没有初始化，不用管，因为当获取英雄知天命日志时，会将最新的日志下发)
     */
    static final int S2C_DIVINE_TRY = 1;

    /**
     * 知天命失败，附带Byte错误码
     * 1、知天命次数无效
     * 2、今日剩余知天命次数不足
     * 3、火猴精血位置或者个数错误
     * 4、仓库已满
     * 5、元宝不足
     * 6、火猴精血不足，但是没有选择元宝购买
     * 7、银两不足
     */
    static final int S2C_DIVINE_TRY_FAIL = 2;

    static final ChannelBuffer ERR_DIVINE_TRY_FAIL_DIVINE_TIMES_INVALID = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_DIVINE_TRY_FAIL, 1);

    static final ChannelBuffer ERR_DIVINE_TRY_FAIL_DIVINE_TIMES_NOT_ENOUGH = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_DIVINE_TRY_FAIL, 2);

    static final ChannelBuffer ERR_DIVINE_TRY_FAIL_POS_COUNT_INVALID = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_DIVINE_TRY_FAIL, 3);

    static final ChannelBuffer ERR_DIVINE_TRY_FAIL_STORAGE_FULL = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_DIVINE_TRY_FAIL, 4);

    static final ChannelBuffer ERR_DIVINE_TRY_FAIL_YUANBAO_NOT_ENOUGH = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_DIVINE_TRY_FAIL, 5);

    static final ChannelBuffer ERR_DIVINE_TRY_FAIL_GOODS_NOT_ENOUGH = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_DIVINE_TRY_FAIL, 6);

    static final ChannelBuffer ERR_DIVINE_TRY_FAIL_MONEY_NOT_ENOUGH = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_DIVINE_TRY_FAIL, 7);

    /**
     * 获取知天命仓库数据，没有附带数据
     * 
     * 在第一次打开仓库时请求（每次登陆期间只能请求一次）
     */
    static final int C2S_DIVINE_STORAGE = 3;

    /**
     * 知天命仓库数据
     * 
     * while(byteArray.available)
     *     varint32 物品静态属性长度
     *     bytes 物品静态属性
     *     varint32 物品动态属性
     *     bytes 物品动态属性
     */
    static final int S2C_DIVINE_STORAGE = 4;

    static ChannelBuffer EMPTY_STORAGE_MSG = onlySendHeaderMessage(MODULE_ID,
            S2C_DIVINE_STORAGE);

    /**
     * 获取知天命仓库数据失败，附带Byte错误码
     * 1、英雄已经获取过知天命仓库数据了（每次登陆只能取一次）
     */
    static final int S2C_DIVINE_STORAGE_FAIL = 5;

    static final ChannelBuffer ERR_DIVINE_STORAGE_FAIL_ALREADY_ASKED = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_DIVINE_STORAGE_FAIL, 1);

    /**
     * 知天命仓库物品移动，只能是从知天命仓库移动到背包，不能逆向操作
     * 
     * varint32 知天命仓库位置，从0开始(此位置必须要有物品)
     * varint32 背包位置，从0开始(此位置必须是空的)
     */
    static final int C2S_DIVINE_STORAGE_MOVE = 6;

    /**
     * 知天命仓库物品移动成功，
     * varint32 知天命仓库位置
     * varint32 仓库位置
     */
    static final int S2C_DIVINE_STORAGE_MOVE = 7;

    /**
     * 知天命仓库物品移动失败，附带Byte错误码
     * 1、仓库位置无效，或者该位置上没有物品
     * 2、背包位置无效，或者改位置上存在物品
     */
    static final int S2C_DIVINE_STORAGE_MOVE_FAIL = 8;

    static final ChannelBuffer ERR_DIVINE_STORAGE_MOVE_FAIL_SPOS_INVALID = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_DIVINE_STORAGE_MOVE_FAIL, 1);

    static final ChannelBuffer ERR_DIVINE_STORAGE_MOVE_FAIL_TPOS_INVALID = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_DIVINE_STORAGE_MOVE_FAIL, 2);

    /**
     * 获取英雄自己的知天命日志，（每次登陆只能取一次）
     */
    static final int C2S_DIVINE_SELF_LOG = 9;

    /**
     * 获取自己的知天命日志
     * while(byteArray.available)
     *     varint64 日志时间
     *     varint32 物品静态数据长度
     *     bytes 物品静态数据
     *     varint32 物品动态数据长度
     *     bytes 物品动态数据
     *     
     * 展示：您本次推演天命时，竟意外与XXX结缘！
     */
    static final int S2C_DIVINE_SELF_LOG = 10;

    /**
     * 获取自己的知天命日志失败，附带byte错误码
     * 1、英雄已经获取过自己的知天命日志
     */
    static final int S2C_DIVINE_SELF_LOG_FAIL = 11;

    static final ChannelBuffer ERR_DIVINE_SELF_LOG_FAIL_ALREADY_ASKED = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_DIVINE_SELF_LOG_FAIL, 1);

    /**
     * 获取全局的知天命日志，（每次登陆只能取一次）
     */
    static final int C2S_DIVINE_GLOBAL_LOG = 12;

    /**
     * 获取全局的知天命日志
     * while(byteArray.available)
     *     varint64 英雄ID
     *     UTF 英雄名称
     *     varint32 物品静态数据长度
     *     bytes 物品静态数据
     *     varint32 物品动态数据长度
     *     bytes 物品动态数据
     *     
     * 根据获取的数据展示日志：唯尽人事，方知天命，【XXXX】找泥菩萨推演天机时，竟意外发现和XXX十分有缘！
     */
    static final int S2C_DIVINE_GLOBAL_LOG = 13;

    /**
     * 获取全局的知天命日志失败，附带byte错误码
     * 1、英雄已经获取过自己的知天命日志
     */
    static final int S2C_DIVINE_GLOBAL_LOG_FAIL = 14;

    static final ChannelBuffer ERR_DIVINE_GLOBAL_LOG_FAIL_ALREADY_ASKED = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_DIVINE_GLOBAL_LOG_FAIL, 1);

    /**
     * 知天命极品物品，广播通知
     * varint64 英雄ID
     * UTF 英雄名称
     * while(byteArray.available)
     *     varint32 物品静态数据长度
     *     bytes 物品静态数据
     *     varint32 物品动态数据长度
     *     bytes 物品动态数据
     * 
     * 收到此消息，
     * 1、提示信息：唯尽人事，方知天命，【XXXX】找泥菩萨推演天机时，竟意外发现和XXX十分有缘！
     * 2、在全局知天命日志中加入本条信息（加入头部），如果超过日志最大条数，将最早的那条数据顶掉（最底部的数据）
     * (如果收到这个消息时，全局知天命日志还没有初始化，不用管，因为当获取全局知天命日志时，会将最新的日志下发)
     */
    static final int S2C_DIVINE_BROADCAST = 15;

    /**
     * 知天命仓库物品一键取出
     * 
     * 将仓库中所有物品都移到背包(客户端需要先判断背包中有足够的空位置)
     */
    static final int C2S_DIVINE_STORAGE_MOVE_ALL = 16;

    /**
     * 知天命仓库物品一键取出成功
     * while(byteArray.available)
     *     varint32 背包位置
     */
    static final int S2C_DIVINE_STORAGE_MOVE_ALL = 17;

    static final ChannelBuffer EMPTY_DIVINE_STORAGE_MOVE_ALL = onlySendHeaderMessage(
            MODULE_ID, S2C_DIVINE_STORAGE_MOVE_ALL);

    /**
     * 知天命仓库物品一键取出失败，附带Byte错误码
     * 1、全部取出，背包空位不足
     * 2、仓库中没有物品，还一键取出
     */
    static final int S2C_DIVINE_STORAGE_MOVE_ALL_FAIL = 18;

    static final ChannelBuffer ERR_DIVINE_STORAGE_MOVE_ALL_FAIL_DEPOT_FULL = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_DIVINE_STORAGE_MOVE_ALL_FAIL, 1);

    static final ChannelBuffer ERR_DIVINE_STORAGE_MOVE_ALL_FAIL_EMPTY_STORAGE = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_DIVINE_STORAGE_MOVE_ALL_FAIL, 2);

    /**
     * 仓库整理
     */
    static final int C2S_CLEAN = 19;

    /**
     * 整理成功，附带以下信息
     * varlong 下次可整理时间
     * for
     *     varint32 未整理前所在的位置，根据这个位置读取物品信息
     *     varint32 整理后对应下标的物品数量
     */
    static final int S2C_CLEAN_SUCCESS = 20;

    /**
     * 失败返回S2C_CLEAN_FAIL，附带byte错误码
     * 1、仓库中没有物品
     * 2、下次整理时间未到
     */
    static final int S2C_CLEAN_FAIL = 21;

    static final ChannelBuffer ERR_CLEAN_FAIL_EMPTY_STORAGE = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_CLEAN_FAIL, 1);

    static final ChannelBuffer ERR_CLEAN_FAIL_CLEAN_TIME_NOT_REACHED = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_CLEAN_FAIL, 2);

    // ---- 消息 ----

    static ChannelBuffer tryDivineMsg(int blessAmount, int divinePos,
            long time, List<byte[]> goodsDataList){
        ChannelBuffer buffer = newDynamicMessage(MODULE_ID, S2C_DIVINE_TRY);

        BufferUtil.writeVarInt32(buffer, blessAmount);
        BufferUtil.writeVarInt32(buffer, divinePos);
        BufferUtil.writeVarInt64(buffer, time);
        for (byte[] data : goodsDataList){
            BufferUtil.writeVarInt32(buffer, data.length);
            buffer.writeBytes(data);
        }

        return buffer;
    }

    static ChannelBuffer divineStorageMsg(List<Goods> list){
        if (list.isEmpty()){
            return EMPTY_STORAGE_MSG;
        }

        ChannelBuffer buffer = newDynamicMessage(MODULE_ID, S2C_DIVINE_STORAGE);

        for (Goods g : list){
            byte[] staticData = g.getData().getProtoBytes();
            BufferUtil.writeVarInt32(buffer, staticData.length);
            buffer.writeBytes(staticData);

            byte[] dynamicData = g.encodeBytes4Client();
            BufferUtil.writeVarInt32(buffer, dynamicData.length);
            buffer.writeBytes(dynamicData);
        }

        return buffer;
    }

    static ChannelBuffer moveGoodsMsg(int spos, int tpos){
        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID,
                S2C_DIVINE_STORAGE_MOVE, BufferUtil.computeVarInt32Size(spos)
                        + BufferUtil.computeVarInt32Size(tpos));

        BufferUtil.writeVarInt32(buffer, spos);
        BufferUtil.writeVarInt32(buffer, tpos);

        return buffer;
    }

    static ChannelBuffer moveGoodsMsg(IntArrayList posList){
        ChannelBuffer buffer = newDynamicMessage(MODULE_ID,
                S2C_DIVINE_STORAGE_MOVE_ALL, 2 * posList.size());

        for (int i = 0; i < posList.size(); i++){
            BufferUtil.writeVarInt32(buffer, posList.get(i));
        }

        return buffer;
    }

    static ChannelBuffer divineSelfLog(Deque<GoodsShowData> logs){
        ChannelBuffer buffer = newDynamicMessage(MODULE_ID, S2C_DIVINE_SELF_LOG);

        for (GoodsShowData log : logs){
            BufferUtil.writeVarInt64(buffer, log.getTime());
            byte[] staticData = log.getData().getProtoBytes();
            BufferUtil.writeVarInt32(buffer, staticData.length);
            buffer.writeBytes(staticData);

            byte[] dynamicData = log.getDynamicData();
            BufferUtil.writeVarInt32(buffer, dynamicData.length);
            buffer.writeBytes(dynamicData);
        }

        return buffer;
    }

    public static ChannelBuffer divineGlobalLog(DivineGlobalLogs logs){
        ChannelBuffer buffer = newDynamicMessage(MODULE_ID,
                S2C_DIVINE_GLOBAL_LOG);
        logs.writeData(buffer);

        return buffer;
    }

    static ChannelBuffer divineBroadcastMsg(long heroId, byte[] heroName,
            List<byte[]> goodsDataList){
        ChannelBuffer buffer = newDynamicMessage(MODULE_ID,
                S2C_DIVINE_BROADCAST);

        BufferUtil.writeVarInt64(buffer, heroId);
        BufferUtil.writeUTF(buffer, heroName);
        for (byte[] data : goodsDataList){
            BufferUtil.writeVarInt32(buffer, data.length);
            buffer.writeBytes(data);
        }

        return buffer;
    }

    public static ChannelBuffer getCleanSuccessBuffer(long nextCanCleanTime){

        ChannelBuffer buffer = newDynamicMessage(MODULE_ID, S2C_CLEAN_SUCCESS);
        BufferUtil.writeVarInt64(buffer, nextCanCleanTime);
        return buffer;
    }
}
