package app.game.module.guild;

import java.util.Arrays;
import java.util.Set;
import java.util.concurrent.LinkedTransferQueue;
import java.util.concurrent.TimeUnit;

import jsr166e.ConcurrentHashMapV8;

import org.jboss.netty.buffer.ChannelBuffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.cluster.protobuf.CombatContent.RemoteGuildProto;
import app.game.data.ServerData;
import app.game.data.scene.ChallengeDungeonSceneData;
import app.game.entity.Hero;
import app.game.module.HeroID;
import app.game.module.scene.ChallengeDungeonModule.FastestCrossDungeonObject;
import app.game.service.TimeService;
import app.protobuf.GuildContent.ChallengeFastCrossProto;
import app.protobuf.GuildContent.ClientNewsProto;
import app.protobuf.GuildContent.GuildInListProto;
import app.protobuf.GuildContent.GuildMemberProto;
import app.protobuf.GuildContent.GuildProto;
import app.utils.IDUtils;
import app.utils.IndividualServerConfig;
import app.utils.VariableConfig;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.google.protobuf.ByteString;
import com.mokylin.collection.IntValueLongConcurrentHashMap;
import com.mokylin.collection.IntValueLongConcurrentHashMap.LongKeyIterator;
import com.mokylin.collection.LongConcurrentSynchronizedHashMap;
import com.mokylin.sink.util.Empty;
import com.mokylin.sink.util.StringEncoder;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.annotation.MultiThread;
import com.mokylin.sink.util.concurrent.PaddedAtomicInteger;
import com.mokylin.sink.util.concurrent.PaddedAtomicReference;

public class Guild implements IGuild{
    private static final Logger logger = LoggerFactory.getLogger(Guild.class);

    public static final Guild[] EMPTY_ARRAY = new Guild[0];

    private static final CacheBuilder<Object, Object> requestJoinCacheBuilder = CacheBuilder
            .newBuilder()
            .concurrencyLevel(1)
            .expireAfterWrite(VariableConfig.GUILD_REQUEST_JOIN_EXPIRE_TIME,
                    TimeUnit.MILLISECONDS).initialCapacity(8);

    private static final CacheBuilder<Object, Object> inviteFriendGuildCacheBuilder = CacheBuilder
            .newBuilder()
            .concurrencyLevel(1)
            .expireAfterWrite(
                    VariableConfig.GUILD_INVITE_FRIEND_GUILD_EXPIRE_TIME,
                    TimeUnit.MILLISECONDS).initialCapacity(4);

    /**
     * 英雄下线时, 如果没有帮派, 则把他的帮派cas(null, offline_guild). 防止别人加了个不在线的
     */
    public static final Guild OFFLINE_GUILD = new Guild(null, 0, 0,
            Empty.BYTE_ARRAY, Empty.BYTE_ARRAY, 0, null, 0, null, null, 0);

    // ---------

    public static final int POSITION_NORMAL = 0;
    public static final int POSITION_TANG_LEADER = 1;
    public static final int POSITION_VICE_LEADER = 2;
    public static final int POSITION_LEADER = 3;
    /**
     * 帮派名字
     */
    public final byte[] name;

    public final String nameString;

    public final ServerData serverData;

    // --- 拼出 决定ServerData ---
    /**
     * 区号. 暂时只有改帮旗名的时候, 用老的区号拼出新的帮旗名字
     */
    final int serverID;

    /**
     * 运营商id
     */
    final int operatorID;
    // ---

    private final int hashCode;

    public final ByteString nameByteString;

    final LongConcurrentSynchronizedHashMap<GuildMember> members;

    private final ConcurrentHashMapV8<Guild, Boolean> friendGuild;

    private final ConcurrentHashMapV8<Guild, Boolean> enemyGuild;

    private final ConcurrentHashMapV8<Guild, Boolean> beenAddedEnemyHaveNotNotified;

    private final ConcurrentHashMapV8<Guild, Boolean> beenRemovedEnemyHaveNotNotified;

    private final ConcurrentHashMapV8<Guild, Boolean> beenRemovedFriendHaveNotNotified;

    private final Cache<Guild, Object> invitedGuild;

    /**
     * 帮主
     */
    private final PaddedAtomicReference<GuildMember> leader;

    /**
     * 副帮主
     */
    private final PaddedAtomicReference<GuildMember> viceLeader;

    /**
     * 堂主
     */
    private final PaddedAtomicReference<GuildMember> tangLeader;

    /**
     * 入帮申请
     */
    private final Cache<HeroID, Object> requestJoin;

    /**
     * 邀请别人入帮
     */
    private final Cache<HeroID, HeroID> inviteJoin;

    private final long createTime;

    /**
     * 帮旗名字
     */
    private ByteString flagNameByteString;

    /**
     * 公告
     */
    private ByteString announcement;

    /**
     * 公告最后更新时间
     */
    private long changeAnnouncementTime;

    /**
     * 帮旗样式 0-9
     */
    private int flagKind;

    private boolean isAutoAcceptJoinRequest;

    /**
     * 最大英雄人数
     */
    private volatile int maxHeroCount;

    private GuildFlagData flagLevel;

    private int giftGoods1;
    private int giftGoods2;
    private int giftGoods3;
    private int giftGoods4;
    private long giftMoney;

    /**
     * 兑换商店今天已经买了的次数
     */
    private int[] contributionBoughtCount;

    // --- 板块战占领场景数 ---

    private transient final PaddedAtomicInteger territoryWinCount;

    // --- 自动解散帮派 ----
    private volatile boolean activeDegreeFullToday;

    /**
     * 今天贡献了活跃度的英雄id
     */
    private final IntValueLongConcurrentHashMap activeDegree;

    /**
     * 帮派解散警告值
     */
    private int dismissWarningLevel;

    // --------------------

    private final LinkedTransferQueue<ByteString> news;
    private final PaddedAtomicInteger newsCount;

    private final PaddedAtomicReference<FastestCrossDungeonObject>[] fastCrossArray;

    // 无双城
    private WushuangCityMaster master;

    private LongCityMaster longMaster;

    public boolean isGMCreated;

    /**
     * 新建个帮派
     * @param name
     * @param flagName
     * @param flagKind
     * @param creator
     */
    @SuppressWarnings("unchecked")
    Guild(ServerData serverData, int operatorID, int serverID, byte[] name,
            byte[] flagName, int flagKind, GuildMember creator, long ctime,
            GuildFlagData firstFlagLevel,
            GuildContributionGoodsShop contributionShop,
            int challengeDungeonCount){
        this.serverData = serverData;
        this.operatorID = operatorID;
        this.serverID = serverID;
        this.friendGuild = new ConcurrentHashMapV8<>(8, 0.75f, 2);
        this.enemyGuild = new ConcurrentHashMapV8<>(8, 0.75f, 2);
        this.beenAddedEnemyHaveNotNotified = new ConcurrentHashMapV8<>(8,
                0.75f, 2);
        this.beenRemovedEnemyHaveNotNotified = new ConcurrentHashMapV8<>(8,
                0.75f, 2);
        this.beenRemovedFriendHaveNotNotified = new ConcurrentHashMapV8<>(8,
                0.75f, 2);

        this.news = new LinkedTransferQueue<>();
        this.newsCount = new PaddedAtomicInteger();
        this.territoryWinCount = new PaddedAtomicInteger();

        if (contributionShop == null){ // null_guild
            this.contributionBoughtCount = Empty.INT_ARRAY;
        } else{
            this.contributionBoughtCount = new int[contributionShop.goodsCount];
        }

        this.requestJoin = requestJoinCacheBuilder.build();
        this.inviteJoin = requestJoinCacheBuilder.build();
        this.invitedGuild = inviteFriendGuildCacheBuilder.build();

        this.activeDegree = new IntValueLongConcurrentHashMap(16);

        this.name = name;
        this.nameString = StringEncoder.encode(name);
        this.hashCode = Arrays.hashCode(name);
        this.nameByteString = ByteString.copyFrom(name);
        this.flagNameByteString = ByteString.copyFrom(flagName);
        this.flagKind = flagKind;
        this.flagLevel = firstFlagLevel;
        this.announcement = ByteString.EMPTY;
        this.changeAnnouncementTime = ctime;

        this.createTime = ctime;
        this.isAutoAcceptJoinRequest = true;

        this.maxHeroCount = VariableConfig.GUILD_INITIAL_HERO_LIMIT;

        this.members = new LongConcurrentSynchronizedHashMap<>(64);
        this.leader = new PaddedAtomicReference<GuildMember>(creator);
        this.viceLeader = new PaddedAtomicReference<GuildMember>(null);
        this.tangLeader = new PaddedAtomicReference<GuildMember>(null);

        if (creator != null){ // OFFLINE_GUILD需要
            this.members.put(creator.id, creator);
        }

        fastCrossArray = new PaddedAtomicReference[challengeDungeonCount];
        for (int i = 0; i < challengeDungeonCount; i++){
            fastCrossArray[i] = new PaddedAtomicReference<FastestCrossDungeonObject>(
                    null);
        }
    }

    @SuppressWarnings("unchecked")
    private Guild(GuildProto proto, GuildFlagDatas flagLevels,
            GuildContributionGoodsShop contributionShop,
            int challengeDungeonCount, TimeService timeService,
            IndividualServerConfig individualServerConfig){
        this.operatorID = proto.hasOperatorId() ? proto.getOperatorId()
                : IDUtils.getOperatorID(proto.getLeaderId());
        this.serverID = proto.hasServerId() ? proto.getServerId() : IDUtils
                .getServerID(proto.getLeaderId());

        this.serverData = individualServerConfig.getServerData(IDUtils
                .combineOperatorAndServerID(operatorID, serverID));
        if (serverData == null){
            logger.error(
                    "帮派decode时, 没找到帮派所属的联服区ServerData. {} @ OperatorID: {}, ServerID: {}",
                    proto.getGuildName().toStringUtf8(), operatorID, serverID);
            throw new IllegalArgumentException();
        }

        this.friendGuild = new ConcurrentHashMapV8<>(8, 0.75f, 2);
        this.enemyGuild = new ConcurrentHashMapV8<>(8, 0.75f, 2);
        this.beenAddedEnemyHaveNotNotified = new ConcurrentHashMapV8<>(8,
                0.75f, 2);
        this.beenRemovedEnemyHaveNotNotified = new ConcurrentHashMapV8<>(8,
                0.75f, 2);
        this.beenRemovedFriendHaveNotNotified = new ConcurrentHashMapV8<>(8,
                0.75f, 2);

        this.news = new LinkedTransferQueue<>();
        this.territoryWinCount = new PaddedAtomicInteger();

        this.requestJoin = requestJoinCacheBuilder.build();
        this.inviteJoin = requestJoinCacheBuilder.build();
        this.invitedGuild = inviteFriendGuildCacheBuilder.build();

        this.activeDegree = new IntValueLongConcurrentHashMap(16);

        this.nameByteString = proto.getGuildName();
        this.name = this.nameByteString.toByteArray();
        this.nameString = StringEncoder.encode(name);

        this.hashCode = Arrays.hashCode(name);

        this.flagNameByteString = proto.getFlagName();
        this.flagKind = proto.getFlagKind();

        int level = Math.min(proto.getFlagLevel(), flagLevels.getMaxLevel());
        this.flagLevel = flagLevels.getLevel(level);
        this.announcement = proto.getAnnouncement();
        this.changeAnnouncementTime = proto.getChangeAnnouncementTime();

        this.createTime = proto.getCreateTime();
        this.isAutoAcceptJoinRequest = proto.getIsAutoAcceptJoinRequest();

        this.maxHeroCount = VariableConfig.GUILD_INITIAL_HERO_LIMIT
                + this.flagLevel.addCapacity;

        this.giftGoods1 = proto.getGiftGoods1();
        this.giftGoods2 = proto.getGiftGoods2();
        this.giftGoods3 = proto.getGiftGoods3();
        this.giftGoods4 = proto.getGiftGoods4();
        this.giftMoney = proto.getGiftMoney();

        this.members = new LongConcurrentSynchronizedHashMap<>(64);

        // decode guild member
        for (GuildMemberProto memberProto : proto.getMembersList()){
            GuildMember mem = GuildMember.decode(memberProto, timeService);
            mem.setGuildWhenNull(this);
            this.members.put(mem.id, mem);
        }

        // 帮主
        GuildMember mem = this.members.get(proto.getLeaderId());
        if (mem == null){
            logger.error("Guild.decode时, 帮主没找到: leaderID: {}, 帮派人数: {}",
                    proto.getLeaderId(), proto.getMembersCount());
            this.leader = new PaddedAtomicReference<GuildMember>(null);
        } else{
            this.leader = new PaddedAtomicReference<GuildMember>(mem);
        }

        // 副帮主
        if (proto.hasViceLeaderId()){
            mem = this.members.get(proto.getViceLeaderId());
            if (mem != null){
                this.viceLeader = new PaddedAtomicReference<GuildMember>(mem);
            } else{
                logger.error("Guild.decode时, 本来有副帮主, 但是副帮主没找到: id: {}",
                        proto.getViceLeaderId());
                this.viceLeader = new PaddedAtomicReference<GuildMember>(null);
            }
        } else{
            this.viceLeader = new PaddedAtomicReference<GuildMember>(null);
        }

        // 堂主
        if (proto.hasTangLeaderId()){
            mem = this.members.get(proto.getTangLeaderId());
            if (mem != null){
                this.tangLeader = new PaddedAtomicReference<GuildMember>(mem);
            } else{
                logger.error("Guild.decode时, 本来有堂主, 但是堂主没找到: id: {}",
                        proto.getTangLeaderId());
                this.tangLeader = new PaddedAtomicReference<GuildMember>(null);
            }
        } else{
            this.tangLeader = new PaddedAtomicReference<GuildMember>(null);
        }

        // 设置活跃度
        this.dismissWarningLevel = proto.getDismissWarningLevel();
        if (proto.getActiveDegreeFull()){
            this.activeDegreeFullToday = true;
        } else{
            for (int i = proto.getActiveHeroIdCount(); --i >= 0;){
                this.activeDegree.put(proto.getActiveHeroId(i), 1);
            }
        }

        // --- 兑换个数 ---

        this.contributionBoughtCount = new int[contributionShop.goodsCount];
        int protoContributionGoodsCount = Math.min(
                proto.getServerContributionBoughtCountCount(),
                proto.getServerContributionGoodsIdCount());

        for (int i = protoContributionGoodsCount; --i >= 0;){
            GuildContributionGoods g = contributionShop.getGoodsByID(proto
                    .getServerContributionGoodsId(i));
            if (g != null){
                int count = proto.getServerContributionBoughtCount(i);
                if (g.limitPerDay > 0){
                    // 有限制
                    this.contributionBoughtCount[g.index] = Math.min(count,
                            g.limitPerDay);
                }
            }
        }

        // --- 帮派新闻 ---
        for (ByteString bs : proto.getServerNewsList()){
            news.add(bs);
        }
        this.newsCount = new PaddedAtomicInteger(proto.getServerNewsCount());
        while (newsCount.get() > VariableConfig.GUILD_NEWS_LIMIT){
            news.poll();
            newsCount.decrementAndGet();
        }

        fastCrossArray = new PaddedAtomicReference[challengeDungeonCount];
        for (int i = 0; i < challengeDungeonCount; i++){
            fastCrossArray[i] = new PaddedAtomicReference<FastestCrossDungeonObject>(
                    null);
        }

        for (ChallengeFastCrossProto data : proto.getFastCrossDataList()){
            if (data.getSequence() <= 0
                    || data.getSequence() > challengeDungeonCount){
                continue;
            }

            FastestCrossDungeonObject obj = new FastestCrossDungeonObject(
                    data.getSequence(), data.getId(), data.getName()
                            .toByteArray(), data.getName(), data.getUseTime());
            fastCrossArray[data.getSequence() - 1].compareAndSet(null, obj);
        }
    }

    /**
     * 加新闻, 可多线程调用
     * @param news
     */
    @MultiThread
    public void addNews(byte[] bs){
        news.add(ByteString.copyFrom(bs));

        int count = newsCount.incrementAndGet();
        if (count > VariableConfig.GUILD_NEWS_LIMIT){
            news.poll();
            newsCount.decrementAndGet();
        }
    }

    @Override
    public boolean isWsCityMaster(){
        return getWsCityMaster() != null;
    }

    WushuangCityMaster getWsCityMaster(){
        return master;
    }

    void setCityMaster(WushuangCityMaster master){
        this.master = master;
    }

    @Override
    public boolean isLongCityMaster(){
        return getLongCityMaster() != null;
    }

    LongCityMaster getLongCityMaster(){
        return longMaster;
    }

    void setLongCityMaster(LongCityMaster master){
        this.longMaster = master;
    }

    public int addTerritoryWinCount(int diff){
        return territoryWinCount.addAndGet(diff);
    }

    public int getTerritoryWinCount(){
        return territoryWinCount.get();
    }

    ByteString getFlagName(){
        return flagNameByteString;
    }

    boolean containsMember(long id){
        return members.containsKey(id);
    }

    int getMemCount(){
        return members.size();
    }

    boolean hasEmptySpot(){
        return members.size() < maxHeroCount;
    }

    boolean isAutoAcceptJoinRequest(){
        return isAutoAcceptJoinRequest;
    }

    void setAutoAcceptJoinRequest(boolean v){
        this.isAutoAcceptJoinRequest = v;
    }

    boolean addWhenUnderMaxSize(GuildMember member){
        return members.putIfUnderSize(member.id, member, maxHeroCount);
    }

    void removeMember(long id){
        members.remove(id);
    }

    GuildMember getMember(long id){
        return members.get(id);
    }

    @MultiThread
    public void broadcast(ChannelBuffer buffer, long dontSend){
        for (GuildMember mem : members.values()){
            if (mem.id != dontSend){
                mem.sendMessage(buffer);
            }
        }
    }

    @MultiThread
    public void broadcast(ChannelBuffer buffer){
        for (GuildMember mem : members.values()){
            mem.sendMessage(buffer);
        }
    }

    @MultiThread
    public void broadcastDroppableMsg(ChannelBuffer buffer, long dontSend){
        for (GuildMember mem : members.values()){
            if (mem.id != dontSend){
                mem.sendDroppableMessage(buffer);
            }
        }
    }

    @MultiThread
    public void broadcastDroppableMsg(ChannelBuffer buffer){
        for (GuildMember mem : members.values()){
            mem.sendDroppableMessage(buffer);
        }
    }

    public GuildFlagData getFlagLevelData(){
        return flagLevel;
    }

    public int getFlagLevel(){
        return flagLevel.level;
    }

    public int getFlagKind(){
        return flagKind;
    }

    int getDismissLevel(){
        return dismissWarningLevel;
    }

    void setAnnouncement(ByteString newAnnouncement, long ctime){
        this.announcement = newAnnouncement;
        this.changeAnnouncementTime = ctime;
    }

    void setFlagKind(int newFlagKind){
        this.flagKind = newFlagKind;
    }

    void setFlagLevel(GuildFlagData newLevel){
        this.flagLevel = newLevel;
        maxHeroCount = VariableConfig.GUILD_INITIAL_HERO_LIMIT
                + newLevel.addCapacity;
    }

    int getGiftGoodsCount(int type){
        switch (type){
            case 1:{
                return giftGoods1;
            }
            case 2:{
                return giftGoods2;
            }
            case 3:{
                return giftGoods3;
            }
            case 4:{
                return giftGoods4;
            }
            default:{
                return 0;
            }
        }
    }

    public long getGiftMoney(){
        return giftMoney;
    }

    boolean hasEnoughResourceToUpgradeFlag(GuildFlagData data){
        return giftGoods1 >= data.upgradeGoods1
                && giftGoods2 >= data.upgradeGoods2
                && giftGoods3 >= data.upgradeGoods3
                && giftGoods4 >= data.upgradeGoods4
                && giftMoney >= data.upgradeMoney;
    }

    public void reduceGiftMoneyAnyway(int amount){
        if (amount <= 0){
            logger.error(
                    "Guild.reduceGiftMoneyAnyway时, 传入的amount <=0: {}. @ {}",
                    amount, Utils.getStackTrace());
            return;
        }

        synchronized (this){
            giftMoney = Math.max(0, giftMoney - amount);
        }
    }

    void reduceUpgradeFlagResource(GuildFlagData data){
        giftGoods1 = Math.max(0, giftGoods1 - data.upgradeGoods1);
        giftGoods2 = Math.max(0, giftGoods2 - data.upgradeGoods2);
        giftGoods3 = Math.max(0, giftGoods3 - data.upgradeGoods3);
        giftGoods4 = Math.max(0, giftGoods4 - data.upgradeGoods4);
        giftMoney = Math.max(0, giftMoney - data.upgradeMoney);
    }

    boolean hasEnoughResourceToChangeFlagKind(VariableConfig variableConfig){
        return giftGoods1 >= variableConfig.GUILD_CHANGE_FLAG_KIND_COST_GOODS_1
                && giftGoods2 >= variableConfig.GUILD_CHANGE_FLAG_KIND_COST_GOODS_2
                && giftGoods3 >= variableConfig.GUILD_CHANGE_FLAG_KIND_COST_GOODS_3
                && giftGoods4 >= variableConfig.GUILD_CHANGE_FLAG_KIND_COST_GOODS_4
                && giftMoney >= variableConfig.GUILD_CHANGE_FLAG_KIND_COST_MONEY;
    }

    void reduceChangeFlagKindResource(VariableConfig variableConfig){
        giftGoods1 = Math.max(0, giftGoods1
                - variableConfig.GUILD_CHANGE_FLAG_KIND_COST_GOODS_1);

        giftGoods2 = Math.max(0, giftGoods2
                - variableConfig.GUILD_CHANGE_FLAG_KIND_COST_GOODS_2);

        giftGoods3 = Math.max(0, giftGoods3
                - variableConfig.GUILD_CHANGE_FLAG_KIND_COST_GOODS_3);

        giftGoods4 = Math.max(0, giftGoods4
                - variableConfig.GUILD_CHANGE_FLAG_KIND_COST_GOODS_4);

        giftMoney = Math.max(0, giftMoney
                - variableConfig.GUILD_CHANGE_FLAG_KIND_COST_MONEY);
    }

    void setFlagName(byte[] newName){
        this.flagNameByteString = ByteString.copyFrom(newName);
    }

    boolean hasEnoughResourceToChangeFlagName(VariableConfig variableConfig){
        return giftGoods1 >= variableConfig.GUILD_CHANGE_FLAG_NAME_COST_GOODS_1
                && giftGoods2 >= variableConfig.GUILD_CHANGE_FLAG_NAME_COST_GOODS_2
                && giftGoods3 >= variableConfig.GUILD_CHANGE_FLAG_NAME_COST_GOODS_3
                && giftGoods4 >= variableConfig.GUILD_CHANGE_FLAG_NAME_COST_GOODS_4
                && giftMoney >= variableConfig.GUILD_CHANGE_FLAG_NAME_COST_MONEY;
    }

    void reduceChangeFlagNameResource(VariableConfig variableConfig){
        giftGoods1 = Math.max(0, giftGoods1
                - variableConfig.GUILD_CHANGE_FLAG_NAME_COST_GOODS_1);

        giftGoods2 = Math.max(0, giftGoods2
                - variableConfig.GUILD_CHANGE_FLAG_NAME_COST_GOODS_2);

        giftGoods3 = Math.max(0, giftGoods3
                - variableConfig.GUILD_CHANGE_FLAG_NAME_COST_GOODS_3);

        giftGoods4 = Math.max(0, giftGoods4
                - variableConfig.GUILD_CHANGE_FLAG_NAME_COST_GOODS_4);

        giftMoney = Math.max(0, giftMoney
                - variableConfig.GUILD_CHANGE_FLAG_NAME_COST_MONEY);
    }

    boolean casLeader(GuildMember oldMem, GuildMember newMem){
        return leader.compareAndSet(oldMem, newMem);
    }

    boolean casViceLeader(GuildMember oldMem, GuildMember newMem){
        return viceLeader.compareAndSet(oldMem, newMem);
    }

    boolean casTangLeader(GuildMember oldMem, GuildMember newMem){
        return tangLeader.compareAndSet(oldMem, newMem);
    }

    void addActiveDegree(long heroID){
        if (!activeDegreeFullToday){
            activeDegree.putIfAbsent(heroID, 1);
            if (activeDegree.size() >= VariableConfig.GUILD_ACTIVE_DEGREE_PER_DAY){
                activeDegree.clear();
                activeDegreeFullToday = true;
            }
        }
    }

    int updateDismissWarningLevel(){
        if (isLongCityMaster() || isWsCityMaster()){
            return dismissWarningLevel = 0;
        }

        if (activeDegreeFullToday){
            dismissWarningLevel = Math.max(0, dismissWarningLevel - 1);
        } else{
            ++dismissWarningLevel;
        }

        activeDegree.clear();
        for (GuildMember gm : members.values()){
            if (gm.isOnline()){
                activeDegree.put(gm.id, 1);
            }
        }

        if (activeDegree.size() >= VariableConfig.GUILD_ACTIVE_DEGREE_PER_DAY){
            activeDegree.clear();
            activeDegreeFullToday = true;
        } else{
            activeDegreeFullToday = false;
        }

        return dismissWarningLevel;
    }

    /**
     * 必须synchronized guild下才能调用
     * @param index
     * @param limit
     * @return
     */
    boolean incrementContributionGoodsCountIfUnderLimit(int index, int limit){
        assert index >= 0 && index < contributionBoughtCount.length;
        if (limit > 0){
            if (contributionBoughtCount[index] >= limit){
                return false;
            }
            ++contributionBoughtCount[index];
            return true;
        }
        return true;
    }

    int getContributionGoodsBoughtCount(int index){
        return contributionBoughtCount[index];
    }

    void clearContributionGoodsCount(){
        for (int i = contributionBoughtCount.length; --i >= 0;){
            contributionBoughtCount[i] = 0;
        }
    }

    void clearOnDismiss(){
        maxHeroCount = 0; // 必须. 被解散后不能再加人就靠这个了
        leader.set(null);
        viceLeader.set(null);
        tangLeader.set(null);

        requestJoin.invalidateAll();
        inviteJoin.invalidateAll();
        members.clear();
        activeDegree.clear();
    }

    void clearRelationsOnDismiss(){
        friendGuild.clear();
        enemyGuild.clear();
        invitedGuild.invalidateAll();
        beenAddedEnemyHaveNotNotified.clear();
    }

    // ----- 帮派关系 -----

    boolean canAddMoreFriendGuild(){
        return friendGuild.size() < VariableConfig.GUILD_MAX_FRIEND_GUILD_LIMIT;
    }

    boolean canAddMoreEnemyGuild(){
        return enemyGuild.size() < VariableConfig.GUILD_MAX_ENEMY_GUILD_LIMIT;
    }

    public boolean containsFriendGuild(Guild g){
        return friendGuild.containsKey(g);
    }

    void addFriendGuild(Guild g){
        friendGuild.put(g, Boolean.TRUE);
    }

    boolean hasBeenInvitedFriendGuild(Guild g){
        return invitedGuild.getIfPresent(g) != null;
    }

    boolean removeFriendGuildInviteIfExists(Guild g){
        boolean invited = invitedGuild.getIfPresent(g) != null;
        if (invited){
            invitedGuild.invalidate(g);
            return true;
        }
        return false;
    }

    void markAsBeenInvited(Guild g){
        invitedGuild.put(g, Boolean.TRUE);
    }

    boolean containsEnemyGuild(Guild g){
        return enemyGuild.containsKey(g);
    }

    boolean removeFriendGuild(Guild g){
        return friendGuild.remove(g) != null;
    }

    boolean removeEnemyGuild(Guild g){
        return enemyGuild.remove(g) != null;
    }

    void addEnemyGuild(Guild g){
        enemyGuild.put(g, Boolean.TRUE);
    }

    // --- 被加敌帮提醒 ---
    boolean removeBeenAddedEnemyHaveNotNotified(Guild g){
        return beenAddedEnemyHaveNotNotified.remove(g) != null;
    }

    void addBeenAddedEnemyHaveNotNotified(Guild g){
        beenAddedEnemyHaveNotNotified.put(g, Boolean.TRUE);
    }

    Set<Guild> getBeenAddedEnemyHaveNotNotified(){
        return beenAddedEnemyHaveNotNotified.keySet();
    }

    // --- 被删敌帮提醒 ---

    boolean removeBeenRemovedEnemyHaveNotNotified(Guild g){
        return beenRemovedEnemyHaveNotNotified.remove(g) != null;
    }

    void addBeenRemovedEnemyHaveNotNotified(Guild g){
        beenRemovedEnemyHaveNotNotified.put(g, Boolean.TRUE);
    }

    Set<Guild> getBeenRemovedEnemyHaveNotNotified(){
        return beenRemovedEnemyHaveNotNotified.keySet();
    }

    // --- 被删友帮提醒 ---

    boolean removeBeenRemovedFriendHaveNotNotified(Guild g){
        return beenRemovedFriendHaveNotNotified.remove(g) != null;
    }

    void addBeenRemovedFriendHaveNotNotified(Guild g){
        beenRemovedFriendHaveNotNotified.put(g, Boolean.TRUE);
    }

    Set<Guild> getBeenRemovedFriendHaveNotNotified(){
        return beenRemovedFriendHaveNotNotified.keySet();
    }

    // --------

    public Set<Guild> getFriendGuilds(){
        return friendGuild.keySet();
    }

    public Set<Guild> getEnemyGuilds(){
        return enemyGuild.keySet();
    }

    // ----- 加帮贡 -----
    boolean addGiftGoods1(int count){
        assert count > 0;

        int newAmount = giftGoods1 + count;
        if (newAmount <= 0
                || newAmount > VariableConfig.GUILD_GIFT_GOODS_UPPER_LIMIT){
            return false;
        }

        giftGoods1 = newAmount;
        return true;
    }

    boolean addGiftGoods2(int count){
        assert count > 0;

        int newAmount = giftGoods2 + count;
        if (newAmount <= 0
                || newAmount > VariableConfig.GUILD_GIFT_GOODS_UPPER_LIMIT){
            return false;
        }

        giftGoods2 = newAmount;
        return true;
    }

    boolean addGiftGoods3(int count){
        assert count > 0;

        int newAmount = giftGoods3 + count;
        if (newAmount <= 0
                || newAmount > VariableConfig.GUILD_GIFT_GOODS_UPPER_LIMIT){
            return false;
        }

        giftGoods3 = newAmount;
        return true;
    }

    boolean addGiftGoods4(int count){
        assert count > 0;

        int newAmount = giftGoods4 + count;
        if (newAmount <= 0
                || newAmount > VariableConfig.GUILD_GIFT_GOODS_UPPER_LIMIT){
            return false;
        }

        giftGoods4 = newAmount;
        return true;
    }

    boolean addGiftMoney(int amount){
        assert amount > 0;

        long newAmount = giftMoney + amount;
        if (newAmount <= 0
                || newAmount > VariableConfig.GUILD_GIFT_MONEY_UPPER_LIMIT){
            return false;
        }

        giftMoney = newAmount;
        return true;
    }

    // ---- 邀请入帮 ----
    boolean hasInviteJoin(HeroID id){
        return inviteJoin.getIfPresent(id) != null;
    }

    void markInvitedJoin(HeroID id, HeroID inviter){
        inviteJoin.put(id, inviter);
    }

    HeroID removeInviteIfExists(HeroID id){
        HeroID result = inviteJoin.getIfPresent(id);
        if (result != null){
            inviteJoin.invalidate(id);
            return result;
        }
        return null;
    }

    // ---- 入帮申请 ----
    boolean hasRequestJoin(HeroID id){
        return requestJoin.getIfPresent(id) != null;
    }

    void markRequestedJoin(HeroID id){
        requestJoin.put(id, Empty.DUMB_OBJECT);
    }

    boolean removeRequestJoinIfExists(HeroID id){
        boolean result = requestJoin.getIfPresent(id) != null;
        if (result){
            requestJoin.invalidate(id);
            return true;
        }
        return false;
    }

    // -------

    public GuildMember getLeader(){
        return leader.get();
    }

    public GuildMember getViceLeader(){
        return viceLeader.get();
    }

    public GuildMember getTangLeader(){
        return tangLeader.get();
    }

    // --- 总战斗力 ---
    private long totalFightAmount;

    public long getTotalFightAmountIfNotZero(){
        long result = totalFightAmount;
        if (result == 0){
            return doCalculateTotalFightAmount();
        }
        return result;
    }

    private long doCalculateTotalFightAmount(){
        long result = 0;
        for (GuildMember member : members.values()){
            result += member.getFightAmount();
        }

        totalFightAmount = result;
        return result;
    }

    // --------------

    @MultiThread
    GuildInListProto encodeToGuildList(){
        GuildInListProto.Builder builder = GuildInListProto.newBuilder();
        builder.setName(nameByteString).setFlagLevel(flagLevel.level)
                .setFlagName(flagNameByteString)
                .setIsAutoAcceptJoinRequest(isAutoAcceptJoinRequest)
                .setHeroCount(members.size()).setMaxHeroCount(maxHeroCount)
                .setCreateTime(createTime).setOperatorId(operatorID)
                .setServerId(serverID)
                .setTerritoryMasterCount(territoryWinCount.get());

        GuildMember mem = leader.get();
        if (mem != null){
            builder.setLeaderId(mem.id);
            builder.setLeaderName(mem.heroNameByteString);
            if (mem.isOnline()){
                builder.setLeaderOnline(true);
            }
            builder.setLeaderLevel(mem.getLevel());
        }

        mem = viceLeader.get();
        if (mem != null){
            builder.setViceLeaderName(mem.heroNameByteString);
            if (mem.isOnline()){
                builder.setViceLeaderOnline(true);
            }
            builder.setViceLeaderLevel(mem.getLevel());
        }

        builder.setTotalFightAmount(doCalculateTotalFightAmount());

        return builder.build();
    }

    public RemoteGuildProto encodeForRemote(){
        RemoteGuildProto.Builder builder = RemoteGuildProto.newBuilder();

        builder.setName(nameByteString)
                .setIsTerritoryMaster(isTerritoryMaster())
                .setIsWsCityMaster(isWsCityMaster())
                .setIsLongCityMaster(isLongCityMaster())
                .setFlagLevel(flagLevel.level);

        GuildMember leader = getLeader();
        if (leader != null){
            builder.setLeaderId(leader.id);
        }
        for (Guild friend : friendGuild.keySet()){
            builder.addFriendGuild(friend.nameByteString);
        }

        return builder.build();
    }

    private GuildProto.Builder encodeShared(boolean toServer){
        GuildProto.Builder builder = GuildProto.newBuilder();

        builder.setGuildName(nameByteString).setFlagName(flagNameByteString)
                .setFlagKind(flagKind).setFlagLevel(flagLevel.level)
                .setCreateTime(createTime)
                .setIsAutoAcceptJoinRequest(isAutoAcceptJoinRequest)
                .setMaxHeroCount(maxHeroCount).setGiftGoods1(giftGoods1)
                .setGiftGoods2(giftGoods2).setGiftGoods3(giftGoods3)
                .setGiftGoods4(giftGoods4).setGiftMoney(giftMoney)
                .setAnnouncement(announcement)
                .setChangeAnnouncementTime(changeAnnouncementTime);

        // encode members
        for (GuildMember member : members.values()){
            builder.addMembers(member.encode(toServer));
        }

        // encode posts
        GuildMember member = leader.get();
        if (member == null){
            logger.error("Guild.encode时, 帮派的leader.get()为null");
        } else{
            builder.setLeaderId(member.id);
        }

        member = viceLeader.get();
        if (member != null){
            builder.setViceLeaderId(member.id);
        }

        member = tangLeader.get();
        if (member != null){
            builder.setTangLeaderId(member.id);
        }

        return builder;
    }

    GuildProto encode4Server(GuildContributionGoodsShop contributionShop){
        final GuildProto.Builder builder;
        synchronized (this){ // 加锁, 防止数据不可见, 或存了个有问题的值
            builder = encodeShared(true);

            builder.setServerId(serverID).setOperatorId(operatorID);

            // --- 活跃度 & 自动解散所需字段
            builder.setDismissWarningLevel(dismissWarningLevel);
            if (activeDegreeFullToday){
                builder.setActiveDegreeFull(true);
            } else{
                for (LongKeyIterator ite = activeDegree.newKeyIte(); ite
                        .hasNext();){
                    long heroID = ite.nextLong();
                    builder.addActiveHeroId(heroID);
                }

                if (builder.getActiveHeroIdCount() >= VariableConfig.GUILD_ACTIVE_DEGREE_PER_DAY){
                    builder.setActiveDegreeFull(true);
                    builder.clearActiveHeroId();
                }
            }

            for (Guild friend : friendGuild.keySet()){
                builder.addFriendGuild(friend.nameByteString);
            }

            for (Guild enemy : enemyGuild.keySet()){
                builder.addEnemyGuild(enemy.nameByteString);
            }

            // --- 帮派购买物品数量 ---

            int[] contributionShopIDs = contributionShop.getIDs();
            for (int i = contributionShop.goodsCount; --i >= 0;){
                builder.addServerContributionGoodsId(contributionShopIDs[i]);
                builder.addServerContributionBoughtCount(contributionBoughtCount[i]);
            }
        }

        // --- 以下的encode时不加锁 ---

        for (Guild addedEnemyNotNotified : beenAddedEnemyHaveNotNotified
                .keySet()){
            builder.addBeenAddedEnemyNotNotified(addedEnemyNotNotified.nameByteString);
        }

        for (Guild removedEnemyNotNotified : beenRemovedEnemyHaveNotNotified
                .keySet()){
            builder.addBeenRemovedEnemyNotNotified(removedEnemyNotNotified.nameByteString);
        }

        for (Guild removedFriendNotNotified : beenRemovedFriendHaveNotNotified
                .keySet()){
            builder.addBeenRemovedFriendNotNotified(removedFriendNotNotified.nameByteString);
        }

        // --- 帮派新闻 ---

        for (ByteString newsBytes : news){
            builder.addServerNews(newsBytes);
        }

        for (PaddedAtomicReference<FastestCrossDungeonObject> ref : fastCrossArray){
            FastestCrossDungeonObject obj = ref.get();
            if (obj != null){
                builder.addFastCrossData(obj.encode());
            }
        }

        return builder.build();
    }

    @MultiThread
    GuildProto encode4Client(){
        GuildProto.Builder builder = encodeShared(false);

        for (int count : contributionBoughtCount){
            builder.addContributionGoodsAlreadyBought(count);
        }

        return builder.build();
    }

    ClientNewsProto encodeNews4Client(){
        ClientNewsProto.Builder builder = ClientNewsProto.newBuilder();
        for (ByteString bs : news){
            builder.addNews(bs);
        }

        return builder.build();
    }

    static Guild decode(GuildProto proto, GuildFlagDatas flagDatas,
            GuildContributionGoodsShop contributionShop,
            int challengeDungeonCount, TimeService timeService,
            IndividualServerConfig individualServerConfig){
        return new Guild(proto, flagDatas, contributionShop,
                challengeDungeonCount, timeService, individualServerConfig);
    }

    @Override
    public int hashCode(){
        return hashCode;
    }

    @Override
    public boolean equals(Object obj){
        return this == obj;
    }

    // --- gm ---

    public int gmGetVacancy(){
        return maxHeroCount - members.size();
    }

    public void gmSetContributionMoney(int money){
        synchronized (this){
            giftMoney = money;
        }
    }

    public void gmSetContributionGoods(int count){
        synchronized (this){
            giftGoods1 = giftGoods2 = giftGoods3 = giftGoods4 = count;
        }
    }

    public PaddedAtomicReference<FastestCrossDungeonObject> getFastestCrossDungeonObject(
            int sequence){
        assert sequence > 0 && sequence <= fastCrossArray.length: "Guild.getFastestCrossDungeonObject() invalid sequence";
        return fastCrossArray[sequence - 1];
    }

    public void updateFastCrossObject(ChallengeDungeonSceneData sceneData,
            Hero hero, int useTime){
        if (useTime <= 0){
            return; // 防御性
        }

        PaddedAtomicReference<FastestCrossDungeonObject> crossRef = fastCrossArray[sceneData.sequence - 1];

        FastestCrossDungeonObject old = crossRef.get();
        if (old == null || old.useTime > useTime){
            FastestCrossDungeonObject newObj = new FastestCrossDungeonObject(
                    sceneData.sequence, hero.getID(), hero.getNameBytes(),
                    hero.getNameByteString(), useTime);

            if (crossRef.compareAndSet(old, newObj)){
                logger.debug("更新挑战侠士本帮最快通关时间：{}", useTime);
                // 成功，广播变化
                broadcast(sceneData.getGuildFastCrossChangedMsg());
                return;
            } else{
                // 再尝试3次， 哥只能帮你到这里了
                for (int i = 0; i < 3; i++){
                    old = crossRef.get();
                    if (old == null || old.useTime > useTime){
                        if (crossRef.compareAndSet(old, newObj)){
                            logger.debug("更新挑战侠士本帮最快通关时间：{}", useTime);
                            // 成功，广播变化
                            broadcast(sceneData.getGuildFastCrossChangedMsg());
                            return;
                        }
                    } else{
                        return; // 条件不符，return出来
                    }
                }
            }
        }
    }

    void onMemberRemoved(long id){
        // 移除最快通关数据
        for (PaddedAtomicReference<FastestCrossDungeonObject> ref : fastCrossArray){
            FastestCrossDungeonObject obj = ref.get();
            if (obj != null && obj.id == id){
                ref.compareAndSet(obj, null);
            }
        }
    }

    @Override
    public boolean canAttack(IGuild target){
        if (this == target){
            return false;
        }

        if (friendGuild.containsKey(target)){
            return false;
        }

        return true;
    }

    @Override
    public byte[] getName(){
        return name;
    }

    @Override
    public boolean isTerritoryMaster(){
        return territoryWinCount.get() > 0;
    }
}
