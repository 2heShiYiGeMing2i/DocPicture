package app.game.module;

import static app.game.module.GemMessages.*;
import static app.protobuf.LogContent.LogEnum.OperateObject.GEM;
import static app.protobuf.LogContent.LogEnum.OperateType.*;

import org.jboss.netty.buffer.ChannelBuffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.data.SpriteStat;
import app.game.data.UpgradeData;
import app.game.data.UpgradeData.ReduceCostResult;
import app.game.data.gem.HeroGem;
import app.game.data.goods.GemGoodsData;
import app.game.data.goods.Goods;
import app.game.data.goods.GoodsAddHelper;
import app.game.data.goods.GoodsDatas;
import app.game.entity.Depot;
import app.game.entity.Hero;
import app.game.service.TimeService;
import app.game.service.log.LogService;
import app.utils.VariableConfig;

import com.google.inject.Inject;
import com.mokylin.sink.util.BufferUtil;
import com.mokylin.sink.util.Utils;

/**
 * @author Liwei
 *
 */
public class GemModule{

    private static final Logger logger = LoggerFactory
            .getLogger(GemModule.class);

    private final TimeService timeService;

    private final GoodsContainerModule goodsContainerModule;

    private final GemGoodsData[] gemArray;

    private final LogService logService;

    @Inject
    GemModule(TimeService timeService,
            GoodsContainerModule goodsContainerModule, GoodsDatas goodsDatas,
            LogService logService){
        this.timeService = timeService;
        this.goodsContainerModule = goodsContainerModule;
        this.logService = logService;

        gemArray = goodsDatas.getGems();
    }

    public void onMessage(final int sequenceID, final ChannelBuffer buffer,
            final HeroController hc){

        switch (sequenceID){
//            case C2S_GEM_MOVE:{
//                onGemMove(hc, buffer);
//                return;
//            }
//            case C2S_GEM_DEPOT_UPGRADE:{
//                onDepotGemUpgrade(hc, buffer);
//                return;
//            }
//            case C2S_GEM_UPGRADE:{
//                onGemUpgrade(hc, buffer);
//                return;
//            }
            default:{
                logger.error("BowModule模块收到未知消息: {}", sequenceID);
            }
        }
    }

    private void onGemMove(HeroController hc, ChannelBuffer buffer){
        Hero hero = hc.getHero();

        HeroGem heroGem = hero.getGem();
        if (heroGem == null){
            logger.warn("宝石穿戴，但是宝石系统还未开放");
            hc.sendMessage(ERR_MOVE_GEM_FAIL_GEM_NOT_OPEN);
            return;
        }

        int gemPos = BufferUtil.readVarInt32(buffer);
        if (gemPos < 0 || gemPos >= heroGem.getGemMaxCount()){
            logger.warn("宝石穿戴，宝石插槽位置无效");
            hc.sendMessage(ERR_MOVE_GEM_FAIL_INVALID_GEM_SLOT);
            return;
        }

        Depot depot = hero.getDepot();

        long ctime = timeService.getCurrentTime();

        Goods depotGoods = null;
        int depotPos = -1;
        if (buffer.readable()){
            depotPos = BufferUtil.readVarInt32(buffer);

            if (depot.isInvalidPos(depotPos)){
                logger.warn("宝石穿戴，背包物品位置无效");
                hc.sendMessage(ERR_MOVE_GEM_FAIL_INVALID_DEPOT_GOODS);
                return;
            }

            if (depot.isLocked(depotPos)){
                logger.warn("宝石穿戴，背包物品已被锁定");
                hc.sendMessage(ERR_MOVE_GEM_FAIL_INVALID_DEPOT_GOODS);
                return;
            }

            depotGoods = depot.get(depotPos);
            if (depotGoods == null
                    || !(depotGoods.getData() instanceof GemGoodsData)){
                logger.warn("宝石穿戴，背包物品不是宝石物品");
                hc.sendMessage(ERR_MOVE_GEM_FAIL_INVALID_DEPOT_GOODS);
                return;
            }

            if (depotGoods.isExpired(ctime)){
                // 虽然限定了宝石物品不能产出过期的物品，这里只是防御性处理
                logger.warn("宝石穿戴，背包物品已经过期");
                hc.sendMessage(ERR_MOVE_GEM_FAIL_INVALID_DEPOT_GOODS);
                return;
            }

            if (depotGoods.getData().getRequireLevel() > hero.getLevel()){
                logger.warn("宝石穿戴，英雄等级不足");
                hc.sendMessage(ERR_MOVE_GEM_FAIL_HERO_LEVEL_NOT_ENOUGH);
                return;
            }
        }

        Goods gemSlotGoods = heroGem.getGem(gemPos);

        if (gemSlotGoods == null){
            if (depotGoods == null){
                logger.warn("宝石穿戴，插槽上没有物品，也没有发背包物品");
                hc.sendMessage(ERR_MOVE_GEM_FAIL_GEM_NOT_FOUND);
                return;
            }
        } else{
            // 替换宝石
            if (depotGoods != null && gemSlotGoods.isSameGoods(depotGoods)){
                // 相同的宝石，什么事情都没发生
                hc.sendMessage(moveGemMsg(gemPos,
                        ((GemGoodsData) gemSlotGoods.getData()).getGemLevel()));
                return;
            }

            if (!depot.hasEnoughEmptyCount(1)){
                logger.warn("宝石穿戴，背包上没有空位放入换下的宝石");
                hc.sendMessage(ERR_MOVE_GEM_FAIL_DEPOT_FULL);
                return;
            }
        }

        // 将宝石从背包中扣除
        Goods toSet = depotGoods;
        if (depotGoods != null){
            if (depotGoods.getCount() > 1){
                toSet = depotGoods.split(1);
                hc.sendMessage(GoodsContainerMessages.setGoodsCountMsg(0,
                        depotPos, depotGoods.getCount()));
            } else{
                depot.set(depotPos, null);
                hc.sendMessage(GoodsContainerMessages.removeGoodsMsg(0,
                        depotPos));
            }
        }

        // 替换前的属性
        SpriteStat oldStat = heroGem.getTotalStat();

        int newGemLevel = heroGem.setGem(gemPos, toSet);
        // 成功消息
        hc.sendMessage(moveGemMsg(gemPos, newGemLevel));

        if (gemSlotGoods != null){
            // 插槽物品放入背包
            goodsContainerModule.addGoods(hero, gemSlotGoods, hc.getSender(),
                    hc.getHeroMiscModule(), INTERNAL, 0, ctime);
        }

        hc.getHeroFightModule().changeBaseStat(oldStat, heroGem.getTotalStat(),
                ctime);

        // 更新战斗力
        hc.getHeroFightModule().updateFightingAmount();
    }

    private void onDepotGemUpgrade(HeroController hc, ChannelBuffer buffer){

        Hero hero = hc.getHero();

        HeroGem heroGem = hero.getGem();
        if (heroGem == null){
            logger.warn("背包宝石升级，但是宝石系统还未开放");
            hc.sendMessage(ERR_UPGRADE_DEPOT_GEM_FAIL_GEM_NOT_OPEN);
            return;
        }

        int gemLevel = BufferUtil.readVarInt32(buffer);

        if (gemLevel <= 1 || gemLevel > gemArray.length){
            logger.warn("背包宝石升级，无效的宝石等级");
            hc.sendMessage(ERR_UPGRADE_DEPOT_GEM_FAIL_INVALID_LEVEL);
            return;
        }

        GemGoodsData data = gemArray[gemLevel - 1];
        UpgradeData upgradeData = data.getDepotGemUpgradeData();
        if (upgradeData == null){
            // 正常是不应该进来的，防御性
            logger.warn("背包宝石升级，upgradeData为null，神马情况");
            hc.sendMessage(ERR_UPGRADE_DEPOT_GEM_FAIL_INVALID_LEVEL);
            return;
        }

        int gemCount = BufferUtil.readVarInt32(buffer);

        // 如果包含不同绑定类型的物品，需要额外的一个位置放入
        int emptyPos = Utils.divide(gemCount, data.getMaxCount()) + 1;
        if (gemCount <= 0 || !hc.getDepot().hasEnoughEmptyCount(emptyPos)){
            logger.warn("背包宝石升级，背包空间不足");
            hc.sendMessage(ERR_UPGRADE_DEPOT_GEM_FAIL_DEPOT_FULL);
            return;
        }

        long ctime = timeService.getCurrentTime();
        String iEventId = logService.newTodoEventId(); // TODO 加日志
        ReduceCostResult result = upgradeData.tryReduceGoods("背包宝石升级",
                hc.getHeroMiscModule(), ctime, hero, hc.getSender(), buffer,
                goodsContainerModule,
                gemCount * upgradeData.getUpgradeGoodsCount(), GEM_MERGE,
                iEventId, true);

        switch (result.getStatus()){
            case GOODS_NOT_ENOUGH:{
                hc.sendMessage(ERR_UPGRADE_DEPOT_GEM_FAIL_GOODS_NOT_ENOUGH);
                return;
            }
            case LIJIN_NOT_ENOUGH:{
                hc.sendMessage(ERR_UPGRADE_DEPOT_GEM_FAIL_LIJIN_NOT_ENOUGH);
                return;
            }
            case YUANBAO_NOT_ENOUGH:{
                hc.sendMessage(ERR_UPGRADE_DEPOT_GEM_FAIL_YUANBAO_NOT_ENOUGH);
                return;
            }
            case INVALID_POS_COUNT:{
                hc.sendMessage(ERR_UPGRADE_DEPOT_GEM_FAIL_INVALID_POS);
                return;
            }
            case SUCCESS:{
                break;
            }
            case MONEY_NOT_ENOUGH:{
                hc.sendMessage(ERR_UPGRADE_DEPOT_GEM_FAIL_MONEY_NOT_ENOUGH);
                return;
            }
            case REAL_AIR_NOT_ENOUGH:{
                hc.sendMessage(ERR_UPGRADE_DEPOT_GEM_FAIL_REAL_AIR_NOT_ENOUGH);
                return;
            }
            default:{
                logger.error("背包宝石升级，遇到未知的失败类型，{}", result);
                hc.sendMessage(ERR_UPGRADE_DEPOT_GEM_FAIL_GOODS_NOT_ENOUGH);
                return;
            }
        }

        // 合成成功
        hc.sendMessage(GEM_DEPOT_UPGRADE);

        // 合成了多少个绑定的宝石
        int bindedCount = Utils.divide(result.getBindedGoodsCount(),
                upgradeData.getUpgradeGoodsCount());

        if (bindedCount > 0){
            GoodsAddHelper gemGoods = data
                    .newGemGoods(true, bindedCount, ctime);

            goodsContainerModule.addGoods(hero, gemGoods, hc.getSender(),
                    hc.getHeroMiscModule(), GEM_MERGE, 0, ctime);
        }

        int unbindedCount = gemCount - bindedCount;
        if (unbindedCount > 0){
            GoodsAddHelper gemGoods = data.newGemGoods(false, unbindedCount,
                    ctime);
            goodsContainerModule.addGoods(hero, gemGoods, hc.getSender(),
                    hc.getHeroMiscModule(), GEM_MERGE, 0, ctime);
        }

        logService.todo();
//        logService.writeOperateLog(GEM_MERGE, GEM, gemLevel, gemCount, 0, 0, 0,
//                hero);
    }

    private void onGemUpgrade(HeroController hc, ChannelBuffer buffer){
        Hero hero = hc.getHero();

        HeroGem heroGem = hero.getGem();
        if (heroGem == null){
            logger.warn("插槽宝石升级，但是宝石系统还未开放");
            hc.sendMessage(ERR_UPGRADE_GEM_FAIL_GEM_NOT_OPEN);
            return;
        }

        int gemPos = BufferUtil.readVarInt32(buffer);
        if (gemPos < 0 || gemPos >= heroGem.getGemMaxCount()){
            logger.warn("插槽宝石升级，宝石插槽位置无效");
            hc.sendMessage(ERR_UPGRADE_GEM_FAIL_INVALID_GEM_POS);
            return;
        }

        Goods gem = heroGem.getGem(gemPos);
        if (gem == null || !(gem.getData() instanceof GemGoodsData)){
            logger.warn("插槽宝石升级，宝石插槽上没有宝石");
            hc.sendMessage(ERR_UPGRADE_GEM_FAIL_GEM_NOT_FOUND);
            return;
        }

        long oldIdentifier = gem.getGoodsIdentifier();
        hero.getGoodsOwnership()
                .checkGoodsEnough(oldIdentifier, gem.getCount());

        GemGoodsData data = (GemGoodsData) gem.getData();

        GemGoodsData nextLevel = data.getNextLevel();
        if (nextLevel == null){
            logger.warn("插槽宝石升级，插槽宝石已经是最高级的了");
            hc.sendMessage(ERR_UPGRADE_GEM_FAIL_MAX_LEVEL);
            return;
        }

        if (nextLevel.getRequireLevel() > hero.getLevel()){
            logger.warn("插槽宝石升级，宝石升级后的穿戴等级大于英雄等级");
            hc.sendMessage(ERR_UPGRADE_GEM_FAIL_HERO_LEVEL_NOT_ENOUGH);
            return;
        }

        UpgradeData upgradeData = nextLevel.getGemSlotUpgradeData();
        if (upgradeData == null){
            // 正常是不应该进来的，防御性
            logger.warn("插槽宝石升级，upgradeData为null，神马情况");
            hc.sendMessage(ERR_UPGRADE_GEM_FAIL_MAX_LEVEL);
            return;
        }

        long ctime = timeService.getCurrentTime();
        String iEventId = logService.newTodoEventId(); // TODO 加日志
        ReduceCostResult result = upgradeData.tryReduceCostAllowBindedYuanbao("插槽宝石升级",
                hc.getHeroMiscModule(), ctime, hero, hc.getSender(), buffer,
                goodsContainerModule, GEM_UPDATE, iEventId);

        switch (result.getStatus()){
            case GOODS_NOT_ENOUGH:{
                hc.sendMessage(ERR_UPGRADE_GEM_FAIL_GOODS_NOT_ENOUGH);
                return;
            }
            case LIJIN_NOT_ENOUGH:{
                hc.sendMessage(ERR_UPGRADE_GEM_FAIL_LIJIN_NOT_ENOUGH);
                return;
            }
            case YUANBAO_NOT_ENOUGH:{
                hc.sendMessage(ERR_UPGRADE_GEM_FAIL_YUANBAO_NOT_ENOUGH);
                return;
            }
            case INVALID_POS_COUNT:{
                hc.sendMessage(ERR_UPGRADE_GEM_FAIL_INVALID_POS);
                return;
            }
            case SUCCESS:{
                break;
            }
            case MONEY_NOT_ENOUGH:{
                hc.sendMessage(ERR_UPGRADE_GEM_FAIL_MONEY_NOT_ENOUGH);
                return;
            }
            case REAL_AIR_NOT_ENOUGH:{
                hc.sendMessage(ERR_UPGRADE_GEM_FAIL_REAL_AIR_NOT_ENOUGH);
                return;
            }
            default:{
                logger.error("插槽宝石升级，遇到未知的失败类型，{}", result);
                hc.sendMessage(ERR_UPGRADE_GEM_FAIL_GOODS_NOT_ENOUGH);
                return;
            }
        }

        // 合成成功
        hc.sendMessage(upgradeGemMsg(gemPos, nextLevel.getGemLevel()));

        boolean binded = gem.isBinded() || result.hasBindedGoods();
        Goods gemGoods = nextLevel.newGemGoods(binded, 1, ctime).create();

        hero.getGoodsOwnership().changeIdentifier(oldIdentifier,
                gemGoods.getGoodsIdentifier(), gemGoods.getCount(), GEM_UPDATE,
                ctime, gemGoods.needLog());

        // 替换前的属性
        SpriteStat oldStat = heroGem.getTotalStat();

        heroGem.setGem(gemPos, gemGoods);

        hc.getHeroFightModule().changeBaseStat(oldStat, heroGem.getTotalStat(),
                ctime);

        // 更新战斗力
        hc.getHeroFightModule().updateFightingAmount();

        logService.todo();
//        logService.writeOperateLog(GEM_UPDATE, GEM, gemPos
//                / VariableConfig.GEM_PART_SLOT_COUNT, gemPos
//                % VariableConfig.GEM_PART_SLOT_COUNT, nextLevel.getGemLevel(),
//                0, 0, hero);
    }
}
