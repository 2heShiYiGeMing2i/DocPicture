package app.game.module.auction;

import static com.mokylin.sink.util.Utils.short2Int;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AuctionTypeHelper{

    private static final Logger logger = LoggerFactory
            .getLogger(AuctionTypeHelper.class);

    private static final int ALL = short2Int(0, 999999);
    private static final int BU_JING_YUN_EQUIPMENT = short2Int(10, 19);
    private static final int NIE_FENG_EQUIPMENT = short2Int(20, 29);
    private static final int CHU_CHU_EQUIPMENT = short2Int(30, 39);
    private static final int DI_ER_MENG_EQUIPMENT = short2Int(40, 49);
    private static final int SPELL_BOOK = short2Int(70, 79);
    private static final int MOUNT_EQUIPMENT = short2Int(80, 89);
    private static final int GENERAL_EQUIPMENT = short2Int(90, 95);
    private static final int CURRENCY = short2Int(98, 99);
    private static final int TOOL = short2Int(101, 119);
    private static final int OTHER = short2Int(121, 127);

    /**
     * 一个请求是否是范围请求, 是的话, 返回short2Int [low, high]. 不是的话, 返回-1
     * @param query
     * @return
     */
    public static int isAuctionTypeRangeQuery(int query){
        switch (query){
            case 0:
                return ALL;

            case 1:
                return BU_JING_YUN_EQUIPMENT;

            case 2:
                return NIE_FENG_EQUIPMENT;

            case 3:
                return CHU_CHU_EQUIPMENT;

            case 4:
                return DI_ER_MENG_EQUIPMENT;

            case 7:
                return SPELL_BOOK;

            case 8:
                return MOUNT_EQUIPMENT;

            case 9:
                return GENERAL_EQUIPMENT;

            case 97:
                return CURRENCY;

            case 100:
                return TOOL;

            case 120:
                return OTHER;

            default:
                return -1;
        }
    }
}
