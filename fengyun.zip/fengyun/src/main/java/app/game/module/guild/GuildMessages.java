package app.game.module.guild;

import static com.mokylin.sink.util.BufferUtil.*;

import java.util.Set;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.module.Modules;
import app.protobuf.GuildContent.ClientGuildListProto;
import app.protobuf.GuildContent.ClientNewsProto;
import app.protobuf.GuildContent.GuildProto;

import com.mokylin.sink.util.annotation.MaybeNull;

public class GuildMessages{
    public static final int MODULE_ID = Modules.GUILD_MODULE_ID;

    private GuildMessages(){
    }

    // ---- 创建帮派 ----

    /**
     * 创建帮派. 当前必须没有帮派. 客户端需本地判断钱/等级/帮派名字合法/帮旗名字合法 
     * 
     * 附带
     * bool 是否使用银两创建 (false则使用元宝)
     * 
     * UTF 帮派名字.2-7字 (客户端需已经前后去空, 且过滤了关键字, 有关键字就本地弹错, 不要发过来)
     * 
     * UTF 帮旗名字.2-6字 (同上)
     * 
     * byte 帮旗样式 (0-9)
     */
    static final int C2S_CREATE_GUILD = 1;

    /**
     * 创建帮派失败, 附带varint32 失败原因
     * 
     * 1. 你有帮派
     * 2. 钱不够
     * 3. 等级不够
     * 4. 帮派名字字数不对
     * 5. 帮旗名字字数不对
     * 6. 帮派名字已经存在
     * 7. 帮旗名字已经存在
     * 8. 非法帮旗样式 必须0-9
     */
    static final int S2C_CREATE_GUILD_FAIL = 1;
    static final ChannelBuffer ERROR_CREATE_GUILD_YOU_HAVE_GUILD = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_CREATE_GUILD_FAIL, 1);
    static final ChannelBuffer ERROR_CREATE_GUILD_NOT_ENOUGH_MONEY = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_CREATE_GUILD_FAIL, 2);
    static final ChannelBuffer ERROR_CREATE_GUILD_NOT_ENOUGH_LEVEL = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_CREATE_GUILD_FAIL, 3);
    static final ChannelBuffer ERROR_CREATE_GUILD_ILLEGAL_GUILD_NAME = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_CREATE_GUILD_FAIL, 4);
    static final ChannelBuffer ERROR_CREATE_GUILD_ILLEGAL_FLAG_NAME = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_CREATE_GUILD_FAIL, 5);
    static final ChannelBuffer ERROR_CREATE_GUILD_GUILD_NAME_EXISTED = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_CREATE_GUILD_FAIL, 6);
    static final ChannelBuffer ERROR_CREATE_GUILD_FLAG_NAME_EXISTED = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_CREATE_GUILD_FAIL, 7);
    static final ChannelBuffer ERROR_CREATE_GUILD_ILLEGAL_FLAG_KIND = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_CREATE_GUILD_FAIL, 8);

    /**
     * 帮派创建成功. 将自己帮派设为消息发过来的帮派. 不会向创建者发送入帮消息了
     * 
     * 服务器会另外发送扣钱消息, 这条消息不需要处理
     * 
     * 附带
     * 
     * UTF 帮派名字 (和客户端请求的不一样, 前面加上了区服id)
     * UTF 帮旗名字 (同上)
     * byte 帮旗样式
     */
    static final int S2C_CREATE_GUILD_SUCCESS = 2;

    /**
     * 大家飘字: 江湖风起云涌，又一个新势力【帮派名称】崛起了
     * 
     * 附带
     * varint64 帮主ID
     * UTF 帮主名字
     * UTFBytes 帮派名字
     */
    static final int S2C_NEW_GUILD_CREATED_BROADCAST = 3;

    // ---- 帮派列表 ----

    /**
     * 请求帮派列表. 客户端缓存10秒, 关掉界面再打开, 10秒内还是用上次请求时返回的数据. 
     * 仅在打开界面时判断缓存是否过期, 开着界面的时候不需要自动刷新
     * 
     * 没有附带信息
     */
    static final int C2S_GET_GUILD_LIST = 2;

    /**
     * 回复帮派列表信息
     * 
     * 附带
     * 
     * ClientGuildListProto
     */
    static final int S2C_REPLY_GUILD_LIST = 4;

    // ---- 获取自己帮派的详细信息 ----

    /**
     * 获取自己的帮派详细信息, 包括成员列表, 帮旗, 等级, 已捐献物品数量等等
     * 
     * 请求时当前必须在个帮派中.
     * 
     * 数据缓存10秒, 打开着成员列表这个界面时, 每10秒请求一次
     * 
     * 从收到返回开始计时, 不是从请求开始
     * 离开帮派后, 计时清零. 防止退出帮派/又进入个新的帮派后, 打开成员列表没东西. 但在前一个请求没返回前, 不能再请求
     * 
     * 没有附带信息
     */
    static final int C2S_GET_SELF_GUILD_INFO = 3;

    /**
     * 请求帮派信息失败, 附带varint32 错误码
     * 
     * 1. 请求太频繁
     * 2. 你当前没有帮派
     * 3. 服务器内部错误, 不要自动重试
     */
    static final int S2C_GET_SELF_GUILD_INFO_FAIL = 5;
    static final ChannelBuffer ERROR_GET_SELF_GUILD_INFO_TOO_FREQUENT = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_GET_SELF_GUILD_INFO_FAIL, 1);
    static final ChannelBuffer ERROR_GET_SELF_GUILD_INFO_NO_GUILD = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_GET_SELF_GUILD_INFO_FAIL, 2);
    static final ChannelBuffer ERROR_GET_SELF_GUILD_INFO_INTERNAL_ERROR = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_GET_SELF_GUILD_INFO_FAIL, 3);

    /**
     * 回复帮派详细信息. 消息已压缩
     * 
     * 附带
     * 
     * GuildProto
     */
    static final int S2C_REPLY_SELF_GUILD_INFO = 6;

    // ----- 请求加入帮派 -----

    /**
     * 请求加入别的帮派, 返回前不能再请求, 或者回复别的帮派的邀请
     * 
     * 请求时必须自己没有帮派, 且要求加入的帮派人数没满
     * 
     * 附带
     * 
     * UTFBytes 要求加入的帮派名字
     */
    static final int C2S_REQUEST_JOIN = 4;

    /**
     * 要求加入帮派失败, 附带varint32 错误码
     * 
     * 1. 你有帮派了
     * 2. 你请求加入的帮派不存在
     * 3. 你请求加入的帮派满人了
     * 4. 帮派不是自动接受入帮申请, 且负责人都不在线
     * 5. 你已经申请过这个帮派了
     * 6. 你的等级不够
     * 7. 板块战期间, 不能进入
     * 8. 不能加入别的联服的帮派
     */
    static final int S2C_REQUEST_JOIN_FAIL = 7;
    static final ChannelBuffer ERROR_REQUEST_JOIN_YOU_HAVE_GUILD = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_REQUEST_JOIN_FAIL, 1);
    static final ChannelBuffer ERROR_REQUEST_JOIN_GUILD_NOT_EXIST = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_REQUEST_JOIN_FAIL, 2);
    static final ChannelBuffer ERROR_REQUEST_JOIN_GUILD_FULL = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_REQUEST_JOIN_FAIL, 3);
    static final ChannelBuffer ERROR_REQUEST_JOIN_LEADER_NOT_ONLINE = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_REQUEST_JOIN_FAIL, 4);
    static final ChannelBuffer ERROR_REQUEST_JOIN_ALREADY_APPLIED = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_REQUEST_JOIN_FAIL, 5);
    static final ChannelBuffer ERROR_REQUEST_JOIN_LEVEL_TOO_LOW = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_REQUEST_JOIN_FAIL, 6);
    static final ChannelBuffer ERROR_REQUEST_IN_BATTLE = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_REQUEST_JOIN_FAIL, 7);
    static final ChannelBuffer ERROR_REQUEST_OTHER_UNION = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_REQUEST_JOIN_FAIL, 8);

    /**
     * 请求入帮成功, 紧接着会收到S2C_YOU_JOIN_GUILD消息通知你进入了一个帮派
     * 
     * 仅供解锁C2S_REQUEST_JOIN. 并展示"恭喜，XXX帮派已同意您的入帮请求" 
     * 
     * 没有附带信息
     */
    static final int S2C_REQUEST_JOIN_SUCCESS = 8;
    static final ChannelBuffer requestJoinSuccess = onlySendHeaderMessage(
            MODULE_ID, S2C_REQUEST_JOIN_SUCCESS);

    /**
     * 入帮申请已经转发给了相关负责人
     * 
     * 客户端需要缓存自己已经申请过且申请结果是S2C_REQUEST_JOIN_SUCCESS_WAIT_OTHER_REPLY的帮派, 保存2分钟. 
     * 2分钟后自动删除, 服务器不会再发消息通知
     * 如果期间收到了对方明确的回复, 不管是同意还是拒绝, 都删掉这个帮派的缓存
     */
    static final int S2C_REQUEST_JOIN_SUCCESS_WAIT_OTHER_REPLY = 9;
    static final ChannelBuffer requestJoinSuccessWaitOtherReply = onlySendHeaderMessage(
            MODULE_ID, S2C_REQUEST_JOIN_SUCCESS_WAIT_OTHER_REPLY);

    /**
     * 广播给帮派所有人, 有人入帮了.
     * 
     * 仅供展示提醒. 欢迎【XXX玩家名】加入本帮，本帮变的更加强大了
     * 
     * 如果打开着帮派成员界面, 则马上重新请求一次成员列表
     * 
     * 附带
     * 
     * UTFBytes 入帮的人的名字
     */
    static final int S2C_OTHER_JOIN_GUILD = 10;

    /**
     * 加入了帮派后 (可能是申请通过, 可能是别人邀请你(可能自动接受邀请, 可能自己手动同意的邀请))
     * 都会收到这条消息
     * 
     * 如果此时打开着帮派界面, 请求一次成员列表
     * 
     * 删掉所有邀请加我入他们帮的icon
     * 
     *  
     * 附带
     * 
     * UTF 新帮派的名字 (需要在自己在场景中的角色头上加上帮派名)
     * 
     * 下面是所有这个帮派的敌帮和盟帮, 读法
     * 
     * while(byteArray.available){
     *  var v : int = byteArray.readVarint32();
     *  var len : int = v >>> 1;
     *  var name : string = byteArray.readUTFBytes(len); // 这个帮派的名字
     *  var isFriend:Boolean = (v & 1) == 1; // 这个帮派是否是盟帮. 否 = 敌帮
     * }
     */
    static final int S2C_YOU_JOIN_GUILD = 11;

    /**
     * 收到了别人的入帮请求. 2分钟后去掉这个请求, 服务器不会再发送通知
     * 
     * 附带
     * 
     * varint64 对方id
     * varint32 对方职业
     * varint32 对方等级
     * UTFBytes 对方名字
     */
    static final int S2C_RECEIVE_JOIN_REQUEST = 12;

    // ----- 回复入帮申请 -----

    /**
     * 回复别人的入帮申请, 必须等待服务器返回, 才能再回复其他的入帮申请(包括全部同意)
     * 
     * 不管服务器有没有返回, 客户端自己删掉这个申请, 就算服务器返回失败, 也不可能再回复一次
     * 
     * 如果是拒绝, 则服务器没有返回, 
     * 
     * 附带
     * 
     * varint64 对方的id
     * bool 是否同意
     */
    static final int C2S_REPLY_JOIN_REQUEST = 5;

    /**
     * 回复别人的入帮申请失败. 一定是同意才会收到. 失败不会有返回
     * 
     * 附带varint32 错误码
     * 
     * 1. 你当前没有帮派
     * 2. 你不是帮主或副帮主
     * 3. 申请已过期
     * 4. 对方已经在你帮派中了 (可能通过其他途径加入)
     * 5. 对方已经在其他帮派中了
     * 6. 对方已经不在线
     * 7. 自己帮派人满了
     * 8. 板块战期间
     */
    static final int S2C_REPLY_JOIN_REQUEST_FAIL = 13;
    static final ChannelBuffer ERROR_REPLY_JOIN_REQUEST_YOU_HAVE_NO_GUILD = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_REPLY_JOIN_REQUEST_FAIL, 1);
    static final ChannelBuffer ERROR_REPLY_JOIN_REQUEST_YOU_HAVE_NO_RIGHT = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_REPLY_JOIN_REQUEST_FAIL, 2);
    static final ChannelBuffer ERROR_REPLY_JOIN_REQUEST_REQUEST_EXPIRED = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_REPLY_JOIN_REQUEST_FAIL, 3);
    static final ChannelBuffer ERROR_REPLY_JOIN_REQUEST_ALREADY_IN_YOUR_GUILD = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_REPLY_JOIN_REQUEST_FAIL, 4);
    static final ChannelBuffer ERROR_REPLY_JOIN_REQUEST_IN_OTHER_GUILD = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_REPLY_JOIN_REQUEST_FAIL, 5);
    static final ChannelBuffer ERROR_REPLY_JOIN_REQUEST_TARGET_OFFLINE = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_REPLY_JOIN_REQUEST_FAIL, 6);
    static final ChannelBuffer ERROR_REPLY_JOIN_REQUEST_GUILD_FULL = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_REPLY_JOIN_REQUEST_FAIL, 7);
    static final ChannelBuffer ERROR_REPLY_JOIN_REQUEST_IN_BATTLE = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_REPLY_JOIN_REQUEST_FAIL, 8);

    /**
     * 同意对方入帮申请成功, 马上就会收到对方入帮的广播.
     * 
     * 解锁C2S_REPLY_JOIN_REQUEST
     * 
     * 没有附带信息
     */
    static final int S2C_REPLY_JOIN_REQUEST_SUCCESS = 14;
    static final ChannelBuffer replyJoinRequestSuccess = onlySendHeaderMessage(
            MODULE_ID, S2C_REPLY_JOIN_REQUEST_SUCCESS);

    /**
     * 帮主/副帮主 拒绝了别人的入帮申请后, 申请者会收到这条
     * 
     * 收到后删掉对应的帮派的申请缓存, 使自己能再次发出入这个帮的申请
     * 
     * 显示提示 很抱歉，XXX帮派拒绝了您的入帮申请
     * 
     * 只有自己当前没有帮派时才会收到
     * 
     * 附带
     * 
     * UTFBytes 帮派名字
     */
    static final int S2C_OTHER_REJECTED_YOUR_JOIN_REQUEST = 15;

    /**
     * 帮主/副帮主 同意了别人的入帮申请后, 申请者会收到这条
     * 
     * 紧接着会收到S2C_YOU_JOIN_GUILD
     * 
     * 提示 恭喜，XXX帮派已同意您的入帮请求
     * 
     * 附带
     * 
     * UTFBytes 帮派名字
     */
    static final int S2C_OTHER_ACCEPTED_YOUR_JOIN_REQUEST = 16;

    // ----- 邀请别人进入帮派 -----

    /**
     * 邀请别人加入帮派, 只有当前有帮派且是帮主或副帮主时才能发送. 
     * 
     * 必须要等服务器返回才能再发送别的邀请
     * 
     * 附带
     * varint64 对方id
     */
    static final int C2S_INVITE_JOIN = 6;

    /**
     * 邀请失败, 附带varint32 错误码
     * 
     * 1. 你没有帮派
     * 2. 你不是帮主或副帮主
     * 3. 帮派人已经满了
     * 4. 对方不在线
     * 5. 对方已经在你帮派里了
     * 6. 对方在别的帮派里
     * 7. 已经邀请过对方了 
     * 8. 对方等级不够
     * 9. 对方设置了 禁止被别人邀请加入帮派
     * 10. 板块战期间
     * 11. 对方是别的联服的
     */
    static final int S2C_INVITE_JOIN_FAIL = 17;
    static final ChannelBuffer ERROR_INVITE_JOIN_YOU_HAVE_NO_GUILD = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_INVITE_JOIN_FAIL, 1);
    static final ChannelBuffer ERROR_INVITE_JOIN_YOU_HAVE_NO_RIGHT = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_INVITE_JOIN_FAIL, 2);
    static final ChannelBuffer ERROR_INVITE_JOIN_GUILD_FULL = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_INVITE_JOIN_FAIL, 3);
    static final ChannelBuffer ERROR_INVITE_JOIN_TARGET_NOT_ONLINE = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_INVITE_JOIN_FAIL, 4);
    static final ChannelBuffer ERROR_INVITE_JOIN_TARGET_IN_YOUR_GUILD = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_INVITE_JOIN_FAIL, 5);
    static final ChannelBuffer ERROR_INVITE_JOIN_TARGET_IN_OTHER_GUILD = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_INVITE_JOIN_FAIL, 6);
    static final ChannelBuffer ERROR_INVITE_JOIN_ALREADY_INVITED = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_INVITE_JOIN_FAIL, 7);
    static final ChannelBuffer ERROR_INVITE_JOIN_OTHER_LEVEL_TOO_LOW = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_INVITE_JOIN_FAIL, 8);
    static final ChannelBuffer ERROR_INVITE_JOIN_OTHER_FORBID_BEEN_INVITED = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_INVITE_JOIN_FAIL, 9);
    static final ChannelBuffer ERROR_INVITE_JOIN_IN_BATTLE = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_INVITE_JOIN_FAIL, 10);
    static final ChannelBuffer ERROR_INVITE_JOIN_OTHER_UNION = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_INVITE_JOIN_FAIL, 11);

    /**
     * 邀请成功, 对方是自动接受邀请的
     * 紧接着就会收到S2C_OTHER_JOIN_GUILD对方加入帮派的消息
     * 
     * 没有附带信息
     */
    static final int S2C_INVITE_JOIN_SUCCESS = 18;
    static final ChannelBuffer inviteJoinSuccess = onlySendHeaderMessage(
            MODULE_ID, S2C_INVITE_JOIN_SUCCESS);

    /**
     * 邀请成功, 对方不是自动接受邀请的, 需要等待对方的回复
     * 
     * 客户端需要自己缓存自己邀请过的人的id, 缓存2分钟, 2分钟后删掉. 过期时, 服务器不会再发消息通知
     * 
     * 没有附带信息
     */
    static final int S2C_INVITE_JOIN_SUCCESS_AND_WAIT_OTHER_REPLY = 19;
    static final ChannelBuffer inviteJoinSuccessAndWaitOtherReply = onlySendHeaderMessage(
            MODULE_ID, S2C_INVITE_JOIN_SUCCESS_AND_WAIT_OTHER_REPLY);

    /**
     * 收到别的帮派的入帮邀请
     * 
     * 附带
     * 
     * varint64 对方id
     * UTF 对方玩家名字
     * varint32 职业
     * varint32 帮旗等级
     * UTFBytes 帮派名字
     */
    static final int S2C_RECEIVE_JOIN_INVITE = 20;

    // ----- 回复别人的邀请 -----

    /**
     * 回复收到的入帮邀请, 在收到返回前不能再回复邀请
     * 
     * 不管结果如何, 客户端在本地删掉这个邀请
     * 
     * 如果是拒绝, 则没有返回
     * 
     * 附带
     * 
     * bool 是否同意
     * UTFBytes 对方帮派名字
     */
    static final int C2S_REPLY_JOIN_INVITE = 7;

    /**
     * 回复入帮邀请失败, 只有同意才会收到
     * 
     * 附带varint32 错误码
     * 
     * 1. 你已经有帮派了
     * 2. 对方帮派已经满了
     * 3. 邀请过期
     * 4. 你返回的帮派不存在
     * 5. 板块战期间
     */
    static final int S2C_REPLY_JOIN_INVITE_FAIL = 21;
    static final ChannelBuffer ERROR_REPLY_JOIN_INVITE_YOU_HAVE_GUILD = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_REPLY_JOIN_INVITE_FAIL, 1);
    static final ChannelBuffer ERROR_REPLY_JOIN_INVITE_TARGET_GUILD_FULL = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_REPLY_JOIN_INVITE_FAIL, 2);
    static final ChannelBuffer ERROR_REPLY_JOIN_INVITE_INVITE_EXPIRED = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_REPLY_JOIN_INVITE_FAIL, 3);
    static final ChannelBuffer ERROR_REPLY_JOIN_INVITE_GUILD_NOT_EXIST = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_REPLY_JOIN_INVITE_FAIL, 4);
    static final ChannelBuffer ERROR_REPLY_JOIN_INVITE_IN_BATTLE = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_REPLY_JOIN_INVITE_FAIL, 5);

    /**
     * 回复同意进入帮派成功, 解锁C2S_REPLY_JOIN_INVITE, 紧接着会收到S2C_YOU_JOIN_GUILD
     * 
     * 没有附带信息
     */
    static final int S2C_REPLY_JOIN_INVITE_SUCCESS = 22;
    static final ChannelBuffer replyJoinInviteSuccess = onlySendHeaderMessage(
            MODULE_ID, S2C_REPLY_JOIN_INVITE_SUCCESS);

    /**
     * 发给别人的入帮邀请, 被别人拒绝了. 从本地删除自己发送给他的入帮邀请缓存, 使自己能再次邀请他
     * 
     * 可能玩家下线再上, 导致没有邀请过的人的缓存, 多发了个对方名字, 供显示被拒绝提示
     * 
     * 附带
     * varint64 对方id
     * UTFBytes 对方名字
     */
    static final int S2C_OTHER_REJECTED_YOUR_JOIN_INVITE = 23;

    /**
     * 拒绝所有邀请我入他们帮的邀请, 没有附带信息, 服务器没有返回. 发送后从自己这里删除所有的邀请
     * 
     * 如果只有一条邀请, 则转化为针对他们帮派的拒绝消息 C2S_REPLY_JOIN_INVITE
     */
    static final int C2S_REJECT_ALL_JOIN_INVITE = 29;

    /**
     * 别人同意了你的入帮邀请. 发送给主动邀请别人的人
     * 
     * 只需要展示 恭喜, xxx同意了你的帮派邀请
     * 
     * 附带
     * 
     * UTFBytes 对方名字
     */
    static final int S2C_OTHER_ACCEPTED_YOUR_JOIN_INVITE = 89;

    // ----- 离开帮派 -----

    /**
     * 要离开帮派, 没有附带消息
     */
    static final int C2S_LEAVE_GUILD = 8;

    /**
     * 离开帮派失败, 附带varint32 错误码
     * 
     * 1. 你本来就没有帮派
     * 2. 你是帮主
     * 3. 帮派战期间（包括板块战，无双城，龙城）
     */
    static final int S2C_LEAVE_GUILD_FAIL = 24;
    static final ChannelBuffer ERROR_LEAVE_GUILD_YOU_HAVE_NO_GUILD = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_LEAVE_GUILD_FAIL, 1);
    static final ChannelBuffer ERROR_LEAVE_GUILD_YOU_ARE_LEADER = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_LEAVE_GUILD_FAIL, 2);
    static final ChannelBuffer ERROR_LEAVE_GUILD_IN_BATTLE = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_LEAVE_GUILD_FAIL, 3);

    /**
     * 离开帮派成功, 自己把自己的帮派设为空
     */
    static final int S2C_LEAVE_GUILD_SUCCESS = 25;
    static final ChannelBuffer leaveGuildSuccess = onlySendHeaderMessage(
            MODULE_ID, S2C_LEAVE_GUILD_SUCCESS);

    /**
     * 其他人离开了帮派, 广播给在帮派中的人, 收到后如果当前打开着帮派成员列表, 则马上刷新一下
     * 
     * 附带
     * UTFBytes 
     */
    static final int S2C_OTHER_LEAVE_GUILD_BROADCAST = 26;

    // ----- 踢出帮派 -----

    /**
     * 将人踢出帮派. 客户端需要自己判断权限以及对方的职位. 也不能踢自己 
     * 
     * 服务器返回前不能再发送踢人请求
     * 
     * 附带
     * 
     * varint64 要踢的人id
     */
    static final int C2S_KICK_MEMBER = 9;

    /**
     * 踢人失败, 附带varint32 错误码
     * 
     * 1. 你没有帮派
     * 2. 你没有权限 (帮主或副帮主才能踢人) (如果要踢有官职的必须是帮主) (不能踢自己)
     * 3. 帮中没有你要踢的这个人
     * 4. 帮派战期间（包括板块战，无双城，龙城）
     */
    static final int S2C_KICK_MEMBER_FAIL = 27;
    static final ChannelBuffer ERROR_KICK_MEMBER_NOT_IN_GUILD = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_KICK_MEMBER_FAIL, 1);
    static final ChannelBuffer ERROR_KICK_MEMBER_YOU_HAVE_NO_RIGHT = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_KICK_MEMBER_FAIL, 2);
    static final ChannelBuffer ERROR_KICK_MEMBER_TARGET_NOT_IN_GUILD = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_KICK_MEMBER_FAIL, 3);
    static final ChannelBuffer ERROR_KICK_MEMBER_IN_BATTLE = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_KICK_MEMBER_FAIL, 4);

    /**
     * 踢人成功, 紧接着会收到S2C_SOMEONE_BEEN_KICKED的广播
     * 
     * 没有附带信息
     */
    static final int S2C_KICK_MEMBER_SUCCESS = 28;
    static final ChannelBuffer kickMemberSuccess = onlySendHeaderMessage(
            MODULE_ID, S2C_KICK_MEMBER_SUCCESS);

    /**
     * 被踢的人, 收到这条. 将自己的帮派设为空, 角色名字上面不要有帮派. 如果打开着帮派页面, 改为创建帮派页面
     * 
     * 附带
     * 
     * UTFBytes 踢你的人的名字
     */
    static final int S2C_YOU_BEEN_KICKED = 29;

    /**
     * 有人被提出帮派了, 帮派中所有人收到广播, 被踢的不会收到
     * 
     * 收到这条时, 如果正打开着帮派成员列表, 则刷新.
     * 
     * 附带
     * 
     * UTF 主动踢人的人名
     * UTFBytes 被踢的人名
     */
    static final int S2C_SOMEONE_BEEN_KICKED_BROADCAST = 30;

    // ----- 设置职位 -----

    /**
     * 设置别人的职位, 只有帮主才能执行这操作. 必须等待服务器返回才能继续设置
     * 
     * 附带
     * 
     * varint64 要换的人的id
     * varint32 目标职位 0 帮众, 1 堂主, 2 副帮主, 3 帮主
     */
    static final int C2S_SET_POSITION = 10;

    /**
     * 设置失败, 附带varint32 错误码
     * 
     * 1. 你没有帮派
     * 2. 你不是帮主
     * 3. 对应id的人不在你帮派中
     * 4. 职位非法, 必须是0-3
     * 5. 目标已经是那个职位了
     * 6. 不能改自己的职位
     * 7. 自己是无双城主
     * 8. 帮派战期间（包括板块战，无双城，龙城）
     * 9. 自己是龙城城主
     */
    static final int S2C_SET_POSITION_FAIL = 31;
    static final ChannelBuffer ERROR_SET_POSITION_YOU_HAVE_NOT_GUILD = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_SET_POSITION_FAIL, 1);
    static final ChannelBuffer ERROR_SET_POSITION_YOU_HAVE_NO_RIGHT = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_SET_POSITION_FAIL, 2);
    static final ChannelBuffer ERROR_SET_POSITION_TARGET_NOT_FOUND = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_SET_POSITION_FAIL, 3);
    static final ChannelBuffer ERROR_SET_POSITION_ILLEGAL_POST = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_SET_POSITION_FAIL, 4);
    static final ChannelBuffer ERROR_SET_POSITION_TARGET_ALREADY_THAT_POST = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_SET_POSITION_FAIL, 5);
    static final ChannelBuffer ERROR_SET_POSITION_CANNOT_SET_SELF = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_SET_POSITION_FAIL, 6);
    static final ChannelBuffer ERROR_SET_POSITION_IS_WS_CITY_MASTER = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_SET_POSITION_FAIL, 7);
    static final ChannelBuffer ERROR_SET_POSITION_IN_BATTLE = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_SET_POSITION_FAIL, 8);
    static final ChannelBuffer ERROR_SET_POSITION_IS_LONG_CITY_MASTER = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_SET_POSITION_FAIL, 9);

    /**
     * 设置成功, 解锁. 接下来全帮会收到S2C_POSITION_CHANGE_BROADCAST
     * 
     * 如果给别人的新职位是帮主,则提示 您将帮主禅让给了：XXXX玩家名
     */
    static final int S2C_SET_POSITION_SUCCESS = 32;
    static final ChannelBuffer setPositionSuccess = onlySendHeaderMessage(
            MODULE_ID, S2C_SET_POSITION_SUCCESS);

    /**
     * 帮中职位变动, 收到后如果正打开着帮派成员列表, 则刷新
     * 需要根据里面的职位, 和被设置职位的人, 显示对应的提醒.
     * 
     * 如果职位是帮主, 且被设置的人是自己, 显示　恭喜您被提升为【帮主】
     * 不然则显示　本帮帮主变更，欢迎新帮主：XXXXX
     * 
     * 其他职位, 如果被设置的人是自己, 则显示 您在帮中的职位变更为：XXXX
     * 不然则显示 本帮XXX被任命为XXX职位
     * 
     * 附带
     * 
     * varint64 被改的人id, 用来和自己的id比对
     * varint32 目标职位 0 帮众, 1 堂主, 2 副帮主, 3 帮主
     * UTFBytes 被改的人名字
     * 
     */
    static final int S2C_POSITION_CHANGE_BROADCAST = 33;

    /**
     * 如果某人被设为副帮主或堂主时, 此职位有人, 则原来的人会收到这条, 需要显示 您在帮中的职位变更为：普通帮众
     * 
     * 没有附带信息
     */
    static final int S2C_YOUR_POST_LOST = 34;
    static final ChannelBuffer yourPostLost = onlySendHeaderMessage(MODULE_ID,
            S2C_YOUR_POST_LOST);

    // ----- 设置自动接受入帮邀请 -----

    /**
     * 将自己的是否自动接受入帮邀请 设为 是
     * 
     * 没有返回
     */
    static final int C2S_SET_AUTO_ACCEPT_INVITE_TO_TRUE = 11;

    /**
     * 将自己的是否接受入帮邀请 设为否
     * 
     * 没有返回
     */
    static final int C2S_SET_AUTO_ACCEPT_INVITE_TO_FALSE = 12;

    // ----- 设置自动同意入帮申请 -----

    /**
     * 设置帮派是否自动同意别人的入帮申请. 只有帮主才能设置
     * 
     * 有变化才发过来, 需要等待服务器返回
     * 
     * 附带
     * 
     * bool true 自动同意, false 不自动同意,需要手动同意
     */
    static final int C2S_SET_GUILD_AUTO_ACCEPT_JOIN_REQUEST = 13;

    /**
     * 设置失败, 附带varint32 错误码
     * 
     * 1. 你没有帮派
     * 2. 你不是帮主
     */
    static final int S2C_SET_GUILD_AUTO_ACCEPT_JOIN_REQUEST_FAIL = 35;
    static final ChannelBuffer ERROR_SET_GUILD_AUTO_ACCEPT_JOIN_REQUEST_YOU_HAVE_NO_GUILD = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_SET_GUILD_AUTO_ACCEPT_JOIN_REQUEST_FAIL, 1);
    static final ChannelBuffer ERROR_SET_GUILD_AUTO_ACCEPT_JOIN_REQUEST_YOU_HAVE_NO_RIGHT = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_SET_GUILD_AUTO_ACCEPT_JOIN_REQUEST_FAIL, 2);

    /**
     * 设置成功
     */
    static final int S2C_SET_GUILD_AUTO_ACCEPT_JOIN_REQUEST_SUCCESS = 36;
    static final ChannelBuffer setGuildAutoAcceptJoinRequestSuccess = onlySendHeaderMessage(
            MODULE_ID, S2C_SET_GUILD_AUTO_ACCEPT_JOIN_REQUEST_SUCCESS);

    // ----- 设置昵称 -----

    /**
     * 设置别人昵称. 客户端需要去除前后以及中间的空格, 并且过滤敏感字
     * 
     * 有官职的才能发来. 必须等服务器返回后才能再发设置昵称
     * 
     * 附带
     * 
     * varint64 对方id
     * UTFBytes 要设置的昵称. 不发则为取消. 0-6个汉字(12个字符)
     */
    static final int C2S_SET_NICKNAME = 14;

    /**
     * 设置昵称失败, 附带varint32 原因
     * 
     * 1. 你没有帮派
     * 2. 你没有权限
     * 3. id没找到
     * 4. 发来的昵称长度太长
     * 5. 昵称中有非法字符
     */
    static final int S2C_SET_NICKNAME_FAIL = 37;
    static final ChannelBuffer ERROR_SET_NICKNAME_NO_GUILD = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_SET_NICKNAME_FAIL, 1);
    static final ChannelBuffer ERROR_SET_NICKNAME_NO_RIGHT = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_SET_NICKNAME_FAIL, 2);
    static final ChannelBuffer ERROR_SET_NICKNAME_TARGET_NOT_FOUND = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_SET_NICKNAME_FAIL, 3);
    static final ChannelBuffer ERROR_SET_NICKNAME_NOO_LONG = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_SET_NICKNAME_FAIL, 4);
    static final ChannelBuffer ERROR_SET_NICKNAME_ILLEGAL_CHAR = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_SET_NICKNAME_FAIL, 5);

    /**
     * 设置昵称成功, 自己弹出提示
     * 
     * 如果发来的昵称为空, 则显示  成功取消了XXX玩家的帮中昵称
     * 不然, 显示 成功修改了XXX的帮中昵称为：XX 
     */
    static final int S2C_SET_NICKNAME_SUCCESS = 38;
    static final ChannelBuffer setNicknameSuccess = onlySendHeaderMessage(
            MODULE_ID, S2C_SET_NICKNAME_SUCCESS);

    /**
     * 昵称被改的人收到. 如果附带的昵称为空, 则显示 您的帮中昵称被“帮中职位”清除了
     * 不然, 则显示 您的帮中昵称被“帮中职位”修改为：XX
     * 
     * 附带
     * 
     * varint32 修改你昵称的职位 1 堂主, 2 副帮主, 3 帮主
     * UTFBytes 新的昵称
     */
    static final int S2C_YOUR_NICKNAME_CHANGED = 39;

    // ----- 分组头衔 -----

    static final int C2S_SET_GROUPNAME = 15;

    static final int S2C_SET_GROUPNAME_FAIL = 40;
    static final ChannelBuffer ERROR_SET_GROUPNAME_NO_GUILD = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_SET_GROUPNAME_FAIL, 1);
    static final ChannelBuffer ERROR_SET_GROUPNAME_NO_RIGHT = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_SET_GROUPNAME_FAIL, 2);
    static final ChannelBuffer ERROR_SET_GROUPNAME_TARGET_NOT_FOUND = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_SET_GROUPNAME_FAIL, 3);
    static final ChannelBuffer ERROR_SET_GROUPNAME_TOO_LONG = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_SET_GROUPNAME_FAIL, 4);
    static final ChannelBuffer ERROR_SET_GROUPNAME_ILLEGAL_CHAR = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_SET_GROUPNAME_FAIL, 5);

    static final int S2C_SET_GROUPNAME_SUCCESS = 41;
    static final ChannelBuffer setGroupnameSuccess = onlySendHeaderMessage(
            MODULE_ID, S2C_SET_GROUPNAME_SUCCESS);

    static final int S2C_YOUR_GROUPNAME_CHANGED = 42;

    // ----- 捐帮贡物品 -----

    /**
     * 捐献帮贡物品, 需要等待服务器返回才能再捐献.
     * 
     * 发来之前需要确保包里有这么多要捐献的物品
     * 
     * 附带
     * 
     * byte 捐献的物品类型 1,2,3,4 对应config.proto中的guild_gift_goods编号 (不是物品id)
     * varint32 要捐献的个数
     */
    static final int C2S_GIVE_GIFT_GOODS = 16;

    /**
     * 捐献物品失败, 附带 varint32 错误码
     * 
     * 1. 你没有帮派
     * 2. 发来的物品类型非法, 必须是1-4
     * 3. 这个类型的物品已经满了. 可能只差1个满, 但你要捐2个. 这样1个都不会捐. 客户端应该只允许他最多捐1个
     * 4. 你包里没有这么多要捐的物品. 比如只有1个, 但发来说要捐2个
     * 5. 发来的要捐的个数非法. 必须 >=1 && <= 999
     */
    static final int S2C_GIVE_GIFT_GOODS_FAIL = 43;
    static final ChannelBuffer ERROR_GIVE_GIFT_GOODS_NO_GUILD = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_GIVE_GIFT_GOODS_FAIL, 1);
    static final ChannelBuffer ERROR_GIVE_GIFT_GOODS_ILLEGAL_GOODS_TYPE = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_GIVE_GIFT_GOODS_FAIL, 2);
    static final ChannelBuffer ERROR_GIVE_GIFT_GOODS_GUILD_FULL = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_GIVE_GIFT_GOODS_FAIL, 3);
    static final ChannelBuffer ERROR_GIVE_GIFT_GOODS_DONT_HAVE_THAT_MANY = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_GIVE_GIFT_GOODS_FAIL, 4);
    static final ChannelBuffer ERROR_GIVE_GIFT_GOODS_ILLEGAL_COUNT_TO_GIVE = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_GIVE_GIFT_GOODS_FAIL, 5);

    /**
     * 捐献物品成功. 服务器会另外发扣物品消息
     * 
     * 显示提示  感谢您，捐献了X个【XX】，您获得了X点帮贡和X点江湖历练
     *
     * 多少个物品根据请求的消息中附带的物品个数显示, 多少帮贡根据物品 x config.proto中附带的每捐个物品得多少帮贡来算
     * 
     * 如果当前正打开着帮派界面, (成员列表或帮贡界面, 刷新)
     * 
     * 附带
     * 
     * 捐献者不会收到S2C_OTHER_GIVE_GIFT_GOODS_BROADCAST
     * 
     * varint32 自己最新的帮贡值 (覆盖掉原来的帮贡值)
     * varint32 自己最新的江湖历练值 (覆盖掉原来的)
     */
    static final int S2C_GIVE_GIFT_GOODS_SUCCESS = 44;

    /**
     * 帮派中别人捐献了物品, 帮派中其他人会收到广播 (捐献者不会收到)
     * 
     * 显示 感谢XXX玩家为帮派捐献了X个XX，获得了XX帮贡和XX江湖历练
     * 
     * 消息中附带物品个数, 客户端自己算出得到了多少点帮贡和江湖历练
     * 
     * 如果当前正打开着帮派界面, (成员列表或帮贡界面, 刷新)
     * 
     * 附带
     * 
     * byte 捐献的物品类型 1-4
     * varint32 捐献的个数
     * UTFBytes 捐献者的名字
     */
    static final int S2C_OTHER_GIVE_GIFT_GOODS_BROADCAST = 45;

    // ----- 捐献银两 -----

    /**
     * 捐献银两. 需要等服务器返回之后才能再次捐献. 发过来的捐献数必须<=包里有的银两数
     * 
     * 附带
     * 
     * varint32 需要得到的帮贡数 (注意是帮贡数, 而不是银两数. 多少银两换一个帮贡在config.proto中)
     */
    static final int C2S_GIVE_GIFT_MONEY = 17;

    /**
     * 捐献银两失败, 附带varint32 错误码
     * 
     * 1. 你没有帮派
     * 2. 你没有这么多钱
     * 3. 帮贡里的钱满了 比如只差1块, 但你要捐2块. 结果就是完全没捐
     * 4. 发来的数量非法. 必须 >= 1 && <= 9999
     */
    static final int S2C_GIVE_GIFT_MONEY_FAIL = 46;
    static final ChannelBuffer ERROR_GIVE_GIFT_MONEY_NO_GUILD = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_GIVE_GIFT_MONEY_FAIL, 1);
    static final ChannelBuffer ERROR_GIVE_GIFT_MONEY_NOT_ENOUGH_MONEY = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_GIVE_GIFT_MONEY_FAIL, 2);
    static final ChannelBuffer ERROR_GIVE_GIFT_MONEY_GUILD_FULL = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_GIVE_GIFT_MONEY_FAIL, 3);
    static final ChannelBuffer ERROR_GIVE_GIFT_MONEY_ILLEGAL_COUNT = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_GIVE_GIFT_MONEY_FAIL, 4);

    /**
     * 捐献银两成功, 服务器会另外发送扣钱消息
     * 
     * 提示 感谢您，捐献了XXX银两，您获得了X点帮贡和X点江湖历练 (根据自己发的请求自己算)
     * 
     * 如果当前正打开着帮派界面, (成员列表或帮贡界面, 刷新)
     * 附带
     * 
     * varint32 最新帮贡
     * varint32 最新历练
     */
    static final int S2C_GIVE_GIFT_MONEY_SUCCESS = 47;

    /**
     * 帮中其他人捐献了银两
     * 
     * 显示 感谢XX玩家为帮派捐献了XXXX银两，获得了XX帮贡和XX江湖历练
     * 
     * 如果当前正打开着帮派界面, (成员列表或帮贡界面, 刷新)
     * 附带
     * 
     * varint32 得到的帮贡数 (根据帮贡自己算花的银两)
     * UTFBytes 捐献的人名字
     */
    static final int S2C_OTHER_GIVE_GIFT_MONEY_BROADCAST = 48;

    // ----- 帮旗改造型 -----

    /**
     * 要求改变帮旗造型. 只有帮主才能发送. 必须先检查好需要扣的物品足够. 且要改的造型和之前的不同
     * 
     * 附带
     * 
     * varint32 想要的新造型id (0-9)
     */
    static final int C2S_CHANGE_FLAG_KIND = 18;

    /**
     * 改帮旗造型失败, 附带varint32 错误码
     * 
     * 1. 你没有帮派
     * 2. 你不是帮主
     * 3. 发来的新帮旗造型不合法, 必须是0-9
     * 4. 发来的新帮旗造型和之前的一样
     * 5. 帮派里没有足够的要扣的物品
     * 6. 帮派战期间（包括板块战，无双城，龙城）
     */
    static final int S2C_CHANGE_FLAG_KIND_FAIL = 49;
    static final ChannelBuffer ERROR_CHANGE_FLAG_KIND_NO_GUILD = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_CHANGE_FLAG_KIND_FAIL, 1);
    static final ChannelBuffer ERROR_CHANGE_FLAG_KIND_NO_RIGHT = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_CHANGE_FLAG_KIND_FAIL, 2);
    static final ChannelBuffer ERROR_CHANGE_FLAG_KIND_ILLEGAL_FLAG_KIND = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_CHANGE_FLAG_KIND_FAIL, 3);
    static final ChannelBuffer ERROR_CHANGE_FLAG_KIND_SAME_FLAG_KIND = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_CHANGE_FLAG_KIND_FAIL, 4);
    static final ChannelBuffer ERROR_CHANGE_FLAG_KIND_NOT_ENOUGH_GIFT = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_CHANGE_FLAG_KIND_FAIL, 5);
    static final ChannelBuffer ERROR_CHANGE_FLAG_KIND_IN_BATTLE = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_CHANGE_FLAG_KIND_FAIL, 6);

    /**
     * 帮旗改造型成功. 重新请求帮派详细信息
     * 
     * 没有附带信息
     */
    static final int S2C_CHANGE_FLAG_KIND_SUCCESS = 50;
    static final ChannelBuffer changeFlagKindSuccess = onlySendHeaderMessage(
            MODULE_ID, S2C_CHANGE_FLAG_KIND_SUCCESS);

    /**
     * 帮主改变了帮旗造型, 清掉帮派详细信息缓存. 如果当前正打开着帮派界面, 刷新
     * 
     * 帮主不会收到这条
     * 
     * 没有附带信息
     */
    static final int S2C_FLAG_KIND_CHANGED_BROADCAST = 51;
    static final ChannelBuffer flagKindChangedBroadcast = onlySendHeaderMessage(
            MODULE_ID, S2C_FLAG_KIND_CHANGED_BROADCAST);

    // ----- 帮旗改名 -----

    /**
     * 要求改变帮旗名字. 只有帮主才能发送. 必须先检查好需要扣的物品足够. 且要改的名字和之前的不同
     * 
     * 名字必须是2-6汉字之内, 且前后去空格, 不能有非法字符, 需先过滤敏感字
     * 
     * 附带
     * 
     * UTFBytes 想要的新帮旗名字
     */
    static final int C2S_CHANGE_FLAG_NAME = 19;

    /**
     * 改帮旗名字失败, 附带varint32 错误码
     *
     * 1. 你没有帮派
     * 2. 你不是帮主
     * 3. 新帮旗名字长度非法 必须2-6汉字. 4-12字节
     * 4. 新帮旗名字中有非法字符
     * 5. 新帮旗名字和以前的一样
     * 6. 不够改名字的资源 (帮贡物品或银两不足)
     * 7. 名字已经被占用了
     * 8. 帮派战期间（包括板块战，无双城，龙城）
     */
    static final int S2C_CHANGE_FLAG_NAME_FAIL = 52;
    static final ChannelBuffer ERROR_CHANGE_FLAG_NAME_NO_GUILD = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_CHANGE_FLAG_NAME_FAIL, 1);
    static final ChannelBuffer ERROR_CHANGE_FLAG_NAME_NO_RIGHT = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_CHANGE_FLAG_NAME_FAIL, 2);
    static final ChannelBuffer ERROR_CHANGE_FLAG_NAME_ILLEGAL_LEN = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_CHANGE_FLAG_NAME_FAIL, 3);
    static final ChannelBuffer ERROR_CHANGE_FLAG_NAME_ILLEGAL_CHAR = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_CHANGE_FLAG_NAME_FAIL, 4);
    static final ChannelBuffer ERROR_CHANGE_FLAG_NAME_SAME_NAME = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_CHANGE_FLAG_NAME_FAIL, 5);
    static final ChannelBuffer ERROR_CHANGE_FLAG_NAME_NOT_ENOUGH_RESOURCE = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_CHANGE_FLAG_NAME_FAIL, 6);
    static final ChannelBuffer ERROR_CHANGE_FLAG_NAME_NAME_TAKEN = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_CHANGE_FLAG_NAME_FAIL, 7);
    static final ChannelBuffer ERROR_CHANGE_FLAG_NAME_IN_BATTLE = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_CHANGE_FLAG_NAME_FAIL, 8);

    /**
     * 改名字成功, 重新请求帮派详细信息
     * 
     * 没有附带信息
     */
    static final int S2C_CHANGE_FLAG_NAME_SUCCESS = 53;
    static final ChannelBuffer flagNameSuccess = onlySendHeaderMessage(
            MODULE_ID, S2C_CHANGE_FLAG_NAME_SUCCESS);

    /**
     * 帮主改了帮旗名字, 帮中其他人收到广播. 帮主不会收到
     * 
     * 附带
     * 
     * UTFBytes 新的帮旗名字
     */
    static final int S2C_FLAG_NAME_CHANGED_BROADCAST = 54;

    // ----- 帮旗升级 -----

    /**
     * 升级帮旗. 必须等到服务器返回才能继续发送请求
     * 
     * 只有自己是帮主, 帮旗不是顶级而且升级所需资源都足够的情况下, 才能请求
     * 
     * 没有附带信息
     */
    static final int C2S_FLAG_UPGRADE = 20;

    /**
     * 帮旗升级失败, 附带varint32 错误码
     * 
     * 1. 你没有帮派
     * 2. 你不是帮主
     * 3. 帮旗已经顶级
     * 4. 帮旗升级资源不够
     */
    static final int S2C_FLAG_UPGRADE_FAIL = 55;
    static final ChannelBuffer ERROR_FLAG_UPGRADE_NO_GUILD = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_FLAG_UPGRADE_FAIL, 1);
    static final ChannelBuffer ERROR_FLAG_UPGRADE_NO_RIGHT = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_FLAG_UPGRADE_FAIL, 2);
    static final ChannelBuffer ERROR_FLAG_UPGRADE_FLAG_TOP_LEVEL = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_FLAG_UPGRADE_FAIL, 3);
    static final ChannelBuffer ERROR_FLAG_UPGRADE_NOT_ENOUGH_RESOURCE = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_FLAG_UPGRADE_FAIL, 4);

    /**
     * 升级成功, 刷新帮派页面
     * 
     * 没有附带信息
     */
    static final int S2C_FLAG_UPGRADE_SUCCESS = 56;
    static final ChannelBuffer flagUpgradeSuccess = onlySendHeaderMessage(
            MODULE_ID, S2C_FLAG_UPGRADE_SUCCESS);

    /**
     * 帮旗升级成功, 广播给帮派里所有人
     * 
     * 附带
     * 
     * varint32 最新帮旗等级
     */
    static final int S2C_FLAG_UPGRADE_BROADCAST = 57;

    /**
     * 升级成功后, 广播给所有在线的用户
     * 展示提示
     * 
     * xxx帮派的帮旗升级至x级, 他们变得更强大了
     * 
     * 自己帮派的人相当于会收到2条, 这条和S2C_FLAG_UPGRADE_BROADCAST都会收到.
     * 
     * 附带
     * 
     * varint32 最新帮旗等级
     * UTFBytes 当事帮派名
     */
    static final int S2C_FLAG_UPGRADE_BROADCAST_TO_ALL_ONLINE_USER = 88;

    // ----- 邀请加盟帮 -----

    /**
     * 邀请加某个帮派为盟帮. 自己必须是帮主, 且盟帮个数< 5个. 且不能是敌对帮派. 等服务器返回才能再请求. 
     * 
     * 前后去空格. 名字不能是自己
     * 
     * 成功邀请后, 客户端需要在本地缓存2分钟此请求, 2分钟之内都不能邀请同一个帮派作为盟帮
     * 
     * 附带
     * 
     * UTFBytes 对方帮派名字
     */
    static final int C2S_INVITE_FRIEND_GUILD = 21;

    /**
     * 加盟帮失败, 附带varint32 错误码
     * 
     * 1. 你没有帮派
     * 2. 你不是帮主
     * 3. 你的盟帮数量到了上限
     * 4. 你输入的帮派名字不存在
     * 5. 对方帮派帮主不在线
     * 6. 对方盟帮数量到了上限
     * 7. 你之前已经邀请过了
     * 8. 此帮派是你的敌对帮派
     * 9. 不能邀请自己帮
     * 10. 系统忙, 稍后再试. 不要自动重试, 提示玩家就行
     * 11. 对方帮派把你加为了敌对帮派
     * 12. 对方已经是你的盟帮了
     * 13. 不能加别的联服的帮派
     * 14. 攻城期间不能加盟帮
     */
    static final int S2C_INVITE_FRIEND_GUILD_FAIL = 58;
    static final ChannelBuffer ERROR_INVITE_FRIEND_GUILD_YOU_HAVE_NO_GUILD = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_INVITE_FRIEND_GUILD_FAIL, 1);
    static final ChannelBuffer ERROR_INVITE_FRIEND_GUILD_YOU_HAVE_NO_RIGHT = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_INVITE_FRIEND_GUILD_FAIL, 2);
    static final ChannelBuffer ERROR_INVITE_FRIEND_GUILD_TOO_MUCH_FRIEND = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_INVITE_FRIEND_GUILD_FAIL, 3);
    static final ChannelBuffer ERROR_INVITE_FRIEND_GUILD_GUILD_NOT_FOUND = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_INVITE_FRIEND_GUILD_FAIL, 4);
    static final ChannelBuffer ERROR_INVITE_FRIEND_GUILD_TARGET_LEADER_OFFLINE = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_INVITE_FRIEND_GUILD_FAIL, 5);
    static final ChannelBuffer ERROR_INVITE_FRIEND_GUILD_TARGET_TOO_MUCH_FRIEND = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_INVITE_FRIEND_GUILD_FAIL, 6);
    static final ChannelBuffer ERROR_INVITE_FRIEND_GUILD_ALREADY_INVITED = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_INVITE_FRIEND_GUILD_FAIL, 7);
    static final ChannelBuffer ERROR_INVITE_FRIEND_GUILD_TARGET_IS_ENEMY = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_INVITE_FRIEND_GUILD_FAIL, 8);
    static final ChannelBuffer ERROR_INVITE_FRIEND_GUILD_CANNOT_INVITE_SELF = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_INVITE_FRIEND_GUILD_FAIL, 9);
    static final ChannelBuffer ERROR_INVITE_FRIEND_GUILD_SYSTEM_BUSY = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_INVITE_FRIEND_GUILD_FAIL, 10);
    static final ChannelBuffer ERROR_INVITE_FRIEND_GUILD_TARGET_ADD_YOU_AS_ENEMY = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_INVITE_FRIEND_GUILD_FAIL, 11);
    static final ChannelBuffer ERROR_INVITE_FRIEND_GUILD_TARGET_ALREADY_YOUR_FRIEND = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_INVITE_FRIEND_GUILD_FAIL, 12);
    static final ChannelBuffer ERROR_INVITE_FRIEND_GUILD_OTHER_UNION = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_INVITE_FRIEND_GUILD_FAIL, 13);
    static final ChannelBuffer ERROR_INVITE_FRIEND_GUILD_BATTLE = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_INVITE_FRIEND_GUILD_FAIL, 14);

    /**
     * 请求成功, 等对方帮主返回. 收到这条消息后开始缓存2分钟. 2分钟后自己显示提示 对方没有相应. 服务器不会再有消息通知
     * 
     * 没有附带信息
     */
    static final int S2C_INVITE_FRIEND_GUILD_SUCCESS = 59;
    static final ChannelBuffer inviteFriendGuildSuccess = onlySendHeaderMessage(
            MODULE_ID, S2C_INVITE_FRIEND_GUILD_SUCCESS);

    /**
     * 收到了别的帮派的加盟帮邀请
     * 
     * 附带
     * 
     * varint32 对方的帮旗等级
     * UTFBytes 对方的帮派名字
     */
    static final int S2C_RECEIVED_FRIEND_GUILD_INVITE = 60;

    // ----- 回复加盟帮 -----

    /**
     * 回复别人发出的盟帮邀请. 如果是同意则必须等待服务器返回才能继续回复别的邀请, 如果同意失败, 不要删掉此邀请.
     * 如果是拒绝, 服务器没有返回, 直接删掉邀请
     * 
     * 附带
     * 
     * bool 是否同意
     * UTFBytes 对方的帮派名
     */
    static final int C2S_REPLY_INVITE_FRIEND_GUILD = 22;

    /**
     * 同意盟帮邀请失败, 附带varint32 错误码. 收到后不要删掉盟帮邀请, 保留着(除非错误码是邀请已过期)
     * 
     * 1. 你没有帮派
     * 2. 你不是帮主
     * 3. 对方帮派不存在, 可能解散了, 也可能客户端发来的请求不对
     * 4. 你的盟帮数量到了上限
     * 5. 对方的盟帮数量到了上限
     * 6. 对方是你的敌对帮派
     * 7. 对方把你加为了敌对帮派
     * 8. 对方已经是你的盟帮了
     * 9. 系统忙, 稍后再试. 不要自动重试. 
     * 10. 邀请已过期
     * 11. 攻城期间不能加盟帮
     */
    static final int S2C_REPLY_INVITE_FRIEND_GUILD_FAIL = 61;
    static final ChannelBuffer ERROR_REPLY_FRIEND_GUILD_NO_GUILD = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_REPLY_INVITE_FRIEND_GUILD_FAIL, 1);
    static final ChannelBuffer ERROR_REPLY_FRIEND_GUILD_NO_RIGHT = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_REPLY_INVITE_FRIEND_GUILD_FAIL, 2);
    static final ChannelBuffer ERROR_REPLY_FRIEND_GUILD_TARGET_NOT_FOUND = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_REPLY_INVITE_FRIEND_GUILD_FAIL, 3);
    static final ChannelBuffer ERROR_REPLY_FRIEND_GUILD_TOO_MUCH_FRIEND = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_REPLY_INVITE_FRIEND_GUILD_FAIL, 4);
    static final ChannelBuffer ERROR_REPLY_FRIEND_GUILD_TARGET_TOO_MUCH_FRIEND = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_REPLY_INVITE_FRIEND_GUILD_FAIL, 5);
    static final ChannelBuffer ERROR_REPLY_FRIEND_GUILD_TARGET_IS_ENEMY = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_REPLY_INVITE_FRIEND_GUILD_FAIL, 6);
    static final ChannelBuffer ERROR_REPLY_FRIEND_GUILD_TARGET_ADD_YOU_AS_ENEMY = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_REPLY_INVITE_FRIEND_GUILD_FAIL, 7);
    static final ChannelBuffer ERROR_REPLY_FRIEND_GUILD_ALREADY_YOUR_FRIEND = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_REPLY_INVITE_FRIEND_GUILD_FAIL, 8);
    static final ChannelBuffer ERROR_REPLY_FRIEND_GUILD_SYSTEM_BUSY = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_REPLY_INVITE_FRIEND_GUILD_FAIL, 9);
    static final ChannelBuffer ERROR_REPLY_FRIEND_GUILD_INVITATION_EXPIRED = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_REPLY_INVITE_FRIEND_GUILD_FAIL, 10);
    static final ChannelBuffer ERROR_REPLY_FRIEND_GUILD_BATTLE = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_REPLY_INVITE_FRIEND_GUILD_FAIL, 11);

    /**
     * 同意盟帮成功. 解锁. 稍后全服都会收到广播S2C_NEW_FRIEND_GUILD_PAIR_BROADCAST
     * 
     * 没有附带信息
     */
    static final int S2C_REPLY_INVITE_FRIEND_GUILD_SUCCESS = 62;
    static final ChannelBuffer replyInviteFriendGuildSuccess = onlySendHeaderMessage(
            MODULE_ID, S2C_REPLY_INVITE_FRIEND_GUILD_SUCCESS);

    /**
     * 别的帮派拒绝了你的盟帮邀请. 清掉自己这里的邀请缓存, 使被拒绝的一方可以再发送邀请
     * 
     * 附带
     * 
     * UTFBytes 拒绝你的帮派名字
     */
    static final int S2C_OTHER_REJECTED_YOUR_FRIEND_GUILD_INVITE = 63;

    /**
     * 2个帮派成为了盟帮, 全服都会收到. 
     * 
     * 如果其中一方是自己的帮派, 则把对方加入到自己帮派的盟帮列表中, 且如果当前有邀请过对方盟帮或对方邀请过我盟帮的邀请, 则删掉
     * 如果周围有人是这个帮派的, 则脚底要显示 盟帮 
     * 在自己帮派频道里增加 恭喜恭喜，您的帮派与XXX帮派结为盟友，在以后的路上并肩作战
     * 
     * 全服都提示  XXX帮派与XXX帮派结为盟友，将要在江湖上掀起风霜雪雨
     * 
     * 附带
     * 
     * UTF 帮派1
     * UTFBytes 帮派2
     */
    static final int S2C_NEW_FRIEND_GUILD_PAIR_BROADCAST = 64;

    // ----- 解除盟帮 -----

    /**
     * 删除盟帮, 自己必须是帮主, 必须等待服务器返回
     * 
     * 附带
     * 
     * UTFBytes 对方帮派名字
     */
    static final int C2S_REMOVE_FRIEND_GUILD = 23;

    /**
     * 删除盟帮失败, 附带varint32 错误码
     * 
     * 1. 你没有帮派
     * 2. 你不是帮主
     * 3. 对方不是你的盟帮
     * 4. 系统忙, 稍后再试, 不要自动重试
     * 5. 帮派战期间不能删除盟帮
     */
    static final int S2C_REMOVE_FRIEND_GUILD_FAIL = 65;
    static final ChannelBuffer ERROR_REMOVE_FRIEND_GUILD_NO_GUILD = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_REMOVE_FRIEND_GUILD_FAIL, 1);
    static final ChannelBuffer ERROR_REMOVE_FRIEND_GUILD_NO_RIGHT = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_REMOVE_FRIEND_GUILD_FAIL, 2);
    static final ChannelBuffer ERROR_REMOVE_FRIEND_GUILD_NOT_FRIEND = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_REMOVE_FRIEND_GUILD_FAIL, 3);
    static final ChannelBuffer ERROR_REMOVE_FRIEND_GUILD_SYSTEM_BUSY = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_REMOVE_FRIEND_GUILD_FAIL, 4);
    static final ChannelBuffer ERROR_REMOVE_FRIEND_GUILD_BATTLE = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_REMOVE_FRIEND_GUILD_FAIL, 5);

    /**
     * 删除盟帮成功, 解锁. 过会全服都会收到广播 S2C_FRIEND_GUILD_PAIR_REMOVED_BROADCAST
     * 
     * 没有附带信息
     */
    static final int S2C_REMOVE_FRIEND_GUILD_SUCCESS = 66;
    static final ChannelBuffer removeFriendGuildSuccess = onlySendHeaderMessage(
            MODULE_ID, S2C_REMOVE_FRIEND_GUILD_SUCCESS);

    /**
     * 2个盟帮解除了盟帮关系, 如果其中一个是自己帮派, 则把对方从自己帮派的盟帮列表中删除
     * 如果周围有人是这个帮派的, 把脚底显示的 盟帮 去掉
     * 
     * 根据是自己主动还是对方主动, 在帮派频道增加
     *  本帮与XXX帮派之间的联盟关系已解除
     *  XXX帮派解除了与本帮的联盟关系
     *  
     * 全服都提示 XXX帮派与XXX帮派解除了联盟关系，江湖陷入纷乱争斗中
     * 
     * 附带
     * 
     * UTF 主动解除盟帮的帮派名
     * UTFBytes 被解除盟帮的帮派名
     */
    static final int S2C_FRIEND_GUILD_PAIR_REMOVED_BROADCAST = 67;

    /**
     * 被别人解除盟帮后, 帮主会收到. 如果被加时帮主不在线, 则帮主上线时, 会收到
     * 
     * 附带
     * 
     * varint32 对方帮旗等级
     * UTFBytes 对方帮派名字
     */
    static final int S2C_OTHER_REMOVED_YOU_AS_FRIEND = 90;

    // ----- 加敌对帮 -----

    /**
     * 要添加个帮派为敌对帮派, 自己必须是帮主, 且敌对帮派数<5, 必须等待服务器返回, 才能加别的敌对帮派和盟帮
     * 前后去空格
     * 
     * 不能加自己
     * 
     * 附带
     * 
     * UTFBytes 对方帮派名字
     */
    static final int C2S_ADD_ENEMY_GUILD = 24;

    /**
     * 加敌对帮派失败, 附带varint32 错误码
     * 
     * 1. 你没有帮派
     * 2. 你不是帮主
     * 3. 没有找到对方帮派. 客户端发错了, 或者对方正好解散了
     * 4. 对方是你的盟帮
     * 5. 对方已经是你的敌对帮派了
     * 6. 你的敌对帮派数已经到了上限
     * 7. 系统忙, 稍后再试. 不要自动重试
     * 8. 不能加别的联服
     * 9. 帮派战期间不能加敌对帮派
     */
    static final int S2C_ADD_ENEMY_GUILD_FAIL = 68;
    static final ChannelBuffer ERROR_ADD_ENEMY_GUILD_NO_GUILD = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_ADD_ENEMY_GUILD_FAIL, 1);
    static final ChannelBuffer ERROR_ADD_ENEMY_GUILD_NO_RIGHT = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_ADD_ENEMY_GUILD_FAIL, 2);
    static final ChannelBuffer ERROR_ADD_ENEMY_GUILD_TARGET_NOT_FOUND = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_ADD_ENEMY_GUILD_FAIL, 3);
    static final ChannelBuffer ERROR_ADD_ENEMY_GUILD_TARGET_IS_FRIEND = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_ADD_ENEMY_GUILD_FAIL, 4);
    static final ChannelBuffer ERROR_ADD_ENEMY_GUILD_TARGET_ALREADY_ENEMY = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_ADD_ENEMY_GUILD_FAIL, 5);
    static final ChannelBuffer ERROR_ADD_ENEMY_GUILD_TOO_MANY_ENEMY = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_ADD_ENEMY_GUILD_FAIL, 6);
    static final ChannelBuffer ERROR_ADD_ENEMY_GUILD_SYSTEM_BUSY = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_ADD_ENEMY_GUILD_FAIL, 7);
    static final ChannelBuffer ERROR_ADD_ENEMY_GUILD_OTHER_UNION = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_ADD_ENEMY_GUILD_FAIL, 8);
    static final ChannelBuffer ERROR_ADD_ENEMY_GUILD_BATTLE = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_ADD_ENEMY_GUILD_FAIL, 9);

    /**
     * 加敌对帮派成功, 解锁. 接着全服都会收到广播S2C_ENEMY_GUILD_ADDED_BROADCAST
     * 
     * 没有附带信息
     */
    static final int S2C_ADD_ENEMY_GUILD_SUCCESS = 69;
    static final ChannelBuffer addEnemyGuildSuccess = onlySendHeaderMessage(
            MODULE_ID, S2C_ADD_ENEMY_GUILD_SUCCESS);

    /**
     * 有个帮派加了另一个帮派为敌对帮派了. 如果主动加的帮派是自己帮派, 则把对方帮派加到自己的敌对帮派列表中
     * 被加的帮派不要加对方为敌对. 这个是单向的关系
     * 
     * 根据主动加的帮派和被加的, 在帮派频道显示相应的提示 本帮派已将XXX帮派列为敌对帮派  XXX帮派已将本帮列为敌对帮派
     * 
     * 全服都展示提示 XXX帮派将XXX帮派列为敌对帮派，江湖即将风起云涌
     * 
     * 附带
     * 
     * UTF 主动加别人为敌对的帮派名字
     * UTFBytes 被加为敌对的帮派名字
     */
    static final int S2C_ENEMY_GUILD_ADDED_BROADCAST = 70;

    /**
     * 被别人加为敌对帮派后, 帮主会收到. 如果被加时帮主不在线, 则帮主上线时, 会收到
     * 
     * 附带
     * 
     * varint32 对方帮旗等级
     * UTFBytes 对方帮派名字
     */
    static final int S2C_OTHER_ADDED_YOU_AS_ENEMY = 71;

    // ----- 删除敌对帮 -----

    /**
     * 解除与对方的敌对关系. 必须是帮主, 且对方在自己敌对帮派列表中才能发送
     *
     * 必须等待服务器返回
     * 
     * 附带
     * 
     * UTFBytes 对方帮派名字
     */
    static final int C2S_REMOVE_ENEMY_GUILD = 25;

    /**
     * 解除敌对关系失败, 附带varint32 错误码
     * 
     * 1. 你没有帮派
     * 2. 你不是帮主
     * 3. 对方不是你的敌对帮派
     * 4. 系统忙, 稍后再试, 不要自动重试
     * 5. 帮派战期间不能解除敌对关系
     */
    static final int S2C_REMOVE_ENEMY_GUILD_FAIL = 72;
    static final ChannelBuffer ERROR_REMOVE_ENEMY_NO_GUILD = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_REMOVE_ENEMY_GUILD_FAIL, 1);
    static final ChannelBuffer ERROR_REMOVE_ENEMY_NO_RIGHT = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_REMOVE_ENEMY_GUILD_FAIL, 2);
    static final ChannelBuffer ERROR_REMOVE_ENEMY_TARGET_NOT_ENEMY = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_REMOVE_ENEMY_GUILD_FAIL, 3);
    static final ChannelBuffer ERROR_REMOVE_ENEMY_SYSTEM_BUSY = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_REMOVE_ENEMY_GUILD_FAIL, 4);
    static final ChannelBuffer ERROR_REMOVE_ENEMY_BATTLE = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_REMOVE_ENEMY_GUILD_FAIL, 5);

    /**
     * 解除敌对帮派成功, 解锁. 不要处理逻辑. 接着全服都会收到广播 S2C_ENEMY_GUILD_REMOVED_BROADCAST
     * 
     * 没有附带信息
     */
    static final int S2C_REMOVE_ENEMY_GUILD_SUCCESS = 73;
    static final ChannelBuffer removeEnemyGuildSuccess = onlySendHeaderMessage(
            MODULE_ID, S2C_REMOVE_ENEMY_GUILD_SUCCESS);

    /**
     * 某帮解除了对另一个帮的敌对状态. 如果自己是解除方, 则把被解除方的帮派从自己的敌对帮派列表中删除
     * 
     * 相关的帮派在帮派频道中提示 本帮解除了与XXX帮派的敌对关系 或 XXX帮派解除了与本帮的敌对关系
     * 
     * 全服都提示 XXX帮派解除了与XXX帮派的敌对关系，江湖再次归于平静
     * 
     * 附带
     * 
     * UTF 主动解除敌对的帮派名字
     * UTFBytes 被解除的帮派名字
     */
    static final int S2C_ENEMY_GUILD_REMOVED_BROADCAST = 74;

    /**
     * 被别人解除敌对帮派后, 帮主会收到. 如果被加时帮主不在线, 则帮主上线时, 会收到
     * 
     * 附带
     * 
     * varint32 对方帮旗等级
     * UTFBytes 对方帮派名字
     */
    static final int S2C_OTHER_REMOVED_YOU_AS_ENEMY = 85;

    // ----- 解散帮派 -----

    /**
     * 手动解散帮派, 只有帮主才能发送. 必须等待服务器返回, 且发送前已经2次确认过
     * 
     * 没有附带信息
     */
    static final int C2S_DISMISS_GUILD = 26;

    /**
     * 解散帮派失败, 附带varint32 错误码
     * 
     * 1. 你没有帮派
     * 2. 你不是帮主
     * 3. 占领无双城帮派不能解散
     * 4. 帮派战期间（包括板块战，无双城，龙城）
     */
    static final int S2C_DISMISS_GUILD_FAIL = 75;
    static final ChannelBuffer ERROR_DISMISS_GUILD_NO_GUILD = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_DISMISS_GUILD_FAIL, 1);
    static final ChannelBuffer ERROR_DISMISS_GUILD_NO_RIGHT = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_DISMISS_GUILD_FAIL, 2);
    static final ChannelBuffer ERROR_DISMISS_GUILD_CITY_MASTER = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_DISMISS_GUILD_FAIL, 3);
    static final ChannelBuffer ERROR_DISMISS_GUILD_IN_BATTLE = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_DISMISS_GUILD_FAIL, 4);

    /**
     * 帮派解散成功, 解锁. 马上全服会收到广播S2C_GUILD_DISMISSED_BROADCAST
     * 
     * 没有附带信息
     */
    static final int S2C_DISMISS_GUILD_SUCCESS = 76;
    static final ChannelBuffer dismissGuildSuccess = onlySendHeaderMessage(
            MODULE_ID, S2C_DISMISS_GUILD_SUCCESS);

    /**
     * 广播给全服, 此帮派已解散. 把这个帮派从自己的盟帮和敌对帮中删除
     * 
     * 视野里如果有这个帮派的人, 则把他们的帮派设为无
     * 如果解散的帮派是自己的帮, 把自己的帮派设为无. 显示 您所处的帮派XXXX，被帮主XXX解散了
     * 
     * 附带
     * 
     * UTF 帮主名字
     * UTFBytes 解散的帮派的名字
     */
    static final int S2C_GUILD_DISMISSED_BROADCAST = 77;

    /**
     * 广播全服. 因为活跃度不足而解散. 逻辑和上面一样, 只是提示自己帮派的人的话不同
     * 
     * 您所在的帮派XXX因活跃玩家不足而自动解散
     * 
     * 附带
     * 
     * UTFBytes 解散的帮派的名字
     */
    static final int S2C_GUILD_DISMISSED_LOW_ACTIVITY = 81;

    // ----- 更改公告 -----

    /**
     * 改变帮派公告, 只有帮主能发, 必须等待服务器返回才能再更改
     * 
     * 客户端需要过滤敏感字, 且需要检查字数在100汉字(200字节)以下
     * 
     * 去掉后面的空格, 不需要去前面的
     * 
     * 有改变才发过来. 没有不要发
     * 
     * 附带
     * 
     * UTFBytes 新的帮派公告
     */
    static final int C2S_CHANGE_ANNOUNCEMENT = 27;

    /**
     * 改变帮派公告失败, 附带varint32 错误码
     * 
     * 1. 你没有帮派
     * 2. 你不是帮主
     * 3. 公告长度非法 必须是0-200字符
     * 4. 公告内有非法字符
     */
    static final int S2C_CHANGE_ANNOUNCEMENT_FAIL = 78;
    static final ChannelBuffer ERROR_CHANGE_ANNOUNCEMENT_NO_GUILD = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_CHANGE_ANNOUNCEMENT_FAIL, 1);
    static final ChannelBuffer ERROR_CHANGE_ANNOUNCEMENT_NO_RIGHT = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_CHANGE_ANNOUNCEMENT_FAIL, 2);
    static final ChannelBuffer ERROR_CHANGE_ANNOUNCEMENT_ILLEGAL_LEN = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_CHANGE_ANNOUNCEMENT_FAIL, 3);
    static final ChannelBuffer ERROR_CHANGE_ANNOUNCEMENT_ILLEGAL_CHAR = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_CHANGE_ANNOUNCEMENT_FAIL, 4);

    /**
     * 改变公告成功, 把公告内容改成请求的内容.
     * 
     * 没有附带信息
     */
    static final int S2C_CHANGE_ANNOUNCEMENT_SUCCESS = 79;
    static final ChannelBuffer changeAnnouncementSuccess = onlySendHeaderMessage(
            MODULE_ID, S2C_CHANGE_ANNOUNCEMENT_SUCCESS);

    /**
     * 帮派中其他人收到此广播, 帮主不会收到. 收到后清掉帮派信息缓存, 如果当前正打开着帮派面板, 则马上刷新
     * 
     * 提示 帮主更新了帮派公告，欢迎查看
     * 
     * 没有附带信息
     */
    static final int S2C_ANNOUNCEMENT_CHANGED_BROADCAST = 80;
    static final ChannelBuffer announcementChangeBroadcast = onlySendHeaderMessage(
            MODULE_ID, S2C_ANNOUNCEMENT_CHANGED_BROADCAST);

    /**
     * 上线时, 如果帮派活跃度不够, 会收到
     * 
     * 您所在的帮派每日活跃玩家不足，请多招募成员，并鼓励成员每日上线，否则您的帮派将会于 x 日内解散
     * 
     * 附带
     * 
     * varint32 剩余多少天会被解散
     */
    static final int S2C_LOW_ACTIVITY_WARNING = 82;

    // ----- 物品兑换 -----

    /**
     * 要用帮派历练兑换物品, 必须帮贡足够, 且剩余数量足够, 背包有足够空格 (所需空格计算方式: 每兑换一次获得的个数/物品每堆的个数, 向上取整)
     * 必须等服务器返回才能继续兑换
     * 
     * 附带
     * 
     * varint32 要兑换的物品的index (其在config.proto中的index. 从0开始)
     */
    static final int C2S_BUY_CONTRIBUTION_GOODS = 28;

    /**
     * 兑换物品失败, 附带varint32 错误码
     * 
     * 1. 你没有帮派
     * 2. 物品index非法 那个位置没有物品. index从0开始了吗
     * 3. 没有足够的帮贡
     * 4. 没有足够的历练
     * 5. 没有剩余可兑换的了, 明天再来
     * 6. 背包没有空位
     */
    static final int S2C_BUY_CONTRIBUTION_GOODS_FAIL = 83;
    static final ChannelBuffer ERROR_BUY_CONTRIBUTION_GOODS_NO_GUILD = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_BUY_CONTRIBUTION_GOODS_FAIL, 1);
    static final ChannelBuffer ERROR_BUY_CONTRIBUTION_GOODS_ILLEGAL_INDEX = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_BUY_CONTRIBUTION_GOODS_FAIL, 2);
    static final ChannelBuffer ERROR_BUY_CONTRIBUTION_GOODS_NOT_ENOUGH_CONTRIBUTION = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_BUY_CONTRIBUTION_GOODS_FAIL, 3);
    static final ChannelBuffer ERROR_BUY_CONTRIBUTION_GOODS_NOT_ENOUGH_LILIAN = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_BUY_CONTRIBUTION_GOODS_FAIL, 4);
    static final ChannelBuffer ERROR_BUY_CONTRIBUTION_GOODS_NONE_LEFT = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_BUY_CONTRIBUTION_GOODS_FAIL, 5);
    static final ChannelBuffer ERROR_BUY_CONTRIBUTION_GOODS_BAG_FULL = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_BUY_CONTRIBUTION_GOODS_FAIL, 6);

    /**
     * 兑换物品成功, 服务器会另外发送添加物品的消息
     * 
     * 附带
     * 
     * varint32 兑换过后剩余的帮派历练 (覆盖自己的最新历练数)
     */
    static final int S2C_BUY_CONTRIBUTION_GOODS_SUCCESS = 84;

    /**
     * 兑换物品被人兑换了, 更新剩余数量
     * 
     * 此物品一定是有个数限制的
     * 
     * 附带
     * 
     * varint32 index  (其在config.proto中的index. 从0开始)
     * varint32 新的已被购买掉的个数 (剩余个数由总个数 - 这个数)
     */
    static final int S2C_CHANGE_BOUGHT_CONTRIBUTION_GOODS_COUNT = 91;

    // ----- 获取帮派见闻 -----

    /**
     * 获取最新帮派见闻, 不要自动刷新, 且将数据保存10秒, 10秒内再看帮派见闻就用缓存着的数据
     * 
     * 离开帮派后删除数据. 防止10秒内进到个新帮派, 会看到老帮派的见闻
     * 
     * 没有附带信息
     */
    static final int C2S_GET_NEWS = 30;

    /**
     * 获取帮派见闻出错, 附带varint32 错误码
     * 
     * 1. 你没有帮派
     */
    static final int S2C_GET_NEWS_FAIL = 86;
    static final ChannelBuffer ERROR_GET_NEWS_NO_GUILD = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_GET_NEWS_FAIL, 1);

    /**
     * 返回帮派见闻, 消息已压缩
     * 
     * 附带
     * 
     * ClientNewsProto 这个proto 具体proto内容和读法, 客户端做到再说
     */
    static final int S2C_REPLY_NEWS = 87;

    // ----- 设置  是否禁止他人邀请我加人帮派-----

    /**
     * 将  自己的是否禁止他人邀请我加入帮派设为  是
     * 
     * 没有返回
     */
    static final int C2S_SET_FORBID_OTHER_INVITE_ME_JOIN_GUILD_TRUE = 31;

    /**
     * 将  自己的是否禁止他人邀请我加入帮派设为  否
     * 
     * 没有返回
     */
    static final int C2S_SET_FORBID_OTHER_INVITE_ME_JOIN_GUILD_FLASE = 32;

    // ----- 具体消息 -----

    static ChannelBuffer changeBoughtContributionGoodsCount(int index, int count){
        return onlySendHeadAnd2VarInt32Message(MODULE_ID,
                S2C_CHANGE_BOUGHT_CONTRIBUTION_GOODS_COUNT, index, count);
    }

    static ChannelBuffer otherAcceptedYourJoinInvite(byte[] name){
        return onlySendHeadAndAUTFBytes(MODULE_ID,
                S2C_OTHER_ACCEPTED_YOUR_JOIN_INVITE, name);
    }

    static ChannelBuffer flagUpgradeBroadcastToAllOnline(int newLevel,
            byte[] name){
        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID,
                S2C_FLAG_UPGRADE_BROADCAST_TO_ALL_ONLINE_USER,
                computeVarInt32Size(newLevel) + name.length);
        writeVarInt32(buffer, newLevel);
        buffer.writeBytes(name);
        return buffer;
    }

    static ChannelBuffer replyNews(ClientNewsProto proto){
        return getCompressedMessage(MODULE_ID, S2C_REPLY_NEWS,
                proto.toByteArray(), false);
    }

    static ChannelBuffer otherRemovedYouAsFriend(int flagLevel, byte[] guildName){
        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID,
                S2C_OTHER_REMOVED_YOU_AS_FRIEND, computeVarInt32Size(flagLevel)
                        + guildName.length);
        writeVarInt32(buffer, flagLevel);
        buffer.writeBytes(guildName);
        return buffer;
    }

    static ChannelBuffer otherRemovedYouAsEnemy(int flagLevel, byte[] guildName){
        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID,
                S2C_OTHER_REMOVED_YOU_AS_ENEMY, computeVarInt32Size(flagLevel)
                        + guildName.length);
        writeVarInt32(buffer, flagLevel);
        buffer.writeBytes(guildName);
        return buffer;
    }

    static ChannelBuffer buyContributionGoodsSuccess(int newLilian){
        return onlySendHeadAndAVarInt32Message(MODULE_ID,
                S2C_BUY_CONTRIBUTION_GOODS_SUCCESS, newLilian);
    }

    static ChannelBuffer lowActivityWarning(int days){
        return onlySendHeadAndAVarInt32Message(MODULE_ID,
                S2C_LOW_ACTIVITY_WARNING, days);
    }

    static ChannelBuffer guildDismissedLowActivity(byte[] guildName){
        return onlySendHeadAndAUTFBytes(MODULE_ID,
                S2C_GUILD_DISMISSED_LOW_ACTIVITY, guildName);
    }

    static ChannelBuffer guildDismissedBroadcast(byte[] leaderName,
            byte[] guildName){
        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID,
                S2C_GUILD_DISMISSED_BROADCAST, 2 + leaderName.length
                        + guildName.length);
        writeUTF(buffer, leaderName);
        buffer.writeBytes(guildName);
        return buffer;
    }

    static ChannelBuffer enemyGuildRemovedBroadcast(byte[] proactiveGuildName,
            byte[] otherGuildName){
        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID,
                S2C_ENEMY_GUILD_REMOVED_BROADCAST, 2
                        + proactiveGuildName.length + otherGuildName.length);
        writeUTF(buffer, proactiveGuildName);
        buffer.writeBytes(otherGuildName);
        return buffer;
    }

    static ChannelBuffer otherAddedYouAsEnemy(int flagLevel, byte[] name){
        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID,
                S2C_OTHER_ADDED_YOU_AS_ENEMY, computeVarInt32Size(flagLevel)
                        + name.length);
        writeVarInt32(buffer, flagLevel);
        buffer.writeBytes(name);
        return buffer;
    }

    static ChannelBuffer enemyGuildAddedBroadcast(byte[] proactiveGuildName,
            byte[] otherGuildName){
        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID,
                S2C_ENEMY_GUILD_ADDED_BROADCAST, 2 + proactiveGuildName.length
                        + otherGuildName.length);
        writeUTF(buffer, proactiveGuildName);
        buffer.writeBytes(otherGuildName);
        return buffer;
    }

    static ChannelBuffer friendGuildPairRemovedBroadcast(
            byte[] proactiveGuildName, byte[] otherGuildName){
        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID,
                S2C_FRIEND_GUILD_PAIR_REMOVED_BROADCAST, 2
                        + proactiveGuildName.length + otherGuildName.length);
        writeUTF(buffer, proactiveGuildName);
        buffer.writeBytes(otherGuildName);
        return buffer;
    }

    static ChannelBuffer newFriendGuildPairBroadcast(byte[] name1, byte[] name2){
        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID,
                S2C_NEW_FRIEND_GUILD_PAIR_BROADCAST, 2 + name1.length
                        + name2.length);
        writeUTF(buffer, name1);
        buffer.writeBytes(name2);
        return buffer;
    }

    static ChannelBuffer otherRejectedYourFriendGuildInvite(byte[] name){
        return onlySendHeadAndAUTFBytes(MODULE_ID,
                S2C_OTHER_REJECTED_YOUR_FRIEND_GUILD_INVITE, name);
    }

    static ChannelBuffer receivedFriendGuildInvite(int flagLevel, byte[] name){
        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID,
                S2C_RECEIVED_FRIEND_GUILD_INVITE,
                computeVarInt32Size(flagLevel) + name.length);
        writeVarInt32(buffer, flagLevel);
        buffer.writeBytes(name);
        return buffer;
    }

    static ChannelBuffer flagUpgradedBroadcast(int newLevel){
        return onlySendHeadAndAVarInt32Message(MODULE_ID,
                S2C_FLAG_UPGRADE_BROADCAST, newLevel);
    }

    static ChannelBuffer flagNameChangedBroadcast(byte[] newName){
        return onlySendHeadAndAUTFBytes(MODULE_ID,
                S2C_FLAG_NAME_CHANGED_BROADCAST, newName);
    }

    static ChannelBuffer otherGiveGiftMoneyBroadcast(int contribution,
            byte[] name){
        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID,
                S2C_OTHER_GIVE_GIFT_MONEY_BROADCAST,
                computeVarInt32Size(contribution) + name.length);
        writeVarInt32(buffer, contribution);
        buffer.writeBytes(name);
        return buffer;
    }

    static ChannelBuffer giveGiftMoneySuccess(int newContribution, int newLilian){
        return onlySendHeadAnd2VarInt32Message(MODULE_ID,
                S2C_GIVE_GIFT_MONEY_SUCCESS, newContribution, newLilian);
    }

    static ChannelBuffer otherGiveGiftGoodsBroadcast(int goodsType, int count,
            byte[] name){
        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID,
                S2C_OTHER_GIVE_GIFT_GOODS_BROADCAST, 1
                        + computeVarInt32Size(count) + name.length);
        buffer.writeByte(goodsType);
        writeVarInt32(buffer, count);
        buffer.writeBytes(name);
        return buffer;
    }

    static ChannelBuffer giveGiftGoodsSuccess(int newContribution, int newLilian){
        return onlySendHeadAnd2VarInt32Message(MODULE_ID,
                S2C_GIVE_GIFT_GOODS_SUCCESS, newContribution, newLilian);
    }

    static ChannelBuffer yourGroupnameChanged(int otherPost,
            @MaybeNull byte[] newNickname){
        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID,
                S2C_YOUR_GROUPNAME_CHANGED, computeVarInt32Size(otherPost)
                        + (newNickname == null ? 0 : newNickname.length));
        writeVarInt32(buffer, otherPost);
        if (newNickname != null){
            buffer.writeBytes(newNickname);
        }
        return buffer;
    }

    static ChannelBuffer yourNicknameChanged(int otherPost,
            @MaybeNull byte[] newNickname){
        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID,
                S2C_YOUR_NICKNAME_CHANGED, computeVarInt32Size(otherPost)
                        + (newNickname == null ? 0 : newNickname.length));
        writeVarInt32(buffer, otherPost);
        if (newNickname != null){
            buffer.writeBytes(newNickname);
        }
        return buffer;
    }

    static ChannelBuffer positionChangeBroadcast(long id, byte[] name, int post){
        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID,
                S2C_POSITION_CHANGE_BROADCAST, computeVarInt64Size(id)
                        + computeVarInt32Size(post) + name.length);
        writeVarInt64(buffer, id);
        writeVarInt32(buffer, post);
        buffer.writeBytes(name);
        return buffer;
    }

    static ChannelBuffer someoneBeenKicked(byte[] kicker, byte[] beenKicked){
        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID,
                S2C_SOMEONE_BEEN_KICKED_BROADCAST, 2 + kicker.length
                        + beenKicked.length);
        writeUTF(buffer, kicker);
        buffer.writeBytes(beenKicked);
        return buffer;
    }

    static ChannelBuffer youBeenKicked(byte[] heroName){
        return onlySendHeadAndAUTFBytes(MODULE_ID, S2C_YOU_BEEN_KICKED,
                heroName);
    }

    static ChannelBuffer otherLeaveGuild(byte[] heroName){
        return onlySendHeadAndAUTFBytes(MODULE_ID,
                S2C_OTHER_LEAVE_GUILD_BROADCAST, heroName);
    }

    static ChannelBuffer otherRejectedYourJoinInvite(long id, byte[] heroName){
        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID,
                S2C_OTHER_REJECTED_YOUR_JOIN_INVITE, computeVarInt64Size(id)
                        + heroName.length);
        writeVarInt64(buffer, id);
        buffer.writeBytes(heroName);
        return buffer;
    }

    static ChannelBuffer receiveJoinInvite(long id, byte[] heroName, int race,
            int flagLevel, byte[] guildName){
        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID,
                S2C_RECEIVE_JOIN_INVITE, computeVarInt64Size(id) + 2
                        + heroName.length + computeVarInt32Size(race)
                        + computeVarInt32Size(flagLevel) + guildName.length);
        writeVarInt64(buffer, id);
        writeUTF(buffer, heroName);
        writeVarInt32(buffer, race);
        writeVarInt32(buffer, flagLevel);
        buffer.writeBytes(guildName);
        return buffer;
    }

    static ChannelBuffer otherAcceptedYourRequest(byte[] guildName){
        return onlySendHeadAndAUTFBytes(MODULE_ID,
                S2C_OTHER_ACCEPTED_YOUR_JOIN_REQUEST, guildName);
    }

    static ChannelBuffer otherRejectedYourRequest(byte[] guildName){
        return onlySendHeadAndAUTFBytes(MODULE_ID,
                S2C_OTHER_REJECTED_YOUR_JOIN_REQUEST, guildName);
    }

    static ChannelBuffer otherJoinGuild(byte[] heroName){
        return onlySendHeadAndAUTFBytes(MODULE_ID, S2C_OTHER_JOIN_GUILD,
                heroName);
    }

    static ChannelBuffer youJoinGuild(Guild guild){
        Set<Guild> friendGuild = guild.getFriendGuilds();
        Set<Guild> enemyGuild = guild.getEnemyGuilds();

        ChannelBuffer buffer = newDynamicMessage(MODULE_ID, S2C_YOU_JOIN_GUILD,
                (friendGuild.size() + enemyGuild.size() + 1) * 20);

        writeUTF(buffer, guild.name);

        for (Guild g : friendGuild){
            int v = (g.name.length << 1) | 0x1;
            writeVarInt32(buffer, v);
            buffer.writeBytes(g.name);
        }

        for (Guild g : enemyGuild){
            int v = g.name.length << 1;
            writeVarInt32(buffer, v);
            buffer.writeBytes(g.name);
        }

        return buffer;
    }

    static ChannelBuffer receiveJoinRequest(long id, int race, int level,
            byte[] name){
        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID,
                S2C_RECEIVE_JOIN_REQUEST, computeVarInt64Size(id)
                        + computeVarInt32Size(race)
                        + computeVarInt32Size(level) + name.length);
        writeVarInt64(buffer, id);
        writeVarInt32(buffer, race);
        writeVarInt32(buffer, level);
        buffer.writeBytes(name);
        return buffer;
    }

    static ChannelBuffer replySelfGuildInfo(GuildProto proto){
        return getCompressedMessage(MODULE_ID, S2C_REPLY_SELF_GUILD_INFO,
                proto.toByteArray(), false);
    }

    static ChannelBuffer replyGuildList(ClientGuildListProto proto){
        return newProtobufMessage(MODULE_ID, S2C_REPLY_GUILD_LIST, proto);
    }

    static ChannelBuffer createGuildSuccess(byte[] guildName, byte[] flagName,
            int flagKind){
        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID,
                S2C_CREATE_GUILD_SUCCESS, 5 + guildName.length
                        + flagName.length);
        writeUTF(buffer, guildName);
        writeUTF(buffer, flagName);
        buffer.writeByte(flagKind);
        return buffer;
    }

    static ChannelBuffer newGuildCreatedBroadcast(long heroId, byte[] heroName,
            byte[] guildName){
        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID,
                S2C_NEW_GUILD_CREATED_BROADCAST, computeVarInt64Size(heroId)
                        + 2 + heroName.length + guildName.length);
        writeVarInt64(buffer, heroId);
        writeUTF(buffer, heroName);
        buffer.writeBytes(guildName);
        return buffer;
    }

}
