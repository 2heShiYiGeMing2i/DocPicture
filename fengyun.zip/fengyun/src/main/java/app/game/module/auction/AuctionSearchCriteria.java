package app.game.module.auction;

import java.util.Arrays;

import com.mokylin.sink.util.Utils;

class AuctionSearchCriteria{

    public final int serverSequence; // 3bit
    public final int goodsQuality; // 4bit
    public final int goodsLevel; // 16bit
    public final int sortType; // 3bit
    public final int goodsType; // 16bit
    public final int page; // 16bit
    public final byte[] goodsName;

    public final long uniqueNum;

    AuctionSearchCriteria(int goodsQuality, int goodsLevel, int sortType,
            int goodsType, int page, byte[] goodsName, int serverSequence){
        super();
        this.goodsQuality = goodsQuality - 1;
        this.goodsLevel = goodsLevel - 1;
        this.sortType = sortType;
        this.goodsType = goodsType;
        this.page = page;
        this.goodsName = goodsName;
        this.serverSequence = serverSequence;

        this.uniqueNum = (((long) Utils.short2Int(page, goodsType)) << 32)
                | (goodsQuality | (goodsLevel << 4) | (sortType << 23) | (serverSequence << 27));
    }

    @Override
    public int hashCode(){
        return (int) uniqueNum;
    }

    @Override
    public boolean equals(Object obj){
        if (obj instanceof AuctionSearchCriteria){
            AuctionSearchCriteria as = (AuctionSearchCriteria) obj;
            return as.uniqueNum == uniqueNum
                    && Arrays.equals(goodsName, as.goodsName);
        }
        return false;
    }

}
