package app.game.module;

import static com.mokylin.sink.util.BufferUtil.*;

import org.jboss.netty.buffer.ChannelBuffer;

/**
 * @author Liwei
 *
 */
public class GemMessages{

    public static final int MODULE_ID = Modules.GEM_MODULE_ID;

    // 宝石穿戴

    /**
     * 宝石穿戴
     * varint32 宝石插槽
     * if (装备宝石) // 如果是摘除宝石，则不用发下面这个
     *     varint32 要装备的宝石在背包的位置
     * 
     * 宝石插槽 = 装备部件 * 部件宝石插槽个数 + 部件宝石插槽号
     * 
     * 发送这个消息，需要确保背包中有一个空格，否则提示用户整理背包
     */
    static final int C2S_GEM_MOVE = 0;

    /**
     * 宝石穿戴
     * varint32 宝石插槽
     * varint32 宝石阶数，如果是0，说明这个位置上没有宝石
     * 
     * 装备部件 = 宝石插槽 / 部件宝石插槽个数
     * 部件宝石插槽号 = 宝石插槽 % 部件宝石插槽个数
     */
    static final int S2C_GEM_MOVE = 1;

    /**
     * 宝石穿戴失败，附带byte错误码
     * 1、宝石系统还未开放
     * 2、发送的宝石插槽无效
     * 3、宝石插槽上没有宝石，但是又没有发送要装备的宝石位置
     * 4、发送的背包物品无效（位置无效，或者位置上的物品不是宝石，或者物品已经过期，或者物品正在交易中）
     * 5、英雄等级不足，不能装备
     * 6、背包已满，无法放入换下的宝石
     */
    static final int S2C_GEM_MOVE_FAIL = 2;

    static final ChannelBuffer ERR_MOVE_GEM_FAIL_GEM_NOT_OPEN = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_GEM_MOVE_FAIL, 1);

    static final ChannelBuffer ERR_MOVE_GEM_FAIL_INVALID_GEM_SLOT = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_GEM_MOVE_FAIL, 2);

    static final ChannelBuffer ERR_MOVE_GEM_FAIL_GEM_NOT_FOUND = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_GEM_MOVE_FAIL, 3);

    static final ChannelBuffer ERR_MOVE_GEM_FAIL_INVALID_DEPOT_GOODS = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_GEM_MOVE_FAIL, 4);

    static final ChannelBuffer ERR_MOVE_GEM_FAIL_HERO_LEVEL_NOT_ENOUGH = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_GEM_MOVE_FAIL, 5);

    static final ChannelBuffer ERR_MOVE_GEM_FAIL_DEPOT_FULL = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_GEM_MOVE_FAIL, 6);

    // 宝石进阶
    /**
     * 背包宝石进阶
     * varint32 目标宝石阶数，2进3，发3
     * varint32 合成颗数
     * varint32 进阶类型 0-全物品，1-物品不够礼金购买，2-物品不够元宝购买
     * while(availiable)
     *     varint32 pos 物品在背包中的位置
     *     varint32 count 在这个位置扣除多少个
     *     
     * 客户端需要判断背包空间是否足够，背包空格 = (合成个数 + 堆个数 - 1) / 堆个数
     */
    static final int C2S_GEM_DEPOT_UPGRADE = 3;

    /**
     * 进阶成功
     * 
     * 新宝石会通过添加物品消息加到背包中
     */
    static final int S2C_GEM_DEPOT_UPGRADE = 4;

    static final ChannelBuffer GEM_DEPOT_UPGRADE = onlySendHeaderMessage(
            MODULE_ID, S2C_GEM_DEPOT_UPGRADE);

    /**
     * 进阶失败，附带byte错误码
     * 1、宝石系统还未开放
     * 2、这种宝石不存在，比如要合成11级的宝石
     * 3、银两不足(暂时没用，预留)
     * 4、礼金购买，但是礼金不够
     * 5、元宝购买，但是元宝不够
     * 6、客户端消息附带的物品位置或者扣除个数无效（空物品位置，物品已过期，不是升阶物品，物品个数不足）
     * 7、物品不够，但是没有选择礼金购买或者元宝购买
     * 8、真气不足(暂时没用，预留)
     * 9、背包空间不足，无法放入新的宝石
     */
    static final int S2C_GEM_DEPOT_UPGRADE_FAIL = 5;

    static final ChannelBuffer ERR_UPGRADE_DEPOT_GEM_FAIL_GEM_NOT_OPEN = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_GEM_DEPOT_UPGRADE_FAIL, 1);

    static final ChannelBuffer ERR_UPGRADE_DEPOT_GEM_FAIL_INVALID_LEVEL = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_GEM_DEPOT_UPGRADE_FAIL, 2);

    static final ChannelBuffer ERR_UPGRADE_DEPOT_GEM_FAIL_MONEY_NOT_ENOUGH = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_GEM_DEPOT_UPGRADE_FAIL, 3);

    static final ChannelBuffer ERR_UPGRADE_DEPOT_GEM_FAIL_LIJIN_NOT_ENOUGH = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_GEM_DEPOT_UPGRADE_FAIL, 4);

    static final ChannelBuffer ERR_UPGRADE_DEPOT_GEM_FAIL_YUANBAO_NOT_ENOUGH = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_GEM_DEPOT_UPGRADE_FAIL, 5);

    static final ChannelBuffer ERR_UPGRADE_DEPOT_GEM_FAIL_INVALID_POS = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_GEM_DEPOT_UPGRADE_FAIL, 6);

    static final ChannelBuffer ERR_UPGRADE_DEPOT_GEM_FAIL_GOODS_NOT_ENOUGH = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_GEM_DEPOT_UPGRADE_FAIL, 7);

    static final ChannelBuffer ERR_UPGRADE_DEPOT_GEM_FAIL_REAL_AIR_NOT_ENOUGH = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_GEM_DEPOT_UPGRADE_FAIL, 8);

    static final ChannelBuffer ERR_UPGRADE_DEPOT_GEM_FAIL_DEPOT_FULL = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_GEM_DEPOT_UPGRADE_FAIL, 9);

    /**
     * 插槽宝石进阶
     * varint32 宝石插槽号
     * varint32 进阶类型 0-全物品，1-物品不够礼金购买，2-物品不够元宝购买
     * while(availiable)
     *     varint32 pos 物品在背包中的位置
     *     varint32 count 在这个位置扣除多少个
     */
    static final int C2S_GEM_UPGRADE = 6;

    /**
     * 插槽宝石进阶成功
     * varint32 宝石插槽
     * varint32 宝石阶数
     * 
     * 装备部件 = 宝石插槽 / 部件宝石插槽个数
     * 部件宝石插槽号 = 宝石插槽 % 部件宝石插槽个数
     */
    static final int S2C_GEM_UPGRADE = 7;

    /**
     * 插槽宝石进阶失败，附带byte错误码
     * 1、宝石系统还未开放
     * 2、真气不足(暂时没用，预留)
     * 3、银两不足(暂时没用，预留)
     * 4、礼金购买，但是礼金不够
     * 5、元宝购买，但是元宝不够
     * 6、客户端消息附带的物品位置或者扣除个数无效（空物品位置，物品已过期，不是升阶物品，物品个数不足）
     * 7、物品不够，但是没有选择礼金购买或者元宝购买
     * 8、发送的宝石插槽无效
     * 9、宝石插槽上没有宝石
     * 10、当前宝石已经是最高级宝石
     * 11、进阶后宝石等级超过英雄等级
     */
    static final int S2C_GEM_UPGRADE_FAIL = 8;

    static final ChannelBuffer ERR_UPGRADE_GEM_FAIL_GEM_NOT_OPEN = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_GEM_UPGRADE_FAIL, 1);

    static final ChannelBuffer ERR_UPGRADE_GEM_FAIL_REAL_AIR_NOT_ENOUGH = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_GEM_UPGRADE_FAIL, 2);

    static final ChannelBuffer ERR_UPGRADE_GEM_FAIL_MONEY_NOT_ENOUGH = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_GEM_UPGRADE_FAIL, 3);

    static final ChannelBuffer ERR_UPGRADE_GEM_FAIL_LIJIN_NOT_ENOUGH = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_GEM_UPGRADE_FAIL, 4);

    static final ChannelBuffer ERR_UPGRADE_GEM_FAIL_YUANBAO_NOT_ENOUGH = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_GEM_UPGRADE_FAIL, 5);

    static final ChannelBuffer ERR_UPGRADE_GEM_FAIL_INVALID_POS = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_GEM_UPGRADE_FAIL, 6);

    static final ChannelBuffer ERR_UPGRADE_GEM_FAIL_GOODS_NOT_ENOUGH = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_GEM_UPGRADE_FAIL, 7);

    static final ChannelBuffer ERR_UPGRADE_GEM_FAIL_INVALID_GEM_POS = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_GEM_UPGRADE_FAIL, 8);

    static final ChannelBuffer ERR_UPGRADE_GEM_FAIL_GEM_NOT_FOUND = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_GEM_UPGRADE_FAIL, 9);

    static final ChannelBuffer ERR_UPGRADE_GEM_FAIL_MAX_LEVEL = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_GEM_UPGRADE_FAIL, 10);

    static final ChannelBuffer ERR_UPGRADE_GEM_FAIL_HERO_LEVEL_NOT_ENOUGH = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_GEM_UPGRADE_FAIL, 11);

    static ChannelBuffer moveGemMsg(int gemPos, int gemLevel){
        return onlySendHeadAnd2VarInt32Message(MODULE_ID, S2C_GEM_MOVE, gemPos,
                gemLevel);
    }

    static ChannelBuffer upgradeGemMsg(int gemPos, int gemLevel){
        return onlySendHeadAnd2VarInt32Message(MODULE_ID, S2C_GEM_UPGRADE,
                gemPos, gemLevel);
    }
}
