package app.game.module;

import static app.game.module.DivineMessages.*;
import static app.protobuf.LogContent.LogEnum.OperateType.DIVINE;

import java.util.Deque;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.jboss.netty.buffer.ChannelBuffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.data.ConfigService;
import app.game.data.UpgradeData;
import app.game.data.UpgradeData.ReduceCostResult;
import app.game.data.divine.DivineData;
import app.game.data.divine.DivineDatas;
import app.game.data.divine.DivineGlobalLog;
import app.game.data.divine.DivineGlobalLogs;
import app.game.data.goods.Goods;
import app.game.data.goods.GoodsData;
import app.game.data.goods.GoodsShowData;
import app.game.entity.Depot;
import app.game.entity.Divination;
import app.game.entity.Hero;
import app.game.entity.record.goods.GoodsOwnership;
import app.game.module.scene.OneThreadJob;
import app.game.service.DBService;
import app.game.service.IThreadService;
import app.game.service.TimeService;
import app.game.service.WorldService;
import app.protobuf.ConfigContent.ShengWangType;
import app.protobuf.GoodsServerContent.GoodsServerProto;
import app.utils.VariableConfig;

import com.google.common.collect.Lists;
import com.google.inject.Inject;
import com.mokylin.collection.IntArrayList;
import com.mokylin.sink.util.BufferUtil;

/**
 * @author Liwei
 *
 */
public class DivineModule{

    private static final Logger logger = LoggerFactory
            .getLogger(DivineModule.class);

    private static final ThreadLocal<List<byte[]>> localDivineGoodsDataList = new ThreadLocal<List<byte[]>>(){
        @Override
        protected List<byte[]> initialValue(){
            return Lists.newArrayListWithCapacity(20);
        }
    };

    private static final ThreadLocal<List<byte[]>> localDivineLuckyGoodsDataList = new ThreadLocal<List<byte[]>>(){
        @Override
        protected List<byte[]> initialValue(){
            return Lists.newArrayListWithCapacity(20);
        }
    };

    private final TimeService timeService;

    private final WorldService worldService;

    private final DBService dbService;

    private final GoodsContainerModule goodsContainerModule;

    private final DivineDatas divineDatas;

    private final DivineGlobalLogs globalLogs;

    private final UpgradeData divineUpgradeData;

    private final VariableConfig config;

    @Inject
    DivineModule(TimeService timeService, WorldService worldService,
            final IThreadService threadService, DBService dbService,
            ConfigService configService,
            GoodsContainerModule goodsContainerModule, DivineDatas divineDatas,
            DivineGlobalLogs globalLogs, VariableConfig config)
            throws Throwable{
        this.timeService = timeService;
        this.worldService = worldService;
        this.dbService = dbService;
        this.goodsContainerModule = goodsContainerModule;
        this.divineDatas = divineDatas;
        this.globalLogs = globalLogs;
        this.config = config;

        divineUpgradeData = divineDatas.getUpgradeData();

        loadGlobalLog(configService);

        // 定时保存知天命全局日志数据
        threadService.getScheduledExecutorService().scheduleAtFixedRate(
                new Runnable(){
                    @Override
                    public void run(){
                        try{
                            if (saveJob.tryCAS()){
                                threadService.getDbExecutor().execute(saveJob);
                            }
                        } catch (Throwable ex){
                            logger.error("DivineModule.定时保存任务出错", ex);
                        }
                    }
                }, 2, 10, TimeUnit.MINUTES);
    }

    void onMessage(int sequenceID, ChannelBuffer buffer, HeroController hc){

        switch (sequenceID){
            case DivineMessages.C2S_DIVINE_TRY:{
                onDivineTry(hc, buffer);
                return;
            }
            case DivineMessages.C2S_DIVINE_STORAGE:{
                onGetDivineStorage(hc, buffer);
                return;
            }
            case DivineMessages.C2S_DIVINE_STORAGE_MOVE:{
                onMoveDivineStorageGoods(hc, buffer);
                return;
            }
            case DivineMessages.C2S_DIVINE_STORAGE_MOVE_ALL:{
                onMoveAllDivineStorageGoods(hc, buffer);
                return;
            }
            case DivineMessages.C2S_DIVINE_GLOBAL_LOG:{
                onGetGlobalLog(hc, buffer);
                return;
            }
            case DivineMessages.C2S_DIVINE_SELF_LOG:{
                onGetSelfLog(hc, buffer);
                return;
            }
            case DivineMessages.C2S_CLEAN:{
                onCleanStorage(hc, buffer);
                return;
            }
            default:{
                logger.error("DivineModule模块收到未知消息: {}", sequenceID);
            }
        }
    }

    private void onGetSelfLog(HeroController hc, ChannelBuffer buffer){
        if (hc.divineSelfLogProcessed){
            logger.warn("请求英雄自己的知天命日志，但是已经请求过了");
            hc.sendMessage(ERR_DIVINE_SELF_LOG_FAIL_ALREADY_ASKED);
            return;
        }
        hc.divineSelfLogProcessed = true;

        hc.sendMessage(divineSelfLog(hc.getHero().getDivination()
                .getDivineSelfLogs()));
    }

    private void onGetGlobalLog(HeroController hc, ChannelBuffer buffer){
        if (hc.divineGlobalLogProcessed){
            logger.warn("请求全局的知天命日志，但是已经请求过了");
            hc.sendMessage(ERR_DIVINE_GLOBAL_LOG_FAIL_ALREADY_ASKED);
            return;
        }
        hc.divineGlobalLogProcessed = true;

        hc.sendMessage(globalLogs.getDivineGlobalLogMsg());
    }

    private void onMoveDivineStorageGoods(HeroController hc,
            ChannelBuffer buffer){

        // 只移动一个物品
        int spos = BufferUtil.readVarInt32(buffer);

        List<Goods> goodsList = hc.getHero().getDivination().getDivineStorage();
        if (spos < 0 || spos >= goodsList.size()){
            logger.warn("知天命仓库取出物品，仓库位置无效");
            hc.sendMessage(ERR_DIVINE_STORAGE_MOVE_FAIL_SPOS_INVALID);
            return;
        }

        Depot depot = hc.getDepot();

        int tpos = BufferUtil.readVarInt32(buffer);
        if (depot.isInvalidPos(tpos)){
            logger.warn("知天命仓库取出物品，背包位置无效");
            hc.sendMessage(ERR_DIVINE_STORAGE_MOVE_FAIL_TPOS_INVALID);
            return;
        }

        if (depot.isLocked(tpos)){
            logger.warn("知天命仓库取出物品，背包位置已锁定");
            hc.sendMessage(ERR_DIVINE_STORAGE_MOVE_FAIL_TPOS_INVALID);
            return;
        }

        if (depot.get(tpos) != null){
            logger.warn("知天命仓库取出物品，背包位置已经存在物品");
            hc.sendMessage(ERR_DIVINE_STORAGE_MOVE_FAIL_TPOS_INVALID);
            return;
        }

        depot.set(tpos, goodsList.remove(spos));
        hc.sendMessage(moveGoodsMsg(spos, tpos));

        // 此处不处理任务，这地方不应该产出任务所需物品
    }

    private void onMoveAllDivineStorageGoods(HeroController hc,
            ChannelBuffer buffer){
        List<Goods> goodsList = hc.getHero().getDivination().getDivineStorage();
        if (goodsList.isEmpty()){
            logger.warn("知天命仓库取出全部物品，但是仓库中没有物品");
            hc.sendMessage(ERR_DIVINE_STORAGE_MOVE_ALL_FAIL_EMPTY_STORAGE);
            return;
        }

        Depot depot = hc.getDepot();
        if (!depot.hasEnoughEmptyCount(goodsList.size())){
            logger.warn("知天命仓库取出全部物品，但是背包空格不足");
            hc.sendMessage(ERR_DIVINE_STORAGE_MOVE_ALL_FAIL_DEPOT_FULL);
            return;
        }

        IntArrayList emptyPosList = depot.getEmptyPos(goodsList.size());
        if (emptyPosList.size() < goodsList.size()){
            logger.warn("知天命仓库取出全部物品，空格判断过了，但是没获取到格子");
            hc.sendMessage(ERR_DIVINE_STORAGE_MOVE_ALL_FAIL_DEPOT_FULL);
            return;
        }

        int idx = 0;
        for (Goods g : goodsList){
            int pos = emptyPosList.get(idx++);

            Goods o = depot.set(pos, g);
            assert o == null: "moveAllDivineGoods时找到的空位置上面有物品";
        }

        // 清空仓库
        goodsList.clear();

        hc.sendMessage(moveGoodsMsg(emptyPosList));
    }

    private void onCleanStorage(HeroController hc, ChannelBuffer buffer){

        long ctime = timeService.getCurrentTime();
        if (ctime < hc.nextCleanDivineStorageTime){
            logger.warn("知天命仓库整理，但是下次整理时间未到");
            hc.sendMessage(ERR_CLEAN_FAIL_CLEAN_TIME_NOT_REACHED);
            return;
        }

        List<Goods> goodsList = hc.getHero().getDivination().getDivineStorage();
        if (goodsList.isEmpty()){
            logger.warn("知天命仓库整理，但是仓库中没有物品");
            hc.sendMessage(ERR_CLEAN_FAIL_EMPTY_STORAGE);
            return;
        }

        hc.nextCleanDivineStorageTime = ctime
                + VariableConfig.CLEAN_GOODS_CONTAINER_INTERVAL;

        Goods[] goodsArray = goodsList.toArray(Goods.EMPTY_GOODS_ARRAY);
        goodsContainerModule.cleanGoodsArray(hc, goodsArray);

        ChannelBuffer cleanMsg = getCleanSuccessBuffer(hc.nextCleanDivineStorageTime);
        goodsList.clear();

        for (Goods g : goodsArray){
            if (g == null){
                break;
            }

            goodsList.add(g);
            BufferUtil.writeVarInt32(cleanMsg, g.pos);
            BufferUtil.writeVarInt32(cleanMsg, g.getCount());
        }

        hc.sendMessage(cleanMsg);
    }

    private void onGetDivineStorage(HeroController hc, ChannelBuffer buffer){
        if (hc.divineStorageProcessed){
            logger.warn("请求英雄知天命仓库，但是已经请求过了");
            hc.sendMessage(ERR_DIVINE_STORAGE_FAIL_ALREADY_ASKED);
            return;
        }
        hc.divineStorageProcessed = true;

        hc.sendMessage(divineStorageMsg(hc.getHero().getDivination()
                .getDivineStorage()));
    }

    private void onDivineTry(HeroController hc, ChannelBuffer buffer){
        int tryTimes = BufferUtil.readVarInt32(buffer);

        Hero hero = hc.getHero();
        Divination divination = hero.getDivination();

        boolean isMoneyDivine = divination.getDivineTimes() < config.DIVINE_MONEY_TIMES;

        // 一次或者10次
        if (tryTimes != 1 && (isMoneyDivine || tryTimes != 10)){
            logger.warn("知天命，客户端发送的次数无效");
            hc.sendMessage(ERR_DIVINE_TRY_FAIL_DIVINE_TIMES_INVALID);
            return;
        }

        List<Goods> goodsList = divination.getDivineStorage();
        // 检查知天命仓库是否有足够的空间
        if (tryTimes + goodsList.size() > config.DIVINE_STORAGE_CAPCITY){
            logger.warn("知天命，仓库空间不足");
            hc.sendMessage(ERR_DIVINE_TRY_FAIL_STORAGE_FULL);
            return;
        }

        long ctime = timeService.getCurrentTime();
        if (isMoneyDivine){
            // 扣钱
            if (!hc.getHeroMiscModule().reduceMoney(
                    config.DIVINE_MONEY_COST * tryTimes, DIVINE, null)){
                logger.warn("知天命，银两不足");
                hc.sendMessage(ERR_DIVINE_TRY_FAIL_MONEY_NOT_ENOUGH);
                return;
            }

        } else{
            int reduceGoodsCount = tryTimes
                    * divineUpgradeData.getUpgradeGoodsCount();

            ReduceCostResult result = divineUpgradeData.tryReduceGoods("知天命",
                    hc.getHeroMiscModule(), ctime, hero, hc.getSender(),
                    buffer, goodsContainerModule, reduceGoodsCount, DIVINE,
                    null, false);

            switch (result.getStatus()){
                case SUCCESS:{
                    break;
                }
                case GOODS_NOT_ENOUGH:{
                    hc.sendMessage(ERR_DIVINE_TRY_FAIL_GOODS_NOT_ENOUGH);
                    return;
                }
                case YUANBAO_NOT_ENOUGH:{
                    hc.sendMessage(ERR_DIVINE_TRY_FAIL_YUANBAO_NOT_ENOUGH);
                    return;
                }
                case INVALID_POS_COUNT:{
                    hc.sendMessage(ERR_DIVINE_TRY_FAIL_POS_COUNT_INVALID);
                    return;
                }
                default:{
                    logger.error("知天命，遇到未知的失败类型，{}", result);
                    hc.sendMessage(ERR_DIVINE_TRY_FAIL_GOODS_NOT_ENOUGH);
                    return;
                }
            }
        }

        // 成功了
        divination.setDivineTimes(divination.getDivineTimes() + tryTimes);

        int blessAmount = divination.getDivineBlessAmount();
        int luckyTimes = 0;
        for (int i = 0; i < tryTimes; i++){
            if (blessAmount < divineUpgradeData.getUpgradeMaxBless()){
                blessAmount += divineUpgradeData.randomBlessAmount();
            } else{
                blessAmount = 0;
                luckyTimes++;
            }
        }

        if (blessAmount > divineUpgradeData.getUpgradeMaxBless()){
            blessAmount = divineUpgradeData.getUpgradeMaxBless();
        }

        divination.setDivineBlessAmount(blessAmount);

        Deque<GoodsShowData> selfLogs = divination.getDivineSelfLogs();

        List<byte[]> goodsDataList = localDivineGoodsDataList.get();
        goodsDataList.clear();

        List<byte[]> luckyGoodsDataList = localDivineLuckyGoodsDataList.get();
        luckyGoodsDataList.clear();

        GoodsOwnership ownership = hero.getGoodsOwnership();

        int divinePos = 0;
        for (int i = 0; i < tryTimes; i++){
            DivineData divineData = null;
            if (i < luckyTimes){
                divineData = divineDatas.luckyRandom();
            } else{
                divineData = divineDatas.random();
            }

            divinePos = divineData.getId();

            Goods g = divineData.random(ctime);
            if (isMoneyDivine){
                g.bind(); // 免费次数获得的物品是绑定的
            }

            goodsList.add(g); // 加物品

            // 数据
            GoodsData data = g.getData();
            byte[] dynamicData = g.encodeBytes4Client();
            GoodsServerProto serverProto = g.encode();
            goodsDataList.add(data.getProtoBytes());
            goodsDataList.add(dynamicData);

            // 英雄日志
            selfLogs.add(new GoodsShowData(data, dynamicData, serverProto,
                    ctime));
            if (selfLogs.size() > VariableConfig.DIVINE_LOG_MAX_COUNT){
                selfLogs.poll();
            }

            if (divineData.isLucky()){
                luckyGoodsDataList.add(data.getProtoBytes());
                luckyGoodsDataList.add(dynamicData);

                // 全局日志
                globalLogs.addLog(new DivineGlobalLog(hero.getID(), hero
                        .getNameBytes(), data, dynamicData, serverProto));
            }

            ownership.addGoods(g.getGoodsIdentifier(), g.getCount(), DIVINE, 0,
                    ctime, g.needLog());
        }

        hc.sendMessage(tryDivineMsg(blessAmount, divinePos, ctime,
                goodsDataList));
        goodsDataList.clear();

        if (!luckyGoodsDataList.isEmpty()){
            ChannelBuffer luckyMsg = divineBroadcastMsg(hero.getID(),
                    hero.getNameBytes(), luckyGoodsDataList);

            worldService.broadcastToEnteredFirstSceneHeroWithSameServerData(
                    luckyMsg, hc.getServerData(), 0);
            luckyGoodsDataList.clear();
        }

        // 声望
        hc.getHeroMiscModule().tryCompleteShengWangTask(
                ShengWangType.SW_DIVINE, true, 1);
    }

    // 定时保存

    private final OneThreadJob saveJob = new OneThreadJob(){

        @Override
        protected void doRun(){
            save();
        }
    };

    private void loadGlobalLog(ConfigService configService) throws Throwable{
        byte[] globalData = dbService
                .loadGlobalData(DBService.KEY_DIVINE_GLOBAL_LOG);
        globalLogs.decode(globalData, configService);
    }

    public void save(){
        try{
            byte[] data = globalLogs.encode().toByteArray();
            if (data != null && data.length > 0){
                dbService.saveGlobalData(DBService.KEY_DIVINE_GLOBAL_LOG, data);
            }
        } catch (Throwable ex){
            logger.error("知天命全局日志保存出错", ex);
        }
    }
}
