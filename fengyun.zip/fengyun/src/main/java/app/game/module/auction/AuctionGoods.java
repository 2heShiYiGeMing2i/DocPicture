package app.game.module.auction;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.data.goods.GoodsData;

import com.mokylin.sink.util.BufferUtil;

class AuctionGoods extends AuctionItem{

    private final byte[] staticInfo;
    private final byte[] dynamicInfo;

    AuctionGoods(GoodsData goodsData, long id, byte[] clientProto, int cost,
            long combineId, byte[] sellerHeroName){
        super(id, combineId, sellerHeroName, cost);

        this.staticInfo = goodsData.getProtoBytes();
        this.dynamicInfo = clientProto;
    }

    @Override
    public void writeGoods(ChannelBuffer buffer){
        BufferUtil.writeVarInt32(buffer, staticInfo.length);
        buffer.writeBytes(staticInfo);
        BufferUtil.writeVarInt32(buffer, dynamicInfo.length);
        buffer.writeBytes(dynamicInfo);
    }

}
