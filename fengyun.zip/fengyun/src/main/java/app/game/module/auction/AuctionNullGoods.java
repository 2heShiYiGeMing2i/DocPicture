package app.game.module.auction;

import org.jboss.netty.buffer.ChannelBuffer;

import com.mokylin.sink.util.Empty;

public class AuctionNullGoods extends AuctionItem{

    protected AuctionNullGoods(){
        super(0, 0, Empty.BYTE_ARRAY, 0);
    }

    @Override
    public void writeGoods(ChannelBuffer buffer){

    }

    @Override
    public void writeGoodsWithoutHeroInfo(ChannelBuffer buffer){

    }

    @Override
    public void writeGoodsWithHeroInfo(ChannelBuffer buffer){

    }
}
