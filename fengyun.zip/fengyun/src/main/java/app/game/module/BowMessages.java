package app.game.module;

import static com.mokylin.sink.util.BufferUtil.*;

import org.jboss.netty.buffer.ChannelBuffer;

import app.protobuf.HeroContent.BowProto;

import com.mokylin.sink.util.BufferUtil;

/**
 * @author Liwei
 *
 */
public class BowMessages{

    public static final int MODULE_ID = Modules.BOW_MODULE_ID;

    /**
     * 获取弓箭，有服务器主动推送，在完成任务开启弓箭系统时会收到
     * bytes BowProto
     */
    static final int S2C_BOW_GIVE = 0;

    /**
     * 凤舞弓进阶
     * varint32 进阶类型 0-全物品，1-物品不够礼金购买，2-物品不够元宝购买
     * while(availiable)
     *     varint32 pos 物品在背包中的位置
     *     varint32 count 在这个位置扣除多少个
     */
    static final int C2S_BOW_UPGRADE = 1;

    /**
     * 凤舞弓进阶成功，附带以下信息
     * varint32 最新的阶数
     */
    static final int S2C_BOW_UPGRADE_SUCCESS = 2;

    /**
     * 凤舞弓进阶失败，附带以下信息
     * varint32 最新的祝福值
     */
    static final int S2C_BOW_UPDATE_BLESS = 3;

    /**
     * 凤舞弓进阶失败，附带Byte错误码
     * 1、英雄还没有凤舞弓
     * 2、英雄凤舞弓已经满级了
     * 3、银两不足
     * 4、礼金购买，但是礼金不够
     * 5、元宝购买，但是元宝不够
     * 6、客户端消息附带的物品位置或者扣除个数无效（空物品位置，物品已过期，不是升阶物品，物品个数不足）
     * 7、物品不够，但是没有选择礼金购买或者元宝购买
     * 8、凤舞弓开放时间未到，不能升阶
     */
    static final int S2C_BOW_UPGRADE_FAIL = 4;

    static final ChannelBuffer ERR_UPGRADE_BOW_FAIL_NOT_BOW = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_BOW_UPGRADE_FAIL, 1);

    static final ChannelBuffer ERR_UPGRADE_BOW_FAIL_MAX_LEVEL = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_BOW_UPGRADE_FAIL, 2);

    static final ChannelBuffer ERR_UPGRADE_BOW_FAIL_MONEY_NOT_ENOUGH = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_BOW_UPGRADE_FAIL, 3);

    static final ChannelBuffer ERR_UPGRADE_BOW_FAIL_LIJIN_NOT_ENOUGH = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_BOW_UPGRADE_FAIL, 4);

    static final ChannelBuffer ERR_UPGRADE_BOW_FAIL_YUANBAO_NOT_ENOUGH = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_BOW_UPGRADE_FAIL, 5);

    static final ChannelBuffer ERR_UPGRADE_BOW_FAIL_INVALID_POS = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_BOW_UPGRADE_FAIL, 6);

    static final ChannelBuffer ERR_UPGRADE_BOW_FAIL_GOODS_NOT_ENOUGH = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_BOW_UPGRADE_FAIL, 7);

    static final ChannelBuffer ERR_UPGRADE_BOW_FAIL_BOW_NOT_OPEN = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_BOW_UPGRADE_FAIL, 8);

    /**
     * 弓箭进阶祝福值清空时间，附带以下信息
     * varint64 清空时间
     */
    static final int S2C_BOW_BLESS_CLEAR_TIME = 5;

    /**
     * 清理弓箭祝福值，收到此消息后，将弓箭祝福值重置为0
     */
    static final int S2C_BOW_CLEAR_BLESS_AMOUNT = 6;

    public static final ChannelBuffer CLEAR_BLESS_MSG = onlySendHeaderMessage(
            MODULE_ID, S2C_BOW_CLEAR_BLESS_AMOUNT);

    /**
     * 升级凤舞弓广播
     * UTF 英雄名称
     * varint32 最新的凤舞弓阶数
     */
    static final int S2C_BOW_UPGRADE_BROADCAST = 7;

    // 凤舞箭

//    /**
//     * 凤舞箭进阶（包括激活）
//     * varint32 进阶类型 0-全物品，1-物品不够礼金购买，2-物品不够元宝购买
//     * while(availiable)
//     *     varint32 pos 物品在背包中的位置
//     *     varint32 count 在这个位置扣除多少个
//     */
//    static final int C2S_ARROW_UPGRADE = 20;
//
//    /**
//     * 凤舞箭进阶成功
//     * varint32 凤舞箭阶数
//     * varint32 星级（从0开始，0表示第一个星正在升级）
//     * varint32 最新经验值
//     */
//    static final int S2C_ARROW_UPGRADE = 21;
//
//    /**
//     * 凤舞箭星级更新
//     * varint32 星级（从0开始，0表示第一个星正在升级）
//     * varint32 最新经验值
//     */
//    static final int S2C_ARROW_UPDATE_STAR = 22;
//
//    /**
//     * 凤舞箭经验更新
//     * varint32 最新经验值
//     * 
//     * 本次新增经验，客户端根据服务器发送的最新值-客户端当前值计算得到
//     */
//    static final int S2C_ARROW_UPDATE_EXP = 23;
//
//    /**
//     * 凤舞箭进阶失败，附带Byte错误码
//     * 1、英雄还没有凤舞弓，或者凤舞弓等级不足
//     * 2、英雄凤舞箭已经满级了
//     * 3、银两不足
//     * 4、礼金购买，但是礼金不够
//     * 5、元宝购买，但是元宝不够
//     * 6、客户端消息附带的物品位置或者扣除个数无效（空物品位置，物品已过期，不是升阶物品，物品个数不足）
//     * 7、物品不够，但是没有选择礼金购买或者元宝购买
//     */
//    static final int S2C_ARROW_UPGRADE_FAIL = 24;
//
//    static final ChannelBuffer ERR_UPGRADE_ARROW_FAIL_INVALID_BOW = onlySendHeadAndAByteMessage(
//            MODULE_ID, S2C_ARROW_UPGRADE_FAIL, 1);
//
//    static final ChannelBuffer ERR_UPGRADE_ARROW_FAIL_MAX_LEVEL = onlySendHeadAndAByteMessage(
//            MODULE_ID, S2C_ARROW_UPGRADE_FAIL, 2);
//
//    static final ChannelBuffer ERR_UPGRADE_ARROW_FAIL_MONEY_NOT_ENOUGH = onlySendHeadAndAByteMessage(
//            MODULE_ID, S2C_ARROW_UPGRADE_FAIL, 3);
//
//    static final ChannelBuffer ERR_UPGRADE_ARROW_FAIL_LIJIN_NOT_ENOUGH = onlySendHeadAndAByteMessage(
//            MODULE_ID, S2C_ARROW_UPGRADE_FAIL, 4);
//
//    static final ChannelBuffer ERR_UPGRADE_ARROW_FAIL_YUANBAO_NOT_ENOUGH = onlySendHeadAndAByteMessage(
//            MODULE_ID, S2C_ARROW_UPGRADE_FAIL, 5);
//
//    static final ChannelBuffer ERR_UPGRADE_ARROW_FAIL_INVALID_POS = onlySendHeadAndAByteMessage(
//            MODULE_ID, S2C_ARROW_UPGRADE_FAIL, 6);
//
//    static final ChannelBuffer ERR_UPGRADE_ARROW_FAIL_GOODS_NOT_ENOUGH = onlySendHeadAndAByteMessage(
//            MODULE_ID, S2C_ARROW_UPGRADE_FAIL, 7);
//
//    /**
//     * 升级凤舞箭广播
//     * UTF 英雄名称
//     * varint32 最新的凤舞箭阶数
//     */
//    static final int S2C_ARROW_UPGRADE_BROADCAST = 25;

    /**
     * 领取凤舞弓
     */
    static final int C2S_GET_FREE_BOW = 26;

    /**
     * 领取凤舞弓失败，附带Byte错误消息
     * 1、英雄已经有弓箭了
     * 2、等级不足
     */
    static final int S2C_GET_FREE_BOW_FAIL = 27;

    static final ChannelBuffer ERR_GET_FREE_BOW_FAIL_OWN_BOW = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_GET_FREE_BOW_FAIL, 1);

    static final ChannelBuffer ERR_GET_FREE_BOW_FAIL_LEVEL_NOT_ENOUGH = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_GET_FREE_BOW_FAIL, 2);

    /**
     * 佩戴凤舞弓
     * varint32 凤舞弓，0表示隐藏凤舞弓
     */
    static final int C2S_CHANGE_BOW_RESOURCE = 28;

    /**
     * 佩戴凤舞弓成功
     * varint32 凤舞弓，0表示隐藏凤舞弓
     */
    static final int S2C_CHANGE_BOW_RESOURCE = 29;

    static final ChannelBuffer HIDE_BOW_MSG = changeBowResourceMsg(0);

    /**
     * 佩戴凤舞弓失败，附带Byte错误消息
     * 1、英雄还没有凤舞
     * 2、凤舞等级不足
     */
    static final int S2C_CHANGE_BOW_RESOURCE_FAIL = 30;

    static final ChannelBuffer ERR_CHANGE_BOW_RESOURCE_FAIL_NOT_BOW = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_CHANGE_BOW_RESOURCE_FAIL, 1);

    static final ChannelBuffer ERR_CHANGE_BOW_RESOURCE_FAIL_NOT_ENOUGH_LEVEL = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_CHANGE_BOW_RESOURCE_FAIL, 2);

    // ------------- end of msg --------------

    public static ChannelBuffer giveBowMsg(BowProto proto){
        return newProtobufMessage(MODULE_ID, S2C_BOW_GIVE, proto);
    }

    public static ChannelBuffer upgradeBowSuccess(int bow){
        return onlySendHeadAndAVarInt32Message(MODULE_ID,
                S2C_BOW_UPGRADE_SUCCESS, bow);
    }

    static ChannelBuffer updateBowBlassMsg(int bless){
        return onlySendHeadAndAVarInt32Message(MODULE_ID, S2C_BOW_UPDATE_BLESS,
                bless);
    }

    static ChannelBuffer updateBowBlessClearTime(long time){
        return onlySendHeadAndAVarInt64Message(MODULE_ID,
                S2C_BOW_BLESS_CLEAR_TIME, time);
    }

    static ChannelBuffer upgradeBowBroadcastMsg(byte[] hero, int bow){
        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID,
                S2C_BOW_UPGRADE_BROADCAST, BufferUtil.computeVarInt32Size(bow)
                        + 2 + hero.length);

        BufferUtil.writeUTF(buffer, hero);
        BufferUtil.writeVarInt32(buffer, bow);

        return buffer;
    }

    // ---

//    static ChannelBuffer upgradeArrowSuccess(int arrow, int star, int newExp){
//        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID,
//                S2C_ARROW_UPGRADE, computeVarInt32Size(arrow)
//                        + computeVarInt32Size(star)
//                        + computeVarInt32Size(newExp));
//
//        BufferUtil.writeVarInt32(buffer, arrow);
//        BufferUtil.writeVarInt32(buffer, star);
//        BufferUtil.writeVarInt32(buffer, newExp);
//
//        return buffer;
//    }
//
//    static ChannelBuffer updateArrowStarMsg(int star, int newExp){
//        return onlySendHeadAnd2VarInt32Message(MODULE_ID,
//                S2C_ARROW_UPDATE_STAR, star, newExp);
//    }
//
//    static ChannelBuffer updateArrowExpMsg(int newExp){
//        return onlySendHeadAndAVarInt32Message(MODULE_ID, S2C_ARROW_UPDATE_EXP,
//                newExp);
//    }
//
//    static ChannelBuffer upgradeArrowBroadcastMsg(byte[] hero, int arrow){
//        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID,
//                S2C_ARROW_UPGRADE_BROADCAST,
//                BufferUtil.computeVarInt32Size(arrow) + 2 + hero.length);
//
//        BufferUtil.writeUTF(buffer, hero);
//        BufferUtil.writeVarInt32(buffer, arrow);
//
//        return buffer;
//    }

    public static ChannelBuffer changeBowResourceMsg(int bow){
        return onlySendHeadAndAVarInt32Message(MODULE_ID,
                S2C_CHANGE_BOW_RESOURCE, bow);
    }
}
