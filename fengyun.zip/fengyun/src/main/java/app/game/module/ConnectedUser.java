package app.game.module;

import static app.game.module.MiscModule.DisconnectReason.BANNED;

import java.util.concurrent.Executor;

import org.jboss.netty.buffer.ChannelBuffer;
import org.joda.time.DateTimeConstants;

import app.game.data.ServerData;
import app.game.entity.ClientTimeChecker;
import app.game.entity.Hero;
import app.game.entity.User;
import app.game.module.GMDoingModule.GMCommand;
import app.game.module.MiscModule.DisconnectReason;
import app.message.IDisconnector;
import app.message.IDroppableSender;
import app.protobuf.HeroContent.LoginType;

import com.mokylin.sink.util.annotation.MultiThread;
import com.mokylin.sink.util.annotation.SelfThreadOnly;
import com.mokylin.sink.util.holder.BooleanHolder;

public class ConnectedUser{

    private final User user;
    private final Executor taskExec;
    private final IDroppableSender sender;
    private final IDisconnector disconnector;
    private final long combinedID;
    private final Long combindedBigLongID;
    private final LoginType loginType;
    private final String vClientIP;

    /**
     * 来自哪一个联服组
     */
    private final ServerData serverData;
    private HeroController hc;

    @SelfThreadOnly
    private final BooleanHolder isOffline;

    /**
     * 检查客户端有没有用外挂调时间
     *
     * 进入第一个场景后初始化
     */
    private final ClientTimeChecker clientTimeChecker;

    @MultiThread
    private GMCommand command;

    public ConnectedUser(User user, Executor taskExec, IDroppableSender sender,
            IDisconnector disconnector, LoginType loginType, String vClientIP,
            ServerData serverData, long ctime){
        this.user = user;
        this.taskExec = taskExec;
        this.sender = sender;
        this.disconnector = disconnector;
        this.combinedID = user.getCombineID();
        this.combindedBigLongID = Long.valueOf(combinedID);
        this.loginType = loginType;
        this.vClientIP = vClientIP;
        this.serverData = serverData;
        this.isOffline = new BooleanHolder(false);
        this.clientTimeChecker = new ClientTimeChecker(ctime);
    }

    public ClientTimeChecker getClientTimeChecker(){
        return clientTimeChecker;
    }

    public ServerData getServerData(){
        return serverData;
    }

    public boolean isGMLogin(){
        return loginType == LoginType.GM_LOGIN;
    }

    public LoginType getLoginType(){
        return loginType;
    }

    public String getClientIP(){
        return vClientIP;
    }

    @SelfThreadOnly
    public void setIfOffline(){
        this.isOffline.set(true);
    }

    @SelfThreadOnly
    public BooleanHolder getIsOffline(){
        return isOffline;
    }

    public long getCombinedID(){
        return combinedID;
    }

    public Long getCombinedBigLongID(){
        return combindedBigLongID;
    }

    /**
     * 写给用户自己
     *
     * @param buffer
     */
    public void writeTo(ChannelBuffer buffer){
        user.writeTo(buffer, loginType);
    }

    public User getUser(){
        return user;
    }

    public void disconnect(DisconnectReason reason){
        disconnector.disconnect(reason);
    }

    public IDroppableSender getSender(){
        return sender;
    }

    IDisconnector getDisconnector(){
        return disconnector;
    }

    public Executor getExecutor(){
        return taskExec;
    }

    public void setHeroController(HeroController hc){
        this.hc = hc;
    }

    public HeroController getHeroController(){
        return hc;
    }

    public boolean isSameExec(Executor e){
        return e == taskExec;
    }

    @Override
    public int hashCode(){
        return (int) combinedID;
    }

    @Override
    public boolean equals(Object obj){
        if (obj instanceof ConnectedUser){
            ConnectedUser u = (ConnectedUser) obj;
            return u.combinedID == combinedID;
        }
        return false;
    }

    /**
     * 几百毫秒调用一次. 调用时用户一定在线, 在WorldService的用户列表中
     *
     * @param ctime
     */
    public void updateHeroFightModuleStates(long ctime){
        if (hc != null){
            hc.updateHeroFightModuleStates(ctime);
        }
    }

    public boolean checkHeartBeatNeedKick(long ctime){
        if (clientTimeChecker.needKick(ctime)){
            return true;
        }
        return false;
    }

    public void setGmCommand(GMCommand command){
        this.command = command;
    }

    private boolean tryProcessGmCommand(HeroController hc, long ctime){
        GMCommand cmd = command;
        if (cmd != null){
            command = null;

            Hero hero = hc.getHero();

            switch (cmd.type){
                case 1:{
                    // 禁言
                    hero.setSpeechLimitEndTime(ctime + 3L
                            * DateTimeConstants.MILLIS_PER_HOUR);
                    break;
                }
                case 2:{
                    // 解除禁言
                    hero.setSpeechLimitEndTime(0);
                    break;
                }
                case 3:{
                    // 封号
                    user.setBanned(true, ctime
                            + DateTimeConstants.MILLIS_PER_WEEK, cmd.gmName
                            + ":GM游戏内封");
                    disconnect(BANNED);
                    break;
                }
            }

            hc.getServices()
                    .getLogService()
                    .getGMOperateProcessor()
                    .addLogEvent(hero.getOperatorId(), null,
                            hero.getServerId(), hero.getUin(),
                            hero.getUserId(), hero.getName(), cmd.type,
                            cmd.gmName);

            return true;
        }
        return false;
    }

    public void updatePerSecond(long ctime){
        if (hc != null){
            if (tryProcessGmCommand(hc, ctime)){
                return;
            }

            hc.updatePerSecond(ctime);
        }
    }

    public void updatePerDay(long ctime){
        if (hc != null){
            hc.updatePerDay(ctime);
        }
    }

    public void updatePerMinute(long ctime){
        if (hc != null){
            hc.updatePerMinute(ctime);

            if (!user.isLogProgress
                    && hc.getHeroFightModule().hasEnterSceneForTheFirstTime()){
                user.isLogProgress = true;

                Hero hero = hc.getHero();
                hc.getServices()
                        .getLogService()
                        .getLoadProgressProcessor()
                        .addLogEvent(hero.getOperatorId(), null,
                                hero.getServerId(), hero.getUin(),
                                user.getLoadProgress());
            }
        }
    }

    public void checkBug(long ctime){
        if (hc != null){
            hc.checkBug(ctime);
        }
    }
}
