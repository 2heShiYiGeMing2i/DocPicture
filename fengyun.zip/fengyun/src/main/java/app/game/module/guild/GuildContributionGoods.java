package app.game.module.guild;

import static com.mokylin.sink.util.Preconditions.*;
import app.game.data.goods.Goods;
import app.game.data.goods.GoodsData;
import app.game.data.goods.GoodsDatas;
import app.game.data.goods.GoodsRandomer;
import app.protobuf.ConfigContent.GuildContributionGoodsProto;

import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.parse.ObjectParser;

public class GuildContributionGoods{

    final int id;

    final int index;

    final GoodsRandomer goodsRandomer;

    final int goodsCount;

    final int requiredGuildContribution;

    final int guildLilianCost;

    final int limitPerDay;

    final transient int neededDepotEmptyPos;

    GuildContributionGoods(ObjectParser p, GoodsDatas goodsDatas, int index){
        this.index = index;
        this.id = p.getIntKey("id");
        this.requiredGuildContribution = p.getIntKey("contribution");
        this.guildLilianCost = p.getIntKey("lilian");
        this.limitPerDay = p.getIntKey("limit_per_day");

        String item = p.getKey("goods_item");
        this.goodsRandomer = GoodsRandomer.newRandomer(this, item, goodsDatas);
        checkNotNull(goodsRandomer);

        GoodsData goodsData = goodsRandomer.getData();
        this.goodsCount = goodsRandomer.getDefaultCount();
        checkArgument(goodsCount > 0 && goodsCount <= 9999,
                "帮派物品兑换, 数量必须是1-9999之间: id %s, 物品 %s-%s", id, goodsData.id,
                goodsData.name);

        checkArgument(requiredGuildContribution >= 0,
                "帮派物品兑换, 所需帮贡不能<0: id %s: %s", id, requiredGuildContribution);

        checkArgument(guildLilianCost > 0, "帮派物品兑换, 消耗的帮派历练必须>0: id %s: %s",
                id, guildLilianCost);

        checkArgument(limitPerDay >= 0,
                "帮派物品兑换, 每天的兑换限额不能<0. 0表示无限: id %s: %s", id, limitPerDay);

        this.neededDepotEmptyPos = Utils.divide(goodsCount,
                goodsData.getMaxCount());

        assert neededDepotEmptyPos > 0;
    }

    Goods newGoods(long ctime){
        return goodsRandomer.create(ctime);
    }

    public GuildContributionGoodsProto encode(){
        GuildContributionGoodsProto.Builder builder = GuildContributionGoodsProto
                .newBuilder();

        builder.setGoods(goodsRandomer.getGoodsWrapper().encode4Client());

        if (limitPerDay != 0){
            builder.setEveryDayLimit(limitPerDay);
        }

        if (requiredGuildContribution != 0){
            builder.setRequiredContribution(requiredGuildContribution);
        }

        if (guildLilianCost != 0){
            builder.setGuildLilianCost(guildLilianCost);
        }

        return builder.build();
    }

    @Override
    public String toString(){
        return "帮贡兑换-" + id;
    }
}
