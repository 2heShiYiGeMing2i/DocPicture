package app.game.module.guild;

import static com.mokylin.sink.util.Preconditions.checkArgument;

import java.util.List;

import app.game.data.GameObjects;
import app.game.data.SpriteStats;

import com.google.inject.Inject;
import com.mokylin.sink.util.parse.ObjectParser;

public class GuildFlagDatas{

    private static final String LOCATION = "config/data/guild/flag.txt";

    private final GuildFlagData[] datas;

    @Inject
    GuildFlagDatas(GameObjects go, SpriteStats spriteStats){
        List<ObjectParser> data = go.loadFile(LOCATION);

        checkArgument(data.size() > 0, "帮旗表必须至少配1级: %s", LOCATION);

        datas = new GuildFlagData[data.size()];

        for (int i = 0; i < data.size(); i++){
            GuildFlagData g = new GuildFlagData(data.get(i), spriteStats);
            checkArgument(g.level == i + 1,
                    "帮旗表中的等级没有按顺序, 必须是从1开始的连续的等级: %s. %s", g.level, LOCATION);
            datas[i] = g;

            if (i == 0){
                checkArgument(g.addCapacity == 0, "1级帮旗增加的人数, 必须是0");
            } else{
                checkArgument(g.addCapacity >= datas[i - 1].addCapacity,
                        "%s级帮旗必须比低级的帮旗增加的人数更多", g.level);
            }
        }
    }

    public GuildFlagData getLevel(int i){
        int index = i - 1;
        if (index >= 0 && index < datas.length){
            return datas[index];
        }
        return null;
    }

    public int getMaxLevel(){
        return datas.length;
    }
}
