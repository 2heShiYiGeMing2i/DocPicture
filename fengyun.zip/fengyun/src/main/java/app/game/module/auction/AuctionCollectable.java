package app.game.module.auction;

public class AuctionCollectable{

    public final long money;
    public final long yuanbao;
    public final long exp;

    public AuctionCollectable(long money, long yuanbao, long exp){
        super();
        this.money = money;
        this.yuanbao = yuanbao;
        this.exp = exp;
    }

    public boolean isEmpty(){
        return money == 0 && yuanbao == 0 && exp == 0;
    }

    @Override
    public int hashCode(){
        return (int) money;
    }

    @Override
    public boolean equals(Object obj){
        if (obj instanceof AuctionCollectable){
            AuctionCollectable c = (AuctionCollectable) obj;
            return c.money == money && c.yuanbao == yuanbao && c.exp == exp;
        }
        return false;
    }
}
