package app.game.module;

import org.jboss.netty.buffer.ChannelBuffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mokylin.sink.util.Empty;

/**
 * 处理每个场景中的旗子逻辑
 * @author Timmy
 *
 */
public abstract class AbstractFlagEventProcessor{
    private static final Logger logger = LoggerFactory
            .getLogger(AbstractFlagEventProcessor.class);

    private final byte[] prevWinGuildName;

    private final byte[][] prevWinFriendGuilds;

    /**
     * 当前扛着旗子的英雄id
     */
    private volatile long carryFlagHeroID;

    private volatile long startCarryFlagTime;

    // 根据这个获取盟号
    private int carryGuildSequence;

    private byte[] carryGuildName;

    private byte[][] carryFriendGuilds;

    private byte[] carryHeroName;

    /**
     * 战斗结束时间
     */
    public final long battleEndTime;

    /**
     * 是否在战斗中
     */
    private volatile boolean isInBattle;

    /**
     * 英雄刚进入场景时, 发送给他的信息
     */
    private volatile ChannelBuffer msgToSendOnHeroEnterScene;

    /**
     * 创建时, 已经结束了. 有了获胜的帮派了
     * 
     * 仅供启动服务器时, 战斗已经提前结束了用
     * @param winGuildName
     */
    protected AbstractFlagEventProcessor(long battleEndTime, int guildSequence,
            byte[] winGuildName, byte[][] friendGuilds, boolean isInBattle){
        prevWinGuildName = winGuildName;
        prevWinFriendGuilds = friendGuilds;

        this.battleEndTime = battleEndTime;
        this.carryGuildSequence = guildSequence;
        this.carryGuildName = winGuildName;
        this.carryHeroName = Empty.BYTE_ARRAY;
        this.carryFriendGuilds = friendGuilds;

        this.isInBattle = isInBattle;

        msgToSendOnHeroEnterScene = generateMsgToSendOnHeroEnter();
    }

    public boolean isDefencePart(byte[] name){
        return isDefencePart(name, carryGuildName, carryFriendGuilds);
    }

    public boolean isDefencePart(byte[] name, byte[] carryGuildName,
            byte[][] carryFriendGuilds){
        if (name == carryGuildName){
            return true;
        }

        if (carryFriendGuilds != null){
            for (byte[] friendGuild : carryFriendGuilds){
                if (name == friendGuild){
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * 尝试扛旗, 必须英雄线程调用
     * @param heroID
     * @param ctime
     * @return
     */
    public CarryFlagResult tryCarryFlagByHeroThread(long heroID,
            int guildSequence, byte[] guildName, byte[][] friendGuilds,
            long ctime, byte[] heroName){
        assert guildName != null;
        assert heroID != 0;
        assert heroName != null;

        synchronized (this){
            if (!isInBattle){
                return CarryFlagResult.NOT_IN_BATTLE;
            }

            if (carryFlagHeroID != 0){
                if (carryFlagHeroID == heroID){
                    return CarryFlagResult.ALREADY_GOT_FLAG;
                }

                return CarryFlagResult.OTHER_CARRING;
            }

            carryFlagHeroID = heroID;
            carryHeroName = heroName;
            carryGuildSequence = guildSequence;
            carryGuildName = guildName;
            carryFriendGuilds = friendGuilds;
            startCarryFlagTime = ctime;
            msgToSendOnHeroEnterScene = generateMsgToSendOnHeroEnter();
            return CarryFlagResult.SUCCESS;
        }
    }

    /**
     * 英雄死亡/离开场景时, 如果当前扛着旗, 则把旗子丢掉
     * 
     * 如果之前确实是他扛着旗, 返回true. 不然, 返回false
     * @param heroID
     */
    public boolean dropFlagIfCarry(long heroID){
        if (carryFlagHeroID != heroID){
            // 有可能有问题. 刚拔旗, 就死掉, 可能先调用了这个drop, 再拔旗成功
            return false;
        }

        synchronized (this){
            if (!isInBattle){
                return false;
            }
            if (carryFlagHeroID == heroID){
                carryGuildSequence = 0;
                carryGuildName = prevWinGuildName;
                carryHeroName = Empty.BYTE_ARRAY;
                carryFriendGuilds = prevWinFriendGuilds;
                carryFlagHeroID = 0;
                startCarryFlagTime = 0;
                msgToSendOnHeroEnterScene = generateMsgToSendOnHeroEnter();
                return true;
            } else{
                return false;
            }
        }
    }

    /**
     * 尝试提前结束战斗, 看下有没有人扛旗超过这个时间
     * 
     * 返回大于0, 表示成功提前结束. 返回的是扛旗的人的id
     * @param ctime
     * @param duration
     * @return
     */
    public byte[] tryStopBattleIfCarryMoreThanTime(long ctime, long duration){
        if (carryFlagHeroID == 0){
            return null;
        }

        final long target = ctime - duration; // 如果是在这个时间前抗旗的, 则提前结束
        if (startCarryFlagTime > target){
            return null;
        }

        synchronized (this){
            if (!isInBattle){
                return null;
            }
            if (startCarryFlagTime > target){
                return null;
            }

            byte[] result = carryGuildName;
            if (result == null || result.length == 0){
                return null; // 当前没有人扛着
            }

            carryHeroName = Empty.BYTE_ARRAY;
            carryFriendGuilds = Empty.BYTES_ARRAY;
            carryFlagHeroID = 0;
            startCarryFlagTime = 0;
            isInBattle = false; // 提前结束了

            msgToSendOnHeroEnterScene = generateMsgToSendOnHeroEnter();
            return result;
        }
    }

    /**
     * 时间到, 结束战斗. 返回当前扛着旗子的帮派
     * @return
     */
    public byte[] stopBattle(){
        synchronized (this){
            if (!isInBattle){
                logger.error("AbstractFlagEventProcessor.stopBattle时, isInBattle = false");
                return null;
            }

            byte[] result = carryGuildName;

            carryHeroName = Empty.BYTE_ARRAY;
            carryGuildSequence = 0;
            carryGuildName = Empty.BYTE_ARRAY;
            carryFriendGuilds = Empty.BYTES_ARRAY;
            carryFlagHeroID = 0;
            startCarryFlagTime = 0;
            isInBattle = false; // 提前结束了

            // 接下来这个会被设成null, 不需要generate msg了
            return result;
        }
    }

    /**
     * 生成玩家进入场景时, 会收到的当前战斗状态的消息
     * 
     * 会在加锁时调用. 方法中获得到的各种值都是线程安全的
     * @return
     */
    protected abstract ChannelBuffer generateMsgToSendOnHeroEnter();

    public ChannelBuffer getMsgToSendOnHeroEnter(){
        return msgToSendOnHeroEnterScene;
    }

    public long getCarryFlagHeroID(){
        return carryFlagHeroID;
    }

    protected long getStartCarryFlagTime(){
        return startCarryFlagTime;
    }

    protected byte[] getCarryHeroName(){
        return carryHeroName;
    }

    protected int getCarryGuildSequence(){
        return carryGuildSequence;
    }

    public byte[] getCarryGuildName(){
        return carryGuildName;
    }

    public byte[][] getCarryFriendGuilds(){
        return carryFriendGuilds;
    }

    public boolean isInBattle(){
        return isInBattle;
    }

    public long getBattleEndTime(){
        return battleEndTime;
    }

    public enum CarryFlagResult{
        NOT_IN_BATTLE, OTHER_CARRING, ALREADY_GOT_FLAG, SUCCESS;
    }
}
