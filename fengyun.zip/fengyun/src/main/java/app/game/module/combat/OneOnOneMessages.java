package app.game.module.combat;

import static com.mokylin.sink.util.BufferUtil.*;

import java.util.List;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.module.Modules;
import app.protobuf.HeroContent.ChallengeResultProto;
import app.protobuf.PrizeContent.PrizeProto;
import app.utils.VariableConfig;

/**
 * @author Liwei
 *
 */
public class OneOnOneMessages{

    public static final int MODULE_ID = Modules.ONE_VS_ONE_MODULE_ID;

    /**
     * 获取自己的个人竞技场数据（第一次打开请求一次，之后不能再请求）
     * 
     * 必须开启个人竞技场功能后才能请求，否则不返回消息
     */
    static final int C2S_GET_SELF_CHALLENGE = 0;

    /**
     * 获取自己的个人竞技场数据
     * varint32 可挑战次数
     * varint64 冷却时间 cooldown
     * varint32 鼓舞战力次数
     * varint32 鼓舞附加战斗力
     * varint32 前一天奖励结果，result
     * 
     * // 冷却时间比当前时间大的话，需要判断是否疲劳
     * if(cooldown > ctime)
     *     boolean hasFatigue = cooldown % 2 == 1; // true表示已疲劳（需要将冷却时间全部用完才能继续挑战）
     * 
     * hasCollectPrize = result & 1 == 1; // true表示已经领取过奖励了
     * rank = result >>> 1; // 排名，0表示未上榜
     */
    static final int S2C_GET_SELF_CHALLENGE = 1;

    /**
     * 获取个人竞技场的挑战列表，此数据缓存10秒，10秒之内打开面板不要重复请求
     * 
     * 必须开启个人竞技场功能后才能请求，否则不返回消息
     */
    static final int C2S_GET_CHALLENGE_LIST = 2;

    /**
     * 个人竞技场列表
     * varint32 英雄自己的名次，0表示未上榜
     * while(byteArray.available)
     *     varint32 名次
     *     varint64 英雄id
     *     UTF 英雄名称
     *     varint32 职业 1-步惊云 2-聂风 3-楚楚 4-第二梦
     *     varint32 level
     *     varint32 战斗力
     *     varint32 换装
     * 
     * 客户端收到这个消息后，将英雄插入到英雄列表中
     * 
     * 假设消息中只有一个第5名的英雄，如果自己的名次是第4名，则英雄自己排在这个英雄之前
     */
    static final int S2C_GET_CHALLENGE_LIST = 3;

    /**
     * 第一条挑战日志
     * 
     * // 可以读到数据，说明有日志，否则说明当前没有日志信息
     * if (byteArray.available)
     *     varint64 日志时间
     *     varint32 result
     *     UTF 对方名字
     *     
     * boolean isPassive = result & 1 == 1; // true为被动，false为主动
     * boolean isWin = (result >>> 1) & 1 == 1; // true表示赢了，false表示输了
     * boolean isChangePos = (result >>> 2) & 1 == 1; // true表示排名变化了，false表示排名未变化
     * int pos = rasult >>> 3; // 名次，0表示未上榜
     */
    static final int S2C_FIRST_SINGLE_FIGHT_LOG = 4;

    static final ChannelBuffer EMPTY_FIRST_FIGHT_LOG = onlySendHeaderMessage(
            MODULE_ID, S2C_FIRST_SINGLE_FIGHT_LOG);

    /**
     * 获取挑战日志，只请求一次
     * 
     * 必须开启个人竞技场功能后才能请求，否则不返回消息
     */
    static final int C2S_GET_CHALLENGE_LOG = 5;

    /**
     * 获取挑战日志
     * while(byteArray.available)
     *     varint64 日志时间
     *     varint32 result
     *     UTF 对方名字
     *     
     * boolean isPassive = result & 1 == 1; // true为被动，false为主动
     * boolean isWin = (result >>> 1) & 1 == 1; // true表示赢了，false表示输了
     * boolean isChangePos = (result >>> 2) & 1 == 1; // true表示排名变化了，false表示排名未变化
     * int pos = rasult >>> 3; // 名次，0表示未上榜
     */
    static final int S2C_GET_CHALLENGE_LOG = 6;

    /**
     * 添加一条挑战日志
     * varint64 日志时间
     * varint32 result
     * UTF 对方名字
     * 
     * boolean isPassive = result & 1 == 1; // true为被动，false为主动
     * boolean isWin = (result >>> 1) & 1 == 1; // true表示赢了，false表示输了
     * boolean isChangePos = (result >>> 2) & 1 == 1; // true表示排名变化了，false表示排名未变化
     * int pos = rasult >>> 3; // 名次，0表示未上榜
     * 
     * 客户端将新的日志更新到最新一条日志，将日志列表中最后一条删除（如果列表已满，没满不用删）
     * 
     * 收到这个消息，如果名次有变化，则下次打开面板时重新请求挑战列表（如果当前正在开着面板，立即请求一次）
     */
    static final int S2C_ADD_CHALLENGE_LOG = 7;

    /**
     * 增加挑战次数
     */
    static final int C2S_ADD_CHALLENGE_TIMES = 8;

    /**
     * 增加挑战次数
     * varint32 新的可挑战次数
     */
    static final int S2C_ADD_CHALLENGE_TIMES = 9;

    private static final ChannelBuffer[] ADD_CHALLENGE_TIMES_MSG;
    static{
        ADD_CHALLENGE_TIMES_MSG = new ChannelBuffer[VariableConfig.ONE_ON_ONE_CHALLENGE_MAX_TIMES];
        for (int i = 0; i < VariableConfig.ONE_ON_ONE_CHALLENGE_MAX_TIMES; i++){
            ADD_CHALLENGE_TIMES_MSG[i] = onlySendHeadAndAVarInt32Message(
                    MODULE_ID, S2C_ADD_CHALLENGE_TIMES, i + 1);
        }
    }

    /**
     * 增加挑战次数失败，附带byte错误码
     * 1、功能还未开放
     * 2、次数已满
     * 3、元宝不足
     */
    static final int S2C_ADD_CHALLENGE_TIMES_FAIL = 10;

    static final ChannelBuffer ERR_ADD_TIMES_FAIL_NOT_OPEN = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_ADD_CHALLENGE_TIMES_FAIL, 1);

    static final ChannelBuffer ERR_ADD_TIMES_FAIL_FULL_TIMES = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_ADD_CHALLENGE_TIMES_FAIL, 2);

    static final ChannelBuffer ERR_ADD_TIMES_FAIL_YUANBAO_NOT_ENOUGH = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_ADD_CHALLENGE_TIMES_FAIL, 3);

    /**
     * 重置冷却时间
     */
    static final int C2S_RESET_COOL_DOWN = 11;

    /**
     * 重置冷却时间成功，客户端收到后，将冷却时间重置
     */
    static final int S2C_RESET_COOL_DOWN = 12;

    static final ChannelBuffer RESET_COOL_DOWN_MSG = onlySendHeaderMessage(
            MODULE_ID, S2C_RESET_COOL_DOWN);

    /**
     * 重置冷却时间失败，附带byte错误码
     * 1、功能还未开放
     * 2、当前没有冷却时间
     * 3、元宝不足
     */
    static final int S2C_RESET_COOL_DOWN_FAIL = 13;

    static final ChannelBuffer ERR_RESET_COOL_DOWN_FAIL_NOT_OPEN = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_RESET_COOL_DOWN_FAIL, 1);

    static final ChannelBuffer ERR_RESET_COOL_DOWN_FAIL_NOT_COOL_DOWN = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_RESET_COOL_DOWN_FAIL, 2);

    static final ChannelBuffer ERR_RESET_COOL_DOWN_FAIL_YUANBAO_NOT_ENOUGH = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_RESET_COOL_DOWN_FAIL, 3);

    /**
     * 鼓舞战力
     */
    static final int C2S_ADD_CHALLENGE_REFINED_TIMES = 14;

    /**
     * 鼓舞战力
     * boolean success = byteArray.available;
     * if (success) // 鼓舞成功才读取下面的值
     *     varint32 鼓舞成功次数
     *     varint32 鼓舞附加战斗力
     */
    static final int S2C_ADD_CHALLENGE_REFINED_TIMES = 15;

    static final ChannelBuffer REFINED_FAIL_MSG = onlySendHeaderMessage(
            MODULE_ID, S2C_ADD_CHALLENGE_REFINED_TIMES);

    /**
     * 鼓舞战力失败，附带byte错误码
     * 1、功能还未开放
     * 2、战力鼓舞已满
     * 3、元宝不足或者礼金不足
     */
    static final int S2C_ADD_CHALLENGE_REFINED_TIMES_FAIL = 16;

    static final ChannelBuffer ERR_ADD_CHALLENGE_REFINED_TIMES_FAIL_NOT_OPEN = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_ADD_CHALLENGE_REFINED_TIMES_FAIL, 1);

    static final ChannelBuffer ERR_ADD_CHALLENGE_REFINED_TIMES_FAIL_FULL_TIMES = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_ADD_CHALLENGE_REFINED_TIMES_FAIL, 2);

    static final ChannelBuffer ERR_ADD_CHALLENGE_REFINED_TIMES_FAIL_MONEY_NOT_ENOUGH = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_ADD_CHALLENGE_REFINED_TIMES_FAIL, 3);

    /**
     * 挑战英雄
     * varint32 挑战名次
     */
    static final int C2S_DO_CHALLENGE = 21;

    /**
     * 挑战成功，并不是胜利（只是开始打而已）
     * varint32 挑战剩余次数
     * varint64 冷却时间
     * 
     * // 需要判断是否疲劳
     * boolean hasFatigue = cooldown % 2 == 1; // true表示已疲劳（需要将冷却时间全部用完才能继续挑战）
     */
    static final int S2C_DO_CHALLENGE = 22;

    /**
     * 挑战英雄失败，附带byte错误码
     * 1、英雄还未开放
     * 2、挑战次数已用完
     * 3、cd中
     * 4、不能挑战小于第7名的玩家（前7名，不包含第7名）
     * 5、不能挑战比自己位置低的玩家（小于等于7名）
     * 6、挑战的英雄是自己
     * 7、挑战的位置无效
     * 8、前一次挑战还未处理完
     * 9、英雄不在普通场景中
     * 
     */
    static final int S2C_DO_CHALLENGE_FAIL = 23;

    static final ChannelBuffer ERR_CHALLENGE_FAIL_NOT_OPEN = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_DO_CHALLENGE_FAIL, 1);

    static final ChannelBuffer ERR_CHALLENGE_FAIL_NOT_CHALLENGE_TIMES = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_DO_CHALLENGE_FAIL, 2);

    static final ChannelBuffer ERR_CHALLENGE_FAIL_COOLDOWN = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_DO_CHALLENGE_FAIL, 3);

    static final ChannelBuffer ERR_CHALLENGE_FAIL_LESS_TOP7 = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_DO_CHALLENGE_FAIL, 4);

    static final ChannelBuffer ERR_CHALLENGE_FAIL_LESS_SELF = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_DO_CHALLENGE_FAIL, 5);

    static final ChannelBuffer ERR_CHALLENGE_FAIL_CHALLENGE_SELF = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_DO_CHALLENGE_FAIL, 6);

    static final ChannelBuffer ERR_CHALLENGE_FAIL_INVALID_POS = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_DO_CHALLENGE_FAIL, 7);

    static final ChannelBuffer ERR_CHALLENGE_FAIL_CHALLENGING = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_DO_CHALLENGE_FAIL, 8);

    static final ChannelBuffer ERR_CHALLENGE_FAIL_NOT_IN_NORMAL_SCENE = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_DO_CHALLENGE_FAIL, 9);

    /**
     * 根据这个消息播放挑战动画
     * bytes ChallengeResultProto
     * 
     * 挑战胜利（名次有改变），则清掉缓存，重新请求一次数据
     * 
     * 目标英雄id如果跟客户端的id不一致时(无论是否胜利)，主动清掉个人竞技场缓存数据，重新请求一次
     * 
     * result解析，下面的搞成一个方法，后面也会用到
     * boolean isPassive = result & 1 == 1; // true为被动，false为主动
     * boolean isWin = (result >>> 1) & 1 == 1; // true表示赢了，false表示输了
     * boolean isChangePos = (result >>> 2) & 1 == 1; // true表示排名变化了，false表示排名未变化
     * int pos = rasult >>> 3; // 名次，0表示未上榜
     * 
     * 除了模拟打斗之外，还需要添加一条竞技场日志
     */
    static final int S2C_PLAY_CHALLENGE_MOVIE = 24;

    /**
     * 领取每日排名奖励
     */
    static final int C2S_COLLECT_DAILY_PRIZE = 25;

    /**
     * 领取奖励成功
     * 
     * 奖励内容由其他消息添加（加经验消息，加钱消息等等）
     */
    static final int S2C_COLLECT_DAILY_PRIZE = 26;

    static final ChannelBuffer COLLECT_DAILY_PRIZE_MSG = onlySendHeaderMessage(
            MODULE_ID, S2C_COLLECT_DAILY_PRIZE);

    /**
     * 领取每日排名奖励失败，附带byte错误码
     * 1、英雄还未开放
     * 2、今日已经领取过了
     */
    static final int S2C_COLLECT_DAILY_PRIZE_FAIL = 27;

    static final ChannelBuffer ERR_COLLECT_DAILY_PRIZE_FAIL_NOT_OPEN = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_COLLECT_DAILY_PRIZE_FAIL, 1);

    static final ChannelBuffer ERR_COLLECT_DAILY_PRIZE_FAIL_COLLECTED = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_COLLECT_DAILY_PRIZE_FAIL, 2);

    /**
     * 请求预览列表
     * varint32 startPos，这个阶段的启始位置，最后一段不能请求，就是500+那段不能请求
     * 
     * 这个数据缓存10秒，10秒内重复打开，用缓存的数据
     * 
     * 这个消息必须等到服务器返回后才可以再次请求
     */
    static final int C2S_GET_PREVIEW_LIST = 28;

    /**
     * 请求预览列表
     * while(byteArray.available) // 如果没有读到数据，说明这个段里面没有英雄
     *     varint64 英雄id
     *     UTF 英雄名字
     *     varint32 英雄等级
     *     varint32 英雄战力
     * 
     * 启始名次客户端自己存储，服务器不发送（所以说要等到服务器返回才能再次请求）
     */
    static final int S2C_GET_PREVIEW_LIST = 29;

    static final ChannelBuffer EMPTY_PREVIEW_LIST_MSG = onlySendHeaderMessage(
            MODULE_ID, S2C_GET_PREVIEW_LIST);

    /**
     * 请求预览列表失败，附带byte错误码
     * 1、英雄还未开放
     * 2、启始位置无效
     * 3、内部错误
     */
    static final int S2C_GET_PREVIEW_LIST_FAIL = 30;

    static final ChannelBuffer ERR_GET_PREVIEW_LIST_FAIL_NOT_OPEN = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_GET_PREVIEW_LIST_FAIL, 1);

    static final ChannelBuffer ERR_GET_PREVIEW_LIST_FAIL_INVALID_START_POS = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_GET_PREVIEW_LIST_FAIL, 2);

    static final ChannelBuffer ERR_GET_PREVIEW_LIST_FAIL_INTERNAL_ERROR = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_GET_PREVIEW_LIST_FAIL, 3);

    /**
     * 挑战内部错误
     * 
     * 收到这个消息后，英雄发送消息进入场景，
     */
    static final int S2C_DO_CHALLENGE_INTERNAL_ERROR = 31;

    static final ChannelBuffer CHALLENGE_INTERNAL_ERROR_MSG = onlySendHeaderMessage(
            MODULE_ID, S2C_DO_CHALLENGE_INTERNAL_ERROR);

    /**
     * 请求整点累计奖励
     * 
     * 第一次打开面板时请求一次，每个整点客户端清空缓存，再次打开面板的时候重新请求一次
     * 
     * 这里的每个整点必须要服务器时间计算得到的（延迟5秒，比如1点0分05秒清掉缓存）
     */
    static final int C2S_GET_HOURLY_ACC_PRIZE = 32;

    /**
     * 请求整点累计奖励
     * if (byteArray.available)
     *     bytes PrizeProto 整点奖励数据
     */
    static final int S2C_GET_HOURLY_ACC_PRIZE = 33;

    static final ChannelBuffer EMPTY_HOURLY_ACC_PRIZE_MSG = onlySendHeaderMessage(
            MODULE_ID, S2C_GET_HOURLY_ACC_PRIZE);

    static ChannelBuffer getHourlyAccPrizeMsg(PrizeProto proto){
        return newProtobufMessage(MODULE_ID, S2C_GET_HOURLY_ACC_PRIZE, proto);
    }

    /**
     * 第一名变化广播
     * varint64 heroID
     * bytes 名字
     */
    static final int S2C_TOP_ONE_CHANGED = 34;

    /**
     * 个人竞技场每日排名变化
     * varint32 第几名
     */
    static final int S2C_RESET_DAILY_POS = 35;

    static final ChannelBuffer EMPTY_RANK_MSG = getResetDailyPosMsg(0);

    static ChannelBuffer getResetDailyPosMsg(int pos){
        return onlySendHeadAndAVarInt32Message(MODULE_ID, S2C_RESET_DAILY_POS,
                pos);
    }

    static ChannelBuffer getTopOneChanged(long heroId, byte[] name){
        return onlySendHeadAndAVarInt64WithBytesMessage(MODULE_ID,
                S2C_TOP_ONE_CHANGED, heroId, name);
    }

    // ------- end of msg ---------

    static ChannelBuffer getSelfChanllenge(int challengeTimes, long cooldown,
            int refinedTimes, int refinedFightingAmount, int lastRankPos,
            boolean hasCollected){

        int result = (lastRankPos << 1) | (hasCollected ? 1 : 0);

        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID,
                S2C_GET_SELF_CHALLENGE, computeVarInt32Size(challengeTimes)
                        + computeVarInt64Size(cooldown)
                        + computeVarInt32Size(refinedTimes)
                        + computeVarInt32Size(refinedFightingAmount)
                        + computeVarInt32Size(result));

        writeVarInt32(buffer, challengeTimes);
        writeVarInt64(buffer, cooldown);
        writeVarInt32(buffer, refinedTimes);
        writeVarInt32(buffer, refinedFightingAmount);
        writeVarInt32(buffer, result);

        return buffer;
    }

    static ChannelBuffer getChallengeListBuffer(){
        return newDynamicMessage(MODULE_ID, S2C_GET_CHALLENGE_LIST);
    }

    static ChannelBuffer getDoChallengeMsg(int challengeTimes, long cooldown){
        return onlySendHeadAndAVarInt32WithAVarInt64Message(MODULE_ID,
                S2C_DO_CHALLENGE, challengeTimes, cooldown);
    }

    static ChannelBuffer playMovieMsg(ChallengeResultProto proto){
        return newProtobufMessage(MODULE_ID, S2C_PLAY_CHALLENGE_MOVIE, proto);
    }

    static ChannelBuffer addChallengeTimesMsg(int newTimes){
        assert newTimes > 0;

        if (newTimes > 0 && newTimes <= ADD_CHALLENGE_TIMES_MSG.length){
            return ADD_CHALLENGE_TIMES_MSG[newTimes - 1];
        }

        return onlySendHeadAndAVarInt32Message(MODULE_ID,
                S2C_ADD_CHALLENGE_TIMES, newTimes);
    }

    static ChannelBuffer addChallengeRefinedTimesMsg(int times,
            int refinedFightingAmount){
        return onlySendHeadAnd2VarInt32Message(MODULE_ID,
                S2C_ADD_CHALLENGE_REFINED_TIMES, times, refinedFightingAmount);
    }

    static ChannelBuffer getFightLogMsg(List<SingleChallengeLog> logList){
        ChannelBuffer buffer = newDynamicMessage(MODULE_ID,
                S2C_GET_CHALLENGE_LOG);
        for (SingleChallengeLog log : logList){
            log.writeTo(buffer);
        }

        return buffer;
    }

    static ChannelBuffer addFightLogMsg(SingleChallengeLog log){
        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID,
                S2C_ADD_CHALLENGE_LOG, log.getWriteLen());
        log.writeTo(buffer);
        return buffer;
    }

    static ChannelBuffer getFirstFightLogMsg(SingleChallengeLog log){
        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID,
                S2C_FIRST_SINGLE_FIGHT_LOG, log.getWriteLen());

        log.writeTo(buffer);
        return buffer;
    }

    static final ChannelBuffer getPreviewListBuffer(){
        return newDynamicMessage(MODULE_ID, S2C_GET_PREVIEW_LIST);
    }
}
