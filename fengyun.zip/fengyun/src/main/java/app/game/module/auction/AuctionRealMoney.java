package app.game.module.auction;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.module.GoodsContainerModule;
import app.game.module.HeroController;
import app.protobuf.GoodsServerContent.GoodsType;
import app.protobuf.LogContent.LogEnum.OperateType;

import com.mokylin.sink.util.BufferUtil;

class AuctionRealMoney extends AuctionRealItem{

    private static final int GOODS_TYPE = GoodsType.MONEY_GOODS.getNumber();

    private static final int GOODS_TYPE_VARINT32_LEN = BufferUtil
            .computeVarInt32Size(GOODS_TYPE);

    final int amount;

    AuctionRealMoney(int amount, int cost, long sellerID, byte[] sellerNameBytes){
        super(sellerID, sellerNameBytes, cost);

        this.amount = amount;
    }

    @Override
    int getItemId(){
        return GOODS_TYPE;
    }

    @Override
    String getItemName(){
        return GoodsType.MONEY_GOODS.name();
    }

    @Override
    int getItemCount(){
        return amount;
    }

    @Override
    boolean canHold(HeroController hc, boolean ifYuanbaoReduceTax){
        return hc.getHeroMiscModule().canAddMoney(amount);
    }

    @Override
    void doGive(HeroController hc, GoodsContainerModule goodsContainerModule,
            boolean ifYuanbaoReduceTax, OperateType type, String iEventId,
            long ctime){
        hc.getHeroMiscModule().addMoneyAnyway(amount, type, iEventId);
    }

    @Override
    public void writeGoods(ChannelBuffer buffer, boolean isYuanbaoReduceTax){
        BufferUtil.writeVarInt32(
                buffer,
                GOODS_TYPE_VARINT32_LEN
                        + BufferUtil.computeVarInt32Size(amount));
        BufferUtil.writeVarInt32(buffer, GOODS_TYPE);
        BufferUtil.writeVarInt32(buffer, amount);
    }

    @Override
    AuctionLog toAuctionLog(long buyerID, byte[] buyerName, long time,
            int collectableExp){
        return new AuctionLog(time, sellerHeroID, sellerNameBytes, buyerID,
                buyerName, cost, sellerCollectableMoney(),
                sellerCollectableYuanbao(), collectableExp, 98, null, null,
                amount);
    }

    @Override
    int sellerCollectableMoney(){
        return 0;
    }

    @Override
    int sellerCollectableYuanbao(){
        return cost - calculateTax(cost);
    }

    @Override
    int sellerCollectableConcurrency(){
        return sellerCollectableYuanbao();
    }

    @Override
    int sellerTax(){
        return calculateTax(cost);
    }

    @Override
    int buyerTax(){
        return 0;
    }
}
