package app.game.module.auction;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.module.GoodsContainerModule;
import app.game.module.HeroController;
import app.protobuf.LogContent.LogEnum.OperateType;
import app.utils.VariableConfig;

import com.mokylin.sink.util.Empty;

public abstract class AuctionRealItem{

    public static final AuctionRealItem NULL_ITEM = new AuctionRealItem(0,
            Empty.BYTE_ARRAY, 0){

        @Override
        int getItemId(){
            return 0;
        }

        @Override
        String getItemName(){
            return "";
        }

        @Override
        int getItemCount(){
            return 0;
        }

        @Override
        void writeGoods(ChannelBuffer buffer, boolean isYuanbaoReduceTax){
            throw new UnsupportedOperationException();
        }

        @Override
        AuctionLog toAuctionLog(long buyerID, byte[] buyerName, long time,
                int collectableExp){
            throw new UnsupportedOperationException();
        }

        @Override
        int sellerCollectableYuanbao(){
            throw new UnsupportedOperationException();
        }

        @Override
        int sellerCollectableMoney(){
            throw new UnsupportedOperationException();
        }

        @Override
        void doGive(HeroController hc,
                GoodsContainerModule goodsContainerModule,
                boolean ifYuanbaoReduceTax, OperateType type, String iEventId,
                long ctime){
            throw new UnsupportedOperationException();
        }

        @Override
        boolean canHold(HeroController hc, boolean ifYuanbaoReduceTax){
            throw new UnsupportedOperationException();
        }

        @Override
        int sellerCollectableConcurrency(){
            throw new UnsupportedOperationException();
        }

        @Override
        int sellerTax(){
            throw new UnsupportedOperationException();
        }

        @Override
        int buyerTax(){
            throw new UnsupportedOperationException();
        }
    };

    protected final long sellerHeroID;
    protected final byte[] sellerNameBytes;
    protected final int cost;

    protected AuctionRealItem(long sellerHeroID, byte[] sellerNameBytes,
            int cost){
        this.sellerHeroID = sellerHeroID;
        this.sellerNameBytes = sellerNameBytes;
        this.cost = cost;
    }

    abstract int getItemId();

    abstract String getItemName();

    abstract int getItemCount();

    /**
     * 是否放得下
     * @param hc
     * @return
     */
    abstract boolean canHold(HeroController hc, boolean ifYuanbaoReduceTax);

    /**
     * 实际给予这个人
     * @param hc
     * @param uuid TODO
     * @param type TODO
     */
    abstract void doGive(HeroController hc,
            GoodsContainerModule goodsContainerModule,
            boolean ifYuanbaoReduceTax, OperateType type, String iEventId,
            long ctime);

    abstract void writeGoods(ChannelBuffer buffer, boolean isYuanbaoReduceTax);

    abstract int sellerCollectableMoney();

    abstract int sellerCollectableYuanbao();

    abstract AuctionLog toAuctionLog(long buyerID, byte[] buyerName, long time,
            int collectableExp);

    abstract int sellerCollectableConcurrency();

    abstract int sellerTax();

    abstract int buyerTax();

    protected static int calculateTax(int yuanbao){
        assert yuanbao >= 2;

        return Math.max(1,
                (int) (yuanbao * VariableConfig.YUANBAO_EXCHANGE_TAX));
    }
}
