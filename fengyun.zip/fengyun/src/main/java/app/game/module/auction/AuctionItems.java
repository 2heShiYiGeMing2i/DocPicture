package app.game.module.auction;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.data.goods.GoodsData;
import app.game.data.goods.GoodsDatas;

public class AuctionItems{

    private static final Logger logger = LoggerFactory
            .getLogger(AuctionItems.class);

    private static final AuctionItem NULL_ITEM = new AuctionNullGoods();

    private AuctionItems(){
    }

    public static AuctionItem parseGoods(GoodsDatas goodsDatas, long id,
            int goodsID, byte[] clientProto, int totalCost, long sellerCombineId,
            byte[] sellerHeroName){
        GoodsData goodsData = goodsDatas.get(goodsID);
        if (goodsData == null){
            logger.error("AuctionItems.parseGoods时, goods id不存在: {}", goodsID);
            return NULL_ITEM;
        }

        return new AuctionGoods(goodsData, id, clientProto, totalCost,
                sellerCombineId, sellerHeroName);
    }

    public static AuctionItem parseMoney(long id, int count, int totalCost,
            long sellerCombineId, byte[] sellerHeroName){
        return new AuctionMoney(id, count, totalCost, sellerCombineId, sellerHeroName);
    }

    public static AuctionItem parseYuanbao(long id, int count, int totalCost,
            long sellerCombineId, byte[] sellerHeroName){
        return new AuctionYuanbao(id, count, totalCost, sellerCombineId,
                sellerHeroName);
    }
}
