package app.game.module.guild;

import static app.game.module.guild.GuildMessages.*;
import static app.protobuf.LogContent.LogEnum.OperateType.*;
import static com.mokylin.sink.util.Preconditions.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.jboss.netty.buffer.ChannelBuffer;
import org.joda.time.DateTimeConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.data.ServerData;
import app.game.data.goods.Goods;
import app.game.data.goods.GoodsData;
import app.game.data.goods.GoodsDatas;
import app.game.data.goods.GoodsTryReduceResult;
import app.game.data.scene.ChallengeDungeonSceneDatas;
import app.game.entity.Hero;
import app.game.module.GoodsContainerModule;
import app.game.module.HeroController;
import app.game.module.HeroID;
import app.game.module.TerritoryMasterInfo;
import app.game.module.ViewOtherHeroCache;
import app.game.module.scene.OneThreadJob;
import app.game.service.DBService;
import app.game.service.IThreadService;
import app.game.service.TimeService;
import app.game.service.WorldService;
import app.game.service.log.LogService;
import app.i18n.I18NConfigs;
import app.message.IDroppableSender;
import app.message.ISender;
import app.protobuf.GuildContent.ClientGuildListProto;
import app.protobuf.GuildContent.ClientNewsProto;
import app.protobuf.GuildContent.GuildProto;
import app.protobuf.GuildServerContent.AllGuildProto;
import app.utils.IDUtils;
import app.utils.IndividualServerConfig;
import app.utils.VariableConfig;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.google.inject.Inject;
import com.google.protobuf.ByteString;
import com.mokylin.collection.ByteArrayBuilder;
import com.mokylin.collection.ByteArrayConcurrentHashMap;
import com.mokylin.collection.LongConcurrentHashMap;
import com.mokylin.collection.ReusableIterator;
import com.mokylin.sink.util.BufferUtil;
import com.mokylin.sink.util.Empty;
import com.mokylin.sink.util.StringEncoder;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.concurrent.PaddedAtomicBoolean;
import com.mokylin.sink.util.holder.BooleanHolder;
import com.mokylin.sink.util.holder.LongCountHolder;

public class GuildModule{
    /*
     * 加入帮派时, 先加锁, cas英雄自己的帮派, 再将英雄添加到帮派中, 加入到总入帮成员列表中, 解锁
     *
     * 退出帮派时, 先从帮派中移除, 在cas英雄的帮派. happen-before他再加入别的帮派,或者重新加回同一个帮派
     *
     * 所有要将已在帮派中的人, 要离开帮派时, 都需要加锁. 防止别的地方将此人设为了某职位. 设职位时, 也需要加锁, 并检查此人是否还在帮派中
     *
     * 解散帮派时, 先加锁,从所有帮派中移除, 不要出现在帮派列表中. 改变maxHeroCount, 让此后加入的都显示人满.
     */
    private static final Logger logger = LoggerFactory
            .getLogger(GuildModule.class);

//    private final byte[] QU_NAME;

    private final LongConcurrentHashMap<GuildMember> guildMembers;

    private final ByteArrayConcurrentHashMap<Guild> guilds;

    private final ByteArrayConcurrentHashMap<Object> flagNames;

    private final WorldService worldService;

    private final DBService dbService;

    private final IThreadService threadService;

    private final TimeService timeService;

    private final VariableConfig variableConfig;

    private final LoadingCache<Guild, ChannelBuffer> guildInfoMsgCache;

    private final LoadingCache<Guild, ChannelBuffer> guildNewsMsgCache;

    private final GoodsContainerModule goodsContainerModule;

    private final GuildFlagDatas flagDatas;

    private final GuildRelationManager guildRelationManager;

    private final GuildContributionGoodsShop contributionGoodsShop;

    private final ViewOtherHeroCache viewOtherHeroCache;

    private final IndividualServerConfig individualServerConfig;

    private final TerritoryMasterInfo territoryMasterInfo;

    private final int challengeDungeonCount;

    private final LogService logService;

    private final GoodsData giftGoodsData1;
    private final GoodsData giftGoodsData2;
    private final GoodsData giftGoodsData3;
    private final GoodsData giftGoodsData4;

    /**
     * 当前是否在板块战期间
     *
     * 阻止进出帮, 设定职位, 解散帮派
     */
    private final PaddedAtomicBoolean territoryStarted;

    private final PaddedAtomicBoolean[] wsCityBattleStarteds;

    private final PaddedAtomicBoolean longCityBattleStarted;

    private final Guild[] GUILD_LIST_KEY;

    @Inject
    GuildModule(WorldService worldService, DBService dbService,
            IThreadService threadService, I18NConfigs language,
            TimeService timeService, GoodsDatas goodsDatas,
            GoodsContainerModule goodsContainerModule,
            GuildFlagDatas flagDatas,
            GuildContributionGoodsShop contributionGoodsShop,
            ViewOtherHeroCache viewOtherHeroCache,
            VariableConfig variableConfig,
            ChallengeDungeonSceneDatas challengeDungeonSceneDatas,
            LogService logService, TerritoryMasterInfo territoryMasterInfo,
            IndividualServerConfig indivualServerConfig) throws Throwable{
//        this.QU_NAME = language.getI18N().getMessage(MESSAGE_ENUM.QU);

        this.individualServerConfig = indivualServerConfig;
        this.worldService = worldService;
        this.dbService = dbService;
        this.threadService = threadService;
        this.timeService = timeService;
        this.goodsContainerModule = goodsContainerModule;
        this.flagDatas = flagDatas;
        this.contributionGoodsShop = contributionGoodsShop;
        this.viewOtherHeroCache = viewOtherHeroCache;
        this.variableConfig = variableConfig;
        this.challengeDungeonCount = challengeDungeonSceneDatas.size();
        this.logService = logService;
        this.territoryMasterInfo = territoryMasterInfo;

        this.territoryStarted = new PaddedAtomicBoolean(false);
        this.wsCityBattleStarteds = new PaddedAtomicBoolean[indivualServerConfig
                .getServerCount()];
        this.longCityBattleStarted = new PaddedAtomicBoolean(false);

        this.GUILD_LIST_KEY = new Guild[indivualServerConfig.getServerCount()];
        for (ServerData data : indivualServerConfig.getServerDatas()){
            wsCityBattleStarteds[data.sequence] = new PaddedAtomicBoolean(false);

            GUILD_LIST_KEY[data.sequence] = new Guild(data, 0, -1,
                    Empty.BYTE_ARRAY, Empty.BYTE_ARRAY, 0, null, 0, null, null,
                    0);
        }

        giftGoodsData1 = checkNotNull(
                goodsDatas.get(variableConfig.GUILD_GIFT_GOODS_ID_1),
                "没有找到捐献帮贡的物品1: %s", variableConfig.GUILD_GIFT_GOODS_ID_1);
        giftGoodsData2 = checkNotNull(
                goodsDatas.get(variableConfig.GUILD_GIFT_GOODS_ID_2),
                "没有找到捐献帮贡的物品2: %s", variableConfig.GUILD_GIFT_GOODS_ID_2);
        giftGoodsData3 = checkNotNull(
                goodsDatas.get(variableConfig.GUILD_GIFT_GOODS_ID_3),
                "没有找到捐献帮贡的物品3: %s", variableConfig.GUILD_GIFT_GOODS_ID_3);
        giftGoodsData4 = checkNotNull(
                goodsDatas.get(variableConfig.GUILD_GIFT_GOODS_ID_4),
                "没有找到捐献帮贡的物品4: %s", variableConfig.GUILD_GIFT_GOODS_ID_4);

        // 帮贡物品id不能重复
        checkArgument(
                !Utils.hasDuplicate(new int[]{
                        variableConfig.GUILD_GIFT_GOODS_ID_1,
                        variableConfig.GUILD_GIFT_GOODS_ID_2,
                        variableConfig.GUILD_GIFT_GOODS_ID_3,
                        variableConfig.GUILD_GIFT_GOODS_ID_4}), "4个帮贡物品的id重复");

        this.guildMembers = new LongConcurrentHashMap<>(4096);

        this.flagNames = new ByteArrayConcurrentHashMap<>(64);
        this.guilds = new ByteArrayConcurrentHashMap<>(64);

        this.guildRelationManager = new GuildRelationManager(this.guilds,
                threadService, worldService, timeService, territoryStarted,
                wsCityBattleStarteds, longCityBattleStarted);

        loadDataFromDB();

        this.guildInfoMsgCache = CacheBuilder.newBuilder().concurrencyLevel(8)
                .expireAfterWrite(8, TimeUnit.SECONDS)
                .build(new GuildInfoMsgLoader(guilds.values()));

        this.guildNewsMsgCache = CacheBuilder.newBuilder().concurrencyLevel(8)
                .expireAfterWrite(8, TimeUnit.SECONDS)
                .build(new GuildNewsMsgLoader());

        // 定时保存帮派数据
        threadService.getScheduledExecutorService().scheduleAtFixedRate(
                new Runnable(){
                    @Override
                    public void run(){
                        try{
                            if (saveJob.tryCAS()){
                                GuildModule.this.threadService.getDbExecutor()
                                        .execute(saveJob);
                            }
                        } catch (Throwable ex){
                            logger.error("GuildModule.定时保存任务出错", ex);
                        }
                    }
                }, 90, 120, TimeUnit.SECONDS); // 2分钟一次, 90秒第一次

        // 每天0点设置活跃度及自动解散废帮派
        threadService.getScheduledExecutorService().scheduleAtFixedRate(
                new Runnable(){
                    @Override
                    public void run(){
                        try{
                            updatePerDay();
                        } catch (Throwable ex){
                            logger.error("GuildModule.定时设置活跃度出错", ex);
                        }
                    }
                },
                Utils.calculateMillisToMidnight(timeService.getCurrentTime()),
                DateTimeConstants.MILLIS_PER_DAY, TimeUnit.MILLISECONDS);
    }

    public void setTerritoryStarted(boolean started){
        this.territoryStarted.set(started);
    }

    public void setWsCityBattleStarted(boolean started){
        for (PaddedAtomicBoolean b : wsCityBattleStarteds){
            b.set(started);
        }
    }

    public void setWsCityBattleStarted(ServerData serverData, boolean started){
        this.wsCityBattleStarteds[serverData.sequence].set(started);
    }

    public void setLongCityBattleStarted(boolean started){
        this.longCityBattleStarted.set(started);
    }

    public boolean isInBattle(ServerData serverData){
        return territoryStarted.get() || longCityBattleStarted.get()
                || wsCityBattleStarteds[serverData.sequence].get();
    }

    public Guild getGuildByName(byte[] name){
        return guilds.get(name);
    }

    ReusableIterator<Guild> newGuildReusableIterator(){
        return guilds.reusableValueIterator();
    }

    // --------- 处理消息 ----------
    public void onMessage(int sequenceID, ChannelBuffer buffer,
            HeroController hc){
        switch (sequenceID){
            case C2S_CREATE_GUILD:{
                onCreateGuild(buffer, hc);
                return;
            }

            case C2S_GET_GUILD_LIST:{
                onGetGuildList(buffer, hc);
                return;
            }

            case C2S_GET_SELF_GUILD_INFO:{
                onGetSelfGuildInfo(buffer, hc);
                return;
            }

            case C2S_REQUEST_JOIN:{
                onRequestJoin(buffer, hc);
                return;
            }

            case C2S_REPLY_JOIN_REQUEST:{
                onReplyJoinRequest(buffer, hc);
                return;
            }

            case C2S_INVITE_JOIN:{
                onInviteJoin(buffer, hc);
                return;
            }

            case C2S_REPLY_JOIN_INVITE:{
                onReplyJoinInvite(buffer, hc);
                return;
            }

            case C2S_REJECT_ALL_JOIN_INVITE:{
                onRejectAllJoinInvite(buffer, hc);
                return;
            }

            case C2S_LEAVE_GUILD:{
                onLeaveGuild(buffer, hc);
                return;
            }

            case C2S_KICK_MEMBER:{
                onKickMember(buffer, hc);
                return;
            }

            case C2S_SET_POSITION:{
                onSetPosition(buffer, hc);
                return;
            }

            case C2S_SET_AUTO_ACCEPT_INVITE_TO_FALSE:{
                onSetAutoAcceptInvite(hc, false);
                return;
            }

            case C2S_SET_AUTO_ACCEPT_INVITE_TO_TRUE:{
                onSetAutoAcceptInvite(hc, true);
                return;
            }

            case C2S_SET_GUILD_AUTO_ACCEPT_JOIN_REQUEST:{
                onSetGuildAutoAcceptJoinRequest(buffer, hc);
                return;
            }

            case C2S_SET_NICKNAME:{
                onSetNickname(buffer, hc);
                return;
            }

            case C2S_SET_GROUPNAME:{
                onSetGroupname(buffer, hc);
                return;
            }

            case C2S_GIVE_GIFT_GOODS:{
                onGiveGiftGoods(buffer, hc);
                return;
            }

            case C2S_GIVE_GIFT_MONEY:{
                onGiveGiftMoney(buffer, hc);
                return;
            }

            case C2S_CHANGE_FLAG_KIND:{
                onChangeFlagKind(buffer, hc);
                return;
            }

            case C2S_CHANGE_FLAG_NAME:{
                onChangeFlagName(buffer, hc);
                return;
            }

            case C2S_FLAG_UPGRADE:{
                onFlagUpgrade(buffer, hc);
                return;
            }

            case C2S_INVITE_FRIEND_GUILD:{
                guildRelationManager.onInviteFriend(buffer, hc);
                return;
            }

            case C2S_REPLY_INVITE_FRIEND_GUILD:{
                guildRelationManager.onReplyInviteFriend(buffer, hc);
                return;
            }

            case C2S_REMOVE_FRIEND_GUILD:{
                guildRelationManager.onRemoveFriend(buffer, hc);
                return;
            }

            case C2S_ADD_ENEMY_GUILD:{
                guildRelationManager.onAddEnemy(buffer, hc);
                return;
            }

            case C2S_REMOVE_ENEMY_GUILD:{
                guildRelationManager.onRemoveEnemy(buffer, hc);
                return;
            }

            case C2S_DISMISS_GUILD:{
                onDismissGuild(buffer, hc);
                return;
            }

            case C2S_CHANGE_ANNOUNCEMENT:{
                onChangeAnnouncement(buffer, hc);
                return;
            }

            case C2S_BUY_CONTRIBUTION_GOODS:{
                onBuyContributionGoods(buffer, hc);
                return;
            }

            case C2S_GET_NEWS:{
                onGetNews(buffer, hc);
                return;
            }

            case C2S_SET_FORBID_OTHER_INVITE_ME_JOIN_GUILD_TRUE:{
                onSetForbidOtherInviteMeJoinGuild(hc, true);
                return;
            }

            case C2S_SET_FORBID_OTHER_INVITE_ME_JOIN_GUILD_FLASE:{
                onSetForbidOtherInviteMeJoinGuild(hc, false);
                return;
            }

            default:{
                logger.warn("GuildModule收到未知消息: {}", sequenceID);
            }
        }
    }

    private void onGetNews(ChannelBuffer buffer, HeroController hc){
        GuildMember selfMember = hc.getGuildMember();
        final Guild guild = selfMember.getGuild();
        if (guild == null){
            hc.sendMessage(ERROR_GET_NEWS_NO_GUILD);
            return;
        }

        ChannelBuffer msg = guildNewsMsgCache.getIfPresent(guild);
        if (msg != null){
            hc.sendMessage(msg);
            return;
        }

        final ISender sender = hc.getSender();

        threadService.getDbExecutor().execute(new Runnable(){
            @Override
            public void run(){
                ChannelBuffer msg = guildNewsMsgCache.getUnchecked(guild);
                sender.sendMessage(msg);
            }
        });
    }

    private void onBuyContributionGoods(ChannelBuffer buffer, HeroController hc){
        GuildMember selfMember = hc.getGuildMember();
        Guild guild = selfMember.getGuild();
        if (guild == null){
            hc.sendMessage(ERROR_BUY_CONTRIBUTION_GOODS_NO_GUILD);
            return;
        }

        int index = BufferUtil.readVarInt32(buffer);
        GuildContributionGoods goodsToBuy = contributionGoodsShop
                .getGoods(index);
        if (goodsToBuy == null){
            hc.sendMessage(ERROR_BUY_CONTRIBUTION_GOODS_ILLEGAL_INDEX);
            return;
        }

        if (selfMember.getContribution() < goodsToBuy.requiredGuildContribution){
            hc.sendMessage(ERROR_BUY_CONTRIBUTION_GOODS_NOT_ENOUGH_CONTRIBUTION);
            return;
        }

        if (hc.getHero().getGuildLilian() < goodsToBuy.guildLilianCost){
            hc.sendMessage(ERROR_BUY_CONTRIBUTION_GOODS_NOT_ENOUGH_LILIAN);
            return;
        }

        if (goodsToBuy.limitPerDay > 0){
            if (guild.getContributionGoodsBoughtCount(index) >= goodsToBuy.limitPerDay){
                hc.sendMessage(ERROR_BUY_CONTRIBUTION_GOODS_NONE_LEFT);
                return;
            }
        }

        if (!hc.getDepot().hasEnoughEmptyCount(goodsToBuy.neededDepotEmptyPos)){
            hc.sendMessage(ERROR_BUY_CONTRIBUTION_GOODS_BAG_FULL);
            return;
        }

        Hero hero = hc.getHero();

        // 加锁兑换
        BuyContributionGoodsResult result = tryBuyContributionGoods(guild,
                selfMember, goodsToBuy, index, hc.getHero());
        switch (result){
            case NO_GUILD:{
                hc.sendMessage(ERROR_BUY_CONTRIBUTION_GOODS_NO_GUILD);
                return;
            }

            case NO_CONTRIBUTION:{
                hc.sendMessage(ERROR_BUY_CONTRIBUTION_GOODS_NOT_ENOUGH_CONTRIBUTION);
                return;
            }

            case NO_LILIAN:{
                hc.sendMessage(ERROR_BUY_CONTRIBUTION_GOODS_NOT_ENOUGH_LILIAN);
                return;
            }

            case NONE_LEFT:{
                hc.sendMessage(ERROR_BUY_CONTRIBUTION_GOODS_NONE_LEFT);
                return;
            }

            case SUCCESS:{
                // 买成功, 添加
                hc.sendMessage(buyContributionGoodsSuccess(hero
                        .getGuildLilian()));

                long ctime = timeService.getCurrentTime();
                Goods g = goodsToBuy.newGoods(ctime);

                goodsContainerModule.addGoods(hero, g, hc.getSender(),
                        hc.getHeroMiscModule(), GUILD_BUY, 0, ctime);

                // 兑换物品
                String iEventId = logService.getPartyExchangeProcessor()
                        .newEventID(hc.getID());
                logService.getPartyExchangeProcessor().addLogEvent(
                        hero.getOperatorId(), iEventId, hero.getServerId(),
                        hero.getUin(), hero.getUserId(), hero.getName(),
                        hero.getGuildLilian(), goodsToBuy.guildLilianCost,
                        goodsToBuy.goodsRandomer.getData().getId(),
                        goodsToBuy.goodsRandomer.getData().name,
                        goodsToBuy.goodsCount);

                // 如果有兑换个数限制, 广播给全帮派
                if (goodsToBuy.limitPerDay > 0){
                    int boughtCount = guild
                            .getContributionGoodsBoughtCount(index);
                    guild.broadcast(changeBoughtContributionGoodsCount(index,
                            boughtCount));
                }
            }
        }
    }

    private enum BuyContributionGoodsResult{
        NO_GUILD, NO_CONTRIBUTION, NO_LILIAN, NONE_LEFT, SUCCESS;
    }

    private BuyContributionGoodsResult tryBuyContributionGoods(Guild guild,
            GuildMember selfMember, GuildContributionGoods goods, int index,
            Hero hero){
        synchronized (guild){
            if (selfMember.getGuild() != guild){
                return BuyContributionGoodsResult.NO_GUILD;
            }

            if (selfMember.getContribution() < goods.requiredGuildContribution){
                return BuyContributionGoodsResult.NO_CONTRIBUTION;
            }

            if (hero.getGuildLilian() < goods.guildLilianCost){
                return BuyContributionGoodsResult.NO_LILIAN;
            }

            boolean hasEnoughLeft = guild
                    .incrementContributionGoodsCountIfUnderLimit(index,
                            goods.limitPerDay);
            if (!hasEnoughLeft){
                return BuyContributionGoodsResult.NONE_LEFT;
            }

            hero.reduceGuildLilian(goods.guildLilianCost);
            return BuyContributionGoodsResult.SUCCESS;
        }
    }

    private void onChangeAnnouncement(ChannelBuffer buffer, HeroController hc){
        GuildMember selfMember = hc.getGuildMember();
        Guild guild = selfMember.getGuild();
        if (guild == null){
            hc.sendMessage(ERROR_CHANGE_ANNOUNCEMENT_NO_GUILD);
            return;
        }

        if (guild.getLeader() != selfMember){
            hc.sendMessage(ERROR_CHANGE_ANNOUNCEMENT_NO_RIGHT);
            return;
        }

        int utfLen = buffer.readableBytes();

        if (utfLen > 500){
            hc.sendMessage(ERROR_CHANGE_ANNOUNCEMENT_ILLEGAL_LEN);
            return;
        }

        byte[] newAnnouncement = new byte[utfLen];
        buffer.readBytes(newAnnouncement);

        int strLen = Utils.getStringLength(newAnnouncement);
        if (strLen > 200){
            hc.sendMessage(ERROR_CHANGE_ANNOUNCEMENT_ILLEGAL_LEN);
            return;
        }

        if (!Utils.isValidName(StringEncoder.encode(newAnnouncement))){
            hc.sendMessage(ERROR_CHANGE_ANNOUNCEMENT_ILLEGAL_CHAR);
            return;
        }

        ChangeAnnouncementResult result = tryChangeAnnouncement(guild,
                selfMember, newAnnouncement);
        switch (result){
            case NO_RIGHT:{
                hc.sendMessage(ERROR_CHANGE_ANNOUNCEMENT_NO_RIGHT);
                return;
            }

            case SUCCESS:{
                // 成功
                invalidGuildInfoCache(guild);
                hc.sendMessage(changeAnnouncementSuccess);
                guild.broadcast(announcementChangeBroadcast, hc.combinedID);

                // 加入帮派见闻

                long ctime = timeService.getCurrentTime();
                guild.addNews(GuildNews.announcementChanged(ctime));
            }
        }
    }

    private enum ChangeAnnouncementResult{
        NO_RIGHT, SUCCESS;
    }

    private ChangeAnnouncementResult tryChangeAnnouncement(Guild guild,
            GuildMember selfMember, byte[] newAnnouncement){
        ByteString bs = ByteString.copyFrom(newAnnouncement);
        synchronized (guild){
            if (guild.getLeader() != selfMember){
                return ChangeAnnouncementResult.NO_RIGHT;
            }

            assert selfMember.getGuild() == guild;

            guild.setAnnouncement(bs, timeService.getCurrentTime());
            return ChangeAnnouncementResult.SUCCESS;
        }
    }

    private void onDismissGuild(ChannelBuffer buffer, final HeroController hc){
        threadService.getDbExecutor().execute(new Runnable(){
            @Override
            public void run(){
                if (hc.getIsOffline().get()){
                    return;
                }

                GuildMember selfMember = hc.getGuildMember();
                Guild guild = selfMember.getGuild();
                if (guild == null){
                    hc.sendMessage(ERROR_DISMISS_GUILD_NO_GUILD);
                    return;
                }

                if (guild.getLeader() != selfMember){
                    hc.sendMessage(ERROR_DISMISS_GUILD_NO_RIGHT);
                    return;
                }

                if (guild.isWsCityMaster() || guild.isLongCityMaster()){
                    hc.sendMessage(ERROR_DISMISS_GUILD_CITY_MASTER);
                    return;
                }

                if (isInBattle(hc.getServerData())){
                    hc.sendMessage(ERROR_DISMISS_GUILD_IN_BATTLE);
                    return;
                }

                final boolean dismissed;
                final List<GuildMember> guildMembers;
                synchronized (guild){
                    if (guild.getLeader() != selfMember){
                        // 从同步块之外发送消息
                        dismissed = false;
                        guildMembers = null;
                    } else{
                        guildMembers = doDismissGuild(guild);
                        dismissed = true;
                    }
                }

                if (!dismissed){
                    // 到这里就是同步块内检查帮主失败的
                    hc.sendMessage(ERROR_DISMISS_GUILD_NO_RIGHT);
                } else{
                    invalidGuildListCache();
                    hc.sendMessage(dismissGuildSuccess);

                    worldService.broadcast(guildDismissedBroadcast(
                            selfMember.heroNameBytes, guild.name));
                    guildRelationManager.onGuildDismissed(guild);

                    if (guildMembers != null && guildMembers.size() > 0){

                        List<Long> offlineHeroIDs = new ArrayList<>();
                        for (GuildMember gm : guildMembers){
                            if (!gm.isOnline()){
                                offlineHeroIDs.add(gm.id);
                            }
                        }

                        if (offlineHeroIDs.size() > 0){
                            viewOtherHeroCache.removeCache(offlineHeroIDs);
                        }
                    }

                    if (guild.getTerritoryWinCount() > 0){
                        territoryMasterInfo.onGuildDismissed(guild);
                    }

                    Hero hero = hc.getHero();
                    String iEventId = logService.getPartyDismissProcessor()
                            .newEventID(hero.getID());
                    logService.getPartyDismissProcessor().addLogEvent(
                            hero.getOperatorId(), iEventId, hero.getServerId(),
                            hero.getUin(), hero.getUserId(), hero.getName(), 0,
                            guild.nameString, guild.getFlagLevel(),
                            guild.getGiftMoney());
                }
            }
        });
    }

    // 调用时, 一定拥有帮派锁
    private List<GuildMember> doDismissGuild(Guild guild){
        List<GuildMember> result = new ArrayList<>(guild.members.size());
        guilds.remove(guild.name);
        flagNames.remove(guild.getFlagName().toByteArray());

        for (GuildMember member : guild.members.values()){
            guildMembers.remove(member.id);
            member.leaveGuild(guild);

            result.add(member);
        }

        guild.clearOnDismiss();
        return result;
    }

    private void onFlagUpgrade(ChannelBuffer buffer, HeroController hc){
        GuildMember selfMember = hc.getGuildMember();
        Guild guild = selfMember.getGuild();
        if (guild == null){
            hc.sendMessage(ERROR_FLAG_UPGRADE_NO_GUILD);
            return;
        }

        if (guild.getLeader() != selfMember){
            hc.sendMessage(ERROR_FLAG_UPGRADE_NO_RIGHT);
            return;
        }

        GuildFlagData oldFlagData = guild.getFlagLevelData();

        int oldFlagLevel = oldFlagData.level;
        if (oldFlagLevel >= flagDatas.getMaxLevel()){
            hc.sendMessage(ERROR_FLAG_UPGRADE_FLAG_TOP_LEVEL);
            return;
        }

        UpgradeFlagResult result = tryUpgradeFlag(guild, selfMember);
        switch (result){
            case FLAG_TOP:{
                hc.sendMessage(ERROR_FLAG_UPGRADE_FLAG_TOP_LEVEL);
                return;
            }

            case NO_RESOURCE:{
                hc.sendMessage(ERROR_FLAG_UPGRADE_NOT_ENOUGH_RESOURCE);
                return;
            }

            case NO_RIGHT:{
                hc.sendMessage(ERROR_FLAG_UPGRADE_NO_RIGHT);
                return;
            }

            case SUCCESS:{
                invalidGuildInfoCache(guild);
                hc.sendMessage(flagUpgradeSuccess);
                guild.broadcast(flagUpgradedBroadcast(oldFlagLevel + 1),
                        hc.combinedID);

                // 广播给全服, 展示提示
                worldService
                        .broadcastToEnteredFirstSceneHeroWithSameServerData(
                                flagUpgradeBroadcastToAllOnline(
                                        oldFlagLevel + 1, guild.name), hc
                                        .getServerData(), 0);

                // 如果当前占领了任何板块, 更新
                if (guild.getTerritoryWinCount() > 0){
                    // 如果是帮主, 且本帮有占领过领地, 则广播变化
                    territoryMasterInfo.onGuildFlagInfoChanged(guild);
                }

                WushuangCityMaster master = guild.getWsCityMaster();
                if (master != null){
                    worldService
                            .broadcastToEnteredFirstSceneHeroWithSameServerData(
                                    master.updateMasterFlagMsg(),
                                    guild.serverData, 0);
                }

                LongCityMaster longMaster = guild.getLongCityMaster();
                if (longMaster != null){
                    worldService.broadcastToEnteredFirstSceneHero(
                            longMaster.updateMasterFlagMsg(), 0);
                }

                long ctime = timeService.getCurrentTime();
                guild.addNews(GuildNews.upgradeFlagLevel(ctime,
                        oldFlagLevel + 1, oldFlagData.upgradeGoods1,
                        oldFlagData.upgradeGoods2, oldFlagData.upgradeGoods3,
                        oldFlagData.upgradeGoods4, oldFlagData.upgradeMoney)); // 加入帮派见闻

                Hero hero = hc.getHero();
                String iEventId = logService.getPartyLevelUpProcessor()
                        .newEventID(hero.getID());
                logService.getPartyLevelUpProcessor().addLogEvent(
                        hero.getOperatorId(), iEventId, hero.getServerId(),
                        hero.getUin(), hero.getUserId(), hero.getName(), 0,
                        guild.nameString, guild.getFlagLevel(),
                        guild.getGiftMoney());

                // 帮派物资日志
                logService.getPartyAssetsProcessor().addLogEvent(
                        hero.getOperatorId(), iEventId, hero.getServerId(),
                        hero.getUin(), hero.getUserId(), hero.getName(), 1,
                        guild.getGiftGoodsCount(1), -oldFlagData.upgradeGoods1,
                        GUILD_BANNER_UPGRADE.getNumber());

                logService.getPartyAssetsProcessor().addLogEvent(
                        hero.getOperatorId(), iEventId, hero.getServerId(),
                        hero.getUin(), hero.getUserId(), hero.getName(), 2,
                        guild.getGiftGoodsCount(2), -oldFlagData.upgradeGoods2,
                        GUILD_BANNER_UPGRADE.getNumber());

                logService.getPartyAssetsProcessor().addLogEvent(
                        hero.getOperatorId(), iEventId, hero.getServerId(),
                        hero.getUin(), hero.getUserId(), hero.getName(), 3,
                        guild.getGiftGoodsCount(3), -oldFlagData.upgradeGoods3,
                        GUILD_BANNER_UPGRADE.getNumber());

                logService.getPartyAssetsProcessor().addLogEvent(
                        hero.getOperatorId(), iEventId, hero.getServerId(),
                        hero.getUin(), hero.getUserId(), hero.getName(), 4,
                        guild.getGiftGoodsCount(4), -oldFlagData.upgradeGoods4,
                        GUILD_BANNER_UPGRADE.getNumber());

                logService.getPartyAssetsProcessor().addLogEvent(
                        hero.getOperatorId(), iEventId, hero.getServerId(),
                        hero.getUin(), hero.getUserId(), hero.getName(), 99,
                        guild.getGiftMoney(), -oldFlagData.upgradeMoney,
                        GUILD_BANNER_UPGRADE.getNumber());
            }
        }
    }

    private enum UpgradeFlagResult{
        NO_RIGHT, FLAG_TOP, NO_RESOURCE, SUCCESS;
    }

    private UpgradeFlagResult tryUpgradeFlag(Guild guild, GuildMember selfMember){
        synchronized (guild){
            if (guild.getLeader() != selfMember){
                return UpgradeFlagResult.NO_RIGHT;
            }

            assert selfMember.getGuild() == guild;

            GuildFlagData oldLevel = guild.getFlagLevelData();
            if (oldLevel.level >= flagDatas.getMaxLevel()){
                return UpgradeFlagResult.FLAG_TOP;
            }

            if (!guild.hasEnoughResourceToUpgradeFlag(oldLevel)){
                return UpgradeFlagResult.NO_RESOURCE;
            }

            // 足够

            GuildFlagData newLevel = flagDatas.getLevel(oldLevel.level + 1);
            if (newLevel == null){
                throw new RuntimeException("帮旗说还能升级, 结果取下一级出来个null");
            }

            guild.setFlagLevel(newLevel);
            guild.reduceUpgradeFlagResource(oldLevel); // 扣的是上一级升级所需的

            return UpgradeFlagResult.SUCCESS;
        }
    }

    private void onChangeFlagName(ChannelBuffer buffer, HeroController hc){
        GuildMember selfMember = hc.getGuildMember();
        Guild guild = selfMember.getGuild();
        if (guild == null){
            hc.sendMessage(ERROR_CHANGE_FLAG_NAME_NO_GUILD);
            return;
        }

        if (guild.getLeader() != selfMember){
            hc.sendMessage(ERROR_CHANGE_FLAG_NAME_NO_RIGHT);
            return;
        }

        if (!guild.hasEnoughResourceToChangeFlagName(variableConfig)){
            hc.sendMessage(ERROR_CHANGE_FLAG_NAME_NOT_ENOUGH_RESOURCE);
            return;
        }

        int utfLen = buffer.readableBytes();
        if (utfLen < 2 || utfLen > 30){
            hc.sendMessage(ERROR_CHANGE_FLAG_NAME_ILLEGAL_LEN);
            return;
        }

        byte[] newName = new byte[utfLen];
        buffer.readBytes(newName);
        int strLen = Utils.getStringLength(newName);
        if (strLen < 4 || strLen > 12){
            hc.sendMessage(ERROR_CHANGE_FLAG_NAME_ILLEGAL_LEN);
            return;
        }

        String flagNameString = StringEncoder.encode(newName);
        if (!Utils.isValidName(flagNameString)){
            hc.sendMessage(ERROR_CHANGE_FLAG_NAME_ILLEGAL_CHAR);
            return;
        }

        // 区号使用之前的区号, 不要以当前帮主的区作为新的帮旗区号
        byte[] quBytes = Utils.getServerIDBytes(guild.serverID);
        newName = padQuInfo(newName, quBytes);

        // 放入flagName列表
        if (flagNames.putIfAbsent(newName, Empty.DUMB_OBJECT) != null){
            // 已经有了
            hc.sendMessage(ERROR_CHANGE_FLAG_NAME_NAME_TAKEN);
            return;
        }

        if (isInBattle(hc.getServerData())){
            hc.sendMessage(ERROR_CHANGE_FLAG_NAME_IN_BATTLE);
            return;
        }

        ByteString oldName = guild.getFlagName(); // 改名前

        ChangeFlagNameResult result = tryChangeFlagName(guild, selfMember,
                newName);
        switch (result){
            case NO_RIGHT:{
                flagNames.remove(newName);
                hc.sendMessage(ERROR_CHANGE_FLAG_NAME_NO_RIGHT);
                return;
            }

            case NOT_ENOUGH_RESOURCE:{
                flagNames.remove(newName);
                hc.sendMessage(ERROR_CHANGE_FLAG_NAME_NOT_ENOUGH_RESOURCE);
                return;
            }

            case SUCCESS:{
                flagNames.remove(oldName.toByteArray());
                invalidGuildInfoCache(guild);
                hc.sendMessage(flagNameSuccess);
                guild.broadcast(flagNameChangedBroadcast(newName),
                        hc.combinedID);

                long ctime = timeService.getCurrentTime();
                guild.addNews(GuildNews.changeFlagName(ctime,
                        variableConfig.GUILD_CHANGE_FLAG_NAME_COST_GOODS_1,
                        variableConfig.GUILD_CHANGE_FLAG_NAME_COST_GOODS_2,
                        variableConfig.GUILD_CHANGE_FLAG_NAME_COST_GOODS_3,
                        variableConfig.GUILD_CHANGE_FLAG_NAME_COST_GOODS_4,
                        variableConfig.GUILD_CHANGE_FLAG_NAME_COST_MONEY,
                        newName)); // 加入帮派见闻

                // 帮派物资日志
                Hero hero = hc.getHero();
                String iEventId = logService.getPartyAssetsProcessor()
                        .newEventID(hero.getID());
                logService.getPartyAssetsProcessor().addLogEvent(
                        hero.getOperatorId(), iEventId, hero.getServerId(),
                        hero.getUin(), hero.getUserId(), hero.getName(), 1,
                        guild.getGiftGoodsCount(1),
                        -variableConfig.GUILD_CHANGE_FLAG_NAME_COST_GOODS_1,
                        GUILD_BANNER_RENAME.getNumber());

                logService.getPartyAssetsProcessor().addLogEvent(
                        hero.getOperatorId(), iEventId, hero.getServerId(),
                        hero.getUin(), hero.getUserId(), hero.getName(), 2,
                        guild.getGiftGoodsCount(2),
                        -variableConfig.GUILD_CHANGE_FLAG_NAME_COST_GOODS_2,
                        GUILD_BANNER_RENAME.getNumber());

                logService.getPartyAssetsProcessor().addLogEvent(
                        hero.getOperatorId(), iEventId, hero.getServerId(),
                        hero.getUin(), hero.getUserId(), hero.getName(), 3,
                        guild.getGiftGoodsCount(3),
                        -variableConfig.GUILD_CHANGE_FLAG_NAME_COST_GOODS_3,
                        GUILD_BANNER_RENAME.getNumber());

                logService.getPartyAssetsProcessor().addLogEvent(
                        hero.getOperatorId(), iEventId, hero.getServerId(),
                        hero.getUin(), hero.getUserId(), hero.getName(), 4,
                        guild.getGiftGoodsCount(4),
                        -variableConfig.GUILD_CHANGE_FLAG_NAME_COST_GOODS_4,
                        GUILD_BANNER_RENAME.getNumber());

                logService.getPartyAssetsProcessor().addLogEvent(
                        hero.getOperatorId(), iEventId, hero.getServerId(),
                        hero.getUin(), hero.getUserId(), hero.getName(), 99,
                        guild.getGiftMoney(),
                        -variableConfig.GUILD_CHANGE_FLAG_NAME_COST_MONEY,
                        GUILD_BANNER_RENAME.getNumber());
            }
        }
    }

    private enum ChangeFlagNameResult{
        NO_RIGHT, NOT_ENOUGH_RESOURCE, SUCCESS;
    }

    private ChangeFlagNameResult tryChangeFlagName(Guild guild,
            GuildMember selfMember, byte[] newName){
        synchronized (guild){
            if (guild.getLeader() != selfMember){
                return ChangeFlagNameResult.NO_RIGHT;
            }

            // 已经放入了总帮旗列表, 肯定不会重名
            if (!guild.hasEnoughResourceToChangeFlagName(variableConfig)){
                return ChangeFlagNameResult.NOT_ENOUGH_RESOURCE;
            }

            guild.setFlagName(newName);
            guild.reduceChangeFlagNameResource(variableConfig);
            return ChangeFlagNameResult.SUCCESS;
        }
    }

    private void onChangeFlagKind(ChannelBuffer buffer, HeroController hc){
        GuildMember selfMember = hc.getGuildMember();
        Guild guild = selfMember.getGuild();
        if (guild == null){
            hc.sendMessage(ERROR_CHANGE_FLAG_KIND_NO_GUILD);
            return;
        }

        if (guild.getLeader() != selfMember){
            hc.sendMessage(ERROR_CHANGE_FLAG_KIND_NO_RIGHT);
            return;
        }

        int newFlagKind = BufferUtil.readVarInt32(buffer);
        if (isIllegalFlagKind(newFlagKind)){
            hc.sendMessage(ERROR_CHANGE_FLAG_KIND_ILLEGAL_FLAG_KIND);
            return;
        }

        if (newFlagKind == guild.getFlagKind()){
            hc.sendMessage(ERROR_CHANGE_FLAG_KIND_SAME_FLAG_KIND);
            return;
        }

        if (isInBattle(hc.getServerData())){
            hc.sendMessage(ERROR_CHANGE_FLAG_KIND_IN_BATTLE);
            return;
        }

        ChangeFlagKindResult result = tryChangeFlagKind(guild, selfMember,
                newFlagKind);

        switch (result){
            case NO_RIGHT:{
                hc.sendMessage(ERROR_CHANGE_FLAG_KIND_NO_RIGHT);
                return;
            }

            case NOT_ENOUGH_RESOURCE:{
                hc.sendMessage(ERROR_CHANGE_FLAG_KIND_NOT_ENOUGH_GIFT);
                return;
            }

            case SAME_KIND:{
                hc.sendMessage(ERROR_CHANGE_FLAG_KIND_SAME_FLAG_KIND);
                return;
            }

            case SUCCESS:{
                // 成功
                invalidGuildInfoCache(guild);
                hc.sendMessage(changeFlagKindSuccess);
                guild.broadcast(flagKindChangedBroadcast, hc.combinedID);

                // 如果当前占领了任何板块, 更新
                if (guild.getTerritoryWinCount() > 0){
                    // 如果是帮主, 且本帮有占领过领地, 则广播变化
                    territoryMasterInfo.onGuildFlagInfoChanged(guild);
                }

                WushuangCityMaster master = guild.getWsCityMaster();
                if (master != null){
                    worldService
                            .broadcastToEnteredFirstSceneHeroWithSameServerData(
                                    master.updateMasterFlagMsg(),
                                    guild.serverData, 0);
                }

                LongCityMaster longMaster = guild.getLongCityMaster();
                if (longMaster != null){
                    worldService.broadcastToEnteredFirstSceneHero(
                            longMaster.updateMasterFlagMsg(), 0);
                }

                long ctime = timeService.getCurrentTime();
                guild.addNews(GuildNews.changeFlagKind(ctime,
                        variableConfig.GUILD_CHANGE_FLAG_KIND_COST_GOODS_1,
                        variableConfig.GUILD_CHANGE_FLAG_KIND_COST_GOODS_2,
                        variableConfig.GUILD_CHANGE_FLAG_KIND_COST_GOODS_3,
                        variableConfig.GUILD_CHANGE_FLAG_KIND_COST_GOODS_4,
                        variableConfig.GUILD_CHANGE_FLAG_KIND_COST_MONEY)); // 加入帮派见闻

                // 帮派物资
                Hero hero = hc.getHero();
                String iEventId = logService.getPartyAssetsProcessor()
                        .newEventID(hero.getID());
                logService.getPartyAssetsProcessor().addLogEvent(
                        hero.getOperatorId(), iEventId, hero.getServerId(),
                        hero.getUin(), hero.getUserId(), hero.getName(), 1,
                        guild.getGiftGoodsCount(1),
                        -variableConfig.GUILD_CHANGE_FLAG_KIND_COST_GOODS_1,
                        GUILD_BANNER_MODIFY.getNumber());

                logService.getPartyAssetsProcessor().addLogEvent(
                        hero.getOperatorId(), iEventId, hero.getServerId(),
                        hero.getUin(), hero.getUserId(), hero.getName(), 2,
                        guild.getGiftGoodsCount(2),
                        -variableConfig.GUILD_CHANGE_FLAG_KIND_COST_GOODS_2,
                        GUILD_BANNER_MODIFY.getNumber());

                logService.getPartyAssetsProcessor().addLogEvent(
                        hero.getOperatorId(), iEventId, hero.getServerId(),
                        hero.getUin(), hero.getUserId(), hero.getName(), 3,
                        guild.getGiftGoodsCount(3),
                        -variableConfig.GUILD_CHANGE_FLAG_KIND_COST_GOODS_3,
                        GUILD_BANNER_MODIFY.getNumber());

                logService.getPartyAssetsProcessor().addLogEvent(
                        hero.getOperatorId(), iEventId, hero.getServerId(),
                        hero.getUin(), hero.getUserId(), hero.getName(), 4,
                        guild.getGiftGoodsCount(4),
                        -variableConfig.GUILD_CHANGE_FLAG_KIND_COST_GOODS_4,
                        GUILD_BANNER_MODIFY.getNumber());

                logService.getPartyAssetsProcessor().addLogEvent(
                        hero.getOperatorId(), iEventId, hero.getServerId(),
                        hero.getUin(), hero.getUserId(), hero.getName(), 99,
                        guild.getGiftMoney(),
                        -variableConfig.GUILD_CHANGE_FLAG_KIND_COST_MONEY,
                        GUILD_BANNER_MODIFY.getNumber());

            }
        }
    }

    private enum ChangeFlagKindResult{
        NO_RIGHT, SAME_KIND, NOT_ENOUGH_RESOURCE, SUCCESS;
    }

    private ChangeFlagKindResult tryChangeFlagKind(Guild guild,
            GuildMember selfMember, int newKind){
        synchronized (guild){
            if (guild.getLeader() != selfMember){
                return ChangeFlagKindResult.NO_RIGHT;
            }
            assert selfMember.getGuild() == guild;

            if (newKind == guild.getFlagKind()){
                return ChangeFlagKindResult.SAME_KIND;
            }

            if (!guild.hasEnoughResourceToChangeFlagKind(variableConfig)){
                return ChangeFlagKindResult.NOT_ENOUGH_RESOURCE;
            }

            guild.setFlagKind(newKind);
            guild.reduceChangeFlagKindResource(variableConfig);
            return ChangeFlagKindResult.SUCCESS;
        }
    }

    private boolean isIllegalFlagKind(int kind){
        return kind < 0 || kind >= 15;
    }

    private void onGiveGiftMoney(ChannelBuffer buffer, HeroController hc){
        GuildMember selfMember = hc.getGuildMember();
        Guild guild = selfMember.getGuild();
        if (guild == null){
            hc.sendMessage(ERROR_GIVE_GIFT_MONEY_NO_GUILD);
            return;
        }

        int contributionAmount = BufferUtil.readVarInt32(buffer);
        if (contributionAmount <= 0 || contributionAmount > 9999){
            logger.warn("GuildModule.onGiveGiftMoney 收到的要捐的帮贡非法: {}",
                    contributionAmount);
            hc.sendMessage(ERROR_GIVE_GIFT_MONEY_ILLEGAL_COUNT);
            return;
        }

        int money = contributionAmount
                * VariableConfig.GUILD_GIFT_MONEY_PER_CONTRIBUTION;
        if (money <= 0){
            logger.error(
                    "GuildModule.onGiveGiftMoney时, 总的要捐的钱数overflow了. 要捐{}帮贡, 乘出来要{}银两",
                    contributionAmount, money);
            hc.sendMessage(ERROR_GIVE_GIFT_MONEY_NOT_ENOUGH_MONEY);
            return;
        }

        if (!hc.getHeroMiscModule().hasEnoughMoney(money)){
            logger.warn("GuildModule.onGiveGiftMoney时, 身上没有这么多钱");
            hc.sendMessage(ERROR_GIVE_GIFT_MONEY_NOT_ENOUGH_MONEY);
            return;
        }

        GiveGiftMoneyResult result = tryGiveGiftMoney(guild, selfMember,
                contributionAmount, money);
        switch (result){
            case NOT_IN_GUILD:
                hc.sendMessage(ERROR_GIVE_GIFT_MONEY_NO_GUILD);
                return;

            case FULL:{
                hc.sendMessage(ERROR_GIVE_GIFT_MONEY_GUILD_FULL);
                return;
            }

            case SUCCESS:{

                String iEventId = logService.getPartyAssetsProcessor()
                        .newEventID(hc.getID());

                hc.getHeroMiscModule().reduceMoneyAnyway(money, GUILD_DONATE,
                        iEventId);

                hc.getHeroMiscModule().addGuildLilian(contributionAmount,
                        GUILD_DONATE, iEventId);

                int newGuildLilian = hc.getHero().getGuildLilian();

                invalidGuildInfoCache(guild);
                hc.sendMessage(giveGiftMoneySuccess(
                        selfMember.getContribution(), newGuildLilian));
                guild.broadcast(
                        otherGiveGiftMoneyBroadcast(contributionAmount,
                                selfMember.heroNameBytes), hc.combinedID);

                long ctime = timeService.getCurrentTime();
                guild.addNews(GuildNews.giveGiveMoney(ctime, selfMember.id,
                        selfMember.heroNameBytes, money, contributionAmount)); // 加入帮派见闻

                // 帮派银两
                Hero hero = hc.getHero();
                logService.getPartyAssetsProcessor().addLogEvent(
                        hero.getOperatorId(), iEventId, hero.getServerId(),
                        hero.getUin(), hero.getUserId(), hero.getName(), 99,
                        guild.getGiftMoney(), money, GUILD_DONATE.getNumber());
            }
        }
    }

    public enum ManualAddContributionResult{
        NOT_IN_GUILD, SUCCESS;
    }

    public ManualAddContributionResult tryManualAddContribution(Guild guild,
            GuildMember selfMember, int amount){
        synchronized (guild){
            if (selfMember.getGuild() != guild){
                return ManualAddContributionResult.NOT_IN_GUILD;
            }

            selfMember.addContribution(amount);

            return ManualAddContributionResult.SUCCESS;
        }
    }

    private enum GiveGiftMoneyResult{
        NOT_IN_GUILD, FULL, SUCCESS;
    }

    private GiveGiftMoneyResult tryGiveGiftMoney(Guild guild,
            GuildMember selfMember, int contribution, int money){
        synchronized (guild){
            if (selfMember.getGuild() != guild){
                return GiveGiftMoneyResult.NOT_IN_GUILD;
            }

            boolean added = guild.addGiftMoney(money);
            if (added){
                selfMember.addHistoryGiftMoney(money);

                selfMember.addContribution(contribution);
                return GiveGiftMoneyResult.SUCCESS;
            }
            return GiveGiftMoneyResult.FULL;
        }
    }

    private void onGiveGiftGoods(ChannelBuffer buffer, HeroController hc){
        GuildMember selfMember = hc.getGuildMember();
        Guild guild = selfMember.getGuild();
        if (guild == null){
            hc.sendMessage(ERROR_GIVE_GIFT_GOODS_NO_GUILD);
            return;
        }

        int goodsType = buffer.readUnsignedByte();
        final GoodsData data;
        switch (goodsType){
            case 1:{
                data = giftGoodsData1;
                break;
            }
            case 2:{
                data = giftGoodsData2;
                break;
            }
            case 3:{
                data = giftGoodsData3;
                break;
            }
            case 4:{
                data = giftGoodsData4;
                break;
            }

            default:{
                logger.warn("GuildModule.onGiveGiftGoods收到要捐的物品类型非法: {}",
                        goodsType);
                hc.sendMessage(ERROR_GIVE_GIFT_GOODS_ILLEGAL_GOODS_TYPE);
                return;
            }
        }

        int count = BufferUtil.readVarInt32(buffer);
        if (count <= 0 || count > 999){
            logger.warn("GuildModule.onGiveGiftGoods收到要捐的物品数量非法: {}", count);
            hc.sendMessage(ERROR_GIVE_GIFT_GOODS_ILLEGAL_COUNT_TO_GIVE);
            return;
        }

        final long ctime = timeService.getCurrentTime();

        GoodsTryReduceResult reduceResult = hc.getDepot().canReduceGoods(
                data.id, count, ctime);
        if (!reduceResult.isSuccess()){
            logger.warn(
                    "GuildModule.onGiveGiftGoods时, 要捐{}个物品 {}, 但是包里没有这么多. 客户端没检测?",
                    count, data);
            hc.sendMessage(ERROR_GIVE_GIFT_GOODS_DONT_HAVE_THAT_MANY);
            return;
        }

        GiveGiftGoodsResult result = tryGiveGiftGoods(guild, selfMember,
                goodsType, count);
        switch (result){
            case NOT_IN_GUILD:{
                hc.sendMessage(ERROR_GIVE_GIFT_GOODS_NO_GUILD);
                return;
            }

            case FULL:{
                hc.sendMessage(ERROR_GIVE_GIFT_GOODS_GUILD_FULL);
                return;
            }

            case SUCCESS:{
                // 成功, 还要给英雄加帮贡和历练
                String iEventId = logService.getPartyAssetsProcessor()
                        .newEventID(hc.getID());

                goodsContainerModule.reduceGoodsListAnyway(
                        reduceResult.getPosCountList(), hc.getHero(),
                        hc.getSender(), GUILD_DONATE, goodsType, ctime);

                int lilian = Math.max(1, count
                        * VariableConfig.GUILD_GIFT_GOODS_ADD_CONTRIBUTION);
                hc.getHeroMiscModule().addGuildLilian(lilian, GUILD_DONATE,
                        iEventId);

                int newLilian = hc.getHero().getGuildLilian();

                invalidGuildInfoCache(guild);
                hc.sendMessage(giveGiftGoodsSuccess(
                        selfMember.getContribution(), newLilian));

                guild.broadcast(
                        otherGiveGiftGoodsBroadcast(goodsType, count,
                                selfMember.heroNameBytes), hc.combinedID);

                guild.addNews(GuildNews.giveGiftGoods(ctime, selfMember.id,
                        selfMember.heroNameBytes, goodsType, count, lilian)); // 加入帮派见闻

                // 帮派物资
                Hero hero = hc.getHero();
                logService.getPartyAssetsProcessor().addLogEvent(
                        hero.getOperatorId(), iEventId, hero.getServerId(),
                        hero.getUin(), hero.getUserId(), hero.getName(),
                        goodsType, guild.getGiftGoodsCount(goodsType), count,
                        GUILD_DONATE.getNumber());
            }
        }
    }

    private enum GiveGiftGoodsResult{
        NOT_IN_GUILD, FULL, SUCCESS;
    }

    private GiveGiftGoodsResult tryGiveGiftGoods(Guild guild,
            GuildMember selfMember, int goodsType, int count){
        synchronized (guild){
            if (selfMember.getGuild() != guild){
                return GiveGiftGoodsResult.NOT_IN_GUILD;
            }

            final boolean added;
            switch (goodsType){
                case 1:{
                    added = guild.addGiftGoods1(count);
                    if (added){
                        selfMember.addHistoryGiftGoods1(count);
                    }
                    break;
                }

                case 2:{
                    added = guild.addGiftGoods2(count);
                    if (added){
                        selfMember.addHistoryGiftGoods2(count);
                    }
                    break;
                }

                case 3:{
                    added = guild.addGiftGoods3(count);
                    if (added){
                        selfMember.addHistoryGiftGoods3(count);
                    }
                    break;
                }

                case 4:{
                    added = guild.addGiftGoods4(count);
                    if (added){
                        selfMember.addHistoryGiftGoods4(count);
                    }
                    break;
                }

                default:{
                    throw new RuntimeException();
                }
            }

            if (added){
                int contribution = count
                        * VariableConfig.GUILD_GIFT_GOODS_ADD_CONTRIBUTION;
                selfMember.addContribution(contribution);

                return GiveGiftGoodsResult.SUCCESS;
            }
            return GiveGiftGoodsResult.FULL;
        }
    }

    private void onSetGroupname(ChannelBuffer buffer, HeroController hc){
        GuildMember selfMember = hc.getGuildMember();
        Guild guild = selfMember.getGuild();
        if (guild == null){
            hc.sendMessage(ERROR_SET_GROUPNAME_NO_GUILD);
            return;
        }

        final int myPost;
        if (guild.getLeader() == selfMember){
            myPost = Guild.POSITION_LEADER;
        } else if (guild.getViceLeader() == selfMember){
            myPost = Guild.POSITION_VICE_LEADER;
        } else if (guild.getTangLeader() == selfMember){
            myPost = Guild.POSITION_TANG_LEADER;
        } else{
            hc.sendMessage(ERROR_SET_GROUPNAME_NO_RIGHT);
            return;
        }

        long targetID = BufferUtil.readVarInt64(buffer);

        GuildMember targetMember = guild.getMember(targetID);
        if (targetMember == null){
            hc.sendMessage(ERROR_SET_GROUPNAME_TARGET_NOT_FOUND);
            return;
        }

        int utfLen = buffer.readableBytes();
        if (utfLen > 30){
            logger.warn(
                    "GuildModule.onSetGroupname时, 客户端发来的昵称长度太长: byte的长度: {}",
                    utfLen);
            hc.sendMessage(ERROR_SET_GROUPNAME_TOO_LONG);
            return;
        }

        final byte[] groupname;
        if (utfLen == 0){
            groupname = Empty.BYTE_ARRAY;
        } else{
            groupname = new byte[utfLen];
            buffer.readBytes(groupname);
            int realLen = Utils.getStringLength(groupname);
            if (realLen > 12){
                logger.warn(
                        "GuildModule.onSetGroupname时, 客户端发来的字符长度太长: 汉字字节数的长度: {}",
                        realLen);
                hc.sendMessage(ERROR_SET_GROUPNAME_TOO_LONG);
                return;
            }
        }

        boolean isLegal = Utils.isValidName(StringEncoder.encode(groupname));
        if (!isLegal){
            hc.sendMessage(ERROR_SET_GROUPNAME_ILLEGAL_CHAR);
            return;
        }

        SetGroupnameResult result = trySetGroupname(guild, selfMember,
                targetID, groupname);
        switch (result){
            case NO_RIGHT:{
                hc.sendMessage(ERROR_SET_GROUPNAME_NO_RIGHT);
                return;
            }

            case TARGET_NOT_FOUND:{
                hc.sendMessage(ERROR_SET_GROUPNAME_TARGET_NOT_FOUND);
                return;
            }

            case SUCCESS:{
                // 成功
                invalidGuildInfoCache(guild);
                hc.sendMessage(setGroupnameSuccess);
                if (targetMember != null && targetMember.isOnline()){
                    targetMember.sendMessage(yourGroupnameChanged(myPost,
                            groupname));
                }

                long ctime = timeService.getCurrentTime();

                guild.addNews(GuildNews.changeGroupname(ctime, targetID,
                        targetMember.heroNameBytes, groupname, selfMember.id,
                        selfMember.heroNameBytes, myPost)); // 加入帮派见闻
            }
        }
    }

    private enum SetGroupnameResult{
        NO_RIGHT, TARGET_NOT_FOUND, SUCCESS;
    }

    private SetGroupnameResult trySetGroupname(Guild guild,
            GuildMember selfMember, long targetID, byte[] newNickname){
        synchronized (guild){
            if (guild.getLeader() != selfMember
                    && guild.getViceLeader() != selfMember
                    && guild.getTangLeader() != selfMember){
                return SetGroupnameResult.NO_RIGHT;
            }

            GuildMember targetMember = guild.getMember(targetID);
            if (targetMember == null){
                return SetGroupnameResult.TARGET_NOT_FOUND;
            }

            assert targetMember.getGuild() == guild;

            targetMember.setGroupname(newNickname);
            return SetGroupnameResult.SUCCESS;
        }
    }

    private void onSetNickname(ChannelBuffer buffer, HeroController hc){
        GuildMember selfMember = hc.getGuildMember();
        Guild guild = selfMember.getGuild();
        if (guild == null){
            hc.sendMessage(ERROR_SET_NICKNAME_NO_GUILD);
            return;
        }

        final int myPost;
        if (guild.getLeader() == selfMember){
            myPost = Guild.POSITION_LEADER;
        } else if (guild.getViceLeader() == selfMember){
            myPost = Guild.POSITION_VICE_LEADER;
        } else if (guild.getTangLeader() == selfMember){
            myPost = Guild.POSITION_TANG_LEADER;
        } else{
            hc.sendMessage(ERROR_SET_NICKNAME_NO_RIGHT);
            return;
        }

        long targetID = BufferUtil.readVarInt64(buffer);

        GuildMember targetMember = guild.getMember(targetID);
        if (targetMember == null){
            hc.sendMessage(ERROR_SET_NICKNAME_TARGET_NOT_FOUND);
            return;
        }

        int utfLen = buffer.readableBytes();
        if (utfLen > 30){
            logger.warn(
                    "GuildModule.onSetNickname时, 客户端发来的昵称长度太长: byte的长度: {}",
                    utfLen);
            hc.sendMessage(ERROR_SET_NICKNAME_NOO_LONG);
            return;
        }

        final byte[] nickname;
        if (utfLen == 0){
            nickname = Empty.BYTE_ARRAY;
        } else{
            nickname = new byte[utfLen];
            buffer.readBytes(nickname);
            int realLen = Utils.getStringLength(nickname);
            if (realLen > 12){
                logger.warn(
                        "GuildModule.onSetNickname时, 客户端发来的昵称长度太长: 汉字字节数的长度: {}",
                        realLen);
                hc.sendMessage(ERROR_SET_NICKNAME_NOO_LONG);
                return;
            }
        }

        String name = StringEncoder.encode(nickname);
        boolean isLegal = Utils.isValidName(name);
        if (!isLegal){
            logger.error("GuildModule.onSetNickname收到个非法的昵称: {}", name);
            hc.sendMessage(ERROR_SET_NICKNAME_ILLEGAL_CHAR);
            return;
        }

        SetNicknameResult result = trySetNickname(guild, selfMember, targetID,
                nickname);
        switch (result){
            case NO_RIGHT:{
                hc.sendMessage(ERROR_SET_NICKNAME_NO_RIGHT);
                return;
            }

            case TARGET_NOT_FOUND:{
                hc.sendMessage(ERROR_SET_NICKNAME_TARGET_NOT_FOUND);
                return;
            }

            case SUCCESS:{
                // 成功
                invalidGuildInfoCache(guild);
                hc.sendMessage(setNicknameSuccess);
                if (targetMember != null && targetMember.isOnline()){
                    targetMember.sendMessage(yourNicknameChanged(myPost,
                            nickname));
                }

                long ctime = timeService.getCurrentTime();

                guild.addNews(GuildNews.changeNickname(ctime, targetID,
                        targetMember.heroNameBytes, nickname, selfMember.id,
                        selfMember.heroNameBytes, myPost)); // 加入帮派见闻
            }
        }
    }

    private enum SetNicknameResult{
        NO_RIGHT, TARGET_NOT_FOUND, SUCCESS;
    }

    private SetNicknameResult trySetNickname(Guild guild,
            GuildMember selfMember, long targetID, byte[] newNickname){
        synchronized (guild){
            if (guild.getLeader() != selfMember
                    && guild.getViceLeader() != selfMember
                    && guild.getTangLeader() != selfMember){
                return SetNicknameResult.NO_RIGHT;
            }

            GuildMember targetMember = guild.getMember(targetID);
            if (targetMember == null){
                return SetNicknameResult.TARGET_NOT_FOUND;
            }

            assert targetMember.getGuild() == guild;

            targetMember.setNickname(newNickname);
            return SetNicknameResult.SUCCESS;
        }
    }

    private void onSetGuildAutoAcceptJoinRequest(ChannelBuffer buffer,
            HeroController hc){
        GuildMember selfMember = hc.getGuildMember();
        Guild guild = selfMember.getGuild();
        if (guild == null){
            hc.sendMessage(ERROR_SET_GUILD_AUTO_ACCEPT_JOIN_REQUEST_YOU_HAVE_NO_GUILD);
            return;
        }

        if (guild.getLeader() != selfMember){
            hc.sendMessage(ERROR_SET_GUILD_AUTO_ACCEPT_JOIN_REQUEST_YOU_HAVE_NO_RIGHT);
            return;
        }

        final boolean isAuto = BufferUtil.readBoolean(buffer);
        SetGuildAutoAcceptJoinRequestResult result = trySetAutoAcceptJoinRequest(
                guild, selfMember, isAuto);
        switch (result){
            case NO_RIGHT:{
                hc.sendMessage(ERROR_SET_GUILD_AUTO_ACCEPT_JOIN_REQUEST_YOU_HAVE_NO_RIGHT);
                return;
            }

            case SUCCESS:{
                hc.sendMessage(setGuildAutoAcceptJoinRequestSuccess);
            }
        }
    }

    private enum SetGuildAutoAcceptJoinRequestResult{
        NO_RIGHT, SUCCESS;
    }

    private SetGuildAutoAcceptJoinRequestResult trySetAutoAcceptJoinRequest(
            Guild guild, GuildMember selfMember, boolean isAuto){
        synchronized (guild){
            if (guild.getLeader() != selfMember){
                return SetGuildAutoAcceptJoinRequestResult.NO_RIGHT;
            }

            assert selfMember.getGuild() == guild;
            guild.setAutoAcceptJoinRequest(isAuto);
            return SetGuildAutoAcceptJoinRequestResult.SUCCESS;
        }
    }

    private void onSetAutoAcceptInvite(HeroController hc, boolean v){
        hc.getHero().setIsGuildAutoAcceptInvite(v);
        hc.getGuildMember().setAutoAcceptInvite(v);
    }

    private void onSetForbidOtherInviteMeJoinGuild(HeroController hc, boolean v){
        hc.getHero().setForbidOtherInviteMeJoinGuild(v);
        hc.getGuildMember().setForbidOtherInviteMeJoinGuild(v);
    }

    private void onSetPosition(ChannelBuffer buffer, HeroController hc){
        GuildMember selfMember = hc.getGuildMember();
        Guild guild = selfMember.getGuild();
        if (guild == null){
            hc.sendMessage(ERROR_SET_POSITION_YOU_HAVE_NOT_GUILD);
            return;
        }

        if (guild.getLeader() != selfMember){
            hc.sendMessage(ERROR_SET_POSITION_YOU_HAVE_NO_RIGHT);
            return;
        }

        final long targetID = BufferUtil.readVarInt64(buffer);
        final int targetPost = BufferUtil.readVarInt32(buffer);

        if (targetPost < 0 || targetPost > 3){
            logger.warn("GuildModule.onSetPosition客户端发来的post: {}", targetPost);
            hc.sendMessage(ERROR_SET_POSITION_ILLEGAL_POST);
            return;
        }

        if (targetID == hc.combinedID){
            logger.warn("GuildModule.onSetPosition客户端发来的人id是自己");
            hc.sendMessage(ERROR_SET_POSITION_CANNOT_SET_SELF);
            return;
        }

        GuildMember targetMember = guild.getMember(targetID);
        if (targetMember == null){
            hc.sendMessage(ERROR_SET_POSITION_TARGET_NOT_FOUND);
            return;
        }

        if (isInBattle(hc.getServerData())){
            hc.sendMessage(ERROR_SET_POSITION_IN_BATTLE);
            return;
        }

        WushuangCityMaster cityMaster = guild.getWsCityMaster();

        final GuildMember oldPost;
        switch (targetPost){
            case Guild.POSITION_VICE_LEADER:
                oldPost = guild.getViceLeader();
                break;

            case Guild.POSITION_TANG_LEADER:
                oldPost = guild.getTangLeader();
                break;
            case Guild.POSITION_LEADER:{
                if (cityMaster != null){
                    hc.sendMessage(ERROR_SET_POSITION_IS_WS_CITY_MASTER);
                    return;
                }

                if (guild.isLongCityMaster()){
                    hc.sendMessage(ERROR_SET_POSITION_IS_LONG_CITY_MASTER);
                    return;
                }
            }
            default:
                oldPost = null;
                break;
        }

        SetPositionResult result = trySetPosition(guild, selfMember, targetID,
                targetPost);
        switch (result){
            case NO_RIGHT:{
                hc.sendMessage(ERROR_SET_POSITION_YOU_HAVE_NO_RIGHT);
                return;
            }

            case TARGET_NOT_FOUND:{
                hc.sendMessage(ERROR_SET_POSITION_TARGET_NOT_FOUND);
                return;
            }

            case TARGET_ALREADY_THAT_POST:{
                hc.sendMessage(ERROR_SET_POSITION_TARGET_ALREADY_THAT_POST);
                return;
            }

            case SUCCESS:{
                // 成功
                invalidGuildInfoCache(guild);
                hc.sendMessage(setPositionSuccess);
                guild.broadcast(positionChangeBroadcast(targetID,
                        targetMember.heroNameBytes, targetPost));
                if (oldPost != null && oldPost.isOnline()){
                    oldPost.sendMessage(yourPostLost);
                }

                if (targetPost != Guild.POSITION_NORMAL){
                    long ctime = timeService.getCurrentTime();

                    guild.addNews(GuildNews.changePost(ctime, targetID,
                            targetMember.heroNameBytes, targetPost)); // 加到帮派见闻
                }

                if (cityMaster != null
                        && targetPost == Guild.POSITION_VICE_LEADER){
                    cityMaster.checkHufaTransfer(targetMember);
                }

                if (targetPost == Guild.POSITION_LEADER){
                    if (guild.getTerritoryWinCount() > 0){
                        // 如果是帮主, 且本帮有占领过领地, 则广播变化
                        territoryMasterInfo.onGuildLeaderChanged(guild,
                                targetMember);
                    }
                }
            }
        }
    }

    private enum SetPositionResult{
        NO_RIGHT, TARGET_NOT_FOUND, TARGET_ALREADY_THAT_POST, SUCCESS;
    }

    private SetPositionResult trySetPosition(final Guild guild,
            final GuildMember selfMember, final long targetID,
            final int targetPost){
        assert targetID != selfMember.id;

        synchronized (guild){
            if (guild.getLeader() != selfMember){
                return SetPositionResult.NO_RIGHT;
            }
            // selfMember.guild 也一定是guild, 不然不会还是leader
            assert selfMember.getGuild() == guild;

            GuildMember targetMember = guild.getMember(targetID);
            if (targetMember == null){
                return SetPositionResult.TARGET_NOT_FOUND;
            }

            if (targetMember.getGuild() != guild){
                logger.error("GuildModule.trySetPosition targetMember还在guild的memberMap中, 但targetMember.guild已经不是这个guild");
                return SetPositionResult.TARGET_NOT_FOUND;
            }

            switch (targetPost){
                case Guild.POSITION_LEADER:{
                    // 要把人设为帮主
                    GuildMember oldMem = guild.getLeader();
                    if (oldMem == targetMember){
                        // should not happen
                        logger.error("GuildModule.trySetPosition, 要被设为帮主的人本来就是帮主? 怎么可能");
                        return SetPositionResult.TARGET_ALREADY_THAT_POST;
                    }

                    boolean set = guild.casLeader(oldMem, targetMember);
                    if (!set){
                        logger.error("GuildModule.trySetPosition时, cas职位失败了");
                        return SetPositionResult.NO_RIGHT;
                    }

                    if (targetMember == guild.getViceLeader()){
                        guild.casViceLeader(targetMember, null);
                    } else if (targetMember == guild.getTangLeader()){
                        guild.casTangLeader(targetMember, null);
                    }

                    return SetPositionResult.SUCCESS;
                }

                case Guild.POSITION_VICE_LEADER:{
                    // 要把人设为副帮主
                    GuildMember oldMem = guild.getViceLeader();
                    if (oldMem == targetMember){
                        return SetPositionResult.TARGET_ALREADY_THAT_POST;
                    }

                    if (guild.getLeader() == oldMem){
                        return SetPositionResult.NO_RIGHT;
                    }

                    boolean set = guild.casViceLeader(oldMem, targetMember);
                    if (!set){
                        logger.error("GuildModule.trySetPosition时, cas职位失败了");
                        return SetPositionResult.NO_RIGHT;
                    }

                    if (guild.getTangLeader() == targetMember){
                        guild.casTangLeader(targetMember, null);
                    }

                    return SetPositionResult.SUCCESS;
                }

                case Guild.POSITION_TANG_LEADER:{
                    // 要把人设为堂主
                    GuildMember oldMem = guild.getTangLeader();
                    if (oldMem == targetMember){
                        return SetPositionResult.TARGET_ALREADY_THAT_POST;
                    }

                    if (guild.getLeader() == oldMem){
                        return SetPositionResult.NO_RIGHT;
                    }

                    boolean set = guild.casTangLeader(oldMem, targetMember);
                    if (!set){
                        logger.error("GuildModule.trySetPosition时, cas职位失败了");
                        return SetPositionResult.NO_RIGHT;
                    }

                    if (guild.getViceLeader() == targetMember){
                        guild.casViceLeader(targetMember, null);
                    }

                    return SetPositionResult.SUCCESS;
                }

                default:{
                    // 要把人设为群众
                    // 看下这个人原来有没有职位
                    GuildMember oldMem = guild.getLeader();
                    if (oldMem == targetMember){
                        logger.error("GuildModule.trySetPosition, 要把原来的帮主设为群众, 怎么可能?");
                        return SetPositionResult.NO_RIGHT;
                    }

                    oldMem = guild.getViceLeader();
                    if (oldMem == targetMember){
                        boolean set = guild.casViceLeader(oldMem, null);
                        if (!set){
                            logger.error("GuildModule.trySetPosition时, cas职位失败了");
                            return SetPositionResult.NO_RIGHT;
                        }
                        return SetPositionResult.SUCCESS;
                    }

                    oldMem = guild.getTangLeader();
                    if (oldMem == targetMember){
                        boolean set = guild.casTangLeader(oldMem, null);
                        if (!set){
                            logger.error("GuildModule.trySetPosition时, cas职位失败了");
                            return SetPositionResult.NO_RIGHT;
                        }

                        return SetPositionResult.SUCCESS;
                    }

                    // 本来就是群众
                    return SetPositionResult.TARGET_ALREADY_THAT_POST;
                }
            }
        }
    }

    private void onKickMember(ChannelBuffer buffer, HeroController hc){

        GuildMember selfMember = hc.getGuildMember();
        final Guild guild = selfMember.getGuild();
        if (guild == null){
            hc.sendMessage(ERROR_KICK_MEMBER_NOT_IN_GUILD);
            return;
        }

        final int selfPost;
        if (guild.getLeader() == selfMember){
            selfPost = Guild.POSITION_LEADER;
        } else if (guild.getViceLeader() == selfMember){
            selfPost = Guild.POSITION_VICE_LEADER;
        } else{
            hc.sendMessage(ERROR_KICK_MEMBER_YOU_HAVE_NO_RIGHT);
            return;
        }

        final long toKickID = BufferUtil.readVarInt64(buffer);
        if (toKickID == hc.combinedID){
            hc.sendMessage(ERROR_KICK_MEMBER_YOU_HAVE_NO_RIGHT);
            return;
        }

        GuildMember targetMember = guild.getMember(toKickID);
        if (targetMember == null){
            hc.sendMessage(ERROR_KICK_MEMBER_TARGET_NOT_IN_GUILD);
            return;
        }

        if (isInBattle(hc.getServerData())){
            hc.sendMessage(ERROR_KICK_MEMBER_IN_BATTLE);
            return;
        }

        KickResult result = tryKick(guild, selfMember, toKickID);
        switch (result){
            case NO_RIGHT:{
                hc.sendMessage(ERROR_KICK_MEMBER_YOU_HAVE_NO_RIGHT);
                return;
            }
            case NOT_FOUND:{
                hc.sendMessage(ERROR_KICK_MEMBER_TARGET_NOT_IN_GUILD);
                return;
            }
            case SUCCESS:{

                invalidGuildInfoCache(guild);
                hc.sendMessage(kickMemberSuccess);
                targetMember
                        .sendMessage(youBeenKicked(selfMember.heroNameBytes));
                guild.broadcast(someoneBeenKicked(selfMember.heroNameBytes,
                        targetMember.heroNameBytes));
                HeroController targetHc = worldService
                        .getHeroController(toKickID); // 就算没进第一个场景, 也要告诉他
                String targetName;
                if (targetHc != null){
                    targetHc.notifyGuildChanged(Empty.BYTE_ARRAY, false, false,
                            false);
                    targetName = targetHc.getHero().getName();
                } else{
                    // 不在线, 要删掉被见缓存
                    clearBeenViewCache(Long.valueOf(toKickID));
                    targetName = StringEncoder
                            .encode(targetMember.heroNameBytes);
                }

                long ctime = timeService.getCurrentTime();

                guild.addNews(GuildNews.kickMember(ctime, toKickID,
                        targetMember.heroNameBytes, selfMember.id,
                        selfMember.heroNameBytes, selfPost)); // 加到帮派见闻中

                Hero hero = hc.getHero();
                String iEventId = logService.getPartyDelMemberProcessor()
                        .newEventID(hero.getID());
                logService.getPartyDelMemberProcessor().addLogEvent(
                        hero.getOperatorId(), iEventId, hero.getServerId(),
                        hero.getUin(), hero.getUserId(), hero.getName(), 0,
                        guild.nameString, guild.getFlagLevel(),
                        guild.getGiftMoney(), targetName);
            }
        }
    }

    /**
     * 删除英雄被见缓存
     * @param id
     */
    private void clearBeenViewCache(final Long id){
        viewOtherHeroCache.removeCache(id);
    }

    private enum KickResult{
        NO_RIGHT, NOT_FOUND, SUCCESS;
    }

    private KickResult tryKick(final Guild guild, final GuildMember selfMember,
            final long toKickID){
        synchronized (guild){
            GuildMember targetMember = guild.getMember(toKickID);
            if (targetMember == null || targetMember.getGuild() != guild){
                return KickResult.NOT_FOUND;
            }

            // 找到了
            boolean selfIsLeader = guild.getLeader() == selfMember;
            boolean selfIsViceLeader;
            if (selfIsLeader){
                selfIsViceLeader = false;
            } else{
                selfIsViceLeader = guild.getViceLeader() == selfMember;
            }

            if (!selfIsLeader && !selfIsViceLeader){
                return KickResult.NO_RIGHT;
            }

            boolean targetIsLeader = guild.getLeader() == targetMember;
            if (targetIsLeader){
                return KickResult.NO_RIGHT;
            }

            boolean targetIsViceLeader = guild.getViceLeader() == targetMember;
            boolean targetIsTangLeader = guild.getTangLeader() == targetMember;

            assert !(selfIsViceLeader && targetIsViceLeader);

            if (selfIsViceLeader && targetIsTangLeader){
                // 只有踢人的人是副帮主时, 才需要检查对方的职位. 帮主除了自己谁都能踢
                return KickResult.NO_RIGHT;
            }

            // 可以踢
            guild.removeMember(toKickID);
            guildMembers.remove(toKickID);

            if (targetIsViceLeader){
                guild.casViceLeader(targetMember, null);
            } else if (targetIsTangLeader){
                guild.casTangLeader(targetMember, null);
            }

            targetMember.leaveGuild(guild);
            return KickResult.SUCCESS;
        }
    }

    private void onLeaveGuild(ChannelBuffer buffer, HeroController hc){

        GuildMember selfMember = hc.getGuildMember();
        final Guild guild = selfMember.getGuild();
        if (guild == null){
            hc.sendMessage(ERROR_LEAVE_GUILD_YOU_HAVE_NO_GUILD);
            return;
        }

        if (guild.getLeader() == selfMember){
            hc.sendMessage(ERROR_LEAVE_GUILD_YOU_ARE_LEADER);
            return;
        }

        if (isInBattle(hc.getServerData())){
            hc.sendMessage(ERROR_LEAVE_GUILD_IN_BATTLE);
            return;
        }

        LeaveGuildResult result = tryLeaveGuild(guild, selfMember);

        switch (result){
            case NOT_IN_GUILD:{
                hc.sendMessage(ERROR_LEAVE_GUILD_YOU_HAVE_NO_GUILD);
                return;
            }

            case YOU_ARE_LEADER:{
                hc.sendMessage(ERROR_LEAVE_GUILD_YOU_ARE_LEADER);
                return;
            }

            case SUCCESS:{
                // 正式退出了
                invalidGuildInfoCache(guild);

                hc.sendMessage(leaveGuildSuccess);

                hc.notifyGuildChanged(Empty.BYTE_ARRAY, false, false, false);
                guild.broadcast(otherLeaveGuild(selfMember.heroNameBytes));

                long ctime = timeService.getCurrentTime();

                guild.addNews(GuildNews.memberLeave(ctime, selfMember.id,
                        selfMember.heroNameBytes)); // 加入帮派见闻中

                Hero hero = hc.getHero();
                String iEventId = logService.getPartyDelMemberProcessor()
                        .newEventID(hero.getID());
                logService.getPartyDelMemberProcessor().addLogEvent(
                        hero.getOperatorId(), iEventId, hero.getServerId(),
                        hero.getUin(), hero.getUserId(), hero.getName(), 0,
                        guild.nameString, guild.getFlagLevel(),
                        guild.getGiftMoney(), hero.getName());
            }
        }
    }

    private enum LeaveGuildResult{
        YOU_ARE_LEADER, NOT_IN_GUILD, SUCCESS;
    }

    private LeaveGuildResult tryLeaveGuild(Guild guild, GuildMember selfMember){
        synchronized (guild){
            Guild guildInLock = selfMember.getGuild();
            if (guildInLock != guild){
                return LeaveGuildResult.NOT_IN_GUILD;
            }

            GuildMember leader = guild.getLeader();
            if (leader != null && leader.id == selfMember.id){
                return LeaveGuildResult.YOU_ARE_LEADER;
            }

            // 不是帮主, 可以退

            // 如果是副帮主, 卸任
            boolean set = guild.casViceLeader(selfMember, null);
            if (!set){
                // 不是副帮主, 如果是堂主, 卸任
                guild.casTangLeader(selfMember, null);
            }

            // 一定要先从guild中remove, 再cas玩家的guild. 添加玩家时, 先cas玩家的guild, 成功后再add到guild中
            guild.removeMember(selfMember.id);
            guildMembers.remove(selfMember.id);

            set = selfMember.leaveGuild(guild);
            if (!set){
                logger.error("GuildModule.onLeaveGuild时, selfMember.setGuildWhenSame(guild, null) 返回失败. 别的地方踢他出帮派的时候没有加锁?");
                return LeaveGuildResult.NOT_IN_GUILD;
            }

            return LeaveGuildResult.SUCCESS;
        }
    }

    private void onRejectAllJoinInvite(ChannelBuffer buffer, HeroController hc){
        ChannelBuffer rejectMsg = null;
        for (Guild g : guilds.values()){
            HeroID inviterID = g.removeInviteIfExists(hc.getHeroID());
            if (inviterID == null){
                continue;
            }

            // 有邀请过

            GuildMember inviter = g.getMember(inviterID.id);
            if (inviter != null && inviter.isOnline()){
                if (rejectMsg == null){
                    rejectMsg = otherRejectedYourJoinInvite(hc.combinedID, hc
                            .getHero().getNameBytes());
                }
                inviter.sendMessage(rejectMsg);
            }
        }
    }

    private void onReplyJoinInvite(ChannelBuffer buffer, HeroController hc){
        boolean reply = BufferUtil.readBoolean(buffer);
        GuildMember selfMember = hc.getGuildMember();
        Guild guild = selfMember.getGuild();
        if (guild != null){
            if (reply){
                hc.sendMessage(ERROR_REPLY_JOIN_INVITE_YOU_HAVE_GUILD);
            }
            return;
        }

        int utfLen = buffer.readableBytes();
        if (utfLen >= 50){
            if (reply){
                hc.sendMessage(ERROR_REPLY_JOIN_INVITE_GUILD_NOT_EXIST);
            }
            return;
        }
        byte[] guildName = new byte[utfLen];
        buffer.readBytes(guildName);

        guild = guilds.get(guildName);
        if (guild == null){
            if (reply){
                hc.sendMessage(ERROR_REPLY_JOIN_INVITE_GUILD_NOT_EXIST);
            }
            return;
        }

        HeroID inviterID = guild.removeInviteIfExists(hc.getHeroID());
        if (inviterID == null){
            // 没有邀请过
            if (reply){
                hc.sendMessage(ERROR_REPLY_JOIN_INVITE_INVITE_EXPIRED);
            }
            return;
        }

        if (!reply){
            // 拒绝, 找到邀请者, 发送被拒绝消息
            GuildMember inviter = guild.getMember(inviterID.id);
            if (inviter != null && inviter.isOnline()){
                inviter.sendMessage(otherRejectedYourJoinInvite(selfMember.id,
                        selfMember.heroNameBytes));
            }
            return;
        }

        // 同意

        if (!guild.hasEmptySpot()){
            hc.sendMessage(ERROR_REPLY_JOIN_INVITE_TARGET_GUILD_FULL);
            return;
        }

        if (isInBattle(hc.getServerData())){
            hc.sendMessage(ERROR_REPLY_JOIN_INVITE_IN_BATTLE);
            return;
        }

        // 先cas自己帮派, 再加帮派

        AddMemberResult result = tryAddMemberToGuild(guild, selfMember);
        switch (result){
            case HERO_HAVE_GUILD:{
                hc.sendMessage(ERROR_REPLY_JOIN_INVITE_YOU_HAVE_GUILD);
                return;
            }

            case GUILD_FULL:{
                hc.sendMessage(ERROR_REPLY_JOIN_INVITE_TARGET_GUILD_FULL);
                return;
            }

            case SUCCESS:{
                hc.sendMessage(replyJoinInviteSuccess);
                afterJoinGuild(guild, selfMember, hc);

                // 通知邀请者
                GuildMember inviter = guild.getMember(inviterID.id);
                if (inviter != null && inviter.isOnline()){
                    inviter.sendMessage(otherAcceptedYourJoinInvite(selfMember.heroNameBytes));
                }

                Hero hero = hc.getHero();
                String iEventId = logService.getPartyAddMemberProcessor()
                        .newEventID(hero.getID());
                logService.getPartyAddMemberProcessor().addLogEvent(
                        hero.getOperatorId(), iEventId, hero.getServerId(),
                        hero.getUin(), hero.getUserId(), hero.getName(), 0,
                        guild.nameString, guild.getFlagLevel(),
                        guild.getGiftMoney(), hero.getName());
            }
        }
    }

    private void onInviteJoin(ChannelBuffer buffer, HeroController hc){
        GuildMember selfMember = hc.getGuildMember();
        Guild guild = selfMember.getGuild();
        if (guild == null){
            hc.sendMessage(ERROR_INVITE_JOIN_YOU_HAVE_NO_GUILD);
            return;
        }

        if (guild.getLeader() != selfMember
                && guild.getViceLeader() != selfMember){
            hc.sendMessage(ERROR_INVITE_JOIN_YOU_HAVE_NO_RIGHT);
            return;
        }

        if (!guild.hasEmptySpot()){
            hc.sendMessage(ERROR_INVITE_JOIN_GUILD_FULL);
            return;
        }
        long targetID = BufferUtil.readVarInt64(buffer);
        HeroController targetHc = worldService
                .getHeroControllerIfEnteredFirstScene(targetID);

        if (targetHc == null){
            hc.sendMessage(ERROR_INVITE_JOIN_TARGET_NOT_ONLINE);
            return;
        }

        if (targetHc.getServerData() != guild.serverData){
            hc.sendMessage(ERROR_INVITE_JOIN_OTHER_UNION);
            return;
        }

        if (targetHc.getHero().getLevel() < VariableConfig.GUILD_INVITE_JOIN_LEVEL_LIMIT){
            hc.sendMessage(ERROR_INVITE_JOIN_OTHER_LEVEL_TOO_LOW);
            return;
        }
        GuildMember targetGuildMember = targetHc.getGuildMember();

        Guild targetGuild = targetGuildMember.getGuild();
        if (targetGuild != null){
            if (targetGuild == guild){
                hc.sendMessage(ERROR_INVITE_JOIN_TARGET_IN_YOUR_GUILD);
            } else if (targetGuild == Guild.OFFLINE_GUILD){
                hc.sendMessage(ERROR_INVITE_JOIN_TARGET_NOT_ONLINE);
            } else{
                hc.sendMessage(ERROR_INVITE_JOIN_TARGET_IN_OTHER_GUILD);
            }
            return;
        }

        if (targetGuildMember.isForbidOtherInviteMeJoinGuild()){
            //禁止被别人邀请加人帮派
            hc.sendMessage(ERROR_INVITE_JOIN_OTHER_FORBID_BEEN_INVITED);
            return;
        }

        if (isInBattle(hc.getServerData())){
            hc.sendMessage(ERROR_INVITE_JOIN_IN_BATTLE);
            return;
        }

        if (targetGuildMember.isAutoAcceptInvite()){
            // 自动接受邀请
            AddMemberResult result = tryAddMemberToGuild(guild,
                    targetGuildMember);
            switch (result){
                case GUILD_FULL:{
                    hc.sendMessage(ERROR_INVITE_JOIN_GUILD_FULL);
                    return;
                }

                case HERO_HAVE_GUILD:{
                    hc.sendMessage(ERROR_INVITE_JOIN_TARGET_IN_OTHER_GUILD);
                    return;
                }

                case SUCCESS:{
                    hc.sendMessage(inviteJoinSuccess);
                    afterJoinGuild(guild, targetGuildMember, targetHc);

                    // 发送对方同意了邀请消息

                    hc.sendMessage(otherAcceptedYourJoinInvite(targetGuildMember.heroNameBytes));

                    Hero hero = hc.getHero();
                    String iEventId = logService.getPartyAddMemberProcessor()
                            .newEventID(hero.getID());
                    logService.getPartyAddMemberProcessor().addLogEvent(
                            hero.getOperatorId(), iEventId, hero.getServerId(),
                            hero.getUin(), hero.getUserId(), hero.getName(), 0,
                            guild.nameString, guild.getFlagLevel(),
                            guild.getGiftMoney(), targetHc.getHero().getName());
                }
            }
            return;
        }

        // 不是自动接受邀请
        if (guild.hasInviteJoin(targetHc.getHeroID())){
            hc.sendMessage(ERROR_INVITE_JOIN_ALREADY_INVITED);
            return;
        }

        guild.markInvitedJoin(targetHc.getHeroID(), selfMember.heroID);

        hc.sendMessage(inviteJoinSuccessAndWaitOtherReply);
        targetHc.sendMessage(receiveJoinInvite(selfMember.id,
                selfMember.heroNameBytes, hc.getHero().getRace().getId(),
                guild.getFlagLevel(), guild.name));
    }

    private void onReplyJoinRequest(ChannelBuffer buffer, HeroController hc){
        long targetID = BufferUtil.readVarInt64(buffer);
        boolean reply = BufferUtil.readBoolean(buffer);

        GuildMember selfMember = hc.getGuildMember();
        Guild guild = selfMember.getGuild();

        // 没有帮派
        if (guild == null){
            if (reply){
                hc.sendMessage(ERROR_REPLY_JOIN_REQUEST_YOU_HAVE_NO_GUILD);
            }
            return;
        }

        // 不是帮主/副帮主
        if (guild.getLeader() != selfMember
                && guild.getViceLeader() != selfMember){
            if (reply){
                hc.sendMessage(ERROR_REPLY_JOIN_REQUEST_YOU_HAVE_NO_RIGHT);
            }
            return;
        }

        HeroController targetHc = worldService
                .getHeroControllerIfEnteredFirstScene(targetID);
        if (targetHc == null){
            if (reply){
                hc.sendMessage(ERROR_REPLY_JOIN_REQUEST_TARGET_OFFLINE);
            }
            return;
        }

        boolean requested = guild.removeRequestJoinIfExists(targetHc
                .getHeroID());
        if (!requested){
            if (reply){
                hc.sendMessage(ERROR_REPLY_JOIN_REQUEST_REQUEST_EXPIRED);
            }
            return;
        }

        if (!reply){
            if (!targetHc.getGuildMember().hasGuild()){
                // 没有帮派时, 才会收到
                targetHc.sendMessage(otherRejectedYourRequest(guild.name));
            }
            return;
        }

        // 同意入帮
        GuildMember targetGuildMember = targetHc.getGuildMember();
        Guild targetGuild = targetGuildMember.getGuild();
        if (targetGuild != null){
            if (targetGuild == guild){
                hc.sendMessage(ERROR_REPLY_JOIN_REQUEST_ALREADY_IN_YOUR_GUILD);
            } else if (targetGuild == Guild.OFFLINE_GUILD){
                hc.sendMessage(ERROR_REPLY_JOIN_REQUEST_TARGET_OFFLINE);
            } else{
                hc.sendMessage(ERROR_REPLY_JOIN_REQUEST_IN_OTHER_GUILD);
            }
            return;
        }

        // 对方没有帮派

        if (!guild.hasEmptySpot()){
            // 没有位子了
            hc.sendMessage(ERROR_REPLY_JOIN_REQUEST_GUILD_FULL);
            return;
        }

        if (isInBattle(hc.getServerData())){
            hc.sendMessage(ERROR_REPLY_JOIN_REQUEST_IN_BATTLE);
            return;
        }

        AddMemberResult result = tryAddMemberToGuild(guild, targetGuildMember);
        switch (result){
            case GUILD_FULL:{
                hc.sendMessage(ERROR_REPLY_JOIN_REQUEST_GUILD_FULL);
                return;
            }

            case HERO_HAVE_GUILD:{
                hc.sendMessage(ERROR_REPLY_JOIN_REQUEST_IN_OTHER_GUILD);
                return;
            }

            case SUCCESS:{
                hc.sendMessage(replyJoinRequestSuccess);
                targetHc.sendMessage(otherAcceptedYourRequest(guild.name));

                afterJoinGuild(guild, targetGuildMember, targetHc);

                Hero hero = hc.getHero();
                String iEventId = logService.getPartyAddMemberProcessor()
                        .newEventID(hero.getID());
                logService.getPartyAddMemberProcessor().addLogEvent(
                        hero.getOperatorId(), iEventId, hero.getServerId(),
                        hero.getUin(), hero.getUserId(), hero.getName(), 0,
                        guild.nameString, guild.getFlagLevel(),
                        guild.getGiftMoney(), targetHc.getHero().getName());
            }
        }
    }

    private void onRequestJoin(ChannelBuffer buffer, HeroController hc){
        if (hc.getHero().getLevel() < VariableConfig.GUILD_REQUEST_JOIN_LEVEL_LIMIT){
            hc.sendMessage(ERROR_REQUEST_JOIN_LEVEL_TOO_LOW);
            return;
        }

        GuildMember mem = hc.getGuildMember();
        if (mem.hasGuild()){
            hc.sendMessage(ERROR_REQUEST_JOIN_YOU_HAVE_GUILD);
            return;
        }

        int utfLen = buffer.readableBytes();
        if (utfLen > 50){
            hc.sendMessage(ERROR_REQUEST_JOIN_GUILD_NOT_EXIST);
            return;
        }

        byte[] guildName = new byte[utfLen];
        buffer.readBytes(guildName);

        Guild guild = guilds.get(guildName);
        if (guild == null){
            hc.sendMessage(ERROR_REQUEST_JOIN_GUILD_NOT_EXIST);
            return;
        }

        if (guild.serverData != hc.getServerData()){
            hc.sendMessage(ERROR_REQUEST_OTHER_UNION);
            return;
        }

        if (isInBattle(hc.getServerData())){
            hc.sendMessage(ERROR_REQUEST_IN_BATTLE);
            return;
        }

        if (!guild.hasEmptySpot()){
            hc.sendMessage(ERROR_REQUEST_JOIN_GUILD_FULL);
            return;
        }

        if (guild.isAutoAcceptJoinRequest()){
            // 自动接受请求的

            AddMemberResult result = tryAddMemberToGuild(guild, mem);

            switch (result){
                case GUILD_FULL:{
                    hc.sendMessage(ERROR_REQUEST_JOIN_GUILD_FULL);
                    return;
                }

                case HERO_HAVE_GUILD:{
                    hc.sendMessage(ERROR_REQUEST_JOIN_YOU_HAVE_GUILD);
                    return;
                }

                case SUCCESS:{
                    hc.sendMessage(requestJoinSuccess);
                    afterJoinGuild(guild, mem, hc);

                    Hero hero = hc.getHero();
                    String iEventId = logService.getPartyAddMemberProcessor()
                            .newEventID(hero.getID());
                    logService.getPartyAddMemberProcessor().addLogEvent(
                            hero.getOperatorId(), iEventId, hero.getServerId(),
                            hero.getUin(), hero.getUserId(), hero.getName(), 0,
                            guild.nameString, guild.getFlagLevel(),
                            guild.getGiftMoney(), hero.getName());
                }
            }
            return;
        }

        // 看下玩家有没有发过申请
        if (guild.hasRequestJoin(mem.heroID)){
            hc.sendMessage(ERROR_REQUEST_JOIN_ALREADY_APPLIED);
            return;
        }

        // 不是自动接受请求的
        GuildMember leader = guild.getLeader();
        if (leader != null && leader.isOnline()){
            leader.sendMessage(receiveJoinRequest(mem.id, hc.getHero()
                    .getRace().getId(), hc.getHero().getLevel(),
                    mem.heroNameBytes));
            guild.markRequestedJoin(mem.heroID);
            hc.sendMessage(requestJoinSuccessWaitOtherReply);
            return;
        }

        // 副帮主
        leader = guild.getViceLeader();
        if (leader != null && leader.isOnline()){
            leader.sendMessage(receiveJoinRequest(mem.id, hc.getHero()
                    .getRace().getId(), hc.getHero().getLevel(),
                    mem.heroNameBytes));
            guild.markRequestedJoin(mem.heroID);
            hc.sendMessage(requestJoinSuccessWaitOtherReply);
            return;
        }

        // 都不在线
        hc.sendMessage(ERROR_REQUEST_JOIN_LEADER_NOT_ONLINE);
    }

    // ---- 入帮 ----
    private enum AddMemberResult{
        HERO_HAVE_GUILD, GUILD_FULL, SUCCESS;
    }

    private AddMemberResult tryAddMemberToGuild(Guild guild, GuildMember member){
        synchronized (guild){
            if (!member.setGuildWhenNull(guild)){
                return AddMemberResult.HERO_HAVE_GUILD;
            }

            if (!guild.addWhenUnderMaxSize(member)){
                member.setGuildWhenSame(guild, null);
                return AddMemberResult.GUILD_FULL;
            }

            guildMembers.put(member.id, member);
            return AddMemberResult.SUCCESS;
        }
    }

    /**
     * 统一处理加入了帮派之后的逻辑和消息.
     * 必须是已加入guild.members列表并且已经设置了guildMember.guild的
     * @param guild
     * @param mem
     */
    private void afterJoinGuild(Guild guild, GuildMember mem, HeroController hc){
        assert mem.getGuild() == guild;
        assert guild.containsMember(mem.id);

        long ctime = timeService.getCurrentTime();
        mem.setEnterGuildTime(ctime);

        invalidGuildInfoCache(guild);
        guild.broadcast(otherJoinGuild(mem.heroNameBytes), mem.id);
        mem.sendMessage(youJoinGuild(guild));
        hc.notifyGuildChanged(guild.name, guild.isWsCityMaster(),
                guild.isLongCityMaster(), guild.isTerritoryMaster());

        guild.addNews(GuildNews.newMember(ctime, mem.id, mem.heroNameBytes)); // 加到帮派见闻中

    }

    // ---- end of 入帮 ----

    private void onGetSelfGuildInfo(ChannelBuffer buffer, HeroController hc){
        GuildMember mem = hc.getGuildMember();
        final Guild g = mem.getGuild();
        if (g == null){
            hc.sendMessage(ERROR_GET_SELF_GUILD_INFO_NO_GUILD);
            return;
        }

        ChannelBuffer msg = guildInfoMsgCache.getIfPresent(g);
        if (msg != null){
            hc.sendMessage(msg);
            return;
        }

        final ISender sender = hc.getSender();

        threadService.getDbExecutor().execute(new Runnable(){
            @Override
            public void run(){
                ChannelBuffer msg;
                try{
                    msg = guildInfoMsgCache.getUnchecked(g);
                } catch (Throwable ex){
                    logger.error(
                            "GuildModule.onGetSelfGuildInfo.guildInfoMsgCache.getUnchecked出错",
                            ex);
                    sender.sendMessage(ERROR_GET_SELF_GUILD_INFO_INTERNAL_ERROR);
                    return;
                }
                sender.sendMessage(msg);
            }
        });
    }

    private void onGetGuildList(ChannelBuffer buffer, HeroController hc){
        final Guild key = GUILD_LIST_KEY[hc.getServerData().sequence];

        ChannelBuffer msg = guildInfoMsgCache.getIfPresent(key);
        if (msg != null){
            hc.sendMessage(msg);
            return;
        }

        final BooleanHolder isOffline = hc.getIsOffline();
        final ISender sender = hc.getSender();

        threadService.getDbExecutor().execute(new Runnable(){
            @Override
            public void run(){
                if (isOffline.get()){
                    return;
                }
                ChannelBuffer msg = guildInfoMsgCache.getUnchecked(key);
                sender.sendMessage(msg);
            }
        });
    }

    private void onCreateGuild(ChannelBuffer buffer, HeroController hc){
        GuildMember guildMember = hc.getGuildMember();

        // 检查英雄是否有帮派
        if (guildMember.hasGuild()){
            hc.sendMessage(ERROR_CREATE_GUILD_YOU_HAVE_GUILD);
            return;
        }

        // 检查英雄等级
        if (hc.getHero().getLevel() < VariableConfig.GUILD_CREATE_LEVEL_LIMIT){
            hc.sendMessage(ERROR_CREATE_GUILD_NOT_ENOUGH_LEVEL);
            return;
        }

        // 检查钱
        boolean useMoney = BufferUtil.readBoolean(buffer);
        if (useMoney){
            if (!hc.getHeroMiscModule().hasEnoughMoney(
                    variableConfig.GUILD_CREATE_MONEY_REQUEST)){
                hc.sendMessage(ERROR_CREATE_GUILD_NOT_ENOUGH_MONEY);
                return; // 这是要赌一块钱吗(原来这里没有return)
            }
        } else{
            if (!hc.getHeroMiscModule().hasEnoughYuanbao(
                    variableConfig.GUILD_CREATE_YUANBAO_REQUEST)){
                hc.sendMessage(ERROR_CREATE_GUILD_NOT_ENOUGH_MONEY);
                return;
            }
        }

        // 检查帮派名
        byte[] guildName = BufferUtil.readUTFBytes(buffer, 30);
        int guildNameLen = Utils.getStringLength(guildName);
        if (guildNameLen < 4 || guildNameLen > 14){
            hc.sendMessage(ERROR_CREATE_GUILD_ILLEGAL_GUILD_NAME);
            return;
        }
        String guildNameString = StringEncoder.encode(guildName);
        if (!Utils.isValidName(guildNameString)){
            hc.sendMessage(ERROR_CREATE_GUILD_ILLEGAL_GUILD_NAME);
            return;
        }

        // 检查帮旗名
        byte[] flagName = BufferUtil.readUTFBytes(buffer, 30);
        int flagNameLen = Utils.getStringLength(flagName);
        if (flagNameLen < 4 || flagNameLen > 12){
            hc.sendMessage(ERROR_CREATE_GUILD_ILLEGAL_FLAG_NAME);
            return;
        }
        String flagNameString = StringEncoder.encode(flagName);
        if (!Utils.isValidName(flagNameString)){
            hc.sendMessage(ERROR_CREATE_GUILD_ILLEGAL_FLAG_NAME);
            return;
        }

        // 检查帮旗种类
        int flagKind = buffer.readUnsignedByte();
        if (isIllegalFlagKind(flagKind)){
            hc.sendMessage(ERROR_CREATE_GUILD_ILLEGAL_FLAG_KIND);
            return;
        }

        int serverID = IDUtils.getServerID(hc.combinedID);
        byte[] quBytes = Utils.getServerIDBytes(serverID);

        // 检查名字是否存在
        byte[] actualFlagName = padQuInfo(flagName, quBytes);
        if (flagNames.containsKey(actualFlagName)){
            hc.sendMessage(ERROR_CREATE_GUILD_FLAG_NAME_EXISTED);
            return;
        }

        byte[] actualGuildName = padQuInfo(guildName, quBytes);
        if (guilds.containsKey(actualGuildName)){
            hc.sendMessage(ERROR_CREATE_GUILD_GUILD_NAME_EXISTED);
            return;
        }

        final long ctime = timeService.getCurrentTime();
        Guild g = new Guild(hc.getServerData(), hc.getServerData().operatorID,
                serverID, actualGuildName, actualFlagName, flagKind,
                guildMember, ctime, flagDatas.getLevel(1),
                contributionGoodsShop, challengeDungeonCount);
        // 设帮派成功
        if (guilds.putIfAbsent(actualGuildName, g) == null){
            // 帮派名字成功
            if (flagNames.putIfAbsent(actualFlagName, Empty.DUMB_OBJECT) == null){
                // 将玩家的帮派设置为这个新的帮
                AddMemberResult result = tryAddMemberToGuild(g, guildMember);
                switch (result){
                    case GUILD_FULL:{
                        logger.error("GuildModule.onCreateGuild.tryAddMemberToGuild时, 返回GUILD_FULL???");
                        // 设置失败
                        guilds.remove(actualGuildName);
                        flagNames.remove(actualFlagName);
                        hc.sendMessage(ERROR_CREATE_GUILD_YOU_HAVE_GUILD);
                        return;
                    }

                    case HERO_HAVE_GUILD:{
                        // 设置失败
                        guilds.remove(actualGuildName);
                        flagNames.remove(actualFlagName);
                        hc.sendMessage(ERROR_CREATE_GUILD_YOU_HAVE_GUILD);
                        return;
                    }

                    case SUCCESS:{
                        guildMember.setEnterGuildTime(ctime);

                        Hero hero = hc.getHero();
                        String iEventId = logService.getPartyBuildProcessor()
                                .newEventID(hero.getID());

                        // 扣钱
                        if (useMoney){
                            hc.getHeroMiscModule().reduceMoneyAnyway(
                                    variableConfig.GUILD_CREATE_MONEY_REQUEST,
                                    GUILD_CREATE, iEventId);
                        } else{
                            hc.getHeroMiscModule()
                                    .reduceYuanbaoAnyway(
                                            variableConfig.GUILD_CREATE_YUANBAO_REQUEST,
                                            GUILD_CREATE, iEventId);
                        }

                        hc.sendMessage(createGuildSuccess(actualGuildName,
                                actualFlagName, flagKind));

                        hc.notifyGuildChanged(actualGuildName, false, false,
                                false);

                        invalidGuildListCache();

                        worldService
                                .broadcastToEnteredFirstSceneHeroWithSameServerData(
                                        newGuildCreatedBroadcast(hc.getID(), hc
                                                .getHero().getNameBytes(),
                                                actualGuildName), hc
                                                .getServerData(), 0);

                        logService.getPartyBuildProcessor().addLogEvent(
                                hero.getOperatorId(), iEventId,
                                hero.getServerId(), hero.getUin(),
                                hero.getUserId(), hero.getName(), 0,
                                g.nameString, g.getFlagLevel(),
                                g.getGiftMoney());
                    }
                }
                return;
            } else{
                // 设帮旗失败
                guilds.remove(actualGuildName);
                hc.sendMessage(ERROR_CREATE_GUILD_FLAG_NAME_EXISTED);
            }
        } else{
            // 帮派名字失败
            hc.sendMessage(ERROR_CREATE_GUILD_GUILD_NAME_EXISTED);
        }
    }

    // -------- 普通方法 ----------
    /**
     * 英雄上线时, 获取自己的GuildMember对象. 如果已经在帮派中, 返回guildMembers里的对象
     * @param heroID
     * @param hero
     * @param sender
     * @return
     */
    public GuildMember getGuildMemberOrCreateNew(HeroID heroID, Hero hero,
            IDroppableSender sender){
        GuildMember result = guildMembers.get(hero.getID());
        if (result == null){
            result = new GuildMember(heroID, hero, sender); // 不需要放入map中, 里面只放有帮派的人
        } else{
            result.setModel(hero.getModel());
            result.setSender(sender);
        }

        return result;
    }

    public GuildMember getGuildMember(long id){
        return guildMembers.get(id);
    }

    private byte[] padQuInfo(byte[] name, byte[] quBytes){
        return new ByteArrayBuilder(2 + name.length + quBytes.length)
                .appendSingleByte((byte) 's').append(quBytes)
                .appendSingleByte((byte) '.').append(name).array();
    }

    private void invalidGuildInfoCache(Guild guild){
        guildInfoMsgCache.invalidate(guild);
    }

    private void invalidGuildListCache(){
        for (Guild g : GUILD_LIST_KEY){
            guildInfoMsgCache.invalidate(g);
        }
    }

    public void updatePerDay(){
        logger.debug("更新帮派每日活跃度");
        for (Guild g : guilds.values()){
            try{
                updateGuildPerDay(g);
            } catch (Throwable ex){
                logger.error("GuildModule.updatePerDay出错", ex);
            }
        }
    }

    private void updateGuildPerDay(Guild g){
        g.clearContributionGoodsCount();

        int newDismissLevel = g.updateDismissWarningLevel();
        if (newDismissLevel >= VariableConfig.GUILD_DISMISS_LEVEL_LIMIT){
            // 解散
            final List<GuildMember> guildMembers;
            synchronized (g){
                if (!guilds.containsKey(g.name)){
                    return;
                }
                // 没有被帮主手动解散
                guildMembers = doDismissGuild(g);
            }

            invalidGuildListCache();
            worldService.broadcast(guildDismissedLowActivity(g.name));
            guildRelationManager.onGuildDismissed(g);

            if (guildMembers != null && guildMembers.size() > 0){

                final List<Long> offlineHeroIDs = new ArrayList<>();
                for (GuildMember gm : guildMembers){
                    if (!gm.isOnline()){
                        offlineHeroIDs.add(gm.id);
                    }
                }

                if (offlineHeroIDs.size() > 0){
                    viewOtherHeroCache.removeCache(offlineHeroIDs);
                }
            }

            if (g.getTerritoryWinCount() > 0){
                territoryMasterInfo.onGuildDismissed(g);
            }

        } else if (newDismissLevel >= VariableConfig.GUILD_DISMISS_WARNING_DAYS){
            g.broadcast(lowActivityWarning(VariableConfig.GUILD_DISMISS_LEVEL_LIMIT
                    - newDismissLevel));

            // 加入到帮派见闻
            long ctime = timeService.getCurrentTime();
            g.addNews(GuildNews.lowActivity(ctime,
                    VariableConfig.GUILD_DISMISS_LEVEL_LIMIT - newDismissLevel));
        }
    }

    // ---- s&l ----

    private final OneThreadJob saveJob = new OneThreadJob(){

        @Override
        protected void doRun(){
            save();
        }
    };

    /**
     * 从db中获取数据
     * @throws Throwable
     */
    private void loadDataFromDB() throws Throwable{
        byte[] data = dbService.loadGlobalData(DBService.KEY_GUILD);

        if (data != null && data.length > 0){
            data = Utils.snappyUncompress(data);

            AllGuildProto allGuildProto = AllGuildProto.parseFrom(data);
            for (GuildProto proto : allGuildProto.getGuildList()){
                final Guild guild;

                try{
                    guild = Guild.decode(proto, flagDatas,
                            contributionGoodsShop, challengeDungeonCount,
                            timeService, individualServerConfig);
                } catch (IllegalArgumentException ar){
                    // 区服没找到, 跳过
                    continue;
                }

                guilds.put(guild.name, guild);
                flagNames.put(guild.getFlagName().toByteArray(),
                        Empty.DUMB_OBJECT);

                for (GuildMember member : guild.members.values()){
                    guildMembers.put(member.id, member);
                }
            }

            // 设置盟帮和敌对帮派
            for (GuildProto proto : allGuildProto.getGuildList()){
                Guild g = guilds.get(proto.getGuildName().toByteArray());
                if (g == null){
                    logger.error("开服要设置盟帮时, 竟然没找到guildProto中的帮派...??");
                    continue;
                }

                for (ByteString friend : proto.getFriendGuildList()){
                    Guild f = guilds.get(friend.toByteArray());
                    if (f == null){
                        logger.error("开服要设置盟帮时, 竟然没有找到盟帮...");
                        continue;
                    }

                    g.addFriendGuild(f);
                    f.addFriendGuild(g);
                }

                for (ByteString enemy : proto.getEnemyGuildList()){
                    Guild e = guilds.get(enemy.toByteArray());
                    if (e == null){
                        logger.error("开服要设置敌帮时, 竟然没有找到敌帮...");
                        continue;
                    }

                    g.addEnemyGuild(e);
                }

                // 被加敌帮
                for (ByteString addedEnemyNotNotified : proto
                        .getBeenAddedEnemyNotNotifiedList()){
                    Guild e = guilds.get(addedEnemyNotNotified.toByteArray());
                    if (e == null){
                        logger.error("开服要设置未提醒的被加敌帮, 竟然没有找到帮派");
                        continue;
                    }

                    g.addBeenAddedEnemyHaveNotNotified(e);
                }

                // 被删敌帮
                for (ByteString removedEnemyNotNotified : proto
                        .getBeenRemovedEnemyNotNotifiedList()){
                    Guild e = guilds.get(removedEnemyNotNotified.toByteArray());
                    if (e == null){
                        logger.error("开服要设置未提醒的被删敌帮, 竟然没有找到帮派");
                        continue;
                    }

                    g.addBeenRemovedEnemyHaveNotNotified(e);
                }

                // 被删友帮
                for (ByteString removedFriendNotNotified : proto
                        .getBeenRemovedFriendNotNotifiedList()){
                    Guild e = guilds
                            .get(removedFriendNotNotified.toByteArray());
                    if (e == null){
                        logger.error("开服要设置未提醒的被删友帮, 竟然没有找到帮派");
                        continue;
                    }

                    g.addBeenRemovedFriendHaveNotNotified(e);
                }
            }
        }
    }

    public void save(){
        try{
            AllGuildProto.Builder allGuildBuilder = AllGuildProto.newBuilder();
            for (Guild g : guilds.values()){
                if (!g.isGMCreated)
                    allGuildBuilder.addGuild(g
                            .encode4Server(contributionGoodsShop));
            }

            byte[] data = Utils.snappyCompress(allGuildBuilder.build()
                    .toByteArray());

            boolean success = dbService.saveGlobalData(DBService.KEY_GUILD,
                    data);
            if (!success){
                logger.error("GuildModule.save.dbService.saveGuildData返回false, 重试");
                success = dbService.saveGlobalData(DBService.KEY_GUILD, data);
                if (success){
                    logger.error("GuildModule.save.dbService.saveGuildData重试成功");
                } else{
                    logger.error("GuildModule.save.dbService.saveGuildData重试还是失败, 放弃");
                }
            }
        } catch (Throwable ex){
            logger.error("GuildModule.save出错", ex);
        }
    }

    // ------ 详细信息loader ------

    private static final Comparator<LongCountHolder<Guild>> comp = new Comparator<LongCountHolder<Guild>>(){

        @Override
        public int compare(LongCountHolder<Guild> o1, LongCountHolder<Guild> o2){

            // 总战斗力大的在前
            if (o2.getValue() != o1.getValue()){
                return o2.getValue() > o1.getValue() ? 1 : -1;
            }

            return 0;
        }
    };

    class GuildInfoMsgLoader extends CacheLoader<Guild, ChannelBuffer>{

        private final Collection<Guild> guildsCollection;

        GuildInfoMsgLoader(Collection<Guild> guilds){
            this.guildsCollection = guilds;
        }

        @Override
        public ChannelBuffer load(Guild key) throws Exception{
            if (key.serverID == -1){

                // 请求帮派列表
                return replyGuildList(encodeGuildList(key.serverData));
            }

            return replySelfGuildInfo(key.encode4Client());
        }

        private ClientGuildListProto encodeGuildList(ServerData serverData){

            int count = guildsCollection.size();
            // 一个家伙都没有
            if (count == 0){
                return ClientGuildListProto.getDefaultInstance();
            }

            // 小于200个
            if (count <= 200){

                ClientGuildListProto.Builder builder = ClientGuildListProto
                        .newBuilder();
                for (Guild g : guildsCollection){
                    builder.addGuild(g.encodeToGuildList());
                }

                return builder.build();
            }

            Guild[] guildArray = guildsCollection.toArray(Guild.EMPTY_ARRAY);

            // 大于200个，本盟200个，外盟200个
            LongCountHolder<Guild>[] array = LongCountHolder
                    .newArray(guildArray.length);

            for (int i = 0; i < array.length; i++){
                array[i] = new LongCountHolder<Guild>(guildArray[i],
                        guildArray[i].getTotalFightAmountIfNotZero());
            }

            Arrays.sort(array, comp);

            ClientGuildListProto.Builder builder = ClientGuildListProto
                    .newBuilder();
            int selfUnionCount = 0;
            int otherUnionCount = 0;
            for (int i = 0; i < array.length; i++){
                Guild g = array[i].getKey();
                if (g.serverData == serverData){
                    // 本盟
                    if (selfUnionCount >= 200){
                        if (otherUnionCount >= 200){
                            break;
                        }
                        continue;
                    }

                    ++selfUnionCount;
                } else{
                    // 外盟
                    if (otherUnionCount >= 200){
                        if (selfUnionCount >= 200){
                            break;
                        }
                        continue;
                    }

                    ++otherUnionCount;
                }

                builder.addGuild(g.encodeToGuildList());
            }

            return builder.build();
        }
    }

    // ------ 帮派新闻 loader -----

    static class GuildNewsMsgLoader extends CacheLoader<Guild, ChannelBuffer>{

        @Override
        public ChannelBuffer load(Guild key) throws Exception{
            ClientNewsProto proto = key.encodeNews4Client();
            return replyNews(proto);
        }

    }

    // --- gm ---

    public Guild gmCreateGuild(HeroController hc, Hero randomHero,
            byte[] actualGuildName, byte[] actualFlagName){

        GuildMember guildMember = getGuildMemberOrCreateNew(new HeroID(
                randomHero.getID()), randomHero, null);
        final long ctime = timeService.getCurrentTime();
        Guild g = new Guild(hc.getServerData(), hc.getServerData().operatorID,
                hc.getHero().getServerId(), actualGuildName, actualFlagName, 0,
                guildMember, ctime, flagDatas.getLevel(1),
                contributionGoodsShop, challengeDungeonCount);

        g.isGMCreated = true;
        // 设帮派成功
        if (guilds.putIfAbsent(actualGuildName, g) == null){
            // 帮派名字成功
            if (flagNames.putIfAbsent(actualFlagName, Empty.DUMB_OBJECT) == null){
                // 将玩家的帮派设置为这个新的帮
                tryAddMemberToGuild(g, guildMember);
            }
        }

        return g;
    }

    public GuildMember gmAddHeroToGuild(Guild g, Hero hero,
            IDroppableSender sender){
        GuildMember guildMember = getGuildMemberOrCreateNew(
                new HeroID(hero.getID()), hero, sender);
        AddMemberResult result = tryAddMemberToGuild(g, guildMember);
        if (result == AddMemberResult.SUCCESS){

            long ctime = timeService.getCurrentTime();
            guildMember.setEnterGuildTime(ctime);

            invalidGuildInfoCache(g);
            g.broadcast(otherJoinGuild(guildMember.heroNameBytes),
                    guildMember.id);
            guildMember.sendMessage(youJoinGuild(g));

            g.addNews(GuildNews.newMember(ctime, guildMember.id,
                    guildMember.heroNameBytes)); // 加到帮派见闻中

            String iEventId = logService.getPartyAddMemberProcessor()
                    .newEventID(hero.getID());
            logService.getPartyAddMemberProcessor().addLogEvent(
                    hero.getOperatorId(), iEventId, hero.getServerId(),
                    hero.getUin(), hero.getUserId(), hero.getName(), 0,
                    g.nameString, g.getFlagLevel(), g.getGiftMoney(),
                    hero.getName());
        }

        return guildMember;
    }

}
