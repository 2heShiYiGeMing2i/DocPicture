package app.game.module;

import static com.mokylin.sink.util.BufferUtil.*;

import org.jboss.netty.buffer.ChannelBuffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.module.MiscModule.DisconnectReason;
import app.game.service.WorldService;

import com.google.inject.Inject;

/**
 * @author Liwei
 *
 */
public class GMDoingModule{

    private static final Logger logger = LoggerFactory
            .getLogger(GMDoingModule.class);
    public static final int MODULE_ID = Modules.GM_DOING_MODULE_ID;

    /**
     * GM账号设置/解除
     * bool true表示英雄被设置为GM，false表示英雄被取消GM
     */
    static final int S2C_SET_GM = 0;

    public static final ChannelBuffer SET_GM_TRUE = onlySendHeadAndABoolBytes(
            MODULE_ID, S2C_SET_GM, true);

    public static final ChannelBuffer SET_GM_FALSE = onlySendHeadAndABoolBytes(
            MODULE_ID, S2C_SET_GM, false);

    /**
     * GM操作，禁言/解除禁言/封号
     * varint64 英雄id
     * varint32 操作类型，1-禁言 2-解禁 3-封号 
     */
    static final int C2S_GM_DOING = 1;

    /**
     * GM操作，禁言/解除禁言/封号成功
     * varint32 操作类型，1-禁言 2-解禁 3-封号
     * varint64 英雄id
     * bytes 英雄名字
     */
    static final int S2C_GM_DOING = 2;

    static ChannelBuffer getGmDoing(int type, long heroId, byte[] heroName){
        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID, S2C_GM_DOING,
                computeVarInt32Size(type) + computeVarInt64Size(heroId)
                        + heroName.length);

        writeVarInt32(buffer, type);
        writeVarInt64(buffer, heroId);
        buffer.writeBytes(heroName);

        return buffer;
    }

    /**
     * GM操作失败，附带byte错误码
     * 1、你操作的对象是你自己，或者是别的GM
     * 2、目标当前不在线
     */
    static final int S2C_GM_DOING_FAIL = 3;

    static final ChannelBuffer ERR_GM_DOING_OTHER_GM = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_GM_DOING_FAIL, 1);

    static final ChannelBuffer ERR_GM_DOING_TARGET_OFFLINE = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_GM_DOING_FAIL, 2);

    private final WorldService worldService;

    @Inject
    GMDoingModule(WorldService worldService){
        this.worldService = worldService;
    }

    void onMessage(int sequenceID, ChannelBuffer buffer, HeroController hc){
        if (!hc.getHero().isGm){
            logger.warn("不是GM，收到GMDoing模块消息");
//            hc.disconnect(DisconnectReason.SEND_GM_MSG);
            return;
        }

        switch (sequenceID){
            case C2S_GM_DOING:{
                onGMDoing(buffer, hc);
                return;
            }
            default:{
                logger.warn("收到未知的GMDoing模块消息: {}", sequenceID);
                return;
            }
        }
    }

    private void onGMDoing(ChannelBuffer buffer, HeroController hc){

        long targetId = readVarInt64(buffer);

        ConnectedUser user = worldService.getUser(targetId);
        if (user == null){
            hc.sendMessage(ERR_GM_DOING_TARGET_OFFLINE);
            return;
        }

        HeroController target = user.getHeroController();
        if (target == null){
            hc.sendMessage(ERR_GM_DOING_TARGET_OFFLINE);
            return;
        }

        if (target.getHero().isGm){
            hc.sendMessage(ERR_GM_DOING_OTHER_GM);
            return;
        }

        int type = readVarInt32(buffer);
        if (type >= 1 && type <= 3){
            user.setGmCommand(new GMCommand(hc.getID(), hc.getHero().getName(),
                    type));
        }

        hc.sendMessage(getGmDoing(type, targetId, target.getHero()
                .getNameBytes()));
    }

    public static class GMCommand{

        public final long gmId;

        public final String gmName;

        public final int type;

        private GMCommand(long gmId, String gmName, int type){
            super();
            this.gmId = gmId;
            this.gmName = gmName;
            this.type = type;
        }

    }
}
