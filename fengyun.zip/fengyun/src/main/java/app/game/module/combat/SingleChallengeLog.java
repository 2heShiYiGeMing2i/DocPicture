package app.game.module.combat;

import static com.mokylin.sink.util.BufferUtil.*;

import org.jboss.netty.buffer.ChannelBuffer;

/**
 * @author Liwei
 *
 */
public class SingleChallengeLog{

    public static final SingleChallengeLog[] EMPTY_ARRAY = new SingleChallengeLog[0];

    public final long selfId;

    public final long targetId;

    public final byte[] targetName;

    public final int result;

    public final long logTime;

    public SingleChallengeLog(long selfId, long targetId, byte[] targetName,
            int result, long logTime){
        super();
        this.selfId = selfId;
        this.targetId = targetId;
        this.targetName = targetName;
        this.result = result;
        this.logTime = logTime;
    }

    int getWriteLen(){
        return computeVarInt64Size(logTime) + computeVarInt32Size(result)
                + computeVarInt64Size(targetId) + 2 + targetName.length;
    }

    void writeTo(ChannelBuffer buffer){
        writeVarInt64(buffer, logTime);
        writeVarInt32(buffer, result);
        writeVarInt64(buffer, targetId);
        writeUTF(buffer, targetName);
    }
}
