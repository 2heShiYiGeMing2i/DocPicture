package app.game.module.dbrank;

import java.util.concurrent.LinkedTransferQueue;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.service.DBService;

import com.google.inject.Inject;
import com.mokylin.collection.IntValueLongConcurrentHashMap;
import com.mokylin.collection.LongConcurrentSynchronizedHashMap;
import com.mokylin.collection.ReusableIterator;

public class DBRankQueue{
    private static final Logger logger = LoggerFactory
            .getLogger(DBRankQueue.class);

    /**
     * 有变化, 要改变的对象
     */
    private final LongConcurrentSynchronizedHashMap<DBRankObject> toUpdate;

    /**
     * 要加入到表中的
     */
    private final LinkedTransferQueue<DBRankObject> toAdd;

    private final IntValueLongConcurrentHashMap admireMap;

    private final DBService dbService;

    private transient final ReusableIterator<DBRankObject> toUpdateIte;

    @Inject
    DBRankQueue(DBService dbService){
        this.dbService = dbService;

        this.toUpdate = new LongConcurrentSynchronizedHashMap<>(1024);
        this.toAdd = new LinkedTransferQueue<>();
        this.toUpdateIte = toUpdate.newValueIterator();

        this.admireMap = new IntValueLongConcurrentHashMap();
    }

    public void save(int[][] totalMap){
        try{
            dbService.updateRankObject(toAdd, toUpdateIte, admireMap, totalMap);
            toUpdate.clear();
            admireMap.clear();
        } catch (Throwable ex){
            logger.error("DBRankQueue.flush 时出错", ex);
        }
    }

    void addAdmire(long id){
        this.admireMap.increment(id);
    }

    void update(DBRankObject obj){
        this.toUpdate.putIfAbsent(obj.combineID, obj);
    }

    void add(DBRankObject obj){
        this.toAdd.add(obj);
    }

}
