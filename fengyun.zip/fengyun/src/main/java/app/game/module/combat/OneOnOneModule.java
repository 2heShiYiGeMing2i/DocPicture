package app.game.module.combat;

import static app.game.module.combat.OneOnOneMessages.*;
import static com.mokylin.sink.util.BufferUtil.*;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;

import org.jboss.netty.buffer.ChannelBuffer;
import org.joda.time.DateTime;
import org.joda.time.DateTimeConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.data.HeroForViewCache;
import app.game.data.Prize;
import app.game.data.SpriteStat;
import app.game.data.fight.FightPosDiffData;
import app.game.data.fight.FightPosDiffDatas;
import app.game.data.fight.FightRefinedStats;
import app.game.data.fight.OneOnOneDatas;
import app.game.entity.Hero;
import app.game.module.HeroController;
import app.game.module.scene.FightData;
import app.game.module.scene.HeroFightModule;
import app.game.module.scene.IScene;
import app.game.module.scene.NormalScene;
import app.game.service.DBService;
import app.game.service.IThreadService;
import app.game.service.TimeService;
import app.game.service.WorldService;
import app.message.ISender;
import app.protobuf.HeroContent.ChallengeResultProto;
import app.protobuf.HeroServerContent.OneOnOneServerConfig;
import app.protobuf.LogContent.LogEnum;
import app.protobuf.LogContent.LogEnum.TransportType;
import app.utils.VariableConfig;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.google.common.collect.Lists;
import com.google.inject.Inject;
import com.google.protobuf.ByteString;
import com.lmax.disruptor.EventFactory;
import com.lmax.disruptor.InsufficientCapacityException;
import com.mokylin.collection.LeftLongPair;
import com.mokylin.collection.LongConcurrentHashMap;
import com.mokylin.collection.ReusableIterator;
import com.mokylin.sink.util.BufferUtil;
import com.mokylin.sink.util.RandomNumber;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.concurrent.RingBufferEvent;
import com.mokylin.sink.util.concurrent.RingBufferWrapper;

/**
 * @author Liwei
 *
 */
public class OneOnOneModule{

    private static final Logger logger = LoggerFactory
            .getLogger(OneOnOneModule.class);

    private final ExecutorService exec;

    private final DBService dbService;

    private final IThreadService threadService;

    private final TimeService timeService;

    private final WorldService worldService;

    private final FightRefinedStats refinedStats;

    private final FightPosDiffDatas diffDatas;

    private final VariableConfig config;

    private static final int challengeListCount = VariableConfig.ONE_ON_ONE_CHALLENGE_LIST_COUNT;

    private final LongConcurrentHashMap<RankObject> rankMap;

    private final CopyOnWriteArrayList<RankObject> rankList;

    private final RingBufferWrapper<ChallengeLogEvent> challengeLogEventBuffer;

    private final LoadingCache<FightPosDiffData, ChannelBuffer> previewListMsgCache;

    private final LoadingCache<Long, HeroOneOnOneData> heroDataCache;

    private final ChannelBuffer[] resetDailyPosMsgs;

    private final LongConcurrentHashMap<LeftLongPair<SingleChallengeLog>> challengeLogMap;

    @Inject
    OneOnOneModule(DBService dbService, IThreadService threadService,
            final TimeService timeService, WorldService worldService,
            OneOnOneDatas datas, VariableConfig config,
            HeroForViewCache heroCache) throws Throwable{
        this.dbService = dbService;
        this.threadService = threadService;
        this.timeService = timeService;
        this.worldService = worldService;
        this.refinedStats = datas.getRefinedStats();
        this.diffDatas = datas.getDiffDatas();
        this.config = config;

        rankMap = new LongConcurrentHashMap<>();
        rankList = new CopyOnWriteArrayList<>();

        challengeLogMap = new LongConcurrentHashMap<>();

        previewListMsgCache = CacheBuilder.newBuilder().concurrencyLevel(8)
                .expireAfterWrite(8, TimeUnit.SECONDS)
                .build(new PreviewListMsgLoader());

        heroDataCache = CacheBuilder.newBuilder().concurrencyLevel(8)
                .expireAfterWrite(8, TimeUnit.SECONDS)
                .build(new HeroDataLoader());

        challengeLogEventBuffer = new RingBufferWrapper<ChallengeLogEvent>(
                ChallengeLogEvent.FACTORY, 4096, true);

        OneOnOneServerConfig serverConfig = loadConfig();
        if (serverConfig != null){
            for (int i = 0; i < serverConfig.getIdCount(); i++){
                long heroId = serverConfig.getId(i);
                if (rankMap.get(heroId) == null){
                    RankObject ro = new RankObject(heroId);
                    rankMap.put(heroId, ro);
                    rankList.add(ro);
                    ro.currentPos = rankList.size();

                    if (i < serverConfig.getDailyPosCount()){
                        ro.dailyPos = Math.max(serverConfig.getDailyPos(i), 0);
                    }
                }
            }
        }

        resetDailyPosMsgs = new ChannelBuffer[Math.min(
                Math.max(1000, rankList.size()), 5000)];
        for (int i = 0; i < resetDailyPosMsgs.length; i++){
            resetDailyPosMsgs[i] = getResetDailyPosMsg(i + 1);
        }

        // 将挑战日志刷到数据库
        ChallengeLogUpdater updater = new ChallengeLogUpdater(dbService,
                challengeLogEventBuffer);
        threadService.getScheduledExecutorService().scheduleAtFixedRate(
                updater, 1, 1, TimeUnit.SECONDS);

        long ctime = timeService.getCurrentTime();
        // 定时给奖励
        DateTime time = new DateTime(ctime);
        int hour = time.getHourOfDay();

        long initialDelay = time.withTimeAtStartOfDay().getMillis()
                + ((hour + 1) * DateTimeConstants.MILLIS_PER_HOUR) - ctime;

        threadService.getScheduledExecutorService().scheduleAtFixedRate(
                new ChallengeRankRunner(hour), initialDelay,
                DateTimeConstants.MILLIS_PER_HOUR, TimeUnit.MILLISECONDS);

        // disruptor
        exec = Executors.newSingleThreadExecutor(new ThreadFactory(){
            @Override
            public Thread newThread(Runnable r){
                return new Thread(r, "FENG_YUN_JUE_THREAD");
            }
        });

        // 每10分钟保存一次数据
        threadService.getScheduledExecutorService().scheduleAtFixedRate(
                new Runnable(){
                    @Override
                    public void run(){
                        addSaveEvent();
                    }
                }, 10, 10, TimeUnit.MINUTES);

        // 每分钟刷新一次缓存的日志数据
        threadService.getScheduledExecutorService().scheduleAtFixedRate(
                new Runnable(){

                    private final ReusableIterator<LeftLongPair<SingleChallengeLog>> challengeLogIter = challengeLogMap
                            .newValueIterator();

                    @Override
                    public void run(){

                        long ctime = timeService.getCurrentTime();
                        for (challengeLogIter.rewind(); challengeLogIter
                                .hasNext();){
                            LeftLongPair<SingleChallengeLog> pair = challengeLogIter
                                    .next();

                            if (pair.left < ctime){
                                challengeLogIter.remove();
                            }
                        }
                    }
                }, 1, 1, TimeUnit.MINUTES);
    }

    private OneOnOneServerConfig loadConfig(){
        try{
            byte[] data = dbService
                    .loadGlobalData(DBService.KEY_ONE_VS_ONE_CONFIG);

            if (data != null && data.length > 0){
                return OneOnOneServerConfig.parseFrom(data);
            }
        } catch (Throwable e){
            logger.error("个人竞技场数据加载出错", e);
        }

        return null;
    }

    private void save(){

        try{
            OneOnOneServerConfig.Builder builder = OneOnOneServerConfig
                    .newBuilder();

            for (RankObject rankObj : rankList){
                if (rankObj != null){
                    builder.addId(rankObj.heroId);
                    builder.addDailyPos(rankObj.dailyPos);
                }
            }

            byte[] data = builder.build().toByteArray();
            if (data != null && data.length > 0){
                dbService.saveGlobalData(DBService.KEY_ONE_VS_ONE_CONFIG, data);
            }
        } catch (Throwable ex){
            logger.error("个人竞技场数据保存出错", ex);
        }
    }

    private class ChallengeRankRunner implements Runnable{

        private static final int maxHour = 24;

        private int hour;

        private ChallengeRankRunner(int hour){
            this.hour = hour;
        }

        @Override
        public void run(){
            ++hour;

            if (hour >= maxHour){
                hour = 0;
            }

            addRankHeroEvent(hour == 0);
        }
    }

    public void shutdown(){
        exec.shutdown();
        try{
            exec.awaitTermination(Long.MAX_VALUE, TimeUnit.DAYS);
        } catch (InterruptedException e){
            e.printStackTrace();
        }

        dbService.processChallengeLogEvents(challengeLogEventBuffer);

        // 最后保存一次到数据库
        save();
    }

    public void onMessage(int sequenceID, ChannelBuffer buffer,
            HeroController hc){

        switch (sequenceID){
            case C2S_GET_CHALLENGE_LIST:{
                onGetChallengeList(hc, buffer);
                return;
            }
            case C2S_DO_CHALLENGE:{
                onDoChallenge(hc, buffer);
                return;
            }
            case C2S_GET_SELF_CHALLENGE:{
                onGetSelfChallengeData(hc, buffer);
                return;
            }
            case C2S_GET_CHALLENGE_LOG:{
                onGetChallengeLog(hc, buffer);
                return;
            }
            case C2S_ADD_CHALLENGE_TIMES:{
                onAddChallengeTimes(hc, buffer);
                return;
            }
            case C2S_ADD_CHALLENGE_REFINED_TIMES:{
                onAddChallengeRefinedTimes(hc, buffer);
                return;
            }
            case C2S_RESET_COOL_DOWN:{
                onResetChallengeCooldown(hc, buffer);
                return;
            }
            case C2S_COLLECT_DAILY_PRIZE:{
                onCollectDailyPrize(hc, buffer);
                return;
            }
            case C2S_GET_PREVIEW_LIST:{
                onGetPreviewList(hc, buffer);
                return;
            }
            case C2S_GET_HOURLY_ACC_PRIZE:{
                onGetHourlyAccPrize(hc, buffer);
                return;
            }
            default:{
                logger.error("OneOnOneModule模块收到未知消息: {}", sequenceID);
            }
        }
    }

    private void onGetHourlyAccPrize(HeroController hc, ChannelBuffer buffer){

        if (hc.getHero().getWelfare().hourlyAccPrize == null){
            hc.sendMessage(EMPTY_HOURLY_ACC_PRIZE_MSG);
        } else{
            hc.sendMessage(getHourlyAccPrizeMsg(hc.getHero().getWelfare().hourlyAccPrize
                    .encode4Client()));
        }
    }

    private void onGetPreviewList(HeroController hc, ChannelBuffer buffer){

        RankObject rankObj = rankMap.get(hc.getID());
        if (rankObj == null){
            logger.warn("个人竞技场预览列表，但是英雄还未开放");
            hc.sendMessage(ERR_GET_PREVIEW_LIST_FAIL_NOT_OPEN);
            return;
        }

        int startPos = BufferUtil.readVarInt32(buffer);
        final FightPosDiffData data = diffDatas.get(startPos);
        if (startPos != data.startPos || data.endPos == Integer.MAX_VALUE){
            logger.warn("个人竞技场预览列表，无效的位置");
            hc.sendMessage(ERR_GET_PREVIEW_LIST_FAIL_INVALID_START_POS);
            return;
        }

        if (data.startPos > rankList.size()){
            hc.sendMessage(EMPTY_PREVIEW_LIST_MSG);
            return;
        }

        ChannelBuffer msg = previewListMsgCache.getIfPresent(data);
        if (msg != null){
            hc.sendMessage(msg);
            return;
        }

        final ISender sender = hc.getSender();
        threadService.getDbExecutor().execute(new Runnable(){
            @Override
            public void run(){
                ChannelBuffer msg;
                try{
                    msg = previewListMsgCache.getUnchecked(data);
                } catch (Throwable ex){
                    logger.error(
                            "OneOnOneModule.onGetPreviewList(...).new Runnable() {...}.run",
                            ex);
                    sender.sendMessage(ERR_GET_PREVIEW_LIST_FAIL_INTERNAL_ERROR);
                    return;
                }
                sender.sendMessage(msg);
            }
        });
    }

    private void onGetChallengeList(HeroController hc, ChannelBuffer buffer){

        final RankObject rankObj = rankMap.get(hc.getID());

        if (rankObj == null){
            logger.warn("个人竞技场获取挑战列表，但是英雄还未开放");
            return;
        }

        final ISender sender = hc.getSender();
        threadService.getDbExecutor().execute(new Runnable(){
            @Override
            public void run(){
                try{
                    processGetChallengeList(rankObj, sender);
                } catch (Throwable e){
                    logger.error(
                            "OneOnOneModule.onGetChallengeList(...).new Runnable() {...}.run",
                            e);
                }
            }
        });
    }

    private void processGetChallengeList(RankObject rankObj, ISender sender){
        ChannelBuffer buffer = getChallengeListBuffer();

        int size = rankList.size();
        int pos = rankObj.currentPos;

        writeVarInt32(buffer, pos);
        if (size <= 4 || (pos > 0 && pos <= 4)){
            // 前4名的，只找前3个人
            for (int i = 0; i < 3; i++){
                if (pos == i + 1){
                    continue;
                }

                RankObject ro = getRankObject(i);
                if (ro == null){
                    break;
                }

                HeroOneOnOneData data = heroDataCache.getUnchecked(ro.heroId);
                if (data != null){
                    data.writeHeroData(i + 1, buffer);
                }
            }
        } else if (size <= challengeListCount
                || (pos > 0 && pos <= challengeListCount)){
            // 前7名的，只找前7个人

            int c = challengeListCount - 1;
            for (int i = 0; i < challengeListCount; i++){
                if (pos == i + 1){
                    continue;
                }

                RankObject ro = getRankObject(i);
                if (ro == null){
                    break;
                }

                HeroOneOnOneData data = heroDataCache.getUnchecked(ro.heroId);
                if (data != null){
                    data.writeHeroData(i + 1, buffer);
                }

                if (--c <= 0){
                    break;
                }
            }
        } else{
            // 超过7名的，按照排名差跳着选

            // 这里少选3个，有前3名
            int c = challengeListCount - 4;

            FightPosDiffData diffData;
            int startPos;
            if (pos <= 0 || pos > size){
                diffData = diffDatas.get(size);
                startPos = size - diffData.diffPos * (c - 1);
            } else{
                diffData = diffDatas.get(pos);
                startPos = pos - diffData.diffPos * c;
            }

            for (int i = 0; i < 3; i++){
                RankObject ro = getRankObject(i);
                if (ro == null){
                    break;
                }

                HeroOneOnOneData data = heroDataCache.getUnchecked(ro.heroId);
                if (data != null){
                    data.writeHeroData(i + 1, buffer);
                }
            }

            startPos = Math.max(startPos, 4); // 防御性
            for (int i = 0; i < c; i++){
                int p = startPos + i * diffData.diffPos;

                RankObject ro = getRankObject(p);
                if (ro == null){
                    break;
                }

                HeroOneOnOneData data = heroDataCache.getUnchecked(ro.heroId);
                if (data != null){
                    data.writeHeroData(p, buffer);
                }
            }
        }

        sender.sendMessage(buffer);
    }

    private RankObject getRankObject(int i){

        if (i < rankList.size()){
            return rankList.get(i);
        }

        return null;
    }

    private void onDoChallenge(HeroController hc, ChannelBuffer buffer){

        Hero hero = hc.getHero();

        RankObject rankObj = rankMap.get(hc.getID());
        if (rankObj == null){
            logger.warn("个人竞技场挑战，但是英雄还未开放");
            hc.sendMessage(ERR_CHALLENGE_FAIL_NOT_OPEN);
            return;
        }

        HeroFightModule hfm = hc.getHeroFightModule();
        if (hfm.challengeResult != null){
            logger.warn("个人竞技场挑战，前一次挑战还未处理完");
            hc.sendMessage(ERR_CHALLENGE_FAIL_CHALLENGING);
            return;
        }

        int canChallengeTimes = Math.max(
                VariableConfig.ONE_ON_ONE_CHALLENGE_MAX_TIMES
                        + hero.challengeAddTimes - hero.challengeTimes, 0);

        if (canChallengeTimes <= 0){
            logger.warn("个人竞技场挑战，但是挑战次数已用完");
            hc.sendMessage(ERR_CHALLENGE_FAIL_NOT_CHALLENGE_TIMES);
            return;
        }

        long ctime = timeService.getCurrentTime();
        if (ctime < hero.nextCanChallengeTime){
            if (hero.hasChallengeFatigue){
                logger.warn("个人竞技场挑战，疲劳CD中");
                hc.sendMessage(ERR_CHALLENGE_FAIL_COOLDOWN);
                return;
            }
        }

        int challengePos = BufferUtil.readVarInt32(buffer);

        int size = rankList.size();
        if (challengePos <= 0 || challengePos > size){
            logger.warn("个人竞技场挑战，挑战的位置无效, {}", challengePos);
            hc.sendMessage(ERR_CHALLENGE_FAIL_INVALID_POS);
            return;
        }

        int selfPos = rankObj.currentPos;
        if (selfPos == challengePos){
            logger.warn("个人竞技场挑战，挑战的人是自己");
            hc.sendMessage(ERR_CHALLENGE_FAIL_CHALLENGE_SELF);
            return;
        }

        if (selfPos > 0 && selfPos <= challengeListCount){
            if (challengePos <= 0 || challengePos > challengeListCount){
                logger.warn("个人竞技场挑战，前7名不能挑战7名之后的人");
                hc.sendMessage(ERR_CHALLENGE_FAIL_LESS_TOP7);
                return;
            }
        } else{
            if (selfPos != 0 && selfPos < challengePos){
                logger.warn("个人竞技场挑战，7名以后的人不能挑战比自己低的人");
                hc.sendMessage(ERR_CHALLENGE_FAIL_LESS_SELF);
                return;
            }
        }

        // 普通场景
        IScene parent = hc.getHeroFightModule().getParent();
        if (!hc.getHeroFightModule().hasEnteredScene()
                || !(parent instanceof NormalScene)){
            logger.warn("个人竞技场挑战，英雄不在普通场景中");
            hc.sendMessage(ERR_CHALLENGE_FAIL_NOT_IN_NORMAL_SCENE);
            return;
        }

        // 可以挑战了，+cd，加次数

        hero.challengeTimes += 1;
        if (ctime < hero.nextCanChallengeTime){
            hero.nextCanChallengeTime += VariableConfig.ONE_ON_ONE_CD_PER;
        } else{
            hero.nextCanChallengeTime = ctime
                    + VariableConfig.ONE_ON_ONE_CD_PER;
        }

        hero.hasChallengeFatigue = hero.nextCanChallengeTime >= ctime
                + VariableConfig.ONE_ON_ONE_FATIGUE_TIME;

        // 用第一个bit表示是否疲劳
        if (((hero.nextCanChallengeTime & 1) == 0) == hero.hasChallengeFatigue){
            hero.nextCanChallengeTime += 1;
        }

        // 英雄移出场景
        int pos = hc.getHeroFightModule().getTraceTargetPoint();
        hc.getHeroFightModule().doChangeScene(parent, Utils.getHighShort(pos),
                Utils.getLowShort(pos), TransportType.ONE_ON_ONE);

        hc.sendMessage(getDoChallengeMsg(canChallengeTimes - 1,
                hero.nextCanChallengeTime));

        hfm.challengeResult = new ChallengeResult(ctime);

        // 加到RingBuffer中处理
        addChallengeEvent(hc, rankObj, challengePos, ctime);
    }

    private void onGetSelfChallengeData(HeroController hc, ChannelBuffer buffer){

        Hero hero = hc.getHero();

        final RankObject rankObj = rankMap.get(hc.getID());
        if (rankObj == null){
            return;
        }

        int canChallengeTimes = Math.max(
                VariableConfig.ONE_ON_ONE_CHALLENGE_MAX_TIMES
                        + hero.challengeAddTimes - hero.challengeTimes, 0);

        long cooldown = hero.nextCanChallengeTime;
        if (cooldown > 0){
            // 用第一个bit表示是否疲劳
            if (((cooldown & 1) == 0) == hero.hasChallengeFatigue){
                cooldown += 1;
            }
        }

        int refinedFightingAmount = 0;
        if (hero.getChallengeRefinedTimes() > 0){
            SpriteStat extraStat = refinedStats.get(hero
                    .getChallengeRefinedTimes());
            SpriteStat baseStat = hero.getFightData().getBaseStat();
            SpriteStat totalStat = baseStat.calculateTotalStat(extraStat);

            refinedFightingAmount = Math.max(
                    FightData.calculateFightingAmount(totalStat)
                            - FightData.calculateFightingAmount(baseStat), 0);
        }

        hc.sendMessage(getSelfChanllenge(canChallengeTimes, cooldown,
                hero.getChallengeRefinedTimes(), refinedFightingAmount,
                rankObj.dailyPos, hero.hasCollectedChallengeDailyPrize));

        // 首条日志
        processGetFirstChallengeLog(hc);

        // 挑战列表
        final ISender sender = hc.getSender();
        threadService.getDbExecutor().execute(new Runnable(){
            @Override
            public void run(){
                try{
                    processGetChallengeList(rankObj, sender);
                } catch (Throwable e){
                    logger.error(
                            "OneOnOneModule.onGetSelfChallengeData(...).new Runnable() {...}.run",
                            e);
                }
            }
        });
    }

    private void onGetChallengeLog(HeroController hc, ChannelBuffer buffer){
        RankObject rankObj = rankMap.get(hc.getID());
        if (rankObj == null){
            return;
        }

        if (hc.singleFightLogProcessed){
            return;
        }

        hc.singleFightLogProcessed = true;

        doSendChallengeLogs(hc);
    }

    private void processGetFirstChallengeLog(HeroController hc){

        LeftLongPair<SingleChallengeLog> pair = challengeLogMap.get(hc.getID());
        if (pair != null){
            SingleChallengeLog log = pair.right;
            if (log != null){
                hc.sendMessage(getFirstFightLogMsg(log));
            } else{
                hc.sendMessage(EMPTY_FIRST_FIGHT_LOG);
            }
        } else{
            doSendChallengeLogs(hc);
        }

    }

    private void doSendChallengeLogs(final HeroController hc){
        threadService.getDbExecutor().execute(new Runnable(){
            @Override
            public void run(){
                hc.singleFightLogProcessed = true;

                List<SingleChallengeLog> logList = dbService
                        .getChallengeLogs(hc.getID());

                hc.sendMessage(getFightLogMsg(logList));

                SingleChallengeLog log = null;
                if (logList.size() > 0){
                    log = logList.get(0);
                }

                challengeLogMap.putIfAbsent(
                        hc.getID(),
                        new LeftLongPair<SingleChallengeLog>(timeService
                                .getCurrentTime() + 60000, log));
            }
        });
    }

    private void onAddChallengeTimes(HeroController hc, ChannelBuffer buffer){
        Hero hero = hc.getHero();

        RankObject rankObj = rankMap.get(hc.getID());
        if (rankObj == null){
            logger.warn("个人竞技场加次数，但是英雄还未开放");
            hc.sendMessage(ERR_ADD_TIMES_FAIL_NOT_OPEN);
            return;
        }

        int canChallengeTimes = Math.max(
                VariableConfig.ONE_ON_ONE_CHALLENGE_MAX_TIMES
                        + hero.challengeAddTimes - hero.challengeTimes, 0);

        if (canChallengeTimes >= VariableConfig.ONE_ON_ONE_CHALLENGE_MAX_TIMES){
            logger.warn("个人竞技场加次数，但是挑战次数已满");
            hc.sendMessage(ERR_ADD_TIMES_FAIL_FULL_TIMES);
            return;
        }

        if (!hc.getHeroMiscModule().tryReduceBindedYuanbaoOrYuanbao(
                config.ONE_ON_ONE_ADD_CHALLENGE_TIMES_COST,
                LogEnum.OperateType.ONE_ON_ONE_ADD_CHALLENGE_TIMES, null)){
            logger.warn("个人竞技场加次数，元宝不足");
            hc.sendMessage(ERR_ADD_TIMES_FAIL_YUANBAO_NOT_ENOUGH);
            return;
        }

        hero.challengeAddTimes += 1;
        hc.sendMessage(addChallengeTimesMsg(canChallengeTimes + 1));
    }

    private void onAddChallengeRefinedTimes(HeroController hc,
            ChannelBuffer buffer){
        Hero hero = hc.getHero();

        RankObject rankObj = rankMap.get(hc.getID());
        if (rankObj == null){
            logger.warn("个人竞技场鼓舞，但是英雄还未开放");
            hc.sendMessage(ERR_ADD_CHALLENGE_REFINED_TIMES_FAIL_NOT_OPEN);
            return;
        }

        if (hero.getChallengeRefinedTimes() >= refinedStats.size()){
            logger.warn("个人竞技场鼓舞，但是挑战次数已满");
            hc.sendMessage(ERR_ADD_CHALLENGE_REFINED_TIMES_FAIL_FULL_TIMES);
            return;
        }

        if (!hc.getHeroMiscModule().reduceLijin(
                config.ONE_ON_ONE_REFINED_LIJIN_COST,
                LogEnum.OperateType.ONE_ON_ONE_ADD_CHALLENGE_REFINED_TIMES,
                null)){
            if (!hc.getHeroMiscModule().tryReduceBindedYuanbaoOrYuanbao(
                    config.ONE_ON_ONE_REFINED_YUANBAO_COST,
                    LogEnum.OperateType.ONE_ON_ONE_ADD_CHALLENGE_REFINED_TIMES,
                    null)){
                logger.warn("个人竞技场鼓舞，钱不足");
                hc.sendMessage(ERR_ADD_CHALLENGE_REFINED_TIMES_FAIL_MONEY_NOT_ENOUGH);
                return;
            }
        }

        if (!refinedStats.tryRate(hero.getChallengeRefinedTimes())){
            // 鼓舞失败
            hc.sendMessage(REFINED_FAIL_MSG);
            return;
        }

        hero.incremnetChallengeRefinedTimes();
        SpriteStat extraStat = refinedStats
                .get(hero.getChallengeRefinedTimes());
        SpriteStat baseStat = hero.getFightData().getBaseStat();
        SpriteStat totalStat = baseStat.calculateTotalStat(extraStat);

        int refinedFightingAmount = Math.max(
                FightData.calculateFightingAmount(totalStat)
                        - FightData.calculateFightingAmount(baseStat), 0);

        hc.sendMessage(addChallengeRefinedTimesMsg(
                hero.getChallengeRefinedTimes(), refinedFightingAmount));
    }

    private void onResetChallengeCooldown(HeroController hc,
            ChannelBuffer buffer){
        Hero hero = hc.getHero();

        RankObject rankObj = rankMap.get(hc.getID());
        if (rankObj == null){
            logger.warn("个人竞技场重置CD，但是英雄还未开放");
            hc.sendMessage(ERR_RESET_COOL_DOWN_FAIL_NOT_OPEN);
            return;
        }

        long ctime = timeService.getCurrentTime();

        if (hero.nextCanChallengeTime <= ctime){
            logger.warn("个人竞技场重置CD，当前没有CD");
            hc.sendMessage(ERR_RESET_COOL_DOWN_FAIL_NOT_COOL_DOWN);
            return;
        }

        // 1分钟1元宝
        int quantity = Utils.divide((hero.nextCanChallengeTime - ctime),
                DateTimeConstants.MILLIS_PER_MINUTE);

        int cost = Utils.multiplyMoney(config.ONE_ON_ONE_RESET_COOLDOWN_COST,
                quantity);

        if (!hc.getHeroMiscModule().tryReduceBindedYuanbaoOrYuanbao(cost,
                LogEnum.OperateType.ONE_ON_ONE_RESET_COOLDOWN, null)){
            logger.warn("个人竞技场重置CD，钱不够");
            hc.sendMessage(ERR_RESET_COOL_DOWN_FAIL_YUANBAO_NOT_ENOUGH);
            return;
        }

        hero.nextCanChallengeTime = 0;
        hc.sendMessage(RESET_COOL_DOWN_MSG);
    }

    private void onCollectDailyPrize(HeroController hc, ChannelBuffer buffer){
        Hero hero = hc.getHero();

        RankObject rankObj = rankMap.get(hc.getID());
        if (rankObj == null){
            logger.warn("个人竞技场领取每日奖励，但是英雄还未开放");
            hc.sendMessage(ERR_COLLECT_DAILY_PRIZE_FAIL_NOT_OPEN);
            return;
        }

        if (hero.hasCollectedChallengeDailyPrize){
            logger.warn("个人竞技场领取每日奖励，但是今日已经领取完了");
            hc.sendMessage(ERR_COLLECT_DAILY_PRIZE_FAIL_COLLECTED);
            return;
        }
        hero.hasCollectedChallengeDailyPrize = true;

        FightPosDiffData diffData = diffDatas.get(rankObj.dailyPos);
        diffData.dailyPrize.giveIgnoreGoods(hc.getHeroMiscModule(), hero,
                false, LogEnum.OperateType.ONE_ON_ONE_DAILY_PRIZE, null);

        hc.sendMessage(COLLECT_DAILY_PRIZE_MSG);
    }

    // ---------- end of message ----------

    public void onHeroUnlockFunc(long heroId){
        RankObject rankObj = rankMap.get(heroId);
        if (rankObj != null){
            return;
        }

        rankObj = new RankObject(heroId);
        if (rankMap.putIfAbsent(heroId, rankObj) == null){
            final RankObject ro = rankObj;
            exec.execute(new Runnable(){
                @Override
                public void run(){
                    try{
                        addHero(ro);
                    } catch (Throwable e){
                        logger.error("OneOnOneModule.onHeroUnlockFunc()", e);
                    }
                }
            });
        }
    }

    private void addChallengeEvent(final HeroController hc,
            final RankObject rankObj, final int challengePos, final long time){

        exec.execute(new Runnable(){
            @Override
            public void run(){
                try{
                    onChallenge(hc, rankObj, challengePos, time);
                } catch (Throwable e){
                    logger.error("OneOnOneModule.addChallengeEvent()", e);
                }
            }
        });
    }

    public void gmResetPrize(boolean initDailyPos){
        addRankHeroEvent(initDailyPos);
    }

    private void addRankHeroEvent(final boolean initDailyPos){
        exec.execute(new Runnable(){
            @Override
            public void run(){
                try{
                    onRankHero(initDailyPos);
                } catch (Throwable e){
                    logger.error("OneOnOneModule.addRankHeroEvent()", e);
                }
            }
        });
    }

    private void addSaveEvent(){
        exec.execute(new Runnable(){
            @Override
            public void run(){
                try{
                    save();
                } catch (Throwable e){
                    logger.error("OneOnOneModule.addSaveEvent()", e);
                }
            }
        });
    }

    private void onRankHero(boolean initDailyPos){

        int size = rankList.size();

        FightPosDiffData diffData = null;
        for (int i = 0; i < size; i++){
            RankObject rankObj = getRankObject(i);

            if (rankObj == null){
                continue;
            }

            int pos = i + 1;
            if (diffData == null || !diffData.isInRange(pos)){
                diffData = diffDatas.get(pos);
            }

            HeroController hc = worldService.getHeroController(rankObj.heroId);
            if (hc != null){
                HeroFightModule hfm = hc.getHeroFightModule();
                hfm.challengeHourlyPrize = diffData.hourlyPrize;
            }

            if (initDailyPos){
                rankObj.dailyPos = pos;

                if (hc != null){
                    if (i < resetDailyPosMsgs.length){
                        hc.sendMessage(resetDailyPosMsgs[i]);
                    } else{
                        hc.sendMessage(getResetDailyPosMsg(i + 1));
                    }
                }
            }
        }
    }

    private void addHero(RankObject rankObj){

        rankList.add(rankObj);
        rankObj.currentPos = rankList.size();
    }

    private void onChallenge(HeroController hc, RankObject selfObj,
            int challengePos, long ctime){

        try{
            HeroFightModule hfm = hc.getHeroFightModule();

            ChallengeResult result = hfm.challengeResult;
            if (result == null){
                logger.error("个人竞技场挑战，但是result == null，过期了？");
                hc.sendMessage(CHALLENGE_INTERNAL_ERROR_MSG);
                return;
            }

            // 检查英雄自己的位置是否正确
            int size = rankList.size();
            if (selfObj.currentPos != 0){
                if (selfObj.currentPos <= 0 || selfObj.currentPos > size){
                    logger.error("英雄的排位无效，重排英雄位置, pos:{}", selfObj.currentPos);

                    selfObj.currentPos = 0;
                    tryRebuild();

                    hc.sendMessage(CHALLENGE_INTERNAL_ERROR_MSG);
                    return;
                }

                if (selfObj != getRankObject(selfObj.currentPos - 1)){
                    logger.error("英雄的排位上的位置不是英雄自己，重排英雄位置, pos:{}",
                            selfObj.currentPos);

                    selfObj.currentPos = 0;
                    tryRebuild();

                    hc.sendMessage(CHALLENGE_INTERNAL_ERROR_MSG);
                    return;
                }
            }

            if (challengePos <= 0 || challengePos > size){
                logger.error("挑战位置无效, pos:{} size:{}", challengePos, size);
                hc.sendMessage(CHALLENGE_INTERNAL_ERROR_MSG);
                return;
            }

            if (selfObj.currentPos == challengePos){
                logger.warn("挑战的英雄是自己");
                hc.sendMessage(ERR_CHALLENGE_FAIL_CHALLENGE_SELF);
                return;
            }

            // 检查目标英雄是否合法
            RankObject targetObj = getRankObject(challengePos - 1);
            if (targetObj == null){
                logger.error("个人竞技场挑战，但是找不到挑战的人");
                tryRebuild();

                hc.sendMessage(CHALLENGE_INTERNAL_ERROR_MSG);
                return;
            }

            if (selfObj == targetObj){
                logger.error("onChallenge selfMember == targetMember");
                tryRebuild();

                hc.sendMessage(ERR_CHALLENGE_FAIL_CHALLENGE_SELF);
                return;
            }

            HeroOneOnOneData targetData = heroDataCache
                    .getUnchecked(targetObj.heroId);
            if (targetData == null){
                logger.error("挑战目标英雄不存在，{}", targetObj.heroId);
                hc.sendMessage(CHALLENGE_INTERNAL_ERROR_MSG);
                return;
            }

            SpriteStat selfStat = getTotalStat(hc.getHero(), ctime);
            SpriteStat targetStat = targetData.totalStat;

            // 到这里自己和目标都已经是正常的了
            boolean isWin = calculateFightResult(selfStat, targetStat, hc
                    .getHero().getLevel(), targetData.level);

            boolean hasChangePos = isWin
                    && (selfObj.currentPos == 0 || selfObj.currentPos > challengePos);
            if (hasChangePos){
                // 交换位置
                targetObj.currentPos = selfObj.currentPos;
                selfObj.currentPos = challengePos;

                rankList.set(challengePos - 1, selfObj);
                if (targetObj.currentPos > 0){
                    rankList.set(targetObj.currentPos - 1, targetObj);
                }
            }

            // 让被挑战人知道
            int targetResult = combineFightResult(true, !isWin, hasChangePos,
                    targetObj.currentPos);
            // 目标日志
            SingleChallengeLog targetLog = new SingleChallengeLog(
                    targetObj.heroId, hc.getID(), hc.getHero().getNameBytes(),
                    targetResult, ctime);
            HeroController targetController = worldService
                    .getHeroController(targetObj.heroId);
            if (targetController != null){
                targetController.sendMessage(addFightLogMsg(targetLog)); // 发送消息
            }
            challengeLogMap.put(targetLog.selfId,
                    new LeftLongPair<SingleChallengeLog>(ctime + 60000,
                            targetLog)); // 缓存最后一条日志
            addChallengeLogEvent(targetLog); // save日志

            // 英雄自己的日志
            int selfResult = combineFightResult(false, isWin, hasChangePos,
                    selfObj.currentPos);
            SingleChallengeLog selfLog = new SingleChallengeLog(selfObj.heroId,
                    targetData.id, targetData.name, selfResult, ctime);
            challengeLogMap
                    .put(selfLog.selfId, new LeftLongPair<SingleChallengeLog>(
                            ctime + 60000, selfLog)); // 缓存最后一条日志
            addChallengeLogEvent(selfLog);
            // 发消息让客户端打架
            playMovie(hc, selfResult, targetData);

            // 给奖励，设置一下，由英雄线程去刷
            FightPosDiffData diffData = diffDatas.get(selfObj.currentPos);

            result.challengePrize = isWin ? diffData.challengeWinPrize
                    : diffData.challengeLosePrize;
            result.hasProcessed = true;

            // 第一名改变广播
            if (hasChangePos && selfObj.currentPos == 1 && challengePos == 1){
                worldService.broadcast(getTopOneChanged(hc.getID(), hc
                        .getHero().getNameBytes()));
            }

        } catch (Throwable e){
            logger.error("OneOnOneModule.onChallenge", e);
            hc.sendMessage(CHALLENGE_INTERNAL_ERROR_MSG);
        }
    }

    private SpriteStat getTotalStat(Hero hero, long ctime){
        SpriteStat baseStat = hero.getFightData().getBaseStat();

        int challengeRefinedTimes = hero.getChallengeRefinedTimes(ctime);
        if (challengeRefinedTimes > 0){
            SpriteStat extraStat = refinedStats.get(challengeRefinedTimes);
            return baseStat.calculateTotalStat(extraStat);
        }
        return baseStat;
    }

    private void playMovie(HeroController hc, int result,
            HeroOneOnOneData targetHero){
        ChallengeResultProto.Builder builder = ChallengeResultProto
                .newBuilder();

        builder.setResult(result);
        builder.setId(targetHero.id);
        builder.setName(targetHero.nameString);
        builder.setRace(targetHero.race);
        builder.setEquipmentResource(targetHero.equipmentResource);
        builder.setTotalStat(targetHero.totalStat.encode());
        builder.setLevel(targetHero.level);

        for (int spellType : targetHero.spellTypes){
            builder.addSpellTypes(spellType);
        }

        hc.sendMessage(playMovieMsg(builder.build()));
    }

    private int combineFightResult(boolean isPass, boolean isWin,
            boolean hasChangePos, int newPos){

        int p = newPos << 3;

        if (isPass){
            p |= 1; // 1
        }

        if (isWin){
            p |= 2; // 10
        }

        if (hasChangePos){
            p |= 4; // 100
        }

        return p;
    }

    private final float HIT_COEFFICIENT = 0.2f;
    private final float HIT_MIN_COEFFICIENT = 1 - HIT_COEFFICIENT;
    private final float HIT_MAX_COEFFICIENT = 1 + HIT_COEFFICIENT;

    private final float CRIT_COEFFICIENT = 0.2f;
    private final float CRIT_MIN_COEFFICIENT = 1 - CRIT_COEFFICIENT;
    private final float CRIT_MAX_COEFFICIENT = 1 + CRIT_COEFFICIENT;

    private boolean calculateFightResult(SpriteStat selfStat,
            SpriteStat targetStat, int selfLevel, int targetLevel){

        // 自己
        float selfHit = calculateHit(selfStat.hit, targetStat.dodge,
                targetLevel - selfLevel);
        float selfCrit = calculateCrit(selfStat.crit, targetStat.antiCrit);

        float selfMinHit = selfHit * HIT_MIN_COEFFICIENT;
        float selfMaxHit = Math.min(selfHit * HIT_MAX_COEFFICIENT, 1);

        float selfMinCrit = selfCrit * CRIT_MIN_COEFFICIENT;
        float selfMaxCrit = Math.min(selfCrit * CRIT_MAX_COEFFICIENT, 1);

        float selfBaseAttack = Math.max(selfStat.attack * 0.1f,
                (selfStat.attack - targetStat.defence) / 2);

        int selfMinDps = (int) (selfBaseAttack * selfMinHit * (1.5f * selfMinCrit + 1 - selfMinCrit));
        int selfMaxDps = (int) (selfBaseAttack * selfMaxHit * (1.5f * selfMaxCrit + 1 - selfMaxCrit));

        int selfDps = Math.max(
                selfMinDps + RandomNumber.getRate(selfMaxDps - selfMinDps), 1);

        int selfTimes = targetStat.maxLife / selfDps;

        // 目标英雄
        float targetHit = calculateHit(targetStat.hit, selfStat.dodge,
                selfLevel - targetLevel);
        float targetCrit = calculateCrit(targetStat.crit, selfStat.antiCrit);

        float targetMinHit = targetHit * HIT_MIN_COEFFICIENT;
        float targetMaxHit = Math.min(targetHit * HIT_MAX_COEFFICIENT, 1);

        float targetMinCrit = targetCrit * CRIT_MIN_COEFFICIENT;
        float targetMaxCrit = Math.min(targetCrit * CRIT_MAX_COEFFICIENT, 1);

        float targetBaseAttack = Math.max(targetStat.attack * 0.1f,
                (targetStat.attack - selfStat.defence) / 2);

        int targetMinDps = (int) (targetBaseAttack * targetMinHit * (1.5f * targetMinCrit + 1 - targetMinCrit));
        int targetMaxDps = (int) (targetBaseAttack * targetMaxHit * (1.5f * targetMaxCrit + 1 - targetMaxCrit));

        int targetDps = Math.max(
                targetMinDps
                        + RandomNumber.getRate(targetMaxDps - targetMinDps), 1);

        int targetTimes = selfStat.maxLife / targetDps;

        // 攻击次数小的胜利，攻击次数一样则再随机一次
        if (selfTimes != targetTimes){
            return selfTimes < targetTimes;
        }

        return RandomNumber.getRate(100) < 50; // 0-49胜利 50-99失败
    }

    private static final int SPELL_HIT = 50;

    private static final int HIT_RATE_DENOMINATOR = 10000;

    private float calculateHit(int hit, int dodge, int levelDiff){

        int toAdd = Math.max(0, SPELL_HIT + HIT_RATE_DENOMINATOR + hit - dodge);

        int toRemove = levelDiff > 0 ? levelDiff * HIT_RATE_DENOMINATOR
                / (levelDiff + 30) : 0;

        float hitCoefficient = Math.max(
                Math.min(toAdd - toRemove, HIT_RATE_DENOMINATOR), SPELL_HIT);

        return (hitCoefficient / HIT_RATE_DENOMINATOR);
    }

    private static final int SPELL_CRIT = 50;

    private static final int CRIT_RATE_DENOMINATOR = 10000;

    private float calculateCrit(int crit, int antiCrit){

        float toAdd = Math.max(
                Math.min(SPELL_CRIT + crit - antiCrit, CRIT_RATE_DENOMINATOR),
                SPELL_CRIT);

        float critCoefficient = toAdd / CRIT_RATE_DENOMINATOR;

        return critCoefficient;
    }

    private void tryRebuild(){
        logger.error("个人竞技场排序出现问题，tryRebuild");

        List<RankObject> list = Lists.newArrayListWithCapacity(rankList.size());

        int size = rankList.size();
        for (int i = 0; i < size; i++){
            RankObject ro = getRankObject(i);
            if (ro != null){
                list.add(ro);
                ro.currentPos = list.size();
            }
        }

        rankList.clear();
        rankList.addAll(list);
    }

    private void addChallengeLogEvent(SingleChallengeLog log){
        try{
            long sequence = challengeLogEventBuffer.tryNext();
            try{
                ChallengeLogEvent event = challengeLogEventBuffer.get(sequence);
                event.log = log;
            } finally{
                challengeLogEventBuffer.publish(sequence);
            }
        } catch (InsufficientCapacityException ex){
            logger.error("ChallengeModule.addChallengeLogEvent满, 放弃");
        }
    }

    private static class RankObject{
        private final long heroId;

        private int currentPos;

        private int dailyPos;

        private RankObject(long heroId){
            this.heroId = heroId;
        }
    }

    private static class ChallengeLogUpdater implements Runnable{
        private final DBService dbService;
        private final RingBufferWrapper<ChallengeLogEvent> ringBuffer;

        private ChallengeLogUpdater(DBService dbService,
                RingBufferWrapper<ChallengeLogEvent> ringBuffer){
            this.dbService = dbService;
            this.ringBuffer = ringBuffer;
        }

        @Override
        public void run(){
            try{
                if (ringBuffer.hasEventsToHandle()){
                    dbService.processChallengeLogEvents(ringBuffer);
                }
            } catch (Throwable ex){
                logger.error("ChallengeLogUpdater.run出错", ex);
            }
        }
    }

    public static class ChallengeLogEvent implements RingBufferEvent{

        public static final EventFactory<ChallengeLogEvent> FACTORY = new EventFactory<ChallengeLogEvent>(){

            @Override
            public ChallengeLogEvent newInstance(){
                return new ChallengeLogEvent();
            }
        };

        public SingleChallengeLog log;

        @Override
        public void handle(){
            throw new UnsupportedOperationException();
        }

        @Override
        public void cleanUp(){
            log = null;
        }
    }

    class PreviewListMsgLoader extends
            CacheLoader<FightPosDiffData, ChannelBuffer>{

        PreviewListMsgLoader(){
        }

        @Override
        public ChannelBuffer load(FightPosDiffData key) throws Exception{

            if (key.startPos > rankList.size()){
                return EMPTY_PREVIEW_LIST_MSG;
            }

            ChannelBuffer buffer = getPreviewListBuffer();
            for (int i = key.startPos; i < key.endPos; i++){
                RankObject ro = getRankObject(i - 1);
                if (ro == null){
                    break;
                }

                HeroOneOnOneData data = heroDataCache.getUnchecked(ro.heroId);
                if (data != null){
                    data.writePreviewData(buffer);
                }
            }

            return buffer;
        }
    }

    public static class ChallengeResult{

        // 防止bug
        public final long expireTime;

        public volatile boolean hasProcessed;

        public Prize challengePrize;

        ChallengeResult(long ctime){
            expireTime = ctime + 10000; // 10秒超时
        }
    }

    class HeroDataLoader extends CacheLoader<Long, HeroOneOnOneData>{

        HeroDataLoader(){
        }

        @Override
        public HeroOneOnOneData load(Long key) throws Exception{

            long id = key;

            HeroController hc = worldService.getHeroController(id);
            if (hc != null){
                return newHeroOneOnOneData(hc.getHero(),
                        timeService.getCurrentTime());
            } else{
                Hero hero = dbService.getHeroForView(id);
                if (hero != null){
                    return newHeroOneOnOneData(hero,
                            timeService.getCurrentTime());
                }
            }

            logger.error("OneOnOneModule.HeroDataLoader.load 发现英雄不存在, {}", id);
            return null;
        }
    }

    public HeroOneOnOneData newHeroOneOnOneData(Hero hero, long ctime){
        return new HeroOneOnOneData(hero, getTotalStat(hero, ctime));
    }

    public static class HeroOneOnOneData{
        public final long id;

        public final byte[] name;

        public final ByteString nameString;

        public final int race;

        public final int equipmentResource;

        public final int level;

        public final int fightingAmount;

        public final SpriteStat baseStat;

        public final SpriteStat totalStat;

        public final int refinedFightingAmount;

        // 英雄会的技能列表
        public final int[] spellTypes;

        private HeroOneOnOneData(Hero hero, SpriteStat totalStat){
            super();
            this.id = hero.getID();
            this.name = hero.getNameBytes();
            this.nameString = hero.getNameByteString();
            this.race = hero.getRaceId();
            this.equipmentResource = hero
                    .getEquipmentResourcesWithBestMountBow();
            this.level = hero.getLevel();
            this.fightingAmount = hero.getFightingAmount();
            this.baseStat = hero.getFightData().getBaseStat();
            this.totalStat = totalStat;
            if (baseStat != totalStat){
                this.refinedFightingAmount = Math.max(
                        FightData.calculateFightingAmount(totalStat)
                                - FightData.calculateFightingAmount(baseStat),
                        0);
            } else{
                this.refinedFightingAmount = 0;
            }

            this.spellTypes = hero.getRace().getSpellType(level);
        }

        private void writeHeroData(int pos, ChannelBuffer buffer){
            writeVarInt32(buffer, pos);
            writeVarInt64(buffer, id);
            writeUTF(buffer, name);
            writeVarInt32(buffer, race);
            writeVarInt32(buffer, level);
            writeVarInt32(buffer, fightingAmount + refinedFightingAmount);
            writeVarInt32(buffer, equipmentResource);
        }

        private void writePreviewData(ChannelBuffer buffer){
            writeVarInt64(buffer, id);
            writeUTF(buffer, name);
            writeVarInt32(buffer, level);
            writeVarInt32(buffer, fightingAmount + refinedFightingAmount);
        }
    }
}
