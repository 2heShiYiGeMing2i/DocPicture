package app.game.module.auction;

import org.jboss.netty.buffer.ChannelBuffer;

import com.mokylin.sink.util.BufferUtil;

public abstract class AuctionItem{

    protected final long auctionID; // 日志里面, 这里就是事件
    protected final long heroID; // 日志里面, 这里就是对方的英雄id
    protected final byte[] heroName; // 日志里面, 这里就是对方的英雄名字

    protected final int cost;

    protected AuctionItem(long auctionID, long heroID, byte[] heroName, int cost){
        super();
        this.auctionID = auctionID;
        this.heroID = heroID;
        this.heroName = heroName;
        this.cost = cost;
    }

    /**
     * 写入物品信息
     * @param buffer
     */
    public abstract void writeGoods(ChannelBuffer buffer);

    public void writeGoodsWithoutHeroInfo(ChannelBuffer buffer){
        BufferUtil.writeVarInt64(buffer, auctionID);
        BufferUtil.writeVarInt32(buffer, cost);
        writeGoods(buffer);
    }

    public void writeGoodsWithHeroInfo(ChannelBuffer buffer){
        BufferUtil.writeVarInt64(buffer, heroID);
        BufferUtil.writeUTF(buffer, heroName);
        writeGoodsWithoutHeroInfo(buffer);
    }

    public void toJsonWithoutHeroInfo(ChannelBuffer buffer){
        BufferUtil.writeVarInt64(buffer, heroID);
        BufferUtil.writeUTF(buffer, heroName);
        writeGoodsWithoutHeroInfo(buffer);
    }

    public void toJsonWithHeroInfo(ChannelBuffer buffer){
        BufferUtil.writeVarInt64(buffer, heroID);
        BufferUtil.writeUTF(buffer, heroName);
        writeGoodsWithoutHeroInfo(buffer);
    }
}
