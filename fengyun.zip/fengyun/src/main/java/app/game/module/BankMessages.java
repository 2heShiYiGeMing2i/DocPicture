package app.game.module;

import static com.mokylin.sink.util.BufferUtil.*;

import java.util.Deque;
import java.util.concurrent.ConcurrentLinkedDeque;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.module.BankModule.BankGlobalLog;

/**
 * @author Liwei
 *
 */
public class BankMessages{

    public static final int MODULE_ID = Modules.BANK_MODULE_ID;

    private BankMessages(){
    }

    /**
     * 投资升级钱庄
     * varint32 投资元宝（必须大于0并且是100的倍数）
     */
    static final int C2S_UPGRADE_BANK_INVEST = 1;

    /**
     * 投资升级钱庄成功
     * varint32 总投资元宝
     */
    static final int S2C_UPGRADE_BANK_INVEST = 2;

    static ChannelBuffer investUpgradeBankMsg(int amount){
        return onlySendHeadAndAVarInt32Message(MODULE_ID,
                S2C_UPGRADE_BANK_INVEST, amount);
    }

    /**
     * 投资升级钱庄失败，附带byte错误码
     * 1、客户端发送的投资元宝无效（必须大于0并且是100的倍数）
     * 2、元宝不足
     * 3、超过最大投资额度
     */
    static final int S2C_UPGRADE_BANK_INVEST_FAIL = 3;

    static final ChannelBuffer UPGRADE_BANK_INVEST_FAIL_INVALID_AMOUNT = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_UPGRADE_BANK_INVEST_FAIL, 1);

    static final ChannelBuffer UPGRADE_BANK_INVEST_FAIL_YUANBAO_NOT_ENOUGH = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_UPGRADE_BANK_INVEST_FAIL, 2);

    static final ChannelBuffer UPGRADE_BANK_INVEST_FAIL_LARGE_THAN_MAX_QUOTA = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_UPGRADE_BANK_INVEST_FAIL, 3);

    /**
     * 领取升级钱庄收益
     * varint32 等级（0表示首日）
     */
    static final int C2S_COLLECT_UPGRADE_BANK_INCOME = 4;

    /**
     * 领取升级钱庄收益成功
     * varint32 等级（0表示首日）
     * varint32 已领取总礼金
     */
    static final int S2C_COLLECT_UPGRADE_BANK_INCOME = 5;

    static ChannelBuffer collectUpgradeBankIncome(int level, int lijin){
        return onlySendHeadAnd2VarInt32Message(MODULE_ID,
                S2C_COLLECT_UPGRADE_BANK_INCOME, level, lijin);
    }

    /**
     * 领取升级钱庄收益失败，附带byte错误码
     * 1、客户端发送的等级无效
     * 2、没有礼金可以领取（领取完了或者没有投资）
     * 3、英雄没有投资过升级钱庄
     * 4、礼金太多，请使用部分
     */
    static final int S2C_COLLECT_UPGRADE_BANK_INCOME_FAIL = 6;

    static final ChannelBuffer COLLECT_UPGRADE_BANK_INCOME_FAIL_INVALID_LEVEL = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_COLLECT_UPGRADE_BANK_INCOME_FAIL, 1);

    static final ChannelBuffer COLLECT_UPGRADE_BANK_INCOME_FAIL_NO_LIJIN = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_COLLECT_UPGRADE_BANK_INCOME_FAIL, 2);

    static final ChannelBuffer COLLECT_UPGRADE_BANK_INCOME_FAIL_NO_INVESTED = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_COLLECT_UPGRADE_BANK_INCOME_FAIL, 3);

    static final ChannelBuffer COLLECT_UPGRADE_BANK_INCOME_FAIL_TOO_MUCH = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_COLLECT_UPGRADE_BANK_INCOME_FAIL, 4);

    /**
     * 投资月卡钱庄，需要判断是否投资中/钱够不够
     */
    static final int C2S_INVEST_MONTHLY_BANK = 7;

    /**
     * 投资月卡钱庄成功，没有附带值
     * varint32 礼金基数
     * varint32 在线累计礼金
     * varint32 在线小时数
     * 
     * 客户端收到消息做下列处理:
     * 设置月卡钱庄投资额
     * 更新钱庄投资时间为当前时间
     * 将2个上次领取时间重置为0
     * 
     */
    static final int S2C_INVEST_MONTHLY_BANK = 8;

    static ChannelBuffer investMonthlyBank(int baseLijin, int onlineLijin,
            int onlineHour){
        return onlySendHeadAnd3VarInt32Message(MODULE_ID,
                S2C_INVEST_MONTHLY_BANK, baseLijin, onlineLijin, onlineHour);
    }

    /**
     * 投资月卡钱庄失败，附带byte错误码
     * 1、投资中（30天未结束）
     * 2、累计礼金未领取
     * 3、元宝不足
     */
    static final int S2C_INVEST_MONTHLY_BANK_FAIL = 9;

    static final ChannelBuffer INVEST_MONTHLY_BANK_FAIL_INVESTING = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_INVEST_MONTHLY_BANK_FAIL, 1);

    static final ChannelBuffer INVEST_MONTHLY_BANK_FAIL_LIJIN_NOT_COLLECTED = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_INVEST_MONTHLY_BANK_FAIL, 2);

    static final ChannelBuffer INVEST_MONTHLY_BANK_FAIL_YUANBAO_NOT_ENOUGH = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_INVEST_MONTHLY_BANK_FAIL, 3);

    /**
     * 领取月卡钱庄收益
     */
    static final int C2S_COLLECT_MONTHLY_BANK_INCOME = 10;

    /**
     * 领取月卡钱庄收益成功，没有附带值
     * 
     *  monthlyBankPrev2CollectTime = monthlyBankPrevCollectTime; // 更新上上次领取时间
     *  monthlyBankPrevCollectTime = ctime; // 更新上次领取时间为当前时间
     *  设置今日已领取
     */
    static final int S2C_COLLECT_MONTHLY_BANK_INCOME = 11;

    static final ChannelBuffer COLLECT_MONTHLY_BANK_INCOME_MSG = onlySendHeaderMessage(
            MODULE_ID, S2C_COLLECT_MONTHLY_BANK_INCOME);

    /**
     * 领取月卡钱庄收益失败，附带byte错误码
     * 1、当前没有收益可以领取
     * 2、今日已领取过了
     * 3、礼金太多，请使用部分
     */
    static final int S2C_COLLECT_MONTHLY_BANK_INCOME_FAIL = 12;

    static final ChannelBuffer COLLECT_MONTHLY_BANK_FAIL_NOT_LIJIN = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_COLLECT_MONTHLY_BANK_INCOME_FAIL, 1);

    static final ChannelBuffer COLLECT_MONTHLY_BANK_FAIL_COLLECTED = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_COLLECT_MONTHLY_BANK_INCOME_FAIL, 2);

    static final ChannelBuffer COLLECT_MONTHLY_BANK_FAIL_LIJIN_TOO_MUCH = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_COLLECT_MONTHLY_BANK_INCOME_FAIL, 3);

    /**
     * 领取月卡钱庄在线礼金，客户端自己判断当前是否可以领取（正常领取时间已过，30天，没过期）
     */
    static final int C2S_COLLECT_MONTHLY_BANK_ONLINE_INCOME = 13;

    /**
     * 领取月卡钱庄在线收益成功，没有附带值
     * 
     * 重置月卡钱庄，重新变成可以投资的状态
     */
    static final int S2C_COLLECT_MONTHLY_BANK_ONLINE_INCOME = 14;

    static final ChannelBuffer COLLECT_MONTHLY_BANK_ONLINE_INCOME_MSG = onlySendHeaderMessage(
            MODULE_ID, S2C_COLLECT_MONTHLY_BANK_ONLINE_INCOME);

    /**
     * 领取月卡钱庄收益失败，附带byte错误码
     * 1、没有在线礼金收益可以领取
     * 2、领取时间未到
     * 3、已经过期，不能领取
     * 4、礼金太多，请使用部分
     */
    static final int S2C_COLLECT_MONTHLY_BANK_ONLINE_INCOME_FAIL = 15;

    static final ChannelBuffer COLLECT_MONTHLY_BANK_ONLINE_FAIL_NOT_LIJIN = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_COLLECT_MONTHLY_BANK_ONLINE_INCOME_FAIL, 1);

    static final ChannelBuffer COLLECT_MONTHLY_BANK_ONLINE_FAIL_TIME_NOT_REACHED = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_COLLECT_MONTHLY_BANK_ONLINE_INCOME_FAIL, 2);

    static final ChannelBuffer COLLECT_MONTHLY_BANK_ONLINE_FAIL_EXPIRED = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_COLLECT_MONTHLY_BANK_ONLINE_INCOME_FAIL, 3);

    static final ChannelBuffer COLLECT_MONTHLY_BANK_ONLINE_FAIL_LIJIN_TOO_MUCH = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_COLLECT_MONTHLY_BANK_ONLINE_INCOME_FAIL, 4);

    /**
     * 月卡钱庄累计礼金变化
     * varint32 累计礼金
     * varint32 累计小时数
     */
    static final int S2C_MONTHLY_BANK_ONLINE_LIJIN_CHANGED = 16;

    public static ChannelBuffer getMonthlyBankOnlineLijinChanged(int amount,
            int hours){
        return onlySendHeadAnd2VarInt32Message(MODULE_ID,
                S2C_MONTHLY_BANK_ONLINE_LIJIN_CHANGED, amount, hours);
    }

    /**
     * 获取英雄自己的钱庄日志（所有的）
     * 
     * 每次请求数据后，都缓存起来，如果英雄做了任意的钱庄存取操作，
     * 清空缓存，下次打开重新请求（如果当前打开面板，则立即请求）
     */
    static final int C2S_GET_SELF_BANK_LOG = 17;

    /**
     * 获取英雄自己的钱庄日志
     * while(byteArray)
     *     varint32 info，复合字段
     *     varint64 time
     *     
     * boolean isUpgradeBank = info & 1 > 0; // true表示升级钱庄，false表示月卡钱庄
     * boolean isSave = ((info >>> 1) & 1) > 0; // true表示存入，false表示取出
     * int amount = info >>> 2; // 金额，存入是元宝，取出时礼金
     */
    static final int S2C_GET_SELF_BANK_LOG = 18;

    static ChannelBuffer getSelfBankLogMsg(Deque<Long> deque){
        ChannelBuffer buffer = newDynamicMessage(MODULE_ID,
                S2C_GET_SELF_BANK_LOG, 6 * deque.size());

        for (long l : deque){
            writeVarInt32(buffer, (int) (l >>> 32));
            writeVarInt64(buffer, ((int) l) * 1000L);
        }

        return buffer;
    }

    /**
     * 获取全区服钱庄日志
     * 
     * 每次请求数据后，都缓存起来，如果英雄做了任意的钱庄存取操作，
     * 清空缓存，下次打开重新请求（如果当前打开面板，则立即请求）
     * 
     * 这个数据缓存10秒，10秒后清掉缓存，下次打开重新请求（如果当前打开面板，则立即请求）
     */
    static final int C2S_GET_GLOBAL_BANK_LOG = 19;

    /**
     * 获取全区服
     * while(byteArray)
     *     varint32 info，复合字段
     *     varint64 heroId
     *     UTF 英雄名字
     *     
     * boolean isUpgradeBank = info & 1 > 0; // true表示升级钱庄，false表示月卡钱庄
     * boolean isSave = ((info >>> 1) & 1) > 0; // true表示存入，false表示取出
     * int amount = info >>> 2; // 金额，存入是元宝，取出时礼金
     */
    static final int S2C_GET_GLOBAL_BANK_LOG = 20;

    static ChannelBuffer getGlobalBankLogMsg(int count,
            ConcurrentLinkedDeque<BankGlobalLog> deque){
        ChannelBuffer buffer = newDynamicMessage(MODULE_ID,
                S2C_GET_GLOBAL_BANK_LOG, 20 * count);

        for (BankGlobalLog log : deque){
            writeVarInt32(buffer, log.info);
            writeVarInt64(buffer, log.heroId);
            writeUTF(buffer, log.heroName);
        }

        return buffer;
    }
}
