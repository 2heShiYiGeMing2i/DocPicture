package app.game.module.dbrank;

public class RankUtil{

    private RankUtil(){

    }

    private static final int MAX_FIGHT_AMOUNT = (1 << 26) - 1;

    public static int combineLevelAndFightAmount(int level, int fightAmount){
        final int fm;
        if (fightAmount > MAX_FIGHT_AMOUNT){
            fm = MAX_FIGHT_AMOUNT;
        } else{
            fm = fightAmount;
        }

        return (level << 26) | fm;
    }

    public static int getLevel(int combined){
        return combined >>> 26;
    }

    public static int getFightAmount(int combined){
        return combined & MAX_FIGHT_AMOUNT;
    }

}
