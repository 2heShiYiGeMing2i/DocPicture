package app.game.module.auction;

import org.jboss.netty.buffer.ChannelBuffer;

import app.protobuf.GoodsServerContent.GoodsType;

import com.mokylin.sink.util.BufferUtil;

class AuctionYuanbao extends AuctionItem{

    private static final int GOODS_TYPE = GoodsType.YUANBAO_GOODS.getNumber();

    private static final int GOODS_TYPE_VARINT32_LEN = BufferUtil
            .computeVarInt32Size(GOODS_TYPE);

    private final int amount;

    AuctionYuanbao(long id, int amount, int money, long sellerCombineId,
            byte[] sellerHeroName){
        super(id, sellerCombineId, sellerHeroName, money);

        this.amount = amount;
    }

    @Override
    public void writeGoods(ChannelBuffer buffer){
        BufferUtil.writeVarInt32(
                buffer,
                GOODS_TYPE_VARINT32_LEN
                        + BufferUtil.computeVarInt32Size(amount));
        BufferUtil.writeVarInt32(buffer, GOODS_TYPE);
        BufferUtil.writeVarInt32(buffer, amount);
    }

}
