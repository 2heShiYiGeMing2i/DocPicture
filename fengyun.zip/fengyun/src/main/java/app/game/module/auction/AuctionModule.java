package app.game.module.auction;

import static app.game.module.MiscModule.DisconnectReason.*;
import static app.game.module.auction.AuctionMessages.*;
import static app.protobuf.LogContent.LogEnum.OperateType.*;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.jboss.netty.buffer.ChannelBuffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.data.goods.Goods;
import app.game.entity.Depot;
import app.game.entity.Hero;
import app.game.module.ChatModule;
import app.game.module.ChatModule.OfflineHeroInfo;
import app.game.module.ConnectedUser;
import app.game.module.GoodsContainerModule;
import app.game.module.HeroController;
import app.game.service.DBService;
import app.game.service.IThreadService;
import app.game.service.TimeService;
import app.game.service.WorldService;
import app.game.service.log.LogService;
import app.message.ISender;
import app.utils.IDUtils;
import app.utils.IndividualServerConfig;
import app.utils.VariableConfig;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.google.inject.Inject;
import com.mokylin.sink.util.BufferUtil;
import com.mokylin.sink.util.StringEncoder;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.holder.BooleanHolder;

public class AuctionModule{
    private static final Logger logger = LoggerFactory
            .getLogger(AuctionModule.class);

    private static final RuntimeException ID_NOT_FOUND = new RuntimeException();

    private final IThreadService threadService;

    private final IndividualServerConfig individualServerConfig;

    private final DBService dbService;

    private final WorldService worldService;

    private final GoodsContainerModule goodsContainerModule;

    private final TimeService timeService;

    private final LogService logService;

    private final LoadingCache<Long, ChannelBuffer> userAuctionListCache;

    private final LoadingCache<AuctionSearchCriteria, ChannelBuffer> searchGoodsCache;

    private final LoadingCache<Long, AuctionRealItem> auctionItemCache;

    @Inject
    AuctionModule(IThreadService threadService, ChatModule chatModule,
            DBService dbService, WorldService worldService,
            GoodsContainerModule goodsContainerModule, TimeService timeService,
            IndividualServerConfig individualServerConfig, LogService logService){
        this.threadService = threadService;
        this.dbService = dbService;
        this.worldService = worldService;
        this.goodsContainerModule = goodsContainerModule;
        this.timeService = timeService;
        this.individualServerConfig = individualServerConfig;
        this.logService = logService;

        userAuctionListCache = CacheBuilder
                .newBuilder()
                .concurrencyLevel(4)
                .maximumSize(4096)
                .build(new UserAuctionListCacheLoader(dbService, worldService,
                        chatModule));

        searchGoodsCache = CacheBuilder.newBuilder().concurrencyLevel(16)
                .expireAfterWrite(5, TimeUnit.SECONDS).maximumSize(4096)
                .build(new SearchAuctionGoodsCache(dbService));

        auctionItemCache = CacheBuilder.newBuilder().concurrencyLevel(4)
                .maximumSize(4096)
                .build(new AuctionRealItemCacheLoader(dbService));

        // 读取所有的物品, 根据sellerID, 获取到真正的serverSequence, 如果有变化, 重新存进去
        logger.debug("更新所有摊位物品所属的服务器");
        dbService.updateAuctionServerSequenceOnStart();
        logger.debug("摊位物品更新完成");
    }

    public void onMessage(int sequenceID, ChannelBuffer buffer,
            HeroController hc){
        switch (sequenceID){
            case C2S_GET_SELF_AUCTION_LIST:{
                onGetSelfAuctionList(buffer, hc);
                return;
            }

            case C2S_GET_TARGET_AUCTION_LIST:{
                onGetTargetAuctionList(buffer, hc);
                return;
            }

            case C2S_ADD_GOODS_TO_AUCTION:{
                onAddGoodsToAuction(buffer, hc);
                return;
            }

            case C2S_ADD_MONEY_TO_AUCTION:{
                onAddMoneyToAuction(buffer, hc);
                return;
            }

            case C2S_ADD_YUANBAO_TO_AUCTION:{
                onAddYuanbaoToAuction(buffer, hc);
                return;
            }

            case C2S_SEARCH_AUCTION_GOODS:{
                onSearchAuctionGoods(buffer, hc);
                return;
            }

            case C2S_REMOVE_MY_AUCTION:{
                onRemoveMyAuction(buffer, hc);
                return;
            }

            case C2S_BUY_AUCTION_GOODS:{
                onBuyAuctionGoods(buffer, hc);
                return;
            }

            case C2S_GET_AUCTION_LOG:{
                onGetAuctionLog(buffer, hc);
                return;
            }

            case C2S_COLLECT_PRIZE:{
                onCollectPrize(buffer, hc);
                return;
            }

            case C2S_CHANGE_PRICE:{
                onChangePrice(buffer, hc);
                return;
            }

            case C2S_DISPLAY:{
                onDisplay(buffer, hc);
                return;
            }

            default:{
                logger.warn("AuctionModule收到未知消息: {}", sequenceID);
            }
        }
    }

    private void onDisplay(ChannelBuffer buffer, final HeroController hc){
        if (hc.getHero().getLevel() < VariableConfig.SELF_UNION_CHAT_LEVEL){
            // 等级不够本盟聊天等级, 不准摊位吆喝
            hc.sendMessage(displaySuccess);
            return;
        }

        long ctime = timeService.getCurrentTime();
        if (hc.nextCanDisplayAuctionTime > ctime){
            hc.sendMessage(ERROR_DISPLAY_TOO_FREQUENT);
            return;
        }

        if (hc.getHero().isSpeechLimited(ctime)){
            // 被禁言的, 不准摊位吆喝
            hc.sendMessage(displaySuccess);
            return;
        }

        final long auctionID = BufferUtil.readVarInt64(buffer);
        hc.nextCanDisplayAuctionTime = ctime
                + VariableConfig.AUCTION_DISPLAY_INTERVAL;

        threadService.getDbExecutor().execute(new Runnable(){

            @Override
            public void run(){
                final AuctionRealItem item;
                try{
                    item = auctionItemCache.get(auctionID);
                } catch (Throwable ex){
                    logger.error(
                            "AuctionModule.onDisplay.auctionItemCache.get出错",
                            ex);
                    hc.nextCanDisplayAuctionTime = 0;
                    hc.sendMessage(ERROR_DISPLAY_INTERNAL_ERROR);
                    return;
                }

                if (item == null || item == AuctionRealItem.NULL_ITEM){
                    hc.nextCanDisplayAuctionTime = 0;
                    hc.sendMessage(ERROR_DISPLAY_ID_NOT_EXIST);
                    return;
                }

                if (item.sellerHeroID != hc.combinedID){
                    hc.nextCanDisplayAuctionTime = 0;
                    hc.sendMessage(ERROR_DISPLAY_NOT_YOURS);
                    return;
                }

                hc.sendMessage(displaySuccess);

                worldService
                        .broadcastDroppableMsgToEnteredFirstSceneHeroWithSameServerData(
                                displayBroadcast(auctionID, item),
                                hc.getServerData(), hc.combinedID);
            }
        });
    }

    private void onChangePrice(ChannelBuffer buffer, HeroController hc){
        final long auctionID = BufferUtil.readVarInt64(buffer);
        final int newPrice = BufferUtil.readVarInt32(buffer);

        if (newPrice <= 0){
            logger.warn("AuctionModule.onChangePrice, 客户端要把个物品的价格改为 {}",
                    newPrice);
            hc.sendMessage(ERROR_CHANGE_PRICE_ILLEGAL_PRICE);
            return;
        }

        final ISender sender = hc.getSender();

        final long heroID = hc.combinedID;
        final int serverSequence = hc.getServerData().sequence;

        final Long bigHeroID = hc.getBigID();
        threadService.getDbExecutor().execute(new Runnable(){

            @Override
            public void run(){
                final Long bigAuctionID = Long.valueOf(auctionID);
                final AuctionRealItem item;
                try{
                    item = auctionItemCache.get(bigAuctionID);

                    if (item == null || item == AuctionRealItem.NULL_ITEM){
                        sender.sendMessage(ERROR_CHANGE_PRICE_ID_NOT_EXIST);
                        return;
                    }

                    if (item.sellerHeroID != heroID){
                        sender.sendMessage(ERROR_CHANGE_PRICE_NOT_YOURS);
                        return;
                    }

                    if (!(item instanceof AuctionRealYuanbao)){
                        // 只要不是卖元宝的, 别的价格都是元宝, 必须价格>=2
                        if (newPrice <= 1){
                            sender.sendMessage(ERROR_CHANGE_PRICE_ILLEGAL_PRICE);
                            return;
                        }
                    }

                    if (!dbService.removeAuctionItem(auctionID, false)){
                        sender.sendMessage(ERROR_CHANGE_PRICE_ID_NOT_EXIST);
                        return;
                    }

                } catch (Throwable ex){
                    logger.error("AuctionModule.onChangePrice出错", ex);
                    sender.sendMessage(ERROR_CHANGE_PRICE_INTERNAL_ERROR);
                    return;
                }

                // 到这里物品已经删掉了

                try{
                    userAuctionListCache.invalidate(bigHeroID);
                    auctionItemCache.put(bigAuctionID,
                            AuctionRealItem.NULL_ITEM);
                } catch (Throwable ex){
                    logger.error("AuctionModule.onChangePrice.改变cache出错", ex);
                    // 不能return
                }

                final long newID;
                try{
                    if (item instanceof AuctionRealMoney){
                        newID = dbService.addAuctionMoney(
                                ((AuctionRealMoney) item).amount, newPrice,
                                heroID, item.sellerNameBytes, serverSequence);
                    } else if (item instanceof AuctionRealYuanbao){
                        newID = dbService.addAuctionYuanbao(
                                ((AuctionRealYuanbao) item).amount, newPrice,
                                heroID, item.sellerNameBytes, serverSequence);
                    } else{
                        AuctionRealGoods realGoods = (AuctionRealGoods) item;
                        newID = dbService.addAuctionGoods(realGoods.goods,
                                newPrice, heroID, item.sellerNameBytes,
                                serverSequence);
                    }
                } catch (Throwable ex){
                    logger.error(
                            "AuctionModule.onChangePrice在将物品从db中删除, 重新上架的时候出错",
                            ex);

                    // TODO 邮件
                    return;
                }

                if (newID == -1){
                    logger.error("AuctionModule.onChangePrice在将物品从db中删除, 重新上架的时候返回的id是-1");
                    // TODO 邮件

                    return;
                }

                if (newID == -2){
                    logger.error("AuctionModule.onChangePrice在将物品从db中删除, 重新上架的时候返回的id是-2,东西已经放上去了, 只能踢掉玩家了");
                    ConnectedUser cu = worldService.getUser(heroID);
                    if (cu != null){
                        cu.disconnect(INTERNAL_ERROR_AUCTION_CHANGE_PRICE_ERROR);
                    }
                    return;
                }

                sender.sendMessage(changePriceSuccess(newID));
            }
        });
    }

    private void onCollectPrize(ChannelBuffer buffer, HeroController hc){
        if (hc.hasTrade()){
            hc.sendMessage(ERROR_COLLECT_PRIZE_IN_TRADE);
            return;
        }

        final AuctionCollectable collectable;
        try{
            collectable = dbService.getAuctionCollectable(hc.combinedID);
        } catch (Throwable ex){
            logger.error(
                    "AuctionModule.onCollectPrize.dbService.getAuctionCollectable出错",
                    ex);
            hc.sendMessage(ERROR_COLLECT_PRIZE_INTERNAL_ERROR);
            return;
        }

        if (collectable == null){
            logger.error("AuctionModule.onCollectPrize.dbService.getAuctionCollectable返回null");
            hc.sendMessage(ERROR_COLLECT_PRIZE_INTERNAL_ERROR);
            return;
        }

        if (collectable.isEmpty()){
            hc.sendMessage(ERROR_COLLECT_PRIZE_NOTHING_TO_COLLECT);
            return;
        }

        final int collectedMoney;
        final int collectedYuanbao;

        // 可领取多少钱
        if (collectable.money <= 0){
            collectedMoney = 0;
        } else{
            if (collectable.money > VariableConfig.MONEY_MAX_AMOUNT){
                collectedMoney = -1;
            } else{
                if (hc.getHeroMiscModule().canAddMoney((int) collectable.money)){
                    collectedMoney = (int) collectable.money;
                } else{
                    collectedMoney = -1;
                }
            }
        }

        // 可领取多少元宝
        if (collectable.yuanbao <= 0){
            collectedYuanbao = 0;
        } else{
            if (collectable.yuanbao > VariableConfig.YUANBAO_MAX_AMOUNT){
                collectedYuanbao = -1;
            } else{
                if (hc.getHeroMiscModule().canAddYuanbao(
                        (int) collectable.yuanbao)){
                    collectedYuanbao = (int) collectable.yuanbao;
                } else{
                    collectedYuanbao = -1;
                }
            }
        }

        // 先保存, 成功再加

        final AuctionCollectable newCollectable;
        try{
            newCollectable = dbService.reduceAuctionCollectable(hc.combinedID,
                    collectedMoney == -1 ? 0 : collectedMoney,
                    collectedYuanbao == -1 ? 0 : collectedYuanbao,
                    collectable.exp);

            if (newCollectable == null){
                logger.error("AuctionModule.onCollectPrize.dbService.reduceAuctionCollectable返回null...");
                hc.sendMessage(ERROR_COLLECT_PRIZE_INTERNAL_ERROR);
                return;
            }
        } catch (Throwable ex){
            logger.error(
                    "AuctionModule.onCollectPrize.dbService.reduceAuctionCollectable出错",
                    ex);
            return;
        }

        // 保存成功, 添加
        if (collectedMoney > 0){
            hc.getHeroMiscModule().addMoneyAnyway(collectedMoney,
                    COLLECT_AUCTION_PRIZE, null);
        }

        if (collectedYuanbao > 0){
            hc.getHeroMiscModule().addYuanbaoAnyway(collectedYuanbao,
                    COLLECT_AUCTION_PRIZE, null);
        }

        if (collectable.exp > 0){
            hc.getHeroFightModule().addExperience(
                    collectable.exp > 20_0000_0000 ? 20_0000_0000
                            : (int) collectable.exp, COLLECT_AUCTION_PRIZE,
                    null);
        }

        // 发消息通知领取成功
        hc.sendMessage(collectPrizeSuccess(collectedMoney, collectedYuanbao,
                collectable.exp));
        hc.sendMessage(setCollectable(newCollectable));
    }

    public void heroOnlineGetCollectable(final long id, final ISender sender,
            final BooleanHolder isOffline){
        try{
            AuctionCollectable collectable = dbService
                    .getAuctionCollectable(id);

            if (collectable == null){
                logger.error("AuctionModule.heroOnlineGetCollectable.dbService.getAuctionCollectable返回了null");
                return;
            }

            if (!collectable.isEmpty()){
                sender.sendMessage(setCollectable(collectable));
            }
        } catch (Throwable e){
            logger.error("AuctionModule.heroOnlineGetCollectable出错", e);
        }
    }

    private void onGetAuctionLog(ChannelBuffer buffer, final HeroController hc){
        if (hc.requestedAuctionLog){
            hc.sendMessage(ERROR_GET_AUCTION_LOG_ALREADY_REQUESTED);
            return;
        }

        hc.requestedAuctionLog = true;

        threadService.getDbExecutor().execute(new Runnable(){
            @Override
            public void run(){
                try{
                    List<AuctionLog> logs = dbService.getAuctionLog(
                            hc.combinedID, VariableConfig.AUCTION_LOG_LIMIT);

                    hc.sendMessage(replyAuctionLog(logs, hc.combinedID));
                } catch (Throwable ex){
                    logger.error(
                            "AuctionModule.onGetAuctionLog.dbService.getAuctionLog出错",
                            ex);
                    hc.requestedAuctionLog = false;
                    hc.sendMessage(ERROR_GET_AUCTION_LOG_INTERNAL_ERROR);
                }
            }
        });
    }

    private void onBuyAuctionGoods(ChannelBuffer buffer, HeroController hc){
        if (hc.hasTrade()){
            hc.sendMessage(ERROR_BUY_AUCTION_GOODS_YOU_ARE_TRADING);
            return;
        }

        final long toBuyID = BufferUtil.readVarInt64(buffer);
        final Long bigAuctionID = Long.valueOf(toBuyID);
        final AuctionRealItem item;

        try{
            item = auctionItemCache.get(bigAuctionID);
            if (item == null || item == AuctionRealItem.NULL_ITEM){
                hc.sendMessage(ERROR_BUY_AUCTION_GOODS_ID_NOT_EXIST);
                return;
            }

            if (item.sellerHeroID == hc.combinedID){
                hc.sendMessage(ERROR_BUY_AUCTION_GOODS_YOU_ARE_THE_SELLER);
                return;
            }

            if (hc.getServerData() != individualServerConfig
                    .getServerData(IDUtils
                            .getCombinedServerAndOperatorID(item.sellerHeroID))){
                hc.sendMessage(ERROR_BUY_AUCTION_GOODS_NOT_SAME_UNION);
                return;
            }

            if (item instanceof AuctionRealYuanbao){
                // 这里的价钱是银两
                if (!hc.getHeroMiscModule().hasEnoughMoney(item.cost)){
                    hc.sendMessage(ERROR_BUY_AUCTION_GOODS_NOT_ENOUGH_MONEY);
                    return;
                }
            } else{
                // 别的物品, 价格都是元宝
                if (!hc.getHeroMiscModule().hasEnoughYuanbao(item.cost)){
                    hc.sendMessage(ERROR_BUY_AUCTION_GOODS_NOT_ENOUGH_MONEY);
                    return;
                }
            }

            if (!item.canHold(hc, true)){
                hc.sendMessage(ERROR_BUY_AUCTION_GOODS_NOT_ENOUGH_SPACE);
                return;
            }

            if (!dbService.removeAuctionItem(toBuyID, true)){
                hc.sendMessage(ERROR_BUY_AUCTION_GOODS_ID_NOT_EXIST);
                return;
            }

        } catch (Throwable ex){
            hc.sendMessage(ERROR_BUY_AUCTION_GOODS_INTERNAL_ERROR);
            return;
        }
        try{
            // 这个出错影响了后面的一大票逻辑
            userAuctionListCache.invalidate(item.sellerHeroID);
            auctionItemCache.put(bigAuctionID, AuctionRealItem.NULL_ITEM);
        } catch (Throwable ex){
            logger.error("AuctionModule.buy.userAuctionListCache.invalidate出错",
                    ex);
            // 不能return
        }

        Hero hero = hc.getHero();
        String iEventId = logService.getStallTradeProcessor().newEventID(
                hero.getID());
        logService.getStallTradeProcessor().addLogEvent(hero.getOperatorId(),
                iEventId, hero.getServerId(), hero.getUin(), hero.getUserId(),
                hero.getName(), IDUtils.getServerID(item.sellerHeroID),
                IDUtils.getUserID(item.sellerHeroID),
                StringEncoder.encode(item.sellerNameBytes), item.getItemId(),
                item.getItemName(), item.getItemCount(), item.cost);

        // 到这里, 东西已经从数据库中删了
        if (item instanceof AuctionRealYuanbao){
            hc.getHeroMiscModule().reduceMoneyAnyway(item.cost, SALE_BUY,
                    iEventId);
        } else{
            hc.getHeroMiscModule().reduceYuanbaoAnywayButNotGameIncome(
                    item.cost, SALE_BUY, iEventId);
        }
        final long ctime = timeService.getCurrentTime();

        final long buyerID = hc.combinedID;
        final byte[] buyName = hc.getHero().getNameBytes();

        ChannelBuffer msgToSeller = otherBoughtYourAuctionGoods(toBuyID, ctime,
                buyerID, buyName, item); // 一定要在给之前, 不然给物品可能会改变count

        item.doGive(hc, goodsContainerModule, true, SALE_BUY, iEventId, ctime);

        int expAmount;
        if (hc.getHero().addAuctionGetExpTimeIfCan(ctime)){
            // 可以给经验
            expAmount = Math.max(0, Utils.square(hc.getHero().getLevel())); // 防止overflow
            hc.getHeroFightModule()
                    .addExperience(expAmount, SALE_BUY, iEventId);
        } else{
            expAmount = 0;
        }
        hc.sendMessage(buyAuctionSuccess(expAmount, item.buyerTax()));

        if (item.buyerTax() > 0){
            // 记录交易税金收入
            hc.getHeroMiscModule().addGameIncomeLog(item.buyerTax(), SALE_TAX,
                    iEventId, 0, 0);
        }
        if (item.sellerTax() > 0){
            // 也记录到买家身上
            hc.getHeroMiscModule().addGameIncomeLog(item.sellerTax(), SALE_TAX,
                    iEventId, 0, 0);
        }

        final ISender sellerSender;
        // 计算对方应该拿多少经验
        final int targetExp;
        ConnectedUser targetCu = worldService.getUser(item.sellerHeroID);
        if (targetCu != null){
            HeroController targetHc = targetCu.getHeroController();
            if (targetHc != null && targetHc.hasEnterSceneForTheFirstTime()){
                if (targetHc.getHero().addAuctionGetExpTimeIfCan(ctime)){
                    targetExp = Math.max(0,
                            Utils.square(targetHc.getHero().getLevel())); // 防止overflow, 虽然貌似不可能
                } else{
                    targetExp = 0;
                }
                sellerSender = targetHc.getSender();

                BufferUtil.writeVarInt32(msgToSeller, targetExp);
                targetHc.sendMessage(msgToSeller);

                targetHc.reduceNumOfAuction();
            } else{
                targetExp = 0;
                sellerSender = null;
            }
        } else{
            targetExp = 0;
            sellerSender = null;
        }

        final AuctionLog log = item.toAuctionLog(buyerID, buyName, ctime,
                targetExp);

        // 交给db去加log
        threadService.getDbExecutor().execute(new Runnable(){

            @Override
            public void run(){

                // 给出售者加上可领取的数量
                int collectableMoney = item.sellerCollectableMoney();
                int collectableYuanbao = item.sellerCollectableYuanbao();

                AuctionCollectable newCollectable = null;
                try{
                    newCollectable = dbService.addAuctionCollectable(
                            item.sellerHeroID, collectableMoney,
                            collectableYuanbao, targetExp);
                } catch (Throwable ex){
                    logger.error(
                            "AuctionModule.buy.dbService.addAuctionCollectable出错",
                            ex);
                    logger.error(
                            "AuctionModule.buy.dbService.addAuctionCollectable出错. 应该要给 {} 加 {} 银两, {} 元宝, {} 经验",
                            item.sellerHeroID, collectableMoney,
                            collectableYuanbao, targetExp);
                }

                // 通知出售者
                if (sellerSender != null && newCollectable != null){
                    sellerSender.sendMessage(setCollectable(newCollectable));
                }

                // 写日志
                try{
                    if (!dbService.addAuctionLog(log)){
                        logger.error("AuctionMoney.buy.dbService.addAuctionLog返回false. row竟然不是1...");
                    }
                } catch (Throwable ex){
                    logger.error("AuctionModule.buy.dbService.addAuctionLog出错",
                            ex);
                }
            }
        });
    }

    private void onRemoveMyAuction(ChannelBuffer buffer, HeroController hc){
        long toRemoveID = BufferUtil.readVarInt64(buffer);
        final Long bigAuctionID = Long.valueOf(toRemoveID);
        final AuctionRealItem item;
        try{
            item = auctionItemCache.get(bigAuctionID);
            if (item == null || item == AuctionRealItem.NULL_ITEM){
                hc.sendMessage(ERROR_REMOVE_MY_AUCTION_ID_NOT_FOUND);
                return;
            }

            if (item.sellerHeroID != hc.combinedID){
                hc.sendMessage(ERROR_REMOVE_MY_AUCTION_NOT_YOURS);
                return;
            }

            if (!item.canHold(hc, false)){
                hc.sendMessage(ERROR_REMOVE_MY_AUCTION_NOT_ENOUGH_SPACE);
                return;
            }

            if (!dbService.removeAuctionItem(toRemoveID, false)){
                hc.sendMessage(ERROR_REMOVE_MY_AUCTION_ID_NOT_FOUND);
                return;
            }
        } catch (Throwable ex){
            logger.error("AuctionModule.onRemoveMyAuction出错", ex);
            hc.sendMessage(ERROR_REMOVE_MY_AUCTION_INTERNAL_ERROR);
            return;
        }

        String iEventId = logService.getStallEndProcessor().newEventID(
                hc.getID());

        // 已经删掉了, 必须加成功
        item.doGive(hc, goodsContainerModule, false, SALE_OFF, iEventId,
                timeService.getCurrentTime());
        hc.sendMessage(removeMyAuctionSuccess);

        userAuctionListCache.invalidate(item.sellerHeroID);
        auctionItemCache.put(bigAuctionID, AuctionRealItem.NULL_ITEM);

        hc.reduceNumOfAuction();
    }

    private void onSearchAuctionGoods(ChannelBuffer buffer,
            final HeroController hc){
        if (hc.isSearchingAuction){
            hc.sendMessage(ERROR_SEARCH_AUCTION_GOODS_HAVENOT_RETURNED);
            return;
        }

        final int goodsQuality = BufferUtil.readVarInt32(buffer);
        if (goodsQuality < 0 || goodsQuality > 5){
            hc.sendMessage(ERROR_SEARCH_AUCTION_GOODS_ILLEGAL_QUALITY);
            return;
        }

        final int goodsLevel = BufferUtil.readVarInt32(buffer);
        if (goodsLevel < 0){
            hc.sendMessage(ERROR_SEARCH_AUCTION_GOODS_ILLEGAL_LEVEL);
            return;
        }

        final int sortType = BufferUtil.readVarInt32(buffer);
        if (sortType < 0 || sortType > 2){
            hc.sendMessage(ERROR_SEARCH_AUCTION_GOODS_ILLEGAL_SORT_TYPE);
            return;
        }

        final int goodsType = BufferUtil.readVarInt32(buffer);
        if (goodsType < 0){
            hc.sendMessage(ERROR_SEARCH_AUCTION_GOODS_ILLEGAL_GOODS_TYPE);
            return;
        }

        final int page = BufferUtil.readVarInt32(buffer);
        if (page < 0){
            logger.warn("AuctionModule.onSearchAuctionGoods时, page<0: {}", page);
            hc.sendMessage(ERROR_SEARCH_AUCTION_GOODS_ILLEGAL_GOODS_TYPE);
            return;
        }

        final byte[] goodsName;
        int bytesLeft = buffer.readableBytes();
        if (bytesLeft > 0){

            if (bytesLeft >= 20){
                hc.sendMessage(ERROR_SEARCH_AUCTION_GOODS_ILLEGAL_GOODS_NAME);
                return;
            }
            goodsName = new byte[bytesLeft];
            buffer.readBytes(goodsName);
        } else{
            goodsName = null;
        }

        final AuctionSearchCriteria criteria = new AuctionSearchCriteria(
                goodsQuality, goodsLevel, sortType, goodsType, page, goodsName,
                hc.getServerData().sequence);

        ChannelBuffer msg = searchGoodsCache.getIfPresent(criteria);
        if (msg != null){
            hc.sendMessage(msg);
            return;
        }

        hc.isSearchingAuction = true;

        threadService.getDbExecutor().execute(new Runnable(){

            @Override
            public void run(){
                if (hc.getIsOffline().get()){
                    return;
                }
                try{
                    ChannelBuffer msg = searchGoodsCache.get(criteria);
                    hc.isSearchingAuction = false;
                    hc.sendMessage(msg);
                } catch (Throwable ex){
                    hc.isSearchingAuction = false;
                    logger.error(
                            "AuctionModule.onSearchAuctionGoods.searchGoodsCache.get出错",
                            ex);
                    hc.sendMessage(ERROR_SEARCH_AUCTION_GOODS_INTERNAL_ERROR);
                }
            }
        });
    }

    private void onAddYuanbaoToAuction(ChannelBuffer buffer, HeroController hc){

        int yuanbaoToSell = BufferUtil.readVarInt32(buffer);
        int moneyPrice = BufferUtil.readVarInt32(buffer);

        if (moneyPrice < 1 || moneyPrice > VariableConfig.AUCTION_MAX_PRICE){
            logger.warn(
                    "AuctionModule.onAddYuanbaoToAuction时, 收到的银两价格不是1-9亿之间, 断线: {}",
                    moneyPrice);
//            hc.disconnect(AUCTION_WRONG_PRICE);
            return;
        }

        if (yuanbaoToSell < 2){
            logger.warn(
                    "AuctionModule.onAddYuanbaoToAuction时, 要卖的元宝 < 2, 断线: {}",
                    yuanbaoToSell);
//            hc.disconnect(AUCTION_WRONG_PRICE);
            return;
        }

        if (yuanbaoToSell > hc.getHero().getYuanbao()){
            hc.sendMessage(ERROR_ADD_YUANBAO_TO_AUCTION_NOT_ENOUGH_YUANBAO);
            return;
        }

        if (hc.hasTrade()){
            hc.sendMessage(ERROR_ADD_YUANBAO_TO_AUCTION_IN_TRADE);
            return;
        }

        // 这些元宝可以放上摊位

        // 检查当前是否在卖元宝

        try{
            boolean isSellingYuanbao = dbService
                    .hasUserAuctionedYuanbao(hc.combinedID);
            if (isSellingYuanbao){
                hc.sendMessage(ERROR_ADD_YUANBAO_TO_AUCTION_ALREADY_SELLING_YUANBAO);
                return;
            }
            int serverSequence = hc.getServerData().sequence;

            long auctionID = dbService.addAuctionYuanbao(yuanbaoToSell,
                    moneyPrice, hc.combinedID, hc.getHero().getNameBytes(),
                    serverSequence);

            if (auctionID == -1){
                hc.sendMessage(ERROR_ADD_YUANBAO_TO_AUCTION_INTERNAL_ERROR);
                return;
            }

            hc.getHeroMiscModule().reduceYuanbaoAnywayButNotGameIncome(
                    yuanbaoToSell, SALE_ON, null);
            removeUserAuctionCache(hc.getBigID());

            if (auctionID == -2){
                // -2表示物品已经添加到数据库了
                logger.error("AuctionModule.onAddYuanbaoToAuction, db返回-2, 只能把玩家踢下线了");
                hc.disconnect(INTERNAL_ERROR_AUCTION_ADD_SELL_DB_ERROR);
                return;
            }

            hc.sendMessage(addYuanbaoToAuctionSuccess(auctionID));

            hc.addNumOfAuction();

        } catch (Throwable ex){
            logger.error("AuctionModule.onAddYuanbaoToAuction出错", ex);
            hc.sendMessage(ERROR_ADD_YUANBAO_TO_AUCTION_INTERNAL_ERROR);
        }
    }

    private void onAddMoneyToAuction(ChannelBuffer buffer, HeroController hc){
        int moneyToSell = BufferUtil.readVarInt32(buffer);
        int yuanbaoPrice = BufferUtil.readVarInt32(buffer);

        if (yuanbaoPrice < 2 || yuanbaoPrice > VariableConfig.AUCTION_MAX_PRICE){
            logger.warn(
                    "AuctionModule.onAddMoneyToAuction时, 收到的元宝价格不是2-9亿之间, 断线: {}",
                    yuanbaoPrice);
//            hc.disconnect(AUCTION_WRONG_PRICE);
            return;
        }

        if (moneyToSell <= 0){
            logger.warn(
                    "AuctionModule.onAddMoneyToAuction时, 要卖的银两 <= 0, 断线: {}",
                    moneyToSell);
//            hc.disconnect(AUCTION_WRONG_PRICE);
            return;
        }

        if (moneyToSell > hc.getHero().getMoney()){
            hc.sendMessage(ERROR_ADD_MONEY_TO_AUCTION_NOT_ENOUGH_MONEY);
            return;
        }

        // 这些钱可以放上摊位

        // 检查当前是否在卖银两

        try{
            boolean isSellingMoney = dbService
                    .hasUserAuctionedMoney(hc.combinedID);
            if (isSellingMoney){
                hc.sendMessage(ERROR_ADD_MONEY_TO_AUCTION_ALREADY_SELLING_MONEY);
                return;
            }

            int serverSequence = hc.getServerData().sequence;
            long auctionID = dbService.addAuctionMoney(moneyToSell,
                    yuanbaoPrice, hc.combinedID, hc.getHero().getNameBytes(),
                    serverSequence);

            if (auctionID == -1){
                // 内部错误, 返回的row不是1
                hc.sendMessage(ERROR_ADD_MONEY_TO_AUCTION_INTERNAL_ERROR);
                return;
            }

            Hero hero = hc.getHero();
            String iEventId = logService.getStallStartProcessor().newEventID(
                    hero.getID());
            logService.todo();
//            logService.getStallStartProcessor().addLogEvent(operatorID,
//                    iEventId, iWorldId, iUin, iRoleId, vRoleName, iJob,
//                    iGender, iRoleLevel, iMoneyBeforeStall, iMoneyAfterStall,
//                    vStallName, iZoneId, iObjNum, iItemId, iItemType, iItemNum,
//                    iItemPrice, iItemGuid);

            hc.getHeroMiscModule().reduceMoneyAnyway(moneyToSell, SALE_ON,
                    iEventId); // 扣钱, 发消息
            removeUserAuctionCache(hc.getBigID()); // 删掉摊位列表的缓存

            if (auctionID == -2){
                // -2表示物品已经添加到数据库了
                logger.error("AuctionModule.onAddMoneyToAuction, db返回-2, 只能把玩家踢下线了");
                hc.disconnect(INTERNAL_ERROR_AUCTION_ADD_SELL_DB_ERROR);
                return;
            }

            hc.sendMessage(addMoneyToAuctionSuccess(auctionID));

            hc.addNumOfAuction();
        } catch (Throwable ex){
            logger.error("AuctionModule.onAddMoneyToAuction出错", ex);
            hc.sendMessage(ERROR_ADD_MONEY_TO_AUCTION_INTERNAL_ERROR);
        }
    }

    private void onAddGoodsToAuction(ChannelBuffer buffer, HeroController hc){
        int pos = BufferUtil.readVarInt32(buffer);
        int goodsID = BufferUtil.readVarInt32(buffer);
        int count = BufferUtil.readVarInt32(buffer);
        final int yuanbaoPrice = BufferUtil.readVarInt32(buffer);

        if (yuanbaoPrice < 2 || yuanbaoPrice > VariableConfig.AUCTION_MAX_PRICE){
            logger.warn(
                    "AuctionModule.onAddGoodsToAuction时, 收到的元宝价格不是2-9亿之间, 断线: {}",
                    yuanbaoPrice);
//            hc.disconnect(AUCTION_WRONG_PRICE);
            return;
        }

        if (count < 1){
            logger.warn(
                    "AuctionModule.onAddGoodsToAuction时, 收到的物品数量<1, 断线: {}",
                    count);
//            hc.disconnect(AUCTION_WRONG_PRICE);
            return;
        }

        Depot depot = hc.getHero().getDepot();
        if (depot.isInvalidPos(pos)){
            hc.sendMessage(ERROR_ADD_GOODS_TO_AUCTION_GOODS_NOT_FOUND);
            return;
        }

        if (depot.isLocked(pos)){
            hc.sendMessage(ERROR_ADD_GOODS_TO_AUCTION_GOODS_LOCKED);
            return;
        }

        Goods onSale = depot.get(pos);
        if (onSale == null){
            hc.sendMessage(ERROR_ADD_GOODS_TO_AUCTION_GOODS_NOT_FOUND);
            return;
        }

        if (onSale.getId() != goodsID){
            hc.sendMessage(ERROR_ADD_GOODS_TO_AUCTION_ID_NOT_MATCH);
            return;
        }

        if (onSale.isBinded() || onSale.hasExpireTime()){
            hc.sendMessage(ERROR_ADD_GOODS_TO_AUCTION_BINDED_OR_EXPIRABLE);
            return;
        }

        if (count > onSale.getCount()){
            hc.sendMessage(ERROR_ADD_GOODS_TO_AUCTION_NOT_ENOUGH_QUANTITY);
            return;
        }

        long identifier = onSale.getGoodsIdentifier();
        hc.getGoodsOwnership().checkGoodsEnough(identifier, count);

        // 到这里物品是可以放上架的, 检查已上架物品个数, ok就真正上架了

        try{
            int onAuctionGoodsCount = dbService
                    .getUserAuctionedGoodsCount(hc.combinedID);
            if (onAuctionGoodsCount >= VariableConfig.AUCTION_GOODS_LIMIT){
                hc.sendMessage(ERROR_ADD_GOODS_TO_AUCTION_TOO_MANY_ON_SALE);
                return;
            }

            long ctime = timeService.getCurrentTime();
            hc.getGoodsOwnership().removeGoods(identifier, count, SALE_ON, 0,
                    ctime, onSale.needLog());

            int serverSequence = hc.getServerData().sequence;
            // 可以上架
            final boolean isTotalAdd;
            final Goods toAdd;
            if (count == onSale.getCount()){
                toAdd = onSale;
                isTotalAdd = true;
            } else{
                toAdd = onSale.split(count);
                isTotalAdd = false;
            }

            final long auctionID;
            try{
                auctionID = dbService.addAuctionGoods(toAdd, yuanbaoPrice,
                        hc.combinedID, hc.getHero().getNameBytes(),
                        serverSequence);
            } catch (Throwable ex){
                logger.error(
                        "AuctionModule.onAddGoodsToAuction.dbService.addAuctionGoods出错",
                        ex);

                if (!isTotalAdd){
                    toAdd.foldTo(onSale); // 把count返回给他
                }
                hc.sendMessage(ERROR_ADD_MONEY_TO_AUCTION_INTERNAL_ERROR);
                return;
            }

            if (auctionID == -1){
                // 内部错误, 返回的row不是1
                if (!isTotalAdd){
                    toAdd.foldTo(onSale);
                    hc.getGoodsOwnership().addGoods(identifier, count, SALE_ON,
                            0, ctime, onSale.needLog());
                }
                hc.sendMessage(ERROR_ADD_GOODS_TO_AUCTION_INTERNAL_ERROR);
                return;
            }

            if (isTotalAdd){
                depot.remove(pos);
            } else{
                // 不用动, 已经把count去掉了
            }
            removeUserAuctionCache(hc.getBigID()); // 删掉摊位列表的缓存

            if (auctionID == -2){
                // -2表示物品已经添加到数据库了
                logger.error("AuctionModule.onAddGoodsToAuction, db返回-2, 只能把玩家踢下线了");
                hc.disconnect(INTERNAL_ERROR_AUCTION_ADD_SELL_DB_ERROR);
                return;
            }

            hc.sendMessage(addGoodsToAuctionSuccess(auctionID));

            hc.addNumOfAuction();
        } catch (Throwable ex){
            logger.error("AuctionModule.onAddGoodsToAuction出错", ex);
            hc.sendMessage(ERROR_ADD_GOODS_TO_AUCTION_INTERNAL_ERROR);
        }
    }

    private void onGetTargetAuctionList(ChannelBuffer buffer, HeroController hc){
        final long id = BufferUtil.readVarInt64(buffer);

        if (hc.getServerData() != individualServerConfig.getServerData(IDUtils
                .getCombinedServerAndOperatorID(id))){
            // 不是同一联服
            hc.sendMessage(ERROR_GET_TARGET_AUCTION_LIST_NOT_SAME_UNION);
            return;
        }

        Long bigID = Long.valueOf(id);
        ChannelBuffer msg = userAuctionListCache.getIfPresent(bigID);
        if (msg != null){
            hc.sendMessage(msg);
            return;
        }

        final ISender sender = hc.getSender();
        final BooleanHolder isOffline = hc.getIsOffline();

        threadService.getDbExecutor().execute(new Runnable(){

            @Override
            public void run(){
                if (isOffline.get()){
                    return;
                }

                try{
                    ChannelBuffer msg = userAuctionListCache.get(id);
                    sender.sendMessage(msg);
                } catch (Exception ex){
                    if (ex.getCause() == ID_NOT_FOUND){
                        logger.warn("获取别人摊位物品列表时, id竟然不存在: {}", id);
                        sender.sendMessage(ERROR_GET_TARGET_ID_NOT_EXIST);
                        return;
                    }

                    logger.error("获取英雄摊位物品列表时出错", ex);
                    sender.sendMessage(ERROR_GET_TARGET_AUCTION_LIST_INTERNAL_ERROR);
                }
            }
        });
    }

    private void onGetSelfAuctionList(ChannelBuffer buffer,
            final HeroController hc){
        if (hc.requestedSelfAuction){
            hc.sendMessage(ERROR_GET_SELF_AUCTION_LIST_ALREADY_REQUESTED);
            return;
        }

        hc.requestedSelfAuction = true;

        ChannelBuffer msg = userAuctionListCache.getIfPresent(hc.getBigID());
        if (msg != null){
            hc.sendMessage(msg);
            return;
        }

        threadService.getDbExecutor().execute(new Runnable(){
            @Override
            public void run(){
                if (hc.getIsOffline().get()){
                    return;
                }

                try{
                    ChannelBuffer msg = userAuctionListCache.get(hc.getBigID());
                    hc.sendMessage(msg);
                } catch (Exception ex){
                    hc.requestedSelfAuction = false;
                    if (ex.getCause() == ID_NOT_FOUND){
                        logger.error("获取自己摊位物品列表时, 竟然抛了id不存在的错??");
                    } else{
                        logger.error("获取英雄摊位物品列表时出错", ex);
                    }
                    hc.sendMessage(ERROR_GET_SELF_AUCTION_LIST_INTERNAL_ERROR);
                }
            }
        });
    }

    // ----- 获取摊位Cache -----

    /**
     * 删除摊位列表中的缓存
     * @param id
     */
    public void removeUserAuctionCache(Long id){
        userAuctionListCache.invalidate(id);
    }

    static class UserAuctionListCacheLoader extends
            CacheLoader<Long, ChannelBuffer>{

        private final DBService dbService;

        private final WorldService worldService;

        private final ChatModule chatModule;

        UserAuctionListCacheLoader(DBService dbService,
                WorldService worldService, ChatModule chatModule){
            this.dbService = dbService;
            this.worldService = worldService;
            this.chatModule = chatModule;
        }

        @Override
        public ChannelBuffer load(Long key) throws Exception{
            long id = key.longValue();

            final int auctionType;

            ConnectedUser cu = worldService.getUser(id);
            if (cu != null){
                HeroController hc = cu.getHeroController();
                if (hc != null){
                    if (hc.hasEnterSceneForTheFirstTime()){
                        auctionType = AUCTION_TYPE_ONLINE;
                    } else{
                        auctionType = AUCTION_TYPE_OFFLINE;
                    }
                } else{
                    throw ID_NOT_FOUND;
                }
            } else{
                // 不在线
                final OfflineHeroInfo info;
                try{
                    info = chatModule.getOfflineHeroInfo(key);
                } catch (Exception ex){
                    logger.error(
                            "AuctionModule.AuctionListCacheLoader.load时, 从chatModule.getOfflineHeroInfo时出错",
                            ex);
                    throw ex;
                }

                if (info == OfflineHeroInfo.EMPTY_OFFLINE_HERO_INFO){
                    throw ID_NOT_FOUND;
                }

                auctionType = AUCTION_TYPE_OFFLINE;
            }

            List<AuctionItem> items = dbService.getAuctionByUser(id);

            return replyAuctionList(auctionType, items);
        }
    }

    // ---- 搜索物品cache ----

    static class SearchAuctionGoodsCache extends
            CacheLoader<AuctionSearchCriteria, ChannelBuffer>{

        private final DBService dbService;

        SearchAuctionGoodsCache(DBService dbService){
            this.dbService = dbService;
        }

        @Override
        public ChannelBuffer load(AuctionSearchCriteria key) throws Exception{
            if (key.goodsType == 0){
                // 全部物品
                List<AuctionItem> items = dbService.searchAllAuction(key.page
                        * VariableConfig.AUCTION_EACH_PAGE_COUNT,
                        VariableConfig.AUCTION_EACH_PAGE_COUNT + 1,
                        key.goodsQuality, key.goodsLevel, key.sortType,
                        key.goodsName, key.serverSequence);
                return replySearchAuctionGoods(items);
            }

            int rangeKey = AuctionTypeHelper
                    .isAuctionTypeRangeQuery(key.goodsType);

            if (rangeKey == -1){
                // 单个物品类型
                List<AuctionItem> items = dbService.searchAuctionByGoodsType(
                        key.page * VariableConfig.AUCTION_EACH_PAGE_COUNT,
                        VariableConfig.AUCTION_EACH_PAGE_COUNT + 1,
                        key.goodsType, key.goodsQuality, key.goodsLevel,
                        key.sortType, key.goodsName, key.serverSequence);
                return replySearchAuctionGoods(items);
            }

            // 范围物品类型
            int lowKey = Utils.getHighShort(rangeKey);
            int highKey = Utils.getLowShort(rangeKey);

            List<AuctionItem> items = dbService.searchAuctionByGoodsTypeRange(
                    key.page * VariableConfig.AUCTION_EACH_PAGE_COUNT,
                    VariableConfig.AUCTION_EACH_PAGE_COUNT + 1, lowKey,
                    highKey, key.goodsQuality, key.goodsLevel, key.sortType,
                    key.goodsName, key.serverSequence);
            return replySearchAuctionGoods(items);
        }
    }

    // ----- 获取单个物品缓存 -----

    static class AuctionRealItemCacheLoader extends
            CacheLoader<Long, AuctionRealItem>{
        private final DBService dbService;

        AuctionRealItemCacheLoader(DBService dbService){
            this.dbService = dbService;
        }

        @Override
        public AuctionRealItem load(Long key) throws Exception{
            AuctionRealItem result = dbService.getAuctionItem(key.longValue());
            if (result == null){
                return AuctionRealItem.NULL_ITEM;
            }
            return result;
        }

    }
}
