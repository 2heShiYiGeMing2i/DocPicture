package app.game.module.auction;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.data.goods.GoodsData;
import app.game.data.goods.GoodsDatas;

import com.google.protobuf.InvalidProtocolBufferException;

public class AuctionRealItems{
    private static final Logger logger = LoggerFactory
            .getLogger(AuctionRealItems.class);

    private AuctionRealItems(){
    }

    public static AuctionRealItem parseMoney(int amount, int cost,
            long sellerID, byte[] sellerNameBytes){
        return new AuctionRealMoney(amount, cost, sellerID, sellerNameBytes);
    }

    public static AuctionRealItem parseYuanbao(int amount, int cost,
            long sellerID, byte[] sellerNameBytes){
        return new AuctionRealYuanbao(amount, cost, sellerID, sellerNameBytes);
    }

    public static AuctionRealItem parseGoods(GoodsDatas goodsDatas,
            int goodsID, byte[] goodsServerProto, int cost, long sellerID,
            byte[] sellerNameBytes){
        GoodsData goodsData = goodsDatas.get(goodsID);
        if (goodsData == null){
            logger.error("AuctionRealItems.parseGoods时, goodsID没找到: {}",
                    goodsID);
            return null;
        }

        try{
            return new AuctionRealGoods(goodsData, goodsServerProto, cost,
                    sellerID, sellerNameBytes);
        } catch (InvalidProtocolBufferException e){
            logger.error("AuctionRealItems.parseGoods.new AuctionRealGoods时出错",
                    e);
            return null;
        }
    }
}
