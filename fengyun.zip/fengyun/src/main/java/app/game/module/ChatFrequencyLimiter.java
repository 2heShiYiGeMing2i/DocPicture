package app.game.module;

public class ChatFrequencyLimiter{

    private final long durationPer2Chat;

    private long nextCanChatTime1;
    private long nextCanChatTime2;

    public ChatFrequencyLimiter(long durationPer2Chat){
        this.durationPer2Chat = durationPer2Chat;
    }

    public boolean canChat(long ctime){
        return ctime >= nextCanChatTime1;
    }

    public void chated(long ctime){
        nextCanChatTime1 = nextCanChatTime2;
        nextCanChatTime2 = ctime + durationPer2Chat;
    }

    public boolean chatIfCan(long ctime){
        if (canChat(ctime)){
            chated(ctime);
            return true;
        }
        return false;
    }
}
