/**
 * 
 */
package app.game.module;

import static com.mokylin.sink.util.BufferUtil.*;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.data.goods.Goods;
import app.game.data.goods.GoodsContainerUnlockData;
import app.game.entity.GoodsContainer;
import app.protobuf.PrizeContent.PrizeProto;

import com.mokylin.collection.IntArrayList;
import com.mokylin.sink.util.BufferUtil;

/**
 * @author Liwei
 * 
 */
public class GoodsContainerMessages{

    static final int MODULE_ID = Modules.GOODS_MODULE_ID;

    private GoodsContainerMessages(){
    }

    // 客户端服务器消息

    /**
     * 背包物品移动，发送C2S_MOVE_GOODS，附带以下信息
     * byte 操作类型：0-背包内移动 1-仓库内移动 2-背包向仓库移动 3-仓库向背包移动
     * varint32 原格子位置
     * varint32 目标格子位置
     * 操作成功后，服务器返回S2C_MOVE_GOODS，附带以下信息
     * byte 操作类型：0-背包内移动 1-仓库内移动 2-背包向仓库移动 3-仓库向背包移动
     * varint32 原格子位置
     * varint32 目标格子位置
     * varint32 count，堆叠个数
     * 
     * 失败返回S2C_MOVE_GOODS_FAIL，附带byte错误码.错误码详见后面的说明.
     */
    static final int C2S_MOVE_GOODS = 3;

    static final int S2C_MOVE_GOODS = 4;

    static final int S2C_MOVE_GOODS_FAIL = 5;

    public static enum MOVE_GOODS_RESULT{
        SUCCESS,

        /**
         * 客户端发送的type无效
         */
        TYPE_INVALID(1),

        /**
         * 客户端发送的源位置与目标位置相同
         */
        SOURCE_POS_EQUAL_TARGET_POS(2),

        /**
         * 客户端发送的源位置无效
         */
        SOURCE_POS_INVALID(3),

        /**
         * 客户端发送的目标位置无效
         */
        TARGET_POS_INVALID(4),

        /**
         * 客户端发送的源位置已经被锁定
         */
        SOURCE_POS_LOCKED(5),

        /**
         * 客户端发送的目标位置已经被锁定
         */
        TARGET_POS_LOCKED(6),

        /**
         * 客户端发送的源位置上面的物品不存在
         */
        SOURCE_POS_GOODS_NOT_FOUND(7),

        /**
         * 英雄还没有仓库
         */
        STORAGE_NOT_OPEN(8);

        private final ChannelBuffer errBuffer;

        private MOVE_GOODS_RESULT(){
            errBuffer = null;
        }

        private MOVE_GOODS_RESULT(int code){
            errBuffer = onlySendHeadAndAByteMessage(MODULE_ID,
                    S2C_MOVE_GOODS_FAIL, code);
        }

        public ChannelBuffer getMessage(){
            return errBuffer;
        }

        public ChannelBuffer getMessage(int type, int spos, int tpos, int count){
            if (errBuffer == null){
                return successMsg(type, spos, tpos, count);
            }

            return errBuffer;
        }

        private ChannelBuffer successMsg(int type, int spos, int tpos, int count){
            ChannelBuffer buffer = newFixedSizeMessage(
                    MODULE_ID,
                    S2C_MOVE_GOODS,
                    1 + BufferUtil.computeVarInt32Size(spos)
                            + BufferUtil.computeVarInt32Size(tpos)
                            + BufferUtil.computeVarInt32Size(count));
            buffer.writeByte(type);
            BufferUtil.writeVarInt32(buffer, spos);
            BufferUtil.writeVarInt32(buffer, tpos);
            BufferUtil.writeVarInt32(buffer, count);
            return buffer;
        }
    }

    /**
     * 背包拆分物品发送C2S_SPLIT_GOODS，附带以下信息
     * byte 操作类型：0-背包内拆分 1-仓库内拆分
     * varint32 原格子位置（拆分哪个）
     * varint32 目标格子位置（拆分到哪里）
     * varint32 拆分数量（拆分多少个出来）
     * 操作成功后，服务器返回S2C_SPLIT_GOODS，附带以下信息
     * byte 操作类型：0-背包内拆分 1-仓库内拆分
     * varint32 原格子位置（拆分哪个）
     * varint32 目标格子位置（拆分到哪里）
     * varint32 拆分数量（拆分多少个出来）
     * 
     * 失败返回S2C_SPLIT_GOODS_FAIL，附带byte错误码.错误码详见后面的说明.
     */
    static final int C2S_SPLIT_GOODS = 9;

    static final int S2C_SPLIT_GOODS = 10;

    static final int S2C_SPLIT_GOODS_FAIL = 11;

    public static enum SPLIT_GOODS_RESULT{
        SUCCESS,

        /**
         * 客户端发送的type无效
         */
        TYPE_INVALID(1),

        /**
         * 客户端发送的源位置与目标位置相同
         */
        SOURCE_POS_EQUAL_TARGET_POS(2),

        /**
         * 客户端发送的源位置无效
         */
        SOURCE_POS_INVALID(3),

        /**
         * 客户端发送的目标位置无效
         */
        TARGET_POS_INVALID(4),

        /**
         * 客户端发送的源位置已经被锁定
         */
        SOURCE_POS_LOCKED(5),

        /**
         * 客户端发送的源位置上面的物品不存在
         */
        SOURCE_POS_GOODS_NOT_FOUND(6),

        /**
         * 客户端发送的目标位置上面的物品已经存在
         */
        TARGET_POS_GOODS_EXIST(7),

        /**
         * 客户端发送的拆分数量错误，1、count <= 0 或者 count >= 源堆中的数量
         */
        SPLIT_COUNT_INVALID(8),

        /**
         * 英雄还没有仓库
         */
        STORAGE_NOT_OPEN(9);

        private final ChannelBuffer errBuffer;

        private SPLIT_GOODS_RESULT(){
            errBuffer = null;
        }

        private SPLIT_GOODS_RESULT(int code){
            errBuffer = onlySendHeadAndAByteMessage(MODULE_ID,
                    S2C_SPLIT_GOODS_FAIL, code);
        }

        public ChannelBuffer getMessage(){
            return errBuffer;
        }

        public ChannelBuffer getMessage(int type, int spos, int tpos, int count){
            if (errBuffer == null){
                return successMsg(type, spos, tpos, count);
            }

            return errBuffer;
        }

        private ChannelBuffer successMsg(int type, int spos, int tpos, int count){
            ChannelBuffer buffer = newFixedSizeMessage(
                    MODULE_ID,
                    S2C_SPLIT_GOODS,
                    1 + BufferUtil.computeVarInt32Size(spos)
                            + BufferUtil.computeVarInt32Size(tpos)
                            + BufferUtil.computeVarInt32Size(count));
            buffer.writeByte(type);
            BufferUtil.writeVarInt32(buffer, spos);
            BufferUtil.writeVarInt32(buffer, tpos);
            BufferUtil.writeVarInt32(buffer, count);
            return buffer;
        }
    }

    /**
     * 背包仓库整理发送C2S_CLEAN，附带以下信息
     * byte 操作类型：0-背包整理 1-仓库整理
     * 成功返回S2C_CLEAN_SUCCESS，附带以下信息
     * byte 操作类型：0-背包整理 1-仓库整理
     * varlong 下次可整理时间
     * for
     * varint32 未整理前所在的位置，根据这个位置读取物品信息
     * varint32 整理后对应下标的物品数量
     * 失败返回S2C_CLEAN_FAIL，附带byte错误码.错误码详见后面的说明.
     */
    static final int C2S_CLEAN = 12;

    static final int S2C_CLEAN_SUCCESS = 13;

    static final int S2C_CLEAN_FAIL = 14;

    public static enum CLEAN_GOODS_RESULT{
        SUCCESS,

        /**
         * 客户端发送的type无效
         */
        TYPE_INVALID(1),

        /**
         * 背包下次更新时间未到
         */
        DEPOT_CLEAN_TIME_NOT_REACHED(2),

        /**
         * 仓库下次更新时间未到
         */
        STORAGE_CLEAN_TIME_NOT_REACHED(3),

        /**
         * 背包已锁定
         */
        DEPOT_LOCKED(4),

        /**
         * 英雄还没有仓库
         */
        STORAGE_NOT_OPEN(5);

        private final ChannelBuffer errBuffer;

        private CLEAN_GOODS_RESULT(){
            errBuffer = null;
        }

        private CLEAN_GOODS_RESULT(int code){
            errBuffer = onlySendHeadAndAByteMessage(MODULE_ID, S2C_CLEAN_FAIL,
                    code);
        }

        public ChannelBuffer getMessage(){
            return errBuffer;
        }

        public ChannelBuffer getMessage(int type, long nextCanCleanTime,
                GoodsContainer gc){
            if (errBuffer == null){
                return successMsg(type, nextCanCleanTime, gc);
            }

            return errBuffer;
        }

        private ChannelBuffer successMsg(int type, long nextCanCleanTime,
                GoodsContainer gc){

            ChannelBuffer buffer = newDynamicMessage(MODULE_ID,
                    S2C_CLEAN_SUCCESS);
            buffer.writeByte(type);
            BufferUtil.writeVarInt64(buffer, nextCanCleanTime);
            for (int i = 0; i < gc.size(); i++){
                Goods g = gc.get(i);
                if (g == null){
                    break;
                }
                BufferUtil.writeVarInt32(buffer, g.pos);
                BufferUtil.writeVarInt32(buffer, g.getCount());
            }
            return buffer;
        }
    }

    /**
     * 手动解锁背包仓库格子发送C2S_DEPOT_STORAGE_OPEN_SLOT,附带以下信息
     * byte 类型 0-背包 1-仓库
     * varint32 开启格子的位置
     */
    static final int C2S_DEPOT_STORAGE_OPEN_SLOT = 17;

    /**
     * 成功返回S2C_DEPOT_STORAGE_OPEN_SLOT,附带以下信息.
     * byte 类型 0-背包 1-仓库
     * varint32 开启格子的位置
     * varint32 消耗的元宝
     * varint32 本行待解锁格子数据，只有每一行最后一个格子解锁的时候，这里才会发送Unlock数据
     * for
     *     varint32 GoodsContainerUnlockProto数据的长度
     *     bytes GoodsContainerUnlockProto 解锁数据
     * bytes SpriteStatProto 已累计获得的属性
     */
    static final int S2C_DEPOT_STORAGE_OPEN_SLOT = 18;

    /**
     * 失败返回S2C_DEPOT_STORAGE_OPEN_SLOT_FAIL，附带byte错误码.
     * 1、客户端发送的type无效
     * 2、占位，暂时没用
     * 3、客户端发送的解锁位置不合法，1、该位置已经被解锁了，2、该位置超出最大位置
     * 4、没有格子需要解锁，全部格子都解锁了
     * 5、元宝不足
     * 6、英雄还没有仓库
     * 
     */
    static final int S2C_DEPOT_STORAGE_OPEN_SLOT_FAIL = 19;

    static final ChannelBuffer ERR_OPEN_SLOT_FAIL_TYPE_INVALID = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_DEPOT_STORAGE_OPEN_SLOT_FAIL, 1);

    static final ChannelBuffer ERR_OPEN_SLOT_FAIL_UNLOCK_POS_INVALID = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_DEPOT_STORAGE_OPEN_SLOT_FAIL, 3);

    static final ChannelBuffer ERR_OPEN_SLOT_FAIL_SLOT_ALL_UNLOCKED = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_DEPOT_STORAGE_OPEN_SLOT_FAIL, 4);

    static final ChannelBuffer ERR_OPEN_SLOT_FAIL_YUANBAO_NOT_ENOUGH = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_DEPOT_STORAGE_OPEN_SLOT_FAIL, 5);

    static final ChannelBuffer ERR_OPEN_SLOT_FAIL_STORAGE_NOT_OPEN = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_DEPOT_STORAGE_OPEN_SLOT_FAIL, 6);

    static ChannelBuffer manualOpenSlotMsg(int type, int pos, int cost,
            GoodsContainerUnlockData unlockingData, byte[] accStat, long ctime){
        ChannelBuffer buffer = newDynamicMessage(MODULE_ID,
                S2C_DEPOT_STORAGE_OPEN_SLOT);
        buffer.writeByte(type);
        BufferUtil.writeVarInt32(buffer, pos);
        BufferUtil.writeVarInt32(buffer, cost);

        if (unlockingData != null){
            GoodsContainerUnlockData[] rowUnlockDatas = unlockingData.rowUnlockDatas;

            BufferUtil.writeVarInt32(buffer, rowUnlockDatas.length);
            for (int i = 0; i < rowUnlockDatas.length; i++){
                GoodsContainerUnlockData unlockData = rowUnlockDatas[i];
                BufferUtil.writeVarInt32(buffer,
                        unlockData.unlockDataProtoBytes.length);
                buffer.writeBytes(unlockData.unlockDataProtoBytes);

            }
        } else{
            BufferUtil.writeVarInt32(buffer, 0);
        }

        buffer.writeBytes(accStat);

        return buffer;
    }

    /**
     * 自动解锁格子发送S2C_DEPOT_STORAGE_AUTO_OPEN_SLOT,附带以下信息.
     * byte 类型 0-背包 1-仓库
     * varint32 开启格子的位置
     * varint32 本行待解锁格子数据，只有每一行最后一个格子解锁的时候，这里才会发送Unlock数据
     * for
     *     varint32 GoodsContainerUnlockProto数据的长度
     *     bytes GoodsContainerUnlockProto 解锁数据
     * bytes SpriteStatProto 已累计获得的属性
     */
    static final int S2C_DEPOT_STORAGE_AUTO_OPEN_SLOT = 20;

    static ChannelBuffer autoOpenSlotMsg(int type, int pos,
            GoodsContainerUnlockData unlockingData, byte[] accStat, long ctime){

        ChannelBuffer buffer = newDynamicMessage(MODULE_ID,
                S2C_DEPOT_STORAGE_AUTO_OPEN_SLOT);
        buffer.writeByte(type);
        BufferUtil.writeVarInt32(buffer, pos);

        if (unlockingData != null){

            GoodsContainerUnlockData[] rowUnlockDatas = unlockingData.rowUnlockDatas;

            BufferUtil.writeVarInt32(buffer, rowUnlockDatas.length);
            for (int i = 0; i < rowUnlockDatas.length; i++){
                GoodsContainerUnlockData unlockData = rowUnlockDatas[i];
                BufferUtil.writeVarInt32(buffer,
                        unlockData.unlockDataProtoBytes.length);
                buffer.writeBytes(unlockData.unlockDataProtoBytes);

            }
        } else{
            BufferUtil.writeVarInt32(buffer, 0);
        }

        buffer.writeBytes(accStat);

        return buffer;
    }

    /**
     * 获取仓库的数据，发送C2S_STORAGE_GET_DATA
     * 服务器返回S2C_STORAGE_GET_DATA，附带以下信息
     * bytes GoodsContainerProto仓库数据
     * 
     * 当英雄还没有仓库时，返回S2C_STORAGE_NOT_OPEN消息
     * 
     * 注意：S2C_STORAGE_GET_DATA消息服务器只会返回一次
     */
    static final int C2S_DEPOT_STORAGE_GET_DATA = 21;

    static final int S2C_DEPOT_STORAGE_GET_DATA = 22;

    static final int S2C_STORAGE_NOT_OPEN = 23;

    static ChannelBuffer getStorageDataMsg(byte[] storageData){

        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID,
                S2C_DEPOT_STORAGE_GET_DATA, storageData.length);
        buffer.writeBytes(storageData);

        return buffer;
    }

    static final ChannelBuffer STORAGE_NOT_OPEN = onlySendHeaderMessage(
            MODULE_ID, S2C_STORAGE_NOT_OPEN);

    /**
     * 给英雄开放仓库时发生这条消息，收到这条消息后，客户端可以显示仓库按钮，可以使用仓库
     */
    static final int S2C_OPEN_STORAGE = 24;

    static final ChannelBuffer OPEN_STORAGE_MESSAGE = onlySendHeaderMessage(
            MODULE_ID, S2C_OPEN_STORAGE);

    // ------------------- 服务器推送消息

    /**
     * 客户端收到S2C_ADD_GOODS消息，在背包或者仓库中添加一个物品，该消息附带以下信息
     * byte 类型 0-背包 1-仓库
     * for (byteArray.avaliable)
     *     varint32 位置
     *     varint32 静态数据大小
     *     bytes 物品静态数据，第一个byte表示物品类型
     *     varint32 动态数据大小
     *     bytes 物品动态数据
     */
    static final int S2C_ADD_GOODS = 25;

    static ChannelBuffer addGoodsMsg(int type, int pos, Goods g){
        byte[] goodsDataBytes = g.getData().getProtoBytes();
        byte[] goodsBytes = g.encodeBytes4Client();

        ChannelBuffer buffer = newFixedSizeMessage(
                MODULE_ID,
                S2C_ADD_GOODS,
                1 + BufferUtil.computeVarInt32Size(pos)
                        + BufferUtil.computeVarInt32Size(goodsDataBytes.length)
                        + goodsDataBytes.length
                        + BufferUtil.computeVarInt32Size(goodsBytes.length)
                        + goodsBytes.length);
        buffer.writeByte(type);
        BufferUtil.writeVarInt32(buffer, pos);
        BufferUtil.writeVarInt32(buffer, goodsDataBytes.length);
        buffer.writeBytes(goodsDataBytes);
        BufferUtil.writeVarInt32(buffer, goodsBytes.length);
        buffer.writeBytes(goodsBytes);
        return buffer;
    }

    static ChannelBuffer addGoodsListMsg(int type, int count, Goods[] toAdds){

        ChannelBuffer buffer = newDynamicMessage(MODULE_ID, S2C_ADD_GOODS);
        buffer.writeByte(type);

        for (int i = 0; i < count; i++){
            Goods g = toAdds[i];
            int pos = g.pos;

            byte[] goodsDataBytes = g.getData().getProtoBytes();
            byte[] goodsBytes = g.encodeBytes4Client();

            BufferUtil.writeVarInt32(buffer, pos);
            BufferUtil.writeVarInt32(buffer, goodsDataBytes.length);
            buffer.writeBytes(goodsDataBytes);
            BufferUtil.writeVarInt32(buffer, goodsBytes.length);
            buffer.writeBytes(goodsBytes);
        }
        return buffer;
    }

    /**
     * 客户端收到S2C_CHANGE_GOODS_COUNT消息，在背包或者仓库中修改一个或者多个物品的个数，该消息附带以下信息
     * byte 类型 0-背包 1-仓库
     * if (byteArray.avaliable)
     *     varint32 位置
     *     varint32 新数量（如果数量为0，则客户端移除该位置的物品）
     */
    static final int S2C_SET_GOODS_COUNT = 27;

    public static ChannelBuffer setGoodsCountMsg(int type, int pos, int count){
        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID,
                S2C_SET_GOODS_COUNT, 1 + BufferUtil.computeVarInt32Size(pos)
                        + BufferUtil.computeVarInt32Size(count));
        buffer.writeByte(type);
        BufferUtil.writeVarInt32(buffer, pos);
        BufferUtil.writeVarInt32(buffer, count);
        return buffer;
    }

    static ChannelBuffer getSetGoodsCountBuffer(int type, int count){

        ChannelBuffer buffer = newDynamicMessage(MODULE_ID,
                S2C_SET_GOODS_COUNT, count * 4);
        buffer.writeByte(type);

        return buffer;
    }

    /**
     * 背包或者仓库物品移除一个或者多个物品时，收到此消息，附带以下信息
     * byte 类型 0-背包 1-仓库
     * if (byteArray.avaliable)
     *     varint32 物品的位置
     * 客户端收到这条消息时，移除物品
     */
    static final int S2C_REMOVE_GOODS = 28;

    public static ChannelBuffer removeGoodsMsg(int type, int pos){

        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID, S2C_REMOVE_GOODS,
                1 + BufferUtil.computeVarInt32Size(pos));
        buffer.writeByte(type);
        BufferUtil.writeVarInt32(buffer, pos);
        return buffer;
    }

    static ChannelBuffer getRemoveGoodsBuffer(int type){

        ChannelBuffer buffer = newDynamicMessage(MODULE_ID, S2C_REMOVE_GOODS);
        buffer.writeByte(type);

        return buffer;
    }

    static ChannelBuffer removeGoodsMsg(int type, IntArrayList posList,
            int count){
        assert count <= posList.size();

        ChannelBuffer buffer = getRemoveGoodsBuffer(type);

        for (int i = 0; i < count; i++){
            BufferUtil.writeVarInt32(buffer, posList.get(i));
        }

        return buffer;
    }

    /**
     * 丢弃物品，客户端先判断物品是否可以丢弃，是否处于安全区等限制，判断通过后，发送C2S_DROP_GOODS消息，
     * 附带丢弃物品的格子位置pos，物品ID，此时客户端需要锁定背包面板，等待服务器返回消息后才可以继续操作背包
     * 在收到确认消息之前，会先收到背包物品移除消息，此时客户端根据此消息将物品移除
     * 
     * 然后客户端会收到物品视野相关的消息，具体参考物品视野文档
     * 
     * 丢弃物品发送C2S_DROP_GOODS，附带以下信息
     * varint32 丢弃的物品位置
     * varint32 goodsId 防御性，防止客户端与服务器数据不一致，导致丢掉了重要物品
     * 成功返回S2C_DROP_GOODS，该消息只有消息头，解锁面板
     * 
     * 失败返回S2C_DROP_GOODS_FAIL，详见消息说明.
     * 解锁面板
     */
    static final int C2S_DROP_GOODS = 29;

    static final int S2C_DROP_GOODS = 30;

    /**
     * 1、客户端发送的位置无效
     * 2、客户端发送的位置上没有物品
     * 3、客户端发送的位置上的物品ID，与客户端发送的物品ID不同
     * 4、物品不能丢弃
     * 5、处于安全区，不能丢弃物品
     * 6、跳跃中，不能丢弃物品
     * 7、物品已过期，不能丢弃物品
     * 8、英雄挂了，不能丢弃物品
     * 9、物品已经被锁定，不能丢弃物品
     * 10. 跨服区域不能丢物品
     */
    static final int S2C_DROP_GOODS_FAIL = 31;

    static final ChannelBuffer DROP_GOODS_SUCCESS = dropGoodsMsg();

    static final ChannelBuffer ERR_DROP_GOODS_FAIL_INVALID_POS = dropGoodsFailMsg(1);
    static final ChannelBuffer ERR_DROP_GOODS_FAIL_GOODS_NOT_FOUND = dropGoodsFailMsg(2);
    static final ChannelBuffer ERR_DROP_GOODS_FAIL_INVALID_GOODS_ID = dropGoodsFailMsg(3);
    static final ChannelBuffer ERR_DROP_GOODS_FAIL_GOODS_CAN_NOT_DROP = dropGoodsFailMsg(4);
    static final ChannelBuffer ERR_DROP_GOODS_FAIL_SAFE_AREA = dropGoodsFailMsg(5);
    static final ChannelBuffer ERR_DROP_GOODS_FAIL_JUMPING = dropGoodsFailMsg(6);
    static final ChannelBuffer ERR_DROP_GOODS_FAIL_EXPIRED = dropGoodsFailMsg(7);
    static final ChannelBuffer ERR_DROP_GOODS_FAIL_YOU_ARE_DEAD = dropGoodsFailMsg(8);
    static final ChannelBuffer ERR_DROP_GOODS_FAIL_GOODS_LOCKED = dropGoodsFailMsg(9);
    static final ChannelBuffer ERR_DROP_GOODS_FAIL_IN_CLUSTER = dropGoodsFailMsg(10);

    static ChannelBuffer dropGoodsMsg(){
        return onlySendHeaderMessage(MODULE_ID, S2C_DROP_GOODS);
    }

    static ChannelBuffer dropGoodsFailMsg(int errCode){
        return onlySendHeadAndAByteMessage(MODULE_ID, S2C_DROP_GOODS_FAIL,
                errCode);
    }

    /**
     * 使用物品发送C2S_USE_GOODS，附带以下信息
     * varint32 物品位置（背包中）
     * varint32 使用数量
     * 
     * 失败返回S2C_USE_GOODS_FAIL，附带byte错误码.错误码详见消息的说明.
     */
    static final int C2S_USE_GOODS = 50;

    /**
     * 使用物品成功，附带以下信息
     * varint32 物品位置（背包中）
     * varint32 该位置剩余数量（如果是0，则移除该位置物品）
     */
    static final int S2C_USE_GOODS = 51;

    /**
     * 有以下几种情况
     * 1、客户端发送的背包位置无效
     * 2、客户端发送的位置上没有物品
     * 3、物品不能使用（如装备）
     * 4、物品不能批量使用（客户端发送的数量大于1）
     * 5、物品个数不足（物品只有五个，客户端说要用6个）
     * 6、物品使用等级不足
     * 7、物品已经过期
     * 8、物品CD中
     * 9、英雄已经挂了
     * 10、物品已经被锁定，不能使用
     * 
     * --包裹
     * 11、打开包裹所需空间不足，后面在读一个varint32，表示需要的空格数
     * 
     * 15、打开元宝礼包，元宝不足
     * 16、打开元宝礼包，背包空位不足
     * 
     * 17、使用传说卡，对应系统未激活
     * 18、使用传说卡，背包空位不足
     * 
     * --传送卷轴
     * 30、传送失败
     * 31、当前等级还不能进入目标场景
     * 32、当前帮派不是无双城占领帮派
     * 33、攻城战期间不能传送
     * 
     * --任务卷轴
     * 50、英雄未完成第二章主线任务
     * 51、今日接受任务个数已达最大个数
     * 52、当前机缘任务列表个数已达最大个数
     * 
     * --药品
     * 60、PK值为0，不能使用物品减少PK值
     * 61、加Buff类物品，英雄的Buff已满
     * 62、使用经验丹，但是等级已满
     * 63、使用真气丹，但是真气已满
     * 64、使用银两物品，但是银两已满
     * 65、使用礼金物品，但是礼金已满
     * 66、使用帮派历练物品，但是帮派历练已满
     * 67、使用加帮贡物品，但是不在帮派中
     * 68、使用限制个数的物品，但是已经达到使用上限
     * 69、使用升级物品（大还丹），但是英雄已经满级了
     * 
     * --坐骑技能书 
     * 70、英雄还没有坐骑
     * 71、坐骑等级不足
     * 72、坐骑还没有技能格子
     * 
     * 73、英雄还没有宠物或者没有技能格子
     * 
     * 74、英雄还没有天劫，天劫等级不足或者没有技能格子
     * 
     * 75、英雄还没有天罪，天罪等级不足或者没有技能格子
     * 
     * 76、英雄技能，不是你这个职业学的
     * 77、英雄技能，这个技能已经学会了
     * 78、英雄技能，没有学会这个技能的前置技能（还没有学会1级就想学2级技能）
     * 
     * 79、神兵心法，英雄还没有激活这把神兵
     * 80、神兵心法，英雄已经激活过了这个心法
     * 
     */
    static final int S2C_USE_GOODS_FAIL = 52;

    static final ChannelBuffer ERR_USE_GOODS_POS_INVALID = useGoodsFailMsg(1);
    static final ChannelBuffer ERR_USE_GOODS_NOT_FOUND = useGoodsFailMsg(2);
    public static final ChannelBuffer ERR_USE_GOODS_CAN_NOT_TO_USE = useGoodsFailMsg(3);
    static final ChannelBuffer ERR_USE_GOODS_CAN_NOT_BULK_USE = useGoodsFailMsg(4);
    static final ChannelBuffer ERR_USE_GOODS_COUNT_NOT_ENOUGH = useGoodsFailMsg(5);
    public static final ChannelBuffer ERR_USE_GOODS_LEVEL_NOT_ENOUGH = useGoodsFailMsg(6);
    static final ChannelBuffer ERR_USE_GOODS_EXPIRED = useGoodsFailMsg(7);
    static final ChannelBuffer ERR_USE_GOODS_COOL_DOWN = useGoodsFailMsg(8);
    static final ChannelBuffer ERR_USE_GOODS_YOU_ARE_DEAD = useGoodsFailMsg(9);
    static final ChannelBuffer ERR_USE_GOODS_POS_LOCKED = useGoodsFailMsg(10);

    public static final ChannelBuffer ERR_USE_YB_PACKAGE_YB_NOT_ENOUGH = useGoodsFailMsg(15);
    public static final ChannelBuffer ERR_USE_YB_PACKAGE_NOT_EMPTY_POS = useGoodsFailMsg(16);

    public static final ChannelBuffer ERR_USE_LEGEND_CARD_NOT_OPEN = useGoodsFailMsg(17);
    public static final ChannelBuffer ERR_USE_LEGEND_CARD_NOT_EMPTY_POS = useGoodsFailMsg(18);

    public static final ChannelBuffer ERR_USE_TP_FAIL = useGoodsFailMsg(30);
    public static final ChannelBuffer ERR_USE_TP_FAIL_LEVEL_NOT_ENOUGH = useGoodsFailMsg(31);
    public static final ChannelBuffer ERR_USE_TP_FAIL_NOT_CITY_MASTER = useGoodsFailMsg(32);
    public static final ChannelBuffer ERR_USE_TP_FAIL_BATTLE = useGoodsFailMsg(33);

    public static final ChannelBuffer ERR_USE_TASK_BOOK_FAIL_NOT_OPEN = useGoodsFailMsg(50);
    public static final ChannelBuffer ERR_USE_TASK_BOOK_FAIL_ACCEPT_TIMES_LIMIT = useGoodsFailMsg(51);
    public static final ChannelBuffer ERR_USE_TASK_BOOK_FAIL_TASK_LIST_IS_FULL = useGoodsFailMsg(52);

    public static final ChannelBuffer ERR_USE_MEDICINE_FAIL_ZERO_PK_AMOUNT = useGoodsFailMsg(60);
    public static final ChannelBuffer ERR_USE_MEDICINE_FAIL_BUFF_FULL = useGoodsFailMsg(61);
    public static final ChannelBuffer ERR_USE_EXP_MEDICINE_FAIL_LEVEL_FULL = useGoodsFailMsg(62);
    public static final ChannelBuffer ERR_USE_MEDICINE_FAIL_REAL_AIR_FULL = useGoodsFailMsg(63);
    public static final ChannelBuffer ERR_USE_MEDICINE_FAIL_MONEY_FULL = useGoodsFailMsg(64);
    public static final ChannelBuffer ERR_USE_MEDICINE_FAIL_LIJIN_FULL = useGoodsFailMsg(65);
    public static final ChannelBuffer ERR_USE_MEDICINE_FAIL_GUILD_LILIAN_FULL = useGoodsFailMsg(66);
    public static final ChannelBuffer ERR_USE_MEDICINE_FAIL_NOT_IN_GUILD = useGoodsFailMsg(67);
    public static final ChannelBuffer ERR_USE_MEDICINE_FAIL_COUNT_LIMIT = useGoodsFailMsg(68);
    public static final ChannelBuffer ERR_USE_LEVEL_MEDICINE_FAIL_LEVEL_FULL = useGoodsFailMsg(69);

    public static final ChannelBuffer ERR_USE_SPELL_BOOK_FAIL_NOT_MOUNT = useGoodsFailMsg(70);
    public static final ChannelBuffer ERR_USE_SPELL_BOOK_FAIL_MOUNT_LEVEL_NOT_ENOUGH = useGoodsFailMsg(71);
    public static final ChannelBuffer ERR_USE_SPELL_BOOK_FAIL_NOT_MOUNT_SLOT = useGoodsFailMsg(72);
    public static final ChannelBuffer ERR_USE_SPELL_BOOK_FAIL_NOT_PET_OR_SLOT = useGoodsFailMsg(73);
    public static final ChannelBuffer ERR_USE_SPELL_BOOK_FAIL_NOT_TIAN_JIE_OR_SLOT = useGoodsFailMsg(74);
    public static final ChannelBuffer ERR_USE_SPELL_BOOK_FAIL_NOT_TIAN_ZUI_OR_SLOT = useGoodsFailMsg(75);
    public static final ChannelBuffer ERR_USE_SPELL_BOOK_FAIL_INVALID_RACE = useGoodsFailMsg(76);
    public static final ChannelBuffer ERR_USE_SPELL_BOOK_FAIL_HAS_LEARNED = useGoodsFailMsg(77);
    public static final ChannelBuffer ERR_USE_SPELL_BOOK_FAIL_PREV_SPELL_NOT_LEARNED = useGoodsFailMsg(78);
    public static final ChannelBuffer ERR_USE_SPELL_BOOK_FAIL_WEAPON_HAS_LEARNED = useGoodsFailMsg(80);

    static ChannelBuffer useGoodsMsg(int pos, int count){

        ChannelBuffer buffer = newFixedSizeMessage(
                MODULE_ID,
                S2C_USE_GOODS,
                BufferUtil.computeVarInt32Size(pos)
                        + BufferUtil.computeVarInt32Size(count));
        BufferUtil.writeVarInt32(buffer, pos);
        BufferUtil.writeVarInt32(buffer, count);
        return buffer;
    }

    static ChannelBuffer useGoodsFailMsg(int errCode){
        return onlySendHeadAndAByteMessage(MODULE_ID, S2C_USE_GOODS_FAIL,
                errCode);
    }

    public static ChannelBuffer usePackageGoodsEmptyPosNotEnoughMsg(int count){
        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID,
                S2C_USE_GOODS_FAIL, 1 + BufferUtil.computeVarInt32Size(count));
        buffer.writeByte(11);
        BufferUtil.writeVarInt32(buffer, count);
        return buffer;
    }

    /**
     * 物品冷却，附带
     * varint32 goodsId
     * varint32 冷却时间，单位毫秒，3000表示收到这个消息后，冷却时间转3秒
     */
    static final int S2C_GOODS_COOLDOWN = 53;

    static ChannelBuffer goodsCooldownMsg(int goodsId, int cd){

        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID,
                S2C_GOODS_COOLDOWN, BufferUtil.computeVarInt32Size(goodsId)
                        + BufferUtil.computeVarInt32Size(cd));

        BufferUtil.writeVarInt32(buffer, goodsId);
        BufferUtil.writeVarInt32(buffer, cd);
        return buffer;
    }

    /**
     * 物品层级冷却，附带
     * varint32 type 冷却层级
     * varint32 冷却时间，单位毫秒，3000表示收到这个消息后，冷却时间转3秒
     */
    static final int S2C_GOODS_TYPE_COOLDOWN = 54;

    static ChannelBuffer goodsTypeCooldownMsg(int cdType, int cd){

        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID,
                S2C_GOODS_TYPE_COOLDOWN, BufferUtil.computeVarInt32Size(cdType)
                        + BufferUtil.computeVarInt32Size(cd));

        BufferUtil.writeVarInt32(buffer, cdType);
        BufferUtil.writeVarInt32(buffer, cd);
        return buffer;
    }

    /**
     * 请求元宝礼包奖励物品
     * varint32 goodsId
     * 
     * 每个物品请求过后换成到客户端，下次需要的时候不要再请求
     */
    static final int C2S_YUANBAO_PACKAGE_SHOW_GOODS = 55;

    /**
     * 请求元宝礼包奖励物品
     * varint32 goodsId
     * bytes PrizeProto
     */
    static final int S2C_YUANBAO_PACKAGE_SHOW_GOODS = 56;

    public static ChannelBuffer getYuanbaoPackageShowGoods(int goodsId,
            PrizeProto proto){

        byte[] data = proto.toByteArray();

        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID,
                S2C_YUANBAO_PACKAGE_SHOW_GOODS, computeVarInt32Size(goodsId)
                        + data.length);

        writeVarInt32(buffer, goodsId);
        buffer.writeBytes(data);

        return buffer;
    }

    public static enum ReduceCooldownGoodsResult{
        // 改变或新增时, 扣喇叭,扣复活道具处也要改
        SUCCESS, COOL_DOWN, GOODS_NOT_FOUND;
    }

}
