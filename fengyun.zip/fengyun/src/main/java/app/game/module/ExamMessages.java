package app.game.module;

import static com.mokylin.sink.util.BufferUtil.*;

import org.jboss.netty.buffer.ChannelBuffer;

import app.protobuf.ConfigContent.ExamQuestionProto;

/**
 * @author Liwei
 *
 */
public class ExamMessages{

    public static final int MODULE_ID = Modules.EXAM_MODULE_ID;

    private ExamMessages(){
    }

    /**
     * 问题更新，广播全服
     * 
     * 客户端收到这个消息时，如果英雄可以答题，则发送消息请求最新的题目
     */
    static final int S2C_EXAM_QUESTION_UPDATE = 0;

    static final ChannelBuffer EXAM_QUESTION_UPDATE = onlySendHeaderMessage(
            MODULE_ID, S2C_EXAM_QUESTION_UPDATE);

    /**
     * 请求最新的题目
     */
    static final int C2S_EXAM_GET_QUESTION = 1;

    /**
     * 请求最新的题目
     * bytes ExamQuestionProto
     * 
     * 注意，该消息已被压缩，读取之前先解压一下
     */
    static final int S2C_EXAM_GET_QUESTION = 2;

    /**
     * 请求最新题目失败，附带byte错误码
     * 1、答题还未开始或者已经结束
     * 2、英雄等级不足
     */
    static final int S2C_EXAM_GET_QUESTION_FAIL = 3;

    static final ChannelBuffer ERR_EXAM_GET_QUESTION_FAIL_UNACTIVE = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_EXAM_GET_QUESTION_FAIL, 1);

    static final ChannelBuffer ERR_EXAM_GET_QUESTION_FAIL_LEVEL_NOT_ENOUGH = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_EXAM_GET_QUESTION_FAIL, 2);

    /**
     * 回答问题
     * varint32 answer
     * 
     * answerIndex答案索引，从0开始
     * isDoubleScore 双倍积分，1表示双倍，0表示单倍
     * answer = (answerIndex << 1) | isDoubleScore;
     */
    static final int C2S_EXAM_ANSWER_QUESTION = 4;

    /**
     * 回答问题成功
     * if (byteArray.available) // 后面还有数据，说明回答正确
     *     varint32 英雄积分
     *     varint32 获得的经验
     *     varint32 获得的银两
     *     varint32 获得的真气
     */
    static final int S2C_EXAM_ANSWER_QUESTION = 5;

    static final ChannelBuffer ANSWER_WRONG_MSG = onlySendHeaderMessage(
            MODULE_ID, S2C_EXAM_ANSWER_QUESTION);

    /**
     * 回答问题失败，附带byte错误码
     * 1、英雄等级不足
     * 2、当前不是答题阶段
     * 3、这道题已经回答过了
     * 4、双倍积分次数不足
     * 5、答案索引无效（0-3）
     * 6、已经花钱完成过了
     */
    static final int S2C_EXAM_ANSWER_QUESTION_FAIL = 6;

    static final ChannelBuffer ERR_ANSWER_QUESTION_FAIL_LEVEL_NOT_ENOUGH = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_EXAM_ANSWER_QUESTION_FAIL, 1);

    static final ChannelBuffer ERR_ANSWER_QUESTION_FAIL_INVALID_ANSWER_TIME = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_EXAM_ANSWER_QUESTION_FAIL, 2);

    static final ChannelBuffer ERR_ANSWER_QUESTION_FAIL_ANSWERED = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_EXAM_ANSWER_QUESTION_FAIL, 3);

    static final ChannelBuffer ERR_ANSWER_QUESTION_FAIL_CANT_USE_DOUBLE_SCORE = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_EXAM_ANSWER_QUESTION_FAIL, 4);

    static final ChannelBuffer ERR_ANSWER_QUESTION_FAIL_CANT_INVALID_ANSWER = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_EXAM_ANSWER_QUESTION_FAIL, 5);

    static final ChannelBuffer ERR_ANSWER_QUESTION_FAIL_PAYBACK = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_EXAM_ANSWER_QUESTION_FAIL, 6);

    /**
     * 去除错误答案
     */
    static final int C2S_EXAM_REMOVE_WRONG_ANSWER = 7;

    /**
     * 去除错误答案成功
     * 
     * 客户端自己将去除错误次数-1
     */
    static final int S2C_EXAM_REMOVE_WRONG_ANSWER = 8;

    static final ChannelBuffer REMOVE_WRONG_ANSWER = onlySendHeaderMessage(
            MODULE_ID, S2C_EXAM_REMOVE_WRONG_ANSWER);

    /**
     * 去除错误答案失败，附带byte错误码
     * 1、英雄等级不足
     * 2、当前不是答题阶段
     * 3、这道题已经回答过了
     * 4、去除错误答案次数不足
     * 5、已经花钱完成过了
     */
    static final int S2C_EXAM_REMOVE_WRONG_ANSWER_FAIL = 9;

    static final ChannelBuffer ERR_REMOVE_WRONG_ANSWER_FAIL_LEVEL_NOT_ENOUGH = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_EXAM_REMOVE_WRONG_ANSWER_FAIL, 1);

    static final ChannelBuffer ERR_REMOVE_WRONG_ANSWER_FAIL_INVALID_ANSWER_TIME = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_EXAM_REMOVE_WRONG_ANSWER_FAIL, 2);

    static final ChannelBuffer ERR_REMOVE_WRONG_ANSWER_FAIL_ANSWERED = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_EXAM_REMOVE_WRONG_ANSWER_FAIL, 3);

    static final ChannelBuffer ERR_REMOVE_WRONG_ANSWER_FAIL_CANT_REMOVE_WRONG = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_EXAM_REMOVE_WRONG_ANSWER_FAIL, 4);

    static final ChannelBuffer ERR_REMOVE_WRONG_ANSWER_FAIL_PAYBACK = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_EXAM_REMOVE_WRONG_ANSWER_FAIL, 5);

    /**
     * 获取英雄答题数据
     */
    static final int C2S_EXAM_SELF_DATA = 10;

    /**
     * 获取英雄答题数据成功
     * varint32 答到第几题，0表示一题都没回答
     * varint32 双倍积分使用次数
     * varint32 排错使用次数
     * varint32 答题积分
     */
    static final int S2C_EXAM_SELF_DATA = 11;

    static final ChannelBuffer EMPTY_SELF_DATA_MSG = getSelfDataMsg(0, 0, 0, 0);

    /**
     * 获取英雄数据失败，附带byte错误码
     * 1、答题还未开始或者已经结束
     * 2、英雄等级不足
     * 3、已经花钱完成过了
     */
    static final int S2C_EXAM_SELF_DATA_FAIL = 12;

    static final ChannelBuffer ERR_EXAM_SELF_DATA_FAIL_UNACTIVE = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_EXAM_SELF_DATA_FAIL, 1);

    static final ChannelBuffer ERR_EXAM_SELF_DATA_FAIL_LEVEL_NOT_ENOUGH = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_EXAM_SELF_DATA_FAIL, 2);

    static final ChannelBuffer ERR_EXAM_SELF_DATA_FAIL_PAYBACK = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_EXAM_SELF_DATA_FAIL, 3);

    /**
     * 更新双倍积分次数
     * varint32 已使用双倍积分次数
     */
    static final int S2C_EXAM_DOUBLE_SCORE_TIMES = 13;

    /**
     * 答题结束广播
     * if (byteArray.available) // 如果没有数据，则说明没有第一名，不用提示了
     *     varint64 heroID
     *     bytes 第一名名字
     */
    static final int S2C_EXAM_FINISH_BROADCAST = 14;

    static final ChannelBuffer EMPTY_EXAM_FINISHED_MSG = onlySendHeaderMessage(
            MODULE_ID, S2C_EXAM_FINISH_BROADCAST);

    /**
     * 获取英雄答题数据
     */
    static final int C2S_EXAM_DIALOG_MSG = 15;

    /**
     * 获取英雄答题数据成功
     * varint32 积分
     * varint32 排名，从1开始，0表示未上榜（20+）
     * varint32 累计获得经验
     * varint32 累计获得银两
     * varint32 累计获得真气
     * 
     * 客户端根据排名自己判断是否有礼包
     */
    static final int S2C_EXAM_DIALOG_MSG = 16;

    static final ChannelBuffer EMPTY_DIALOG_MSG = getDialogMsg(0, 0, 0, 0, 0);

    // -------- 构建消息 ----------

    static ChannelBuffer getExamQuestionMsg(ExamQuestionProto proto){

        return getCompressedMessage(MODULE_ID, S2C_EXAM_GET_QUESTION,
                proto.toByteArray(), true);
    }

    static ChannelBuffer answerQuestionMsg(int score, int toAddExp,
            int toAddMoney, int toAddRealAir){
        return onlySendHeadAnd4VarInt32Message(MODULE_ID,
                S2C_EXAM_ANSWER_QUESTION, score, toAddExp, toAddMoney,
                toAddRealAir);
    }

    static ChannelBuffer getSelfDataMsg(int answeredQuestion,
            int useDoubleScoreTimes, int removeWrongAnswerTimes, int score){
        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID,
                S2C_EXAM_SELF_DATA, computeVarInt32Size(answeredQuestion)
                        + computeVarInt32Size(useDoubleScoreTimes)
                        + computeVarInt32Size(removeWrongAnswerTimes)
                        + computeVarInt32Size(score));

        writeVarInt32(buffer, answeredQuestion);
        writeVarInt32(buffer, useDoubleScoreTimes);
        writeVarInt32(buffer, removeWrongAnswerTimes);
        writeVarInt32(buffer, score);

        return buffer;
    }

    static ChannelBuffer useDoubleScoreTimesMsg(int times){
        return onlySendHeadAndAVarInt32Message(MODULE_ID,
                S2C_EXAM_DOUBLE_SCORE_TIMES, times);
    }

    static ChannelBuffer examFinishedMsg(long heroId, byte[] name){
        return onlySendHeadAndAVarInt64WithBytesMessage(MODULE_ID,
                S2C_EXAM_FINISH_BROADCAST, heroId, name);
    }

    static ChannelBuffer getDialogMsg(int score, int rankPos, int accExp,
            int accMoney, int accRealAir){
        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID,
                S2C_EXAM_DIALOG_MSG, computeVarInt32Size(score)
                        + computeVarInt32Size(rankPos)
                        + computeVarInt32Size(accExp)
                        + computeVarInt32Size(accMoney)
                        + computeVarInt32Size(accRealAir));

        writeVarInt32(buffer, score);
        writeVarInt32(buffer, rankPos);
        writeVarInt32(buffer, accExp);
        writeVarInt32(buffer, accMoney);
        writeVarInt32(buffer, accRealAir);

        return buffer;
    }
}
