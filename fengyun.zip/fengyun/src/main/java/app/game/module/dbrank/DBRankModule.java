package app.game.module.dbrank;

import static app.game.module.dbrank.DBRankMessages.*;
import static app.protobuf.LogContent.LogEnum.OperateType.RANK_ADMIRE;
import static com.mokylin.sink.util.BufferUtil.*;

import java.sql.SQLException;
import java.util.Arrays;
import java.util.concurrent.TimeUnit;

import org.jboss.netty.buffer.ChannelBuffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.data.ConfigService;
import app.game.data.HeroLevelData;
import app.game.data.ServerData;
import app.game.entity.Hero;
import app.game.module.HeroController;
import app.game.module.guild.GuildModule;
import app.game.service.DBService;
import app.game.service.IThreadService;
import app.game.service.MySQLDBService;
import app.game.service.TimeService;
import app.message.ISender;
import app.utils.IndividualServerConfig;
import app.utils.VariableConfig;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.google.inject.Inject;
import com.mokylin.sink.util.BufferUtil;
import com.mokylin.sink.util.Utils;

public class DBRankModule{
    private static final Logger logger = LoggerFactory
            .getLogger(DBRankModule.class);

    private final DBService dbService;

    private final IThreadService threadService;

    private final GuildModule guildModule;

    private final DBRankQueue rankQueue;

    private final TimeService timeService;

    private transient final int selfRankListUpCount;

    private final LoadingCache<RankCacheKey, ChannelBuffer> rankNumMsgCache;

    private final LoadingCache<SelfRankKey, Integer> selfRankPosCache;

    private final LoadingCache<SelfRankKey, ChannelBuffer> rankAroundMeCache;

    private final LoadingCache<SearchRankKey, ChannelBuffer> searchRankCache;

    private final RankType[] ranks;

    /**
     * 每一个服, 每一个排行榜, 总共有多少页
     */
    private final int[][] totalPages;

    private final LoadingCache<Integer, ChannelBuffer> topRankMsg;

    @Inject
    DBRankModule(final DBService dbService, final IThreadService threadService,
            DBRankQueue dbRankQueue, ConfigService configService,
            TimeService timeService, final GuildModule guildModule,
            IndividualServerConfig individualServerConfig){
        this.rankQueue = dbRankQueue;
        this.dbService = dbService;
        this.guildModule = guildModule;
        this.threadService = threadService;
        this.selfRankListUpCount = VariableConfig.RANK_PER_PAGE / 2;
        this.timeService = timeService;

        this.ranks = new RankType[]{RankType.LEVEL, RankType.FIGHT_AMOUNT,
                RankType.MOUNT, RankType.BOW, RankType.ADMIRE,
                RankType.TIAN_ZUI, RankType.TIAN_JIE};

        this.totalPages = new int[ranks.length][individualServerConfig
                .getServerDatas().length + 1];

        this.rankNumMsgCache = CacheBuilder.newBuilder().concurrencyLevel(8)
                .maximumSize(4096)
                .build(new CacheLoader<RankCacheKey, ChannelBuffer>(){

                    @Override
                    public ChannelBuffer load(RankCacheKey key)
                            throws Exception{
                        return key.call();
                    }
                });

        this.selfRankPosCache = CacheBuilder.newBuilder().concurrencyLevel(8)
                .maximumSize(4096)
                .build(new CacheLoader<SelfRankKey, Integer>(){

                    @Override
                    public Integer load(SelfRankKey key) throws Exception{
                        return key.loadMyRank();
                    }
                });

        this.rankAroundMeCache = CacheBuilder.newBuilder().concurrencyLevel(8)
                .maximumSize(4096)
                .build(new CacheLoader<SelfRankKey, ChannelBuffer>(){

                    @Override
                    public ChannelBuffer load(SelfRankKey key) throws Exception{
                        return key.loadListAroundMe();
                    }
                });

        this.searchRankCache = CacheBuilder.newBuilder().concurrencyLevel(8)
                .maximumSize(4096)
                .build(new CacheLoader<SearchRankKey, ChannelBuffer>(){

                    @Override
                    public ChannelBuffer load(SearchRankKey key)
                            throws Exception{
                        return key.load();
                    }
                });

        this.topRankMsg = CacheBuilder.newBuilder().concurrencyLevel(8)
                .initialCapacity(8)
                .build(new CacheLoader<Integer, ChannelBuffer>(){

                    @Override
                    public ChannelBuffer load(Integer key) throws Exception{
                        ChannelBuffer buffer = newDynamicMessage(MODULE_ID,
                                S2C_GET_RANK_TOP_HERO);
                        dbService.getTopRankMsg(buffer, key.intValue(),
                                guildModule);
                        return buffer;
                    }
                });

        // 取出所有在榜上的人, 设置正确的serverSequence/更新所有的数据
        logger.debug("更新排行榜数据");
        dbService.updateRankedObjectsOnStart(totalPages);
        logger.debug("排行榜数据更新完成");

        setUpdate();
    }

    public DBRankObject newRankObject(Hero hero, ServerData serverData){
        return new DBRankObject(rankQueue, hero, serverData);
    }

    private void setUpdate(){
        threadService.getScheduledExecutorService().scheduleAtFixedRate(
                new Runnable(){
                    @Override
                    public void run(){
                        try{
                            // flush add list
                            // flush update list
                            rankQueue.save(totalPages);

                            // clear view cache
                            rankNumMsgCache.invalidateAll();
                            selfRankPosCache.invalidateAll();
                            rankAroundMeCache.invalidateAll();
                            searchRankCache.invalidateAll();
                            topRankMsg.invalidateAll();
                        } catch (Throwable ex){
                            logger.error(
                                    "DBRankModule.setUpdate().new Runnable() {...}.run 出错",
                                    ex);
                        }
                    }
                }, 9, 10, TimeUnit.SECONDS);
    }

    private class SearchRankKey{
        private final RankType rankType;

        private final byte[] nameBytes;

        private final int serverSequence;

        private final int startIndex;

        private final int hashCode;

        SearchRankKey(RankType rankType, byte[] nameBytes, int serverSequence,
                int startIndex){
            super();
            this.rankType = rankType;
            this.nameBytes = nameBytes;
            this.serverSequence = serverSequence;
            this.startIndex = startIndex;

            this.hashCode = (rankType.ordinal() << 20) | (serverSequence << 18)
                    | (startIndex << 8) | nameBytes[0];
        }

        @Override
        public int hashCode(){
            return hashCode;
        }

        @Override
        public boolean equals(Object obj){
            if (obj instanceof SearchRankKey){
                SearchRankKey key = (SearchRankKey) obj;

                return key.rankType == rankType
                        && key.serverSequence == serverSequence
                        && key.startIndex == startIndex
                        && Arrays.equals(key.nameBytes, nameBytes);
            }

            return false;
        }

        public ChannelBuffer load() throws SQLException{
            ChannelBuffer buffer = getSearchRankBuffer(rankType.ordinal());
            dbService.getSearchRankMsg(buffer, startIndex, serverSequence,
                    rankType, nameBytes, guildModule);
            return buffer;
        }

    }

    private class RankCacheKey{
        private final int rankNum;

        private final int page;

        private final RankType rankType;

        private final int serverSequence;

        private final int totalPage;

        RankCacheKey(int rankNum, int page, int totalPage, RankType rankType,
                int serverSequence){
            this.rankNum = rankNum;
            this.page = page;
            this.rankType = rankType;
            this.serverSequence = serverSequence;
            this.totalPage = totalPage;
        }

        @Override
        public boolean equals(Object obj){
            if (obj instanceof RankCacheKey){
                RankCacheKey key = (RankCacheKey) obj;

                return rankNum == key.rankNum
                        && serverSequence == key.serverSequence;
            }

            return false;
        }

        @Override
        public int hashCode(){
            return rankNum;
        }

        public ChannelBuffer call() throws Exception{
            int startIndex = (page - 1) * VariableConfig.RANK_PER_PAGE;

            ChannelBuffer buffer = DBRankMessages.getRankListBuffer(rankNum,
                    totalPage);

            dbService.getRankMsg(buffer, startIndex, serverSequence, rankType,
                    guildModule);
            return buffer;
        }
    }

    private class SelfRankKey{
        private final RankType rankType;

        private final long selfID;

        private final int serverSequence;

        SelfRankKey(RankType rankType, long selfID, int serverSequence){
            super();
            this.rankType = rankType;
            this.selfID = selfID;
            this.serverSequence = serverSequence;
        }

        public Integer loadMyRank() throws SQLException{
            Integer result = dbService.getRankPosition(selfID, rankType,
                    serverSequence);
            logger.debug("获取英雄 {} 在 {} 榜的排名: {}", selfID, rankType, result);

            return result;
        }

        public ChannelBuffer loadListAroundMe() throws Exception{
            Integer pos = selfRankPosCache.getUnchecked(this);
            if (pos == 0){
                return getEmptyMyRankListBuffer(rankType.ordinal());
            }

            int realPos = pos - 1;

            int startIndex = Math.max(0, realPos - selfRankListUpCount);

            ChannelBuffer buffer = getMyRankListBuffer(rankType.ordinal(),
                    startIndex + 1);
            dbService.getRankMsg(buffer, startIndex, serverSequence, rankType,
                    guildModule);
            return buffer;
        }

        @Override
        public int hashCode(){
            return (int) selfID;
        }

        @Override
        public boolean equals(Object obj){
            if (obj instanceof SelfRankKey){
                SelfRankKey key = (SelfRankKey) obj;
                return key.rankType == rankType && selfID == key.selfID
                        && serverSequence == key.serverSequence;
            }
            return false;
        }
    }

    // --- 处理用户请求 ---

    /**
     * 处理本服的排行榜
     * @param sequenceID
     * @param buffer
     * @param hc
     */
    public void onMessage(final int sequenceID, final ChannelBuffer buffer,
            final HeroController hc){
        switch (sequenceID){
        // ---
            case C2S_RANK_GET_RANK:{
                onGetRank(hc, buffer, false);
                return;
            }

            case C2S_GET_UNION_RANK:{
                onGetRank(hc, buffer, true);
                return;
            }
            // ---

            case C2S_RANK_SELF_POS:{
                onGetSelfPos(hc, buffer, false);
                return;
            }

            case C2S_RANK_UNION_SELF_POS:{
                onGetSelfPos(hc, buffer, true);
                return;
            }

            // ---
            case C2S_RANK_MY_RANK_LIST:{
                onGetMyRankList(hc, buffer, false);
                return;
            }

            case C2S_RANK_UNION_MY_RANK_LIST:{
                onGetMyRankList(hc, buffer, true);
                return;
            }

            // ---
            case C2S_RANK_SEARCH:{
                onSearch(hc, buffer, false);
                return;
            }

            case S2C_RANK_UNION_SEARCH:{
                onSearch(hc, buffer, true);
                return;
            }

            // ---
            case C2S_GET_RANK_TOP_HERO:{
                onGetRankTopHero(hc, buffer, false);
                return;
            }

            case C2S_GET_UNION_RANK_TOP_HERO:{
                onGetRankTopHero(hc, buffer, true);
                return;
            }

            case C2S_RANK_ADMIRE:{
                onAdmire(hc, buffer);
                return;
            }

            case C2S_RANK_SELF_ADMIRED_TIMES:{
                onGetSelfBeenAdmiredTimes(hc, buffer);
                return;
            }

            default:{
                logger.error("DBRankModule 收到未知消息: {}", sequenceID);
            }
        }
    }

    private void onGetSelfBeenAdmiredTimes(HeroController hc,
            ChannelBuffer buffer){
        int beenAdmired = dbService.getBeenAdmiredTimes(hc.combinedID);

        hc.sendMessage(getSelfAdmiredTimes(beenAdmired));
    }

    private void onAdmire(HeroController hc, ChannelBuffer buffer){
        Hero hero = hc.getHero();

        int heroAdmireTimes = hero.getAdmiredHeroTimes();
        if (heroAdmireTimes >= VariableConfig.RANK_ADMIRE_MAX_TIMES){
            hc.sendMessage(ERR_ADMIRE_FAIL_FULL_ADMIRED_TIMES);
            return;
        }

        long targetID = readVarInt64(buffer);

        if (hero.hasAdmiredHero(targetID)){
            hc.sendMessage(ERR_ADMIRE_FAIL_HERO_WAS_ADMIRED);
            return;
        }

        rankQueue.addAdmire(targetID);  // 不管是否存在, 不管

        hero.addAdmiredHero(targetID);

        HeroLevelData levelData = hero.getLevelData();
        hc.sendMessage(admireRankMsg(heroAdmireTimes + 1,
                levelData.getAdmireExp(), levelData.getAdmireRealAir()));

        // 加经验，真气
        hc.getHeroFightModule().addExperience(levelData.getAdmireExp(),
                RANK_ADMIRE, null);
        hc.getHeroMiscModule().addRealAirAnyway(levelData.getAdmireRealAir(),
                RANK_ADMIRE, null);
    }

    private static final Integer UNION_SERVER_SEQUENCE_INTEGER = -1;

    private void onGetRankTopHero(HeroController hc, ChannelBuffer buffer,
            boolean isUnion){
        final Integer key = isUnion ? UNION_SERVER_SEQUENCE_INTEGER : hc
                .getServerData().integerSequence;

        ChannelBuffer result = topRankMsg.getIfPresent(key);
        if (result != null){
            hc.sendMessage(result);
            return;
        }

        final ISender sender = hc.getSender();
        threadService.getDbExecutor().execute(new Runnable(){
            @Override
            public void run(){
                ChannelBuffer result = topRankMsg.getUnchecked(key);
                sender.sendMessage(result);
            }
        });
    }

    private void onSearch(HeroController hc, ChannelBuffer buffer,
            boolean isUnion){
        long ctime = timeService.getCurrentTime();
        if (ctime < hc.nextCanSearchByHeroNameTime){
            hc.sendMessage(ERR_GET_SEARCH_FAIL_TIME_NOT_REACHED);
            return;
        }

        int num = readVarInt32(buffer);

        int rankType = num & 15;
        if (rankType >= ranks.length){
            logger.warn("搜索排行榜，但是rank不对, {}", rankType);
            hc.sendMessage(ERR_GET_SEARCH_FAIL_INVALID_RANK);
            return;
        }

        int startIndex = num >>> 4;
        byte[] nameBytes = readVarUTFBytes(buffer, 127);
        int len = Utils.getStringLength(nameBytes);
        if (len == 0 || len > MySQLDBService.HERO_NAME_MAX_LENGTH){
            hc.sendMessage(ERR_GET_SEARCH_FAIL_INVALID_NAME);
            return;
        }

        int serverSequence = isUnion ? -1 : hc.getServerData().sequence;
        hc.nextCanSearchByHeroNameTime = ctime + 1000;
        final SearchRankKey key = new SearchRankKey(ranks[rankType], nameBytes,
                serverSequence, startIndex);

        ChannelBuffer result = searchRankCache.getIfPresent(key);
        if (result != null){
            hc.sendMessage(result);
            return;
        }

        final ISender sender = hc.getSender();
        threadService.getDbExecutor().execute(new Runnable(){
            @Override
            public void run(){
                try{
                    ChannelBuffer result = searchRankCache.get(key);
                    sender.sendMessage(result);
                } catch (Throwable ex){
                    logger.error("DBRankModule.onSearch 出错", ex);
                    sender.sendMessage(ERR_GET_SEARCH_FAIL_INTERNAL_ERROR);
                }
            }
        });
    }

    private void onGetMyRankList(HeroController hc, ChannelBuffer buffer,
            boolean isUnion){
        int rankType = BufferUtil.readVarInt32(buffer);

        if (rankType < 0 || rankType >= ranks.length){
            logger.warn("获取自己的排行榜列表，但是rank不对, {}", rankType);
            hc.sendMessage(ERR_GET_MY_RANK_FAIL_INVALID_RANK);
            return;
        }

        int serverSequence = isUnion ? -1 : hc.getServerData().sequence;
        RankType rank = ranks[rankType];
        final SelfRankKey key = new SelfRankKey(rank, hc.combinedID,
                serverSequence);

        ChannelBuffer result = rankAroundMeCache.getIfPresent(key);
        if (result != null){
            hc.sendMessage(result);
            return;
        }
        final ISender sender = hc.getSender();
        threadService.getDbExecutor().execute(new Runnable(){
            @Override
            public void run(){
                try{
                    ChannelBuffer result = rankAroundMeCache.getUnchecked(key);
                    sender.sendMessage(result);
                } catch (Throwable ex){
                    logger.error(
                            "DBRankModule.onGetMyRankList(...).new Runnable() {...}.onGetMyRankList 出错",
                            ex);
                    sender.sendMessage(ERR_GET_MY_RANK_FAIL_INTERNAL_ERROR);
                }
            }
        });

    }

    private void onGetSelfPos(HeroController hc, ChannelBuffer buffer,
            boolean isUnion){
        final int rankType = readVarInt32(buffer);

        if (rankType >= ranks.length){
            logger.warn("获取自己的排行榜排名，但是rank不对, {}", rankType);
            hc.sendMessage(ERR_GET_SELF_POS_FAIL_INVALID_RANK);
            return;
        }

        int serverSequence = isUnion ? -1 : hc.getServerData().sequence;
        RankType rank = ranks[rankType];
        final SelfRankKey key = new SelfRankKey(rank, hc.combinedID,
                serverSequence);
        Integer result = selfRankPosCache.getIfPresent(key);
        if (result != null){
            hc.sendMessage(getSelfPosMsg(rankType, result));
            return;
        }

        final ISender sender = hc.getSender();
        threadService.getDbExecutor().execute(new Runnable(){
            @Override
            public void run(){
                try{
                    Integer result = selfRankPosCache.getUnchecked(key);
                    sender.sendMessage(getSelfPosMsg(rankType, result));
                } catch (Throwable ex){
                    logger.error(
                            "DBRankModule.onGetSelfPos(...).new Runnable() {...}.run 出错",
                            ex);
                    sender.sendMessage(ERR_GET_SELF_POS_FAIL_INVALID_RANK);
                }
            }
        });
    }

    private void onGetRank(HeroController hc, ChannelBuffer buffer,
            boolean isUnion){
        int rankNum = readVarInt32(buffer);

        int rankType = rankNum & 15;

        if (rankType >= ranks.length){
            logger.warn("获取排行榜数据，但是rank不对, {}", rankType);
            hc.sendMessage(ERR_GET_RANK_FAIL_INVALID_TYPE);
            return;
        }

        int serverSequence = isUnion ? -1 : hc.getServerData().sequence;
        int totalPage = totalPages[rankType][serverSequence + 1];

        if (totalPage == 0){
            hc.sendMessage(DBRankMessages.getRankListBuffer(rankNum, 0));
            return;
        }

        int page = rankNum >>> 4;

        if (page > totalPage){
            logger.warn("排行榜页数超出了");
            hc.sendMessage(ERR_GET_RANK_FAIL_INVALID_PAGE);
            return;
        }

        final RankCacheKey key = new RankCacheKey(rankNum, page, totalPage,
                ranks[rankType], serverSequence);

        ChannelBuffer result = rankNumMsgCache.getIfPresent(key);
        if (result != null){
            hc.sendMessage(result);
            return;
        }

        final ISender sender = hc.getSender();
        threadService.getDbExecutor().execute(new Runnable(){
            @Override
            public void run(){
                try{
                    ChannelBuffer result = rankNumMsgCache.getUnchecked(key);
                    sender.sendMessage(result);
                } catch (Throwable ex){
                    logger.error(
                            "DBRankModule.onGetRank(...).new Runnable() {...}.run 出错",
                            ex);
                    sender.sendMessage(ERR_GET_RANK_FAIL_INTERNAL_ERROR);
                }
            }
        });
    }
}
