package app.game.module.guild;

import static com.mokylin.sink.util.Preconditions.*;
import app.game.data.SpriteStat;
import app.game.data.SpriteStats;
import app.protobuf.ConfigContent.GuildFlagLevelProto;

import com.mokylin.sink.util.parse.ObjectParser;

public class GuildFlagData{

    public final int level;

    public final SpriteStat spriteStat;

    public final int addCapacity;

    public final int addExp;

    public final int addRealAir;

    public final int upgradeGoods1;

    public final int upgradeGoods2;

    public final int upgradeGoods3;

    public final int upgradeGoods4;

    public final int upgradeMoney;

    GuildFlagData(ObjectParser p, SpriteStats spriteStats){
        this.level = p.getIntKey("level");
        int sid = p.getIntKey("stat_id");
        this.spriteStat = checkNotNull(spriteStats.get(sid),
                "没有找到 %s级帮旗的属性 %s", level, sid);

        this.addCapacity = p.getIntKey("add_capacity");
        this.addExp = p.getIntKey("add_exp");
        this.addRealAir = p.getIntKey("add_real_air");

        this.upgradeGoods1 = p.getIntKey("upgrade_goods_1");
        this.upgradeGoods2 = p.getIntKey("upgrade_goods_2");
        this.upgradeGoods3 = p.getIntKey("upgrade_goods_3");
        this.upgradeGoods4 = p.getIntKey("upgrade_goods_4");
        this.upgradeMoney = p.getIntKey("upgrade_money");

        checkArgument(upgradeGoods1 >= 0, "帮旗升级所需物品数不能<0: %s级", level);
        checkArgument(upgradeGoods2 >= 0, "帮旗升级所需物品数不能<0: %s级", level);
        checkArgument(upgradeGoods3 >= 0, "帮旗升级所需物品数不能<0: %s级", level);
        checkArgument(upgradeGoods4 >= 0, "帮旗升级所需物品数不能<0: %s级", level);
        checkArgument(upgradeMoney >= 0, "帮旗升级所需银两数不能<0: %s级", level);
    }

    public GuildFlagLevelProto encode(){
        GuildFlagLevelProto.Builder builder = GuildFlagLevelProto.newBuilder()
                .setLevel(level).setAddExp(addExp).setAddRealAir(addRealAir);

        builder.setUpgradeGoods1(upgradeGoods1).setUpgradeGoods2(upgradeGoods2)
                .setUpgradeGoods3(upgradeGoods3)
                .setUpgradeGoods4(upgradeGoods4).setUpgradeMoney(upgradeMoney);

        builder.setStat(spriteStat.encode());

        return builder.build();
    }
}
