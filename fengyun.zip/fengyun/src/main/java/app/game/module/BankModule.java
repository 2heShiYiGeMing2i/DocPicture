package app.game.module;

import static app.game.module.BankMessages.*;
import static com.mokylin.sink.util.BufferUtil.readVarInt32;

import java.io.Closeable;
import java.util.concurrent.ConcurrentLinkedDeque;

import org.jboss.netty.buffer.ChannelBuffer;
import org.joda.time.DateTime;
import org.joda.time.DateTimeConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.data.bank.BankDatas;
import app.game.entity.Hero;
import app.game.service.CloseService;
import app.game.service.DBService;
import app.game.service.TimeService;
import app.game.service.log.LogService;
import app.protobuf.HeroServerContent.BankGlobalLogProto;
import app.protobuf.LogContent.LogEnum.OperateType;
import app.utils.VariableConfig;

import com.google.inject.Inject;
import com.google.protobuf.ByteString;
import com.mokylin.sink.util.concurrent.PaddedAtomicInteger;

/**
 * @author Liwei
 *
 */
public class BankModule implements Closeable{

    private static final Logger logger = LoggerFactory
            .getLogger(BankModule.class);

    private final TimeService timeService;

    private final LogService logService;

    private final DBService dbService;

    private final BankDatas datas;

    private final ConcurrentLinkedDeque<BankGlobalLog> globalLogs;

    private final PaddedAtomicInteger counter;

    @Inject
    BankModule(TimeService timeService, LogService logService,
            DBService dbService, BankDatas datas, CloseService closeService)
            throws Throwable{
        this.timeService = timeService;
        this.logService = logService;
        this.dbService = dbService;
        this.datas = datas;
        globalLogs = new ConcurrentLinkedDeque<>();
        counter = new PaddedAtomicInteger();

        BankGlobalLogProto proto = loadData();
        if (proto != null){
            int count = Math.min(
                    Math.min(proto.getInfoCount(), proto.getHeroIdCount()),
                    proto.getHeroNameCount());

            for (int i = 0; i < count; i++){
                globalLogs.add(new BankGlobalLog(proto.getInfo(i), proto
                        .getHeroId(i), proto.getHeroName(i).toByteArray()));
            }

            counter.set(globalLogs.size());
        }

        // 不定时保存也没关系，只是些日志，没了就没了
        closeService.register(this);
    }

    private BankGlobalLogProto loadData() throws Throwable{
        byte[] data = dbService.loadGlobalData(DBService.KEY_BANK);
        if (data != null && data.length > 0){
            return BankGlobalLogProto.parseFrom(data);
        }

        return null;
    }

    @Override
    public void close(){
        save();
    }

    public void save(){
        try{
            BankGlobalLogProto.Builder builder = BankGlobalLogProto
                    .newBuilder();
            for (BankGlobalLog log : globalLogs){
                if (log == null){
                    continue;
                }

                builder.addInfo(log.info);
                builder.addHeroId(log.heroId);
                builder.addHeroName(ByteString.copyFrom(log.heroName));
            }

            dbService.saveGlobalData(DBService.KEY_BANK, builder.build()
                    .toByteArray());
        } catch (Throwable ex){
            logger.error("钱庄数据保存出错", ex);
        }
    }

    public void onMessage(int sequenceID, ChannelBuffer buffer,
            HeroController hc){

        switch (sequenceID){
            case C2S_UPGRADE_BANK_INVEST:{
                onInvestUpgradeBank(hc, buffer);
                return;
            }
            case C2S_COLLECT_UPGRADE_BANK_INCOME:{
                onCollectUpgradeBankIncome(hc, buffer);
                return;
            }
            case C2S_INVEST_MONTHLY_BANK:{
                onInvestMonthlyBank(hc, buffer);
                return;
            }
            case C2S_COLLECT_MONTHLY_BANK_INCOME:{
                onCollectMonthlyBankIncome(hc, buffer);
                return;
            }
            case C2S_COLLECT_MONTHLY_BANK_ONLINE_INCOME:{
                onCollectMonthlyBankOnlineIncome(hc, buffer);
                return;
            }
            case C2S_GET_SELF_BANK_LOG:{
                onGetSelfBankLog(hc, buffer);
                return;
            }
            case C2S_GET_GLOBAL_BANK_LOG:{
                onGetGlobalBankLog(hc, buffer);
                return;
            }
            default:{
                logger.error("BankModule模块收到未知消息: {}", sequenceID);
            }
        }
    }

    private void onInvestUpgradeBank(HeroController hc, ChannelBuffer buffer){

        int toAdd = readVarInt32(buffer);

        if (toAdd <= 0 || toAdd % 100 != 0){
            logger.warn("投资升级钱庄，投资额度<=0或者不是100的倍数");
            hc.sendMessage(UPGRADE_BANK_INVEST_FAIL_INVALID_AMOUNT);
            return;
        }

        long investMoney = hc.getHero().getInvestUpgradeBankMoney();

        if (investMoney + toAdd > datas.getUpgradeBankMaxQuota()){
            logger.warn("投资升级钱庄，投资额度超出最大可投资额度");
            hc.sendMessage(UPGRADE_BANK_INVEST_FAIL_LARGE_THAN_MAX_QUOTA);
            return;
        }

        String iEventId = logService.newTodoEventId();
        if (!hc.getHeroMiscModule().reduceYuanbao(toAdd,
                OperateType.INVEST_UPGRADE_BANK, iEventId)){
            logger.warn("投资升级钱庄，元宝不足");
            hc.sendMessage(UPGRADE_BANK_INVEST_FAIL_YUANBAO_NOT_ENOUGH);
            return;
        }

        int total = hc.getHero().addInvestUpgradeBankMoney(toAdd);

        hc.sendMessage(investUpgradeBankMsg(total));

        long ctime = timeService.getCurrentTime();

        int info = getInfo(true, true, toAdd);
        hc.getHero().addBankLog(info, (int) (ctime / 1000));
        addGlobalLog(new BankGlobalLog(info, hc.getHero().getID(), hc.getHero()
                .getNameBytes()));
    }

    private void onCollectUpgradeBankIncome(HeroController hc,
            ChannelBuffer buffer){

        long money = hc.getHero().getInvestUpgradeBankMoney();
        if (money <= 0){
            logger.warn("领取升级钱庄收益，位投资升级钱庄");
            hc.sendMessage(COLLECT_UPGRADE_BANK_INCOME_FAIL_NO_INVESTED);
            return;
        }

        int level = readVarInt32(buffer);
        int rate = datas.getUpgradeBankRebate(level);

        if (rate <= 0){
            logger.warn("领取升级钱庄收益，领取等级无效-{}", level);
            hc.sendMessage(COLLECT_UPGRADE_BANK_INCOME_FAIL_INVALID_LEVEL);
            return;
        }

        long canCollectMoney = money * datas.getExchangeRate() * rate / 100;
        if (canCollectMoney <= 0 || canCollectMoney > Integer.MAX_VALUE){
            // 这是在逗我吗
            logger.error("领取升级钱庄收益，0 <= canCollectMoney < Integer.MAX_VALUE");
            hc.sendMessage(COLLECT_UPGRADE_BANK_INCOME_FAIL_TOO_MUCH);
            return;
        }

        int total = (int) canCollectMoney;

        int collectedMoney = hc.getHero().getCollectUpgradeBankMoney(level);
        if (collectedMoney >= total){
            logger.warn("领取升级钱庄收益，没有礼金可以领取");
            hc.sendMessage(COLLECT_UPGRADE_BANK_INCOME_FAIL_NO_LIJIN);
            return;
        }

        int toAdd = total - collectedMoney;
        String iEventId = logService.newTodoEventId();
        if (!hc.getHeroMiscModule().addLijin(toAdd,
                OperateType.COLLECT_MONTHLY_BANK_INCOME, iEventId)){
            logger.debug("领取升级钱庄收益，礼金太多");
            hc.sendMessage(COLLECT_UPGRADE_BANK_INCOME_FAIL_TOO_MUCH);
            return;
        }

        hc.getHero().setCollectUpgradeBankMoney(level, total);

        hc.sendMessage(collectUpgradeBankIncome(level, total));

        long ctime = timeService.getCurrentTime();

        int info = getInfo(true, false, toAdd);
        hc.getHero().addBankLog(info, (int) (ctime / 1000));
        addGlobalLog(new BankGlobalLog(info, hc.getHero().getID(), hc.getHero()
                .getNameBytes()));
    }

    private void onInvestMonthlyBank(HeroController hc, ChannelBuffer buffer){

        Hero hero = hc.getHero();
        long invertEndTime = hero.getInvestMonthlyBankTime()
                + datas.getMonthlyBankDuration();

        long ctime = timeService.getCurrentTime();
        if (ctime < invertEndTime){
            logger.warn("投资月卡钱庄，当前还在投资期间内");
            hc.sendMessage(INVEST_MONTHLY_BANK_FAIL_INVESTING);
            return;
        }

        if (hero.getMonthlyBankOnlineLijin() > 0){
            long collectLijinEndTime = invertEndTime
                    + datas.getMonthlyBankCollectDuration();

            if (ctime < collectLijinEndTime){
                logger.warn("投资月卡钱庄，当前还有礼金没领完");
                hc.sendMessage(INVEST_MONTHLY_BANK_FAIL_LIJIN_NOT_COLLECTED);
                return;
            }
        }

        String iEventId = logService.newTodoEventId();
        int toAdd = datas.getMonthlyBankQuota();
        if (!hc.getHeroMiscModule().reduceYuanbao(toAdd,
                OperateType.INVEST_MONTHLY_BANK, iEventId)){
            logger.warn("投资月卡钱庄，元宝不足");
            hc.sendMessage(INVEST_MONTHLY_BANK_FAIL_YUANBAO_NOT_ENOUGH);
            return;
        }

        int baseLijin = datas.getMonthlyBankOnlineBaseLijin();

        long onlineMillis = hero.getDailyOnlineAccTime(ctime);
        int onlineHour = (int) (onlineMillis / DateTimeConstants.MILLIS_PER_HOUR);
        int rebate = datas.getMonthlyBankOnlineRebate(onlineHour);

        int onlineLijin = Math.max(baseLijin * rebate / 1000, baseLijin);

        int realOnlineHour = Math.min(onlineHour,
                datas.getMonthlyBankDailyMaxOnlineHour());

        hero.tryInvestMonthlyBank(datas.getMonthlyBankQuota(), new DateTime(
                ctime).withTimeAtStartOfDay().getMillis(), baseLijin,
                onlineLijin, realOnlineHour);

        hc.sendMessage(investMonthlyBank(baseLijin, onlineLijin, realOnlineHour));

        int info = getInfo(false, true, toAdd);
        hc.getHero().addBankLog(info, (int) (ctime / 1000));
        addGlobalLog(new BankGlobalLog(info, hc.getHero().getID(), hc.getHero()
                .getNameBytes()));
    }

    private void onCollectMonthlyBankIncome(HeroController hc,
            ChannelBuffer buffer){
        Hero hero = hc.getHero();

        long ctime = timeService.getCurrentTime();

        if (ctime < hero.getInvestMonthlyBankTime()){
            logger.warn("领取月卡钱庄收益，投资时间居然比当前时间还大");
            hc.sendMessage(INVEST_MONTHLY_BANK_FAIL_INVESTING);
            return;
        }

        long invertEndTime = hero.getInvestMonthlyBankTime()
                + datas.getMonthlyBankDuration();

        if (ctime >= invertEndTime){
            logger.warn("领取月卡钱庄收益，没有投资月卡钱庄");
            hc.sendMessage(INVEST_MONTHLY_BANK_FAIL_INVESTING);
            return;
        }

        long todayStartTime = new DateTime(ctime).withTimeAtStartOfDay()
                .getMillis();

        if (todayStartTime <= hero.getMonthlyBankPrevCollectTime()){
            logger.warn("领取月卡钱庄收益，今日已领取过了");
            hc.sendMessage(COLLECT_MONTHLY_BANK_FAIL_COLLECTED);
            return;
        }

        long money = hero.getInvestMonthlyBankMoney();
        long total = money * datas.getExchangeRate();

        long rebate = datas.getMonthlyBankDailyRebate();
        if (hero.getInvestMonthlyBankTime() == todayStartTime){
            // 首日
            rebate += datas.getMonthlyBankFirstDayRebate();
        }

        long income = total * rebate / 100;
        if (income > Integer.MAX_VALUE || income <= 0){
            logger.warn("领取月卡钱庄收益，income > Integer.MAX_VALUE || income <= 0");
            hc.sendMessage(COLLECT_MONTHLY_BANK_FAIL_LIJIN_TOO_MUCH);
            return;
        }

        int toAdd = (int) income;

        String iEventId = logService.newTodoEventId();
        if (!hc.getHeroMiscModule().addLijin(toAdd,
                OperateType.COLLECT_MONTHLY_BANK_INCOME, iEventId)){
            logger.debug("领取月卡钱庄收益，礼金太多");
            hc.sendMessage(COLLECT_MONTHLY_BANK_FAIL_LIJIN_TOO_MUCH);
            return;
        }

        hero.collectMonthlyBankIncome(todayStartTime);

        hc.sendMessage(COLLECT_MONTHLY_BANK_INCOME_MSG);

        int info = getInfo(false, false, toAdd);
        hc.getHero().addBankLog(info, (int) (ctime / 1000));
        addGlobalLog(new BankGlobalLog(info, hc.getHero().getID(), hc.getHero()
                .getNameBytes()));
    }

    private void onCollectMonthlyBankOnlineIncome(HeroController hc,
            ChannelBuffer buffer){
        Hero hero = hc.getHero();

        if (hero.getMonthlyBankOnlineLijin() <= 0){
            logger.warn("领取月卡钱庄在线收益，没有礼金可以领取");
            hc.sendMessage(COLLECT_MONTHLY_BANK_ONLINE_FAIL_TIME_NOT_REACHED);
            return;
        }

        long ctime = timeService.getCurrentTime();

        long invertEndTime = hero.getInvestMonthlyBankTime()
                + datas.getMonthlyBankDuration();

        long collectLijinEndTime = invertEndTime
                + datas.getMonthlyBankCollectDuration();

        if (ctime < invertEndTime){
            logger.warn("领取月卡钱庄在线收益，领取时间未到");
            hc.sendMessage(COLLECT_MONTHLY_BANK_ONLINE_FAIL_TIME_NOT_REACHED);
            return;
        }

        if (ctime > collectLijinEndTime){
            logger.warn("领取月卡钱庄在线收益，已过期");
            hc.sendMessage(COLLECT_MONTHLY_BANK_ONLINE_FAIL_EXPIRED);
            return;
        }

        int toAdd = Math.min(hero.getMonthlyBankOnlineLijin(),
                VariableConfig.MONTHLY_BANK_ONLINE_LIJIN_MAX_AMOUNT);

        String iEventId = logService.newTodoEventId();
        if (!hc.getHeroMiscModule().addLijin(toAdd,
                OperateType.COLLECT_MONTHLY_BANK_ONLINE_INCOME, iEventId)){
            logger.debug("领取月卡钱庄在线收益，礼金太多");
            hc.sendMessage(COLLECT_MONTHLY_BANK_ONLINE_FAIL_LIJIN_TOO_MUCH);
            return;
        }

        hero.onCollectMonthlyOnlineIncome();

        hc.sendMessage(COLLECT_MONTHLY_BANK_ONLINE_INCOME_MSG);

        int info = getInfo(false, false, toAdd);
        hc.getHero().addBankLog(info, (int) (ctime / 1000));
        addGlobalLog(new BankGlobalLog(info, hc.getHero().getID(), hc.getHero()
                .getNameBytes()));
    }

    private void onGetSelfBankLog(HeroController hc, ChannelBuffer buffer){
        hc.sendMessage(getSelfBankLogMsg(hc.getHero().getBankLogs()));
    }

    private void onGetGlobalBankLog(HeroController hc, ChannelBuffer buffer){
        hc.sendMessage(getGlobalBankLogMsg(counter.get(), globalLogs));
    }

    private void addGlobalLog(BankGlobalLog log){
        globalLogs.addFirst(log);
        int c = counter.incrementAndGet();

        if (c > VariableConfig.BANK_LOG_COUNT){
            globalLogs.removeLast();
            counter.decrementAndGet();
        }
    }

    private int getInfo(boolean isUpgradeBank, boolean isSave, int amount){
        return (isUpgradeBank ? 1 : 0) | (isSave ? 2 : 0) | (amount << 2);
    }

    public static class BankGlobalLog{
        public final int info;

        public final long heroId;

        public final byte[] heroName;

        BankGlobalLog(int info, long heroId, byte[] heroName){
            this.info = info;
            this.heroId = heroId;
            this.heroName = heroName;
        }
    }
}
