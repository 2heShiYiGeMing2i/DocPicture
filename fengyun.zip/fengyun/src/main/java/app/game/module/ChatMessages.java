package app.game.module;

import static com.mokylin.sink.util.BufferUtil.*;

import java.util.List;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.module.ChatModule.OfflineChatMsg;
import app.game.module.ChatModule.OfflineLeaveMsgHeroInfo;
import app.protobuf.HeroContent.ChatMessage;

import com.mokylin.sink.util.BufferUtil;

public class ChatMessages{

    public static final int MODULE_ID = Modules.CHAT_MODULE_ID;

    private ChatMessages(){
    }

    // ------ 世界频道 ------
    /**
     * 请求发送世界聊天, 请求后, 不要直接清掉聊天框中的消息把消息放到世界频道中, 而要等待服务器返回
     * 服务器返回前, 需要锁定聊天栏, 不让他继续输入, 按回车忽略, 点击发送忽略(不要把按钮做成不可点击).
     *
     * 客户端发送前就需要检查 等级/频率/长度. 不符合的就本地弹出错误消息.
     *
     * 附带 ChatMessage这个proto
     */
    public static final int C2S_WORLD_CHAT = 1;

    /**
     * 世界聊天发送成功, 后面没有附带的信息. 客户端自己把聊天栏中的话放到世界频道中
     * 发送者只会收到发送成功消息, 别人会收到S2C_WORLD_CHAT_BROADCAST广播消息. 发送者不会收到广播消息
     */
    static final int S2C_WORLD_CHAT_SUCCESS = 1;
    static final ChannelBuffer worldChatSuccess = onlySendHeaderMessage(
            MODULE_ID, S2C_WORLD_CHAT_SUCCESS);

    /**
     * 世界聊天发送失败, 保留聊天框中的信息, 弹出错误提示
     *
     * 附带varint32的错误码
     *
     * 1. 等级不够
     * 2. 发送太频繁
     * 3. 话太长
     * 4. 格式非法. 消息后面解不出ChatMessage
     */
    static final int S2C_WORLD_CHAT_FAIL = 2;
    static final ChannelBuffer ERROR_WORLD_CHAT_NOT_ENOUGH_LEVEL = worldChatFail(1);
    static final ChannelBuffer ERROR_WORLD_CHAT_TOO_FREQUENT = worldChatFail(2);
    static final ChannelBuffer ERROR_WORLD_CHAT_TOO_LONG = worldChatFail(3);
    static final ChannelBuffer ERROR_WORLD_CHAT_ILLEGAL_DATA = worldChatFail(4);

    /**
     * 别人在世界聊天中说了话
     *
     * 附带ChatMessage这个proto. 从中获取英雄的相关信息
     */
    static final int S2C_WORLD_CHAT_BROADCAST = 3;

    // ------ 本地频道 ------
    /**
     * 类似世界聊天, 所有的场景聊天共享发送频率, 即就算换了场景, 还是需要算上之前一段时间内在别的场景所说的话
     *
     * 附带ChatMessage这个proto
     */
    public static final int C2S_SCENE_CHAT = 2;

    /**
     * 场景聊天成功. 不附带信息. 和S2C_WORLD_CHAT_SUCCESS类似
     */
    static final int S2C_SCENE_CHAT_SUCCESS = 4;
    static final ChannelBuffer sceneChatSuccess = onlySendHeaderMessage(
            MODULE_ID, S2C_SCENE_CHAT_SUCCESS);

    /**
     * 场景聊天失败
     *
     * 附带varint32的错误码
     *
     * 1. 发送太频繁
     * 2. 话太长
     * 3. 格式非法. 消息后面解不出ChatMessage
     */
    static final int S2C_SCENE_CHAT_FAIL = 5;
    static final ChannelBuffer ERROR_SCENE_CHAT_TOO_FREQUENT = sceneChatFail(1);
    static final ChannelBuffer ERROR_SCENE_CHAT_TOO_LONG = sceneChatFail(2);
    static final ChannelBuffer ERROR_SCENE_CHAT_ILLEGAL_DATA = sceneChatFail(3);

    /**
     * 别人在当前频道说了话
     *
     * 附带ChatMessage这个proto. 从中获取英雄的相关信息
     */
    static final int S2C_SCENE_CHAT_BROADCAST = 6;

    // ------ 喇叭频道 ------

    /**
     * 喇叭广播
     *
     * 附带
     *
     * varint32 所要消耗的喇叭物品在背包中的位置. 如果将来vip每天可以免费喇叭, 则在免费期间, 发0
     * ChatMessage proto
     */
    static final int C2S_PAID_CHAT = 3;

    static final int S2C_PAID_CHAT_SUCCESS = 7;
    static final ChannelBuffer paidChatSuccess = onlySendHeaderMessage(
            MODULE_ID, S2C_PAID_CHAT_SUCCESS);

    /**
     * 喇叭失败
     *
     * 1. 发送太频繁
     * 2. 话太长
     * 3. 格式非法. 消息后面解不出ChatMessage
     * 4. 物品不够
     * 5. 喇叭cd....
     * 6. 等级不够
     */
    static final int S2C_PAID_CHAT_FAIL = 8;
    static final ChannelBuffer ERROR_PAID_CHAT_TOO_FREQUENT = paidChatFail(1);
    static final ChannelBuffer ERROR_PAID_CHAT_TOO_LONG = paidChatFail(2);
    static final ChannelBuffer ERROR_PAID_CHAT_ILLEGAL_DATA = paidChatFail(3);
    static final ChannelBuffer ERROR_PAID_CHAT_NO_GOODS = paidChatFail(4);
    static final ChannelBuffer ERROR_PAID_CHAT_GOODS_CD = paidChatFail(5);
    static final ChannelBuffer ERROR_PAID_CHAT_LEVEL_NOT_ENOUGH = paidChatFail(6);

    /**
     * 发喇叭失败, 被禁言. 后面附带解禁时间点. 由客户端自己算出剩余被禁言时间, 显示在错误消息中
     *
     * 附带
     *
     * varint64 解禁时间点
     */
    static final int S2C_PAID_CHAT_FORBIDDEN = 12;

    static final int S2C_PAID_CHAT_BROADCAST = 9;

    // ------ 问物品静态属性 ------
    /**
     * 请求物品静态信息
     *
     * 附带
     * varint32 物品id
     */
    static final int C2S_GOODS_INFO_QUERY = 4;

    /**
     * 返回物品静态信息
     *
     * 后面全都是发送物品时的静态二进制信息
     * 即第一个byte表示物品类型, 根据物品类型, 决定后面所有的内容所代表的是什么类型的proto
     */
    static final int S2C_GOODS_INFO_REPLY = 10;

    /**
     * 返回物品静态信息错误
     *
     * 附带varint32错误码
     *
     * 1. 没找到你找的物品
     * 2. 你已经问过这物品了, 怎么还来问
     */
    static final int S2C_GOODS_INFO_REPLY_ERROR = 11;
    static final ChannelBuffer ERROR_REPLY_GOODS_INFO_NOT_EXIST = goodsInfoReplyError(1);
    static final ChannelBuffer ERROR_REPLY_GOODS_INFO_ASK_AGAIN = goodsInfoReplyError(2);

    // ------ 普通私聊 ------

    /**
     * 普通私聊
     *
     * 附带
     * varint64 目标id
     * ChatMessage这个proto
     */
    static final int C2S_NORMAL_PRIVATE_CHAT = 5;

    static final int S2C_NORMAL_PRIVATE_CHAT_SUCCESS_AND_TARGET_ONLINE = 13;
    static final ChannelBuffer normalPrivateChatSuccessAndTargetOnline = onlySendHeaderMessage(
            MODULE_ID, S2C_NORMAL_PRIVATE_CHAT_SUCCESS_AND_TARGET_ONLINE);

    static final int S2C_NORMAL_PRIVATE_CHAT_SUCCESS_AND_TARGET_OFFLINE = 14;
    static final ChannelBuffer normalPrivateChatSuccessAndTargetOffline = onlySendHeaderMessage(
            MODULE_ID, S2C_NORMAL_PRIVATE_CHAT_SUCCESS_AND_TARGET_OFFLINE);

    /**
     * 私聊失败
     *
     * 附带varint32 失败原因
     *
     * 1. 频率太快
     * 2. 内容太长
     * 3. 格式非法. 后面解不出ChatMessage
     * 4. 对方加你到黑名单了(清掉输入框)
     * 5. 目标不存在
     * 6. 服务器内部错误, 稍后再试
     */
    static final int S2C_NORMAL_PRIVATE_CHAT_FAIL = 15;
    static final ChannelBuffer ERROR_NORMAL_CHAT_TOO_FREQUENT = normalPrivateChatError(1);
    static final ChannelBuffer ERROR_NORMAL_CHAT_TOO_LONG = normalPrivateChatError(2);
    static final ChannelBuffer ERROR_NORMAL_CHAT_ILLEGAL_DATA = normalPrivateChatError(3);
    static final ChannelBuffer ERROR_NORMAL_CHAT_BLACKED = normalPrivateChatError(4);
    static final ChannelBuffer ERROR_NORMAL_CHAT_NOT_EXISTS = normalPrivateChatError(5);
    static final ChannelBuffer ERROR_NORMAL_CHAT_INTERNAL_ERROR = normalPrivateChatError(6);

    /**
     * 收到私聊信息, 来自于左下角的私聊框. 不加入私聊窗口
     *
     * 附带
     *
     * varint64 发送的时间
     * ChatMessage这proto
     */
    static final int S2C_RECEIVED_NORMAL_PRIVATE_CHAT = 16;

    // ------ 私聊窗口关注 ------

    /**
     * 客户端打开了与某人的私聊窗口, 请求对方的在线及心情状态, 并且注册对方在线或心情变化事件
     *
     * 附带
     *
     * varint64 对方id
     */
    static final int C2S_WINDOW_CHAT_OPEN_AND_GET_MOOD = 6;

    /**
     * 返回对方心情状态
     *
     * 附带
     * varint64 对方id
     * varint32 职业与是否在线  假设n是读到的varint32  isOnline = (n & 1) == 1;  raceID = n >>> 1
     * varint32 对方等级
     * UTFBytes 对方心情
     */
    static final int S2C_WINDOW_CHAT_OPEN_REPLY_MOOD = 17;

    /**
     * 询问对方心情失败
     *
     * 附带varint32 错误码
     *
     * 1. id不存在
     * 2. 你不是已经注册过了吗? 上次关掉没取消注册? bug? 再这样我断你线哦
     * 3. 对方已经是你的好友, 且你也请求过好友面板的具体数据了, 你应该发只注册不请求心情的消息啊. 不管怎么样, 还是帮你注册了
     * 4. 服务器内部错误, 稍后再试. 不要自动帮他重写发送. 也不要提示他, 忽略就行
     * 5. 同时关注了6个人? bug
     */
    static final int S2C_WINDOW_CHAT_OPEN_ERROR = 18;
    static final ChannelBuffer ERROR_WINDOW_CHAT_OPEN_ID_NOT_EXIST = openWindowError(1);
    static final ChannelBuffer ERROR_WINDOW_CHAT_OPEN_DUP_REGISTER = openWindowError(2);
    static final ChannelBuffer ERROR_WINDOW_CHAT_OPEN_ALREADY_YOUR_FRIEND = openWindowError(3);
    static final ChannelBuffer ERROR_WINDOW_CHAT_OPEN_INTERNAL_ERROR = openWindowError(4);
    static final ChannelBuffer ERROR_WINDOW_CHAT_OPEN_REGISTERED_TOO_MANY = openWindowError(5);

    /**
     * 客户端打开了私聊窗口, 对方在我的关系列表中, 我已经有了他的心情和在线状态, 就注册下
     *
     * 服务器没有返回
     *
     * 附带
     *
     * varint64 对方id
     */
    static final int C2S_WINDOW_CHAT_OPEN_AND_MOOD_ALREADY_KNOWN = 7;

    /**
     * 客户端关闭了和某人的私聊窗口, 不再接收他的心情和在线状态变化. 如果他在关系列表中, 服务器还是会通知的, 别担心
     *
     * 服务器没有返回
     *
     * 附带
     *
     * varint64 对方id
     */
    static final int C2S_WINDOW_CHAT_CLOSED = 8;

    // ----- 私聊窗口 ------

    /**
     * 发送窗口聊天, 流程和左下角私聊一样, 仅仅是消息号不同
     *
     * 附带
     * varint64 对方id
     * ChatMessage 这proto
     */
    static final int C2S_SEND_WINDOW_CHAT = 9;

    /**
     * 窗口聊天发送成功, 且对方在线
     */
    static final int S2C_SEND_WINDOW_CHAT_SUCCESS_AND_TARGET_ONLINE = 19;
    static final ChannelBuffer sendWindowChatSuccessAndTargetOnline = onlySendHeaderMessage(
            MODULE_ID, S2C_SEND_WINDOW_CHAT_SUCCESS_AND_TARGET_ONLINE);

    /**
     * 窗口聊天发送成功, 且对方不在线
     */
    static final int S2C_SEND_WINDOW_CHAT_SUCCESS_AND_TARGET_OFFLINE = 20;
    static final ChannelBuffer sendWindowChatSuccessAndTargetOffline = onlySendHeaderMessage(
            MODULE_ID, S2C_SEND_WINDOW_CHAT_SUCCESS_AND_TARGET_OFFLINE);

    /**
     * 窗口聊天发送失败, 附带varint32 错误码
     *
     * 1. 频率太快
     * 2. 内容太长
     * 3. 格式非法. 后面解不出ChatMessage
     * 4. 对方加你到黑名单了(清掉输入框)
     * 5. 目标不存在
     * 6. 服务器内部错误, 稍后再试
     */
    static final int S2C_SEND_WINDOW_CHAT_FAIL = 21;
    static final ChannelBuffer ERROR_SEND_WINDOW_CHAT_TOO_FREQUENT = sendWindowChatFail(1);
    static final ChannelBuffer ERROR_SEND_WINDOW_CHAT_TOO_LONG = sendWindowChatFail(2);
    static final ChannelBuffer ERROR_SEND_WINDOW_CHAT_ILLEGAL_DATA = sendWindowChatFail(3);
    static final ChannelBuffer ERROR_SEND_WINDOW_CHAT_BLACKED = sendWindowChatFail(4);
    static final ChannelBuffer ERROR_SEND_WINDOW_CHAT_NOT_EXISTS = sendWindowChatFail(5);
    static final ChannelBuffer ERROR_SEND_WINDOW_CHAT_INTERNAL_ERROR = sendWindowChatFail(6);

    /**
     * 收到私聊窗口信息, 如果当前打开着和对方的私聊窗口, 则将消息加入私聊窗口.
     *
     * 如果没有打开, 则在界面下弹提示, 并不需要预先创建私聊窗口, 缓存这条消息. 仅加入总私聊缓存就行
     *
     * 附带
     *
     * varint64 消息的时间
     * ChatMessage这proto
     */
    static final int S2C_RECEIVED_WINDOW_CHAT = 22;

    // ------ 私聊正在输入提醒 ------

    /**
     * 正在私聊窗口中输入.
     *
     * 附带
     *
     * varint64的对方id
     */
    static final int C2S_I_AM_TYPING = 10;

    /**
     * 我已停止在私聊窗口中输入. 回车发送私聊不需要发停止输入, 默认已经切为停止输入状态
     *
     * 输入状态下, 2秒不输入, 发送这条
     *
     * 附带
     *
     * varint64的对方id
     */
    static final int C2S_I_STOPPED_TYPING = 11;

    /**
     * 私聊对象正在输入
     *
     * 附带
     *
     * varint64的对方id
     */
    static final int S2C_OTHER_IS_TYPING = 23;

    /**
     * 私聊对象停止了输入
     *
     * 附带
     *
     * varint64的对方id
     */
    static final int S2C_OTHER_STOPPED_TYPING = 24;

    // ----- 获取聊天记录 ------

    /**
     * 获取和这个聊天对象的聊天记录
     *
     * 附带
     * varint64 对方id
     * varint64 当前已经缓存着的私聊的最大时间 (没有缓存过, 则发0)
     */
    static final int C2S_GET_CHAT_HISTORY = 12;

    /**
     * 返回私聊聊天记录
     *
     * varint64 对方id
     * boolean 读完这批聊天记录后, 是否还有更多聊天记录
     * 接下来的读取方式
     * while(byteArray.available){
     *     var isMySpeech:Boolean = byteArray.readBoolean(); // 这句话是否是我说的
     *     var time:Number = byteArray.readVarInt64(); // 这条消息的时间
     *     var len :int = byteArray.readVarInt32();
     *     var chatMessageProto : ByteArray = new ByteArray();
     *     byteArray.readBytes(chatMessageProto, 0, len); // 读取ChatMessage的proto
     * }
     */
    static final int S2C_GET_CHAT_HISTORY_RESULT = 25;

    /**
     * 获取私聊记录失败
     *
     * 附带varint32错误码
     *
     * 1. 获取太频繁, 没有等够cd. 将来当做外挂处理
     * 2. 你之前没有发送和对方窗口私聊的消息. 将来当做外挂处理
     * 3. 服务器内部错误, 稍后再试
     */
    static final int S2C_GET_CHAT_HISTORY_FAIL = 26;
    static final ChannelBuffer ERROR_GET_CHAT_HISTORY_TOO_FREQUENT = getChatHistoryFail(1);
    static final ChannelBuffer ERROR_GET_CHAT_HISTORY_NOT_CHATTING_WITH_HIM = getChatHistoryFail(2);
    static final ChannelBuffer ERROR_GET_CHAT_HISTORY_INTERNAL_ERROR = getChatHistoryFail(3);

    // ----- 下线时给我留言的人 ------

    /**
     * 刚上线时, 如果不在线时, 有人给你留言, 将会收到提醒
     *
     * 所有留言的人都会在这一条消息中附带
     *
     * 数据读取方法
     *
     * while(byteArray.available){
     *
     *  var id:Number = byteArray.readVarInt64(); // 对方id
     *  var name:String = byteArray.readUTF(); // 对方名字
     *  var level:int = byteArray.readVarInt32(); // 对方等级
     * }
     */
    static final int S2C_THEY_LEFT_MSG_WHEN_YOU_OFFLINE = 27;

    // ----- 队伍聊天 -----
    /**
     * 请求发送队伍聊天, 请求后, 不要直接清掉聊天框中的消息把消息放到队伍频道中, 而要等待服务器返回
     * 服务器返回前, 需要锁定聊天栏, 不让他继续输入, 按回车忽略, 点击发送忽略(不要把按钮做成不可点击)
     *
     * 离开队伍后, 说话频率不清. 保留到加入新队伍
     *
     * 客户端发送前就需要检查 等级/频率/长度. 不符合的就本地弹出错误消息.
     *
     * 附带 ChatMessage这个proto
     */
    static final int C2S_TEAM_CHAT = 13;

    /**
     * 队伍聊天失败
     *
     * 附带varint32的错误码
     *
     * 1. 发送太频繁
     * 2. 话太长
     * 3. 格式非法. 消息后面解不出ChatMessage
     * 4. 你没有队伍
     */
    static final int S2C_TEAM_CHAT_FAIL = 28;
    static final ChannelBuffer ERROR_TEAM_CHAT_TOO_FREQUENT = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_TEAM_CHAT_FAIL, 1);
    static final ChannelBuffer ERROR_TEAM_CHAT_TOO_LONG = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_TEAM_CHAT_FAIL, 2);
    static final ChannelBuffer ERROR_TEAM_CHAT_ILLEGAL_DATA = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_TEAM_CHAT_FAIL, 3);
    static final ChannelBuffer ERROR_TEAM_CHAT_NO_TEAM = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_TEAM_CHAT_FAIL, 4);

    /**
     * 队伍聊天发送成功, 后面没有附带的信息. 客户端自己把聊天栏中的话放到队伍频道中
     * 发送者只会收到发送成功消息, 别人会收到S2C_TEAM_CHAT_BROADCAST广播消息. 发送者不会收到广播消息
     */
    static final int S2C_TEAM_CHAT_SUCCESS = 29;
    static final ChannelBuffer teamChatSuccess = onlySendHeaderMessage(
            MODULE_ID, S2C_TEAM_CHAT_SUCCESS);

    /**
     * 别人在队伍频道说了话
     *
     * 附带ChatMessage这个proto. 从中获取英雄的相关信息
     */
    static final int S2C_TEAM_CHAT_BROADCAST = 30;

    // ----- 帮派聊天 -----

    /**
     * 请求发送帮派聊天, 请求后, 不要直接清掉聊天框中的消息把消息放到帮派频道中, 而要等待服务器返回
     * 服务器返回前, 需要锁定聊天栏, 不让他继续输入, 按回车忽略, 点击发送忽略(不要把按钮做成不可点击)
     *
     * 离开帮派后, 说话频率不清. 保留到加入新帮派
     *
     * 客户端发送前就需要检查 等级/频率/长度. 不符合的就本地弹出错误消息.
     *
     * 附带 ChatMessage这个proto
     */
    static final int C2S_GUILD_CHAT = 14;

    /**
     * 帮派聊天失败
     *
     * 附带varint32的错误码
     *
     * 1. 发送太频繁
     * 2. 话太长
     * 3. 格式非法. 消息后面解不出ChatMessage
     * 4. 你没有帮派
     */
    static final int S2C_GUILD_CHAT_FAIL = 31;
    static final ChannelBuffer ERROR_GUILD_CHAT_TOO_FREQUENT = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_GUILD_CHAT_FAIL, 1);
    static final ChannelBuffer ERROR_GUILD_CHAT_TOO_LONG = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_GUILD_CHAT_FAIL, 2);
    static final ChannelBuffer ERROR_GUILD_CHAT_ILLEGAL_DATA = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_GUILD_CHAT_FAIL, 3);
    static final ChannelBuffer ERROR_GUILD_CHAT_NO_GUILD = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_GUILD_CHAT_FAIL, 4);

    /**
     * 帮派聊天发送成功, 后面没有附带的信息. 客户端自己把聊天栏中的话放到帮派频道中
     * 发送者只会收到发送成功消息, 别人会收到S2C_GUILD_CHAT_BROADCAST广播消息. 发送者不会收到广播消息
     */
    static final int S2C_GUILD_CHAT_SUCCESS = 32;
    static final ChannelBuffer guildChatSuccess = onlySendHeaderMessage(
            MODULE_ID, S2C_GUILD_CHAT_SUCCESS);

    /**
     * 别人在帮派频道说了话
     *
     * 附带ChatMessage这个proto. 从中获取英雄的相关信息
     */
    static final int S2C_GUILD_CHAT_BROADCAST = 33;

    // --- 本盟内聊天 ---

    /**
     * 本盟内聊天. 聊天的频率也是15秒2条. 别的和世界聊天一样. 等级限制也是和世界聊天一样20级
     *
     * 客户端发送前就需要检查 等级/频率/长度. 不符合的就本地弹出错误消息.
     *
     * 附带 ChatMessage这个proto
     */
    public static final int C2S_SELF_UNION_CHAT = 15;

    /**
     * 发送失败, 保留聊天框中的信息, 弹出错误提示
     *
     * 附带varint32的错误码
     *
     * 1. 等级不够
     * 2. 发送太频繁
     * 3. 话太长
     * 4. 格式非法. 消息后面解不出ChatMessage
     */
    static final int S2C_SELF_UNION_CHAT_FAIL = 34;
    static final ChannelBuffer ERROR_SELF_UNION_CHAT_NOT_ENOUGH_LEVEL = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_SELF_UNION_CHAT_FAIL, 1);
    static final ChannelBuffer ERROR_SELF_UNION_CHAT_TOO_FREQUENT = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_SELF_UNION_CHAT_FAIL, 2);
    static final ChannelBuffer ERROR_SELF_UNION_CHAT_TOO_LONG = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_SELF_UNION_CHAT_FAIL, 3);
    static final ChannelBuffer ERROR_SELF_UNION_CHAT_ILLEGAL_FORMAT = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_SELF_UNION_CHAT_FAIL, 4);

    /**
     * 发送成功, 客户端自己把聊天栏中的话放到本盟聊天频道中
     * 发送者不会收到自己话的S2C_SELF_UNION_CHAT_BROADCAST
     *
     * 没有附带信息
     */
    static final int S2C_SELF_UNION_CHAT_SUCCESS = 35;
    static final ChannelBuffer selfUnionChatSuccess = onlySendHeaderMessage(
            MODULE_ID, S2C_SELF_UNION_CHAT_SUCCESS);

    /**
     * 别人在本盟频道说了话
     *
     * 附带ChatMessage这proto
     */
    static final int S2C_SELF_UNION_CHAT_BROADCAST = 36;

    // ----------------------
    static ChannelBuffer theyLeftMsgWhenYouOffline(
            List<OfflineLeaveMsgHeroInfo> infos){

        int len = 0;
        OfflineLeaveMsgHeroInfo info;
        for (int i = infos.size(); --i >= 0;){
            info = infos.get(i);
            len = len + computeVarInt64Size(info.id) + 2 + info.name.length
                    + computeVarInt32Size(info.level);
        }

        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID,
                S2C_THEY_LEFT_MSG_WHEN_YOU_OFFLINE, len);
        for (int i = infos.size(); --i >= 0;){
            info = infos.get(i);
            writeVarInt64(buffer, info.id);
            writeUTF(buffer, info.name);
            writeVarInt32(buffer, info.level);
        }
        return buffer;
    }

    static ChannelBuffer noChatHistoryResult(long targetID){
        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID,
                S2C_GET_CHAT_HISTORY_RESULT, computeVarInt64Size(targetID) + 1);
        BufferUtil.writeVarInt64(buffer, targetID);
        BufferUtil.writeBoolean(buffer, false);
        return buffer;
    }

    static ChannelBuffer getChatHistoryResult(List<OfflineChatMsg> chats,
            long targetID, int batchSize){
        int len = 1 + computeVarInt64Size(targetID);
        OfflineChatMsg msg;

        final int toSendChatCount = Math.min(chats.size(), batchSize - 1);
        for (int i = toSendChatCount; --i >= 0;){
            msg = chats.get(i);
            ++len; // 是否是我说的byte
            len += computeVarInt64Size(msg.time); // 发送时间varint64
            len += computeVarInt32Size(msg.data.length); // 下面data的长度varint32
            len += msg.data.length; // 真正的data
        }

        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID,
                S2C_GET_CHAT_HISTORY_RESULT, len);
        BufferUtil.writeVarInt64(buffer, targetID);
        BufferUtil.writeBoolean(buffer, batchSize == chats.size());
        for (int i = 0; i < toSendChatCount; i++){
            msg = chats.get(i);
            BufferUtil.writeBoolean(buffer, msg.senderID != targetID); // 是否是我说的
            BufferUtil.writeVarInt64(buffer, msg.time);
            BufferUtil.writeVarInt32(buffer, msg.data.length);
            buffer.writeBytes(msg.data);
        }
        return buffer;
    }

    private static ChannelBuffer getChatHistoryFail(int errorID){
        return onlySendHeadAndAVarInt32Message(MODULE_ID,
                S2C_GET_CHAT_HISTORY_FAIL, errorID);
    }

    public static ChannelBuffer otherIsTyping(long id){
        return onlySendHeadAndAVarInt64Message(MODULE_ID, S2C_OTHER_IS_TYPING,
                id);
    }

    public static ChannelBuffer otherStoppedTyping(long id){
        return onlySendHeadAndAVarInt64Message(MODULE_ID,
                S2C_OTHER_STOPPED_TYPING, id);
    }

    public static ChannelBuffer receivedWindowChat(long time, ChatMessage msg){
        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID,
                S2C_RECEIVED_WINDOW_CHAT,
                computeVarInt64Size(time) + msg.getSerializedSize());
        BufferUtil.writeVarInt64(buffer, time);
        BufferUtil.writeProto(buffer, msg);
        return buffer;
    }

    private static ChannelBuffer sendWindowChatFail(int errorID){
        return onlySendHeadAndAVarInt32Message(MODULE_ID,
                S2C_SEND_WINDOW_CHAT_FAIL, errorID);
    }

    static ChannelBuffer openWindowError(int errorID){
        return onlySendHeadAndAVarInt32Message(MODULE_ID,
                S2C_WINDOW_CHAT_OPEN_ERROR, errorID);
    }

    static ChannelBuffer openWindowReplyMood(long targetID, boolean isOnline,
            int level, byte[] mood, int raceID){
        int raceAndOnline = isOnline ? (raceID << 1 | 1) : (raceID << 1);
        ChannelBuffer buffer = newFixedSizeMessage(
                MODULE_ID,
                S2C_WINDOW_CHAT_OPEN_REPLY_MOOD,
                computeVarInt32Size(raceAndOnline) + mood.length
                        + BufferUtil.computeVarInt64Size(targetID)
                        + BufferUtil.computeVarInt32Size(level));

        BufferUtil.writeVarInt64(buffer, targetID);
        BufferUtil.writeVarInt32(buffer, raceAndOnline);
        BufferUtil.writeVarInt32(buffer, level);
        buffer.writeBytes(mood);
        return buffer;
    }

    public static ChannelBuffer receivedNormalPrivateChat(long time,
            ChatMessage msg){
        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID,
                S2C_RECEIVED_NORMAL_PRIVATE_CHAT, computeVarInt64Size(time)
                        + msg.getSerializedSize());
        BufferUtil.writeVarInt64(buffer, time);
        BufferUtil.writeProto(buffer, msg);
        return buffer;
    }

    private static ChannelBuffer normalPrivateChatError(int errorID){
        return onlySendHeadAndAVarInt32Message(MODULE_ID,
                S2C_NORMAL_PRIVATE_CHAT_FAIL, errorID);
    }

    private static ChannelBuffer goodsInfoReplyError(int errorID){
        return onlySendHeadAndAVarInt32Message(MODULE_ID,
                S2C_GOODS_INFO_REPLY_ERROR, errorID);
    }

    public static ChannelBuffer goodsInfoReply(byte[] goodsProtoByteString){
        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID,
                S2C_GOODS_INFO_REPLY, goodsProtoByteString.length);
        buffer.writeBytes(goodsProtoByteString);
        return buffer;
    }

    static ChannelBuffer selfUnionBroadcast(ChatMessage msg){
        return newProtobufMessage(MODULE_ID, S2C_SELF_UNION_CHAT_BROADCAST, msg);
    }

    static ChannelBuffer paidChatBroadcast(ChatMessage msg){
        return newProtobufMessage(MODULE_ID, S2C_PAID_CHAT_BROADCAST, msg);
    }

    static ChannelBuffer paidChatForbidden(long endTime){
        return onlySendHeadAndAVarInt64Message(MODULE_ID,
                S2C_PAID_CHAT_FORBIDDEN, endTime);
    }

    static ChannelBuffer paidChatFail(int errorID){
        return onlySendHeadAndAVarInt32Message(MODULE_ID, S2C_PAID_CHAT_FAIL,
                errorID);
    }

    static ChannelBuffer teamChatBroadcast(ChatMessage chatMessage){
        return newProtobufMessage(MODULE_ID, S2C_TEAM_CHAT_BROADCAST,
                chatMessage);
    }

    static ChannelBuffer guildChatBroadcast(ChatMessage chatMessage){
        return newProtobufMessage(MODULE_ID, S2C_GUILD_CHAT_BROADCAST,
                chatMessage);
    }

    static ChannelBuffer sceneChatBroadcast(ChatMessage chatMessage){
        return newProtobufMessage(MODULE_ID, S2C_SCENE_CHAT_BROADCAST,
                chatMessage);
    }

    static ChannelBuffer sceneChatFail(int errorID){
        return onlySendHeadAndAVarInt32Message(MODULE_ID, S2C_SCENE_CHAT_FAIL,
                errorID);
    }

    static ChannelBuffer worldChatFail(int errorID){
        return onlySendHeadAndAVarInt32Message(MODULE_ID, S2C_WORLD_CHAT_FAIL,
                errorID);
    }

    static ChannelBuffer worldChatBroadcast(ChatMessage chatMessage){
        return newProtobufMessage(MODULE_ID, S2C_WORLD_CHAT_BROADCAST,
                chatMessage);
    }

}
