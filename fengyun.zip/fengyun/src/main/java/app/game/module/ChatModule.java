package app.game.module;

import static app.game.module.ChatMessages.*;
import static app.game.module.MiscModule.DisconnectReason.BAD_CHAT_DATA;
import static app.protobuf.LogContent.LogEnum.OperateType.PAID_CHAT;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import org.jboss.netty.buffer.ChannelBuffer;
import org.joda.time.DateTimeConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.cluster.client.combat.ClusterClientCombatServerContainer;
import app.game.data.goods.GoodsData;
import app.game.data.goods.GoodsDatas;
import app.game.entity.Hero;
import app.game.entity.RelationList;
import app.game.module.GoodsContainerMessages.ReduceCooldownGoodsResult;
import app.game.module.guild.Guild;
import app.game.module.guild.GuildMember;
import app.game.module.scene.HeroFightModule;
import app.game.module.team.Team;
import app.game.module.team.TeamMember;
import app.game.service.DBService;
import app.game.service.IThreadService;
import app.game.service.TimeService;
import app.game.service.WorldService;
import app.message.ISender;
import app.protobuf.HeroContent.ChatMessage;
import app.protobuf.HeroContent.SingleRelation;
import app.protobuf.RelationContent.RelationProto;
import app.utils.IDUtils;
import app.utils.IndividualServerConfig;
import app.utils.VariableConfig;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.google.inject.Inject;
import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;
import com.lmax.disruptor.EventFactory;
import com.lmax.disruptor.InsufficientCapacityException;
import com.mokylin.collection.LongHashSet;
import com.mokylin.sink.util.BufferUtil;
import com.mokylin.sink.util.Empty;
import com.mokylin.sink.util.StringEncoder;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.concurrent.NoOpCleaner;
import com.mokylin.sink.util.concurrent.RingBufferWrapper;
import com.mokylin.sink.util.holder.BooleanHolder;

public class ChatModule{
    private static final Logger logger = LoggerFactory
            .getLogger(ChatModule.class);

    private static final long GET_CHAT_HISTORY_INTERVAL = 3L * DateTimeConstants.MILLIS_PER_SECOND;
    private static final int GET_CHAT_HISTORY_BATCH = 21; // 需要+1, 判断后面是否还有聊天记录

    private final IThreadService threadService;
    private final WorldService worldService;
    private final DBService dbService;
    private final TimeService timeService;
    private final RelationModule relationModule;
    private final IndividualServerConfig individualServerConfig;

    private final GoodsData paidChatGoodsData;
    private final GoodsDatas goodsDatas;
    private final GoodsContainerModule goodsContainerModule;

    private final RingBufferWrapper<ChatEvent> chatEventBuffer;
    private final ChatUpdater updater;

    private final LoadingCache<Long, OfflineHeroInfo> offlineHeroInfoCache;

    private final ClusterClientCombatServerContainer combatServerContainer;

    private final VariableConfig variableConfig;

    private final boolean isDebug;

    @Inject
    ChatModule(IThreadService threadService, WorldService worldService,
            DBService dbService, TimeService timeService,
            RelationModule relationModule, GoodsDatas goods,
            GoodsContainerModule goodsContainerModule,
            ClusterClientCombatServerContainer combatServerContainer,
            IndividualServerConfig config, VariableConfig variableConfig){
        this.isDebug = config.isDebug();
        this.threadService = threadService;
        this.worldService = worldService;
        this.dbService = dbService;
        this.goodsDatas = goods;
        this.timeService = timeService;
        this.relationModule = relationModule;
        this.combatServerContainer = combatServerContainer;
        this.individualServerConfig = config;
        this.variableConfig = variableConfig;

        this.goodsContainerModule = goodsContainerModule;
        this.paidChatGoodsData = goods.getPaidChatGoods();

        offlineHeroInfoCache = CacheBuilder.newBuilder().concurrencyLevel(4)
                .initialCapacity(1024).maximumSize(2048)
                .build(new BlackListCacheLoader(dbService));

        chatEventBuffer = new RingBufferWrapper<ChatEvent>(ChatEvent.FACTORY,
                4096, false);

        updater = new ChatUpdater(dbService, chatEventBuffer);
        threadService.getScheduledExecutorService().scheduleAtFixedRate(
                updater, 1, 1, TimeUnit.SECONDS);
    }

    public void onMessage(int sequenceID, ChannelBuffer buffer,
            HeroController hc){
        switch (sequenceID){
            case C2S_WORLD_CHAT:{
//                onWorldChat(buffer, hc);
                return;
            }

            case C2S_SELF_UNION_CHAT:{
                onSelfUnionChat(buffer, hc);
                return;
            }

            case C2S_SCENE_CHAT:{
                onSceneChat(buffer, hc);
                return;
            }

            case C2S_TEAM_CHAT:{
                onTeamChat(buffer, hc);
                return;
            }

            case C2S_GUILD_CHAT:{
                onGuildChat(buffer, hc);
                return;
            }

            case C2S_PAID_CHAT:{
                onPaidChat(buffer, hc);
                return;
            }

            case C2S_GOODS_INFO_QUERY:{
                onGoodsInfoQuery(buffer, hc);
                return;
            }

//            case C2S_NORMAL_PRIVATE_CHAT:{
//                processPrivateChat(buffer, hc, true);
//                return;
//            }

            case C2S_WINDOW_CHAT_OPEN_AND_GET_MOOD:{
                onWindowChatOpenAndGetMood(buffer, hc);
                return;
            }

            case C2S_WINDOW_CHAT_OPEN_AND_MOOD_ALREADY_KNOWN:{
                onWindowChatOpenAndMoodAlreadyKnown(buffer, hc);
                return;
            }

            case C2S_WINDOW_CHAT_CLOSED:{
                onWindowChatClosed(buffer, hc);
                return;
            }

            case C2S_SEND_WINDOW_CHAT:{
                processPrivateChat(buffer, hc, false);
                return;
            }

            case C2S_I_AM_TYPING:{
                onIAmTyping(buffer, hc);
                return;
            }

            case C2S_I_STOPPED_TYPING:{
                onIStoppedTyping(buffer, hc);
                return;
            }

            case C2S_GET_CHAT_HISTORY:{
                onGetChatHistory(buffer, hc);
                return;
            }

            default:{
                logger.warn("收到未知的ChatModule消息: {}", sequenceID);
            }
        }
    }

    /**
     * 获取聊天记录
     * @param buffer
     * @param hc
     */
    private void onGetChatHistory(ChannelBuffer buffer, HeroController hc){
        long ctime = timeService.getCurrentTime();
        if (ctime < hc.nextCanGetChatHistoryTime){
            hc.sendMessage(ERROR_GET_CHAT_HISTORY_TOO_FREQUENT);
            return;
        }

        hc.nextCanGetChatHistoryTime = ctime + GET_CHAT_HISTORY_INTERVAL;

        final long targetID = BufferUtil.readVarInt64(buffer);
        if (!hc.isWindowChatInterested(targetID)){
            hc.sendMessage(ERROR_GET_CHAT_HISTORY_NOT_CHATTING_WITH_HIM);
            return;
        }

        final long maxTime = BufferUtil.readVarInt64(buffer);

        final long myID = hc.combinedID;
        final ISender mySender = hc.getSender();
        final BooleanHolder isOffline = hc.getIsOffline();

        threadService.getDbExecutor().execute(new Runnable(){
            @Override
            public void run(){
                if (isOffline.get()){
                    return;
                }
//                logger.debug("获取聊天记录中. {} & {} before {}", myID, targetID,
//                        maxTime);
                List<OfflineChatMsg> chatHistory;
                try{
                    chatHistory = dbService.getChatHistory(myID, targetID,
                            maxTime, GET_CHAT_HISTORY_BATCH);
                } catch (Throwable e){
                    logger.error("聊天模块获取聊天记录出错", e);
                    mySender.sendMessage(ERROR_GET_CHAT_HISTORY_INTERNAL_ERROR);
                    return;
                }

                if (chatHistory == null){
                    // 没有更多聊天记录了
                    logger.debug("没有更多的聊天记录了");
                    mySender.sendMessage(noChatHistoryResult(targetID));
                    return;
                }

//                int lastCount = chatHistory.size() == GET_CHAT_HISTORY_BATCH ? GET_CHAT_HISTORY_BATCH - 2
//                        : chatHistory.size() - 1;
//                logger.debug("获取到{}条聊天记录, 最早的一条时间为 {}", chatHistory.size(),
//                        chatHistory.get(lastCount).time);
                mySender.sendMessage(getChatHistoryResult(chatHistory,
                        targetID, GET_CHAT_HISTORY_BATCH));
            }
        });
    }

    // ------- 对方正在输入 ---------
    private void onIStoppedTyping(ChannelBuffer buffer, HeroController hc){
        long id = BufferUtil.readVarInt64(buffer);

        if (!hc.isWindowChatInterested(id)){
            logger.warn("私聊模块收到自己停止输入消息, 但是并没有对对方感兴趣");
            if (isDebug){
                hc.sendMessage(GMModule.gmReply("私聊模块收到自己停止输入消息, 但是并没有对对方感兴趣"));
            }
            return;
        }

        // id一定存在
        ConnectedUser cu = worldService.getUser(id);
        if (cu != null){
            HeroController targetHc = cu.getHeroController();
            if (targetHc != null
                    && targetHc.isWindowChatInterested(hc.combinedID)){
                // 对方也对我感兴趣

                targetHc.sendMessage(hc.getIStoppedTypingMsg());
            }
        }
    }

    private void onIAmTyping(ChannelBuffer buffer, HeroController hc){
        long id = BufferUtil.readVarInt64(buffer);

        // 如果没有打开着与对方的私聊窗口
        if (!hc.isWindowChatInterested(id)){
            logger.warn("私聊模块收到自己正在输入消息, 但是并没有对对方有兴趣");
            if (isDebug){
                hc.sendMessage(GMModule.gmReply("私聊模块收到自己正在输入消息, 但是并没有对对方有兴趣"));
            }
            return;
        }

        // id一定存在
        ConnectedUser cu = worldService.getUser(id);
        if (cu != null){
            HeroController targetHc = cu.getHeroController();
            if (targetHc != null
                    && targetHc.isWindowChatInterested(hc.combinedID)){
                // 对方也对我感兴趣

                targetHc.sendMessage(hc.getIAmTypingMsg());
            }
        }
    }

    // ------- 私聊窗口关注 ---------
    private void onWindowChatClosed(ChannelBuffer buffer, HeroController hc){
        long id = BufferUtil.readVarInt64(buffer);

        hc.removeWindowChatInterest(id);
    }

    private void onWindowChatOpenAndMoodAlreadyKnown(ChannelBuffer buffer,
            HeroController hc){
        if (hc.getWindowChatInterestedCount() >= 5){
            logger.warn("ChatModule窗口聊天同时关注的人太多了");
            if (isDebug){
                hc.sendMessage(GMModule.gmReply("私聊窗口同时关注的人太多了"));
            }
            return;
        }

        long id = BufferUtil.readVarInt64(buffer);

        if (id == hc.combinedID){
            logger.warn("ChatModule.onWindowChatOpenAndMoodAlreadyKnown, 发来的id是自己的id");
            return;
        }

        boolean unique = hc.addWindowChatInterest(id);
        if (!unique){
            logger.warn("私聊时重复添加了聊天兴趣");
            if (isDebug){
                hc.sendMessage(GMModule.gmReply("私聊时重复添加了聊天兴趣"));
            }
        }
    }

    private void onWindowChatOpenAndGetMood(ChannelBuffer buffer,
            HeroController hc){
        if (hc.getWindowChatInterestedCount() >= 5){
            logger.warn("ChatModule窗口聊天同时关注的人太多了");
            if (isDebug){
                hc.sendMessage(GMModule.gmReply("私聊窗口同时关注的人太多了"));
            }
            hc.sendMessage(ERROR_WINDOW_CHAT_OPEN_REGISTERED_TOO_MANY);
            return;
        }

        long id = BufferUtil.readVarInt64(buffer);
        if (id == hc.combinedID){
            logger.warn("ChatModule.onWindowChatOpenAndGetMood, 发来的id是自己的id");
            return;
        }

        ConnectedUser cu = worldService.getUser(id);
        if (cu != null){
            HeroController targetHc = cu.getHeroController();
            if (targetHc == null){
                hc.sendMessage(ERROR_WINDOW_CHAT_OPEN_ID_NOT_EXIST);
                return;
            }

            if (targetHc.hasEnterSceneForTheFirstTime()){
                // 在线
                doAddChatInterestOrAlreadyInterested(hc, id, targetHc.getHero()
                        .getRelationList().getMoodBytes(), true, targetHc
                        .getHero().getLevel(), targetHc.getHero().getRace()
                        .getId());
                return;
            }

            // 还在进入场景, 没在线
            doAddChatInterestOrAlreadyInterested(hc, id, targetHc.getHero()
                    .getRelationList().getMoodBytes(), false, targetHc
                    .getHero().getLevel(), targetHc.getHero().getRace().getId());
            return;
        }

        // 不在线
        OfflineHeroInfo offlineHeroInfo;
        try{
            offlineHeroInfo = offlineHeroInfoCache.get(id);
        } catch (ExecutionException e){
            logger.error(
                    "ChatModule.onWindowChatOpenAndGetMood中, 获取offlineHeroInfoCache失败",
                    e);
            hc.sendMessage(ERROR_WINDOW_CHAT_OPEN_INTERNAL_ERROR);
            return;
        }

        if (offlineHeroInfo == OfflineHeroInfo.EMPTY_OFFLINE_HERO_INFO){
            hc.sendMessage(ERROR_WINDOW_CHAT_OPEN_ID_NOT_EXIST);
            return;
        }

        doAddChatInterestOrAlreadyInterested(hc, id, offlineHeroInfo.mood,
                false, offlineHeroInfo.level, offlineHeroInfo.raceID);
    }

    private void doAddChatInterestOrAlreadyInterested(HeroController hc,
            long targetID, byte[] targetMood, boolean targetIsOnline,
            int targetLevel, int targetRaceID){
        if (hc.addWindowChatInterest(targetID)){
            // 添加兴趣成功
            hc.sendMessage(openWindowReplyMood(targetID, targetIsOnline,
                    targetLevel, targetMood, targetRaceID));
        } else{
            logger.warn("私聊时重复添加了聊天兴趣");
            if (isDebug){
                hc.sendMessage(GMModule.gmReply("私聊时重复添加了聊天兴趣"));
            }
            hc.sendMessage(ERROR_WINDOW_CHAT_OPEN_DUP_REGISTER);
        }
    }

    // ---------------------

    // ---- 私聊 ----

    /**
     * 统一处理私聊, 仅在发送的消息的消息头这里区分左下角私聊还是窗口私聊
     *
     * @param buffer
     * @param hc
     * @param isNormalChat 是否是左下角私聊
     */
    private void processPrivateChat(ChannelBuffer buffer, HeroController hc,
            boolean isNormalChat){

        long ctime = timeService.getCurrentTime();

        // 检查私聊频率
        if (!hc.getHero().isGm
                && !hc.privateChatFrequencyLimiter.canChat(ctime)){
            hc.sendMessage(isNormalChat ? ERROR_NORMAL_CHAT_TOO_FREQUENT
                    : ERROR_SEND_WINDOW_CHAT_TOO_FREQUENT);
            return;
        }

        // 私聊对象id
        long targetID = BufferUtil.readVarInt64(buffer);

        if (targetID == hc.combinedID){
            hc.sendMessage(isNormalChat ? ERROR_NORMAL_CHAT_NOT_EXISTS
                    : ERROR_SEND_WINDOW_CHAT_NOT_EXISTS);
            return;
        }

        if (hc.getHero().isSpeechLimited(ctime)){
            // 被禁言, 根据在不在线来发送对应的成功消息
            if (worldService.getUser(targetID) == null){
                hc.sendMessage(isNormalChat ? normalPrivateChatSuccessAndTargetOffline
                        : sendWindowChatSuccessAndTargetOffline);
            } else{
                hc.sendMessage(isNormalChat ? normalPrivateChatSuccessAndTargetOnline
                        : sendWindowChatSuccessAndTargetOnline);
            }
            return;
        }

        hc.getHero().checkPrivateChat(targetID, ctime,
                variableConfig.P2P_CHAT_BAN_CHECK_MAX_COUNT);

        byte[] msgBytes = readRemainingData(buffer);

        // 获取私聊信息
        ChatMessage.Builder msgBuilder;
        try{
            msgBuilder = ChatMessage.newBuilder().mergeFrom(msgBytes);
        } catch (Throwable ex){
            hc.sendMessage(isNormalChat ? ERROR_NORMAL_CHAT_ILLEGAL_DATA
                    : ERROR_SEND_WINDOW_CHAT_ILLEGAL_DATA);
            if (++hc.chatIllegalDataCount >= 2){
                hc.disconnect(BAD_CHAT_DATA);
            }
            return;
        }
        hc.privateChatFrequencyLimiter.chated(ctime);

        if (msgBuilder.getHasMyPos()){
            fillMyPosChatMessage(msgBuilder, hc.getHeroFightModule());
            msgBytes = msgBuilder.build().toByteArray(); // 更新位置
        }

        // TODO 检查聊天长度

        // 看下对方是否在线

        ConnectedUser cu = worldService.getUser(targetID);
        if (cu != null){
            HeroController targetHc = cu.getHeroController();
            if (targetHc == null){
                hc.sendMessage(isNormalChat ? ERROR_NORMAL_CHAT_NOT_EXISTS
                        : ERROR_SEND_WINDOW_CHAT_NOT_EXISTS);
                return;
            }

            // 在线
            int relation = targetHc.getHero().getRelationList()
                    .getRelation(hc.combinedID);
            if (RelationList.isBlack(relation)){
                hc.sendMessage(isNormalChat ? ERROR_NORMAL_CHAT_BLACKED
                        : ERROR_SEND_WINDOW_CHAT_BLACKED);
                return;
            }

            // 没有被加黑名单
            if (targetHc.hasEnterSceneForTheFirstTime()){
                // 已经加载完第一个场景了, 可以发送消息
                hc.sendMessage(isNormalChat ? normalPrivateChatSuccessAndTargetOnline
                        : sendWindowChatSuccessAndTargetOnline);

                ChatMessage msg = fillChatMessage(msgBuilder,
                        hc.getHeroFightModule());
                targetHc.sendMessage(isNormalChat ? receivedNormalPrivateChat(
                        ctime, msg) : receivedWindowChat(ctime, msg));

                addChatEvent(hc.combinedID, targetID, ctime, msgBytes);

                // 将对方加到我的最近联系人
                relationModule.addRecent(
                        targetHc.getHero().getSingleRelation(), hc.getHero(),
                        hc.getSender(), true);

                // 将我加到对方的最近联系人
                targetHc.concurrentAddRecent(hc.getHero().getSingleRelation());
            } else{
                // 当做不在线
                hc.sendMessage(isNormalChat ? normalPrivateChatSuccessAndTargetOffline
                        : sendWindowChatSuccessAndTargetOffline);
                addChatEvent(hc.combinedID, targetID, ctime, msgBytes);

                // 将对方加到我的最近联系人
                relationModule.addRecent(
                        targetHc.getHero().getSingleRelation(), hc.getHero(),
                        hc.getSender(), false);
            }

            hc.getServices()
                    .getPlatformPushService()
                    .onChat(hc.getHero(), targetHc.getHero().getUserId(),
                            targetHc.getHero().getName(), 1,
                            msgBuilder.getSpeech(),
                            hc.getHeroFightModule().vClientIp);
            return;
        }

        // 对方真的不在线
        OfflineHeroInfo offlineHeroInfo;
        try{
            offlineHeroInfo = offlineHeroInfoCache.get(targetID);
        } catch (ExecutionException e){
            logger.error("获取OfflineHeroInfo出错", e);
            hc.sendMessage(isNormalChat ? ERROR_NORMAL_CHAT_INTERNAL_ERROR
                    : ERROR_SEND_WINDOW_CHAT_INTERNAL_ERROR);
            return;
        }

        if (offlineHeroInfo == OfflineHeroInfo.EMPTY_OFFLINE_HERO_INFO){
            // 英雄不存在
            hc.sendMessage(isNormalChat ? ERROR_NORMAL_CHAT_NOT_EXISTS
                    : ERROR_SEND_WINDOW_CHAT_NOT_EXISTS);
            return;
        }

        if (offlineHeroInfo.isBlacked(hc.combinedID)){
            // 被对方加入黑名单了
            hc.sendMessage(isNormalChat ? ERROR_NORMAL_CHAT_BLACKED
                    : ERROR_SEND_WINDOW_CHAT_BLACKED);
            return;
        }

        hc.sendMessage(isNormalChat ? normalPrivateChatSuccessAndTargetOffline
                : sendWindowChatSuccessAndTargetOffline);
        addChatEvent(hc.combinedID, targetID, ctime, msgBytes);

        // 将对方加到我的最近联系人
        relationModule.addRecent(offlineHeroInfo.singleRelation, hc.getHero(),
                hc.getSender(), false);

        hc.getServices()
                .getPlatformPushService()
                .onChat(hc.getHero(), IDUtils.getUserID(offlineHeroInfo.id),
                        StringEncoder.encode(offlineHeroInfo.name), 1,
                        msgBuilder.getSpeech(),
                        hc.getHeroFightModule().vClientIp);
    }

    private void onGoodsInfoQuery(ChannelBuffer buffer, HeroController hc){
        int id = BufferUtil.readVarInt32(buffer);
        GoodsData gd = goodsDatas.get(id);
        if (gd != null){
            hc.sendMessage(gd.getGoodsReplyInfoMsg());
        } else{
            hc.sendMessage(ERROR_REPLY_GOODS_INFO_NOT_EXIST);
        }
    }

    private void onPaidChat(ChannelBuffer buffer, HeroController hc){
        long ctime = timeService.getCurrentTime();

        Hero hero = hc.getHero();

        if (!hc.getHero().isGm
                && hero.getLevel() < hc.getServices().getVariableConfig().PAID_CHAT_LEVEL){
            hc.sendMessage(ERROR_PAID_CHAT_LEVEL_NOT_ENOUGH);
            return;
        }

        if (hero.isSpeechLimited(ctime)){
            hc.sendMessage(paidChatForbidden(hc.getHero()
                    .getSpeechLimitEndTime())); // 提示他被禁言
            return;
        }

        if (!hc.getHero().isGm && !hc.paidChatFrequencyLimiter.canChat(ctime)){
            hc.sendMessage(ERROR_PAID_CHAT_TOO_FREQUENT);
            return;
        }

        int chatGoodsPos = BufferUtil.readVarInt32(buffer);

        ChatMessage.Builder msgBuilder;
        try{
            msgBuilder = decodeChatMessage(buffer);
        } catch (Throwable ex){
            hc.sendMessage(ERROR_PAID_CHAT_ILLEGAL_DATA);
            if (++hc.chatIllegalDataCount >= 2){
                hc.disconnect(BAD_CHAT_DATA);
            }
            return;
        }

        // 免费喇叭
        if (!hero.isGm && !hero.tryFreeChat()){
            // 用物品

            ReduceCooldownGoodsResult result = goodsContainerModule
                    .tryReduceCooldownGoods(hc.getHero(), chatGoodsPos,
                            paidChatGoodsData, hc.getSender(), PAID_CHAT, 0,
                            ctime);
            switch (result){
                case SUCCESS:{
                    break;
                }
                case COOL_DOWN:{
                    hc.sendMessage(ERROR_PAID_CHAT_GOODS_CD);
                    return;
                }

                case GOODS_NOT_FOUND:{
                    hc.sendMessage(ERROR_PAID_CHAT_NO_GOODS);
                    return;
                }
                default:{
                    logger.error("goodsContainerModule.tryReduceCooldownGoods还有别的返回, 在扣除喇叭时没有判断. 新加的结果?");
                    hc.sendMessage(ERROR_PAID_CHAT_NO_GOODS);
                    return;
                }
            }
        }

        // 成功
        hc.paidChatFrequencyLimiter.chated(ctime);
        hc.sendMessage(paidChatSuccess);

        ChatMessage msg = fillChatMessage(msgBuilder, hc.getHeroFightModule());
        worldService.broadcastDroppableMsgToEnteredFirstSceneHero(
                paidChatBroadcast(msg), hc.combinedID); // 不发送给自己

        hc.getServices()
                .getPlatformPushService()
                .onChat(hc.getHero(), 0, "", 2, msgBuilder.getSpeech(),
                        hc.getHeroFightModule().vClientIp);
    }

    private void onGuildChat(ChannelBuffer buffer, HeroController hc){
        long ctime = timeService.getCurrentTime();
        if (!hc.getHero().isGm && !hc.guildChatFrequencyLimiter.canChat(ctime)){
            hc.sendMessage(ERROR_GUILD_CHAT_TOO_FREQUENT);
            return;
        }

        GuildMember guildMember = hc.getGuildMember();
        Guild guild = guildMember.getGuild();
        if (guild == null){
            hc.sendMessage(ERROR_GUILD_CHAT_NO_GUILD);
            return;
        }

        hc.guildChatFrequencyLimiter.chated(ctime);

        if (hc.getHero().isSpeechLimited(ctime)){
            hc.sendMessage(guildChatSuccess);
            return;
        }

        ChatMessage.Builder msgBuilder;
        try{
            msgBuilder = decodeChatMessage(buffer);
        } catch (Throwable ex){
            hc.sendMessage(ERROR_TEAM_CHAT_ILLEGAL_DATA);
            if (++hc.chatIllegalDataCount >= 2){
                hc.disconnect(BAD_CHAT_DATA);
            }
            return;
        }

        hc.sendMessage(guildChatSuccess);

        ChatMessage msg = fillChatMessage(msgBuilder, hc.getHeroFightModule());
        guild.broadcast(guildChatBroadcast(msg), hc.combinedID);

        hc.getServices()
                .getPlatformPushService()
                .onChat(hc.getHero(), 0, "", 6, msgBuilder.getSpeech(),
                        hc.getHeroFightModule().vClientIp);
    }

    private void onTeamChat(ChannelBuffer buffer, HeroController hc){
        long ctime = timeService.getCurrentTime();

        if (!hc.getHero().isGm && !hc.teamChatFrequencyLimiter.canChat(ctime)){
            hc.sendMessage(ERROR_TEAM_CHAT_TOO_FREQUENT);
            return;
        }

        TeamMember teamMember = hc.getTeamMember();
        Team team = teamMember.getTeam();
        if (team == null){
            hc.sendMessage(ERROR_TEAM_CHAT_NO_TEAM);
            return;
        }

        hc.teamChatFrequencyLimiter.chated(ctime);

        if (hc.getHero().isSpeechLimited(ctime)){
            // 被禁言
            hc.sendMessage(teamChatSuccess);
            return;
        }

        ChatMessage.Builder msgBuilder;
        try{
            msgBuilder = decodeChatMessage(buffer);
        } catch (Throwable ex){
            hc.sendMessage(ERROR_TEAM_CHAT_ILLEGAL_DATA);
            if (++hc.chatIllegalDataCount >= 2){
                hc.disconnect(BAD_CHAT_DATA);
            }
            return;
        }

        hc.sendMessage(teamChatSuccess);

        ChatMessage msg = fillChatMessage(msgBuilder, hc.getHeroFightModule());
        TeamMember[] members = team.getMembers();
        if (members != null){
            ChannelBuffer m = teamChatBroadcast(msg);
            for (TeamMember tm : members){
                if (tm.getID() != hc.combinedID){
                    tm.sendDroppableMessage(m);
                }
            }
        }

        hc.getServices()
                .getPlatformPushService()
                .onChat(hc.getHero(), 0, "", 7, msgBuilder.getSpeech(),
                        hc.getHeroFightModule().vClientIp);
    }

    private void onSceneChat(ChannelBuffer buffer, HeroController hc){
        long ctime = timeService.getCurrentTime();
        if (!hc.getHero().isGm
                && !hc.sceneChatFrequencyLimiter.chatIfCan(ctime)){
            hc.sendMessage(ERROR_SCENE_CHAT_TOO_FREQUENT);
            return;
        }

        if (hc.getHero().isSpeechLimited(ctime)){
            // 被禁言, 让他自娱自乐
            hc.sendMessage(sceneChatSuccess);
            return;
        }

        ChatMessage.Builder msgBuilder;
        try{
            msgBuilder = decodeChatMessage(buffer);
        } catch (Throwable ex){
            hc.sendMessage(ERROR_SCENE_CHAT_ILLEGAL_DATA);
            if (++hc.chatIllegalDataCount >= 2){
                hc.disconnect(BAD_CHAT_DATA);
            }
            return;
        }

        if (hc.getHero().getLevel() < 50){
            hc.getHero().checkSceneChat(msgBuilder.getSpeech(), ctime);
        }

        hc.sendMessage(sceneChatSuccess);

        ChatMessage msg = fillChatMessage(msgBuilder, hc.getHeroFightModule());
        hc.heroFightModule
                .broadcastDroppableMsgToParentButNotSelf(sceneChatBroadcast(msg)); // 如果在跨服场景, 也会广播给别的服

        hc.getServices()
                .getPlatformPushService()
                .onChat(hc.getHero(), 0, "", 8, msgBuilder.getSpeech(),
                        hc.getHeroFightModule().vClientIp);
    }

    private void onSelfUnionChat(ChannelBuffer buffer, HeroController hc){
        if (!hc.getHero().isGm
                && hc.getHero().getLevel() < VariableConfig.SELF_UNION_CHAT_LEVEL){
            hc.sendMessage(ERROR_SELF_UNION_CHAT_NOT_ENOUGH_LEVEL);
            return;
        }

        long ctime = timeService.getCurrentTime();
        if (!hc.getHero().isGm
                && !hc.selfUnionChatFrequencyLimiter.chatIfCan(ctime)){
            hc.sendMessage(ERROR_SELF_UNION_CHAT_TOO_FREQUENT);
            return;
        }

        if (hc.getHero().isSpeechLimited(ctime)){
            // 被禁言了, 告诉他发送成功, 自娱自乐
            hc.sendMessage(selfUnionChatSuccess);
            return;
        }

        ChatMessage.Builder msgBuilder;
        try{
            msgBuilder = decodeChatMessage(buffer);
        } catch (Throwable ex){
            hc.sendMessage(ERROR_SELF_UNION_CHAT_ILLEGAL_FORMAT);
            if (++hc.chatIllegalDataCount >= 2){
                hc.disconnect(BAD_CHAT_DATA);
            }
            return;
        }

        hc.sendMessage(selfUnionChatSuccess);

        ChatMessage msg = fillChatMessage(msgBuilder, hc.getHeroFightModule());
        worldService
                .broadcastDroppableMsgToEnteredFirstSceneHeroWithSameServerData(
                        selfUnionBroadcast(msg), hc.getServerData(),
                        hc.combinedID); // 不发送给自己

        hc.getServices()
                .getPlatformPushService()
                .onChat(hc.getHero(), 0, "", 5, msgBuilder.getSpeech(),
                        hc.getHeroFightModule().vClientIp);
    }

    private void onWorldChat(ChannelBuffer buffer, HeroController hc){
        if (hc.getHero().getLevel() < VariableConfig.WORLD_CHAT_LEVEL){
            hc.sendMessage(ERROR_WORLD_CHAT_NOT_ENOUGH_LEVEL);
            return;
        }

        long ctime = timeService.getCurrentTime();
        if (!hc.getHero().isGm
                && !hc.worldChatFrequencyLimiter.chatIfCan(ctime)){// 解不出也算上这次
            hc.sendMessage(ERROR_WORLD_CHAT_TOO_FREQUENT);
            return;
        }

        if (hc.getHero().isSpeechLimited(ctime)){
            // 被禁言了, 告诉他发送成功, 自娱自乐
            hc.sendMessage(worldChatSuccess);
            return;
        }

        ChatMessage.Builder msgBuilder;
        try{
            msgBuilder = decodeChatMessage(buffer);
        } catch (Throwable ex){
            hc.sendMessage(ERROR_WORLD_CHAT_ILLEGAL_DATA);
            if (++hc.chatIllegalDataCount >= 2){
                hc.disconnect(BAD_CHAT_DATA);
            }
            return;
        }
        hc.sendMessage(worldChatSuccess);

        ChatMessage msg = fillChatMessage(msgBuilder, hc.getHeroFightModule());
        worldService.broadcastDroppableMsgToEnteredFirstSceneHero(
                worldChatBroadcast(msg), hc.combinedID); // 不发送给自己

        hc.getServices()
                .getPlatformPushService()
                .onChat(hc.getHero(), 0, "", 4, msgBuilder.getSpeech(),
                        hc.getHeroFightModule().vClientIp);
    }

    private static ChatMessage fillChatMessage(ChatMessage.Builder builder,
            HeroFightModule hfm){
        Hero hero = hfm.getHero();

        if (hero.isGm){
            builder.setIsGm(true);
        }

        if (hero.isVip()){
            builder.setIsVip(true);
        }

        if (builder.getHasMyPos()){
            fillMyPosChatMessage(builder, hfm);
        }

        if (hfm.isLongCityMaster()){
            builder.setIsLongCityMaster(true);

            if (hfm.getGuildMember().isGuildLeader()){
                builder.setCityMasterType(1);
            }
        } else{
            if (hfm.isWsCityMaster()){
                builder.setIsWsCityMaster(true);

                if (hfm.getGuildMember().isGuildLeader()){
                    builder.setCityMasterType(2);
                }
            }
        }

        int pvipType = hfm.getPVipType();
        if (pvipType > 0){
            builder.setPlatformVip(pvipType);
        }

        return builder.setHeroId(hero.getID())
                .setHeroName(hero.getNameByteString())
                .setLevel(hero.getLevel()).build();
    }

    private static void fillMyPosChatMessage(ChatMessage.Builder builder,
            HeroFightModule hfm){
        builder.clearHasMyPos(); // 省点空间

        int pos = hfm.getTraceTargetPoint();
        int line = hfm.getLineNumber();

        builder.setSceneId(hfm.getHero().getFightData().getActualSceneID());
        builder.setSceneX(Utils.getHighShort(pos));
        builder.setSceneY(Utils.getLowShort(pos));
        builder.setSceneLine(line);
    }

    private static byte[] readRemainingData(ChannelBuffer buf){
        final int length = buf.readableBytes();
        byte[] array = new byte[length];
        buf.getBytes(buf.readerIndex(), array, 0, length);
        return array;
    }

    private static ChatMessage.Builder decodeChatMessage(ChannelBuffer buf)
            throws InvalidProtocolBufferException{

        final byte[] array;
        final int offset;
        final int length = buf.readableBytes();

        if (buf.hasArray()){
            array = buf.array();
            offset = buf.arrayOffset() + buf.readerIndex();
        } else{
            array = new byte[length];
            buf.getBytes(buf.readerIndex(), array, 0, length);
            offset = 0;
        }

        return ChatMessage.newBuilder().mergeFrom(array, offset, length);
    }

    // ---------- 私聊event保存 --------------

    public static class ChatCoupleIDStream extends java.io.InputStream{
        private long toReadID1;
        private long toReadID2;
        private int currentIndex;

        public void set(long id1, long id2){
            if (id1 > id2){
                this.toReadID1 = id1;
                this.toReadID2 = id2;
            } else{
                this.toReadID1 = id2;
                this.toReadID2 = id1;
            }
            currentIndex = -1;
        }

        @Override
        public int read() throws IOException{
            if (++currentIndex >= 16){
                return -1;
            }

            switch (currentIndex){
                case 0:
                    return (int) ((toReadID1 >>> 56) & 0xff);
                case 1:
                    return (int) ((toReadID1 >>> 48) & 0xff);
                case 2:
                    return (int) ((toReadID1 >>> 40) & 0xff);
                case 3:
                    return (int) ((toReadID1 >>> 32) & 0xff);
                case 4:
                    return (int) ((toReadID1 >>> 24) & 0xff);
                case 5:
                    return (int) ((toReadID1 >>> 16) & 0xff);
                case 6:
                    return (int) ((toReadID1 >>> 8) & 0xff);
                case 7:
                    return (int) (toReadID1 & 0xff);
                case 8:
                    return (int) ((toReadID2 >>> 56) & 0xff);
                case 9:
                    return (int) ((toReadID2 >>> 48) & 0xff);
                case 10:
                    return (int) ((toReadID2 >>> 40) & 0xff);
                case 11:
                    return (int) ((toReadID2 >>> 32) & 0xff);
                case 12:
                    return (int) ((toReadID2 >>> 24) & 0xff);
                case 13:
                    return (int) ((toReadID2 >>> 16) & 0xff);
                case 14:
                    return (int) ((toReadID2 >>> 8) & 0xff);
                case 15:
                    return (int) (toReadID2 & 0xff);

                default:
                    throw new IllegalStateException(
                            "ChatModule.ChatEvent.read时, currentIndex不合法: "
                                    + currentIndex);
            }
        }

    }

    public static class ChatEvent extends NoOpCleaner{
        public static final EventFactory<ChatEvent> FACTORY = new EventFactory<ChatModule.ChatEvent>(){

            @Override
            public ChatEvent newInstance(){
                return new ChatEvent();
            }
        };

        public ChatEvent(){
            this.coupleIDStream = new ChatCoupleIDStream();
        }

        public long senderID;
        public long receiverID;

        public long time;
        public byte[] chatMessageProto;

        public final ChatCoupleIDStream coupleIDStream;

        @Override
        public void handle(){
            throw new UnsupportedOperationException();
        }
    }

    private void addChatEvent(long senderID, long receiverID, long time,
            byte[] data){
        try{
            long sequence = chatEventBuffer.tryNext();
            try{
                ChatEvent event = chatEventBuffer.get(sequence);
                event.senderID = senderID;
                event.receiverID = receiverID;

                event.time = time;
                event.chatMessageProto = data;
            } finally{
                chatEventBuffer.publish(sequence);
            }
        } catch (InsufficientCapacityException ex){
            logger.error("ChatModule.addChatEvent满, 放弃");
        }
    }

    public void close(){
        try{
            dbService.processChatEvents(chatEventBuffer);
        } catch (Throwable ex){
            logger.error("ChatModule.close出错", ex);
        }
    }

    public static class OfflineChatMsg{
        public final byte[] data;
        public final long time;
        public final long senderID;

        public OfflineChatMsg(byte[] data, long time, long senderID){
            super();
            this.data = data;
            this.time = time;
            this.senderID = senderID;
        }

        @Override
        public int hashCode(){
            return (int) time + data.length;
        }

        @Override
        public boolean equals(Object obj){
            if (obj instanceof OfflineChatMsg){
                OfflineChatMsg o = (OfflineChatMsg) obj;
                return o.time == time && Arrays.equals(o.data, data);
            }
            return false;
        }
    }

    public static class OfflineLeaveMsgHeroInfo{

        public final long id;
        public final byte[] name;
        public final int level;

        public OfflineLeaveMsgHeroInfo(long id, byte[] name, int easyInfo){
            this.id = id;
            this.name = name;
            this.level = Hero.decodeEasyInfoGetLevel(easyInfo);
        }
    }

    public void getOfflineLeaveMsgHero(long id, ISender sender, long offlineTime){
        List<OfflineLeaveMsgHeroInfo> infos = dbService.getLeaveMsgHeroInfo(id,
                offlineTime);
        if (infos != null){
            sender.sendMessage(theyLeftMsgWhenYouOffline(infos));
        }
    }

    private static class ChatUpdater implements Runnable{
        private final DBService dbService;
        private final RingBufferWrapper<ChatEvent> ringBuffer;

        private ChatUpdater(DBService dbService,
                RingBufferWrapper<ChatEvent> ringBuffer){
            this.dbService = dbService;
            this.ringBuffer = ringBuffer;
        }

        @Override
        public void run(){
            try{
                if (ringBuffer.hasEventsToHandle()){
                    dbService.processChatEvents(ringBuffer);
                }
            } catch (Throwable ex){
                logger.error("ChatModule.ChatUpdater.run出错", ex);
            }
        }
    }

    // -------- 获取 黑名单列表 ---------

    public static class OfflineHeroInfo{
        public static final OfflineHeroInfo EMPTY_OFFLINE_HERO_INFO = new OfflineHeroInfo(
                Empty.BYTE_ARRAY, Empty.BYTE_ARRAY, 0, Empty.BYTE_ARRAY, 0L);

        private static final LongHashSet EMPTY_HASH_SET = new LongHashSet(){

            @Override
            public boolean contains(long id){
                return false;
            }
        };

        public final long id;
        public final LongHashSet blackList;
        public final byte[] mood;
        public final int level;
        public final byte[] name;
        public final SingleRelation singleRelation;
        public final int raceID;

        public OfflineHeroInfo(byte[] relationData, byte[] mood, int easyInfo,
                byte[] name, long combineId){
            super();
            this.id = combineId;
            this.name = name;
            this.level = Hero.decodeEasyInfoGetLevel(easyInfo);
            this.raceID = Hero.decodeEasyInfoGetRace(easyInfo);

            SingleRelation.Builder builder = SingleRelation.newBuilder();
            builder.setId(id).setName(ByteString.copyFrom(name))
                    .setRace(raceID).setLevel(level);
            if (mood != null && mood.length > 0){
                builder.setMood(ByteString.copyFrom(mood));
            }
            if (Hero.decodeEasyInfoGetHasSell(easyInfo)){
                builder.setHasSell(true);
            }
            this.singleRelation = builder.build();

            RelationProto proto;
            try{
                proto = RelationProto.parseFrom(relationData);
            } catch (InvalidProtocolBufferException e){
                throw new RuntimeException(e);
            }

            int blackCount = proto.getBlackIdCount();

            if (blackCount == 0){
                this.blackList = EMPTY_HASH_SET;
            } else{
                LongHashSet rhs = new LongHashSet(blackCount, 0.75f);
                for (int i = blackCount; --i >= 0;){
                    rhs.add(proto.getBlackId(i));
                }
                this.blackList = rhs;
            }
            this.mood = mood == null ? Empty.BYTE_ARRAY : mood;
        }

        public boolean isBlacked(long id){
            return blackList.contains(id);
        }
    }

    public OfflineHeroInfo getOfflineHeroInfo(Long id)
            throws ExecutionException{
        return offlineHeroInfoCache.get(id);
    }

    public void removeOfflineHeroInfoCache(Long id){
        offlineHeroInfoCache.invalidate(id);
    }

    static class BlackListCacheLoader extends
            CacheLoader<Long, OfflineHeroInfo>{
        private final DBService dbService;

        public BlackListCacheLoader(DBService dbService){
            this.dbService = dbService;
        }

        @Override
        public OfflineHeroInfo load(Long key) throws Exception{
            long id = key.longValue();
            OfflineHeroInfo result = dbService.getOfflineHeroInfo(id);
            if (result == null){
                return OfflineHeroInfo.EMPTY_OFFLINE_HERO_INFO;
            }
            return result;
        }
    }

}
