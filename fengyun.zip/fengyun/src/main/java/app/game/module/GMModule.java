package app.game.module;

import static app.game.module.GoodsContainerMessages.*;
import static app.game.module.HeroMiscMessages.changePkAmountMsg;
import static app.game.module.MiscModule.DisconnectReason.GM_MODULE_EXPECTED;
import static app.protobuf.LogContent.LogEnum.OperateType.GM;
import static com.mokylin.sink.util.BufferUtil.*;

import java.util.concurrent.TimeUnit;

import org.jboss.netty.buffer.ChannelBuffer;
import org.jboss.netty.buffer.ChannelBuffers;
import org.joda.time.DateTimeConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.data.ConfigService;
import app.game.data.HeroSimpleData;
import app.game.data.bow.BowData;
import app.game.data.bow.HeroBow;
import app.game.data.goods.Equipment;
import app.game.data.goods.EquipmentData;
import app.game.data.goods.Goods;
import app.game.data.goods.GoodsContainerUnlockData;
import app.game.data.goods.GoodsData;
import app.game.data.mail.Mail;
import app.game.data.pet.HeroTianJie;
import app.game.data.pet.HeroTianZui;
import app.game.data.pet.TianJieData;
import app.game.data.pet.TianZuiData;
import app.game.data.scene.NormalSceneData;
import app.game.data.scene.SceneData;
import app.game.data.scene.SceneDatas;
import app.game.data.scene.StoryDungeonSceneData;
import app.game.data.task.ChapterTask;
import app.game.data.task.HeroTaskList;
import app.game.data.task.TaskCallbackModule;
import app.game.data.weapon7.HeroSuperWeapon;
import app.game.entity.GoodsContainer;
import app.game.entity.Hero;
import app.game.entity.Model.ModelType;
import app.game.entity.RelationList;
import app.game.entity.User;
import app.game.module.ChatModule.ChatEvent;
import app.game.module.MiscModule.DisconnectReason;
import app.game.module.combat.OneOnOneModule;
import app.game.module.guild.Guild;
import app.game.module.guild.GuildMember;
import app.game.module.guild.GuildModule;
import app.game.module.guild.LongCityModule;
import app.game.module.guild.WushuangCityModule;
import app.game.module.pvip.PVipInfo;
import app.game.module.pvip.PlatformVipGetter;
import app.game.module.pvip.PlatformVipModule;
import app.game.module.scene.FireMonkeyModule;
import app.game.module.scene.JijianModule;
import app.game.module.scene.NormalScene;
import app.game.module.scene.StoryDungeonModule;
import app.game.service.DBService;
import app.game.service.IThreadService;
import app.game.service.PhoenixCounter;
import app.game.service.TimeService;
import app.game.service.WorldData;
import app.game.service.WorldService;
import app.game.service.redeploy.IHotRedeployService;
import app.protobuf.GoodsServerContent.Quality;
import app.protobuf.HeroContent.ChatMessage;
import app.protobuf.HeroServerContent.HeroMinorProto;
import app.protobuf.HeroServerContent.HeroServerProto;
import app.protobuf.LogContent.LogEnum.TransportType;
import app.protobuf.SpriteStatContent.StatType;
import app.protobuf.TaskContent.TaskRelatedFunction;
import app.utils.IDUtils;
import app.utils.IndividualServerConfig;
import app.utils.VariableConfig;

import com.google.common.base.Joiner;
import com.google.inject.Inject;
import com.google.protobuf.ByteString;
import com.lmax.disruptor.InsufficientCapacityException;
import com.mokylin.collection.LongArrayList;
import com.mokylin.sink.util.BufferUtil;
import com.mokylin.sink.util.Empty;
import com.mokylin.sink.util.RandomNumber;
import com.mokylin.sink.util.StringEncoder;
import com.mokylin.sink.util.TimeFormatter;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.annotation.SelfThreadOnly;
import com.mokylin.sink.util.concurrent.RingBufferWrapper;
import com.mokylin.sink.util.pack.FileLoader;
import com.mokylin.sink.util.pack.RealTimeFileLoader;

public class GMModule{
    private static final Logger logger = LoggerFactory
            .getLogger(GMModule.class);
    public static final int MODULE_ID = Modules.GM_MODULE_ID;

    /**
     * 发送gm指令
     *
     * 附带个utf, 前后去掉空格. 全部是小写
     */
    public static final int C2S_GM_QUERY = 1;

    /**
     * 显示在gm面板上的话
     *
     * 附带个utf. 需支持html格式符
     */
    static final int S2C_GM_REPLY = 1;

    public static ChannelBuffer gmReply(String msg){
        byte[] msgBytes = StringEncoder.encode(msg);
        ChannelBuffer buffer = BufferUtil.newFixedSizeMessage(MODULE_ID,
                S2C_GM_REPLY, 2 + msgBytes.length);
        BufferUtil.writeUTF(buffer, msgBytes);
        return buffer;
    }

    // ------

    private static final ChannelBuffer NOT_DEBUG_MODE = gmReply("未开启");
    private static final ChannelBuffer CMD_UNKNOWN_MSG = gmReply("未知指令. 输入help查看帮助");
    private static final ChannelBuffer CMD_ERROR_MSG = gmReply("指令格式错误. 输入help查看帮助");

    private static final ChannelBuffer HELP_MSG = gmReply(Joiner.on("<br>")
            .join(new String[]{"stat help获取属性相关gm指令帮助",
                    "goods help获取物品相关gm指令帮助", "money help获取钱相关gm指令帮助",
                    "scene help获取场景相关gm指令帮助", "show help获取换装相关gm指令帮助",
                    "depot help获取背包仓库相关gm指令帮助", "chat help获取聊天相关gm指令帮助",
                    "task help获取任务相关gm指令帮助", "reset help获取重置英雄状态相关gm指令帮助",
                    "guild help获取帮派相关gm指令帮助", "mail help获取邮件相关gm指令帮助",
                    "relation help获取关系列表相关gm指令帮助", "world help获取world相关gm指令帮助",
                    "pk help获取pk相关gm指令帮助", "mount help获取坐骑相关gm指令帮助",
                    "boss help获取世界Boss相关gm指令帮助", "welfare help获取签到相关gm指令帮助",
                    "hd help获取活动相关gm指令帮助", "bow help获取活动相关gm指令帮助"}));

    /**
     * GM修改物品，包括后台接口修改
     * varint32 source 0-装备 1-背包 2-仓库 3-知天命
     * varint32 pos 位置
     * if (byteArray.available){
     *     // 将该位置上放入该物品，如果原来有物品，就替换掉
     *     varint32 物品静态数据长度
     *     bytes 物品静态数据
     *     varint32 物品动态数据长度
     *     bytes 物品动态数据
     * }else{
     *     // 删除掉那个位置的物品
     * }
     */
    static final int S2C_GM_REPLACE_GOODS = 2;

    public static ChannelBuffer gmReplaceGoods(int source, int pos){
        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID,
                S2C_GM_REPLACE_GOODS, computeVarInt32Size(source)
                        + computeVarInt32Size(pos));
        writeVarInt32(buffer, source);
        writeVarInt32(buffer, pos);

        return buffer;
    }

    public static ChannelBuffer gmReplaceGoods(int source, int pos,
            byte[] staticData, byte[] dynamicData){
        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID,
                S2C_GM_REPLACE_GOODS, computeVarInt32Size(source)
                        + computeVarInt32Size(pos)
                        + computeVarInt32Size(staticData.length)
                        + computeVarInt32Size(dynamicData.length)
                        + staticData.length + dynamicData.length);

        writeVarInt32(buffer, source);
        writeVarInt32(buffer, pos);
        writeVarInt32(buffer, staticData.length);
        buffer.writeBytes(staticData);
        writeVarInt32(buffer, dynamicData.length);
        buffer.writeBytes(dynamicData);

        return buffer;
    }

    // ------

    private final TimeService timeService;

    private final IThreadService threadService;

    private final WorldService worldService;

    private final DBService dbService;

    private final TaskCallbackModule taskCallbackModule;

    private final GuildModule guildModule;

    private final MailModule mailModule;

    private final RelationModule relationModule;

    private final IndividualServerConfig individualServerConfig;

    private final WorldData worldData;

    private final VipModule vipModule;

    private final ConfigService configService;

    private final SceneDatas sceneDatas;

    private final StoryDungeonModule storyDungeonModule;

    private final MountModule mountModule;

    private final WelfareModule welfareModule;

    private final FireMonkeyModule fireMonkeyModule;

    private final BowModule bowModule;

    private final ExamModule examModule;

    private final JijianModule swordSacrificeModule;

    private final SuperWeaponModule superWeaponModule;

    private final PhoenixCounter phoenixCounter;

    private final OneOnOneModule oneOnOneModule;

    private final LongCityModule longCityModule;

    private final WushuangCityModule wsCityModule;

    private final PlatformVipModule platformVipModule;

    private final IHotRedeployService hotRedeployService;

    private final FileLoader fileLoader;

    private final PetModule petModule;

    private final boolean isDebug;

    @Inject
    GMModule(TimeService timeService, IThreadService threadService,
            IndividualServerConfig config, WorldService worldService,
            DBService dbService, TaskCallbackModule taskCallbackModule,
            GuildModule guildModule, MailModule mailModule,
            RelationModule relationModule, WorldData worldData,
            VipModule vipModule, ConfigService configService,
            SceneDatas sceneDatas, StoryDungeonModule storyDungeonModule,
            MountModule mountModule, WelfareModule welfareModule,
            FireMonkeyModule fireMonkeyModule, BowModule bowModule,
            ExamModule examModule, JijianModule swordSacrificeModule,
            SuperWeaponModule superWeaponModule, PhoenixCounter phoenixCounter,
            OneOnOneModule oneOnOneModule, LongCityModule longCityModule,
            WushuangCityModule wsCityModule,
            PlatformVipModule platformVipModule,
            IHotRedeployService hotRedeployService, FileLoader fileLoader,
            PetModule petModule){
        this.timeService = timeService;
        this.threadService = threadService;
        this.worldService = worldService;
        this.dbService = dbService;
        this.taskCallbackModule = taskCallbackModule;
        this.guildModule = guildModule;
        this.mailModule = mailModule;
        this.relationModule = relationModule;
        this.worldData = worldData;
        this.individualServerConfig = config;
        this.vipModule = vipModule;
        this.configService = configService;

        this.sceneDatas = sceneDatas;
        this.storyDungeonModule = storyDungeonModule;
        this.mountModule = mountModule;
        this.welfareModule = welfareModule;
        this.fireMonkeyModule = fireMonkeyModule;
        this.bowModule = bowModule;
        this.examModule = examModule;
        this.swordSacrificeModule = swordSacrificeModule;
        this.superWeaponModule = superWeaponModule;
        this.phoenixCounter = phoenixCounter;
        this.oneOnOneModule = oneOnOneModule;
        this.longCityModule = longCityModule;
        this.wsCityModule = wsCityModule;
        this.platformVipModule = platformVipModule;
        this.hotRedeployService = hotRedeployService;
        this.fileLoader = fileLoader;
        this.petModule = petModule;

        this.isDebug = config.isDebug();
    }

    void onMessage(int sequenceID, ChannelBuffer buffer, HeroController hc){
        if (!isDebug){
            return;
        }

        switch (sequenceID){
            case C2S_GM_QUERY:{
                processGmQuery(buffer, hc);
                return;
            }

            default:{
                logger.warn("收到未知的GM模块消息: {}", sequenceID);
                return;
            }
        }
    }

    private void processGmQuery(ChannelBuffer buffer, HeroController hc){
        String cmd = BufferUtil.readUTF(buffer);
        int firstSpace = cmd.indexOf(" ");
        final String firstCmd, lastCmd;
        if (firstSpace < 0){
            firstCmd = cmd;
            lastCmd = "";
        } else{
            firstCmd = cmd.substring(0, firstSpace);
            lastCmd = cmd.substring(firstSpace + 1);
        }

        try{
            switch (firstCmd){
                case "help":{
                    hc.sendMessage(HELP_MSG);
                    return;
                }

                case "reload":{
                    if (fileLoader instanceof RealTimeFileLoader){
                        hotRedeployService.onConfigUpdated(fileLoader);
                    } else{
                        hc.sendMessage(gmReply("只有使用config文件夹启动的才能用命令热更新"));
                    }
                    return;
                }
                case "time":{
                    hc.sendMessage(gmReply(TimeFormatter.SECOND2
                            .print(timeService.getCurrentTime())));
                    return;
                }
                case "stat":{
                    processStatQuery(lastCmd, hc);
                    return;
                }

                case "goods":{
                    processGoodsQuery(lastCmd, hc);
                    return;
                }

                case "money":{
                    processMoneyQuery(lastCmd, hc);
                    return;
                }

                case "scene":{
                    processSceneQuery(lastCmd, hc);
                    return;
                }

                case "show":{
                    processEquipmentShowQuery(lastCmd, hc);
                    return;
                }

                case "depot":{
                    processDepotQuery(lastCmd, hc);
                    return;
                }

                case "chat":{
                    processChatQuery(lastCmd, hc);
                    return;
                }
                case "task":{
                    processTaskQuery(lastCmd, hc);
                    return;
                }
                case "reset":{
                    processResetQuery(lastCmd, hc);
                    return;
                }
                case "set":{
                    processSetQuery(lastCmd, hc);
                    return;
                }
                case "guild":{
                    processGuildQuery(lastCmd, hc);
                    return;
                }
                case "mail":{
                    processMailQuery(lastCmd, hc);
                    return;
                }

                case "relation":{
                    processRelationQuery(lastCmd, hc);
                    return;
                }
                case "world":{
                    processWorldQuery(lastCmd, hc);
                    return;
                }
                case "pk":{
                    processPkQuery(lastCmd, hc);
                    return;
                }
                case "mount":{
                    processMountQuery(lastCmd, hc);
                    return;
                }
                case "welfare":{
                    processWelfareQuery(lastCmd, hc);
                    return;
                }

                case "hd":{
                    processHdQuery(lastCmd, hc);
                    return;
                }
                case "bow":{
                    processBowQuery(lastCmd, hc);
                    return;
                }
                case "weapon":{
                    processWeapon7Query(lastCmd, hc);
                    return;
                }
                case "version":{
                    hc.sendMessage(gmReply(VariableConfig.VERSION));
                    return;
                }
                case "kick":{
                    ConnectedUser user = worldService.getUser(hc.getID());
                    if (user != null){
                        user.getUser().setBanned(true);
                    }

                    // 踢下线
                    user.disconnect(DisconnectReason.BANNED);
                    return;
                }
                case "upgrade":{
                    processUpgradeQuery(lastCmd, hc);
                    return;
                }
                default:{
                    hc.sendMessage(CMD_UNKNOWN_MSG);
                    return;
                }
            }
        } catch (Throwable ex){
            logger.error("GM模块报错({}): {}", cmd, ex.getMessage());
            hc.sendMessage(CMD_ERROR_MSG);
        }
    }

    private void processUpgradeQuery(String lastCmd, HeroController hc){
        String[] arg = lastCmd.split(" ");
        switch (arg[0]){
            case "mount":{
                Hero hero = hc.getHero();
                if (hero.getMount() == null){
                    mountModule.giveFirstMount(hc.getHero(), hc.getSender());
                    return;
                }

                if (hero.getMount().getBestMount().getNextLevelData() == null){
                    hc.sendMessage(gmReply("坐骑已经满级了"));
                    return;
                }

                mountModule.doMountUpgraded(hc, hero.getMount(), hero
                        .getMount().getBestMount().getNextLevelData(),
                        timeService.getCurrentTime(), GM, null);
                return;
            }
            case "bow":{
                HeroBow bow = hc.getHero().getBow();
                if (bow == null){
                    bowModule.giveBow(hc.getHeroFightModule(), hc.getSender());

                    // 弓箭功能开放
                    if (hc.getHero().tryOpenTaskFunction(
                            TaskRelatedFunction.FUNC_BOW)){
                        hc.sendMessage(configService.getTasks()
                                .getChapterTaskDatas()
                                .getFuncMsg(TaskRelatedFunction.FUNC_BOW));
                    }
                    return;
                }

                BowData nextLevel = bow.getBowData().getNextLevel();

                bowModule.doBowUpgrade(hc, bow, nextLevel,
                        timeService.getCurrentTime(), GM, null);
                return;
            }
            case "tianjie":{
                HeroTianJie tianjie = hc.getHero().getTianJie();
                if (tianjie == null){
                    petModule.giveTianJie(hc.getHeroFightModule());

                    // 天劫功能开放
                    if (hc.getHero().tryOpenTaskFunction(
                            TaskRelatedFunction.FUNC_TIAN_JIE)){
                        hc.sendMessage(configService.getTasks()
                                .getChapterTaskDatas()
                                .getFuncMsg(TaskRelatedFunction.FUNC_TIAN_JIE));
                    }
                    return;
                }

                TianJieData nextLevel = tianjie.getData().getNextLevel();

                petModule.doTianJieUpgraded(hc, tianjie, nextLevel,
                        timeService.getCurrentTime(), GM, null);
                return;
            }
            case "tianzui":{
                HeroTianZui tianzui = hc.getHero().getTianZui();
                if (tianzui == null){
                    petModule.giveTianZui(hc);

                    // 天罪功能开放
                    if (hc.getHero().tryOpenTaskFunction(
                            TaskRelatedFunction.FUNC_TIAN_ZUI)){
                        hc.sendMessage(configService.getTasks()
                                .getChapterTaskDatas()
                                .getFuncMsg(TaskRelatedFunction.FUNC_TIAN_ZUI));
                    }
                    return;
                }

                TianZuiData nextLevel = tianzui.getData().getNextLevel();

                petModule.doTianZuiUpgraded(hc, tianzui, nextLevel,
                        timeService.getCurrentTime(), GM, null);
                return;
            }
            default:{
                hc.sendMessage(HELP_MOUNT_MSG);
                return;
            }
        }
    }

    private static final ChannelBuffer HELP_WEAPON7_MSG = gmReply(Joiner.on(
            "<br>").join(new String[]{"weapon next_level 数字：第几把神兵升一阶"}));

    private void processWeapon7Query(String lastCmd, HeroController hc){
        String[] arg = lastCmd.split(" ");
        switch (arg[0]){
            case "next_level":{
                int pos = Integer.parseInt(arg[1]);
                HeroSuperWeapon[] weapons = hc.getHero().getSuperWeapons();

                if (pos < 0 || pos >= weapons.length){
                    hc.sendMessage(gmReply("神兵位置不对"));
                    return;
                }

                if (weapons[pos] == null){
                    superWeaponModule.giveWeapon(hc, configService
                            .getSuperWeapons().get(pos + 1), timeService
                            .getCurrentTime(), GM);
                    return;
                }

                HeroSuperWeapon weapon = weapons[pos];
                if (weapon.getNextLevel() == null){
                    return;
                }

                superWeaponModule.doWeaponUpgrade(hc, weapon,
                        weapon.getNextLevel(), timeService.getCurrentTime());
                return;
            }
            case "full_level":{
                int pos = Integer.parseInt(arg[1]);
                HeroSuperWeapon[] weapons = hc.getHero().getSuperWeapons();

                if (pos < 0 || pos >= weapons.length){
                    hc.sendMessage(gmReply("神兵位置不对"));
                    return;
                }

                if (weapons[pos] == null){
                    superWeaponModule.giveWeapon(hc, configService
                            .getSuperWeapons().get(pos + 1), timeService
                            .getCurrentTime(), GM);
                    return;
                }

                HeroSuperWeapon weapon = weapons[pos];
                while (weapon.getNextLevel() != null){
                    superWeaponModule
                            .doWeaponUpgrade(hc, weapon, weapon.getNextLevel(),
                                    timeService.getCurrentTime());
                }
            }
            default:{
                hc.sendMessage(HELP_WEAPON7_MSG);
                return;
            }
        }
    }

    private static final ChannelBuffer HELP_BOW_MSG = gmReply(Joiner.on("<br>")
            .join(new String[]{"bow give 给第一阶弓箭", "bow upgrade 升级一阶弓箭"}));

    private void processBowQuery(String lastCmd, HeroController hc){
        String[] arg = lastCmd.split(" ");
        switch (arg[0]){
            case "give":{
                bowModule.giveBow(hc.getHeroFightModule(), hc.getSender());

                // 弓箭功能开放
                if (hc.getHero().tryOpenTaskFunction(
                        TaskRelatedFunction.FUNC_BOW)){
                    hc.sendMessage(configService.getTasks()
                            .getChapterTaskDatas()
                            .getFuncMsg(TaskRelatedFunction.FUNC_BOW));
                }
                return;
            }
            case "upgrade":{
                HeroBow bow = hc.getHero().getBow();
                if (bow == null){
                    bowModule.giveBow(hc.getHeroFightModule(), hc.getSender());

                    // 弓箭功能开放
                    if (hc.getHero().tryOpenTaskFunction(
                            TaskRelatedFunction.FUNC_BOW)){
                        hc.sendMessage(configService.getTasks()
                                .getChapterTaskDatas()
                                .getFuncMsg(TaskRelatedFunction.FUNC_BOW));
                    }
                    return;
                }

                BowData nextLevel = bow.getBowData().getNextLevel();

                bowModule.doBowUpgrade(hc, bow, nextLevel,
                        timeService.getCurrentTime(), GM, null);
                return;
            }
            default:{
                hc.sendMessage(HELP_BOW_MSG);
                return;
            }
        }
    }

    // --------- 活动 hd ----------

    private static final ChannelBuffer HELP_HD_MSG = gmReply(Joiner
            .on("<br>")
            .join(new String[]{"hd kongci xxx 将今日已通关关数设为xxx. 设置成功后会断线, 为了让客户端重新连接以同步数据"}));

    private void processHdQuery(String lastCmd, HeroController hc){
        String[] arg = lastCmd.split(" ");
        switch (arg[0]){
            case "help":{
                hc.sendMessage(HELP_HD_MSG);
                return;
            }

            case "kongci":{
                if (!hc.getHeroFightModule().getParentSceneData()
                        .isNormalScene()){
                    hc.sendMessage(gmReply("必须在普通场景中"));
                    return;
                }

                int batch = Integer.parseInt(arg[1]);
                if (batch <= hc.getHero().getDefenceTodayFinishedBatch()){
                    hc.sendMessage(gmReply("今日已经通过了"
                            + hc.getHero().getDefenceTodayFinishedBatch()
                            + "关, 只能往后面设"));
                    return;
                }

                if (batch > sceneDatas.getDefence().getTotalBatch()){
                    hc.sendMessage(gmReply("总共只有"
                            + sceneDatas.getDefence().getTotalBatch() + "关"));
                    return;
                }

                hc.getHero().setDefenceTodayFinishedBatch(batch);
                if (batch > hc.getHero().getDefenceHistoryMaxBatch()){
                    hc.getHero().setDefenceHistoryMaxBatch(batch);
                }
                hc.disconnect(GM_MODULE_EXPECTED);

                return;
            }
        }
    }

    // --------- welfare ----------

    private static final ChannelBuffer HELP_WELFARE_MSG = gmReply(Joiner.on(
            "<br>").join(
            new String[]{"welfare sign 数字 ：签到本月XX号",
                    "welfare sign_all：签到本月所有天数都签到一次",
                    "reset monthly：可以重置每月签到次数"}));

    private void processWelfareQuery(String lastCmd, HeroController hc){
        String[] arg = lastCmd.split(" ");
        switch (arg[0]){
            case "sign":{
                welfareModule.sign(hc, hc.getHero().getWelfare(),
                        Integer.parseInt(arg[1]));
                return;
            }
            case "sign_all":{
                for (int i = 1; i < 32; i++){
                    welfareModule.sign(hc, hc.getHero().getWelfare(), i);
                }
                return;
            }
            default:{
                hc.sendMessage(HELP_WELFARE_MSG);
                return;
            }
        }
    }

    // --------- mount ----------

    private static final ChannelBuffer HELP_MOUNT_MSG = gmReply(Joiner.on(
            "<br>").join(
            new String[]{"mount give ：给个1级坐骑", "mount upgrade ：无消耗点一次进阶坐骑",
                    "mount next_level ：直接升到下一阶"}));

    private void processMountQuery(String lastCmd, HeroController hc){
        String[] arg = lastCmd.split(" ");
        switch (arg[0]){
            case "give":{
                mountModule.giveFirstMount(hc.getHero(), hc.getSender());
                return;
            }
            case "upgrade":{
                Hero hero = hc.getHero();
                if (hero.getMount() == null){
                    mountModule.giveFirstMount(hc.getHero(), hc.getSender());
                    return;
                }

                if (hero.getMount().getBestMount().getNextLevelData() == null){
                    hc.sendMessage(gmReply("坐骑已经满级了"));
                    return;
                }

                mountModule.tryUpgradeMount(hc, hero.getMount(), hero
                        .getMount().getBestMount().getUpgradeData(), hero
                        .getMount().getBestMount().getNextLevelData(),
                        timeService.getCurrentTime(), GM, null);
                return;
            }
            case "next_level":{
                Hero hero = hc.getHero();
                if (hero.getMount() == null){
                    mountModule.giveFirstMount(hc.getHero(), hc.getSender());
                    return;
                }

                if (hero.getMount().getBestMount().getNextLevelData() == null){
                    hc.sendMessage(gmReply("坐骑已经满级了"));
                    return;
                }

                mountModule.doMountUpgraded(hc, hero.getMount(), hero
                        .getMount().getBestMount().getNextLevelData(),
                        timeService.getCurrentTime(), GM, null);
                return;
            }
            default:{
                hc.sendMessage(HELP_MOUNT_MSG);
                return;
            }
        }
    }

    // --------- pk ---------

    private static final ChannelBuffer HELP_PK_MSG = gmReply(Joiner.on("<br>")
            .join(new String[]{"pk add 数字：增加PK值，负数表示减少PK值"}));

    private void processPkQuery(String lastCmd, HeroController hc){
        String[] arg = lastCmd.split(" ");
        switch (arg[0]){
            case "help":{
                hc.sendMessage(HELP_PK_MSG);
                return;
            }

            case "add":{
                int amount = Integer.parseInt(arg[1]);

                Hero hero = hc.getHero();
                if (amount > 0){
                    boolean zeroPkAmount = hero.getPkAmount() <= 0;

                    int newAmount = hero.addPkAmount(amount);
                    if (zeroPkAmount){
                        hero.setNextReducePkAmountTime(timeService
                                .getCurrentTime()
                                + VariableConfig.PK_AMOUNT_REDUCE_INTERVAL);
                    }

                    hc.heroFightModule
                            .selfThreadBroadcastAroundAndSelf(changePkAmountMsg(
                                    hero.getID(), newAmount,
                                    hero.getNextReducePkAmountTime()));
                } else if (amount < 0){
                    int newPkAmount = hero.reducePkAmount(-amount);

                    if (newPkAmount <= 0){
                        hero.setNextReducePkAmountTime(0);
                    }

                    // 发消息
                    hc.heroFightModule
                            .selfThreadBroadcastAroundAndSelf(changePkAmountMsg(
                                    hero.getID(), newPkAmount,
                                    hero.getNextReducePkAmountTime()));
                }
                return;
            }

            default:{
                hc.sendMessage(HELP_RELATION_MSG);
                return;
            }
        }
    }

    // --------- world ---------

    private static final ChannelBuffer HELP_WORLD_MSG = gmReply(Joiner
            .on("<br>")
            .join(new String[]{"world night 数字1 数字2：多少秒之后进入夜晚挂机保护，多少秒退出夜晚挂机保护，2个数字都是0表示还原夜晚挂机保护"}));

    private void processWorldQuery(String lastCmd, HeroController hc){
        String[] arg = lastCmd.split(" ");
        switch (arg[0]){
            case "help":{
                hc.sendMessage(HELP_WORLD_MSG);
                return;
            }

            case "night":{
                processChangeNightProtectTime(arg, hc);
                return;
            }
            default:{
                hc.sendMessage(HELP_RELATION_MSG);
                return;
            }
        }
    }

    // --------- relation --------

    private void processChangeNightProtectTime(String[] arg, HeroController hc){
        int startTime = Integer.parseInt(arg[1]);
        int endTime = Integer.parseInt(arg[2]);
        if (startTime == 0 && endTime == 0){
            worldData.startNightProtectTime = 0;
            worldData.endNightProtectTime = 0;
            return;
        }

        if (startTime >= endTime){
            endTime = startTime + 60;
        }

        final long ctime = timeService.getCurrentTime();
        worldData.startNightProtectTime = ctime + startTime * 1000;
        worldData.endNightProtectTime = ctime + endTime * 1000;

        threadService.getScheduledExecutorService().schedule(new Runnable(){
            @Override
            public void run(){
                for (ConnectedUser user : worldService.all()){
                    user.getHeroController().heroFightModule.tryAutoIntoNightProtected(ctime);
                }
            }
        }, startTime * 1000, TimeUnit.MILLISECONDS);
    }

    private static final ChannelBuffer HELP_RELATION_MSG = gmReply(Joiner.on(
            "<br>").join(
            new String[]{"relation add friend 数字: 给我新增x个好友",
                    "relation add enemy 数字: 给我新增x个仇人",
                    "relation add black 数字: 给我新增x个屏蔽",
                    "relation record 数字: 把自己所有的仇人战绩改为xx, 为了和客户端同步, 输完后会断线"}));

    private void processRelationQuery(String lastCmd, HeroController hc){
        String[] arg = lastCmd.split(" ");
        switch (arg[0]){
            case "help":{
                hc.sendMessage(HELP_RELATION_MSG);
                return;
            }

            case "add":{
                processRelationAdd(arg, hc);
                return;
            }

            case "record":{
                int record = Integer.parseInt(arg[1]);
                hc.getHero().getRelationList().gmSetEnemyRecord(record);
                hc.disconnect(GM_MODULE_EXPECTED);
                return;
            }

            default:{
                hc.sendMessage(HELP_RELATION_MSG);
                return;
            }
        }
    }

    private void processRelationAdd(String[] args, final HeroController hc){
        RelationList relationList = hc.getHero().getRelationList();

        if (args.length <= 2){
            hc.sendMessage(gmReply("数字必填"));
            return;
        }

        int amount = Integer.parseInt(args[2]);
        if (amount <= 0 || amount > 100){
            hc.sendMessage(gmReply("数字必须1-100"));
            return;
        }

        switch (args[1]){
            case "friend":{
                // 添加好友
                for (int i = Math.min(amount,
                        relationList.gmGetFriendEmptyCount()); --i >= 0;){
                    long id = createRandomHero().getID();
                    ChannelBuffer buffer = ChannelBuffers.dynamicBuffer();
                    BufferUtil.writeVarInt64(buffer, id);
                    relationModule.gmAddFriend(buffer, hc);
                }
                return;
            }

            case "enemy":{
                // 添加仇人
                for (int i = Math.min(amount,
                        relationList.gmGetEnemyEmptyCount()); --i >= 0;){
                    long id = createRandomHero().getID();
                    ChannelBuffer buffer = ChannelBuffers.dynamicBuffer();
                    BufferUtil.writeVarInt64(buffer, id);
                    relationModule.gmAddEnemy(buffer, hc);
                }
                return;
            }

            case "black":{
                // 添加屏蔽
                for (int i = Math.min(amount,
                        relationList.gmGetBlackEmptyCount()); --i >= 0;){
                    long id = createRandomHero().getID();
                    ChannelBuffer buffer = ChannelBuffers.dynamicBuffer();
                    BufferUtil.writeVarInt64(buffer, id);
                    relationModule.gmAddBlack(buffer, hc);
                }
                return;
            }

            default:{
                hc.sendMessage(gmReply("未知的类型 " + args[1]));
            }
        }
    }

    private Hero createRandomHero(){
        User user = createRandomUser();

        for (;;){
            Object obj = dbService.userCreateHero(user,
                    StringEncoder.encode(getRandomHeroname()),
                    RandomNumber.getRate(4) + 1);
            if (obj instanceof Hero){
                return ((Hero) obj);
            }
        }

    }

    private User createRandomUser(){
        for (;;){
            Object obj = dbService.createUser(
                    StringEncoder.encode(getRandomUsername()),
                    individualServerConfig.getDefaultServerID(),
                    individualServerConfig.getDefaultOperatorID());
            if (obj instanceof User){
                return (User) obj;
            }
        }
    }

    private static String getRandomHeroname(){
        int len = DBService.HERO_NAME_MIN_LENGTH
                + RandomNumber.getRate(DBService.HERO_NAME_MAX_LENGTH
                        - DBService.HERO_NAME_MIN_LENGTH);

        return Utils.getRandomString(len);
    }

    private static String getRandomUsername(){
        int len = DBService.USER_NAME_MIN_LENGTH
                + RandomNumber.getRate(DBService.USER_NAME_MAX_LENGTH
                        - DBService.USER_NAME_MIN_LENGTH);

        return Utils.getRandomString(len);
    }

    // --------- mail -----------
    private static final ChannelBuffer HELP_MAIL_MSG = gmReply(Joiner
            .on("<br>")
            .join(new String[]{"mail create 给自己发一个邮件，邮件包含100银两，100元宝，英雄背包第一格上的物品"}));

    private void processMailQuery(String lastCmd, HeroController hc){
        String[] arg = lastCmd.split(" ");
        switch (arg[0]){
            case "help":{
                hc.sendMessage(HELP_MAIL_MSG);
                return;
            }

            case "create":{
                processSendMail(arg, hc);
                return;
            }

            case "all":{
                processSendGlobalMail(arg, hc);
                return;
            }

            default:{
                hc.sendMessage(HELP_MAIL_MSG);
                return;
            }
        }
    }

    private void processSendMail(String[] arg, HeroController hc){

        Goods[] array = Goods.EMPTY_GOODS_ARRAY;
        Goods g = hc.getDepot().get(0);
        if (g != null){
            array = new Goods[]{g};
        }

        Mail mail = Mail.newMail(hc.getID(), timeService.getCurrentTime(),
                StringEncoder.encode("测试邮件"), 100, 100, 100, array);

        mailModule.addMailEvent(mail);
    }

    private void processSendGlobalMail(String[] arg, HeroController hc){

        Goods[] array = Goods.EMPTY_GOODS_ARRAY;
        Goods g = hc.getDepot().get(0);
        if (g != null){
            array = new Goods[]{g};
        }

        Mail mail = Mail.newMail(
                IDUtils.getCombinedServerAndOperatorID(hc.getID()),
                timeService.getCurrentTime(), StringEncoder.encode("测试邮件"),
                100, 100, 100, array);

        mailModule.addMailEvent(mail);
    }

    // --------- guild -----------
    private static final ChannelBuffer HELP_GUILD_MSG = gmReply(Joiner.on(
            "<br>").join(
            new String[]{"guild new 数字: 随机创建XX个帮派",
                    "guild add 数字: 随机让xx个玩家加入自己帮派",
                    "guild goods 数字: 将所有的帮贡物品数量设为xx, 显示上未必会立即更新, 可刷新看到",
                    "guild money 数字: 将帮贡银两设为xx, 显示上未必会立即更新, 可刷新看到"}));

    private void processGuildQuery(String lastCmd, HeroController hc){
        String[] arg = lastCmd.split(" ");
        switch (arg[0]){
            case "help":{
                hc.sendMessage(HELP_GUILD_MSG);
                return;
            }

            case "goods":{
                processGuildSetContributionGoods(hc, Integer.parseInt(arg[1]));
                return;
            }

            case "money":{
                processGuildSetContributionMoney(hc, Integer.parseInt(arg[1]));
                return;
            }

            case "add":{
                processGuildAdd(hc, Integer.parseInt(arg[1]));
                return;
            }
            case "new":{
                processGuildNew(hc, Integer.parseInt(arg[1]));
                return;
            }

            default:{
                hc.sendMessage(HELP_GUILD_MSG);
                return;
            }
        }
    }

    private void processGuildNew(HeroController hc, int count){
        if (count <= 0){
            hc.sendMessage(gmReply("数字必须>0"));
            return;
        }

        for (int i = 0; i < count; i++){
            String actualGuildName = "测试帮派_" + i;
            String actualFlagName = "测试帮旗_" + i;

            Hero h = createRandomHero();
            Guild g = guildModule.gmCreateGuild(hc, h,
                    StringEncoder.encode(actualGuildName),
                    StringEncoder.encode(actualFlagName));

            int randomCount = RandomNumber.getRate(20);
            for (int n = 0; n < randomCount; n++){
                Hero hero = createRandomHero();
                GuildMember gm = guildModule.gmAddHeroToGuild(g, hero, null);
                gm.setBowLevel(RandomNumber.getRate(5));
                gm.setFightAmount(RandomNumber.getRate(20000) + 1);
                gm.setLevel(RandomNumber.getRate(80) + 1);
                gm.setMountLevel(RandomNumber.getRate(5));
                gm.setTianJieLevel(RandomNumber.getRate(5));
                gm.setTianZuiLevel(RandomNumber.getRate(5));
            }
        }
    }

    private void processGuildSetContributionMoney(HeroController hc, int count){
        if (count <= 0){
            hc.sendMessage(gmReply("数字必须>0"));
            return;
        }

        Guild guild = hc.getGuildMember().getGuild();
        if (guild == null){
            hc.sendMessage(gmReply("你没有帮派"));
            return;
        }

        if (count > VariableConfig.GUILD_GIFT_MONEY_UPPER_LIMIT){
            hc.sendMessage(gmReply("数字不能>"
                    + VariableConfig.GUILD_GIFT_MONEY_UPPER_LIMIT));
            return;
        }

        guild.gmSetContributionMoney(count);
    }

    private void processGuildSetContributionGoods(HeroController hc, int count){
        if (count <= 0){
            hc.sendMessage(gmReply("数字必须>0"));
            return;
        }

        Guild guild = hc.getGuildMember().getGuild();
        if (guild == null){
            hc.sendMessage(gmReply("你没有帮派"));
            return;
        }

        if (count > VariableConfig.GUILD_GIFT_GOODS_UPPER_LIMIT){
            hc.sendMessage(gmReply("数字不能>"
                    + VariableConfig.GUILD_GIFT_GOODS_UPPER_LIMIT));
            return;
        }

        guild.gmSetContributionGoods(count);
    }

    private void processGuildAdd(HeroController hc, int count){
        if (count <= 0){
            hc.sendMessage(gmReply("数字必须>0"));
            return;
        }
        Guild guild = hc.getGuildMember().getGuild();
        if (guild == null){
            hc.sendMessage(gmReply("你没有帮派"));
            return;
        }

        int toAdd = Math.min(count, guild.gmGetVacancy());
        for (int i = 0; i < toAdd; i++){
            Hero h = createRandomHero();
            guildModule.gmAddHeroToGuild(guild, h, null);
        }
    }

    // --------- set ---------
    private static final ChannelBuffer HELP_SET_MSG = gmReply(Joiner.on("<br>")
            .join(new String[]{"set long", "set ws"}));

    private void processSetQuery(String lastCmd, HeroController hc){
        String[] arg = lastCmd.split(" ");

        switch (arg[0]){
            case "long":{
                Guild guild = hc.getGuildMember().getGuild();
                if (guild == null || guild.getLeader() != hc.getGuildMember()){
                    return;
                }

                longCityModule.gmSetMaster(guild);
                return;
            }
            case "ws":{
                Guild guild = hc.getGuildMember().getGuild();
                if (guild == null || guild.getLeader() != hc.getGuildMember()){
                    return;
                }

                wsCityModule.gmSetMaster(guild);
                return;
            }
            case "pvip":{
                int level = Math.max(Integer.parseInt(arg[1]), 1);
                int chargeType = Math.min(
                        Math.max(Integer.parseInt(arg[2]), 1), 3);

                for (PlatformVipGetter getter : platformVipModule.gmGetAll()){
                    if (hc.getHero().getOperatorId() == getter.getOperatorID()){

                        PVipInfo vip = new PVipInfo(getter.getVipType(), level,
                                chargeType);
                        getter.gmPutVipInfo(hc.getHero().getUserId(), vip);
                    }
                }

                platformVipModule.onSceneLoad(hc.getHeroFightModule());
                return;
            }
            case "gm":{
                hc.setGm(!hc.getHero().isGm);
                return;
            }
            default:{
                hc.sendMessage(HELP_SET_MSG);
                return;
            }
        }
    }

    //---------- reset ------------
    private static final ChannelBuffer HELP_RESET_MSG = gmReply(Joiner.on(
            "<br>").join(
            new String[]{"reset daily：重置英雄每日状态，如日常任务重置为第一环等待",
                    "reset monthly：重置英雄每月状态，如签到数据", "reset exam：重置答题系统",
                    "reset jijian: 重置祭剑系统",
                    "reset hero_jijian：重置英雄祭剑数据，需要重新进入场景生效",
                    "reset boss：重置世界boss，精英怪", "reset phoenix：重置凤血今日产出"}));

    private void processResetQuery(String lastCmd, HeroController hc){
        String[] arg = lastCmd.split(" ");

        switch (arg[0]){
            case "help":{
                hc.sendMessage(HELP_RESET_MSG);
                return;
            }
            case "daily":{
                hc.heroFightModule.resetDailyStaticstics();
                return;
            }
            case "monthly":{
                hc.heroFightModule.resetMonthlyStaticstics();
                return;
            }
            case "exam":{
                long ctime = timeService.getCurrentTime();
                long startTime = ctime - VariableConfig.EXAM_WAIT_TIME + 5000; // 5秒后开启

                examModule.startExam(startTime, ctime);
                return;
            }
            case "hero_jijian":{
                hc.getHero().tryResetJijian(0, 0);
                return;
            }

            case "boss":{
                long ctime = timeService.getCurrentTime();
                for (NormalSceneData scene : sceneDatas
                        .getAllNormalSceneDatas()){
                    for (NormalScene s : scene.getNormalSceneContainer(
                            hc.getServerData()).getNormalScenes()){
                        if (s instanceof NormalScene){
                            s.getFightProcessor().gmRefreshTimeMonster(ctime);
                        }
                    }
                }
                return;
            }
            case "phoenix":{
                phoenixCounter.getTodayOutputPhoenixCount().set(0);
                return;
            }
            case "ooo":{
                oneOnOneModule.gmResetPrize(arg.length > 1);
                return;
            }
            default:{
                hc.sendMessage(CMD_UNKNOWN_MSG);
                return;
            }
        }
    }

    // --------- task --------
    private static final ChannelBuffer HELP_TASK_MSG = gmReply(Joiner
            .on("<br>")
            .join(new String[]{"task wc :完成当前的主线任务",
                    "task wc_1z :完成当前章节的所有主线任务", "task wc_all :完成所有的主线任务",
                    "task accept 品质:接受一个机缘任务，品质 0-白色 1-绿色 2-蓝色 3-紫色 4-橙色"}));

    private void processTaskQuery(String lastCmd, final HeroController hc){
        String[] arg = lastCmd.split(" ");

        HeroTaskList taskList = hc.getHero().getTaskList();

        switch (arg[0]){
            case "help":{
                hc.sendMessage(HELP_TASK_MSG);
                return;
            }
            case "wc":{
                ChapterTask doingTask = taskList.getDoingChapterTask();
                taskCallbackModule.onCompleteChapterTask(hc.getHero(),
                        hc.getSender(), doingTask, hc.getHeroMiscModule());
                return;
            }
            case "wc_1z":{
                ChapterTask doingTask = taskList.getDoingChapterTask();
                if (doingTask == null){
                    return;
                }

                int chapter = doingTask.getChapter();
                for (;;){
                    doingTask = taskList.getDoingChapterTask();
                    if (doingTask == null || doingTask.getChapter() != chapter){
                        return;
                    }

                    taskCallbackModule.onCompleteChapterTask(hc.getHero(),
                            hc.getSender(), doingTask, hc.getHeroMiscModule());
                }
            }
            case "wc_all":{
                for (;;){
                    ChapterTask doingTask = taskList.getDoingChapterTask();
                    if (doingTask == null){
                        return;
                    }
                    taskCallbackModule.onCompleteChapterTask(hc.getHero(),
                            hc.getSender(), doingTask, hc.getHeroMiscModule());
                }
            }
            case "accept":{
                int intQuality = Integer.parseInt(arg[1]);
                Quality quality = Quality.valueOf(intQuality);
                if (quality == null){
                    quality = Quality.WHITE;
                }

                taskCallbackModule.acceptChanceTask(quality, 1, hc.getHero(),
                        hc.getSender(), GM);
                return;
            }
            default:{
                hc.sendMessage(CMD_UNKNOWN_MSG);
                return;
            }
        }
    }

    // --------- chat --------

    private static final ChannelBuffer HELP_CHAT_MSG = gmReply(Joiner
            .on("<br>").join(
                    new String[]{"chat window 数字: 来人哪! 给我发xxx条窗口私聊",
                            "chat private 数字: 来人哪! 给我发xxx条左下角私聊"}));

    private void processChatQuery(String lastCmd, final HeroController hc){
        String[] arg = lastCmd.split(" ");
        switch (arg[0]){
            case "help":{
                hc.sendMessage(HELP_CHAT_MSG);
                return;
            }
            case "gb":{
                worldService.broadcastAllUser(MiscModule
                        .getBroadcastMsg(arg[1]));
                return;
            }

            case "private":
            case "window":{
                int count = Integer.parseInt(arg[1]);
                if (count <= 0 || count > 1000){
                    hc.sendMessage(gmReply("条数必须是1-1000"));
                    return;
                }

                ConnectedUser cu = worldService
                        .gmGetRandomEnteredHero(hc.combinedID);
                if (cu == null){
                    hc.sendMessage(gmReply("当前必须有另一个英雄同时在此服务器上在线"));
                    return;
                }

                final ByteString heroName = cu.getHeroController().getHero()
                        .getNameByteString();
                final long heroid = cu.getCombinedID();
                final int level = cu.getHeroController().getHero().getLevel();
                final int repeatedCount = count;

                final boolean isNormalChat = "private".equals(arg[0]);

                threadService.getDbExecutor().execute(new Runnable(){
                    @Override
                    public void run(){

                        final long ctime = timeService.getCurrentTime();
                        RingBufferWrapper<ChatEvent> ringBuffer = new RingBufferWrapper<ChatModule.ChatEvent>(
                                ChatEvent.FACTORY, 1, true);

                        for (int i = 1; i <= repeatedCount; i++){
                            ChatMessage cm = ChatMessage.newBuilder()
                                    .setHeroId(heroid).setHeroName(heroName)
                                    .setSpeech(String.valueOf(i)).build();
                            byte[] data = cm.toByteArray();

                            hc.sendMessage(isNormalChat ? ChatMessages
                                    .receivedNormalPrivateChat(ctime, cm)
                                    : ChatMessages
                                            .receivedWindowChat(ctime, cm));

                            try{
                                long sequence = ringBuffer.tryNext();
                                try{
                                    ChatEvent event = ringBuffer.get(sequence);
                                    event.senderID = heroid;
                                    event.receiverID = hc.combinedID;

                                    event.time = ctime;
                                    event.chatMessageProto = data;
                                } finally{
                                    ringBuffer.publish(sequence);
                                }

                                dbService.processChatEvents(ringBuffer);

                            } catch (InsufficientCapacityException ex){
                                logger.error("GmModule尝试往ChatEvent的ringBuffer里tryNext的时候没有了...");
                            }
                        }
                    }
                });
                return;
            }
        }
    }

    // ---------  stat -------

    private static final ChannelBuffer HELP_STAT_MSG = gmReply(Joiner
            .on("<br>")
            .join(new String[]{"stat add stamina 数字: 增加xx点体力. 负数表示减",
                    "stat add life 数字: 增加xx点血. 负数表示减",
                    "stat add shield 数字: 增加xx点跳闪值, 负数表示减",
                    "stat add exp 数字: 增加xx点经验. 不能是负数. 数字最大20亿",
                    "stat add maxlife 数字: 增加xx最大血量. 负数表示减. 做了别的操作之后可能会还原",
                    "stat add attack 数字: 增加xx攻击力. 负数表示减. 做了别的操作之后可能会还原",
                    "stat add defence 数字: 增加xx防御力. 负数表示减. 做了别的操作之后可能会还原",
                    "stat add movespeed 数字: 增加xx移动速度, 负数表示减. 做了别的操作之后可能会还原",
                    "stat add zhenqi 数字: 增加xx真气, 负数表示减. 数字最大20亿",
                    "stat add chenmi: 只针对防沉迷系统加10分钟在线时间"}));

    private void processStatQuery(String lastCmd, HeroController hc){
        String[] arg = lastCmd.split(" ");
        switch (arg[0]){
            case "help":{
                hc.sendMessage(HELP_STAT_MSG);
                return;
            }

            case "add":{
                // 增加属性
                processAddStatQuery(arg, hc);
                return;
            }

            default:{
                hc.sendMessage(gmReply("未知的命令: " + arg[0]));
                return;
            }
        }
    }

    private void processAddStatQuery(String[] arg, HeroController hc){
        switch (arg[1]){
            case "chenmi":{
                hc.getHeroFightModule().gmAdd10MinOnlineTime();
                return;
            }

            case "zhenqi":{
                int amount = Integer.parseInt(arg[2]);
                if (amount > 0){
                    hc.getHeroMiscModule().addRealAirAnyway(amount, GM, null);
                } else if (amount < 0){
                    hc.getHeroMiscModule().reduceRealAirAnyway(-amount, GM,
                            null);
                }
                return;
            }

            case "stamina":{
                // 加体力
                int amount = Integer.parseInt(arg[2]);
                hc.heroFightModule.addStaminaAndBroadcast(amount);
                return;
            }

            case "life":{
                int amount = Integer.parseInt(arg[2]);
                hc.heroFightModule.gmAddLife(amount);
                return;
            }

            case "shield":{
                int amount = Integer.parseInt(arg[2]);
                hc.heroFightModule.addJumpShield(amount);
                return;
            }

            case "exp":{
                int amount = Integer.parseInt(arg[2]);
                hc.heroFightModule.addExperience(amount, GM, null);
                return;
            }

            case "maxlife":{
                int amount = Integer.parseInt(arg[2]);
                hc.heroFightModule.gmAddMaxLife(amount);
                return;
            }

            case "attack":{
                int amount = Integer.parseInt(arg[2]);
                hc.heroFightModule.gmAddAttack(amount);
                return;
            }

            case "defence":{
                int amount = Integer.parseInt(arg[2]);
                hc.heroFightModule.gmAddDefence(amount);
                return;
            }

            case "movespeed":{
                int amount = Integer.parseInt(arg[2]);
                hc.heroFightModule.gmAddMoveSpeed(amount);
                return;
            }

            case "rage":{
                hc.heroFightModule.gmAddRage();
                return;
            }
            case "single_stat":{
                int intStatType = Integer.parseInt(arg[2]);
                StatType statType = StatType.valueOf(intStatType);
                if (statType != null){
                    hc.heroFightModule.gmAddSingleStat(statType,
                            Integer.parseInt(arg[3]),
                            timeService.getCurrentTime());
                }
                return;
            }
            case "online_time":{
                long minutes = Integer.parseInt(arg[2]);
                hc.getHero().gmAddTotalOnlineTime(
                        minutes * DateTimeConstants.MILLIS_PER_MINUTE);
                return;
            }
        }
    }

    // --------  equipment -------

    private static final ChannelBuffer HELP_EQUIPMENT_MSG = gmReply(Joiner.on(
            "<br>").join(
            new String[]{"show WEAPON 数值：武器换装，数值表示换装类型，数值支持0-15",
                    "show ARMOR 数值：衣服换装，数值表示换装类型，数值支持0-15",
                    "show MOUNT 数值：坐骑换装，数值表示换装类型，数值支持0-15",
                    "show BOW 数值：弓箭换装，数值表示换装类型，数值支持0-15",
                    "show SUPER_WEAPON 数值：神兵换装，数值表示换装类型，数值支持0-15"}));

    private void processEquipmentShowQuery(String lastCmd, HeroController hc){
        String[] arg = lastCmd.split(" ");
        if ("help".equals(arg[0])){
            hc.sendMessage(HELP_EQUIPMENT_MSG);
            return;

        }

        int res = Integer.parseInt(arg[1]);
        if (res < 0 && res > 15){
            hc.sendMessage(gmReply("换装数值目前支持0-15: " + res));
            return;
        }

        // 先不检查资源是否合法
        for (ModelType resources : ModelType.values()){
            if (resources.name().equalsIgnoreCase(arg[0])){
                hc.hero.replaceEquipmentResources(resources, res);
                hc.heroFightModule.onEquipmentResourcesChanged();
                return;
            }
        }

        hc.sendMessage(gmReply("未知的命令: " + arg[0]));
        return;
    }

    private static final ChannelBuffer HELP_DEPOT_MSG = gmReply(Joiner.on(
            "<br>").join(
            new String[]{"depot depot clear ：清除背包所有物品",
                    "depot storage clear：清除仓库所有物品",
                    "depot depot unlock：解锁背包所有格子",
                    "depot storage unlock：解锁仓库所有格子", "depot openstorage：开放仓库"}));

    private void processDepotQuery(String lastCmd, HeroController hc){
        String[] arg = lastCmd.split(" ");
        if ("help".equals(arg[0])){
            hc.sendMessage(HELP_DEPOT_MSG);
            return;
        }

        GoodsContainer goodsContainer = null;
        switch (arg[0]){
            case "depot":{
                goodsContainer = hc.getDepot();
                break;
            }
            case "storage":{
                goodsContainer = hc.getStorage();

                if (goodsContainer == null){
                    hc.sendMessage(gmReply("你的仓库还未开放"));
                    return;
                }

                if (!hc.storageProcessed){
                    hc.storageProcessed = true;
                    hc.sendMessage(getStorageDataMsg(hc.getStorage()
                            .encode4Client().toByteArray()));
                }
                break;
            }
            case "openstorage":{
                goodsContainer = hc.getStorage();

                if (goodsContainer != null){
                    hc.sendMessage(gmReply("你的仓库已经开放了"));
                    return;
                }

                hc.getHero().openStorage(timeService.getCurrentTime());
                hc.sendMessage(OPEN_STORAGE_MESSAGE);
                return;
            }
            default:{
                hc.sendMessage(gmReply("未知的命令: depot " + arg[1]));
                return;
            }
        }

        switch (arg[1]){
            case "clear":{
                for (int i = 0; i < goodsContainer.size(); i++){
                    if (goodsContainer.remove(i) != null){
                        hc.sendMessage(GoodsContainerMessages.removeGoodsMsg(
                                goodsContainer.getType(), i));
                    }
                }
                return;
            }
            case "unlock":{
                GoodsContainerUnlockData unlockingData = goodsContainer
                        .getUnlockingData();

                if (unlockingData == null){
                    hc.sendMessage(gmReply("格子已经全部解锁"));
                    return;
                }

                long ctime = timeService.getCurrentTime();

                for (;;){
                    if (unlockingData.nextLevel == null){
                        break;
                    }

                    unlockingData = unlockingData.nextLevel;

                    if (unlockingData.rowUnlockDatas.length == 1){
                        int unlockPos = unlockingData.openSlotCount
                                + goodsContainer.getInitSize() - 1;
                        goodsContainer.unlockSlot(unlockingData, ctime);
                        hc.sendMessage(manualOpenSlotMsg(
                                goodsContainer.getType(), unlockPos, 0,
                                unlockingData.nextLevel,
                                unlockingData.accStatData, ctime));
                    }
                }

                int unlockPos = unlockingData.openSlotCount
                        + goodsContainer.getInitSize() - 1;

                goodsContainer.unlockSlot(unlockingData, ctime);
                hc.sendMessage(manualOpenSlotMsg(goodsContainer.getType(),
                        unlockPos, 0, unlockingData.nextLevel,
                        unlockingData.accStatData, ctime));

                // 更新战斗力
                hc.getHeroFightModule().updateFightingAmount();
                return;
            }
        }

        hc.sendMessage(gmReply("未知的命令: " + arg[0] + " " + arg[1] + " " + arg[2]));
        return;
    }

    // --------  goods -------

    private static final ChannelBuffer HELP_GOODS_MSG = gmReply(Joiner.on(
            "<br>").join(
            new String[]{"zb id refinedTimes quality statType 获取已经装备，后3个字段可选",
                    "goods give id count"}));

    private void processGoodsQuery(String lastCmd, HeroController hc){
        String[] arg = lastCmd.split(" ");
        switch (arg[0]){
            case "help":{
                hc.sendMessage(HELP_GOODS_MSG);
                return;
            }
            case "give":{
                processGiveGoodsQuery(arg, hc);
                return;
            }
            case "zb":{
                processEquipmentQuery(arg, hc);
                return;
            }
            case "gm":{
                int source = Integer.parseInt(arg[1]);
                int pos = Integer.parseInt(arg[2]);
                Goods g = null;
                if (arg.length > 3){
                    int depotPos = Integer.parseInt(arg[3]);
                    g = hc.getDepot().get(depotPos);
                }

                if (g == null){
                    hc.sendMessage(gmReplaceGoods(source, pos));
                } else{
                    hc.sendMessage(gmReplaceGoods(source, pos, g.getData()
                            .getProtoBytes(), g.encodeBytes4Client()));
                }

                return;
            }

            default:{
                hc.sendMessage(gmReply("未知的命令: " + arg[0]));
                return;
            }
        }
    }

    private void processGiveGoodsQuery(String[] arg, HeroController hc){

        int id = Integer.parseInt(arg[1]);
        GoodsData data = configService.getGoods().get(id);
        if (data == null){
            hc.sendMessage(gmReply("物品没找到, " + arg[1]));
            return;
        }

        int count = 1;
        if (arg.length > 2){
            count = Integer.parseInt(arg[2]);
            if (count < 1){
                count = 1;
            }
        }

        boolean binded = true;
        if (arg.length > 3){
            binded = "0".equals(arg[3]);
        }

        do{
            int c = count > data.getMaxCount() ? data.getMaxCount() : count;
            count -= data.getMaxCount();

            Goods g = data.createGoods4Test(c);
            if (binded){
                g.bind();
            }

            hc.getHeroFightModule()
                    .getServices()
                    .getModules()
                    .getGoodsModule()
                    .addGoods(hc.getHero(), g, hc.getSender(),
                            hc.getHeroMiscModule(), GM, 0,
                            timeService.getCurrentTime());
        } while (count > 0);
    }

    private void processEquipmentQuery(String[] arg, HeroController hc){

        String[] arr = arg[1].split("-");

        int startId = Integer.parseInt(arr[0]);
        int endId = startId;
        if (arr.length > 1){
            endId = Integer.parseInt(arr[1]);
        }

        if (startId > endId || startId < endId - 20){
            hc.sendMessage(gmReply("startId > endId || startId < endId - 20, "
                    + arg[1]));
            return;
        }

        int refinedTimes = 0;
        if (arg.length > 2){
            refinedTimes = Integer.parseInt(arg[2]);
        }

        Quality quality = Quality.WHITE;
        if (arg.length > 3){
            quality = Quality.valueOf(Integer.parseInt(arg[3]));
            if (quality == null){
                quality = Quality.WHITE;
            }
        }

        StatType statType = null;
        if (arg.length > 4){
            statType = StatType.valueOf(Integer.parseInt(arg[4]));
        }

        boolean binded = true;
        if (arg.length > 5){
            binded = "0".equals(arg[5]);
        }

        for (int id = startId; id <= endId; id++){
            EquipmentData data = configService.getGoods().getEquipment(id);
            if (data == null){
                hc.sendMessage(gmReply("装备没找到, " + id));
                continue;
            }

            Equipment e = data.newEquipment4Test(refinedTimes, statType,
                    quality);

            if (binded){
                e.bind();
            }

            hc.getHeroFightModule()
                    .getServices()
                    .getModules()
                    .getGoodsModule()
                    .addGoods(hc.getHero(), e, hc.getSender(),
                            hc.getHeroMiscModule(), GM, 0,
                            timeService.getCurrentTime());
        }
        return;
    }

    // ------ money ---------
    private static final ChannelBuffer HELP_MONEY_MSG = gmReply(Joiner.on(
            "<br>").join(
            new String[]{"money add yinliang 数值: 增加xx银两, 负数表示减",
                    "money add lijin 数值: 增加xx礼金, 负数表示减",
                    "money add yuanbao 数值: 增加xx元宝, 负数表示减",
                    "money add soushen 数值: 增加xx搜神值, 负数表示减",
                    "money add honor 数值: 增加xx荣誉值, 负数表示减"}));

    private void processMoneyQuery(String lastCmd, HeroController hc){
        String[] arg = lastCmd.split(" ");
        switch (arg[0]){
            case "help":{
                hc.sendMessage(HELP_MONEY_MSG);
                return;
            }

            case "add":{
                processAddMoneyQuery(arg, hc);
                return;
            }
            case "all":{
                hc.getHeroMiscModule().addMoney(1000000, GM, null);
                hc.getHeroMiscModule().addLijin(1000000, GM, null);

                hc.onRecharge(1000000, null, timeService.getCurrentTime());
                return;
            }
            default:{
                hc.sendMessage(gmReply("未知的命令: " + arg[0]));
            }
        }
    }

    private void processAddMoneyQuery(String[] arg, HeroController hc){
        switch (arg[1]){
            case "yinliang":{
                int amount = Integer.parseInt(arg[2]);
                if (amount > 0){
                    if (!hc.heroMiscModule.addMoney(amount, GM, null)){
                        hc.sendMessage(gmReply("银两超出限制"));
                    }
                } else{
                    if (!hc.heroMiscModule.reduceMoney(-amount, GM, null)){
                        hc.sendMessage(gmReply("不够减"));
                    }
                }
                return;
            }

            case "lijin":{
                int amount = Integer.parseInt(arg[2]);
                if (amount > 0){
                    if (!hc.heroMiscModule.addLijin(amount, GM, null)){
                        hc.sendMessage(gmReply("礼金超出限制"));
                    }
                } else{
                    if (!hc.heroMiscModule.reduceLijin(-amount, GM, null)){
                        hc.sendMessage(gmReply("不够减"));
                    }
                }
                return;
            }

            case "friendyuanbao":{
                final int amount = Integer.parseInt(arg[2]);
                if (amount > 0){

                    LongArrayList list = hc.getHero().getRelationList()
                            .gmGetFriendList();
                    for (int i = 0; i < list.size(); i++){
                        final long heroID = list.get(i);
                        threadService.getExecutor(IDUtils.getUserID(heroID))
                                .execute(new Runnable(){
                                    @Override
                                    public void run(){
                                        try{
                                            doRecharge(heroID, amount);
                                        } catch (Throwable e){
                                            // TODO Auto-generated catch block
                                            e.printStackTrace();
                                        }
                                    }
                                });
                    }
                } else{
                    hc.sendMessage(gmReply("必须>0"));
                }
                return;
            }

            case "yuanbao":{
                int amount = Integer.parseInt(arg[2]);
                if (amount > 0){
                    if (!hc.heroMiscModule.addYuanbao(amount, GM, null)){
                        hc.sendMessage(gmReply("元宝超出限制"));
                    } else{
                        hc.getHero().setHasRecharged();
                        vipModule.addVipExp(hc.getHeroFightModule(), amount);

                        // 加充值
                        hc.heroMiscModule.addRechargeYuanbao(amount);

                        // 插入订单
                        final long heroId = hc.combinedID;
                        final long ctime = timeService.getCurrentTime();
                        final String orderID = String.valueOf(heroId) + "@"
                                + String.valueOf(ctime);
                        final int orderTime = (int) (ctime / 1000);
                        final int processTime = orderTime;
                        final int rmb = amount * 10;
                        try{
                            boolean result = dbService.insertRechargeOrder(
                                    StringEncoder.encode(orderID), heroId,
                                    IDUtils.getOperatorID(heroId),
                                    IDUtils.getServerID(heroId),
                                    IDUtils.getUserID(heroId), rmb, amount,
                                    orderTime, processTime, Empty.BYTE_ARRAY,
                                    Empty.BYTE_ARRAY);

                            if (!result){
                                throw new IllegalStateException("尝试插入订单返回不成功");
                            }

                        } catch (Throwable e){
                            logger.error("DBService.insertRechargeOrder异常", e);
                        }
                    }
                } else{
                    if (!hc.heroMiscModule.reduceYuanbao(-amount, GM, null)){
                        hc.sendMessage(gmReply("不够减"));
                    }
                }
                return;
            }
            case "bdyb":{
                int amount = Integer.parseInt(arg[2]);
                if (amount > 0){
                    hc.heroMiscModule.addBindedYuanbao(amount);
                    hc.onRechargedProcess(amount);
                } else{
                    if (!hc.heroMiscModule.reduceBindedYuanbao(-amount, GM,
                            null)){
                        hc.sendMessage(gmReply("不够减"));
                    }
                }
                return;
            }

            case "soushen":{
                int amount = Integer.parseInt(arg[2]);
                if (amount > 0){
                    hc.getHeroMiscModule().addSouShenPoint(amount, GM, null);
                } else{
                    hc.getHeroMiscModule()
                            .reduceSouShenPoint(-amount, GM, null);
                }
                return;
            }
            case "honor":{
                int amount = Integer.parseInt(arg[2]);
                if (amount > 0){
                    hc.getHeroMiscModule().addHonorPoint(amount, GM, null);
                } else{
                    hc.getHeroMiscModule().reduceHonorPoint(-amount, GM, null);
                }
                return;
            }
            case "shengwang":{
                int amount = Integer.parseInt(arg[2]);
                hc.getHeroMiscModule().addShengWang(Math.abs(amount), GM);
                return;
            }
            default:{
                hc.sendMessage(gmReply("未知的命令: " + arg[1]));
            }
        }
    }

    private void doRecharge(long heroId, int amount) throws Throwable{
        final long ctime = timeService.getCurrentTime();
        final String orderID = String.valueOf(heroId) + "@"
                + String.valueOf(ctime);
        final int orderTime = (int) (ctime / 1000);
        final int processTime = orderTime;
        final int rmb = amount * 10;
        HeroController hc = worldService.getHeroController(heroId);
        if (hc != null){
            // 尝试插入订单
            boolean result = dbService.insertRechargeOrder(
                    StringEncoder.encode(orderID), heroId,
                    IDUtils.getOperatorID(heroId), IDUtils.getServerID(heroId),
                    IDUtils.getUserID(heroId), rmb, amount, orderTime,
                    processTime, Empty.BYTE_ARRAY, Empty.BYTE_ARRAY);

            if (!result){
                return;
            }
            tryOnlineRecharge(hc, amount, orderID);
        } else{
            HeroSimpleData simpleData = dbService.getHeroSimpleData(heroId);

            if (simpleData == null){
                return;
            }

            // 尝试插入订单
            boolean result = dbService.insertRechargeOrder(
                    StringEncoder.encode(orderID), heroId,
                    IDUtils.getOperatorID(heroId), IDUtils.getServerID(heroId),
                    IDUtils.getUserID(heroId), rmb, amount, orderTime,
                    processTime, Empty.BYTE_ARRAY, Empty.BYTE_ARRAY);

            if (!result){
                return;
            }

            tryOfflineRecharge(simpleData, heroId, amount);
        }
    }

    private void tryOnlineRecharge(HeroController hc, int gold, String iEventId)
            throws Throwable{
        long ctime = timeService.getCurrentTime();
        hc.onRecharge(gold, iEventId, ctime);

        // 保存数据，防止挂掉了，没有加上数据
        HeroServerProto heroData = hc.getHero().encodeHeroServerProto(ctime);
        HeroMinorProto heroMinorData = hc.getHero().encodeMinorData(ctime);
        dbService.saveHeroData(hc.getID(), heroData, heroMinorData);
    }

    @SelfThreadOnly
    private void tryOfflineRecharge(HeroSimpleData simpleData, long heroId,
            int gold) throws Throwable{

        // server
        HeroServerProto.Builder serverBuilder = simpleData.serverProto
                .toBuilder();
        serverBuilder.setHasRechargedYuanbao(true);

        int newVipExp = serverBuilder.getVipExp() + gold;
        if (newVipExp >= 0 && newVipExp <= VariableConfig.VIP_EXP_MAX_VALUE){
            serverBuilder.setVipExp(newVipExp);
        } else{
            serverBuilder.setVipExp(VariableConfig.VIP_EXP_MAX_VALUE);
        }

        // minor
        HeroMinorProto.Builder minorBuilder = simpleData.minorProto.toBuilder();
        int oldYuanbao = minorBuilder.getYuanbao();
        int newYuanbao = oldYuanbao + gold;
        if (newYuanbao >= 0 && newYuanbao <= VariableConfig.YUANBAO_MAX_AMOUNT){
            minorBuilder.setYuanbao(newYuanbao);
        } else{
            newYuanbao = VariableConfig.YUANBAO_MAX_AMOUNT;
            // 发邮件
            if (gold > VariableConfig.YUANBAO_MAX_AMOUNT){
                // 分2封邮件发
                mailModule.newMailOnYuanbaoReachedMaxLimit(heroId,
                        VariableConfig.YUANBAO_MAX_AMOUNT);
                mailModule.newMailOnYuanbaoReachedMaxLimit(heroId, gold
                        - VariableConfig.YUANBAO_MAX_AMOUNT);
            } else{
                mailModule.newMailOnYuanbaoReachedMaxLimit(heroId, gold);
            }
        }

        // 总充值元宝数
        int newTotalRechargeYuanbao = minorBuilder.getTotalRechargeYuanbao()
                + gold;
        if (newTotalRechargeYuanbao >= 0
                && newTotalRechargeYuanbao <= VariableConfig.YUANBAO_MAX_AMOUNT){
            minorBuilder.setTotalRechargeYuanbao(newTotalRechargeYuanbao);
        } else{
            minorBuilder
                    .setTotalRechargeYuanbao(VariableConfig.YUANBAO_MAX_AMOUNT);
        }

        HeroServerProto serverProto = serverBuilder.build();
        HeroMinorProto minorProto = minorBuilder.build();
        // 保存数据
        dbService.saveHeroData(heroId, serverProto, minorProto);

    }

    // ----- scene --------

    private static final ChannelBuffer HELP_SCENE_MSG = gmReply(Joiner.on(
            "<br>").join(
            new String[]{"scene move x y: 瞬移到本场景的<x, y>坐标. 如果坐标不可走则无效",
                    "scene killall: 瞬间击杀视野里所有英雄", "scene ts 场景id: 传送进入个剧情副本"}));

    private void processSceneQuery(String lastCmd, HeroController hc){
        String[] arg = lastCmd.split(" ");
        switch (arg[0]){
            case "help":{
                hc.sendMessage(HELP_SCENE_MSG);
                return;
            }

            case "move":{
                int x = Integer.parseInt(arg[1]);
                int y = Integer.parseInt(arg[2]);
                hc.heroFightModule.gmMove(x, y);
                return;
            }

            case "killall":{
                hc.heroFightModule.gmKillAllHero();
                return;
            }

            case "ts":{
                int sceneID = Integer.parseInt(arg[1]);
                SceneData data = sceneDatas.get(sceneID);
                if (!(data instanceof StoryDungeonSceneData)){
                    hc.sendMessage(gmReply("你要的场景不存在或不是剧情副本"));
                    return;
                }

                storyDungeonModule
                        .gmTransport(hc, (StoryDungeonSceneData) data);
                return;
            }

            case "leave":{
                hc.getHeroFightModule().gmDoLeaveDungeon();
                return;
            }

            case "tp":{
                int sid = Integer.parseInt(arg[1]);
                NormalSceneData sceneData = configService.getScenes()
                        .getNormal(sid);

                if (!(sceneData instanceof NormalSceneData)){
                    hc.sendMessage(gmReply("你要的场景不存在或不是普通场景"));
                    return;
                }

                int randomPos = sceneData.getRandomPoint();
                hc.getHeroFightModule().transportHero(sceneData,
                        Utils.getHighShort(randomPos),
                        Utils.getLowShort(randomPos), TransportType.GM_TP);
                return;
            }
            case "two_tp":{

                NormalSceneData sceneData = null;
                if (arg.length > 1){
                    int sid = Integer.parseInt(arg[1]);
                    sceneData = configService.getScenes().getNormal(sid);
                    hc.sendMessage(sceneData.changeToThisSceneMessage);
                }

                if (sceneData == null){
                    sceneData = configService.getScenes().getMediteScene();
                    hc.sendMessage(sceneData.changeToThisSceneMessage);
                }

                sceneData = null;
                if (arg.length > 2){
                    int sid = Integer.parseInt(arg[2]);
                    sceneData = configService.getScenes().getNormal(sid);
                }

                if (!(sceneData instanceof NormalSceneData)){
                    sceneData = configService.getScenes().getMediteScene();
                }

                int randomPos = sceneData.getRandomPoint();
                hc.getHeroFightModule().transportHero(sceneData,
                        Utils.getHighShort(randomPos),
                        Utils.getLowShort(randomPos), TransportType.GM_TP);
                return;
            }

            default:{
                hc.sendMessage(gmReply("未知的命令: " + arg[0]));
            }
        }
    }
}
