package app.game.module;

import static app.game.module.BowMessages.*;
import static app.protobuf.LogContent.LogEnum.OperateType.BOW_UPGRADE;

import org.jboss.netty.buffer.ChannelBuffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.cluster.client.combat.scene.ILocalClusterScene;
import app.cluster.shared.scene.ClusterSceneHeader;
import app.game.data.SpriteStat;
import app.game.data.UpgradeData;
import app.game.data.UpgradeData.ReduceCostResult;
import app.game.data.bow.BowData;
import app.game.data.bow.BowDatas;
import app.game.data.bow.HeroBow;
import app.game.data.goods.CritCardData;
import app.game.entity.Hero;
import app.game.entity.Model.ModelType;
import app.game.module.scene.HeroFightModule;
import app.game.module.scene.IScene;
import app.game.service.TimeService;
import app.game.service.WorldService;
import app.game.service.log.LogService;
import app.game.service.log.processor.RefinedUpgradeProcessor;
import app.message.ISender;
import app.protobuf.LogContent.LogEnum.OperateType;
import app.utils.IndividualServerConfig;
import app.utils.VariableConfig;

import com.google.inject.Inject;
import com.mokylin.sink.util.BufferUtil;

/**
 * @author Liwei
 *
 */
public class BowModule{

    private static final Logger logger = LoggerFactory
            .getLogger(BowModule.class);

    private final WorldService worldService;

    private final TimeService timeService;

    private final GoodsContainerModule goodsContainerModule;

    private final BowDatas bowDatas;

    private final LogService logService;

    private final int collectFreeBowLevel;

    @Inject
    BowModule(WorldService worldService, TimeService timeService,
            GoodsContainerModule goodsContainerModule, BowDatas bowDatas,
            LogService logService, VariableConfig variableConfig,
            IndividualServerConfig serverConfig){
        this.worldService = worldService;
        this.timeService = timeService;
        this.goodsContainerModule = goodsContainerModule;
        this.bowDatas = bowDatas;

        this.logService = logService;

        collectFreeBowLevel = variableConfig.COLLECT_FREE_BOW_LEVEL;
    }

    public void onMessage(final int sequenceID, final ChannelBuffer buffer,
            final HeroController hc){

        switch (sequenceID){
            case C2S_BOW_UPGRADE:{
                onBowUpgrade(hc, buffer);
                return;
            }
//            case C2S_ARROW_UPGRADE:{
//                onArrowUpgrade(hc, buffer);
//                return;
//            }
            case C2S_GET_FREE_BOW:{
                onGetFreeBow(hc, buffer);
                return;
            }
            case C2S_CHANGE_BOW_RESOURCE:{
                onChangeBowResource(hc, buffer);
                return;
            }
            default:{
                logger.error("BowModule模块收到未知消息: {}", sequenceID);
            }
        }
    }

    private void onChangeBowResource(HeroController hc, ChannelBuffer buffer){
        Hero hero = hc.getHero();

        if (hero.getBow() == null){
            logger.warn("英雄还没有凤舞弓，收到改变造型的消息");
            hc.sendMessage(ERR_CHANGE_BOW_RESOURCE_FAIL_NOT_BOW);
            return;
        }

        int newBowId = BufferUtil.readVarInt32(buffer);

        HeroBow bow = hero.getBow();
        if (bow.getBowId() < newBowId){
            logger.warn("凤舞弓改变造型，但是凤舞弓等级不足");
            hc.sendMessage(ERR_CHANGE_BOW_RESOURCE_FAIL_NOT_ENOUGH_LEVEL);
            return;
        }

        if (newBowId > 0){
            hc.sendMessage(bowDatas.getBow(newBowId).getChangeResourceMsg());
        } else{
            newBowId = 0;
            hc.sendMessage(HIDE_BOW_MSG);
        }

        // 改变英雄换装
        bow.changeBowResource(newBowId);
        hero.replaceEquipmentResources(ModelType.BOW, bow.getBowResource());
        hc.getHeroFightModule().onEquipmentResourcesChanged();
    }

    private void onGetFreeBow(HeroController hc, ChannelBuffer buffer){
        Hero hero = hc.getHero();

        if (hero.getBow() != null){
            logger.warn("英雄已经有凤舞弓了，还收到领取的消息");
            hc.sendMessage(ERR_GET_FREE_BOW_FAIL_OWN_BOW);
            return;
        }

        if (hero.getLevel() < collectFreeBowLevel){
            logger.warn("领取凤舞弓，英雄等级不足");
            hc.sendMessage(ERR_GET_FREE_BOW_FAIL_LEVEL_NOT_ENOUGH);
            return;
        }

        giveBow(hc.getHeroFightModule(), hc.getSender());
    }

    public void giveBow(HeroFightModule heroFightModule, ISender sender){

        Hero hero = heroFightModule.getHero();

        HeroBow bow = hero.getBow();
        if (bow != null){
            return; // 防御性
        }

        long ctime = timeService.getCurrentTime();

        BowData data = bowDatas.getFirstBow();
        bow = data.newBow();
        bow.setBowUpdateTime(ctime);

        hero.setBow(bow);
        sender.sendMessage(bowDatas.getGiveFirstBowMsg());

        // 换装
        hero.replaceEquipmentResources(ModelType.BOW, bow.getBowResource());
        heroFightModule.onEquipmentResourcesChanged();

        // 加属性神马的
        heroFightModule.changeBaseStat(true, bow.getBaseStat(), ctime);

        // 更新战斗力
        heroFightModule.updateFightingAmount();

        hero.onBestBowChanged(bow.getBowId());
        hero.getGuildMember().setBowLevel(data.getId());
        heroFightModule.getRankObject().onBowUpdate(hero);

        IScene parent = heroFightModule.getParent();
        if (parent instanceof ILocalClusterScene){
            ILocalClusterScene localScene = (ILocalClusterScene) parent;
            localScene.sendToRemoteScene(ClusterSceneHeader.S2C.bowUpgrade(
                    localScene.getSceneUUID(), hero.getID(), data.id));
        }
    }

    private void onBowUpgrade(HeroController hc, ChannelBuffer buffer){
        Hero hero = hc.getHero();

        HeroBow bow = hero.getBow();

        if (bow == null){
            logger.warn("凤舞弓升阶，但是英雄还没有弓箭");
            hc.sendMessage(ERR_UPGRADE_BOW_FAIL_NOT_BOW);
            return;
        }

        BowData bowData = bow.getBowData();
        BowData nextLevel = bowData.getNextLevel();
        if (nextLevel == null){
            logger.warn("凤舞弓升阶，但是已经是最高级了");
            hc.sendMessage(ERR_UPGRADE_BOW_FAIL_MAX_LEVEL);
            return;
        }

        long ctime = timeService.getCurrentTime();
        if (ctime < nextLevel.getOpenTime(hc.getServerData().startServiceTime)){
            logger.warn("凤舞弓升阶，但是这阶凤舞弓的开放时间还没到");
            hc.sendMessage(ERR_UPGRADE_BOW_FAIL_BOW_NOT_OPEN);
            return;
        }

        UpgradeData upgradeData = bowData.getUpgradeData();

        String iEventId = logService.getRefinedUpgradeProcessor().newEventID(
                hc.getID());

        ReduceCostResult result = upgradeData.tryReduceCostAllowBindedYuanbao(
                "风舞弓升阶", hc.getHeroMiscModule(), ctime, hero, hc.getSender(),
                buffer, goodsContainerModule, BOW_UPGRADE, iEventId);

        switch (result.getStatus()){
            case SUCCESS:{
                break;
            }
            case INVALID_POS_COUNT:{
                hc.sendMessage(ERR_UPGRADE_BOW_FAIL_INVALID_POS);
                return;
            }
            case GOODS_NOT_ENOUGH:{
                hc.sendMessage(ERR_UPGRADE_BOW_FAIL_GOODS_NOT_ENOUGH);
                return;
            }
            case LIJIN_NOT_ENOUGH:{
                hc.sendMessage(ERR_UPGRADE_BOW_FAIL_LIJIN_NOT_ENOUGH);
                return;
            }
            case YUANBAO_NOT_ENOUGH:{
                hc.sendMessage(ERR_UPGRADE_BOW_FAIL_YUANBAO_NOT_ENOUGH);
                return;
            }
            case MONEY_NOT_ENOUGH:{
                hc.sendMessage(ERR_UPGRADE_BOW_FAIL_MONEY_NOT_ENOUGH);
                return;
            }
            case REAL_AIR_NOT_ENOUGH:{
                hc.sendMessage(ERR_UPGRADE_BOW_FAIL_GOODS_NOT_ENOUGH);
                return;
            }
            default:{
                logger.error("风舞弓进阶，遇到未知的失败类型，{}", result);
                hc.sendMessage(ERR_UPGRADE_BOW_FAIL_GOODS_NOT_ENOUGH);
                return;
            }
        }

        // 进阶
        tryUpgradeBow(hc, bow, upgradeData, nextLevel, ctime, iEventId);
    }

    private void tryUpgradeBow(HeroController hc, HeroBow bow,
            UpgradeData upgradeData, BowData nextLevel, long ctime,
            String iEventId){
        int upgradeTimes = bow.incrementUpgradeTimes();
        if (upgradeData.tryUpgrade(upgradeTimes)){
            // 进阶成功
            doBowUpgrade(hc, bow, nextLevel, ctime, BOW_UPGRADE, iEventId);
            return;
        }

        int toAddBless = upgradeData.randomBlessAmount();
        toAddBless += hc.getHeroFightModule().getHero()
                .randomBlessAmount(CritCardData.BOW, ctime);
        int newBless = bow.addBlessAmount(toAddBless);

        if (newBless >= upgradeData.getUpgradeMaxBless()){
            // 进阶成功
            doBowUpgrade(hc, bow, nextLevel, ctime, BOW_UPGRADE, iEventId);
            return;
        }

        if (newBless <= toAddBless){
            // 第一次，加清理时间
            if (upgradeData.getBlessHoldTime() > 0){
                long clearTime = ctime + upgradeData.getBlessHoldTime();

                bow.setClearBlessTime(clearTime);
                hc.sendMessage(updateBowBlessClearTime(clearTime));

                Hero hero = hc.getHero();
                logService.getRefinedUpgradeBlessProcessor().addLogEvent(
                        hero.getOperatorId(), iEventId, hero.getServerId(),
                        hero.getUin(), hero.getUserId(), hero.getName(),
                        RefinedUpgradeProcessor.BOW_TYPE, bow.getBowId(),
                        clearTime);
            }
        }

        // 加祝福值
        hc.sendMessage(updateBowBlassMsg(newBless));
    }

    void doBowUpgrade(HeroController hc, HeroBow bow, BowData nextLevel,
            long ctime, OperateType type, String iEventId){
        Hero hero = hc.getHero();

        assert bow != null;
        assert bow == hero.getBow();
        assert bow.getBowData().getNextLevel() == nextLevel;

        SpriteStat oldStat = bow.getBaseStat();

        bow.upgradeBow(ctime);
        assert bow.getBowData() == nextLevel;

        hc.sendMessage(nextLevel.getUpgradeMsg());

        // 换装
        hero.replaceEquipmentResources(ModelType.BOW, bow.getBowResource());
        hc.heroFightModule.onEquipmentResourcesChanged();

        // 加属性神马的
        hc.getHeroFightModule().changeBaseStat(oldStat, bow.getBaseStat(),
                ctime);

        // 更新战斗力
        hc.getHeroFightModule().updateFightingAmount();

        if (nextLevel.isUpgradeBroadcast()){
            // 广播全部，进阶成功
            worldService.broadcastToEnteredFirstSceneHeroWithSameServerData(
                    upgradeBowBroadcastMsg(hero.getNameBytes(),
                            nextLevel.getId()), hc.getServerData(), 0);
        }

        logService.getRefinedUpgradeProcessor().addLogEvent(
                hero.getOperatorId(), iEventId, hero.getServerId(),
                hero.getUin(), hero.getUserId(), hero.getName(),
                RefinedUpgradeProcessor.BOW_TYPE, nextLevel.getId());

        hero.onBestBowChanged(bow.getBowId());
        hero.getGuildMember().setBowLevel(nextLevel.getId());
        hc.getHeroFightModule().getRankObject().onBowUpdate(hero);

        IScene parent = hc.getHeroFightModule().getParent();
        if (parent instanceof ILocalClusterScene){
            ILocalClusterScene localScene = (ILocalClusterScene) parent;
            localScene.sendToRemoteScene(ClusterSceneHeader.S2C.bowUpgrade(
                    localScene.getSceneUUID(), hero.getID(), nextLevel.id));
        }
    }
//    private void onArrowUpgrade(HeroController hc, ChannelBuffer buffer){
//        Hero hero = hc.getHero();
//
//        HeroBow bow = hero.getBow();
//
//        if (bow == null){
//            logger.warn("凤舞箭升阶，但是英雄还没有弓箭");
//            hc.sendMessage(ERR_UPGRADE_ARROW_FAIL_INVALID_BOW);
//            return;
//        }
//
//        ArrowData arrowData = bow.getArrowData();
//
//        ArrowData nextLevel;
//        if (arrowData == null){
//            // 说明是激活
//            nextLevel = bowDatas.getFirstArrow();
//        } else{
//            nextLevel = arrowData.getNextLevel();
//            if (nextLevel == null){
//                logger.warn("凤舞箭升阶，但是已经是最高级了");
//                hc.sendMessage(ERR_UPGRADE_ARROW_FAIL_MAX_LEVEL);
//                return;
//            }
//        }
//
//        if (nextLevel.getRequireBowLevel() > bow.getBowId()){
//            logger.warn("凤舞箭升阶，所需的凤舞弓等级不足");
//            hc.sendMessage(ERR_UPGRADE_ARROW_FAIL_INVALID_BOW);
//            return;
//        }
//
//        long ctime = timeService.getCurrentTime();
//
//        UpgradeData upgradeData = nextLevel.getUpgradeData();
//
//        ReduceCostResult result = upgradeData.tryReduceCost("风舞箭升阶",
//                hc.getHeroMiscModule(), ctime, hero, hc.getSender(), buffer,
//                goodsContainerModule, ARROW_UPGRADE, 0, 0);
//
//        switch (result.getStatus()){
//            case SUCCESS:{
//                break;
//            }
//            case INVALID_POS_COUNT:{
//                hc.sendMessage(ERR_UPGRADE_ARROW_FAIL_INVALID_POS);
//                return;
//            }
//            case GOODS_NOT_ENOUGH:{
//                hc.sendMessage(ERR_UPGRADE_ARROW_FAIL_GOODS_NOT_ENOUGH);
//                return;
//            }
//            case LIJIN_NOT_ENOUGH:{
//                hc.sendMessage(ERR_UPGRADE_ARROW_FAIL_LIJIN_NOT_ENOUGH);
//                return;
//            }
//            case YUANBAO_NOT_ENOUGH:{
//                hc.sendMessage(ERR_UPGRADE_ARROW_FAIL_YUANBAO_NOT_ENOUGH);
//                return;
//            }
//            case MONEY_NOT_ENOUGH:{
//                hc.sendMessage(ERR_UPGRADE_ARROW_FAIL_MONEY_NOT_ENOUGH);
//                return;
//            }
//            case REAL_AIR_NOT_ENOUGH:{
//                hc.sendMessage(ERR_UPGRADE_ARROW_FAIL_GOODS_NOT_ENOUGH);
//                return;
//            }
//            default:{
//                logger.error("风舞箭进阶，遇到未知的失败类型，{}", result);
//                hc.sendMessage(ERR_UPGRADE_ARROW_FAIL_GOODS_NOT_ENOUGH);
//                return;
//            }
//        }
//
//        // 激活
//        if (arrowData == null){
//            bow.setArrow(nextLevel);
//            hc.sendMessage(giveFirstArrowMsg);
//
//            // 加属性神马的
//            hc.getHeroFightModule().changeBaseStat(true,
//                    nextLevel.getBaseStat(), ctime);
//
//            // 更新战斗力
//            hc.sendMessage(HeroMiscMessages.changeHeroFightingAmountMsg(hero
//                    .updateFightingAmount()));
//
//            logService.writeOperateLog(ARROW_UPGRADE, ARROW, nextLevel.getId(),
//                    bow.getArrowStar(), 0, 0, 0, hero);
//            return;
//        }
//
//        int toAddExp = nextLevel.randomExp();
//
//        int arrowStar = bow.getArrowStar();
//        int arrowExp = bow.getArrowExp();
//
//        // 加经验
//        int newExp = bow.addArrowExp(toAddExp);
//
//        ArrowData newArrowData = bow.getArrowData();
//        if (arrowData == newArrowData){
//            // 还是同一阶
//            if (arrowStar == bow.getArrowStar()){
//                // 还是同一星
//                hc.sendMessage(updateArrowExpMsg(newExp));
//            } else{
//                hc.sendMessage(updateArrowStarMsg(bow.getArrowStar(), newExp));
//            }
//        } else{
//            // 升阶了
//            hc.sendMessage(upgradeArrowSuccess(newArrowData.getId(),
//                    bow.getArrowStar(), newExp));
//
//            // 加属性神马的
//            hc.getHeroFightModule().changeBaseStat(arrowData.getBaseStat(),
//                    newArrowData.getBaseStat(), ctime);
//
//            // 更新战斗力
//            hc.sendMessage(HeroMiscMessages.changeHeroFightingAmountMsg(hero
//                    .updateFightingAmount()));
//
//            if (newArrowData.isUpgradeBroadcast()){
//                // 广播全部，进阶成功
//                worldService.broadcastToEnteredFirstSceneHero(
//                        upgradeArrowBroadcastMsg(hero.getNameBytes(),
//                                newArrowData.getId()), 0);
//            }
//        }
//
//        logService.writeOperateLog(ARROW_UPGRADE, ARROW, newArrowData.getId(),
//                bow.getArrowStar(), arrowExp, newExp, toAddExp, hero);
//    }
}
