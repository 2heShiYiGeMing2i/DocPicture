package app.game.module.auction;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.data.goods.Goods;
import app.protobuf.GoodsServerContent.GoodsType;
import app.utils.VariableConfig;

import com.mokylin.sink.util.BufferUtil;

public class AuctionLog{

    private static final int MONEY_GOODS_TYPE = GoodsType.MONEY_GOODS
            .getNumber();

    private static final int MONEY_GOODS_TYPE_VARINT32_LEN = BufferUtil
            .computeVarInt32Size(MONEY_GOODS_TYPE);

    private static final int YUANBAO_GOODS_TYPE = GoodsType.YUANBAO_GOODS
            .getNumber();

    private static final int YUANBAO_GOODS_TYPE_VARINT32_LEN = BufferUtil
            .computeVarInt32Size(YUANBAO_GOODS_TYPE);

    public final long time;
    public final long sellerCombineId;
    public final byte[] sellerNameBytes;
    public final long buyerCombineId;
    public final byte[] buyerNameBytes;

    /**
     * 买家总共花了多少钱
     */
    public final int totalCost;

    // 卖家总共能获得的收益
    public final int collectableMoney;
    public final int collectableYuanbao;
    public final int collectableExp;

    // --- 卖的是什么东西 ---

    public final int goodsType;

    // --- 物品 ---
    public final byte[] goodsServerProto;
    public final Goods goods;

    // --- 银两/元宝 ---
    public final int concurrencyAmount;

    public AuctionLog(long time, long sellerCombineId, byte[] sellerNameBytes,
            long buyerCombineId, byte[] buyerNameBytes, int totalCost,
            int collectableMoney, int collectableYuanbao, int collectableExp,
            int goodsType, byte[] goodsServerProto, Goods goods,
            int concurrencyAmount){
        super();
        this.time = time;
        this.sellerCombineId = sellerCombineId;
        this.sellerNameBytes = sellerNameBytes;
        this.buyerCombineId = buyerCombineId;
        this.buyerNameBytes = buyerNameBytes;
        this.totalCost = totalCost;
        this.collectableMoney = collectableMoney;
        this.collectableYuanbao = collectableYuanbao;
        this.collectableExp = collectableExp;
        this.goodsType = goodsType;
        this.goodsServerProto = goodsServerProto;
        this.goods = goods;
        this.concurrencyAmount = concurrencyAmount;
    }

    public void writeToAuctionLogMessage(ChannelBuffer buffer, long selfID){
        boolean isBuyer = selfID == buyerCombineId;

        BufferUtil.writeVarInt64(buffer, time);
        BufferUtil.writeBoolean(buffer, isBuyer);
        if (isBuyer){
            BufferUtil.writeVarInt64(buffer, sellerCombineId);
            BufferUtil.writeUTF(buffer, sellerNameBytes);
        } else{
            BufferUtil.writeVarInt64(buffer, buyerCombineId);
            BufferUtil.writeUTF(buffer, buyerNameBytes);
        }

        BufferUtil.writeVarInt32(buffer, getTotalCost(isBuyer));
        BufferUtil.writeVarInt32(buffer, getTax(isBuyer));
        writeGoods(buffer, isBuyer);
    }

    private int getTax(boolean isBuyer){
        if (isBuyer){
            if (goodsType == 99){
                return Math
                        .max(1,
                                (int) (concurrencyAmount * VariableConfig.YUANBAO_EXCHANGE_TAX));
            }
            return 0;
        } else{
            // 卖家
            switch (goodsType){
                case 99:{
                    return 0;
                }

                default:{
                    return Math
                            .max(1,
                                    (int) (totalCost * VariableConfig.YUANBAO_EXCHANGE_TAX));
                }
            }
        }
    }

    private void writeGoods(ChannelBuffer buffer, boolean isBuyer){
        switch (goodsType){
            case 98:{
                // 卖的是银两
                BufferUtil.writeVarInt32(buffer, MONEY_GOODS_TYPE_VARINT32_LEN
                        + BufferUtil.computeVarInt32Size(concurrencyAmount));
                BufferUtil.writeVarInt32(buffer, MONEY_GOODS_TYPE);
                BufferUtil.writeVarInt32(buffer, concurrencyAmount);
                return;
            }

            case 99:{
                // 卖的是元宝
                int amount = isBuyer ? (int) (concurrencyAmount * VariableConfig.YUANBAO_EXCHANGE_AFTER_TAX)
                        : concurrencyAmount;
                BufferUtil.writeVarInt32(
                        buffer,
                        YUANBAO_GOODS_TYPE_VARINT32_LEN
                                + BufferUtil.computeVarInt32Size(amount));
                BufferUtil.writeVarInt32(buffer, YUANBAO_GOODS_TYPE);
                BufferUtil.writeVarInt32(buffer, amount);
                return;
            }

            default:{
                // 物品
                byte[] staticInfo = goods.getData().getProtoBytes();
                byte[] dynamicInfo = goods.encodeBytes4Client();
                BufferUtil.writeVarInt32(buffer, staticInfo.length);
                buffer.writeBytes(staticInfo);
                BufferUtil.writeVarInt32(buffer, dynamicInfo.length);
                buffer.writeBytes(dynamicInfo);
                return;
            }
        }
    }

    private int getTotalCost(boolean isBuyer){
        switch (goodsType){
            case 99:{
                // 卖的是元宝, 售价是银两. 不管是买家还是卖家得到的都是全价
                return totalCost;
            }

            default:{
                // 总价都是元宝
                if (isBuyer){
                    return totalCost;
                }

                // 卖家看到的都是税后的
                return totalCost - getTax(isBuyer);
            }
        }
    }
}
