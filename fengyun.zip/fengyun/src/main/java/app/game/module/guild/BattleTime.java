package app.game.module.guild;

import com.mokylin.sink.util.annotation.MaybeNull;
import com.mokylin.sink.util.annotation.MustNotNull;

import app.game.data.ServerData;

/**
 * @author Liwei
 *
 */
public class BattleTime{

    private final boolean isRegularTime;

    private final long[] nextBattleTime;

    public final long nearestBattleTime;

    public BattleTime(long time, int serverCount){
        isRegularTime = true;
        nearestBattleTime = time;

        nextBattleTime = new long[serverCount];
        for (int i = 0; i < serverCount; i++){
            nextBattleTime[i] = time;
        }
    }

    public BattleTime(long[] battleTime){
        isRegularTime = false;
        this.nextBattleTime = battleTime;

        long min = Long.MAX_VALUE;
        for (long time : battleTime){
            if (time < min)
                min = time;
        }

        nearestBattleTime = min;
    }

    public boolean isInBattle(@MaybeNull ServerData serverData, long ctime){

        if (serverData == null){
            return isRegularTime;
        }

        return nextBattleTime[serverData.sequence] <= ctime;
    }

    public long getTime(@MustNotNull ServerData serverData){
        return nextBattleTime[serverData.sequence];
    }
}
