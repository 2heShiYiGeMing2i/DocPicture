package app.game.entity.record.goods;

public enum GoodsAddReason{

    /**
     * 拾取地上的
     */
    PICK_UP(1);

    final int actionID;

    private GoodsAddReason(int actionID){
        this.actionID = actionID;
    }
}
