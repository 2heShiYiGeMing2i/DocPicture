package app.game.entity;

import java.util.Collections;
import java.util.List;

public class RelationEntry implements Comparable<RelationEntry>{

    public static final List<RelationEntry> EMPTY_LIST = Collections
            .emptyList();

    public final int relationType;
    public final long id;
    public final RelationEntry next;

    public RelationEntry(int relationType, long id, RelationEntry next){
        this.relationType = relationType;
        this.id = id;
        this.next = next;
    }

    @Override
    public int hashCode(){
        return (int) id;
    }

    @Override
    public boolean equals(Object obj){
        if (obj instanceof RelationEntry){
            RelationEntry e = (RelationEntry) obj;
            return e.id == id && e.relationType == relationType;
        }
        return false;
    }

    @Override
    public int compareTo(RelationEntry o){
        if (id > o.id){
            return 1;
        }
        if (id < o.id){
            return -1;
        }

        return relationType - o.relationType;
    }

}
