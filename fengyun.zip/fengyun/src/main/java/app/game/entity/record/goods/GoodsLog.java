package app.game.entity.record.goods;

public class GoodsLog{

    public static final int ACTION_TYPE_ADD_GOODS = 1;
    public static final int ACTION_TYPE_REMOVE_GOODS = 2;
    public static final int ACTION_TYPE_CHANGE_IDENTIFIER = 3;

    public final int actionType;
    public final int actionID;
    public final long goodsIdentifier;
    public final int count;
    public final long time;
    public final long misc;
    public final GoodsLog next;

    /**
     * 算上自己, 总共有多少条goodsLog
     */
    public final int goodsLogCount;

    public GoodsLog(int actionType, int actionID, long goodsIdentifier,
            int count, long time, long misc, GoodsLog next){
        this.actionType = actionType;
        this.actionID = actionID;
        this.goodsIdentifier = goodsIdentifier;
        this.count = count;
        this.time = time;
        this.misc = misc;
        this.next = next;

        this.goodsLogCount = next == null ? 1 : next.goodsLogCount + 1;
    }

    public boolean equalsWithoutNext(GoodsLog other){
        return actionType == other.actionType && actionID == other.actionID
                && goodsIdentifier == other.goodsIdentifier
                && count == other.count && time == other.time
                && misc == other.misc;
    }

    public GoodsLog reverse(){
        return doReverse(null);
    }

    private GoodsLog doReverse(GoodsLog newNext){
        GoodsLog gl = new GoodsLog(actionType, actionID, goodsIdentifier,
                count, time, misc, newNext);
        if (next == null){
            return gl;
        }

        return next.doReverse(gl);
    }
}
