package app.game.entity;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.data.ConfigService;
import app.protobuf.GoodsServerContent.EquipmentServerProto;
import app.protobuf.GoodsServerContent.MountEquipmentServerProto;
import app.protobuf.HeroContent.LoginType;
import app.protobuf.HeroServerContent.HeroMinorProto;
import app.protobuf.HeroServerContent.HeroServerProto;
import app.protobuf.UserContent.UserProto;
import app.utils.IDUtils;
import app.utils.Operators;

import com.google.protobuf.ExtensionRegistry;

public class User{

    private final long combineID;
    private final long createTime;
    private final String uin;
    private Hero hero;
    private long lastWebLoginTime;
    private boolean isBanned;
    private long bannedEndTime;
    private String bannedDesc;

    public boolean isFirstLogin;

    public boolean isLogProgress;

    private volatile int clientLoadProgress;

    private int lastMaxLoadProgress;
    private int yuanbaoTestRebate;

    private User(int id, int serverID, int operatorID, long createTime,
            String userName){
        this.combineID = IDUtils.combineUserAndServerAndOperatorID(id,
                serverID, operatorID);
        this.createTime = createTime;
        this.uin = Operators.getUinString(operatorID, id, userName);
    }

    private User(long id, long createTime, String userName){
        this.combineID = id;
        this.createTime = createTime;
        this.uin = Operators.getUinString(IDUtils.getOperatorID(id),
                IDUtils.getUserID(id), userName);
    }

    public static User newUser(int id, int serverID, int operatorID,
            long createTime, String userName){
        User user = new User(id, serverID, operatorID, createTime, userName);
        user.isFirstLogin = true;
        return user;
    }

    public static User newUser(long id, long createTime, String userName){
        User user = new User(id, createTime, userName);
        user.isFirstLogin = true;
        return user;
    }

    public String getUin(){
        return uin;
    }

    public void tryUpdateClientLoadProgress(int p){
        if (clientLoadProgress < p){
            clientLoadProgress = p;
        }
    }

    public int getLoadProgress(){
        return clientLoadProgress;
    }

    public long getCreateTime(){
        return createTime;
    }

    public long getLastWebLoginTime(){
        return lastWebLoginTime;
    }

    public void setLastWebLoginTime(long lastWebLoginTime){
        this.lastWebLoginTime = lastWebLoginTime;
    }

    public boolean isBanned(){
        return isBanned;
    }

    public void setBanned(boolean isBanned){
        this.isBanned = isBanned;
    }

    public void setBanned(boolean isBanned, long endTime, String desc){
        this.isBanned = isBanned;
        this.bannedEndTime = endTime;
        this.bannedDesc = desc;
    }

    public long getCombineID(){
        return combineID;
    }

    public Hero getHero(){
        return hero;
    }

    public void setHero(Hero hero){
        this.hero = hero;
    }

    public int getAndClearYuanbaoTestRebate(){
        int result = yuanbaoTestRebate;
        yuanbaoTestRebate = 0;
        return result;
    }

    public void writeTo(ChannelBuffer buffer, LoginType loginType){
        // 写给用户自己
        buffer.writeLong(combineID);
        if (hero == null){
            buffer.writeByte((loginType.getNumber() << 1));
        } else{
            buffer.writeByte((loginType.getNumber() << 1) | 1);
            hero.writeData(buffer);
        }
    }

    public byte[] encode(){
        /*
         * 内不能包含userID和serverID
         */
        UserProto.Builder builder = UserProto.newBuilder()
                .setLastWebLoginTime(lastWebLoginTime)
                .setYuanbaoTestRebate(yuanbaoTestRebate);

        if (isBanned){
            builder.setIsBanned(true);
            if (bannedEndTime > 0){
                builder.setBannedEndTime(bannedEndTime);
            }

            if (bannedDesc != null && !bannedDesc.isEmpty()){
                builder.setBannedDesc(bannedDesc);
            }
        }

        if (clientLoadProgress > 0 || lastMaxLoadProgress > 0){
            builder.setClientLoadProgress(Math.max(clientLoadProgress,
                    lastMaxLoadProgress));
        }

        return builder.build().toByteArray();
    }

    public static final ExtensionRegistry extensionRegistry = ExtensionRegistry
            .newInstance();
    static{
        extensionRegistry.add(EquipmentServerProto.goodsProto);
        extensionRegistry.add(MountEquipmentServerProto.goodsProto);
    }

    public static User decode(long id, byte[] data, byte[] heroName,
            byte[] heroData, byte[] minorData, byte[] relationList,
            long createTime, String userName, long currentTime,
            ConfigService configService) throws Throwable{
        UserProto proto = UserProto.parseFrom(data);
        User result = new User(id, createTime, userName);
        result.lastWebLoginTime = proto.getLastWebLoginTime();
        result.yuanbaoTestRebate = proto.getYuanbaoTestRebate();

        if (proto.getIsBanned()){
            result.isBanned = proto.getBannedEndTime() == 0
                    || proto.getBannedEndTime() > currentTime;
        }

        result.lastMaxLoadProgress = proto.getClientLoadProgress();

        // parse hero
        if (heroName != null){
            if (heroData == null){
                throw new IllegalStateException(
                        "hero_name not null but hero_data null");
            }
            // 有英雄 heroName != null && heroData != null
            HeroServerProto heroProto = HeroServerProto.parseFrom(heroData,
                    extensionRegistry);

            HeroMinorProto minorProto = HeroMinorProto.getDefaultInstance();
            if (minorData != null && minorData.length > 0){
                minorProto = HeroMinorProto.parseFrom(minorData,
                        extensionRegistry);
            }

            Hero hero = Hero.decode(result.combineID, heroName, heroProto,
                    minorProto, relationList, result.uin, currentTime,
                    configService);
            result.hero = hero;
        } else{
            // heroName == null
            if (heroData != null){
                throw new IllegalStateException(
                        "hero_name null but hero_data not null");
            }
        }
        return result;
    }

    public long encodeUserInfo(){
        long userInfo = isBanned ? 1 : 0;
        userInfo = userInfo | (clientLoadProgress << 1);

        return userInfo;
    }

    @Override
    public int hashCode(){
        return (int) combineID;
    }

    @Override
    public boolean equals(Object obj){
        if (!(obj instanceof User)){
            return false;
        }

        User user = (User) obj;
        return combineID == user.combineID;
    }

    /**
     * 新建的用户
     *
     * @return
     */
    private static byte[] newEmptyUserData(){
        return newUser(0, 0, "").encode();
    }

    private static final byte[] EMPTY_USER_DATA = newEmptyUserData();

    /**
     * 返回新用户.encode的数据. 因为每个新用户都是一样的, 所以可以缓存encode之后的数据 像英雄新建时有不同的职业, 就不能缓存
     * 如果将来新建用户需要多储存些数据, 比如用户来源啥的, 就不能缓存
     *
     * @return
     */
    public static byte[] getEmptyUserData(){
        return EMPTY_USER_DATA;
    }
}
