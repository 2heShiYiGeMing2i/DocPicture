package app.game.entity;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.LinkedList;
import java.util.List;

import com.mokylin.collection.IntValueLongHashMap;

import app.game.data.ConfigService;
import app.game.data.goods.Goods;
import app.game.data.goods.GoodsShowData;
import app.protobuf.GoodsServerContent.GoodsServerProto;
import app.protobuf.HeroContent.HeroProto;
import app.protobuf.HeroServerContent.DivinationProto;
import app.utils.VariableConfig;

/**
 * @author Liwei
 *
 */
public class Divination{

    // 知天命
    private int divineTimes;

    /**
     * 吉运值
     */
    private int divineBlessAmount;

    /**
     * 知天命仓库
     */
    private final List<Goods> divineStorage;

    /**
     * 知天命日志
     */
    private final Deque<GoodsShowData> divineSelfLogs;

    public Divination(){
        divineStorage = new LinkedList<>();
        divineSelfLogs = new ArrayDeque<>(VariableConfig.DIVINE_LOG_MAX_COUNT);
    }

    void reset(){
        divineTimes = 0;
        divineBlessAmount = 0;
    }

    public int getDivineTimes(){
        return divineTimes;
    }

    public void setDivineTimes(int times){
        divineTimes = times;
    }

    public int getDivineBlessAmount(){
        return divineBlessAmount;
    }

    public void setDivineBlessAmount(int amount){
        divineBlessAmount = amount;
    }

    public List<Goods> getDivineStorage(){
        return divineStorage;
    }

    public Deque<GoodsShowData> getDivineSelfLogs(){
        return divineSelfLogs;
    }

    void encodeToSelfOnLogin(HeroProto.Builder builder){
        builder.setDivineAmount(divineBlessAmount).setDivineTimes(divineTimes)
                .setDivineStorageGoodsCount(divineStorage.size());
    }

    DivinationProto encode(){
        DivinationProto.Builder builder = DivinationProto.newBuilder()
                .setDivineTimes(divineTimes).setDivineAmount(divineBlessAmount);

        for (Goods goods : divineStorage){
            builder.addDivineStorage(goods.encode());
        }

        for (GoodsShowData log : divineSelfLogs){
            builder.addDivineSelfLog(log.getServerProto());
            builder.addSelfLogTime(log.getTime());
        }

        return builder.build();
    }

    public void decode(DivinationProto proto, ConfigService configService,
            IntValueLongHashMap goodsCountMap){
        if (proto == null){
            return;
        }

        // 知天命
        divineTimes = proto.getDivineTimes();
        divineBlessAmount = proto.getDivineAmount();

        for (int i = 0; i < proto.getDivineStorageCount(); i++){
            GoodsServerProto goodsProto = proto.getDivineStorage(i);
            Goods g = Goods.decode(goodsProto, configService, goodsCountMap);
            if (g == null)
                continue;

            divineStorage.add(g);
        }

        int logCount = Math.min(
                Math.min(proto.getDivineSelfLogCount(),
                        proto.getSelfLogTimeCount()),
                VariableConfig.DIVINE_LOG_MAX_COUNT);
        for (int i = 0; i < logCount; i++){
            GoodsShowData log = GoodsShowData.decode(proto.getDivineSelfLog(i),
                    proto.getSelfLogTime(i), configService);
            if (log != null)
                divineSelfLogs.add(log);
        }
    }
}
