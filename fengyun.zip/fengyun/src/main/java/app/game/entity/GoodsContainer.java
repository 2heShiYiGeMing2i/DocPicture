/**
 * 
 */
package app.game.entity;

import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.List;
import java.util.RandomAccess;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.data.ConfigService;
import app.game.data.goods.Goods;
import app.game.data.goods.GoodsAddHelper;
import app.game.data.goods.GoodsContainerUnlockData;
import app.game.data.goods.GoodsTryAddResult;
import app.game.data.goods.GoodsTryReduceResult;
import app.protobuf.GoodsServerContent.GoodsServerProto;
import app.protobuf.HeroContent.GoodsContainerProto;
import app.protobuf.HeroServerContent.GoodsContainerServerProto;
import app.protobuf.HeroServerContent.GoodsListProto;

import com.mokylin.collection.IntArrayList;
import com.mokylin.collection.IntHashMap;
import com.mokylin.collection.IntValueLongHashMap;
import com.mokylin.collection.LongArrayList;
import com.mokylin.sink.util.Utils;

/**
 * 物品容器，提供背包、仓库等通用存储能力
 * 
 * @author Liwei
 * 
 */
public abstract class GoodsContainer{
    private static final Logger logger = LoggerFactory
            .getLogger(GoodsContainer.class);

    private final int type;

    private final int initSize;

    final Goods[] goodsList;

    protected int size;

    /**
     * 解锁格子数据
     */
    private GoodsContainerUnlockData unlockData;

    /**
     * 开始累积时间
     */
    private long accStartTime;

    /**
     * 预留的格子数 (交易时, 有短暂时间需要保证背包中有一些格子一定为空)
     */
    private int reservedPosCount;

    public long nextCanCleanTime;

    protected GoodsContainer(int type, int initSize, int maxSize,
            GoodsContainerUnlockData unlockData, long currentTime,
            long accOpenTime){
        assert type == 0 || type == 1;

        this.type = type;
        this.initSize = initSize;
        goodsList = new Goods[maxSize];

        setUnlockData(unlockData, currentTime, accOpenTime);
    }

    public int getType(){
        return type;
    }

    public abstract boolean isLocked(int pos);

    private void setUnlockData(GoodsContainerUnlockData unlockData,
            long currentTime, long accOpenTime){
        this.unlockData = unlockData;
        size = initSize + unlockData.openSlotCount;

        accStartTime = currentTime - accOpenTime;
    }

    public int getInitSize(){
        return initSize;
    }

    public long getAccOpenTime(long ctime){
        return ctime - accStartTime;
    }

    public GoodsContainerUnlockData getUnlockingData(){
        if (unlockData != null){
            return unlockData.nextLevel;
        }

        return null;
    }

    public GoodsContainerUnlockData getUnlockedData(){
        return unlockData;
    }

    public GoodsTryAddResult canAddGoods(GoodsAddHelper toAdd){

        GoodsTryAddResult helper = GoodsTryAddResult.current();
        helper.clear();
        assert helper.checkStatus(): "GoodsBatchAddHelper处于无效的状态";

        int leastEmptyPosCount = reservedPosCount; // 至少需要多少个空格，就是所有不可堆叠的物品个数
        int maxEmptyPosCount = reservedPosCount; // 最多需要多少个空格，就是全部物品都放到空格上

        IntHashMap<GoodsAddHelper> foldableMap = helper.getFoldableMap();

        // 设置辅助字段
        toAdd.assistCount = toAdd.getCount();
        toAdd.assistPos = 0;

        if (toAdd.isFoldable()){
            maxEmptyPosCount += toAdd.getNeedEmptyPosCount();
            foldableMap.put(toAdd.getId(), toAdd);
        } else{
            leastEmptyPosCount += toAdd.getCount();
            maxEmptyPosCount += toAdd.getCount();
        }

        return canAddGoods(helper, leastEmptyPosCount, maxEmptyPosCount);
    }

    public GoodsTryAddResult canAddGoods(GoodsAddHelper[] toAdds){

        GoodsTryAddResult helper = GoodsTryAddResult.current();
        helper.clear();
        assert helper.checkStatus(): "GoodsBatchAddHelper处于无效的状态";

        if (toAdds.length <= 0){
            helper.setSuccess();
            return helper;
        }

        int leastEmptyPosCount = reservedPosCount; // 至少需要多少个空格，就是所有不可堆叠的物品个数
        int maxEmptyPosCount = reservedPosCount; // 最多需要多少个空格，就是全部物品都放到空格上
        IntHashMap<GoodsAddHelper> foldableMap = helper.getFoldableMap();
        for (int i = 0; i < toAdds.length; i++){
            GoodsAddHelper g = toAdds[i];

            // 设置辅助字段
            g.assistCount = g.getCount();
            g.assistPos = i;

            if (g.isFoldable()){
                maxEmptyPosCount += g.getNeedEmptyPosCount();
            } else{
                leastEmptyPosCount += g.getCount();
                maxEmptyPosCount += g.getCount();
                continue;
            }

            GoodsAddHelper old = foldableMap.put(g.getId(), g);
            if (old != null){
                g.assistNext = old;
            }
        }

        return canAddGoods(helper, leastEmptyPosCount, maxEmptyPosCount);
    }

    public GoodsTryAddResult canAddGoods(List<GoodsAddHelper> toAdds){
        assert toAdds instanceof RandomAccess: "canAddGoods传入的List居然不是RandomAccess";

        GoodsTryAddResult helper = GoodsTryAddResult.current();
        helper.clear();
        assert helper.checkStatus(): "GoodsBatchAddHelper处于无效的状态";

        if (toAdds.isEmpty()){
            helper.setSuccess();
            return helper;
        }

        int leastEmptyPosCount = reservedPosCount; // 至少需要多少个空格，就是所有不可堆叠的物品个数
        int maxEmptyPosCount = reservedPosCount; // 最多需要多少个空格，就是全部物品都放到空格上
        IntHashMap<GoodsAddHelper> foldableMap = helper.getFoldableMap();
        for (int i = 0; i < toAdds.size(); i++){
            GoodsAddHelper g = toAdds.get(i);

            // 设置辅助字段
            g.assistCount = g.getCount();
            g.assistPos = i;

            if (g.isFoldable()){
                maxEmptyPosCount += g.getNeedEmptyPosCount();
            } else{
                leastEmptyPosCount += g.getCount();
                maxEmptyPosCount += g.getCount();
                continue;
            }

            GoodsAddHelper old = foldableMap.put(g.getId(), g);
            if (old != null){
                g.assistNext = old;
            }
        }

        return canAddGoods(helper, leastEmptyPosCount, maxEmptyPosCount);
    }

    private GoodsTryAddResult canAddGoods(GoodsTryAddResult helper,
            int leastEmptyPosCount, int maxEmptyPosCount){

        IntHashMap<GoodsAddHelper> foldableMap = helper.getFoldableMap();
        ArrayDeque<Integer> emptyPosList = helper.getEmptyPosList();
        LongArrayList foldPosCountList = helper.getFoldPosCountList();

        for (int i = 0; i < size; i++){
            Goods g = goodsList[i];
            if (g == null){
                if (emptyPosList.size() < maxEmptyPosCount){
                    emptyPosList.add(i);

                    if (emptyPosList.size() >= leastEmptyPosCount
                            && foldableMap.isEmpty()){
                        helper.setSuccess(); // 成功
                        return helper;
                    }
                }
                continue;
            }

            if (foldableMap.isEmpty()){
                continue;
            }

            if (isLocked(i)){
                continue;
            }

            int canFoldCount = g.getData().getMaxCount() - g.getCount();
            if (canFoldCount <= 0){
                continue;
            }

            GoodsAddHelper first = foldableMap.get(g.getId());
            if (first == null){
                continue;
            }

            GoodsAddHelper newHead = first;
            for (GoodsAddHelper prev = null, cur = first; cur != null;){
                if (cur.isSameGoods(g)){
                    if (cur.assistCount > canFoldCount){
                        foldPosCountList.add(((1L * i) << 32)
                                | (cur.assistPos << 16) | canFoldCount);

                        cur.assistCount -= canFoldCount;
                        canFoldCount = 0;
                        break;
                    } else{
                        foldPosCountList.add(((1L * i) << 32)
                                | (cur.assistPos << 16) | cur.assistCount);

                        canFoldCount -= cur.assistCount;
                        cur.assistCount = 0;

                        if (prev == null){
                            // 换head
                            newHead = cur.assistNext;
                        } else{
                            prev.assistNext = cur.assistNext;
                        }

                        if (canFoldCount <= 0){
                            break;
                        }
                    }
                } else{
                    prev = cur;
                }

                cur = cur.assistNext;
            }

            if (newHead == null){
                foldableMap.remove(g.getId());

                if (emptyPosList.size() >= leastEmptyPosCount
                        && foldableMap.isEmpty()){
                    helper.setSuccess(); // 成功
                    return helper;
                }
            } else if (newHead != first){
                foldableMap.put(g.getId(), newHead);
            }
        }

        // 如果最少空格数都未达到，说明没有空位放入这些物品
        if (emptyPosList.size() < leastEmptyPosCount){
            // 空格不足
            foldableMap.clear();
            return helper; // 失败
        }

        int foldableNeedEmptyPosCount = 0;
        for (GoodsAddHelper result : foldableMap.values()){
            for (GoodsAddHelper cur = result; cur != null;){
                foldableNeedEmptyPosCount += cur.getNeedEmptyPosCount();
                cur = cur.assistNext;
            }
        }
        foldableMap.clear();

        if (emptyPosList.size() < leastEmptyPosCount
                + foldableNeedEmptyPosCount){
            // 空格不足
            return helper; // 失败
        }

        // 可以全部放入
        helper.setSuccess(); // 成功
        return helper;
    }

    /**
     * 检查该物品能否放入
     * 
     * @param g
     * @return 可以放入返回true，否则返回false
     */
    public boolean hasEnoughEmptyCount(int count){
        int needCount = count + reservedPosCount; // 需要预留一些格子
        for (int i = size; --i >= 0;){
            if (goodsList[i] == null){
                if (--needCount <= 0){
                    return true;
                }
            }
        }

        return false;
    }

    public GoodsTryReduceResult canReduceGoods(int goodsID, int count,
            long ctime){
        GoodsTryReduceResult result = GoodsTryReduceResult.current();
        result.clear();

        if (count <= 0){
            logger.error("GoodsContainer.canReduceGoods传进来的count<=0: {}. {}",
                    count, Utils.getStackTrace());
            return result;
        }

        IntArrayList posCountList = result.getPosCountList();

        int gotCount = 0;
        for (int i = 0; i < size; i++){
            if (isLocked(i)){
                continue;
            }

            Goods g = goodsList[i];
            if (g != null && g.getId() == goodsID && !g.isExpired(ctime)){

                int c = Math.min(count - gotCount, g.getCount());

                posCountList.add(i);
                posCountList.add(c);

                gotCount += c;
                if (gotCount >= count){
                    result.setSuccess();
                    return result;
                }
            }
        }

        return result;
    }

    /**
     * 如果空位有count个，则返回count，如果空格数不足count个，有多少个返回多少个
     */
    public int getEmptyCount(int count){
        int needCount = count + reservedPosCount; // 需要预留一些格子

        for (int i = size; --i >= 0;){
            if (goodsList[i] == null){
                if (--needCount <= 0){
                    return count;
                }
            }
        }

        return count + reservedPosCount - needCount;
    }

    public boolean hasReservedPos(){
        return reservedPosCount > 0;
    }

    protected void clearReserveCount(){
        reservedPosCount = 0;
    }

    public boolean reserveIfHasEnoughEmptyCount(int toReserve){
        assert reservedPosCount == 0;
        if (hasEnoughEmptyCount(toReserve)){
            reservedPosCount = toReserve;
            return true;
        }
        return false;
    }

    /**
     * 添加物品，找个位置空位置放进去
     * 
     * @param g
     * @return 成功放入返回插入位置，否则返回-1
     */
    public int addToEmptyPos(Goods g){
        return addToEmptyPos(0, g);
    }

    public int addToEmptyPos(int startIdx, Goods g){
        assert g.getCount() <= g.getData().getMaxCount();

        for (int i = startIdx; i < size; i++){
            if (goodsList[i] == null){
                goodsList[i] = g;
                return i;
            }
        }

        return -1;
    }

    /**
     * 添加物品到位置pos上
     * 
     * @param g
     * @return 成功放入返回true，否则返回false
     */
    public boolean putIfAbsent(int pos, Goods g){
        assert !isInvalidPos(pos);
        assert g.getCount() <= g.getData().getMaxCount();

        if (goodsList[pos] == null){
            goodsList[pos] = g;
            return true;
        }

        return false;
    }

    /**
     * 将物品放到个空格, 起始寻找的pos(包含)是传进去的. 返回物品实际放入的点.
     * 
     * 返回-1表示在pos之后没有空格
     * 
     * @param pos
     * @param g
     * @return
     */
    public int addToEmptyPosStartWithPos(int pos, Goods g){
        for (int i = pos; i < size; i++){
            if (goodsList[i] == null){
                goodsList[i] = g;
                return i;
            }
        }
        return -1;
    }

    /**
     * 扩容
     * 
     * @param toAdd
     * @return
     */
    public void unlockSlot(GoodsContainerUnlockData unlockData, long currentTime){
        assert unlockData != null;

        setUnlockData(unlockData, currentTime, 0);
    }

    public int size(){
        return size;
    }

    /**
     * 检查pos是否是非法位置
     * 
     * @param pos
     * @return
     */
    public boolean isInvalidPos(int pos){
        return pos < 0 || pos >= size;
    }

    public boolean isInvalidUnlockPos(int pos){
        return pos < size || pos >= goodsList.length;
    }

    /**
     * 检测bug用, 是否有物品的count非法
     * @return
     */
    public boolean hasIllegalGoodsCount(){
        Goods g;
        for (int i = 0; i < size; i++){
            g = goodsList[i];
            if (g != null){
                if (g.getCount() <= 0
                        || g.getCount() > g.getData().getMaxCount()){
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * 检测bug用, 是否有物品在未开启的格子里
     * @return
     */
    public boolean hasGoodsInIllegalPos(){
        for (int i = size; i < goodsList.length; i++){
            if (goodsList[i] != null){
                return true;
            }
        }

        return false;
    }

    /**
     * 获取pos位置上的物品
     * 
     * @param pos
     * @return
     */
    public Goods get(int pos){
        assert !isInvalidPos(pos);

        if (isLocked(pos)){
            throw new RuntimeException(
                    "GoodsContainer.get物品时, 这个物品已经被lock, 是不是忘记检查了?");
        }
        return goodsList[pos];
    }

    /**
     * 获取pos位置上的物品
     * 
     * @param pos
     * @return
     */
    public Goods set(int pos, Goods goods){
        assert !isInvalidPos(pos);

        if (isLocked(pos)){
            throw new RuntimeException(
                    "GoodsContainer.set物品时, 这个物品已经被lock, 是不是忘记检查了?");
        }

        Goods g = goodsList[pos];
        goodsList[pos] = goods;
        return g;
    }

    /**
     * 移除pos位置上面的物品
     * 
     * @param pos
     * @return
     */
    public Goods remove(int pos){
        assert !isInvalidPos(pos);

        if (isLocked(pos)){
            throw new RuntimeException(
                    "GoodsContainer.remove物品时, 这个物品已经被lock, 是不是忘记检查了?");
        }
        Goods g = goodsList[pos];
        goodsList[pos] = null;
        return g;
    }

    /**
     * 这里只能只读的操作获取到的Array，否则，我就要发飙了
     * @return
     */
    public Goods[] getGoodsArray(){
        return Arrays.copyOf(goodsList, size);
    }

    public GoodsContainerProto encode4Client(){
        GoodsContainerProto.Builder builder = GoodsContainerProto.newBuilder();
        builder.setSize(size).setInitCount(initSize)
                .setAccStartTime(accStartTime);

        for (int i = 0; i < size; i++){
            Goods g = goodsList[i];

            if (g != null){
                builder.addPosList(i)
                        .addGoodsDataList(g.getData().getProtoByteString())
                        .addGoodsList(g.encodeByteString4Client());
            }
        }

        GoodsContainerUnlockData unlockingData = getUnlockingData();
        if (unlockingData != null){
            GoodsContainerUnlockData[] rowUnlockDatas = unlockingData.rowUnlockDatas;
            for (int i = 0; i < rowUnlockDatas.length; i++){
                builder.addUnlockDatas(rowUnlockDatas[i].unlockDataProto);
            }
        }

        GoodsContainerUnlockData unlockedData = getUnlockedData();
        if (unlockedData != null){
            builder.setAccStat(unlockedData.accStatProto);
        }

        return builder.build();
    }

    public GoodsContainerServerProto encodeWithoutGoods(long ctime){
        GoodsContainerServerProto.Builder builder = GoodsContainerServerProto
                .newBuilder();
        builder.setType(type).setOpenSlotCount(unlockData.openSlotCount);

        if (unlockData.nextLevel != null)
            builder.setAccOpenTime(ctime - accStartTime);

        return builder.build();
    }

    GoodsListProto encodeGoodsList(){
        GoodsListProto.Builder builder = GoodsListProto.newBuilder();

        for (int i = 0; i < size; i++){
            Goods g = goodsList[i];

            if (g != null){
                builder.addPosList(i);
                builder.addGoodsList(g.encode());
            }
        }

        return builder.build();
    }

    protected void decodeGoodsList(GoodsListProto proto, ConfigService cs,
            IntValueLongHashMap goodsCountMap){
        assert size >= proto.getGoodsListCount(): "decodeGoodsList时，发现size比物品的个数小";

        if (proto.getPosListCount() == proto.getGoodsListCount()
                && proto.getGoodsListCount() <= size){

            int findEmptyPosStartIndex = 0;
            for (int i = 0; i < proto.getGoodsListCount(); i++){
                GoodsServerProto goodsProto = proto.getGoodsList(i);
                Goods g = Goods.decode(goodsProto, cs, goodsCountMap);
                if (g == null)
                    continue;

                int pos = proto.getPosList(i);
                if (isInvalidPos(pos) || goodsList[pos] != null){
                    System.err
                            .println("decode GoodsContainer, Duplicate pos, pos: "
                                    + pos);

                    // 找个空位放进去
                    int idx = addToEmptyPos(findEmptyPosStartIndex, g);
                    if (idx >= 0){
                        findEmptyPosStartIndex = idx + 1;
                    } else{
                        // 找不到了...
                        findEmptyPosStartIndex = size + 1;
                    }
                    continue;
                }

                goodsList[pos] = g;
            }
        } else{
            // 防御性
            System.err
                    .println("decode GoodsContainer, PosListCount != GoodsListCount");

            // 不管位置了，从第一格开始将GoodsList放进列表，位置不够就发邮件
            for (int i = 0; i < proto.getGoodsListCount(); i++){
                GoodsServerProto goodsProto = proto.getGoodsList(i);
                Goods g = Goods.decode(goodsProto, cs, goodsCountMap);
                if (g == null)
                    continue;

                goodsList[i] = g;
            }
        }
    }
}
