package app.game.entity;

public class HeroBinaryData{

    public final long id;

    public final int easyInfo;

    public final byte[] heroData;

    public final byte[] heroMinorData;

    public final long userInfo;

    HeroBinaryData(long id, int easyInfo, byte[] heroData,
            byte[] heroMinorData, long userInfo){
        this.id = id;
        this.easyInfo = easyInfo;
        this.heroData = heroData;
        this.heroMinorData = heroMinorData;
        this.userInfo = userInfo;
    }

}
