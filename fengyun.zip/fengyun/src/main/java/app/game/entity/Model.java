package app.game.entity;

import app.game.service.TimeService;

/**
 * 英雄换装
 * @author Liwei
 *
 */
public class Model{

    private final TimeService timeService;

    /**
     * 换装，4个bit表示一种换装，每个部位的换装最多16种，0-15, 0表示没有该部位的换装,
     * 顺序从低位开始，前4位表示衣服换装，依次为 衣服，武器，坐骑，弓箭，神兵，神兵特效
     */
    private int resource;

    // 包含最高级马和弓箭
    private int resourceWithBestMountBow;

    // 城主结束时间，特殊换装
    private long cityMasterEndTime;

    private static final int MASTER_MASK = 1 << 24;

    // 龙城城主结束时间，特殊换装
    private long longCityMasterEndTime;

    private static final int LONG_CITY_MASTER_MASK = 1 << 25;

    private boolean hasShenLong;

    private static final int SHEN_LONG_MASK = 1 << 26;

    public Model(TimeService timeService){
        this.timeService = timeService;
    }

    public void setCityMasterEndTime(long time){
        cityMasterEndTime = time;
    }

    public long getCityMasterEndTime(){
        return cityMasterEndTime;
    }

    public void setLongCityMasterEndTime(long time, boolean hasShenLong){
        longCityMasterEndTime = time;
        this.hasShenLong = hasShenLong;
    }

    public boolean hasShenLong(){
        return hasShenLong;
    }

    public long getLongCityMasterEndTime(){
        return longCityMasterEndTime;
    }

    public int getOriginalResourceWithBestMountBow(){
        return resourceWithBestMountBow;
    }

    public void setOriginalResourceWithBestMountBow(int resource){
        resourceWithBestMountBow = resource;
    }

    public int getResource(){

        if (cityMasterEndTime > 0 || longCityMasterEndTime > 0){
            long ctime = timeService.getCurrentTime();

            int res = resource;
            if (ctime < cityMasterEndTime){
                res |= MASTER_MASK;
            }

            if (ctime < longCityMasterEndTime){
                res |= LONG_CITY_MASTER_MASK;
                if (hasShenLong)
                    res |= SHEN_LONG_MASK;
            }

            return res;
        }

        return resource;
    }

    public void setCurrentResourceOnly(int resource){
        this.resource = resource;
    }

    public boolean hasMount(){
        return (resource & 0xf00) != 0;
    }

    public int getResourceWithBestMountBow(){

        if (cityMasterEndTime > 0 || longCityMasterEndTime > 0){
            long ctime = timeService.getCurrentTime();

            int res = resourceWithBestMountBow;
            if (ctime < cityMasterEndTime){
                res |= MASTER_MASK;
            }

            if (ctime < longCityMasterEndTime){
                res |= LONG_CITY_MASTER_MASK;
                if (hasShenLong)
                    res |= SHEN_LONG_MASK;
            }

            return res;
        }

        return resourceWithBestMountBow;
    }

    public void replaceResource(ModelType type, int res){
        resource = calculateResources(type, resource, res);

        if (type != ModelType.MOUNT && type != ModelType.BOW){
            resourceWithBestMountBow = calculateResources(type,
                    resourceWithBestMountBow, res);
        }
    }

    public void onBestMountChanged(int bestMount){
        resourceWithBestMountBow = calculateResources(ModelType.MOUNT,
                resourceWithBestMountBow, bestMount);
    }

    public void onBestBowChanged(int bestBow){
        resourceWithBestMountBow = calculateResources(ModelType.BOW,
                resourceWithBestMountBow, bestBow);
    }

    public enum ModelType{
        ARMOR, WEAPON, MOUNT, SUPER_WEAPON, BOW;
    }

    int calculateResources(ModelType type, int source, int toReplace){

        assert toReplace >= 0 && toReplace < 16;

        switch (type){
            case ARMOR:{
                return (source & 0xfffffff0) | toReplace;
            }
            case WEAPON:{
                return (source & 0xffffff0f) | (toReplace << 4);
            }
            case MOUNT:{
                return (source & 0xfffff0ff) | (toReplace << 8);
            }
            case SUPER_WEAPON:{
                return (source & 0xffff0fff) | (toReplace << 12);
            }
            // 16-20
            case BOW:{
                return (source & 0xff0fffff) | (toReplace << 20);
            }
        }

        return source;
    }

}
