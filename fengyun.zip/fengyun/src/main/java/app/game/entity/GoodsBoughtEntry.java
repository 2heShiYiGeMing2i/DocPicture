package app.game.entity;

public class GoodsBoughtEntry{

    public final int id;
    
    public int count;
    
    public GoodsBoughtEntry(int id, int count){
        this.id = id;
        this.count = count;
    }
}
