package app.game.entity;

import java.util.ArrayDeque;
import java.util.Collection;
import java.util.Deque;
import java.util.LinkedList;
import java.util.List;

import org.jboss.netty.buffer.ChannelBuffer;
import org.joda.time.DateTimeConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.data.ConfigService;
import app.game.data.HeroLevelData;
import app.game.data.Race;
import app.game.data.SingleSpriteStat;
import app.game.data.SpriteStat;
import app.game.data.SpriteStatBuilder;
import app.game.data.Vip;
import app.game.data.Vips;
import app.game.data.bow.HeroBow;
import app.game.data.gem.HeroGem;
import app.game.data.goods.CritCardData;
import app.game.data.goods.CritCardData.CritCardBuff;
import app.game.data.goods.Equipment;
import app.game.data.goods.EquipmentExtraStat;
import app.game.data.goods.EquipmentExtraStats;
import app.game.data.goods.GemGoodsData;
import app.game.data.goods.Goods;
import app.game.data.goods.GoodsContainerUnlockData;
import app.game.data.goods.GoodsData;
import app.game.data.goods.GoodsDataCount;
import app.game.data.goods.MedicineData.StatEfficacy;
import app.game.data.goods.TaozData;
import app.game.data.mount.HeroMount;
import app.game.data.pet.HeroPet;
import app.game.data.pet.HeroTianJie;
import app.game.data.pet.HeroTianZui;
import app.game.data.scene.DefenceBatchInfo;
import app.game.data.scene.DefenceCollectablePrize;
import app.game.data.scene.DefenceCollectablePrize.DefenceCollectablePrizeWithExpireTime;
import app.game.data.scene.DefenceDungeonSceneData;
import app.game.data.scene.GroupDungeonsWithPrizeConfig;
import app.game.data.scene.SceneDatas;
import app.game.data.scene.StoryDungeonSceneData;
import app.game.data.scene.StoryDungeonSceneDatas;
import app.game.data.spell.PassiveSpell;
import app.game.data.task.HeroTaskList;
import app.game.data.weapon7.HeroSuperWeapon;
import app.game.data.weapon7.SuperWeaponData;
import app.game.entity.Model.ModelType;
import app.game.entity.record.goods.GoodsOwnership;
import app.game.module.guild.Guild;
import app.game.module.guild.GuildMember;
import app.game.module.scene.AbstractHeroFightModule.PkMode;
import app.game.module.scene.FightData;
import app.game.service.Services;
import app.game.service.WorldService;
import app.game.shop.BuyBackGoods;
import app.protobuf.DungeonContent.GroupDungeonCollectablePrizeProto;
import app.protobuf.GoodsOwnershipContent.GoodsOwnershipProto;
import app.protobuf.GoodsServerContent.GoodsServerProto;
import app.protobuf.GoodsServerContent.Quality;
import app.protobuf.HeroContent.FightingAmountProto;
import app.protobuf.HeroContent.HeroProto;
import app.protobuf.HeroContent.OtherHeroProto;
import app.protobuf.HeroContent.SingleRelation;
import app.protobuf.HeroContent.StoryDungeonCollectablePrizeProto;
import app.protobuf.HeroServerContent.HeroMinorProto;
import app.protobuf.HeroServerContent.HeroServerProto;
import app.protobuf.HeroServerContent.RechargeRebateServerProto;
import app.protobuf.HeroServerContent.UpgradePromotionServerProto;
import app.protobuf.TaskContent.ClientFunction;
import app.protobuf.TaskContent.TaskRelatedFunction;
import app.protobuf.TerritoryContent.HeroInfoProto;
import app.utils.IDUtils;
import app.utils.Operators;
import app.utils.VariableConfig;

import com.google.common.annotations.VisibleForTesting;
import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;
import com.mokylin.collection.IntArrayList;
import com.mokylin.collection.IntHashMap;
import com.mokylin.collection.IntValueIntHashMap;
import com.mokylin.collection.IntValueIntHashMap.Entry;
import com.mokylin.collection.IntValueLongHashMap;
import com.mokylin.collection.LongArrayList;
import com.mokylin.collection.LongHashMap;
import com.mokylin.collection.LongHashSet;
import com.mokylin.collection.LongValueIntHashMap;
import com.mokylin.collection.ReusableIterator;
import com.mokylin.coupon.protobuf.CouponContent.CouponType;
import com.mokylin.sink.util.BufferUtil;
import com.mokylin.sink.util.StringEncoder;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.annotation.MultiThread;
import com.mokylin.sink.util.annotation.SelfThreadOnly;
import com.mokylin.sink.util.annotation.SelfWriteMultiThreadRead;
import com.mokylin.sink.util.holder.IntLongHolder;
import com.mokylin.sink.util.holder.LongLongHolder;
import com.mokylin.sink.util.holder.ObjectHolder;

public class Hero{

    private static final Logger logger = LoggerFactory.getLogger(Hero.class);

    /*
     * 英雄id是个long
     *
     * 8 bit 运营商id 256 - 1
     *
     * 13 bit 英雄所在服务器id, 最大8192 - 1
     *
     * 32 bit user的id
     *
     * 总共53位. flash最多可以处理53位
     */
    private final long id;
    private final int userId;
    private final int serverId;
    private final int operatorId;

    // 平台唯一标示
    private final String uin;

    private final byte[] nameBytes;
    private final String name;
    private final ByteString nameByteString;

    /**
     * 技能列表
     */
    private final SpellList spellList;

    /**
     * 职业
     */
    private final Race race;

    /**
     * 英雄创建时间
     */
    private final long createTime;

    // --- 各种活动 ---

    private RechargeRebateServerProto rechargeRebateServerProto;
    private UpgradePromotionServerProto upgradePromotionServerProto;

    /**
     * 已领取的开服排行榜普及奖
     *
     * 保存领过奖的活动的结束时间
     */
    private final LongArrayList collectedRankPromotionPrize;

    // ---

    /**
     * 是否完成新手剧情，true表示完成了
     */
    private boolean isCrossSingleStory;

    /**
     * 上一次离线时间. 如果是0, 表示是个新建的英雄
     */
    private long lastReadPrivateMessageTime;
    public transient boolean hasEnterSceneForTheFirstTime;

    /**
     * 真气
     */
    int realAir;

    /* -- HeroFightModule 内容 -- */
    private final FightData fightData;

    // 坐骑

    // 装备
    @SelfWriteMultiThreadRead
    private final Equipment[] equipmentList;

    private final IntHashMap<SpriteStat> taozStatMap;

    // 全身+10装备额外属性
    private EquipmentExtraStat equipmentExtraStat;

    private final Model model;

    // 背包
    private Depot depot;

    // 仓库
    private Storage storage;

    private final GoodsOwnership goodsOwnership;

    private boolean isTeamAutoAcceptInvite;

    private boolean isTeamAutoAcceptRequest;

    private boolean isForbidOtherInviteMeJoinTeam;

    private boolean isTradeAutoReject;

    private boolean isGuildAutoAccept;

    private boolean isForbidOtherInviteMeJoinGuild;

    private long tradeNextCanGetExpTime;

    private long auctionNextCanGetExpTime;

    private int firstRechargeCurrentIndex;

    private int firstRechargeCollectIndex;

    public int getFirstRechargeCurrentIndex(){
        return firstRechargeCurrentIndex;
    }

    @MultiThread
    public void setFirstRechargeCurrentIndex(int idx){
        firstRechargeCurrentIndex = idx;
    }

    public int getFirstRechargeCollectIndex(){
        return firstRechargeCollectIndex;
    }

    public boolean hasRechargePrize(){
        return firstRechargeCollectIndex < firstRechargeCurrentIndex;
    }

    public boolean tryAddCollectRechargePrize(){
        if (firstRechargeCollectIndex < firstRechargeCurrentIndex){
            ++firstRechargeCollectIndex;
            return true;
        }

        return false;
    }

    /**
     * 是否充值过
     */
    private boolean hasRecharged;

    // 总累计充值元宝
    private int totalRechargeYuanbao;

    private int bindedYuanbao;

    private int yuanbao;

    private int lijin;

    private int money;

    public long exp;

    /**
     * 帮派历练
     */
    public int guildLilian;

    private int clientOnlyConfig1;
    private int[] clientOnlyIntConfigs;

    private long strongSpeechLimitEndTime;

    private long autoSpeechEndTime;

    private long lastBeenAddBlackTime;
    private int beenAddBlackCount;

    private HeroLevelData levelData;

    private int levelUpdateTime;

    private long lastLogoutTime;

    private long lastResetDailyTime;

    private long lastResetMonthlyTime;

    /**
     * 每日累计在线时间
     */
    private long dailyOnlineAccTime;

    /**
     * 本次在线开始时间
     */
    private long dailyOnlineStartTime;

    /**
     * 英雄登陆时间
     */
    private long loginTime;

    private long totalOnlineAccTime;

    private long accumulatedOfflineTime;

    /**
     * 上次加离线时间的时间, 防bug而存在
     */
    private long lastAddAccumulatedOfflineTime;

    // --- 防沉迷 ---
    private long accumulatedOnlineTime;

    private FangChenMi fangChenMi;

    private boolean needFangChenMi;

    /**
     * 任务列表
     */
    private HeroTaskList taskList;

    /**
     * 回购物品列表
     */
    private final List<BuyBackGoods> buyBackGoodsList;

    private final LongValueIntHashMap goodsCoolDownMap;

    private final LongValueIntHashMap goodsTypeCoolDownMap;

    private final Divination divination;

    /**
     * 战斗值，当涉及到战斗值变化时，重新计算一遍
     */
    private int fightingAmount;

    private PkMode pkMode;

    /**
     * pk值
     */
    private int pkAmount;

    /**
     * 下次减少pk值的时间
     */
    private transient long nextReducePkAmountTime;

    /**
     * 减少pk值累计时间
     */
    private long pkAmountAccTime;

    /**
     * 复活保护结束时间
     */
    private long reliveProtectedEndTime;

    /**
     * 好友/仇人/黑名单/最近联系人. 各种
     */
    private final RelationList relationList;
    private final SingleRelation.Builder singleRelationBuilder;
    private final ObjectHolder<SingleRelation> singleRelationHolder;

    // ---- ViewOtherHeroModule 使用的字段 -----
    public transient long nextViewOtherHeroMsgCacheExpireTime;
    public transient ChannelBuffer msgAsViewOtherHero;

    // -----------------------------------------
    public transient boolean hasRequestedRelation;

    // --- 帮派 ---
    /**
     *  上线时, 如果有帮派就设置, 用来encode到HeroProto. 除此之外没有用. 都会是null
     */
    private transient GuildMember guildMember;

    /**
     * 坐骑
     */
    private HeroMount mount;

    // --- vip ---

    private int vipExp;
    private Vip vip;

    private int collectedVipPrize; // 已经领取的Vip等级礼包奖励
    private long nextCollectVipWeeklyPrizeTime; // 下次可以领取的Vip周礼包

    /**
     * 今日已完成的vip副本id
     */
    private final IntArrayList todayFinishedVipDungeonIDList;

    // --- 副本 ---

    // 进副本之前的场景/坐标
    private int beforeDungeonSceneID;
    private int beforeDungeonX;
    private int beforeDungeonY;

    /**
     * 下线时, 如果是在个跨服场景, 则保存
     */
    private int clusterSceneUUID;

    private final IntHashMap<StoryDungeonStat> storyDungeonStat;
    private final ReusableIterator<StoryDungeonStat> storyDungeonStatIte;

    private final List<StoryDungeonCollectablePrizeProto> storyDungeonCollectablePrize;

    // 自动扫荡
    private int autoFinishStoryID;
    private long autoFinishStoryCompleteTime;

    /**
     * 是否正在一键自动扫荡
     */
    private boolean isAutoFinishAllStory;

    // --- 挑战侠士 ---

    private int finishedChallengeDungeonSequence;

    private int challengeDungeonDailyTimes;

    private int challengeDungeonAssistTimes;

    private final IntArrayList challengeDungeonUseTime;

    // 福利
    private final Welfare welfare;

    /**
     * 有使用次数限制的物品
     */
    private final IntHashMap<GoodsDataCount> useLimitCountGoodsMap;

    // 神兵
    private final HeroSuperWeapon[] superWeapons;

    private SuperWeaponData usingWeapon;

    // --- 守护孔慈 ---

    private int defenceTodayFinishedBatch;
    private int defenceHistoryMaxBatch;
    private int defenceTodayResetCount;
    private int defenceCollectedFirstPassPrize;
    private final List<DefenceCollectablePrizeWithExpireTime> defenceCollectablePrize;

    /**
     * 扫荡完, 等待着别人领取. 防止未领就下线
     */
    private DefenceCollectablePrize defenceAutoFinishPrizeWaitingToBeCollected;

    // --- 搜神宫 ---
    private int souShenPoint;
    private final IntArrayList souShenTodayPassedSceneID;
    private final IntArrayList souShenLifePassedSceneID;

    /**
     * 今日已使用的搜神点数
     */
    private int souShenPointTodayUsedAmount;

    private final IntHashMap<GoodsBoughtEntry> souShenGoodsTodayBoughtCount;

    private final IntHashMap<GoodsBoughtEntry> exchangeGoodsTodayBoughtCount;

    // --- 凌云窟 ---

    private int lingYunTodayFinishedTimes;

    // --- 组队副本通用可领取奖励 ---
    private final List<GroupDungeonCollectablePrizeProto> groupDungeonCollectablePrize;

    // --- 守护龙脉 ---

    /**
     * 守护龙脉今日是否已通关
     */
    private boolean longMaiTodayFirstPassed;

    // --- 无绝神阵 ---
    private int wuJueTodayEnteredTimes;

    // --- 火麟洞 ---

    private long huoLinCombatServerID;
    private int huoLinSceneDataID;
    private int huoLinSceneUUID;
    private long huoLinActivityEndTime;
    private int huoLinLine;
    private int huoLinAccumulatedExp;
    private int huoLinAccumulatedRealAir;

    // --- 板块战 ---

    private final IntArrayList territoryTodayCollectedPrizeSceneID;

    private final BattleHeroInfo territoryHeroInfo;

    // --- 帮派战 ---

    private final BattleHeroInfo guildCityHeroInfo;

    // --- 龙城争夺战 ---
    private final BattleHeroInfo longCityHeroInfo;

    // 新功能开放
    private long taskFuncBitData;

    private int clientFuncBitData;

    private final LongHashSet admiredHeros;

    // 弓箭
    private HeroBow bow;

    // 宝石
    private HeroGem gem;

    // 登录器
    private boolean isCollectLocalLoginFirstPrize;

    private boolean isCollectLocalLoginDailyPrize;

    private int useFreeChatTimes;

    // 祭剑版本
    private long jijianEndTime;

    private int jijianSceneId;

    public int jijianAccExp;
    public int jijianAccRealAir;
    public int jijianMoneyTimes;
    public int jijianYuanbaoTimes;
    public int jijianYuanbaoTotalTimes;
    public long jijianUpdateTime;

    public int jijianAccFreeloadRealAir;

    // 宠物
    private HeroPet pet;

    private HeroTianJie tianjie;

    private HeroTianZui tianzui;

    // 荣誉值
    private int honorPoint;

    // 熔炼值
    public int meltAmount;

    // 声望
    private int shengWang;

    private int shengWangExchangeBits;

    private final IntValueIntHashMap shengwangMap;

    // 花钱完成活动
    private final IntValueIntHashMap dailyActivityBuybackMap;

    private long oneTimesCouponCollected;

    private int unlimitedCouponCollectedTimes;

    private final IntHashMap<IntLongHolder> expTypeMap;

    public long todayLoginTime;

    private final LongValueIntHashMap globalMail;

    // 已投资升级钱庄的元宝
    private int investUpgradeBankMoney;

    private final IntValueIntHashMap collectUpgradeBankMap;

    // 月卡钱庄
    private int investMonthlyBankMoney;

    private long investMonthlyBankTime;

    private long monthlyBankPrevCollectTime;

    private long monthlyBankPrevCollectTime2;

    private int monthlyBankPrevDayOnlineLijin;

    private int monthlyBankOnlineLijin;

    private int monthlyBankOnlineHours;

    private final Deque<Long> bankLogs;

    private final IntValueIntHashMap singlePVipPrizeMap;
    private final IntValueIntHashMap dailyPVipPrizeMap;

    private boolean hasCollectedPlatformEverydayPrize;

    private boolean hasFinishedPhoneCheck;

    private final IntHashMap<CritCardBuff> critCardBuffMap;

    public boolean canSeeShowGirl;

    private int collectedPlatformPrize;

    public boolean isGm;

    private final LongHashMap<LongLongHolder> chatOtherMap;

    private final ReusableIterator<LongLongHolder> chatOtherIter;

    private String lastSceneChatMsg;

    private int sceneChatRepeatTimes;

    private Hero(long id, byte[] heroName, Race race, FightData fightData,
            SpellList spellList, HeroLevelData levelData,
            RelationList relationList, long createTime,
            boolean withoutMinorData, String userName){
        this.id = id;
        this.userId = IDUtils.getUserID(id);
        this.serverId = IDUtils.getServerID(id);
        this.operatorId = IDUtils.getOperatorID(id);
        this.nameBytes = heroName;
        this.name = StringEncoder.encode(heroName);
        this.nameByteString = ByteString.copyFrom(heroName);
        this.createTime = createTime;
        this.fangChenMi = FangChenMi.NONE;

        uin = Operators.getUinString(operatorId, userId, userName);

        this.race = race;
        this.fightData = fightData;
        this.spellList = spellList;
        this.equipmentList = new Equipment[Equipment.HERO_EQUIPED_MAX_COUNT];
        taozStatMap = new IntHashMap<>(4);
        this.levelData = levelData;
        this.relationList = relationList;
        this.model = race.newModel();
        pkMode = PkMode.PEACE; // 默认为和平模式

        superWeapons = new HeroSuperWeapon[VariableConfig.SUPER_WEAPON_COUNT];
        useLimitCountGoodsMap = new IntHashMap<>();

        if (!withoutMinorData){
            // 要上线的英雄
            buyBackGoodsList = new LinkedList<>();
            divination = new Divination();
            goodsOwnership = new GoodsOwnership();

            goodsCoolDownMap = new LongValueIntHashMap();
            goodsTypeCoolDownMap = new LongValueIntHashMap();
            clientOnlyIntConfigs = new int[VariableConfig.CLIENT_INT_CONFIG_COUNT];
            storyDungeonStat = new IntHashMap<>(8);
            storyDungeonStatIte = storyDungeonStat.newValueIterator();
            storyDungeonCollectablePrize = new LinkedList<>();
            defenceCollectablePrize = new LinkedList<>();
            todayFinishedVipDungeonIDList = new IntArrayList(1);

            singleRelationBuilder = SingleRelation.newBuilder().setId(id)
                    .setName(nameByteString).setRace(race.getId())
                    .setLevel(fightData.getLevel());
            if (!relationList.isHideMyLocation()){
                singleRelationBuilder.setSceneId(fightData.getActualSceneID())
                        .setLineNumber(fightData.getSceneSequenceID());
            }
            ByteString bs = relationList.getMood();
            if (bs != null && !bs.isEmpty()){
                singleRelationBuilder.setMood(bs);
            }
            boolean forbidBeenAddedAsFriend = relationList
                    .isForbidBeenAddedAsFriend();
            singleRelationBuilder
                    .setForbidBeenAddedAsFriend(forbidBeenAddedAsFriend);

            singleRelationHolder = new ObjectHolder<SingleRelation>(
                    singleRelationBuilder.build());

            welfare = Welfare.newWelfare(race.lotteryCount);
            admiredHeros = new LongHashSet();
            souShenLifePassedSceneID = new IntArrayList();
            souShenTodayPassedSceneID = new IntArrayList();
            souShenGoodsTodayBoughtCount = new IntHashMap<>(4);

            groupDungeonCollectablePrize = new LinkedList<>();
            exchangeGoodsTodayBoughtCount = new IntHashMap<>(4);
            challengeDungeonUseTime = new IntArrayList(4);
            territoryTodayCollectedPrizeSceneID = new IntArrayList(1);
            territoryHeroInfo = new BattleHeroInfo(true);
            guildCityHeroInfo = new BattleHeroInfo(true);
            longCityHeroInfo = new BattleHeroInfo(false);
            shengwangMap = new IntValueIntHashMap();
            dailyActivityBuybackMap = new IntValueIntHashMap();
            expTypeMap = new IntHashMap<>();
            globalMail = new LongValueIntHashMap();
            collectUpgradeBankMap = new IntValueIntHashMap();
            singlePVipPrizeMap = new IntValueIntHashMap();
            dailyPVipPrizeMap = new IntValueIntHashMap();
            bankLogs = new ArrayDeque<>(128);
            critCardBuffMap = new IntHashMap<>();
            collectedRankPromotionPrize = new LongArrayList(2);
            chatOtherMap = new LongHashMap<>();
            chatOtherIter = chatOtherMap.newValueIterator();
        } else{
            // 给别人观察的英雄/或者是在跨服场景中, 不需要解析MinorProto
            buyBackGoodsList = null;
            divination = null;
            goodsOwnership = null;

            goodsCoolDownMap = null;
            goodsTypeCoolDownMap = null;
            clientOnlyIntConfigs = null;
            storyDungeonStat = null;
            storyDungeonStatIte = null;
            storyDungeonCollectablePrize = null;
            defenceCollectablePrize = null;
            todayFinishedVipDungeonIDList = null;

            singleRelationBuilder = null;
            singleRelationHolder = null;

            welfare = null;
            admiredHeros = null;
            souShenLifePassedSceneID = null;
            souShenTodayPassedSceneID = null;
            souShenGoodsTodayBoughtCount = null;

            groupDungeonCollectablePrize = null;
            exchangeGoodsTodayBoughtCount = null;
            challengeDungeonUseTime = null;
            territoryTodayCollectedPrizeSceneID = null;
            territoryHeroInfo = null;
            guildCityHeroInfo = null;
            longCityHeroInfo = null;
            shengwangMap = null;
            dailyActivityBuybackMap = null;
            expTypeMap = null;
            globalMail = null;
            collectUpgradeBankMap = null;
            singlePVipPrizeMap = null;
            dailyPVipPrizeMap = null;
            bankLogs = null;
            critCardBuffMap = null;
            collectedRankPromotionPrize = null;
            chatOtherMap = null;
            chatOtherIter = null;
        }
    }

    public void putCritCardBuff(CritCardBuff buff){
        critCardBuffMap.put(buff.getType(), buff);
    }

    public Collection<CritCardBuff> getCritCardBuffs(){
        return critCardBuffMap.values();
    }

    public void checkSceneChat(String msg, long ctime){
        if (msg.equalsIgnoreCase(lastSceneChatMsg)){
            if (++sceneChatRepeatTimes >= 5){
                // 这货是坏人，直接禁言8小时
                setSpeechLimitEndTime(Math.max(strongSpeechLimitEndTime, ctime
                        + VariableConfig.P2P_CHAT_BAN_TIME));
            }
        } else{
            lastSceneChatMsg = msg;
            sceneChatRepeatTimes = 0;
        }
    }

    public void checkPrivateChat(long other, long ctime, int maxCount){
        LongLongHolder holder = chatOtherMap.get(other);
        if (holder == null){
            chatOtherMap.put(other, new LongLongHolder(other, ctime));

            if (chatOtherMap.size() >= maxCount){
                for (chatOtherIter.rewind(); chatOtherIter.hasNext();){
                    holder = chatOtherIter.next();
                    if (ctime - holder.getValue() > VariableConfig.P2P_CHAT_BAN_CHECK_INTERVAL){
                        chatOtherIter.remove();
                    }
                }
                chatOtherIter.cleanUp();

                if (chatOtherMap.size() >= maxCount){
                    // 这货是坏人，直接禁言8小时
                    setSpeechLimitEndTime(Math.max(strongSpeechLimitEndTime,
                            ctime + VariableConfig.P2P_CHAT_BAN_TIME));
                    chatOtherMap.clear();
                }
            }
        } else{
            holder.setValue(ctime);
        }
    }

    public int randomBlessAmount(int type, long ctime){
        CritCardBuff buff = critCardBuffMap.get(type);
        if (buff == null){
            return 0;
        }

        return buff.randomBless(ctime);
    }

    public void addBankLog(int info, int time){
        bankLogs.addFirst(((long) info) << 32 | time);

        if (bankLogs.size() > VariableConfig.BANK_LOG_COUNT){
            bankLogs.removeLast();
        }
    }

    public Deque<Long> getBankLogs(){
        return bankLogs;
    }

    public int getPrevDayAccMonthlyBankLijin(){
        return monthlyBankPrevDayOnlineLijin;
    }

    public int getMonthlyBankOnlineLijin(){
        return monthlyBankOnlineLijin;
    }

    public boolean tryUpdateOnlineLijin(int onlineLijin){
        if (monthlyBankOnlineLijin != onlineLijin){
            monthlyBankOnlineLijin = onlineLijin;
            ++monthlyBankOnlineHours; // 每改一次，说明多累计了一个小时
            return true;
        }

        return false;
    }

    public int getMonthlyBankOnlineHours(){
        return monthlyBankOnlineHours;
    }

    public void tryInvestMonthlyBank(int money, long investTime,
            int baseAccLijin, int onlineLijin, int onlineHours){
        investMonthlyBankMoney = money;
        investMonthlyBankTime = investTime;
        monthlyBankPrevCollectTime = monthlyBankPrevCollectTime2 = 0;
        monthlyBankPrevDayOnlineLijin = baseAccLijin;
        monthlyBankOnlineLijin = onlineLijin;
        monthlyBankOnlineHours = onlineHours;
    }

    public int getInvestMonthlyBankMoney(){
        return investMonthlyBankMoney;
    }

    public long getInvestMonthlyBankTime(){
        return investMonthlyBankTime;
    }

    public long getMonthlyBankPrevCollectTime(){
        return monthlyBankPrevCollectTime;
    }

    public void collectMonthlyBankIncome(long ctime){
        monthlyBankPrevCollectTime2 = monthlyBankPrevCollectTime;
        monthlyBankPrevCollectTime = ctime;
    }

    public void onCollectMonthlyOnlineIncome(){
        investMonthlyBankMoney = 0;
        monthlyBankPrevDayOnlineLijin = 0;
        monthlyBankOnlineLijin = 0;
        monthlyBankOnlineHours = 0;
        investMonthlyBankTime = 0;
        monthlyBankPrevCollectTime = 0;
        monthlyBankPrevCollectTime2 = 0;
    }

    public int getInvestUpgradeBankMoney(){
        return investUpgradeBankMoney;
    }

    public int addInvestUpgradeBankMoney(int toAdd){
        investUpgradeBankMoney += toAdd;
        return investUpgradeBankMoney;
    }

    public int getCollectUpgradeBankMoney(int level){
        return Math.max(collectUpgradeBankMap.get(level), 0);
    }

    public void setCollectUpgradeBankMoney(int level, int amount){
        collectUpgradeBankMap.put(level, amount);
    }

    public boolean isCollectedGlobalMail(int mail){
        return globalMail.containsKey(mail);
    }

    public void collectedGlobalMail(int mail, long sendTime){
        globalMail.put(mail, sendTime);
    }

    public int getBindedYuanbao(){
        return bindedYuanbao;
    }

    public void setBindedYuanbao(int b){
        bindedYuanbao = b;
    }

    public void addExpLog(int key, long toAdd){
        IntLongHolder holder = expTypeMap.get(key);
        if (holder == null){
            expTypeMap.put(key, new IntLongHolder(key, toAdd));
        } else{
            holder.add(toAdd);
        }
    }

    public IntHashMap<IntLongHolder> getExpTypeMap(){
        return expTypeMap;
    }

    public boolean isCollectCoupon(CouponType type){
        return (oneTimesCouponCollected & (1L << (type.getNumber() - 1))) != 0;
    }

    public boolean tryCollectCoupon(CouponType type){

        long newResult = doCollectCoupon(type, oneTimesCouponCollected);
        if (oneTimesCouponCollected != newResult){
            oneTimesCouponCollected = newResult;
            return true;
        }
        return false;
    }

    public static long doCollectCoupon(CouponType type, long result){
        return result | (1L << (type.getNumber() - 1));
    }

    public int getUnlimitedCouponCollectedTimes(){
        return unlimitedCouponCollectedTimes;
    }

    public int incrementUnlimitedCouponCollectedTimes(){
        return ++unlimitedCouponCollectedTimes;
    }

    public boolean isCollectPlatformPrize(int index){
        if (index > 0 && index <= 32){
            return (collectedPlatformPrize & (1 << (index - 1))) != 0;
        }

        return true;
    }

    public boolean tryCollectPlatformPrize(int index){
        if (!isCollectPlatformPrize(index)){
            collectedPlatformPrize = collectedPlatformPrize
                    | (1 << (index - 1));
            return true;
        }

        return false;
    }

    public boolean isCrossSingleStory(){
        return isCrossSingleStory;
    }

    public void setCrossSingleStory(){
        isCrossSingleStory = true;
    }

    public boolean isJoinDailyActivity(int key){
        return dailyActivityBuybackMap.get(key) >= 0;
    }

    public boolean isBuyDailyActivity(int key){
        return dailyActivityBuybackMap.get(key) > 0;
    }

    public int setDailyActivity(int key, int result){
        return dailyActivityBuybackMap.putIfAbsent(key, result);
    }

    public void tryResetJijian(int sceneId, long endTime){
        if (jijianEndTime != endTime){
            jijianEndTime = endTime; // 更新版本

            // 重置数据
            jijianAccExp = 0;
            jijianAccRealAir = 0;
            jijianMoneyTimes = 0;
            jijianYuanbaoTimes = 0;
            jijianAccFreeloadRealAir = 0;
        }
        jijianSceneId = sceneId;
    }

    public int getJijianId(){
        return jijianSceneId;
    }

    public long getJijianEndTime(){
        return jijianEndTime;
    }

    public void setFangChenMi(boolean isActivated){
        if (isActivated){
            this.needFangChenMi = true;
            updateFangChenMi();
        } else{
            this.needFangChenMi = false;
            this.fangChenMi = FangChenMi.NONE;
        }
    }

    /**
     * 根据在线时间更新防沉迷等级
     */
    public void updateFangChenMi(){
        if (accumulatedOnlineTime < VariableConfig.FANG_CHEN_MI_HALF_INCOME_TIME){
            this.fangChenMi = FangChenMi.NONE;
        } else if (accumulatedOnlineTime < VariableConfig.FANG_CHEN_MI_ZERO_INCOME_TIME){
            this.fangChenMi = FangChenMi.WEAK;
        } else{
            this.fangChenMi = FangChenMi.STRONG;
        }
    }

    private int phoenixMoneyRefineTimes;

    private int phoenixLijinRefineTimes;

    private int phoenixYuanbaoRefineTimes;

    public int getPhoenixMoneyRefineTimes(){
        return phoenixMoneyRefineTimes;
    }

    public int incrementPhoenixMoneyRefineTimes(){
        return ++phoenixMoneyRefineTimes;
    }

    public int getPhoenixLijinRefineTimes(){
        return phoenixLijinRefineTimes;
    }

    public int incrementPhoenixLijinRefineTimes(){
        return ++phoenixLijinRefineTimes;
    }

    public int getPhoenixYuanbaoRefineTimes(){
        return phoenixYuanbaoRefineTimes;
    }

    public int incrementPhoenixYuanbaoRefineTimes(){
        return ++phoenixYuanbaoRefineTimes;
    }

    public boolean tryFreeChat(){
        if (vip == null){
            return false;
        }

        if (useFreeChatTimes >= vip.getFreeChatTimes()){
            return false;
        }

        useFreeChatTimes++;

        return true;
    }

    public boolean isCollectLocalLoginFirstPrize(){
        return isCollectLocalLoginFirstPrize;
    }

    public void collectLocalLoginFirstPrize(){
        isCollectLocalLoginFirstPrize = true;
        isCollectLocalLoginDailyPrize = true;
    }

    public boolean isCollectLocalLoginDailyPrize(){
        return isCollectLocalLoginDailyPrize;
    }

    public void collectLocalLoginDailyPrize(){
        isCollectLocalLoginDailyPrize = true;
    }

    public boolean isHasCollectedPlatformEverydayPrize(){
        return hasCollectedPlatformEverydayPrize;
    }

    public void setHasCollectedPlatformEverydayPrize(
            boolean hasCollectedPlatformspeedPrize){
        this.hasCollectedPlatformEverydayPrize = hasCollectedPlatformspeedPrize;
    }

    public long getCreateTime(){
        return createTime;
    }

    public float getFangChenMiMultiple(){
        return fangChenMi.getMultiple();
    }

    public int getAdmiredHeroTimes(){
        return admiredHeros.size();
    }

    public boolean addAdmiredHero(long targetHero){
        return admiredHeros.add(targetHero);
    }

    public boolean hasAdmiredHero(long targetID){
        return admiredHeros.contains(targetID);
    }

    public boolean isVipPrizeCollected(int vipLevel){
        return (collectedVipPrize & (1 << (vipLevel - 1))) != 0;
    }

    public int collectVipPrize(int vipLevel){
        assert !isVipPrizeCollected(vipLevel);

        return collectedVipPrize = (collectedVipPrize | (1 << (vipLevel - 1)));
    }

    public long getNextCollectVipWeeklyPrizeTime(){
        return nextCollectVipWeeklyPrizeTime;
    }

    public void setNextCollectVipWeeklyPrizeTime(long time){
        nextCollectVipWeeklyPrizeTime = time;
    }

    public boolean tryOpenTaskFunction(TaskRelatedFunction func){
        long bit = 1L << (func.getNumber() - 1);

        if ((taskFuncBitData & bit) == 0){
            taskFuncBitData = taskFuncBitData | bit;
            return true;
        }
        return false;
    }

    public boolean isTaskFuncOpened(TaskRelatedFunction func){
        return (taskFuncBitData & (1L << (func.getNumber() - 1))) != 0;
    }

    public long getTaskFuncBitData(){
        return taskFuncBitData;
    }

    public boolean tryOpenClientFunction(ClientFunction func){
        int bit = 1 << (func.getNumber() - 1);

        if ((clientFuncBitData & bit) == 0){
            clientFuncBitData = clientFuncBitData | bit;
            return true;
        }
        return false;
    }

    public boolean isShengWangGoodsExchanged(int index){
        return (shengWangExchangeBits & (1 << index)) != 0;
    }

    public boolean tryExchangeShengWangGoods(int index){
        int bit = 1 << index;

        if ((shengWangExchangeBits & bit) == 0){
            shengWangExchangeBits = shengWangExchangeBits | bit;
            return true;
        }
        return false;
    }

    public int getShengWang(){
        return shengWang;
    }

    public int addShengWang(int amount){
        if (amount < 0){
            throw new IllegalArgumentException("要增加声望值时,要增加的数额是负的");
        }

        if ((shengWang += amount) < 0
                || shengWang > VariableConfig.SHENG_WANG_MAX_AMOUNT){
            // overflow
            shengWang = VariableConfig.SHENG_WANG_MAX_AMOUNT;
        }

        return shengWang;
    }

//    public int reduceShengWang(int amount){
//        if (amount < 0){
//            throw new IllegalArgumentException("要扣除声望值时,要扣除的数额是负的");
//        }
//
//        shengWang = Math.max(0, shengWang - amount);
//
//        return shengWang;
//    }

    public int getShengWangTaskTimes(int key){
        int times = shengwangMap.get(key);
        return Math.max(times, 0);
    }

    public void setShengWangTaskTimes(int key, int times){
        shengwangMap.put(key, times);
    }

    public SuperWeaponData getUsingWeapon(){
        return usingWeapon;
    }

    public SuperWeaponData setUsingWeapon(SuperWeaponData newWeapon){
        SuperWeaponData oldWeapon = usingWeapon;
        usingWeapon = newWeapon;
        return oldWeapon;
    }

    public HeroSuperWeapon[] getSuperWeapons(){
        return superWeapons;
    }

    public int getAntiWeaponLevel(int intWeapon){
        if (intWeapon > 0 && intWeapon <= superWeapons.length){
            HeroSuperWeapon weapon = superWeapons[intWeapon - 1];
            if (weapon != null){
                return weapon.getSoulLevel();
            }
        }

        return 0;
    }

    public HeroPet getPet(){
        return pet;
    }

    public void setPet(HeroPet p){
        assert pet == null;

        if (pet == null){
            pet = p;
        }
    }

    public HeroTianJie getTianJie(){
        return tianjie;
    }

    public void setTianJie(HeroTianJie p){
        assert tianjie == null;

        if (tianjie == null){
            tianjie = p;
        }
    }

    public HeroTianZui getTianZui(){
        return tianzui;
    }

    public void setTianZui(HeroTianZui p){
        assert tianzui == null;

        if (tianzui == null){
            tianzui = p;
        }
    }

    public HeroGem getGem(){
        return gem;
    }

    public void setGem(HeroGem g){
        assert gem == null;

        if (gem == null){
            gem = g;
        }
    }

    public HeroBow getBow(){
        return bow;
    }

    public void setBow(HeroBow b){
        assert bow == null;

        if (bow == null){
            bow = b;
        }
    }

    public HeroMount getMount(){
        return mount;
    }

    public int getBestMountId(){
        HeroMount m = mount;
        if (m != null){
            return m.getBestMountId();
        }
        return 0;
    }

    public int getBowId(){
        HeroBow b = bow;
        if (b != null){
            return b.getBowId();
        }
        return 0;
    }

    public int getTianJieId(){
        HeroTianJie b = tianjie;
        if (b != null){
            return b.getId();
        }
        return 0;
    }

    public int getTianZuiId(){
        HeroTianZui b = tianzui;
        if (b != null){
            return b.getId();
        }
        return 0;
    }

    public void setMount(HeroMount m){
        assert mount == null;

        if (mount == null){
            mount = m;
        }
    }

    public int getGoodsUseCount(int goodsId){
        GoodsDataCount goodsIDCount = useLimitCountGoodsMap.get(goodsId);
        return goodsIDCount == null ? 0 : goodsIDCount.goodsCount;
    }

    public void putGoodsUseCount(GoodsData goods, int count){
        useLimitCountGoodsMap.put(goods.id, new GoodsDataCount(goods, count));
    }

    public Collection<GoodsDataCount> getStatGoods(){
        return useLimitCountGoodsMap.values();
    }

    public Welfare getWelfare(){
        return welfare;
    }

    public void setGuildMemberOnOnline(GuildMember guildMember){
        this.guildMember = guildMember;
    }

    public GuildMember getGuildMember(){
        return guildMember;
    }

    public boolean hasGuild(){
        if (guildMember != null){
            return guildMember.getGuild() != null;
        }

        return false;
    }

    public int challengeTimes;

    public int challengeAddTimes;

    private int challengeRefinedTimes;

    public long nextCanChallengeTime;

    public boolean hasChallengeFatigue;

    // 是否领取了每日奖励
    public boolean hasCollectedChallengeDailyPrize;

    public int getChallengeRefinedTimes(){
        return challengeRefinedTimes;
    }

    public int incremnetChallengeRefinedTimes(){
        return ++challengeRefinedTimes;
    }

    public int getChallengeRefinedTimes(long ctime){
        if (ctime - DateTimeConstants.MILLIS_PER_DAY < lastResetDailyTime){
            return challengeRefinedTimes;
        }
        return 0;
    }

    public long getLastLogoutTime(){
        return lastLogoutTime;
    }

    public long getLastResetDailyTime(){
        return lastResetDailyTime;
    }

    public long getLastResetMonthlyTime(){
        return lastResetMonthlyTime;
    }

    public void addAccumulatedOfflineTime(long ctime,
            long offlineExpAccumulationLimit){
        if (lastLogoutTime == 0){
            // 新建英雄
            return;
        }
        if (lastLogoutTime < lastAddAccumulatedOfflineTime){
            logger.error("Hero.addAccumulatedOfflineTime增加离线时间时, 上次下线时间竟然小于上次增加离线时间时间");
            return;
        }

        lastAddAccumulatedOfflineTime = ctime;
        long diff = ctime - lastLogoutTime;
        if (diff > 0){
            // 防沉迷, 如果连续下线时间超过5小时, 清掉累计在线时间
            if (diff >= VariableConfig.FANG_CHEN_MI_OFFLINE_TIME_TO_CLEAR_ONLINE_TIME){
                accumulatedOnlineTime = 0;
                fangChenMi = FangChenMi.NONE;
            }

            accumulatedOfflineTime = Math.min(offlineExpAccumulationLimit,
                    accumulatedOfflineTime + diff);
        } else{
            logger.error("增加离线时间时, 离线时间竟然为 {} ms", diff);
        }
    }

    /**
     * 是否需要防沉迷
     * @return
     */
    public boolean needFangChenMi(){
        return needFangChenMi;
    }

    public long getAccumulatedOnlineTime(){
        return accumulatedOnlineTime;
    }

    public FangChenMi getFangChenMi(){
        return fangChenMi;
    }

    public long addAccumulatedOnlineTime(){
        assert needFangChenMi;
        accumulatedOnlineTime += 60000; // 每分钟给所有在线的人加1分钟在线时间
        updateFangChenMi();
        return accumulatedOnlineTime;
    }

    public void clearAccumulatedOfflineTime(){
        accumulatedOfflineTime = 0;
    }

    public long getAccumulatedOfflineTime(){
        return accumulatedOfflineTime;
    }

    public long getDailyOnlineAccTime(long ctime){
        return dailyOnlineAccTime + ctime - dailyOnlineStartTime;
    }

    public long getTotalOnlineAccTime(long ctime){
        return totalOnlineAccTime + ctime - loginTime;
    }

    public void gmAddTotalOnlineTime(long toAdd){
        totalOnlineAccTime += toAdd;
    }

    public void setLoginTime(long t){
        loginTime = t;
        dailyOnlineStartTime = t;
    }

    public void resetDailyOnlineAccTime(long onlineStartTime){
        dailyOnlineAccTime = 0;
        dailyOnlineStartTime = onlineStartTime;
    }

    @SelfThreadOnly
    public void resetDailyStaticstics(Services services){
        lastResetDailyTime = services.getWorldData()
                .getLastResetDailyStatisticsTime();

        monthlyBankPrevDayOnlineLijin = monthlyBankOnlineLijin;

        resetDailyOnlineAccTime(lastResetDailyTime);

        welfare.resetDailyStaticstics();

        taskList.resetDailyStaticstics(getLevel(), services.getConfigService()
                .getTasks(), hasGuild());

        // 副本今天进入次数
        for (storyDungeonStatIte.rewind(); storyDungeonStatIte.hasNext();){
            storyDungeonStatIte.next().resetTodayEntered();
        }
        storyDungeonStatIte.cleanUp();

        // vip副本进入次数
        todayFinishedVipDungeonIDList.clear();

        // 知天命次数
        divination.reset();

        // 守护孔慈数据
        defenceTodayResetCount = 0;

        // 排行榜崇拜
        admiredHeros.clear();

        // 登录器
        isCollectLocalLoginDailyPrize = false;

        // 搜神宫
        this.souShenTodayPassedSceneID.clear();
        this.souShenPointTodayUsedAmount = 0;
        this.souShenGoodsTodayBoughtCount.clear();

        // 凌云窟
        this.lingYunTodayFinishedTimes = 0;

        // 守护龙脉
        this.longMaiTodayFirstPassed = false;

        // 无绝神阵
        this.wuJueTodayEnteredTimes = 0;

        // 板块战
        this.territoryTodayCollectedPrizeSceneID.clear();

        // 凤血炼制
        phoenixMoneyRefineTimes = 0;
        phoenixLijinRefineTimes = 0;
        phoenixYuanbaoRefineTimes = 0;

        // 个人竞技场
        challengeTimes = 0;
        challengeAddTimes = 0;
        challengeRefinedTimes = 0;
        hasCollectedChallengeDailyPrize = false;

        // 兑换商店
        exchangeGoodsTodayBoughtCount.clear();

        // 挑战侠士
        challengeDungeonDailyTimes = 0;
        setChallengeDungeonAssistTimes(0);

        // 声望
        shengwangMap.clear();
        shengWang = shengWangExchangeBits = 0;

        dailyActivityBuybackMap.clear();

        // 登陆天数
        ++loginDay;

        //平台每日奖励活动
        this.hasCollectedPlatformEverydayPrize = false;

        dailyPVipPrizeMap.clear();
    }

    public void resetMonthlyStaticstics(Services services){
        lastResetMonthlyTime = services.getWorldData()
                .getLastResetMonthlyStatisticsTime();

        welfare.resetMonthlyStaticstics();
    }

    public SingleRelation getSingleRelation(){
        return singleRelationHolder.get();
    }

    public ObjectHolder<SingleRelation> getSingleRelationHolder(){
        return singleRelationHolder;
    }

    public void onSingleRelationHideMyLocationChanged(WorldService worldService){
        if (relationList.isHideMyLocation()){
            singleRelationBuilder.setSceneId(0).setLineNumber(0);
            singleRelationHolder.set(singleRelationBuilder.build());
        } else{
            int newSceneID = fightData.getSceneID();
            singleRelationBuilder.setSceneId(IDUtils
                    .getActualSceneID(newSceneID));
            singleRelationBuilder.setLineNumber(IDUtils
                    .getSceneSequence(newSceneID));
            singleRelationHolder.set(singleRelationBuilder.build());
        }

        worldService.broadcastSingleRelationChangedToRelatedAndOpenedPanel(id,
                singleRelationHolder.get());
    }

    public void updateSingleRelationLevel(int newLevel,
            WorldService worldService){
        singleRelationBuilder.setLevel(newLevel);
        singleRelationHolder.set(singleRelationBuilder.build());

        worldService
                .broadcastSingleRelationChangedToRelatedAndOpenedPanelAndChatMate(
                        id, singleRelationHolder.get());
    }

    public void updateSingleRelationSceneOnOnline(int newSceneID,
            boolean hasAuction, WorldService worldService){
        if (!relationList.isHideMyLocation()){
            singleRelationBuilder.setSceneId(IDUtils
                    .getActualSceneID(newSceneID));
            singleRelationBuilder.setLineNumber(IDUtils
                    .getSceneSequence(newSceneID));
        }

        singleRelationBuilder.setHasSell(hasAuction);

        SingleRelation sr = singleRelationBuilder.build();
        singleRelationHolder.set(sr);

        // 必须广播, 当做上线提醒
        worldService.broadcastSingleRelationChangedOnOnline(id, sr);
    }

    public void updateSingleRelationScene(int newSceneID,
            WorldService worldService){
        if (!relationList.isHideMyLocation()){
            singleRelationBuilder.setSceneId(IDUtils
                    .getActualSceneID(newSceneID));
            singleRelationBuilder.setLineNumber(IDUtils
                    .getSceneSequence(newSceneID));
            singleRelationHolder.set(singleRelationBuilder.build());
        }
        // 已经进入过场景了

        worldService.broadcastSingleRelationChangedToRelatedAndOpenedPanel(id,
                singleRelationHolder.get());
    }

    public void updateSingleRelationHasSell(boolean hasSell,
            WorldService worldService){
        this.hasSell = hasSell;
        singleRelationBuilder.setHasSell(hasSell);
        singleRelationHolder.set(singleRelationBuilder.build());

        worldService.broadcastSingleRelationChangedToRelatedAndOpenedPanel(id,
                singleRelationHolder.get());
    }

    public void updateSingleRelationMood(ByteString mood,
            WorldService worldService){
        singleRelationBuilder.setMood(mood);
        singleRelationHolder.set(singleRelationBuilder.build());

        worldService
                .broadcastSingleRelationChangedToRelatedAndOpenedPanelAndChatMate(
                        id, singleRelationHolder.get());
    }

    /**
     * 在线的hero 不会通过缓存的singleRelationHolder去读取forbidBeenAddedAsFriend字段
     *
     * 此处只是为了保证 singleRelationHolder 和 relationList 数据一致
     * 英雄下线时要将 singleRelation放入singleRelationCache
     * @param forbidBeenAddedAsFriend
     * @param worldService
     */
    public void updateSingleRelationForbidBeenAddedAsFriend(
            boolean forbidBeenAddedAsFriend, WorldService worldService){
        singleRelationBuilder
                .setForbidBeenAddedAsFriend(forbidBeenAddedAsFriend);
        singleRelationHolder.set(singleRelationBuilder.build());

    }

    // ----- 战斗力 -----

    public int doCalculateFightAmount(){
        int newAmount = getHeroBaseFightingAmount()
                + getEquipmentFightingAmount() + getSpellFightingAmount()
                + getMountFightingAmount() + getBowFightingAmount()
                + getSuperWeaponFightingAmount() + getSuperArmFightingAmount()
                + getPetFightingAmount() + getSuperWeaponXinfaFightingAmount()
                + getTianJieFightingAmount() + getTianZuiFightingAmount();

        GuildMember gm = getGuildMember();
        if (gm != null){
            gm.setFightAmount(newAmount);
        }
        return fightingAmount = newAmount;
    }

    public int getFightingAmount(){
        return fightingAmount;
    }

    public FightingAmountProto getFightingAmountProto(){
        FightingAmountProto.Builder builder = FightingAmountProto.newBuilder();

        builder.setBaseFightingAmount(getHeroBaseFightingAmount());
        builder.setEquipmentFightingAmount(getEquipmentFightingAmount());
        builder.setSpellFightingAmount(getSpellFightingAmount());
//        builder.setGemFightingAmount(getGemFightingAmount());
        builder.setMountFightingAmount(getMountFightingAmount());
        builder.setBowFightingAmount(getBowFightingAmount());
        builder.setSuperWeaponFightingAmount(getSuperWeaponFightingAmount());
        builder.setSuperArmFightingAmount(getSuperArmFightingAmount());
        builder.setSuperWeaponXinfaFightingAmount(getSuperWeaponXinfaFightingAmount());
        builder.setTianjieFightingAmount(getTianJieFightingAmount());
        builder.setTianzuiFightingAmount(getTianZuiFightingAmount());

        return builder.build();
    }

    public int getHeroBaseFightingAmount(){
        HeroLevelData levelData = this.levelData;
        int fightingAmount = levelData.getFightAmount();

        Depot depot = this.depot;
        if (depot != null){
            fightingAmount += depot.getUnlockedData().getFightingAmount();
        }

        Storage storage = this.storage;
        if (storage != null){
            fightingAmount += storage.getUnlockedData().getFightingAmount();
        }

        return fightingAmount;
    }

    public int getEquipmentFightingAmount(){

        int fightingAmount = 0;
        for (Equipment e : equipmentList){
            if (e != null){
                fightingAmount += e.getFightingAmount();
            }
        }

        // 装备穿戴额外附加属性
        EquipmentExtraStat extraData = equipmentExtraStat;
        if (extraData != null){
            fightingAmount += extraData.getFightingAmount();
        }

        return fightingAmount;
    }

    public int getSpellFightingAmount(){
        return spellList.getFightingAmount();
    }

    public boolean isCollectPVipPrize(boolean isDailyPrize, int groupID, int key){
        if (isDailyPrize){
            return isCollectDailyPVipPrize(groupID);
        } else{
            return isCollectSinglePVipPrize(groupID, key);
        }
    }

    public boolean tryCollectPVipPrize(boolean isDailyPrize, int groupID,
            int key){
        if (isDailyPrize){
            return tryCollectDailyPVipPrize(groupID, key);
        } else{
            return tryCollectSinglePVipPrize(groupID, key);
        }
    }

    public boolean isCollectSinglePVipPrize(int groupID, int key){
        int result = singlePVipPrizeMap.get(groupID, 0);

        return (result & (1 << key)) != 0;
    }

    public int getCollectSinglePVipPrize(int groupID){
        return singlePVipPrizeMap.get(groupID, 0);
    }

    public boolean tryCollectSinglePVipPrize(int groupID, int key){
        int result = singlePVipPrizeMap.get(groupID, 0);

        int newResult = (result | (1 << key));
        if (result != newResult){
            singlePVipPrizeMap.put(groupID, newResult);
            return true;
        }

        return false;
    }

    public boolean isCollectDailyPVipPrize(int groupID){
        return dailyPVipPrizeMap.containsKey(groupID);
    }

    public int getCollectDailyPVipPrize(int groupID){
        return dailyPVipPrizeMap.get(groupID, 0);
    }

    public boolean tryCollectDailyPVipPrize(int groupID, int key){

        int result = dailyPVipPrizeMap.get(groupID, 0);

        int newResult = (result | (1 << key));
        if (result != newResult){
            dailyPVipPrizeMap.put(groupID, newResult);
            return true;
        }

        return false;
    }

//    public int getGemFightingAmount(){
//        HeroGem gem = this.gem;
//        if (gem != null){
//            return gem.getFightingAmount();
//        }
//
//        return 0;
//    }

    public int getMountFightingAmount(){
        HeroMount mount = this.mount;
        if (mount != null && mount.isValid()){
            return mount.getFightingAmount();
        }
        return 0;
    }

    public int getBestMountFightingAmount(){
        HeroMount mount = this.mount;
        if (mount != null){
            return mount.getBestMountFightingAmount();
        }
        return 0;
    }

    public int getBowFightingAmount(){
        HeroBow bow = this.bow;
        if (bow != null){
            return bow.getFightingAmount();
        }

        return 0;
    }

    public int getSuperWeaponFightingAmount(){
        int amount = 0;
        for (HeroSuperWeapon weapon : superWeapons){
            if (weapon != null){
                amount += weapon.getFightingAmount();
            }
        }

        return amount;
    }

    public int getSuperWeaponXinfaFightingAmount(){
        int amount = 0;
        for (HeroSuperWeapon weapon : superWeapons){
            if (weapon != null){
                amount += weapon.getXinfaFightingAmount();
            }
        }

        return amount;
    }

    public int getPetFightingAmount(){

        HeroPet pet = this.pet;
        if (pet != null){
            return pet.getFightingAmount();
        }

        return 0;
    }

    public int getTianJieFightingAmount(){

        HeroTianJie tianjie = this.tianjie;
        if (tianjie != null){
            return tianjie.getFightingAmount();
        }

        return 0;
    }

    public int getTianZuiFightingAmount(){

        HeroTianZui tianzui = this.tianzui;
        if (tianzui != null){
            return tianzui.getFightingAmount();
        }

        return 0;
    }

    public int getSuperArmFightingAmount(){
        // TODO
        return 0;
    }

    // ----- end of 战斗力 -----

    // --- PK模式 ---

    public PkMode getPkMode(){
        return pkMode;
    }

    public void setPkMode(PkMode mode){
        pkMode = mode;
    }

    public int getIntPkMode(){
        return pkMode.getIntMode();
    }

    public int getPkAmount(){
        return pkAmount;
    }

    public int addPkAmount(int toAdd){
        return pkAmount = Math.min(pkAmount + toAdd,
                VariableConfig.PK_MAX_AMOUNT);
    }

    public int reducePkAmount(int toReduce){
        return pkAmount = Math.max(0, pkAmount - toReduce);
    }

    public boolean isRedName(){
        return pkAmount >= VariableConfig.RED_NAME_PK_AMOUNT_THRESHOLD;
    }

    public long getNextReducePkAmountTime(){
        return nextReducePkAmountTime;
    }

    public void setNextReducePkAmountTime(long time){
        nextReducePkAmountTime = time;
    }

    public long getReliveProtectedEndTime(){
        return reliveProtectedEndTime;
    }

    public void setReliveProtectedEndTime(long time){
        reliveProtectedEndTime = time;
    }

    // --- end of PK模式 ---

    // ---- 副本 ----
    public int getBeforeDungeonSceneID(){
        return beforeDungeonSceneID;
    }

    public int getBeforeDungeonX(){
        return beforeDungeonX;
    }

    public int getBeforeDungeonY(){
        return beforeDungeonY;
    }

    public void setClusterUUID(int uuid){
        this.clusterSceneUUID = uuid;
    }

    public int getClusterUUID(){
        return clusterSceneUUID;
    }

    public void setBeforeDungeonSceneAndPos(int sceneID, int beforeX,
            int beforeY){
        this.beforeDungeonSceneID = sceneID;
        this.beforeDungeonX = beforeX;
        this.beforeDungeonY = beforeY;
    }

    public StoryDungeonStat getStoryDungeonStat(int dungeonID){
        return storyDungeonStat.get(dungeonID);
    }

    public void putStoryDungeonStat(StoryDungeonStat stat){
        StoryDungeonStat old = storyDungeonStat.put(stat.dungeonID, stat);
        if (old != null){
            logger.error("Hero.putStoryDungeonStat时, 竟然已经有了相同id的stat存在");
        }
    }

    public void addStoryDungeonCollectablePrize(
            StoryDungeonCollectablePrizeProto proto){
        this.storyDungeonCollectablePrize.add(proto);
    }

    public int getStoryDungeonCollectablePrizeSize(){
        return storyDungeonCollectablePrize.size();
    }

    public StoryDungeonCollectablePrizeProto getStoryDungeonCollectablePrize(
            int pos){
        return storyDungeonCollectablePrize.get(pos);
    }

    public void removeStoryDungeonCollectablePrize(int pos){
        storyDungeonCollectablePrize.remove(pos);
    }

    public int getAutoFinishStoryID(){
        return autoFinishStoryID;
    }

    public long getAutoFinishStoryTime(){
        return autoFinishStoryCompleteTime;
    }

    public void setAutoFinishStoryIDAndTime(int id, long time){
        this.autoFinishStoryID = id;
        this.autoFinishStoryCompleteTime = time;
    }

    public boolean isAutoFinishAllStory(){
        return isAutoFinishAllStory;
    }

    public void setIsAutoFinishAllStory(boolean v){
        this.isAutoFinishAllStory = v;
    }

    public ReusableIterator<StoryDungeonStat> getStoryDungeonStatIte(){
        return storyDungeonStatIte;
    }

    public StoryDungeonStat getNextAutoFinishStoryDungeonStat(
            StoryDungeonSceneDatas storySceneDatas){
        StoryDungeonStat result = null;

        StoryDungeonStat currentStat;
        for (storyDungeonStatIte.rewind(); storyDungeonStatIte.hasNext();){
            currentStat = storyDungeonStatIte.next();

            if (!currentStat.hasPassed()){
                continue;
            }

            if (!currentStat.canEnterToday()){
                continue;
            }

            // 今天还能进
            if (result == null || currentStat.dungeonID < result.dungeonID){
                result = currentStat;
            }
        }
        storyDungeonStatIte.cleanUp();

        return result;
    }

    // --- 挑战侠士 ---

    public int getFinishedChallengeDungeonSequence(){
        return finishedChallengeDungeonSequence;
    }

    public void setFinishedChallengeDungeonSequence(int newSequence){
        this.finishedChallengeDungeonSequence = newSequence;

        if (guildMember != null){
            guildMember.setChallengeSequence(newSequence);
        }
    }

    public int getChallengeDungeonDailyTimes(){
        return challengeDungeonDailyTimes;
    }

    public void setChallengeDungeonDailyTimes(int times){
        this.challengeDungeonDailyTimes = times;
    }

    public int getChallengeDungeonAssistTimes(){
        return challengeDungeonAssistTimes;
    }

    public void setChallengeDungeonAssistTimes(int times){
        this.challengeDungeonAssistTimes = times;

        if (guildMember != null){
            guildMember.setChallengeAssistTimes(times);
        }
    }

    public int getChallengeDungeonUseTime(int sequence){
        if (sequence > challengeDungeonUseTime.size()){
            return 0;
        }

        return challengeDungeonUseTime.get(sequence - 1);
    }

    public boolean setChallengeDungeonUseTime(int sequence, int useTime){
        if (sequence > challengeDungeonUseTime.size()){
            for (int i = challengeDungeonUseTime.size() + 1; i < sequence; i++){
                challengeDungeonUseTime.add(0);
            }
            challengeDungeonUseTime.add(useTime);
            return true;
        }

        int time = challengeDungeonUseTime.get(sequence - 1);
        if (time == 0 || time > useTime){
            challengeDungeonUseTime.set(sequence - 1, useTime);
            return true;
        }

        return false;
    }

    // --- vip 副本 ---

    public boolean hasTodayFinishedVipDungeon(int dungeonID){
        return todayFinishedVipDungeonIDList.contains(dungeonID);
    }

    public void addTodayFinishedVipDungeon(int dungeonID){
        todayFinishedVipDungeonIDList.add(dungeonID);
    }

    // --- 守护孔慈 ---

    public int getDefenceTodayFinishedBatch(){
        return defenceTodayFinishedBatch;
    }

    public void setDefenceTodayFinishedBatch(int defenceTodayFinishedBatch){
        this.defenceTodayFinishedBatch = defenceTodayFinishedBatch;
    }

    public int getDefenceHistoryMaxBatch(){
        return defenceHistoryMaxBatch;
    }

    public void setDefenceHistoryMaxBatch(int defenceHistoryMaxBatch){
        this.defenceHistoryMaxBatch = defenceHistoryMaxBatch;
    }

    public int getDefenceTodayResetCount(){
        return defenceTodayResetCount;
    }

    public void setDefenceTodayResetCount(int defenceTodayResetCount){
        this.defenceTodayResetCount = defenceTodayResetCount;
    }

    public int getDefenceCollectedFirstPassPrize(){
        return defenceCollectedFirstPassPrize;
    }

    public void setDefenceCollectedFirstPassPrize(
            int defenceCollectedFirstPassPrize){
        this.defenceCollectedFirstPassPrize = defenceCollectedFirstPassPrize;
    }

    public void addDefenceCollectablePrize(
            DefenceCollectablePrizeWithExpireTime prize){
        this.defenceCollectablePrize.add(prize);
    }

    public int getDefenceCollectablePrizeCount(){
        return defenceCollectablePrize.size();
    }

    public DefenceCollectablePrizeWithExpireTime getDefenceCollectablePrize(
            int pos){
        return defenceCollectablePrize.get(pos);
    }

    public void removeDefenceCollectablePrize(int pos){
        defenceCollectablePrize.remove(pos);
    }

    public DefenceCollectablePrize getDefenceAutoFinishPrizeWaitingToBeCollected(){
        return defenceAutoFinishPrizeWaitingToBeCollected;
    }

    public void setDefenceAutoFinishPrizeWaitingToBeCollected(
            DefenceCollectablePrize defenceAutoFinishPrizeWaitingToBeCollected){
        this.defenceAutoFinishPrizeWaitingToBeCollected = defenceAutoFinishPrizeWaitingToBeCollected;
    }

    // --- 搜神宫 ---

    public int getSouShenPoint(){
        return souShenPoint;
    }

    public int addSouShenPoint(int amount){
        if (amount < 0){
            throw new IllegalArgumentException("要增加搜神值时,要增加的数额是负的");
        }

        if ((souShenPoint += amount) < 0
                || souShenPoint > VariableConfig.SOU_SHEN_POINT_MAX_AMOUNT){
            // overflow
            souShenPoint = VariableConfig.SOU_SHEN_POINT_MAX_AMOUNT;
        }

        return souShenPoint;
    }

    public int reduceSouShenPoint(int amount){
        if (amount < 0){
            throw new IllegalArgumentException("要扣除搜神值时,要扣除的数额是负的");
        }

        souShenPoint = Math.max(0, souShenPoint - amount);

        return souShenPoint;
    }

    public int getHonorPoint(){
        return honorPoint;
    }

    public int addHonorPoint(int amount){
        if (amount < 0){
            throw new IllegalArgumentException("要增加荣誉值时,要增加的数额是负的");
        }

        if ((honorPoint += amount) < 0
                || honorPoint > VariableConfig.HONOR_POINT_MAX_AMOUNT){
            // overflow
            honorPoint = VariableConfig.HONOR_POINT_MAX_AMOUNT;
        }

        return honorPoint;
    }

    public int reduceHonorPoint(int amount){
        if (amount < 0){
            throw new IllegalArgumentException("要扣除荣誉值时,要扣除的数额是负的");
        }

        honorPoint = Math.max(0, honorPoint - amount);

        return honorPoint;
    }

    public boolean hasTodayFinishedSouShen(int sceneID){
        return souShenTodayPassedSceneID.contains(sceneID);
    }

    public void addTodayFinishedSouShen(int sceneID){
        souShenTodayPassedSceneID.add(sceneID);
    }

    public boolean hasLifeFinishedSouShen(int sceneID){
        return souShenLifePassedSceneID.contains(sceneID);
    }

    public void addLifeFinishedSouShen(int sceneID){
        souShenLifePassedSceneID.add(sceneID);
    }

    public Collection<GoodsBoughtEntry> getSouShenGoodsBoughtEntries(){
        return souShenGoodsTodayBoughtCount.values();
    }

    public int getSouShenGoodsBoughtCount(int id){
        GoodsBoughtEntry entry = souShenGoodsTodayBoughtCount.get(id);
        return entry == null ? 0 : entry.count;
    }

    public int addNewSouShenGoodsBoughtCount(int id){
        GoodsBoughtEntry entry = souShenGoodsTodayBoughtCount.get(id);
        if (entry == null){
            souShenGoodsTodayBoughtCount.put(id, new GoodsBoughtEntry(id, 1));
            return 1;
        } else{
            return ++entry.count;
        }
    }

    public int getExchangeGoodsBoughtCount(){
        return exchangeGoodsTodayBoughtCount.size();
    }

    public Collection<GoodsBoughtEntry> getExchangeGoodsBoughtEntries(){
        return exchangeGoodsTodayBoughtCount.values();
    }

    public int getExchangeGoodsBoughtCount(int id){
        GoodsBoughtEntry entry = exchangeGoodsTodayBoughtCount.get(id);
        return entry == null ? 0 : entry.count;
    }

    public int addNewExchangeGoodsBoughtCount(int id){
        GoodsBoughtEntry entry = exchangeGoodsTodayBoughtCount.get(id);
        if (entry == null){
            exchangeGoodsTodayBoughtCount.put(id, new GoodsBoughtEntry(id, 1));
            return 1;
        } else{
            return ++entry.count;
        }
    }

    public int getSouShenPointTodayUsedAmount(){
        return souShenPointTodayUsedAmount;
    }

    public void setSouShenPointTodayUsedAmount(int newAmount){
        this.souShenPointTodayUsedAmount = newAmount;
    }

    // --- 凌云窟 ---

    public int getLingYunTodayFinishedTimes(){
        return lingYunTodayFinishedTimes;
    }

    public int addLingYunTodayFinishedTimes(){
        return ++lingYunTodayFinishedTimes;
    }

    // --- 组队副本可领取奖励 ---
    public void addGroupDungeonCollectablePrize(
            GroupDungeonCollectablePrizeProto proto){
        this.groupDungeonCollectablePrize.add(proto);
    }

    public int getGroupDungeonCollectablePrizeSize(){
        return groupDungeonCollectablePrize.size();
    }

    public GroupDungeonCollectablePrizeProto getGroupDungeonCollectablePrize(
            int pos){
        return groupDungeonCollectablePrize.get(pos);
    }

    public void removeGroupDungeonCollectablePrize(int pos){
        groupDungeonCollectablePrize.remove(pos);
    }

    // --- 守护龙脉 ---

    public boolean hasLongMaiTodayFirstPassed(){
        return longMaiTodayFirstPassed;
    }

    public void setLongMaiTodayFirstPassed(){
        longMaiTodayFirstPassed = true;
    }

    // --- 无绝神阵 ---

    public int getWuJueTodayEnteredTimes(){
        return wuJueTodayEnteredTimes;
    }

    public int addWuJueTodayEnteredTimes(){
        return ++wuJueTodayEnteredTimes;
    }

    // --- 火麟洞 ---

    public void clearHuoLinAccumulatedStat(){
        huoLinAccumulatedExp = huoLinAccumulatedRealAir = 0;
    }

    public int getHuoLinAccumulatedExp(){
        return huoLinAccumulatedExp;
    }

    public int getHuoLinAccumulatedRealAir(){
        return huoLinAccumulatedRealAir;
    }

    public int addHuoLinAccumulatedExp(int amount){
        return huoLinAccumulatedExp += amount;
    }

    public int addHuoLinAccumulatedRealAir(int amount){
        return huoLinAccumulatedRealAir += amount;
    }

    public void setHuoLinScene(long combatServerID, int sceneDataID, int uuid,
            int line, long endTime){
        this.huoLinCombatServerID = combatServerID;
        this.huoLinSceneDataID = sceneDataID;
        this.huoLinSceneUUID = uuid;
        this.huoLinLine = line;
        this.huoLinActivityEndTime = endTime;
    }

    public int getHuoLinLine(){
        return huoLinLine;
    }

    public long getHuoLinActivityEndTime(){
        return huoLinActivityEndTime;
    }

    public long getHuoLinCombatServerID(){
        return huoLinCombatServerID;
    }

    public int getHuoLinSceneDataID(){
        return huoLinSceneDataID;
    }

    public int getHuoLinSceneUUID(){
        return huoLinSceneUUID;
    }

    // ----- end of 副本 ------

    // --- 板块 ---

    public boolean hasCollectedTerritoryPrize(int sceneID){
        return territoryTodayCollectedPrizeSceneID.contains(sceneID);
    }

    public void addCollectedTerritoryPrize(int sceneID){
        territoryTodayCollectedPrizeSceneID.add(sceneID);
    }

    public BattleHeroInfo getTerritoryHeroInfo(){
        return territoryHeroInfo;
    }

    public BattleHeroInfo getGuildFightHeroInfo(){
        return guildCityHeroInfo;
    }

    public BattleHeroInfo getLongCityHeroInfo(){
        return longCityHeroInfo;
    }

    // ---

    public HeroTaskList getTaskList(){
        return taskList;
    }

    public Equipment[] getEquipmentList(){
        return equipmentList;
    }

    public EquipmentExtraStat checkEquipmentExtraStat(
            EquipmentExtraStats extraStats){
        boolean isAllPurpleQuality = true;
        int minRefinedTimes = extraStats.getMaxRefinedTimes();
        for (Equipment e : equipmentList){
            if (e == null || e.getIntQuality() < Quality.PURPLE_VALUE){
                isAllPurpleQuality = false;
                break;
            }

            if (e.getRefinedTimes() < minRefinedTimes){
                minRefinedTimes = e.getRefinedTimes();
            }
        }

        if (isAllPurpleQuality){
            // 牛B啦，全身满级装备
            equipmentExtraStat = extraStats.getExtraStat(minRefinedTimes);
        } else{
            equipmentExtraStat = null;
        }

        return equipmentExtraStat;
    }

    public EquipmentExtraStat getEquipmentExtraStat(){
        return equipmentExtraStat;
    }

    public EquipmentExtraStat clearEquipmentExtraStat(){
        EquipmentExtraStat oldExtraData = equipmentExtraStat;
        equipmentExtraStat = null;
        return oldExtraData;
    }

    public SpriteStat getTaozStat(int taoz){
        return taozStatMap.get(taoz);
    }

    public SpriteStat removeTaozStat(int taoz){
        return taozStatMap.remove(taoz);
    }

    public SpriteStat checkTaozStat(TaozData data, SpriteStat oldStat){
        int count = 0;
        for (Equipment e : equipmentList){
            if (e != null && e.getData().getTaoz() == data){
                ++count;
            }
        }

        SpriteStat newStat = data.get(count);

        if (oldStat != newStat){
            if (newStat == null){
                taozStatMap.remove(data.id);
            } else{
                taozStatMap.put(data.id, newStat);
            }
        }

        return newStat;
    }

    public List<BuyBackGoods> getBuyBackGoodsList(){
        return buyBackGoodsList;
    }

    public long getGoodsCoolDown(int id){
        return goodsCoolDownMap.get(id);
    }

    public void putGoodsCoolDown(int id, long time){
        goodsCoolDownMap.put(id, time);
    }

    public long getGoodsTypeCoolDown(int type){
        return goodsTypeCoolDownMap.get(type);
    }

    public void putGoodsTypeCoolDown(int type, long time){
        goodsTypeCoolDownMap.put(type, time);
    }

    /**
     * 注意这里没有加上组队额外的血量的
     */
    public void calculateProperties(){

        SpriteStatBuilder builder = SpriteStatBuilder.newBuilder();

        // 英雄基础属性
        builder.add(getLevelData().getBaseStat());

        // 装备属性
        for (Equipment equipment : getEquipmentList()){
            if (equipment != null){
                builder.add(equipment.getTotalStat());
            }
        }

        // 全身+10额外属性
        EquipmentExtraStat extraData = getEquipmentExtraStat();
        if (extraData != null){
            builder.add(extraData.getTotalStat());
        }

        // 套装属性
        for (SpriteStat s : taozStatMap.values()){
            builder.add(s);
        }

        // 背包格子属性
        builder.add(getDepot().getUnlockedData().accStat);

        // 仓库格子属性
        Storage storage = getStorage();
        if (storage != null){
            builder.add(storage.getUnlockedData().accStat);
        }

        // 技能属性
        for (PassiveSpell ps : getSpellList().getPassiveSpells()){
            if (ps.isPropertyPassiveSpell()){
                builder.add(ps.getPropertyStat());
            }
        }

        // 坐骑属性
        HeroMount mount = getMount();
        if (mount != null && mount.isValid()){
            builder.add(mount.getTotalStat());
        }

        // 神兵属性
        for (HeroSuperWeapon weapon : getSuperWeapons()){
            if (weapon != null){
                builder.add(weapon.getTotalStat());
            }
        }

        // 弓箭
        HeroBow bow = getBow();
        if (bow != null){
            builder.add(bow.getBaseStat());
        }

        // 加属性药品
        for (GoodsDataCount goods : getStatGoods()){
            if (goods.data == null){
                continue;
            }

            if (goods.data.getEfficacy() instanceof StatEfficacy){
                SingleSpriteStat spriteStat = ((StatEfficacy) goods.data
                        .getEfficacy()).getSpriteStat(goods.goodsCount);
                builder.add(spriteStat);
            }
        }

        // 宠物
        HeroPet pet = getPet();
        if (pet != null){
            builder.add(pet.getMasterStat());
        }

        // 天罪
        HeroTianZui tianzui = getTianZui();
        if (tianzui != null){
            builder.add(tianzui.getTotalStat());
        }

        // 天劫
        HeroTianJie tianjie = getTianJie();
        if (tianjie != null){
            builder.add(tianjie.getTotalStat());
        }

        fightData.setBaseStat(builder.build());
        doCalculateFightAmount();
    }

    public Divination getDivination(){
        return divination;
    }

//    public GoodsLog getAndClearGoodsLog(){
//        return goodsOwnership.getAndClearGoodsLog();
//    }

    public GoodsOwnership getGoodsOwnership(){
        return goodsOwnership;
    }

    public Depot getDepot(){
        return depot;
    }

    public Storage getStorage(){
        return storage;
    }

    public boolean openStorage(long currentTime){
        if (storage == null){
            storage = Storage.newStorage(currentTime);
            return true;
        }

        return false;
    }

    // 从0开始计数
    private int loginDay;

    public int getLoginDay(){
        return loginDay + 1;
    }

    private int loginPrizeInfo;

    public boolean isCollectLoginPrize(int idx){
        return (loginPrizeInfo & (1 << idx)) != 0;
    }

    public boolean tryCollectLoginPrize(int idx){
        int newResult = doCollectLoginPrize(idx, loginPrizeInfo);
        if (loginPrizeInfo != newResult){
            loginPrizeInfo = newResult;
            return true;
        }
        return false;
    }

    public static int doCollectLoginPrize(int type, int result){
        return result | (1 << type);
    }

    public boolean hasRecharged(){
        return hasRecharged;
    }

    public void setHasRecharged(){
        hasRecharged = true;
    }

    public int getTotalRechargeYuanbao(){
        return totalRechargeYuanbao;
    }

    public int addRechargeYuanbao(int amount){
        if (amount <= 0){
            throw new IllegalArgumentException("要增加累计充值元宝时,要增加的数额是负的");
        }

        if ((totalRechargeYuanbao += amount) < 0
                || totalRechargeYuanbao > VariableConfig.YUANBAO_MAX_AMOUNT){
            // overflow
            totalRechargeYuanbao = VariableConfig.YUANBAO_MAX_AMOUNT;
        }

        return totalRechargeYuanbao;
    }

    // 正常是没有需要扣除累计充值的，这个方法只给GM命令用
    @VisibleForTesting
    public int reduceRechargeYuanbao(int amount){
        if (amount < 0){
            throw new IllegalArgumentException("要扣除累计充值元宝时,要扣除的数额是负的");
        }

        totalRechargeYuanbao = Math.max(0, totalRechargeYuanbao - amount);

        return totalRechargeYuanbao;
    }

    /**
     * 包含绑定元宝
     * @return
     */
    public int getTotalYuanbao(){
        long total = getYuanbao();
        total += getBindedYuanbao();

        if (total < VariableConfig.YUANBAO_MAX_AMOUNT){
            return (int) total;
        } else{
            return VariableConfig.YUANBAO_MAX_AMOUNT;
        }
    }

    public int getYuanbao(){
        return yuanbao;
    }

    public int addYuanbao(int amount){
        if (amount < 0){
            throw new IllegalArgumentException("要增加元宝时,要增加的数额是负的");
        }

        if ((yuanbao += amount) < 0
                || yuanbao > VariableConfig.YUANBAO_MAX_AMOUNT){
            // overflow
            yuanbao = VariableConfig.YUANBAO_MAX_AMOUNT;
        }

        return yuanbao;
    }

    public int reduceYuanbao(int amount){
        if (amount < 0){
            throw new IllegalArgumentException("要扣除元宝时,要扣除的数额是负的");
        }

        yuanbao = Math.max(0, yuanbao - amount);

        return yuanbao;
    }

    public int getLijin(){
        return lijin;
    }

    public int addLijin(int amount){
        if (amount < 0){
            throw new IllegalArgumentException("要增加礼金时,要增加的数额是负的");
        }

        if ((lijin += amount) < 0 || lijin > VariableConfig.LIJIN_MAX_AMOUNT){
            // overflow
            lijin = VariableConfig.LIJIN_MAX_AMOUNT;
        }

        return lijin;
    }

    public int reduceLijin(int amount){
        if (amount < 0){
            throw new IllegalArgumentException("要扣除礼金时,要扣除的数额是负的");
        }

        lijin = Math.max(0, lijin - amount);

        return lijin;
    }

    public int getGuildLilian(){
        return guildLilian;
    }

    public int addGuildLilian(int amount){
        if (amount < 0){
            throw new IllegalArgumentException("要增加银两时,要增加的数额是负的");
        }

        if ((guildLilian += amount) < 0
                || guildLilian > VariableConfig.GUILD_LILIAN_UPPER_LIMIT){
            guildLilian = VariableConfig.GUILD_LILIAN_UPPER_LIMIT;
        }

        return guildLilian;
    }

    public int reduceGuildLilian(int amount){
        if (amount < 0){
            throw new IllegalArgumentException("要扣帮派历练时, 要扣除的数额是负的");
        }

        guildLilian = Math.max(0, guildLilian - amount);

        return guildLilian;
    }

    public int getMoney(){
        return money;
    }

    public int addMoney(int amount){
        if (amount < 0){
            throw new IllegalArgumentException("要增加银两时,要增加的数额是负的");
        }

        if ((money += amount) < 0 || money > VariableConfig.MONEY_MAX_AMOUNT){
            // overflow
            money = VariableConfig.MONEY_MAX_AMOUNT;
        }

        return money;
    }

    public int reduceMoney(int amount){
        if (amount < 0){
            throw new IllegalArgumentException("要扣除银两时,要扣除的数额是负的");
        }

        money = Math.max(0, money - amount);

        return money;
    }

    public void setClientOnlyConfig1(int bit){
        clientOnlyConfig1 = (clientOnlyConfig1 | (1 << bit));
    }

    public void unsetClientOnlyConfig1(int bit){
        clientOnlyConfig1 = (clientOnlyConfig1) & (~(1 << bit));
    }

    public void setClientOnlyIntConfig(int idx, int amount){
        if (idx < 0 || idx >= VariableConfig.CLIENT_INT_CONFIG_COUNT){
            return;
        }

        // 服务器存储+1的值，客户端读取-1的值
        clientOnlyIntConfigs[idx] = amount + 1;
    }

    public Race getRace(){
        return race;
    }

    /**
     * 女0，男1
     * @return
     */
    public int getGender(){
        return race.isMale ? 1 : 0;
    }

    public int getRaceId(){
        return race.getId();
    }

    public int getLevel(){
        return fightData.getLevel();
    }

    public int getLevelUpdateTime(){
        return levelUpdateTime;
    }

    public boolean isMaxLevel(){
        return levelData.nextLevel == null;
    }

    public void beenBlacked(long ctime){
        if (lastBeenAddBlackTime + VariableConfig.AUTO_SPEECH_LIMIT_WINDOW <= ctime){
            // 上次被拉黑, 已经过了窗口时间了
            beenAddBlackCount = 1;
        } else{
            beenAddBlackCount++;
            if (beenAddBlackCount >= VariableConfig.AUTO_SPEECH_LIMIT_COUNT){
                autoSpeechEndTime = ctime
                        + VariableConfig.AUTO_SPEECH_LIMIT_DURATION;
            }
        }
        lastBeenAddBlackTime = ctime;
    }

    /**
     * 是否被禁言
     * @param ctime
     * @return
     */
    public boolean isSpeechLimited(long ctime){
        return (getLevel() < VariableConfig.AUTO_SPEECH_LIMIT_LEVEL_LIMIT && ctime < autoSpeechEndTime)
                || ctime < strongSpeechLimitEndTime;
    }

    public boolean isStrongSpeechLimit(long ctime){
        return ctime < strongSpeechLimitEndTime;
    }

    public long getSpeechLimitEndTime(){
        return Math.max(autoSpeechEndTime, strongSpeechLimitEndTime);
    }

    public void setSpeechLimitEndTime(long time){
        strongSpeechLimitEndTime = time;
    }

    public long getReadPrivateMessageTime(){
        return lastReadPrivateMessageTime;
    }

    public boolean isTeamAutoAcceptInvite(){
        return isTeamAutoAcceptInvite;
    }

    public boolean isTeamAutoAcceptRequest(){
        return isTeamAutoAcceptRequest;
    }

    public boolean isTradeAutoReject(){
        return isTradeAutoReject;
    }

    public boolean isGuildAutoAcceptInvite(){
        return isGuildAutoAccept;
    }

    public void setIsGuildAutoAcceptInvite(boolean v){
        this.isGuildAutoAccept = v;
    }

    public boolean isForbidOtherInviteMeJoinGuild(){
        return isForbidOtherInviteMeJoinGuild;
    }

    public void setForbidOtherInviteMeJoinGuild(
            boolean isForbidOtherInviteMeJoinGuild){
        this.isForbidOtherInviteMeJoinGuild = isForbidOtherInviteMeJoinGuild;
    }

    public boolean addTradeGetExpTimeIfCan(long ctime){
        if (tradeNextCanGetExpTime > ctime){
            return false;
        }

        tradeNextCanGetExpTime = ctime
                + VariableConfig.TRADE_CAN_GET_EXP_INTERVAL;
        return true;
    }

    public boolean addAuctionGetExpTimeIfCan(long ctime){
        if (auctionNextCanGetExpTime > ctime){
            return false;
        }

        auctionNextCanGetExpTime = ctime
                + VariableConfig.AUCTION_CAN_GET_EXP_INTERVAL;
        return true;
    }

    public void setIsTradeAutoReject(boolean v){
        this.isTradeAutoReject = v;
    }

    public void setIsTeamAutoAcceptInvite(boolean v){
        this.isTeamAutoAcceptInvite = v;
    }

    public void setIsTeamAutoAcceptRequest(boolean v){
        this.isTeamAutoAcceptRequest = v;
    }

    public boolean isForbidOtherInviteMeJoinTeam(){
        return isForbidOtherInviteMeJoinTeam;
    }

    public void setForbidOtherInviteMeJoinTeam(
            boolean isForbidOtherInviteMeJoinTeam){
        this.isForbidOtherInviteMeJoinTeam = isForbidOtherInviteMeJoinTeam;
    }

    public long getUpgradeExp(){
        return levelData.getUpgradeExp();
    }

    public int onLevelUp(){
        assert !isMaxLevel();
        levelData = levelData.nextLevel;
        int newLevel = fightData.incrementLevel();
        return newLevel;
    }

    public void onLevelChanged(long ctime){
        levelUpdateTime = (int) (ctime / 1000);
    }

    public HeroLevelData getLevelData(){
        return levelData;
    }

    public void setLevelData(HeroLevelData level){
        this.levelData = level;
    }

    public Model getModel(){
        return model;
    }

    public int getEquipmentResources(){
        return model.getResource();
    }

    public int getEquipmentResourcesWithBestMountBow(){
        return model.getResourceWithBestMountBow();
    }

    public void replaceEquipmentResources(ModelType type, int res){
        model.replaceResource(type, res);
    }

    public void onBestMountChanged(int bestMount){
        model.onBestMountChanged(bestMount);
    }

    public void onBestBowChanged(int bestBow){
        model.onBestBowChanged(bestBow);
    }

    /**
     * 获取当前的vip等级对象. 如果不是vip则返回null
     * @return
     */
    public Vip getVip(){
        return vip;
    }

    public int getVipLevel(){
        if (vip != null){
            return vip.level;
        }
        return 0;
    }

    public boolean isVip(){
        return vip != null;
    }

    /**
     * 远程场景中设置Vip信息
     * @param vip
     */
    public void setVip(Vip vip){
        this.vip = vip;
    }

    public int getVipExp(){
        return vipExp;
    }

    /**
     * 加vip经验, 如果导致了vip升级, 方法已经把vip设为了新的vip
     * @param amount
     * @param vips
     * @return 最新的vip经验
     */
    public int addVipExp(int amount, Vips vips){
        if (amount < 0){
            throw new IllegalArgumentException("要增加vip经验时,要增加的数额是负的");
        }

        if ((vipExp += amount) < 0 || vipExp > VariableConfig.VIP_EXP_MAX_VALUE){
            // overflow
            vipExp = VariableConfig.VIP_EXP_MAX_VALUE;
        }

        this.vip = vips.getVipLevelByExp(vipExp);
        return vipExp;
    }

    // --- 活动 ---

    public UpgradePromotionServerProto getUpgradePromotionInfo(){
        return upgradePromotionServerProto;
    }

    public void setUpgradePromotionServerProto(UpgradePromotionServerProto info){
        this.upgradePromotionServerProto = info;
    }

    public RechargeRebateServerProto getRechargeRebateInfo(){
        return rechargeRebateServerProto;
    }

    public void setRechargeRebateInfo(RechargeRebateServerProto info){
        this.rechargeRebateServerProto = info;
    }

    @MultiThread
    public boolean hasCollectedRankPromotionPrize(long endTime){
        for (int i = collectedRankPromotionPrize.size(); --i >= 0;){
            long crp = collectedRankPromotionPrize.get(i);
            if (crp == endTime){
                return true;
            }
        }
        return false;
    }

    public void addCollectedRankPromotionPrize(long endTime){
        collectedRankPromotionPrize.add(endTime);
    }

    // ----------- encode & decode -----------

    public boolean isHasFinishedPhoneCheck(){
        return hasFinishedPhoneCheck;
    }

    public void setHasFinishedPhoneCheck(boolean hasFinishedPhoneCheck){
        this.hasFinishedPhoneCheck = hasFinishedPhoneCheck;
    }

    public static Hero decodeWithoutMinorData(long id, byte[] heroName,
            HeroServerProto proto, long ctime, ConfigService configService){
        Race race = configService.getRaces().getRace(proto.getRace());
        if (race == null){
            logger.error("英雄的职业没找到: {}", proto.getRace());
            throw new RuntimeException("proto中英雄的职业没找到: " + proto.getRace());
        }

        SpellList spellList = SpellList
                .decode(proto, configService, true, null);

        HeroLevelData levelData = configService.getHeroLevelDatas().get(
                proto.getFightData().getLevel());
        FightData fightData = FightData.decode(proto.getFightData(),
                levelData.getBaseStat(), configService.getFightStates(), ctime);
        Hero result = new Hero(id, heroName, race, fightData, spellList,
                levelData, null, 0, true, String.valueOf(IDUtils.getUserID(id)));

        GoodsContainerUnlockData depotUnlockData = configService
                .getUnlockDatas().getDepotUnlockData(
                        proto.getDepot().getOpenSlotCount());
        result.depot = Depot
                .newDepotWithGoodsContainerUnlockData(depotUnlockData);

        if (proto.hasStorage()){
            GoodsContainerUnlockData storageUnlockData = configService
                    .getUnlockDatas().getStorageUnlockData(
                            proto.getStorage().getOpenSlotCount());
            result.storage = Storage
                    .newStorageWithGoodsContainerUnlockData(storageUnlockData);
        }

        result.parseHeroServerProto(proto, configService, ctime, null);
        long cityEndTime = proto.getGuildCityEndTime();
        if (cityEndTime > ctime){
            result.model.setCityMasterEndTime(cityEndTime);
        }

        result.calculateProperties();
        fightData.limitLifeAndStaminaToMax();
        return result;
    }

    private void parseHeroServerProto(HeroServerProto proto,
            ConfigService configService, long ctime,
            IntValueLongHashMap goodsCountMap){
        this.exp = proto.getExp();
        this.vipExp = proto.getVipExp();
        this.vip = configService.getVips().getVipLevelByExp(this.vipExp);

        this.hasRecharged = proto.getHasRechargedYuanbao();

        decodeEquipment(proto, configService, goodsCountMap);

        this.realAir = proto.getRealAir();

        // 英雄初始化有默认的pk模式，如果这里找不到，就不设置了
        PkMode mode = PkMode.valueOf(proto.getPkMode());
        if (mode != null){
            this.pkMode = mode;
        }

        this.pkAmount = proto.getPkAmount();
        if (this.pkAmount > 0){
            this.nextReducePkAmountTime = ctime
                    + VariableConfig.PK_AMOUNT_REDUCE_INTERVAL
                    - proto.getPkAmountAccTime();
        }

        this.reliveProtectedEndTime = proto.getReliveProtectedEndTime();

        // 坐骑
        decodeMount(proto, configService, ctime, goodsCountMap);

        // 神兵
        decodeSuperWeapon(proto, configService);

        // 弓箭
        decodeBow(proto, configService, ctime);

        // 天劫
        decodeTianJie(proto, configService, ctime);

        // 天罪
        decodeTianZui(proto, configService, ctime);

        // 宠物
        decodePet(proto, configService, ctime, tianjie);

        // 宝石
        if (proto.hasGem()){
            gem = HeroGem.decode(this, proto.getGem(), configService,
                    goodsCountMap);
        }

        // 加属性药品
        decodeLimitCountGoods(proto, configService);
    }

    private void parseHeroMinorProto(HeroMinorProto proto,
            ConfigService configService, long ctime,
            IntValueLongHashMap goodsCountMap){
        // --- 活动 ---
        this.rechargeRebateServerProto = proto.getRechargeRebateInfo();
        this.upgradePromotionServerProto = proto.getUpgradePromotionInfo();

        this.collectedVipPrize = proto.getCollectedVipPrize();
        this.nextCollectVipWeeklyPrizeTime = proto
                .getNextCollectVipWeeklyPrizeTime();

        this.money = proto.getMoney();
        this.yuanbao = proto.getYuanbao();
        this.bindedYuanbao = proto.getBindedYuanbao();

        this.lijin = proto.getLijin();
        this.lastLogoutTime = proto.getLastLogoutTime();
        // --- 副本 ---
        // 进入副本前场景/坐标
        this.beforeDungeonSceneID = proto.getBeforeDungeonSceneId();
        this.beforeDungeonX = proto.getBeforeDungeonX();
        this.beforeDungeonY = proto.getBeforeDungeonY();
        this.clusterSceneUUID = proto.getClusterUuid();

        for (int i = 0; i < proto.getAdmiredHerosCount(); i++){
            this.admiredHeros.add(proto.getAdmiredHeros(i));
        }
        this.levelUpdateTime = proto.getLevelUpdateTime();
        this.taskFuncBitData = proto.getTaskFuncBits();
        this.clientFuncBitData = proto.getClientFuncBits();
        this.isTeamAutoAcceptInvite = proto.getTeamAutoAcceptInvite();
        this.isTeamAutoAcceptRequest = proto.getTeamAutoAcceptRequest();
        this.isForbidOtherInviteMeJoinTeam = proto
                .getTeamForbidOtherInviteMeJoin();
        this.isTradeAutoReject = proto.getTradeAutoRejectInvite();
        this.isGuildAutoAccept = proto.getGuildAutoAcceptInvite();
        this.isForbidOtherInviteMeJoinGuild = proto
                .getGuildForbidOtherInviteMeJoin();

        this.guildLilian = proto.getGuildLiLian();
        this.lastBeenAddBlackTime = proto.getLastBeenAddBlackTime();
        this.beenAddBlackCount = proto.getBeenAddBlackTime();

        this.clientOnlyConfig1 = proto.getClientOnlyConfig1();

        int loopCount = Math.min(VariableConfig.CLIENT_INT_CONFIG_COUNT,
                proto.getClientOnlyIntConfigsCount());
        for (int i = 0; i < loopCount; i++){
            this.clientOnlyIntConfigs[i] = proto.getClientOnlyIntConfigs(i);
        }

        this.accumulatedOfflineTime = proto.getAccumulatedOfflineTime();
        this.lastAddAccumulatedOfflineTime = proto
                .getLastAddAccumulatedOfflineTime();

        this.accumulatedOnlineTime = proto.getAccumulatedOnlineTime();

        this.lastResetDailyTime = proto.getLastResetDailyTime();
        this.lastResetMonthlyTime = proto.getLastResetMonthlyTime();

        this.tradeNextCanGetExpTime = proto.getTradeNextCanGetExpTime();
        this.auctionNextCanGetExpTime = proto.getAuctionNextCanGetExpTime();

        this.strongSpeechLimitEndTime = proto.getStrongSpeechLimitEndTime();
        this.autoSpeechEndTime = proto.getAutoSpeechLimitEndTime();
        this.lastReadPrivateMessageTime = proto.getReadPrivateChatTime();
        this.isCrossSingleStory = proto.getIsCrossSingleStory();

        // --- 剧情副本 ---
        SceneDatas storySceneDatas = configService.getScenes();
        for (int i = proto.getStoryDungeonProtoCount(); --i >= 0;){
            StoryDungeonStat stat = StoryDungeonStat.decode(proto
                    .getStoryDungeonProto(i));

            if (storySceneDatas.get(stat.dungeonID) == null){
                // 配置被删了
                continue;
            }
            this.storyDungeonStat.put(stat.dungeonID, stat);
        }

        for (int i = 0; i < proto.getStoryDungeonCollectablePrizeProtoCount(); i++){
            StoryDungeonCollectablePrizeProto storyCollectable = proto
                    .getStoryDungeonCollectablePrizeProto(i);
            if (storyCollectable.getExpireTime() <= ctime
                    || storySceneDatas
                            .getStory(storyCollectable.getDungeonId()) == null){
                continue; // 过期或已经不存在
            }
            this.storyDungeonCollectablePrize.add(storyCollectable);
        }

        int storyID = proto.getAutoFinishStoryId();
        if (storyID > 0){
            if (storySceneDatas.getStory(storyID) != null){
                if (this.vip != null && this.vip.isStoryAutoFinishZeroTime()){
                    // 如果当前是v8, 则自动完成之前正在扫荡的副本, 也不再解析是否是自动扫荡中
                    StoryDungeonCollectablePrizeProto prizeProto = StoryDungeonSceneData
                            .newCollectablePrizeProto(storyID, ctime);
                    this.addStoryDungeonCollectablePrize(prizeProto);
                } else{
                    this.autoFinishStoryID = storyID;
                    this.autoFinishStoryCompleteTime = proto
                            .getAutoFinishStoryCompleteTime();
                    this.isAutoFinishAllStory = proto.getIsAutoFinishAllStory();
                }
            } else{
                logger.error("英雄decode时找不到他之前正在扫荡的副本: {}", storyID);
            }
        }

        // --- 挑战侠士 ---
        this.finishedChallengeDungeonSequence = proto
                .getFinishedChallengeDungeonSequenceId();

        // --- vip副本 ---
        for (int i = proto.getFinishedVipDungeonIdCount(); --i >= 0;){
            this.todayFinishedVipDungeonIDList.add(proto
                    .getFinishedVipDungeonId(i));
        }

        // --- 守护孔慈 ---
        this.defenceTodayFinishedBatch = proto.getDefenceTodayFinishedBatch();
        this.defenceHistoryMaxBatch = proto.getDefenceHistoryMaxBatch();
        this.defenceTodayResetCount = proto.getDefenceTodayResetCount();
        this.defenceCollectedFirstPassPrize = proto
                .getDefenceCollectedFirstPassPrize();

        // 孔慈可领取奖励
        decodeDefenceCollectablePrize(this, proto, configService, ctime);

        // --- 搜神宫 ---
        this.souShenPoint = proto.getSouShenPoint();
        for (int i = proto.getSouShenTodayPassedIdCount(); --i >= 0;){
            this.souShenTodayPassedSceneID
                    .add(proto.getSouShenTodayPassedId(i));
        }
        for (int i = proto.getSouShenLifePassedIdCount(); --i >= 0;){
            this.souShenLifePassedSceneID.add(proto.getSouShenLifePassedId(i));
        }
        this.souShenPointTodayUsedAmount = proto
                .getSouShenPointTodayUsedAmount();

        int c = Math.min(proto.getSouShenBoughtGoodsCountCount(),
                proto.getSouShenBoughtGoodsIdCount());
        for (int i = 0; i < c; i++){
            int sid = proto.getSouShenBoughtGoodsId(i); // 不检验id是否还存在, 就算不存在最多多存一天
            int scount = proto.getSouShenBoughtGoodsCount(i);
            this.souShenGoodsTodayBoughtCount.put(sid, new GoodsBoughtEntry(
                    sid, scount));
        }

        c = Math.min(proto.getExchangeBoughtGoodsCountCount(),
                proto.getExchangeBoughtGoodsIdCount());
        for (int i = 0; i < c; i++){
            int sid = proto.getExchangeBoughtGoodsId(i); // 不检验id是否还存在, 就算不存在最多多存一天
            int scount = proto.getExchangeBoughtGoodsCount(i);
            this.exchangeGoodsTodayBoughtCount.put(sid, new GoodsBoughtEntry(
                    sid, scount));
        }

        // --- 凌云窟 ---
        this.lingYunTodayFinishedTimes = proto.getLingYunTodayFinishedTimes();

        // 组队副本统一临时可领取奖励

        GroupDungeonsWithPrizeConfig groupDungeonWithPrizeConfig = configService
                .getGroupDungeonWithPrizeConfig();
        for (int i = 0; i < proto.getGroupCollectablePrizeProtoCount(); i++){
            GroupDungeonCollectablePrizeProto collectableProto = proto
                    .getGroupCollectablePrizeProto(i);
            if (collectableProto.getExpireTime() <= ctime){
                continue;
            }

            if (groupDungeonWithPrizeConfig
                    .get(collectableProto.getDungeonId()) == null){
                // 奖励已经没有了, 副本id改了或者删了
                logger.error("玩家登录时, 他之前有的组队副本奖励没了. 副本id: {}",
                        collectableProto.getDungeonId());
                continue;
            }

            this.groupDungeonCollectablePrize.add(collectableProto);
        }

        // --- 守护龙脉 ---

        this.longMaiTodayFirstPassed = proto.getLongMaiTodayFirstPassed();

        // --- 无绝神阵 ---
        this.wuJueTodayEnteredTimes = proto.getWuJueTodayEnteredTimes();

        // --- 火麟洞 ---
        this.huoLinCombatServerID = proto.getHuoLinCombatServerId();
        this.huoLinSceneDataID = proto.getHuoLinSceneDataId();
        this.huoLinSceneUUID = proto.getHuoLinSceneUuid();
        this.huoLinAccumulatedExp = proto.getHuoLinAccumulatedExp();
        this.huoLinAccumulatedRealAir = proto.getHuoLinAccumulatedRealAir();
        this.huoLinActivityEndTime = proto.getHuoLinActivityEndTime();

        // --- 板块战 ---
        for (int i = 0; i < proto.getTerritoryTodayCollectedPrizeSceneIdCount(); i++){
            this.territoryTodayCollectedPrizeSceneID.add(proto
                    .getTerritoryTodayCollectedPrizeSceneId(i));
        }

        HeroInfoProto thip = proto.getTerritoryHeroInfo();
        if (thip != null && thip.getBattleEndTime() > ctime){
            this.territoryHeroInfo.decode(thip);
        }

        HeroInfoProto ghip = proto.getGuildCityHeroInfo();
        if (ghip != null && ghip.getBattleEndTime() > ctime){
            guildCityHeroInfo.decode(ghip);
        }

        HeroInfoProto lhip = proto.getLongCityHeroInfo();
        if (lhip != null && lhip.getBattleEndTime() > ctime){
            longCityHeroInfo.decode(lhip);
        }

        loginDay = proto.getLoginDay();
        shengWang = proto.getShengWang();
        shengWangExchangeBits = shengWang & ((1 << 16) - 1);
        shengWang = shengWang >>> 16;

        for (int task : proto.getShengWangTaskList()){
            shengwangMap.put(task & 255, task >>> 8);
        }

        for (int result : proto.getDailyActivityResultList()){
            dailyActivityBuybackMap.put(result >>> 1, result & 1);
        }

        // --- minorProto ---

        this.isCollectLocalLoginFirstPrize = proto
                .getIsCollectLocalLoginFirstPrize();

        this.isCollectLocalLoginDailyPrize = proto
                .getIsCollectLocalLoginDailyPrize();

        this.useFreeChatTimes = proto.getUseFreeChatTimes();

        this.welfare.decode(proto, configService);
        this.dailyOnlineAccTime = proto.getDailyOnlineAccTime();

        this.jijianEndTime = proto.getJijianVersion();
        this.jijianAccExp = proto.getJijianAccExp();
        this.jijianAccRealAir = proto.getJijianAccRealAir();
        this.jijianMoneyTimes = proto.getJijianMoneyTimes();
        this.jijianYuanbaoTimes = proto.getJijianYuanbaoTimes();
        this.jijianAccFreeloadRealAir = proto.getJijianAccFreeloadRealAir();
        this.jijianYuanbaoTotalTimes = proto.getJijianTotalYuanbaoTimes();
        this.jijianUpdateTime = proto.getJijianUpdateTime();
        this.jijianSceneId = proto.getJijianSceneId();

        // 回购物品
        for (int i = 0; i < proto.getBuyBackGoodsListCount(); i++){
            long expireTime = proto.getBuyBackGoodsExpireTime(i);
            if (expireTime <= ctime){
                continue;
            }

            GoodsServerProto goodsProto = proto.getBuyBackGoodsList(i);
            Goods g = Goods.decodeDontCheck(goodsProto, configService);
            if (g == null){
                continue;
            }

            this.buyBackGoodsList.add(BuyBackGoods.newBuyBackGoods(g,
                    expireTime));
        }

        // 知天命
        this.divination.decode(proto.getDivination(), configService,
                goodsCountMap);

        // 任务
        this.taskList = HeroTaskList.decode(fightData.getLevel(), race,
                proto.getTaskList(), configService);

        this.totalRechargeYuanbao = proto.getTotalRechargeYuanbao();

        // 挑战侠士次数
        challengeDungeonDailyTimes = proto.getChallengeDungeonDailyTimes();
        challengeDungeonAssistTimes = proto.getChallengeDungeonAssistTimes();
        for (int useTime : proto.getChallengeDungeonUseTimesList()){
            challengeDungeonUseTime.add(useTime);
        }

        meltAmount = proto.getMeltAmount();

        phoenixMoneyRefineTimes = proto.getPhoenixMoneyRefineTimes();
        phoenixLijinRefineTimes = proto.getPhoenixLijinRefineTimes();
        phoenixYuanbaoRefineTimes = proto.getPhoenixYuanbaoRefineTimes();

        challengeTimes = proto.getChallengeTimes();
        challengeAddTimes = proto.getChallengeAddTimes();
        challengeRefinedTimes = proto.getChallengeRefinedTimes();
        nextCanChallengeTime = proto.getNextCanChallengeTime();
        hasChallengeFatigue = proto.getHasChallengeFatigue();
        hasCollectedChallengeDailyPrize = proto.getHasCollectedChallengePrize();

        honorPoint = proto.getHonor();

        oneTimesCouponCollected = proto.getCollectedCoupon();
        unlimitedCouponCollectedTimes = proto
                .getUnlimitedCouponCollectedTimes();

        c = Math.min(proto.getGlobalMailIdCount(),
                proto.getGlobalMailSendTimeCount());
        for (int i = 0; i < c; i++){
            globalMail.put(proto.getGlobalMailId(i),
                    proto.getGlobalMailSendTime(i));
        }

        todayLoginTime = proto.getTodayLoginTime();

        firstRechargeCollectIndex = proto.getFirstRechargeCollectIndex();

        loginPrizeInfo = proto.getLoginPrizeInfo();

        investUpgradeBankMoney = proto.getInvestUpgradeBankMoney();

        c = Math.min(proto.getCollectUpgradeBankLevelCount(),
                proto.getCollectUpgradeBankLijinCount());
        for (int i = 0; i < c; i++){
            collectUpgradeBankMap.put(proto.getCollectUpgradeBankLevel(i),
                    proto.getCollectUpgradeBankLijin(i));
        }

        investMonthlyBankMoney = proto.getInvestMonthlyBankMoney();
        investMonthlyBankTime = proto.getInvestMonthlyBankTime();
        monthlyBankPrevCollectTime = proto.getMonthlyBankPrevCollectTime();
        monthlyBankPrevCollectTime2 = proto.getMonthlyBankPrevCollectTime2();
        monthlyBankOnlineLijin = proto.getMonthlyBankOnlineLijin();
        monthlyBankPrevDayOnlineLijin = proto
                .getMonthlyBankPrevDayOnlineLijin();
        monthlyBankOnlineHours = proto.getMonthlyBankOnlineHours();

        c = Math.min(proto.getSinglePvipPrizeIdCount(),
                proto.getSinglePvipPrizeInfoCount());
        for (int i = 0; i < c; i++){
            singlePVipPrizeMap.put(proto.getSinglePvipPrizeId(i),
                    proto.getSinglePvipPrizeInfo(i));
        }

        c = Math.min(proto.getDailyPvipPrizeIdCount(),
                proto.getDailyPvipPrizeInfoCount());
        for (int i = 0; i < c; i++){
            dailyPVipPrizeMap.put(proto.getDailyPvipPrizeId(i),
                    proto.getDailyPvipPrizeInfo(i));
        }

        //平台加速
        this.hasCollectedPlatformEverydayPrize = proto
                .getHasCollectedPlatformEverydayPrize();

        this.hasFinishedPhoneCheck = proto.getHasFinishedPhoneCheck();

        for (int i = 0; i < proto.getBankLogCount(); i++){
            bankLogs.addLast(proto.getBankLog(i));
        }

        c = Math.min(proto.getCritCardBuffEndTimeCount(),
                proto.getCritCardBuffGoodsIdCount());
        for (int i = 0; i < c; i++){
            long endTime = proto.getCritCardBuffEndTime(i);
            if (ctime < endTime){
                int goodsId = proto.getCritCardBuffGoodsId(i);
                CritCardData data = configService.getGoods().getCritCard(
                        goodsId);
                if (data != null){
                    CritCardBuff buff = data.newBuff(endTime);

                    critCardBuffMap.put(buff.getType(), buff);
                }
            }
        }

        canSeeShowGirl = proto.getCanSeeShowGirl();
        collectedPlatformPrize = proto.getCollectedPlatformPrize();
        totalOnlineAccTime = proto.getTotalOnlineTime();
        isGm = proto.getIsGm();

        for (int i = 0; i < proto.getCollectedRankPromotionPrizeCount(); i++){
            long crp = proto.getCollectedRankPromotionPrize(i);
            collectedRankPromotionPrize.add(crp);
        }

        c = Math.min(proto.getChatOtherIdCount(), proto.getChatOtherTimeCount());
        for (int i = 0; i < c; i++){
            long time = proto.getChatOtherTime(i);
            if (ctime - time < VariableConfig.P2P_CHAT_BAN_CHECK_INTERVAL){
                long id = proto.getChatOtherId(i);
                chatOtherMap.putIfAbsent(id, new LongLongHolder(id, time));
            }
        }
    }

    static Hero decode(long id, byte[] heroName, HeroServerProto proto,
            HeroMinorProto minorProto, byte[] relationData, String uin,
            long ctime, ConfigService configService)
            throws InvalidProtocolBufferException{
        Race race = configService.getRaces().getRace(proto.getRace());
        if (race == null){
            logger.error("英雄的职业没找到: {}", proto.getRace());
            throw new RuntimeException("proto中英雄的职业没找到: " + proto.getRace());
        }

        // 物品记录
        GoodsOwnershipProto goodsOwnershipProto = minorProto
                .getGoodsOwnership();
        // 用于检测物品是否存在
        IntValueLongHashMap goodsCountMap = new IntValueLongHashMap();
        GoodsOwnership.fillGoodsCountMap(goodsOwnershipProto, goodsCountMap);

        RelationList relationList = RelationList.decode(relationData);
        SpellList spellList = SpellList.decode(proto, configService, false,
                goodsCountMap);

        HeroLevelData levelData = configService.getHeroLevelDatas().get(
                proto.getFightData().getLevel());
        FightData fightData = FightData.decode(proto.getFightData(),
                levelData.getBaseStat(), configService.getFightStates(), ctime);
        Hero result = new Hero(id, heroName, race, fightData, spellList,
                levelData, relationList, proto.getCreateTime(), false, uin);

        // 物品记录
        result.goodsOwnership.decode(goodsOwnershipProto);

        result.depot = Depot.decodeDepot(proto.getDepot(),
                minorProto.getDepot(), configService, ctime, goodsCountMap);

        if (proto.hasStorage()){
            // 仓库在完成某个任务时候才开放
            result.storage = Storage.decodeStorage(proto.getStorage(),
                    minorProto.getStorage(), configService, ctime,
                    goodsCountMap);
        } else{
            if (result.isTaskFuncOpened(TaskRelatedFunction.FUNC_STORAGE)){
                result.storage = Storage.newStorage(ctime);
            }
        }

        result.parseHeroServerProto(proto, configService, ctime, goodsCountMap);

        result.parseHeroMinorProto(minorProto, configService, ctime,
                goodsCountMap);

        result.calculateProperties();
        fightData.limitLifeAndStaminaToMax();
        return result;
    }

    /**
     * decode守护孔慈的可领取奖励
     *
     * @param result
     * @param proto
     * @param configService
     * @param ctime
     */
    private static void decodeDefenceCollectablePrize(Hero result,
            HeroMinorProto proto, ConfigService configService, long ctime){
        int defencePrizeCount = Utils.min(
                proto.getDefenceCollectablePrizeStartBatchCount(),
                proto.getDefenceCollectablePrizeEndBatchCount(),
                proto.getDefenceCollectablePrizeExpireTimeCount());

        DefenceDungeonSceneData defenceDungeonSceneData = configService
                .getDefenceDungeonSceneData();
        for (int i = defencePrizeCount; --i >= 0;){
            long expireTime = proto.getDefenceCollectablePrizeExpireTime(i);
            if (ctime >= expireTime){
                // 过期
                continue;
            }

            int endBatch = proto.getDefenceCollectablePrizeEndBatch(i);
            if (endBatch > defenceDungeonSceneData.getTotalBatch()){
                logger.error(
                        "decode英雄孔慈可领取的奖励时, 要的batch已经没有了... 配置减少了: 要{}波, 但总共只有{}波",
                        endBatch, defenceDungeonSceneData.getTotalBatch());
                continue;
            }

            DefenceBatchInfo batchInfo = defenceDungeonSceneData
                    .getBatch(endBatch);
            assert batchInfo != null;
            int startBatch = proto.getDefenceCollectablePrizeStartBatch(i);
            DefenceCollectablePrize prize = batchInfo
                    .getDefenceCollectablePrize(startBatch);
            result.defenceCollectablePrize
                    .add(prize.withExpireTime(expireTime));
        }
    }

    private void decodeMount(HeroServerProto proto,
            ConfigService configService, long ctime,
            IntValueLongHashMap goodsCountMap){

        // 坐骑
        if (proto.hasMount()){
            mount = HeroMount.decode(getLevel(), proto.getMount(), ctime,
                    configService, goodsCountMap);

            if (mount != null){
                // 换装
                onBestMountChanged(mount.getBestMountId());

                if (mount.isRiding()){
                    replaceEquipmentResources(ModelType.MOUNT,
                            mount.getMountResource());
                }
            }

        }
    }

    private void decodeSuperWeapon(HeroServerProto proto,
            ConfigService configService){
        // 神兵
        for (int i = 0; i < proto.getSuperWeaponCount(); i++){

            HeroSuperWeapon weapon = HeroSuperWeapon.decode(
                    proto.getSuperWeapon(i), configService);

            if (weapon == null){
                continue;
            }

            superWeapons[weapon.getId() - 1] = weapon;
        }

        if (proto.getUsingWeapon() > 0
                && proto.getUsingWeapon() <= superWeapons.length){
            HeroSuperWeapon weapon = superWeapons[proto.getUsingWeapon() - 1];

            if (weapon != null){
                usingWeapon = weapon.getData();
                replaceEquipmentResources(ModelType.SUPER_WEAPON,
                        weapon.getId());
            }
        }
    }

    private void decodeBow(HeroServerProto proto, ConfigService configService,
            long ctime){
        // 弓箭
        if (proto.hasBow()){
            bow = HeroBow.decode(proto.getBow(), configService, ctime);
            if (bow != null){
                // 换装
                replaceEquipmentResources(ModelType.BOW, bow.getBowResource());

                onBestBowChanged(bow.getBowId());
            }
        }
    }

    private void decodePet(HeroServerProto proto, ConfigService configService,
            long ctime, HeroTianJie tianjie){
        // 宠物
        if (proto.hasPet()){
            pet = HeroPet.decode(proto.getPet(), configService, getLevel(),
                    ctime, tianjie);
        }
    }

    private void decodeTianJie(HeroServerProto proto,
            ConfigService configService, long ctime){
        // 天劫
        if (proto.hasTianJie()){
            tianjie = HeroTianJie.decode(proto.getTianJie(), ctime,
                    configService);
        }
    }

    private void decodeTianZui(HeroServerProto proto,
            ConfigService configService, long ctime){
        // 天罪
        if (proto.hasTianZui()){
            tianzui = HeroTianZui.decode(proto.getTianZui(), ctime,
                    configService);
        }
    }

    private void decodeLimitCountGoods(HeroServerProto proto,
            ConfigService configService){
        // 加属性物品
        int statGoodsCount = Math.min(proto.getLimitCountGoodsIdCount(),
                proto.getLimitCountGoodsUseTimesCount());
        for (int i = 0; i < statGoodsCount; i++){
            int goodsId = proto.getLimitCountGoodsId(i);
            GoodsData goodsData = configService.getGoods().get(goodsId);

            int goodsCount = proto.getLimitCountGoodsUseTimes(i);
            if (goodsData == null){
                useLimitCountGoodsMap.put(goodsId, new GoodsDataCount(goodsId,
                        goodsCount));
            } else{
                useLimitCountGoodsMap.put(goodsId, new GoodsDataCount(
                        goodsData, goodsCount));
            }
        }
    }

    private void decodeEquipment(HeroServerProto proto,
            ConfigService configService, IntValueLongHashMap goodsCountMap){
        int count = Math.min(proto.getEquipedPosCount(),
                proto.getEquipmentsCount());

        int depotStartIndex = 0;
        int storageStartIndex = 0;
        IntHashMap<TaozData> taozDataMap = null;
        for (int i = 0; i < count; i++){
            int pos = proto.getEquipedPos(i);
            Goods g = Goods.decode(proto.getEquipments(i), configService,
                    goodsCountMap);

            if (g == null){
                continue;
            }

            if (pos < 0 || pos >= equipmentList.length
                    || !(g instanceof Equipment) || equipmentList[pos] != null){
                if (depot != null){
                    int idx = depot.addToEmptyPos(depotStartIndex, g);
                    if (idx >= 0){
                        depotStartIndex = idx + 1;
                        continue;
                    }

                    depotStartIndex = depot.size() + 1;
                }

                if (storage != null){
                    int idx = storage.addToEmptyPos(storageStartIndex, g);
                    if (idx >= 0){
                        storageStartIndex = idx + 1;
                        continue;
                    }

                    storageStartIndex = storage.size() + 1;
                }

                // 我已经无能为力了，丢就丢了吧
                logger.error("英雄{}-{}在decode装备的时候丢了一件装备 {}", id,
                        StringEncoder.encode(nameBytes), g);
                continue;
            }

            Equipment equipment = equipmentList[pos] = (Equipment) g;
            if (equipment.getData().getResource() > 0){
                if (equipment.isWeapon()){
                    replaceEquipmentResources(ModelType.WEAPON, equipment
                            .getData().getResource());
                } else if (equipment.isArmor()){
                    replaceEquipmentResources(ModelType.ARMOR, equipment
                            .getData().getResource());
                }
            }

            if (equipment.getData().getTaoz() != null){
                if (taozDataMap == null){
                    taozDataMap = new IntHashMap<>(4);
                }

                taozDataMap.putIfAbsent(equipment.getData().getTaoz().id,
                        equipment.getData().getTaoz());
            }
        }

        checkEquipmentExtraStat(configService.getExtraStats());

        if (taozDataMap != null){
            for (TaozData data : taozDataMap.values()){
                checkTaozStat(data, null);
            }
        }
    }

    public HeroBinaryData getHeroBinaryData(long ctime, long userInfo){
        byte[] heroData = encodeHeroServerProto(ctime).toByteArray();
        byte[] heroMinorData = encodeMinorData(ctime).toByteArray();
        return new HeroBinaryData(id, encodeEasyInfo(), heroData,
                heroMinorData, userInfo);
    }

    public HeroMinorProto encodeMinorData(long ctime){
        HeroMinorProto.Builder builder = HeroMinorProto
                .newBuilder()
                .setDailyOnlineAccTime(dailyOnlineAccTime)
                .setIsCollectLocalLoginFirstPrize(isCollectLocalLoginFirstPrize)
                .setIsCollectLocalLoginDailyPrize(isCollectLocalLoginDailyPrize)
                .setHasCollectedPlatformEverydayPrize(
                        hasCollectedPlatformEverydayPrize)
                .setHasFinishedPhoneCheck(hasFinishedPhoneCheck)
                .setUseFreeChatTimes(useFreeChatTimes)
                .setJijianVersion(jijianEndTime)
                .setJijianAccExp(jijianAccExp)
                .setJijianAccRealAir(jijianAccRealAir)
                .setJijianMoneyTimes(jijianMoneyTimes)
                .setJijianYuanbaoTimes(jijianYuanbaoTimes)
                .setJijianAccFreeloadRealAir(jijianAccFreeloadRealAir)
                .setJijianTotalYuanbaoTimes(jijianYuanbaoTotalTimes)
                .setJijianUpdateTime(jijianUpdateTime)
                .setJijianSceneId(jijianSceneId)
                .setTeamAutoAcceptInvite(isTeamAutoAcceptInvite)
                .setTeamAutoAcceptRequest(isTeamAutoAcceptRequest)
                .setTeamForbidOtherInviteMeJoin(isForbidOtherInviteMeJoinTeam)
                .setTradeAutoRejectInvite(isTradeAutoReject)
                .setGuildAutoAcceptInvite(isGuildAutoAccept)
                .setGuildForbidOtherInviteMeJoin(isForbidOtherInviteMeJoinGuild)
                .setClientOnlyConfig1(clientOnlyConfig1)
                .setLastResetDailyTime(lastResetDailyTime)
                .setLastResetMonthlyTime(lastResetMonthlyTime)
                .setGuildLiLian(guildLilian)
                .setAccumulatedOfflineTime(accumulatedOfflineTime)
                .setLastAddAccumulatedOfflineTime(lastAddAccumulatedOfflineTime)
                .setTaskFuncBits(taskFuncBitData)
                .setClientFuncBits(clientFuncBitData)
                .setIsCrossSingleStory(isCrossSingleStory)
                .setLevelUpdateTime(levelUpdateTime)
                .setAccumulatedOnlineTime(accumulatedOnlineTime)
                .setYuanbao(yuanbao)
                .setBindedYuanbao(bindedYuanbao)
                .setLijin(lijin)
                .setMoney(money)
                .setLastLogoutTime(lastLogoutTime)
                .setBeforeDungeonSceneId(beforeDungeonSceneID)
                .setBeforeDungeonX(beforeDungeonX)
                .setBeforeDungeonY(beforeDungeonY)
                .setClusterUuid(clusterSceneUUID)
                .setCollectedVipPrize(collectedVipPrize)
                .setNextCollectVipWeeklyPrizeTime(nextCollectVipWeeklyPrizeTime);

        builder.setCollectedVipPrize(collectedVipPrize);
        builder.setNextCollectVipWeeklyPrizeTime(nextCollectVipWeeklyPrizeTime);

        for (BuyBackGoods buyBackGoods : buyBackGoodsList){
            if (buyBackGoods.expireTime <= ctime){
                continue;
            }

            builder.addBuyBackGoodsList(buyBackGoods.goods.encode())
                    .addBuyBackGoodsExpireTime(buyBackGoods.expireTime);
        }

        builder.setTaskList(taskList.encode());

        // --- 剧情副本 ---
        for (storyDungeonStatIte.rewind(); storyDungeonStatIte.hasNext();){
            builder.addStoryDungeonProto(storyDungeonStatIte.next().encode());
        }
        storyDungeonStatIte.cleanUp();

        for (StoryDungeonCollectablePrizeProto proto : storyDungeonCollectablePrize){
            builder.addStoryDungeonCollectablePrizeProto(proto);
        }

        if (autoFinishStoryID > 0){
            builder.setAutoFinishStoryId(autoFinishStoryID)
                    .setAutoFinishStoryCompleteTime(autoFinishStoryCompleteTime)
                    .setIsAutoFinishAllStory(isAutoFinishAllStory);
        }

        // --- 挑战侠士 ---
        builder.setFinishedChallengeDungeonSequenceId(finishedChallengeDungeonSequence);

        // --- vip 副本 ---
        for (int i = todayFinishedVipDungeonIDList.size(); --i >= 0;){
            builder.addFinishedVipDungeonId(todayFinishedVipDungeonIDList
                    .get(i));
        }

        // --- 守护孔慈 ---
        builder.setDefenceTodayFinishedBatch(defenceTodayFinishedBatch)
                .setDefenceHistoryMaxBatch(defenceHistoryMaxBatch)
                .setDefenceTodayResetCount(defenceTodayResetCount)
                .setDefenceCollectedFirstPassPrize(
                        defenceCollectedFirstPassPrize);

        // 孔慈可领取奖励
        DefenceCollectablePrize p;
        DefenceCollectablePrizeWithExpireTime pt;
        for (int i = defenceCollectablePrize.size(); --i >= 0;){
            pt = defenceCollectablePrize.get(i);
            p = pt.getPrize();
            builder.addDefenceCollectablePrizeStartBatch(p.startBatch);
            builder.addDefenceCollectablePrizeEndBatch(p.endBatch);
            builder.addDefenceCollectablePrizeExpireTime(pt.expireTime);
        }

        // 孔慈扫荡未领取, 加在可领取奖励的最后面
        if (defenceAutoFinishPrizeWaitingToBeCollected != null){
            long expireTime = ctime
                    + VariableConfig.DEFENCE_COLLECTABLE_PRIZE_EXPIRE_TIME;
            builder.addDefenceCollectablePrizeStartBatch(0)
                    .addDefenceCollectablePrizeEndBatch(
                            defenceAutoFinishPrizeWaitingToBeCollected.endBatch)
                    .addDefenceCollectablePrizeExpireTime(expireTime);
        }

        // --- 搜神宫 ---
        builder.setSouShenPoint(souShenPoint);
        for (int i = souShenTodayPassedSceneID.size(); --i >= 0;){
            builder.addSouShenTodayPassedId(souShenTodayPassedSceneID.get(i));
        }

        for (int i = souShenLifePassedSceneID.size(); --i >= 0;){
            builder.addSouShenLifePassedId(souShenLifePassedSceneID.get(i));
        }

        builder.setSouShenPointTodayUsedAmount(souShenPointTodayUsedAmount);
        for (GoodsBoughtEntry entry : souShenGoodsTodayBoughtCount.values()){
            builder.addSouShenBoughtGoodsId(entry.id)
                    .addSouShenBoughtGoodsCount(entry.count);
        }

        for (GoodsBoughtEntry entry : exchangeGoodsTodayBoughtCount.values()){
            builder.addExchangeBoughtGoodsId(entry.id)
                    .addExchangeBoughtGoodsCount(entry.count);
        }

        // --- 凌云窟 ---
        builder.setLingYunTodayFinishedTimes(lingYunTodayFinishedTimes);

        // --- 组队副本通用待领取奖励 ---
        for (GroupDungeonCollectablePrizeProto proto : groupDungeonCollectablePrize){
            builder.addGroupCollectablePrizeProto(proto);
        }

        // --- 守护龙脉 ---
        builder.setLongMaiTodayFirstPassed(longMaiTodayFirstPassed);

        // --- 无绝神阵 ---
        builder.setWuJueTodayEnteredTimes(wuJueTodayEnteredTimes);

        // --- 火麟洞 ---
        if (huoLinActivityEndTime > ctime){
            // 如果活动还没结束, 才存
            builder.setHuoLinCombatServerId(huoLinCombatServerID)
                    .setHuoLinSceneDataId(huoLinSceneDataID)
                    .setHuoLinSceneUuid(huoLinSceneUUID)
                    .setHuoLinLine(huoLinLine)
                    .setHuoLinAccumulatedExp(huoLinAccumulatedExp)
                    .setHuoLinAccumulatedRealAir(huoLinAccumulatedRealAir)
                    .setHuoLinActivityEndTime(huoLinActivityEndTime);
        }

        // --- 板块战 ---
        for (int i = 0; i < territoryTodayCollectedPrizeSceneID.size(); i++){
            builder.addTerritoryTodayCollectedPrizeSceneId(territoryTodayCollectedPrizeSceneID
                    .get(i));
        }

        if (territoryHeroInfo.battleEndTime > ctime){
            builder.setTerritoryHeroInfo(territoryHeroInfo.encode());
        }

        if (guildCityHeroInfo.battleEndTime > ctime){
            builder.setGuildCityHeroInfo(guildCityHeroInfo.encode());
        }

        if (longCityHeroInfo.battleEndTime > ctime){
            builder.setLongCityHeroInfo(longCityHeroInfo.encode());
        }

        builder.setLoginDay(loginDay);
        builder.setShengWang((shengWang << 16) | shengWangExchangeBits);
        for (Entry entry : shengwangMap.entrySet()){
            if (entry.getValue() > 0){
                builder.addShengWangTask(entry.getValue() << 8 | entry.getKey());
            }
        }

        for (Entry entry : dailyActivityBuybackMap.entrySet()){
            builder.addDailyActivityResult((entry.getKey() << 1)
                    | entry.getValue());
        }

        // ---

        for (long v : admiredHeros){
            builder.addAdmiredHeros(v);
        }

        for (int v : clientOnlyIntConfigs){
            builder.addClientOnlyIntConfigs(v);
        }

        if (hasEnterSceneForTheFirstTime){
            builder.setReadPrivateChatTime(ctime);
        } else{
            builder.setReadPrivateChatTime(lastReadPrivateMessageTime); // 这次没进入场景就下线了, 阅读过的私聊记录还是以前的
        }

        if (tradeNextCanGetExpTime > ctime){
            builder.setTradeNextCanGetExpTime(tradeNextCanGetExpTime);
        }

        if (auctionNextCanGetExpTime > ctime){
            builder.setAuctionNextCanGetExpTime(auctionNextCanGetExpTime);
        }

        if (autoSpeechEndTime > ctime){
            builder.setAutoSpeechLimitEndTime(autoSpeechEndTime);
        }
        builder.setLastBeenAddBlackTime(lastBeenAddBlackTime);
        builder.setBeenAddBlackTime(beenAddBlackCount);

        if (strongSpeechLimitEndTime > ctime){
            builder.setStrongSpeechLimitEndTime(strongSpeechLimitEndTime);
        }

        if (depot != null){
            builder.setDepot(depot.encodeGoodsList());
        }

        if (storage != null){
            builder.setStorage(storage.encodeGoodsList());
        }

        if (divination != null){
            builder.setDivination(divination.encode());
        }

        if (goodsOwnership != null){
            builder.setGoodsOwnership(goodsOwnership.encode());
        }

        welfare.encode(builder);

        builder.setTotalRechargeYuanbao(totalRechargeYuanbao);

        builder.setChallengeDungeonDailyTimes(challengeDungeonDailyTimes);
        builder.setChallengeDungeonAssistTimes(challengeDungeonAssistTimes);
        for (int i = 0; i < challengeDungeonUseTime.size(); i++){
            builder.addChallengeDungeonUseTimes(challengeDungeonUseTime.get(i));
        }

        builder.setMeltAmount(meltAmount);

        builder.setPhoenixMoneyRefineTimes(phoenixMoneyRefineTimes);
        builder.setPhoenixLijinRefineTimes(phoenixLijinRefineTimes);
        builder.setPhoenixYuanbaoRefineTimes(phoenixYuanbaoRefineTimes);

        builder.setChallengeTimes(challengeTimes);
        builder.setChallengeAddTimes(challengeAddTimes);
        builder.setChallengeRefinedTimes(challengeRefinedTimes);
        builder.setNextCanChallengeTime(nextCanChallengeTime);
        builder.setHasChallengeFatigue(hasChallengeFatigue);
        builder.setHasCollectedChallengePrize(hasCollectedChallengeDailyPrize);

        builder.setHonor(honorPoint);
        builder.setCollectedCoupon(oneTimesCouponCollected);
        builder.setUnlimitedCouponCollectedTimes(unlimitedCouponCollectedTimes);

        for (com.mokylin.collection.LongValueIntHashMap.Entry entry : globalMail
                .entrySet()){
            if (entry.getValue() + VariableConfig.MAIL_EXPIRE_TIME >= ctime){
                builder.addGlobalMailId(entry.getKey());
                builder.addGlobalMailSendTime(entry.getValue());
            }
        }

        builder.setTodayLoginTime(todayLoginTime);

        builder.setFirstRechargeCollectIndex(firstRechargeCollectIndex);

        builder.setLoginPrizeInfo(loginPrizeInfo);
        // --- 活动 ---

        if (rechargeRebateServerProto != null){
            builder.setRechargeRebateInfo(rechargeRebateServerProto);
        }

        if (upgradePromotionServerProto != null){
            builder.setUpgradePromotionInfo(upgradePromotionServerProto);
        }

        // 排行榜活动
        for (int i = 0; i < collectedRankPromotionPrize.size(); i++){
            long crp = collectedRankPromotionPrize.get(i);
            builder.addCollectedRankPromotionPrize(crp);
        }

        // ---

        builder.setInvestUpgradeBankMoney(investUpgradeBankMoney);
        for (Entry entry : collectUpgradeBankMap.entrySet()){
            builder.addCollectUpgradeBankLevel(entry.getKey());
            builder.addCollectUpgradeBankLijin(entry.getValue());
        }

        builder.setInvestMonthlyBankMoney(investMonthlyBankMoney);
        builder.setInvestMonthlyBankTime(investMonthlyBankTime);
        builder.setMonthlyBankPrevCollectTime(monthlyBankPrevCollectTime);
        builder.setMonthlyBankPrevCollectTime2(monthlyBankPrevCollectTime2);
        builder.setMonthlyBankOnlineLijin(monthlyBankOnlineLijin);
        builder.setMonthlyBankPrevDayOnlineLijin(monthlyBankPrevDayOnlineLijin);
        builder.setMonthlyBankOnlineHours(monthlyBankOnlineHours);

        for (Entry entry : singlePVipPrizeMap.entrySet()){
            builder.addSinglePvipPrizeId(entry.getKey());
            builder.addSinglePvipPrizeInfo(entry.getValue());
        }

        for (Entry entry : dailyPVipPrizeMap.entrySet()){
            builder.addDailyPvipPrizeId(entry.getKey());
            builder.addDailyPvipPrizeInfo(entry.getValue());
        }

        for (long log : bankLogs){
            builder.addBankLog(log);
        }

        for (CritCardBuff buff : critCardBuffMap.values()){
            if (ctime < buff.endTime){
                builder.addCritCardBuffGoodsId(buff.getId());
                builder.addCritCardBuffEndTime(buff.endTime);
            }
        }

        builder.setCanSeeShowGirl(canSeeShowGirl);
        builder.setCollectedPlatformPrize(collectedPlatformPrize);
        builder.setTotalOnlineTime(totalOnlineAccTime);

        if (isGm){
            builder.setIsGm(true);
        }

        for (LongLongHolder holder : chatOtherMap.values()){
            if (ctime - holder.getValue() < VariableConfig.P2P_CHAT_BAN_CHECK_INTERVAL){
                builder.addChatOtherId(holder.getKey());
                builder.addChatOtherTime(holder.getValue());
            }
        }

        return builder.build();
    }

    public HeroServerProto encodeHeroServerProto(long ctime){
        // 内不能不包括 id和名字
        HeroServerProto.Builder builder = HeroServerProto.newBuilder();
        builder.setFightData(fightData.encode(ctime));
        builder.setRace(race.getId());
        builder.setDepot(depot.encodeWithoutGoods(ctime));

        if (storage != null){
            // 仓库在完成某个任务时候才开放
            builder.setStorage(storage.encodeWithoutGoods(ctime));
        }

        builder.setRealAir(realAir);

        for (int i = 0; i < equipmentList.length; i++){
            Equipment equipment = equipmentList[i];
            if (equipment != null){
                builder.addEquipedPos(i).addEquipments(equipment.encode());
            }
        }

        builder.setExp(exp);

        builder.setHasRechargedYuanbao(hasRecharged);
        builder.setVipExp(vipExp);

        // 宝石，屏蔽宝石功能
//        if (gem != null){
//            builder.setGem(gem.encode());
//        }

        // 弓箭
        if (bow != null){
            builder.setBow(bow.encode());
        }

        // 神兵
        for (HeroSuperWeapon weapon : superWeapons){
            if (weapon != null){
                builder.addSuperWeapon(weapon.encode());
            }
        }

        if (usingWeapon != null){
            builder.setUsingWeapon(usingWeapon.getId());
        }

        // 加属性药品
        for (GoodsDataCount goodsIDCount : useLimitCountGoodsMap.values()){
            builder.addLimitCountGoodsId(goodsIDCount.goodsID)
                    .addLimitCountGoodsUseTimes(goodsIDCount.goodsCount);
        }

        if (tianzui != null){
            builder.setTianZui(tianzui.encode());
        }

        if (tianjie != null){
            builder.setTianJie(tianjie.encode());
        }

        if (mount != null){
            builder.setMount(mount.encode());
        }

        // 宠物
        if (pet != null){
            builder.setPet(pet.encode(ctime));
        }

        builder.setCreateTime(createTime);

        long cityMasterEndTime = model.getCityMasterEndTime();
        if (cityMasterEndTime > 0){
            builder.setGuildCityEndTime(cityMasterEndTime);
        }

        spellList.encode(builder);

        builder.setPkMode(getIntPkMode());
        builder.setPkAmount(pkAmount);
        builder.setPkAmountAccTime(pkAmountAccTime);
        builder.setReliveProtectedEndTime(reliveProtectedEndTime);

        return builder.build();
    }

    /**
     * 新建个空的英雄, 需要初始化各种需要初始化的
     *
     * @param id
     * @param heroName
     * @return
     */
    public static Hero newHero(long id, byte[] heroName, Race race, long ctime,
            String uin){
        FightData fightData = race.newFightDataForNewHero();

        Hero result = new Hero(id, heroName, race, fightData,
                race.newSpellList(), race.initialHeroLevelData,
                RelationList.newRelationList(), ctime, false, uin);
        result.isTeamAutoAcceptInvite = true;
        result.isTeamAutoAcceptRequest = true;
        result.isGuildAutoAccept = true;

        result.depot = Depot.newDepot(ctime);

        // 任务
        result.taskList = HeroTaskList.newHeroTaskList(race.maxUseTaskId,
                race.getFirstChapterTask());

        // 状态重置时间
        result.lastResetDailyTime = ctime;
        result.lastResetMonthlyTime = ctime;

        return result;
    }

    public void writeData(ChannelBuffer buffer){
        BufferUtil.writeUTF(buffer, nameBytes);
        BufferUtil.writeProto(buffer, encodeToSelfOnLogin());
    }

    private HeroProto encodeToSelfOnLogin(){
        HeroProto.Builder builder = HeroProto.newBuilder();
        fightData.encodeToSelfHeroOnLogin(builder);
        spellList.encodeToSelfHeroOnLogin(builder);

        builder.setClientRelation(relationList.encodeToClient());
        builder.setRace(race.getId())
                .setRealAir(realAir)
                .setYuanbao(getTotalYuanbao())
                .setLijin(lijin)
                .setMoney(money)
                .setDepot(depot.encode4Client())
                .setTotalStat(fightData.getTotalStat().encode())
                .setExp(exp)
                .setUpgradeExp(getUpgradeExp())
                .setEquipmentResources(model.getResource())
                .setHasStorage(storage != null)
                .setClientOnlyConfig1(clientOnlyConfig1)
                .setPkAmount(pkAmount)
                .setNextReducePkAmountTime(nextReducePkAmountTime)
                .setReliveProtectedEndTime(reliveProtectedEndTime)
                .setAccumulatedOfflineTime(accumulatedOfflineTime)
                .setVipExp(vipExp)
                .setDailyOnlineAccTime(dailyOnlineAccTime)
                .setTotalRechargeYuanbao(totalRechargeYuanbao)
                .setCollectedVipPrize(collectedVipPrize)
                .setNextCollectVipWeeklyPrizeTime(nextCollectVipWeeklyPrizeTime)
                .setLastLogoutTime(lastLogoutTime)
                .setCreateTime(createTime)
                .setIsCollectLocalLoginFirstPrize(isCollectLocalLoginFirstPrize)
                .setIsCollectLocalLoginDailyPrize(isCollectLocalLoginDailyPrize)
                .setUseFreeChatTimes(useFreeChatTimes)
                .setHasRecharge(hasRecharged)
                .setIsCrossSingleStory(isCrossSingleStory);

        // 知天命
        divination.encodeToSelfOnLogin(builder);

        // 分2个int发送
        builder.addFuncBits((int) taskFuncBitData);
        builder.addFuncBits((int) (taskFuncBitData >>> 32));
        builder.addFuncBits(clientFuncBitData);

        // --- 剧情副本 ---
        for (storyDungeonStatIte.rewind(); storyDungeonStatIte.hasNext();){
            builder.addStoryDungeonProto(storyDungeonStatIte.next().encode());
        }
        storyDungeonStatIte.cleanUp();

        for (StoryDungeonCollectablePrizeProto proto : storyDungeonCollectablePrize){
            builder.addStoryDungeonCollectablePrizeProto(proto);
        }

        if (autoFinishStoryID > 0){
            builder.setAutoFinishStoryId(autoFinishStoryID)
                    .setAutoFinishStoryCompleteTime(autoFinishStoryCompleteTime);
        }

        for (int v : clientOnlyIntConfigs){
            builder.addClientOnlyIntConfigs(v);
        }

        // --- 挑战侠士 ---
        builder.setFinishedChallengeDungeonSequenceId(finishedChallengeDungeonSequence);

        // --- vip副本 ---
        for (int i = todayFinishedVipDungeonIDList.size(); --i >= 0;){
            builder.addFinishedVipDungeonId(todayFinishedVipDungeonIDList
                    .get(i));
        }

        // --- 守护孔慈 ---
        if (defenceHistoryMaxBatch != 0){
            // 如果历史最高一关都没通过, 则不可能有今日已通关和已领取的首通奖励
            builder.setDefenceHistoryMaxBatch(defenceHistoryMaxBatch);

            if (defenceTodayFinishedBatch != 0){
                builder.setDefenceTodayFinishedBatch(defenceTodayFinishedBatch);
            }

            if (defenceCollectedFirstPassPrize != 0){
                builder.setDefenceCollectedFirstPassPrize(defenceCollectedFirstPassPrize);
            }
        }
        if (defenceTodayResetCount != 0){
            builder.setDefenceTodayResetCount(defenceTodayResetCount);
        }
        // 孔慈可领取奖励
        for (DefenceCollectablePrizeWithExpireTime prize : defenceCollectablePrize){
            builder.addDefenceCollectablePrize(prize.getPrize().prizeProtoCompressedByteString);
        }

        // --- 搜神宫 ---
        builder.setSouShenPoint(souShenPoint);

        for (int i = souShenTodayPassedSceneID.size(); --i >= 0;){
            builder.addSouShenTodayPassedId(souShenTodayPassedSceneID.get(i));
        }

        for (int i = souShenLifePassedSceneID.size(); --i >= 0;){
            builder.addSouShenLifePassedId(souShenLifePassedSceneID.get(i));
        }

        // --- 凌云窟 ---
        int type = lingYunTodayFinishedTimes > 0 ? 2 : 0;

        if (type > 0){
            builder.setLingYunTodayFinishState(type);
            builder.setLingYunTodayEnteredTimes(lingYunTodayFinishedTimes);
        }

        // --- 组队副本通用待领取奖励 ---

        for (GroupDungeonCollectablePrizeProto proto : groupDungeonCollectablePrize){
            builder.addGroupCollectablePrizeProto(proto);
        }

        // --- 守护龙脉 ---
        builder.setLongMaiTodayFirstPassed(longMaiTodayFirstPassed);

        // --- 无绝神阵 ---
        builder.setWuJueTodayEnteredTimes(wuJueTodayEnteredTimes);

        // --- 板块战 ---
        for (int i = 0; i < territoryTodayCollectedPrizeSceneID.size(); i++){
            builder.addTerritoryTodayCollectedPrizeSceneId(territoryTodayCollectedPrizeSceneID
                    .get(i));
        }

        // 战斗力
        builder.setFightingAmount(fightingAmount);

        if (!isTeamAutoAcceptInvite){
            builder.setTeamAutoAcceptInvite(false);
        }

        if (!isTeamAutoAcceptRequest){
            builder.setTeamAutoAcceptRequest(false);
        }
        if (isForbidOtherInviteMeJoinTeam){
            builder.setTeamForbidOtherInviteMeJoin(true);
        }
        if (isTradeAutoReject){
            builder.setTradeAutoRejectInvite(true);
        }

        if (isGuildAutoAccept){
            builder.setGuildAutoAcceptInvite(true);
        }

        if (isForbidOtherInviteMeJoinGuild){
            builder.setGuildForbidOtherInviteMeJoin(true);
        }
        // 帮派
        if (guildMember != null){
            Guild guild = guildMember.getGuild();
            if (guild != null){
                builder.setGuildName(guild.nameByteString);
                builder.setGuildContribution(guildMember.getContribution());
                builder.setGuildFlagLevel(guild.getFlagLevel()); // 帮旗等级

                for (Guild friendGuild : guild.getFriendGuilds()){
                    builder.addFriendGuildName(friendGuild.nameByteString);
                }

                for (Guild enemyGuild : guild.getEnemyGuilds()){
                    builder.addEnemyGuildName(enemyGuild.nameByteString);
                }

                builder.setIsWsCityMaster(guild.isWsCityMaster());
                builder.setIsLongCityMaster(guild.isLongCityMaster());
                builder.setIsTerritoryLeader(guild.isTerritoryMaster());
                builder.setIsGuildLeader(guild.getLeader() == guildMember);
            }
        }
        builder.setGuildLiLian(guildLilian);

        for (int i = 0; i < equipmentList.length; i++){
            Equipment equipment = equipmentList[i];
            if (equipment != null){
                builder.addEquipedPos(i)
                        .addEquipmentDatas(equipment.getData().getProto())
                        .addEquipments(equipment.encode4ClientProto());
            }
        }

        for (BuyBackGoods buyBackGoods : buyBackGoodsList){
            Goods goods = buyBackGoods.goods;
            builder.addBuyBackGoodsDatas(goods.getData().getProtoByteString());
            builder.addBuyBackGoodsList(goods.encodeByteString4Client());
        }

        builder.setTask(taskList.encodeToSelfOnLogin(race));
        welfare.encode4Client(builder);

        // 坐骑
        if (mount != null){
            builder.setMount(mount.encode4Client());
        }

        // 神兵
        for (HeroSuperWeapon weapon : superWeapons){
            if (weapon != null){
                builder.addSuperWeapon(weapon.encode4Client());
            }
        }

        if (usingWeapon != null){
            builder.setUsingWeapon(usingWeapon.getId());
        }

        // 弓箭
        if (bow != null){
            builder.setBow(bow.encode4Client());
        }

        if (gem != null){
            Goods[] gems = gem.getGems();
            for (int i = 0; i < gems.length; i++){
                Goods g = gems[i];
                if (g != null && g.getData() instanceof GemGoodsData){
                    int gemLevel = ((GemGoodsData) g.getData()).getGemLevel();

                    builder.addGems(gemLevel | (i << 4));
                }
            }
        }

        // 宠物
        if (pet != null){
            builder.setPet(pet.encode4client());
        }

        builder.setPhoenixMoneyRefineTimes(phoenixMoneyRefineTimes);
        builder.setPhoenixLijinRefineTimes(phoenixLijinRefineTimes);
        builder.setPhoenixYuanbaoRefineTimes(phoenixYuanbaoRefineTimes);

        builder.setLoginDay(loginDay);
        builder.setShengWang((shengWang << 16) | shengWangExchangeBits);
        for (Entry entry : shengwangMap.entrySet()){
            if (entry.getValue() > 0){
                builder.addShengWangTask(entry.getValue() << 8 | entry.getKey());
            }
        }

        for (Entry entry : dailyActivityBuybackMap.entrySet()){
            builder.addDailyActivityResult((entry.getKey() << 1)
                    | entry.getValue());
        }

        if (tianjie != null){
            builder.setTianJie(tianjie.encode4client());
        }

        if (tianzui != null){
            builder.setTianZui(tianzui.encode4client());
        }

        // 今日已经崇拜的英雄
        for (long hero : admiredHeros){
            builder.addAdmiredHero(hero);
        }

        builder.setMeltAmount(meltAmount);

        // 挑战侠士次数
        builder.setChallengeDungeonDailyTimes(challengeDungeonDailyTimes);
        builder.setChallengeDungeonAssistTimes(challengeDungeonAssistTimes);
        for (int i = 0; i < challengeDungeonUseTime.size(); i++){
            builder.addChallengeDungeonUseTimes(challengeDungeonUseTime.get(i));
        }

        builder.setHonor(honorPoint);

        builder.setFirstRechargeCollectIndex(firstRechargeCollectIndex);

        builder.setLoginPrizeInfo(loginPrizeInfo);

        builder.setInvestUpgradeBankMoney(investUpgradeBankMoney);
        for (Entry entry : collectUpgradeBankMap.entrySet()){
            builder.addCollectUpgradeBankLevel(entry.getKey());
            builder.addCollectUpgradeBankLijin(entry.getValue());
        }

        builder.setInvestMonthlyBankMoney(investMonthlyBankMoney);
        builder.setInvestMonthlyBankTime(investMonthlyBankTime);
        builder.setMonthlyBankPrevCollectTime(monthlyBankPrevCollectTime);
        builder.setMonthlyBankPrevCollectTime2(monthlyBankPrevCollectTime2);
        builder.setMonthlyBankOnlineLijin(monthlyBankOnlineLijin);
        builder.setMonthlyBankBaseLijin(monthlyBankPrevDayOnlineLijin);
        builder.setMonthlyBankOnlineHours(monthlyBankOnlineHours);

        builder.setTotalOnlineTime(totalOnlineAccTime);

        for (int i = 0; i < collectedRankPromotionPrize.size(); i++){
            builder.addCollectedRankPromotionPrize(collectedRankPromotionPrize
                    .get(i));
        }

        return builder.build();
    }

    /**
     * 别人观察我时, 把我的信息发给他
     * @return
     */
    @MultiThread
    public OtherHeroProto encodeToOtherHeroOnBeingViewed(){
        OtherHeroProto.Builder builder = OtherHeroProto.newBuilder();
        SpriteStat totalStat = fightData.getTotalStat();
        builder.setId(id).setName(nameByteString)
                .setLevel(fightData.getLevel()).setRace(race.getId())
                .setFightingAmount(fightingAmount)
                .setTotalStat(totalStat.encode()).setVipExp(vipExp)
                .setPkAmount(pkAmount).setGuildLiLian(guildLilian);

        // 帮派
        if (guildMember != null){
            Guild guild = guildMember.getGuild();
            if (guild != null){
                builder.setGuildName(guild.nameByteString);
            }
        }

        // 战斗力
        builder.setBaseFightingAmount(getHeroBaseFightingAmount()); // 英雄成长战斗力
        builder.setEquipmentFightingAmount(getEquipmentFightingAmount()); // 装备战斗力
        builder.setSpellFightingAmount(getSpellFightingAmount()); // 技能战斗力
//        builder.setGemFightingAmount(getGemFightingAmount()); // 宝石战斗力
        builder.setMountFightingAmount(getBestMountFightingAmount()); // 坐骑战斗力
        builder.setBowFightingAmount(getBowFightingAmount()); // 弓箭战斗力
        builder.setSuperWeaponFightingAmount(getSuperWeaponFightingAmount()); // 神兵战斗力
        builder.setSuperArmFightingAmount(getSuperArmFightingAmount()); // 麒麟臂战斗力
        builder.setSuperWeaponXinfaFightingAmount(getSuperWeaponXinfaFightingAmount()); // 神兵心法
        builder.setTianjieFightingAmount(getTianJieFightingAmount()); // 天劫
        builder.setTianzuiFightingAmount(getTianZuiFightingAmount()); // 天罪

        for (int i = 0; i < equipmentList.length; i++){
            Equipment equipment = equipmentList[i];
            if (equipment != null){
                builder.addEquipedPos(i)
                        .addEquipmentDatas(equipment.getData().getProto())
                        .addEquipments(equipment.encode4ClientProto());
            }
        }

        // 坐骑
        if (mount != null){
            builder.setMount(mount.encode4Client());
        }

        // 弓箭
        if (bow != null){
            builder.setBow(bow.encode4Client());
        }

        if (gem != null){
            Goods[] gems = gem.getGems();
            for (int i = 0; i < gems.length; i++){
                Goods g = gems[i];
                if (g != null && g.getData() instanceof GemGoodsData){
                    int gemLevel = ((GemGoodsData) g.getData()).getGemLevel();

                    builder.addGems(gemLevel | (i << 4));
                }
            }
        }

        // 宠物
        if (pet != null){
            builder.setPet(pet.encode4client());
        }

        if (tianjie != null){
            builder.setTianJie(tianjie.encode4client());
        }

        if (tianzui != null){
            builder.setTianZui(tianzui.encode4client());
        }

        builder.setEquipmentResources(model.getResourceWithBestMountBow());// 最好的坐骑和弓箭

        builder.setExp(exp).setUpgradeExp(levelData.getUpgradeExp())
                .setLife(fightData.getLife()).setMaxLife(totalStat.maxLife)
                .setRealAir(realAir).setStamina(fightData.getStamina())
                .setMaxStamina(totalStat.maxStamina);

        return builder.build();
    }

    public FightData getFightData(){
        return fightData;
    }

    public long getID(){
        return id;
    }

    public int getUserId(){
        return userId;
    }

    public String getUin(){
        return uin;
    }

    public int getServerId(){
        return serverId;
    }

    public int getOperatorId(){
        return operatorId;
    }

    public byte[] getNameBytes(){
        return nameBytes;
    }

    public String getName(){
        return name;
    }

    public ByteString getNameByteString(){
        return nameByteString;
    }

    public int getRealAir(){
        return realAir;
    }

    public int addRealAir(int amount){
        if (amount < 0){
            throw new IllegalArgumentException("要增加真气时,要增加的数额是负的");
        }

        if ((realAir += amount) < 0
                || realAir > VariableConfig.REAL_AIR_MAX_AMOUNT){
            // overflow
            realAir = VariableConfig.REAL_AIR_MAX_AMOUNT;
        }

        return realAir;
    }

    public int reduceRealAir(int amount){
        if (amount < 0){
            throw new IllegalArgumentException("要扣除真气时,要扣除的数额是负的");
        }

        realAir = Math.max(0, realAir - amount);

        return realAir;
    }

    public SpellList getSpellList(){
        return spellList;
    }

    public RelationList getRelationList(){
        return relationList;
    }

    public void onHeroOffline(long currentTime){
        lastLogoutTime = currentTime;

        // 每日在线时间
        if (currentTime > dailyOnlineStartTime){
            dailyOnlineAccTime += currentTime - dailyOnlineStartTime;
        }

        if (currentTime > loginTime){
            totalOnlineAccTime += currentTime - loginTime;
        }

        if (pkAmount > 0){
            pkAmountAccTime = currentTime
                    + VariableConfig.PK_AMOUNT_REDUCE_INTERVAL
                    - nextReducePkAmountTime;
        }
    }

    private boolean hasSell = false;

    public void setHasSell(boolean v){
        this.hasSell = v;
    }

    /**
     * 将好友列表中需要的信息作为int存在数据库中
     *
     * @return
     */
    public int encodeEasyInfo(){
        /*
         * ForbiddenBeanAddedAsFriend 1bit |tanwei 1bit=2 | level 9bit | raceID
         * 3bit
         */

        int level = fightData.getLevel() & 0b1_1111_1111; // 9bit
        int raceID = race.getId() & 0b111; // 3bit

        // 摊位
        int sellBit = hasSell ? 1 : 0;

        int forbiddenBeenAddedAsFriend = relationList
                .isForbidBeenAddedAsFriend() ? 1 : 0;
        int result = (forbiddenBeenAddedAsFriend << 13) | (sellBit << 12)
                | (level << 3) | (raceID);
        return result;
    }

    public static int decodeEasyInfoGetLevel(int easyInfo){
        return (easyInfo >>> 3) & 0b1_1111_1111;
    }

    public static int decodeEasyInfoGetRace(int easyInfo){
        return easyInfo & 0b111;
    }

    public static boolean decodeEasyInfoGetHasSell(int easyInfo){
        return (easyInfo & 0b1_0000_0000_0000) != 0;
    }

    public static boolean decodeEasyInfoForbidBeenAddedAsFriend(int easyInfo){
        return (easyInfo & 0b10_0000_0000_0000) != 0;
    }
}
