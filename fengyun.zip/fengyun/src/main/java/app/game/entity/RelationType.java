package app.game.entity;

public enum RelationType{

    FRIEND, ENEMY, FRIEND_AND_ENEMY;
}
