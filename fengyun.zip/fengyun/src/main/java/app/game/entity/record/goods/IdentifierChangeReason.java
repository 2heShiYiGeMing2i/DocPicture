package app.game.entity.record.goods;

public enum IdentifierChangeReason{

    ;

    final int actionID;

    private IdentifierChangeReason(int actionID){
        this.actionID = actionID;
    }
}
