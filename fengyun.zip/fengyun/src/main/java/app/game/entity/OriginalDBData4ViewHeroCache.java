package app.game.entity;

import java.util.Arrays;

import com.mokylin.sink.util.Empty;

public class OriginalDBData4ViewHeroCache{

    public final byte[] data;
    public final byte[] heroName;
    public static final OriginalDBData4ViewHeroCache EMPTY = new OriginalDBData4ViewHeroCache(
            Empty.BYTE_ARRAY, Empty.BYTE_ARRAY);

    public OriginalDBData4ViewHeroCache(byte[] data, byte[] heroName){
        super();
        this.data = data;
        this.heroName = heroName;
    }

    @Override
    public int hashCode(){
        int h1 = Arrays.hashCode(data);
        int h2 = Arrays.hashCode(heroName);
        return Arrays.hashCode(new int[]{h1, h2});
    }

    @Override
    public boolean equals(Object obj){
        if (obj instanceof OriginalDBData4ViewHeroCache){
            OriginalDBData4ViewHeroCache v = (OriginalDBData4ViewHeroCache) obj;
            return Arrays.equals(data, v.data)
                    && Arrays.equals(heroName, v.heroName);
        }
        return false;
    }
}
