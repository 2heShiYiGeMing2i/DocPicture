package app.game.entity.record.goods;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.protobuf.GoodsOwnershipContent.GoodsOwnershipProto;
import app.protobuf.LogContent.LogEnum.OperateType;

import com.mokylin.collection.IntValueLongHashMap;

public class GoodsOwnership{

    private static final Logger logger = LoggerFactory
            .getLogger(GoodsOwnership.class);

    private final IntValueLongHashMap goodsCountMap;

//    private GoodsLog goodsLog;

    public GoodsOwnership(){
        this.goodsCountMap = new IntValueLongHashMap();
    }

    public void addGoods(long identifier, int count, OperateType type,
            long misc, long ctime, boolean needLog){
        if (type == OperateType.INTERNAL)
            return; // 英雄内部移动，不记录日志

        try{
            goodsCountMap.increment(identifier, count);
        } catch (RuntimeException ex){
            throw new IllegalGoodsCountException(ex);
        }

//        if (needLog){
//            goodsLog = new GoodsLog(GoodsLog.ACTION_TYPE_ADD_GOODS,
//                    type.getNumber(), identifier, count, ctime, misc, goodsLog);
//        }
    }

    public void checkGoodsEnough(long identifier, int count){
        if (goodsCountMap.get(identifier) < count)
            throw new IllegalGoodsCountException("checkGoodsEnough error. "
                    + identifier + "-" + count);
    }

    public int getGoodsCount(long identifier){
        return Math.max(goodsCountMap.get(identifier), 0);
    }

    public void removeGoods(long identifier, int count, OperateType type,
            long misc, long ctime, boolean needLog){

        try{
            goodsCountMap.decrement(identifier, count);
        } catch (RuntimeException ex){
            throw new IllegalGoodsCountException(ex);
        }

//        if (needLog){
//            goodsLog = new GoodsLog(GoodsLog.ACTION_TYPE_REMOVE_GOODS,
//                    type.getNumber(), identifier, count, ctime, misc, goodsLog);
//        }
    }

    public void changeIdentifier(long oldIdentifier, long newIdentifier,
            int count, OperateType reason, long ctime, boolean needLog){
        // 先读取下oldIdentifier的个数, 够再继续操作

        if (oldIdentifier == newIdentifier){
            logger.error(
                    "changeIdentifier时，发现oldIdentifier == newIdentifier，reason: {}",
                    reason);
            return;
        }

        int oldCount = goodsCountMap.get(oldIdentifier);

        if (oldCount < count){
            throw new IllegalGoodsCountException(
                    "GoodsOwnership.changeIdentifier时, oldIdentifier的个数不够. 需要"
                            + count + ", 但是只有" + oldCount);
        }

        try{
            goodsCountMap.increment(newIdentifier, count); // 先increment. 前面已经检查过个数, decrement应该不会报错
            goodsCountMap.decrement(oldIdentifier, count);
        } catch (RuntimeException ex){
            throw new IllegalGoodsCountException(ex);
        }

//        if (needLog){
//            goodsLog = new GoodsLog(GoodsLog.ACTION_TYPE_CHANGE_IDENTIFIER,
//                    reason.getNumber(), oldIdentifier, count, ctime,
//                    newIdentifier, goodsLog);
//        }
    }

//    public GoodsLog getAndClearGoodsLog(){
//        GoodsLog result = goodsLog;
//        goodsLog = null;
//        return result;
//    }

    public GoodsOwnershipProto encode(){
        GoodsOwnershipProto.Builder builder = GoodsOwnershipProto.newBuilder();
        for (IntValueLongHashMap.Entry entry : goodsCountMap.entrySet()){
            builder.addIdentifier(entry.getKey()).addCount(entry.getValue());
        }
        return builder.build();
    }

    public void decode(GoodsOwnershipProto proto){
        fillGoodsCountMap(proto, goodsCountMap);
    }

    public static void fillGoodsCountMap(GoodsOwnershipProto proto,
            IntValueLongHashMap goodsCountMap){
        assert goodsCountMap.size() == 0;

        int count = Math.min(proto.getCountCount(), proto.getIdentifierCount());

        for (int i = 0; i < count; i++){
            goodsCountMap.put(proto.getIdentifier(i), proto.getCount(i));
        }
    }
}
