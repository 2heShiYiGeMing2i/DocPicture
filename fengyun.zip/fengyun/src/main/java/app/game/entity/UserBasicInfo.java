package app.game.entity;

public class UserBasicInfo{

    public final int id;
    public final byte[] heroName;
    public final int heroLevel;

    public UserBasicInfo(int id, byte[] heroName, int heroLevel){
        super();
        this.id = id;
        this.heroName = heroName;
        this.heroLevel = heroLevel;
    }

}
