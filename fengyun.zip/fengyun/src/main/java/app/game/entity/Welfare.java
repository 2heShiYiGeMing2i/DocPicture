package app.game.entity;

import java.util.List;

import app.game.data.ConfigService;
import app.game.data.Prize;
import app.game.data.goods.GoodsShowData;
import app.protobuf.GoodsServerContent.GoodsServerProto;
import app.protobuf.HeroContent.HeroProto;
import app.protobuf.HeroServerContent.HeroMinorProto;

import com.google.common.collect.Lists;
import com.google.protobuf.ByteString;

/**
 * 福利，单独一个类，比较方便测试
 * @author Liwei
 *
 */
public class Welfare{

    static Welfare newWelfare(int lotteryMaxCount){
        return new Welfare(lotteryMaxCount);
    }

    /**
     * 英雄签到表，每一个bit表示一天，最低位表示1号，左移一位表示下一天
     */
    private int sign;

    private int totalSignTimes;

    /**
     * 英雄签到奖励领取情况，每一个bit表示一种奖励是否已经领取
     * 最低位表示第一个奖励，左移一位表示下一个奖励
     */
    private int signPrize;

    /**
     * 补签次数
     */
    private int replenishSignTimes;

    /**
     * 今日摇奖状态
     */
    private int lottery;

    private final List<GoodsShowData> lotteryGoodsList;

    // 个人竞技场整点累计奖励
    public Prize hourlyAccPrize;

    private Welfare(int lotteryMaxCount){
        lotteryGoodsList = Lists.newArrayListWithCapacity(lotteryMaxCount);
    }

    public void addLotteryGoods(GoodsShowData g){
        lotteryGoodsList.add(g);
    }

    public boolean isSign(int day){
        assert day > 0 && day < 32;

        return ((sign >>> (day - 1)) & 1) == 1;
    }

    public int sign(int day){
        assert day > 0 && day < 32;

        return sign = (sign | (1 << (day - 1)));
    }

    public int incrementTotalSignTimes(){
        if (totalSignTimes < Integer.MAX_VALUE)
            totalSignTimes++;

        return totalSignTimes;
    }

    public int getSignTimes(){
        return Integer.bitCount(sign);
    }

    public int getTotalSingTimes(){
        return totalSignTimes;
    }

    public int getReplenishSignTimes(){
        return replenishSignTimes;
    }

    public int incrementReplenishSignTimes(){
        return ++replenishSignTimes;
    }

    public boolean isCollectedSignPrize(int index){
        assert index >= 0 && index < 32;

        return ((signPrize >>> index) & 1) == 1;
    }

    public int collectedSignPrize(int index){
        assert index >= 0 && index < 32;

        return signPrize = (signPrize | (1 << index));
    }

    public int getLottery(){
        return lottery;
    }

    public void setLottery(int l){
        lottery = l;
    }

    void resetDailyStaticstics(){
        lottery = 0;
        lotteryGoodsList.clear();
        hourlyAccPrize = null;
    }

    void resetMonthlyStaticstics(){
        sign = 0;
        signPrize = 0;
        replenishSignTimes = 0;
    }

    void encode4Client(HeroProto.Builder builder){
        builder.setSign(sign).setSignPrize(signPrize)
                .setReplenishSignTimes(replenishSignTimes).setLottery(lottery)
                .setTotalSignTimes(totalSignTimes);

        for (GoodsShowData g : lotteryGoodsList){
            builder.addLotteryGoodsStaticData(g.getData().getProtoByteString());
            builder.addLotteryGoodsDynamicData(ByteString.copyFrom(g
                    .getDynamicData()));
        }
    }

    void encode(HeroMinorProto.Builder builder){
        builder.setSign(sign).setSignPrize(signPrize)
                .setReplenishSignTimes(replenishSignTimes).setLottery(lottery)
                .setTotalSignTimes(totalSignTimes);

        for (GoodsShowData g : lotteryGoodsList){
            builder.addLotteryGoods(g.getServerProto());
        }

        if (hourlyAccPrize != null)
            builder.setHourlyAccPrize(hourlyAccPrize.encode());
    }

    void decode(HeroMinorProto proto, ConfigService configService){
        sign = proto.getSign();
        signPrize = proto.getSignPrize();
        replenishSignTimes = proto.getReplenishSignTimes();
        lottery = proto.getLottery();
        totalSignTimes = proto.getTotalSignTimes();

        for (GoodsServerProto g : proto.getLotteryGoodsList()){
            GoodsShowData d = GoodsShowData.decode(g, 0, configService);

            if (d != null)
                lotteryGoodsList.add(d);
        }

        if (proto.hasHourlyAccPrize())
            hourlyAccPrize = Prize.decode(proto.getHourlyAccPrize(),
                    configService);
    }
}
