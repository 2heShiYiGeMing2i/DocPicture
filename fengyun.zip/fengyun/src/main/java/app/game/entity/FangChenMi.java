package app.game.entity;

public enum FangChenMi{

    NONE(1), WEAK(0.5f), STRONG(0);

    private final float multiple;

    private FangChenMi(float multiple){
        this.multiple = multiple;
    }

    public float getMultiple(){
        return multiple;
    }

}
