package app.game.entity;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.protobuf.HeroContent.ClientRelation;
import app.protobuf.RelationContent.RelationProto;

import com.google.common.annotations.VisibleForTesting;
import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;
import com.mokylin.collection.IntValueLongConcurrentHashMap;
import com.mokylin.collection.IntValueLongConcurrentHashMap.LongKeyIterator;
import com.mokylin.collection.LongArrayList;
import com.mokylin.sink.util.Empty;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.annotation.MultiThread;
import com.mokylin.sink.util.annotation.MustNotNull;
import com.mokylin.sink.util.annotation.SelfWriteMultiThreadRead;

public class RelationList{
    private static final Logger logger = LoggerFactory
            .getLogger(RelationList.class);

    public static final int FRIEND_COUNT_LIMIT = 50;
    public static final int ENEMY_COUNT_LIMIT = 30;
    public static final int BLACK_COUNT_LIMIT = 20;
    public static final int RECENT_COUNT_LIMIT = 20;

    public static final int MAX_ENEMY_RECORD = 999;
    public static final int MIN_ENEMY_RECORD = -999;

    /**
     * 越前面, 在面板上显示越前
     */
    private final LongArrayList friendList;

    /**
     * 越前面, 在面板上显示越前
     */
    private final List<EnemyRelationEntry> enemyList;

    /**
     * 越前面, 在面板上显示越前
     */
    private final LongArrayList blackList;

    /**
     * 越后面, 在面板上显示越前
     */
    private final LongArrayList recentList;

    @MustNotNull
    private ByteString mood;

    private byte[] moodBytes;

    private boolean hideMyLocation;

    @SelfWriteMultiThreadRead
    private boolean showEnemyEvents;

    private boolean hideOfflineRelation;

    private boolean hideBigHead;

    @SelfWriteMultiThreadRead
    private boolean forbidBeenAddedAsFriend;

    /**
     * 每个关系列表中的id, 出现在关系列表中的次数
     * 访问一定要synchronized
     */
    private transient IntValueLongConcurrentHashMap relationCounter;

    public static RelationList newRelationList(){
        return new RelationList(4, 4, 4, 8);
    }

    private RelationList(int initialFriendSize, int initialEnemySize,
            int initialBlackSize, int initialRecentSize){
        this.friendList = new LongArrayList(initialFriendSize);
        this.enemyList = new ArrayList<>(initialEnemySize);
        this.blackList = new LongArrayList(initialBlackSize);
        this.recentList = new LongArrayList(initialRecentSize);
        this.mood = ByteString.EMPTY;
        this.moodBytes = Empty.BYTE_ARRAY;

        relationCounter = new IntValueLongConcurrentHashMap(initialFriendSize
                + initialEnemySize + initialBlackSize + initialRecentSize);
    }

    public boolean isHideMyLocation(){
        return hideMyLocation;
    }

    @MultiThread
    public boolean isShowEnemyEvents(){
        return showEnemyEvents;
    }

    @MultiThread
    public boolean isForbidBeenAddedAsFriend(){
        return forbidBeenAddedAsFriend;
    }

    /**
     * 设置是否隐藏我的地图信息
     *
     * @param hide
     * @return 是否改变了这个值, 改变了的话需要广播
     */
    public boolean setHideMyLocation(boolean hide){
        if (hideMyLocation != hide){
            hideMyLocation = hide;
            return true;
        }
        return false;
    }

    public void setHideOfflineRelation(boolean hide){
        hideOfflineRelation = hide;
    }

    public void setShowEnemyEvent(boolean show){
        this.showEnemyEvents = show;
    }

    public void setHideBigHead(boolean hide){
        this.hideBigHead = hide;
    }

    /**
     * 设置 ForbidBeenAddedAsFriend
     *
     * @param forbidBeenAddedAsFriend
     * @return 是否改变了这个值, 改变了的话需要更新  hero缓存的singleRelationHolder
     */
    public boolean setForbidBeenAddedAsFriend(boolean forbidBeenAddedAsFriend){
        if (this.forbidBeenAddedAsFriend != forbidBeenAddedAsFriend){
            this.forbidBeenAddedAsFriend = forbidBeenAddedAsFriend;
            return true;
        }
        return false;
    }

    // ------ 所有和RelationCounter相关的操作 ------
    static final int FRIEND_MASK = 0b0001;
    static final int ENEMY_MASK = 0b0010;
    static final int BLACK_MASK = 0b0100;
    static final int RECENT_MASK = 0b1000;

    public static boolean isFriend(int v){
        return v != -1 && (v & FRIEND_MASK) != 0;
    }

    public static boolean isEnemy(int v){
        return v != -1 && (v & ENEMY_MASK) != 0;
    }

    public static boolean isBlack(int v){
        return v != -1 && (v & BLACK_MASK) != 0;
    }

    @VisibleForTesting
    void addRelation(long id, int mask){
        int oldRelation = relationCounter.get(id);
        if (oldRelation == -1){
            relationCounter.put(id, mask);
            return;
        }

        int newRelation = oldRelation | mask;

        assert newRelation != oldRelation;

        if (newRelation == oldRelation){
            logger.error("RelationList.addRelation时, 要添加的mask已经存在");
            return;
        }
        relationCounter.put(id, newRelation);
    }

    @VisibleForTesting
    void removeRelation(long id, int mask){
        int oldRelation = relationCounter.get(id);
        assert oldRelation != -1;

        if (oldRelation == -1){
            logger.error("RelationList.removeRelation时, 要remove的mask本身就不存在");
            return;
        }

        if (oldRelation == mask){
            // 本来就只有这一个关系, 直接删掉
            relationCounter.remove(id);
            return;
        }

        int newRelation = oldRelation & (~mask);
        assert newRelation != oldRelation;
        if (newRelation == oldRelation){
            logger.error("RelationList.removeRelation时, 要remove的mask本身就不存在");
            return;
        }

        relationCounter.put(id, newRelation);
    }

    @MultiThread
    public int getRelation(long id){
        return relationCounter.get(id);
    }

    @MultiThread
    public boolean isRelated(long id){
        return relationCounter.get(id) > 0;
    }

    public LongKeyIterator newRelationCounterKeyIte(){
        return relationCounter.newKeyIte();
    }

    // ----------
    /**
     * 加好友
     * @param id
     * @return
     */
    public void addFriend(long id){
        assert !containsFriend(id);
        friendList.add(id);
        addRelation(id, FRIEND_MASK);
    }

    public boolean isFriendListFull(){
        return friendList.size() >= FRIEND_COUNT_LIMIT;
    }

    public boolean containsFriend(long id){
        return friendList.contains(id);
    }

    public boolean removeFriend(long id){
        for (int i = friendList.size(); --i >= 0;){
            if (friendList.get(i) == id){
                friendList.remove(i);
                removeRelation(id, FRIEND_MASK);
                return true;
            }
        }
        return false;
    }

    // ----------

    /**
     * 加仇人
     * @param id
     * @param num
     * @return
     */
    public void addEnemy(long id){
        assert !containsEnemy(id);
        enemyList.add(new EnemyRelationEntry(id, 0));
        addRelation(id, ENEMY_MASK);
    }

    public boolean isEnemyListFull(){
        return enemyList.size() >= ENEMY_COUNT_LIMIT;
    }

    public boolean containsEnemy(long id){
        for (int i = enemyList.size(); --i >= 0;){
            if (enemyList.get(i).id == id){
                return true;
            }
        }
        return false;
    }

    /**
     * 改变自己对enemy的历史战绩
     * @param id
     * @param delta
     * @return true 表示他已经是我的仇人了
     */
    public boolean adjustEnemyRecord(long id, int delta){
        EnemyRelationEntry entry;
        for (int i = enemyList.size(); --i >= 0;){
            entry = enemyList.get(i);
            if (entry.id == id){
                if (delta > 0){
                    entry.num = Math.min(entry.num + delta, MAX_ENEMY_RECORD);
                } else{
                    entry.num = Math.max(entry.num + delta, MIN_ENEMY_RECORD);
                }
                return true;
            }
        }
        return false;
    }

    public boolean removeEnemy(long id){
        for (int i = enemyList.size(); --i >= 0;){
            if (enemyList.get(i).id == id){
                enemyList.remove(i);
                removeRelation(id, ENEMY_MASK);
                return true;
            }
        }
        return false;
    }

    // ----------

    public long removeFirstBlack(){
        assert blackList.size() > 0;
        long id = blackList.remove(0);
        removeRelation(id, BLACK_MASK);
        return id;
    }

    public boolean isBlackListFull(){
        return blackList.size() >= BLACK_COUNT_LIMIT;
    }

    public boolean containsBlack(long id){
        return blackList.contains(id);
    }

    /**
     * 加黑名单
     * @param id
     * @return
     */
    public void addBlack(long id){
        assert !containsBlack(id);
        blackList.add(id);
        addRelation(id, BLACK_MASK);
    }

    public boolean removeBlack(long id){
        for (int i = blackList.size(); --i >= 0;){
            if (blackList.get(i) == id){
                blackList.remove(i);
                removeRelation(id, BLACK_MASK);
                return true;
            }
        }
        return false;
    }

    // ---- 最近联系人 ----

    public int getRecentSize(){
        return recentList.size();
    }

    public void addRecent(long id){
        recentList.add(id);
        addRelation(id, RECENT_MASK);
    }

    public boolean isAtRecentTop(long id){
        assert recentList.size() > 0;
        return recentList.get(recentList.size() - 1) == id;
    }

    /**
     * 如果此id存在于最近联系人列表中, 则将其移到最上面
     * @param id
     * @return
     */
    public boolean isContainsRecentMoveToTop(long id){
        for (int i = recentList.size() - 1; --i >= 0;){
            if (recentList.get(i) == id){
                recentList.remove(i);
                recentList.add(id);
                return true;
            }
        }
        return false;
    }

    public boolean ifRecentFullRemoveFirst(){
        if (recentList.size() >= RECENT_COUNT_LIMIT){
            long id = recentList.remove(0);
            removeRelation(id, RECENT_MASK);
            return true;
        }
        return false;
    }

    /**
     *
     * @param id
     * @return
     */
    public boolean removeRecent(long id){
        for (int i = recentList.size(); --i >= 0;){
            if (recentList.get(i) == id){
                recentList.remove(i);
                removeRelation(id, RECENT_MASK);
                return true;
            }
        }
        return false;
    }

    // ------ end of 最近联系人 ------

    // ----- 移动好友/仇人 -------

    public boolean moveFriendUp(long id){
        for (int i = friendList.size(); --i >= 1;){ // 只检查到1, 0不检查
            if (friendList.get(i) == id){
                friendList.set(i, friendList.get(i - 1));
                friendList.set(i - 1, id);
                return true;
            }
        }
        return false;
    }

    public boolean moveFriendDown(long id){
        for (int i = friendList.size() - 1; --i >= 0;){ // 从倒数第二个开始检查
            if (friendList.get(i) == id){
                friendList.set(i, friendList.get(i + 1));
                friendList.set(i + 1, id);
                return true;
            }
        }
        return false;
    }

    public boolean moveEnemyUp(long id){
        for (int i = enemyList.size(); --i >= 1;){
            if (enemyList.get(i).id == id){
                EnemyRelationEntry entry = enemyList.get(i);
                enemyList.set(i, enemyList.get(i - 1));
                enemyList.set(i - 1, entry);
                return true;
            }
        }
        return false;
    }

    public boolean moveEnemyDown(long id){
        for (int i = enemyList.size() - 1; --i >= 0;){
            if (enemyList.get(i).id == id){
                EnemyRelationEntry entry = enemyList.get(i);
                enemyList.set(i, enemyList.get(i + 1));
                enemyList.set(i + 1, entry);
                return true;
            }
        }
        return false;
    }

    // --- end of 移动好友/仇人 ----

    public ByteString getMood(){
        return mood;
    }

    public void setMood(byte[] moodBytes){
        this.moodBytes = moodBytes;
        this.mood = ByteString.copyFrom(moodBytes);
    }

    public byte[] getMoodBytes(){
        return moodBytes;
    }

    public static class EnemyRelationEntry{
        public final long id;
        public int num;

        public EnemyRelationEntry(long id, int num){
            this.id = id;
            this.num = num;
        }
    }

    // ------ encode & decode ------

    public byte[] encode(){
        int friendSize = friendList.size();
        int enemySize = enemyList.size();
        int blackSize = blackList.size();
        int recentSize = recentList.size();

        RelationProto.Builder builder = RelationProto.newBuilder();
        builder.setMood(mood);

        // 好友
        for (int i = friendSize; --i >= 0;){
            builder.addFriendId(friendList.get(i));
        }

        // 仇人
        EnemyRelationEntry entry;
        for (int i = enemySize; --i >= 0;){
            entry = enemyList.get(i);
            builder.addEnemyId(entry.id);
            builder.addEnemyScoreHistory(entry.num);
        }

        // 黑名单
        for (int i = blackSize; --i >= 0;){
            builder.addBlackId(blackList.get(i));
        }

        // 最近联系人
        for (int i = recentSize; --i >= 0;){
            builder.addRecentId(recentList.get(i));
        }

        builder.setHideBigHead(hideBigHead).setHideMyLocation(hideMyLocation)
                .setHideOfflineRelation(hideOfflineRelation)
                .setShowEnemyEvent(showEnemyEvents)
                .setForbidBeenAddedAsFriend(forbidBeenAddedAsFriend);

        return builder.build().toByteArray();
    }

    public ClientRelation encodeToClient(){
        int friendSize = friendList.size();
        int enemySize = enemyList.size();
        int recentSize = recentList.size();
        int blackSize = blackList.size();

        ClientRelation.Builder builder = ClientRelation.newBuilder();
        // 好友
        for (int i = 0; i < friendSize; i++){// 好友新加的加在后面
            builder.addFriendId(friendList.get(i));
        }

        // 仇人
        EnemyRelationEntry entry;
        for (int i = 0; i < enemySize; i++){ // 仇人新加的加在后面
            entry = enemyList.get(i);
            builder.addEnemyId(entry.id);
            builder.addEnemyKillHistory(entry.num);
        }

        // 黑名单
        for (int i = 0; i < blackSize; i++){
            builder.addBlackListId(blackList.get(i));
        }

        // 最近联系人
        for (int i = recentSize; --i >= 0;){ // 最近联系人, 新加的加在后面, 显示在最前面, 从后面开始发
            builder.addRecentId(recentList.get(i));
        }
        builder.setHideBigHead(hideBigHead).setHideMyLocation(hideMyLocation)
                .setHideOfflineRelation(hideOfflineRelation)
                .setShowEnemyEvent(showEnemyEvents)
                .setForbidBeenAddedAsFriend(forbidBeenAddedAsFriend);

        return builder.build();
    }

    public static RelationList decode(byte[] data)
            throws InvalidProtocolBufferException{
        if (data == null){
            logger.error("RelationList.decode时, 参数byte[]是个null. 数据库中不应该有hero_data没hero_relation. 返回个空的RelationList");
            return newRelationList();
        }
        RelationProto proto = RelationProto.parseFrom(data);

        int friendSize = proto.getFriendIdCount();
        int enemySize = Math.min(proto.getEnemyIdCount(),
                proto.getEnemyScoreHistoryCount());

        int blackSize = proto.getBlackIdCount();
        int recentSize = proto.getRecentIdCount();

        RelationList result = new RelationList(friendSize, enemySize,
                blackSize, recentSize);

        result.mood = proto.getMood();
        result.moodBytes = result.mood.toByteArray();
        result.hideBigHead = proto.getHideBigHead();
        result.hideMyLocation = proto.getHideMyLocation();
        result.hideOfflineRelation = proto.getHideOfflineRelation();
        result.showEnemyEvents = proto.getShowEnemyEvent();
        result.forbidBeenAddedAsFriend = proto.getForbidBeenAddedAsFriend();

        // 好友
        for (int i = friendSize; --i >= 0;){
            long id = proto.getFriendId(i);
            result.friendList.add(id);
            result.addRelation(id, FRIEND_MASK);
        }

        // 仇人
        for (int i = enemySize; --i >= 0;){
            long id = proto.getEnemyId(i);

            result.enemyList.add(new EnemyRelationEntry(id, proto
                    .getEnemyScoreHistory(i)));
            result.addRelation(id, ENEMY_MASK);
        }

        // 黑名单
        for (int i = blackSize; --i >= 0;){
            long id = proto.getBlackId(i);
            result.blackList.add(id);
            result.addRelation(id, BLACK_MASK);
        }

        // 最近联系人
        for (int i = recentSize; --i >= 0;){
            long id = proto.getRecentId(i);
            result.recentList.add(id);
            result.addRelation(id, RECENT_MASK);
        }

        return result;
    }

    // ---- gm ----

    public LongArrayList gmGetFriendList(){
        return friendList;
    }

    public int gmGetFriendEmptyCount(){
        return FRIEND_COUNT_LIMIT - friendList.size();
    }

    public int gmGetEnemyEmptyCount(){
        return ENEMY_COUNT_LIMIT - enemyList.size();
    }

    public int gmGetBlackEmptyCount(){
        return BLACK_COUNT_LIMIT - blackList.size();
    }

    public void gmSetEnemyRecord(int num){
        int actualNum = Utils.getPointWithRange(MIN_ENEMY_RECORD,
                MAX_ENEMY_RECORD, num);

        for (EnemyRelationEntry entry : enemyList){
            entry.num = actualNum;
        }
    }
}
