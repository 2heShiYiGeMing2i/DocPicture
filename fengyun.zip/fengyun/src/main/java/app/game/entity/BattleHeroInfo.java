package app.game.entity;

import app.protobuf.TerritoryContent.HeroInfoProto;

import com.mokylin.collection.IntValueLongHashMap;
import com.mokylin.collection.IntValueLongHashMap.Entry;

public class BattleHeroInfo{

    private static final IntValueLongHashMap EMPTY_MAP = new IntValueLongHashMap(){
        public int put(long key, int value){
            return 0;
        };

        public int get(long key){
            return Integer.MAX_VALUE;
        };

        public void clear(){
        };
    };

    public long battleEndTime;

    public int accumulatedExp;

    public int accumulatedRealAir;

    public int accumulatedSecond;

    private FinalPrize finalPrize;

    private int totalKillTimes;

    private final IntValueLongHashMap killTimesMap;

    public int winGuildLilian;

    public int winContribution;

    public int loseGuildLilian;

    public int loseContribution;

    public BattleHeroInfo(boolean careKillTarget){
        if (careKillTarget)
            killTimesMap = new IntValueLongHashMap();
        else
            killTimesMap = EMPTY_MAP;
    }

    public FinalPrize getAndClearFinalPrize(){
        FinalPrize result = finalPrize;
        finalPrize = null;
        return result;
    }

    public void setFinalPrize(FinalPrize finalPrize){
        this.finalPrize = finalPrize;
    }

    /**
     * 如果当前的战斗结束时间和当前的不同, 则清空所有数据
     * 
     * 返回之前是否在同一场战斗中
     * 
     * @param battleEndTime
     */
    public boolean setStartIfNotStarted(long battleEndTime){
        if (this.battleEndTime != battleEndTime){
            this.battleEndTime = battleEndTime;
            this.accumulatedExp = 0;
            this.accumulatedRealAir = 0;
            this.accumulatedSecond = 0;
            this.prizeTime = 0;

            totalKillTimes = 0;
            killTimesMap.clear();

            winGuildLilian = 0;
            winContribution = 0;
            loseGuildLilian = 0;
            loseContribution = 0;
            return false;
        } else{
            return true;
        }
    }

    public void onBattleFinish(){
        totalKillTimes = 0;
        killTimesMap.clear();

        winGuildLilian = 0;
        winContribution = 0;
        loseGuildLilian = 0;
        loseContribution = 0;
    }

    public int addAccumulatedExp(int exp){
        return accumulatedExp += exp;
    }

    public int addAccumulatedRealAir(int realAir){
        return accumulatedRealAir += realAir;
    }

    /**
     * 每次到30秒就减到0
     */
    private transient int prizeTime;

    /**
     * 增加在战斗场景的时间
     * 
     * 返回是否应该加经验和真气了
     * @return
     */
    public boolean addAccumulatedSecond(int intervalSecond){
        ++accumulatedSecond;
        if (++prizeTime >= intervalSecond){
            prizeTime = 0;
            return true;
        } else{
            return false;
        }
    }

    public HeroInfoProto encode(){
        HeroInfoProto.Builder builder = HeroInfoProto.newBuilder()
                .setBattleEndTime(battleEndTime)
                .setAccumulatedExp(accumulatedExp)
                .setAccumulatedRealAir(accumulatedRealAir)
                .setAccumulatedSecond(accumulatedSecond)
                .setTotalKillTimes(totalKillTimes);

        for (Entry entry : killTimesMap.entrySet()){
            builder.addKillTargetId(entry.getKey());
            builder.addKillTargetTimes(entry.getValue());
        }

        return builder.build();
    }

    public void decode(HeroInfoProto proto){
        this.battleEndTime = proto.getBattleEndTime();
        this.accumulatedExp = proto.getAccumulatedExp();
        this.accumulatedRealAir = proto.getAccumulatedRealAir();
        this.accumulatedSecond = proto.getAccumulatedSecond();

        totalKillTimes = proto.getTotalKillTimes();
        int c = Math.min(proto.getKillTargetIdCount(),
                proto.getKillTargetTimesCount());
        for (int i = 0; i < c; i++){
            killTimesMap.put(proto.getKillTargetId(i),
                    proto.getKillTargetTimes(i));
        }

    }

    public enum FinalPrize{
        /**
         * 胜利的奖励
         */
        WIN,
        /**
         * 失败的奖励. 但还是有奖励
         */
        LOSE;
    }

    public boolean kill(long target, int killMaxTimes, int killOneMaxTimes){

        if (totalKillTimes >= killMaxTimes){
            return false;
        }

        int times = killTimesMap.get(target);
        if (times >= killOneMaxTimes){
            return false;
        }

        // 加次数
        if (++totalKillTimes >= killMaxTimes){
            killTimesMap.clear();
        } else{
            times = times > 0 ? times + 1 : 1;
            killTimesMap.put(target, times);
        }

        return true;
    }
}
