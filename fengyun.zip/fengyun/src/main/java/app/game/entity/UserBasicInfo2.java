package app.game.entity;

/**
 * 由 username+serverID+operatorID 唯一确定的一个 平台用户的基本信息
 * @author David
 *
 */
public class UserBasicInfo2{

    public final String username;
    public final int serverID;
    public final int operatorID;
    public final byte[] heroName;
    public final int heroLevel;

    public UserBasicInfo2(String username, int serverID, int operatorID,
            byte[] heroName, int heroLevel){
        super();
        this.username = username;
        this.serverID = serverID;
        this.operatorID = operatorID;
        this.heroName = heroName;
        this.heroLevel = heroLevel;
    }

}
