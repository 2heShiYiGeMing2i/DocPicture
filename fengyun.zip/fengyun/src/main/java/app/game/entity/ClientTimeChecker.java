package app.game.entity;

import org.joda.time.DateTimeConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.annotations.VisibleForTesting;

/**
 * 检测客户端的时间走的速度是否和服务器相同
 * @author Timmy
 *
 */
public class ClientTimeChecker{
    private static final Logger logger = LoggerFactory
            .getLogger(ClientTimeChecker.class);

    /**
     * 和前面任何一个的平均tick误差只要小于这个, 就不再检查了
     */
    @VisibleForTesting
    static final double PER_TICK_DIFF_ACCEPTABLE = 0.7f;

    /**
     * 只要某一个的平均tick误差大于这个值, 直接认为是外挂
     */
    @VisibleForTesting
    static final double PER_TICK_DIFF_UNACCEPTABLE = 5f;

    // -------

    /**
     * 总共保存多少个tick
     */
    static final int ENTRY_COUNT = 8;
    private static final int ENTRY_COUNT_TO_MOD = ENTRY_COUNT - 1; // mod, 找到entry slot

    /**
     * 多久必须tick一次
     */
    private static final long TICK_INTERVAL = 10L * DateTimeConstants.MILLIS_PER_SECOND;

    /**
     * 距离上次tick的时间超过这个数, 则踢掉
     */
    @VisibleForTesting
    static final long TICK_INTERVAL_MAX_LIMIT = (long) (TICK_INTERVAL * (1 + PER_TICK_DIFF_UNACCEPTABLE));

    /**
     * 还没进入过场景, 则可以2分钟没收到心跳
     */
    static final long TICK_INTERVAL_MAX_LIMIT_BEFORE_ENTER_SCENE = 2L * DateTimeConstants.MILLIS_PER_MINUTE;
    // -------

    private final TimeEntry[] entries;

    /**
     * 如果当前时间超过这个时间, 则踢掉. 减速挂
     */
    private long nextMustReceiveTickTime;

    private int nextIndex;

    private boolean hasEnteredScene;

    public ClientTimeChecker(long ctime){
        entries = new TimeEntry[ENTRY_COUNT];
        nextMustReceiveTickTime = ctime
                + TICK_INTERVAL_MAX_LIMIT_BEFORE_ENTER_SCENE;
    }

    /**
     * 第一次进入场景, 把下次必须收到心跳的时间设为正常
     * @param ctime
     */
    public void onHeroFirstEnteredScene(long ctime){
        hasEnteredScene = true;
        this.nextMustReceiveTickTime = ctime + TICK_INTERVAL_MAX_LIMIT;
    }

    /**
     * 收到任何消息, 就不会因为没发心跳而踢掉
     * @param ctime
     */
    public void onReceivedMsg(long ctime){
        if (hasEnteredScene){
            this.nextMustReceiveTickTime = ctime + TICK_INTERVAL_MAX_LIMIT;
        } else{
            this.nextMustReceiveTickTime = ctime
                    + TICK_INTERVAL_MAX_LIMIT_BEFORE_ENTER_SCENE;
        }
    }

    /**
     * 检查是否需要踢他下线
     * @param ctime
     * @return
     */
    public boolean needKick(long ctime){
        if (ctime >= nextMustReceiveTickTime){
            return true;
        }

        return false;
    }

    /**
     * 收到了心跳包
     *
     * @param ctime
     * @return true 需要踢掉. false 还正常
     */
    public boolean needKickOnClientTick(long clientTime, long ctime){
        if (!hasEnteredScene){
            nextMustReceiveTickTime = ctime
                    + TICK_INTERVAL_MAX_LIMIT_BEFORE_ENTER_SCENE;
            return false;
        }

        // 往前检查, 间隔小的, 单个tick允许的误差大. 间隔大的, 平均每个tick允许的误差就越小

        boolean hasAcceptableTick = false;

        for (TimeEntry oldEntry : entries){
            if (oldEntry == null){
                break;
            }

            long serverDiff = ctime - oldEntry.serverTime;
            if (serverDiff == 0){
                return false; // 服务器时间都没走过, 又来了, 算了
            }

            long clientDiff = clientTime - oldEntry.clientTime;

            double diff = Math.abs((((double) clientDiff) / serverDiff) - 1);

            if (diff >= PER_TICK_DIFF_UNACCEPTABLE){
                return true;
            }

            if (diff <= PER_TICK_DIFF_ACCEPTABLE){
                hasAcceptableTick = true;
                break;
            }
        }

        if (!hasAcceptableTick && nextIndex >= ENTRY_COUNT){
            // 已经过了一圈了, 还是没有可接受的tick, 踢
            return true;
        }

        TimeEntry entry = entries[nextIndex & ENTRY_COUNT_TO_MOD];
        if (entry == null){
            entry = new TimeEntry(clientTime, ctime);
            entries[nextIndex & ENTRY_COUNT_TO_MOD] = entry;
        } else{
            entry.set(clientTime, ctime);
        }

        ++nextIndex;
        return false;
    }

    private static class TimeEntry{
        private long clientTime;

        private long serverTime;

        TimeEntry(long clientTime, long serverTime){
            this.clientTime = clientTime;
            this.serverTime = serverTime;
        }

        private void set(long clientTime, long serverTime){
            this.clientTime = clientTime;
            this.serverTime = serverTime;
        }
    }
}
