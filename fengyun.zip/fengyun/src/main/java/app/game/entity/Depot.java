/**
 * 
 */
package app.game.entity;

import app.game.data.ConfigService;
import app.game.data.goods.Goods;
import app.game.data.goods.GoodsContainerUnlockData;
import app.protobuf.HeroServerContent.GoodsContainerServerProto;
import app.protobuf.HeroServerContent.GoodsListProto;

import com.mokylin.collection.IntArrayList;
import com.mokylin.collection.IntValueLongHashMap;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.annotation.SelfThreadOnly;

/**
 * 背包
 * 
 * @author Liwei
 * 
 */
public class Depot extends GoodsContainer{

    public static final int DEPOT_TYPE = 0;

    public static final int DEPOT_INIT_SIZE = 36;

    public static final int DEPOT_MAX_SIZE = 168;

    public static final int DEPOT_UNLOCK_SIZE = DEPOT_MAX_SIZE
            - DEPOT_INIT_SIZE;

    public static final int DEPOT_ROW_SLOT_COUNT = 7;

    public static Depot newDepot(long currentTime){
        return new Depot(DEPOT_INIT_SIZE,
                GoodsContainerUnlockData.FIRST_DEPOT_UNLOCK_DATA, currentTime,
                0);
    }

    private final boolean[] locks;

    private Depot(int initSize, GoodsContainerUnlockData unlockData,
            long ctime, long accOpenTime){
        super(DEPOT_TYPE, initSize, initSize + DEPOT_UNLOCK_SIZE, unlockData,
                ctime, accOpenTime);

        locks = new boolean[initSize + DEPOT_UNLOCK_SIZE];
    }

    // ----
    /**
     * 仅保存开格子数据
     * @param unlockData
     * @param logTime
     */
    private Depot(GoodsContainerUnlockData unlockData){
        super(DEPOT_TYPE, 0, 0, unlockData, 0, 0);
        locks = null;
    }

    public static Depot newDepotWithGoodsContainerUnlockData(
            GoodsContainerUnlockData unlockData){
        return new Depot(unlockData);
    }

    // ----

    private static final ThreadLocal<IntArrayList> localEmptyPosList = new ThreadLocal<IntArrayList>(){
        protected IntArrayList initialValue(){
            return new IntArrayList();
        }
    };

    /**
     * 每个线程一个IntArrayList
     */
    @SelfThreadOnly
    public IntArrayList getEmptyPos(int count){
        assert hasEnoughEmptyCount(count): "getEmptyPos(int)之前没有判断hasEnoughEmptyCount(int)";

        IntArrayList emptyPosList = localEmptyPosList.get();
        emptyPosList.clear();

        for (int i = 0; i < size; i++){
            if (goodsList[i] == null){
                emptyPosList.add(i);

                if (emptyPosList.size() >= count)
                    break;
            }
        }

        return emptyPosList;
    }

    public boolean isLocked(int pos){
        assert !isInvalidPos(pos);

        return locks[pos];
    }

    public void lock(int pos){
        assert !isInvalidPos(pos);
        locks[pos] = true;
    }

    public void unlock(int pos){
        assert !isInvalidPos(pos);
        locks[pos] = false;
    }

    public void unlockAll(){
        for (int i = 0; i < size; i++){
            locks[i] = false;
        }

        clearReserveCount();
    }

    /**
     * lock的位置是否都是有非绑定物品的
     * @return true表示都有, false表示有的格子被lock了, 但是物品是null或者是个绑定的物品
     */
    public boolean isLockedPosAllHaveUnbindedGoods(){
        Goods g;
        for (int i = 0; i < size; i++){
            if (locks[i]){
                g = goodsList[i];
                if (g == null || g.isBinded()){
                    return false;
                }
            }
        }
        return true;
    }

    public boolean hasLockedPos(){
        for (int i = 0; i < size; i++){
            if (locks[i]){
                return true;
            }
        }

        return false;
    }

    public static Depot decodeDepot(GoodsContainerServerProto proto,
            GoodsListProto goodsListProto, ConfigService cs, long ctime,
            IntValueLongHashMap goodsCountMap){

        if (DEPOT_TYPE != proto.getType()){
            System.err.println("decode Depot, type error.");
        }

        int goodsCount = 0;
        if (goodsListProto != null)
            goodsCount = goodsListProto.getGoodsListCount();

        int openSlotCount = proto.getOpenSlotCount();
        GoodsContainerUnlockData unlockData = cs.getUnlockDatas()
                .getDepotUnlockData(openSlotCount);

        int initSize = DEPOT_INIT_SIZE;
        if (initSize + unlockData.openSlotCount < goodsCount){
            // 我擦，物品个数居然比格子数还大... 扩大初始格子数
            int row = Utils.divide(goodsCount - initSize
                    - unlockData.openSlotCount, DEPOT_ROW_SLOT_COUNT);

            initSize += row * DEPOT_ROW_SLOT_COUNT;
        }

        Depot depot = new Depot(initSize, unlockData, ctime,
                proto.getAccOpenTime());
        if (goodsListProto != null)
            depot.decodeGoodsList(goodsListProto, cs, goodsCountMap);
        return depot;
    }
}
