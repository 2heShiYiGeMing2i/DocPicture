package app.game.entity.record.goods;

/**
 * 英雄物品拥有数量有异常, catch到后断线
 * @author Timmy
 *
 */
public class IllegalGoodsCountException extends RuntimeException{

    private static final long serialVersionUID = 149384994846288204L;

    public IllegalGoodsCountException(){
        super();
    }

    public IllegalGoodsCountException(String msg){
        super(msg);
    }

    public IllegalGoodsCountException(String msg, Throwable ex){
        super(msg, ex);
    }

    public IllegalGoodsCountException(Throwable ex){
        super(ex);
    }
}
