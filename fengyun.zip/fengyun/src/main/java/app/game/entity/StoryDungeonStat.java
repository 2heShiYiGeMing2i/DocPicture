package app.game.entity;

import app.protobuf.HeroContent.StoryDungeonStatProto;

public class StoryDungeonStat{

    public final int dungeonID;

    private boolean canNotEnterToday;

    private boolean hasFinishedToday;

    private int fastestRecord;

    public StoryDungeonStat(int dungeonID){
        this.dungeonID = dungeonID;
    }

    public int getFastestRecord(){
        return fastestRecord;
    }

    /**
     * 是否已经通关过
     * @return
     */
    public boolean hasPassed(){
        return fastestRecord > 0;
    }

    public void setTodayCanNotEnter(){
        canNotEnterToday = true;
    }

    public void setTodayFinished(){
        hasFinishedToday = true;
    }

    public boolean canEnterToday(){
        return !canNotEnterToday;
    }

    public void resetTodayEntered(){
        canNotEnterToday = false;
        hasFinishedToday = false;
    }

    /**
     * 更新最快通关时间, 返回之前的时间
     * @param record
     * @return
     */
    public int updateFastestRecordIfFaster(int record){
        if (fastestRecord == 0 || fastestRecord > record){
            int result = fastestRecord;
            fastestRecord = record;
            return result;
        }

        return fastestRecord;
    }

    public StoryDungeonStatProto encode(){
        StoryDungeonStatProto.Builder builder = StoryDungeonStatProto
                .newBuilder().setDungeonId(dungeonID);
        if (canNotEnterToday){
            builder.setCanNotEnterToday(true);
        }

        if (hasFinishedToday){
            builder.setIsFinishedToday(true);
        }

        if (fastestRecord > 0){
            builder.setFastestRecord(fastestRecord);
        }
        return builder.build();
    }

    public static StoryDungeonStat decode(StoryDungeonStatProto proto){
        StoryDungeonStat result = new StoryDungeonStat(proto.getDungeonId());
        result.fastestRecord = proto.getFastestRecord();
        result.canNotEnterToday = proto.getCanNotEnterToday();
        result.hasFinishedToday = proto.getIsFinishedToday();
        return result;
    }
}
