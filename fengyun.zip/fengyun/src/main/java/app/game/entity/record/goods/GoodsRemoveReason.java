package app.game.entity.record.goods;

public enum GoodsRemoveReason{
    ;

    final int actionID;

    private GoodsRemoveReason(int actionID){
        this.actionID = actionID;
    }
}
