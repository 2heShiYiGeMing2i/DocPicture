/**
 * 
 */
package app.game.entity;

import com.mokylin.collection.IntValueLongHashMap;
import com.mokylin.sink.util.Utils;

import app.game.data.ConfigService;
import app.game.data.goods.GoodsContainerUnlockData;
import app.protobuf.HeroServerContent.GoodsContainerServerProto;
import app.protobuf.HeroServerContent.GoodsListProto;

/**
 * 仓库
 * 
 * @author Liwei
 * 
 */
public class Storage extends GoodsContainer{

    public static final int STORAGE_TYPE = 1;

    public static final int STORAGE_INIT_SIZE = 40;

    public static final int STORAGE_MAX_SIZE = 240;

    public static final int STORAGE_UNLOCK_SIZE = STORAGE_MAX_SIZE
            - STORAGE_INIT_SIZE;

    public static final int STORAGE_ROW_SLOT_COUNT = 8;

    public static Storage newStorage(long currentTime){
        return new Storage(STORAGE_INIT_SIZE,
                GoodsContainerUnlockData.FIRST_STORAGE_UNLOCK_DATA,
                currentTime, 0);
    }

    private Storage(int initSize, GoodsContainerUnlockData unlockData,
            long currentTime, long accOpenTime){
        super(STORAGE_TYPE, initSize, initSize + STORAGE_UNLOCK_SIZE,
                unlockData, currentTime, accOpenTime);
    }

    // ----
    /**
     * 仅保存开格子数据
     * @param unlockData
     * @param logTime
     */
    private Storage(GoodsContainerUnlockData unlockData){
        super(STORAGE_TYPE, 0, 0, unlockData, 0, 0);
    }

    public static Storage newStorageWithGoodsContainerUnlockData(
            GoodsContainerUnlockData unlockData){
        return new Storage(unlockData);
    }

    // -----

    public boolean isLocked(int pos){
        return false;
    }

    public static Storage decodeStorage(GoodsContainerServerProto proto,
            GoodsListProto goodsListProto, ConfigService cs, long ctime,
            IntValueLongHashMap goodsCountMap){

        if (STORAGE_TYPE != proto.getType()){
            System.err.println("decode Storage, type error.");
        }

        int goodsCount = 0;
        if (goodsListProto != null)
            goodsCount = goodsListProto.getGoodsListCount();

        int openSlotCount = proto.getOpenSlotCount();
        GoodsContainerUnlockData unlockData = cs.getUnlockDatas()
                .getStorageUnlockData(openSlotCount);

        int initSize = STORAGE_INIT_SIZE;
        if (initSize + unlockData.openSlotCount < goodsCount){
            // 我擦，物品个数居然比格子数还大... 扩大初始格子数
            int row = Utils.divide(goodsCount - initSize
                    - unlockData.openSlotCount, STORAGE_ROW_SLOT_COUNT);

            initSize += row * STORAGE_ROW_SLOT_COUNT;
        }

        long accOpenTime = proto.getAccOpenTime();

        Storage storage = new Storage(initSize, unlockData, ctime, accOpenTime);

        if (goodsListProto != null)
            storage.decodeGoodsList(goodsListProto, cs, goodsCountMap);
        return storage;
    }
}
