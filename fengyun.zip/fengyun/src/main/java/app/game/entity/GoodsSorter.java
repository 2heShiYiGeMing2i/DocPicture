package app.game.entity;

import java.util.Arrays;

import app.game.data.goods.Goods;
import app.game.data.goods.GoodsFolder;

import com.mokylin.collection.IntArrayList;

public enum GoodsSorter{
    DEFAULT_SORTER {
        @Override
        void dofold(Goods[] goodsList, int size){
            Goods[] agoods = goodsList;
            int length = size;

            // 先标记各个物品整理之前所在的位置，同时找出所有可堆叠物品的位置
            IntArrayList foldablePos = new IntArrayList(length);
            for (int i = 0; i < size; i++){
                Goods g = goodsList[i];
                if (g != null){
                    g.pos = i;

                    if (g.notFull()){
                        foldablePos.add(i);
                    }
                }
            }

            // 只循环可堆叠物品位置
            length = foldablePos.size();
            outer: for (int i = 0; i < length; i++){
                Goods goods = agoods[foldablePos.get(i)];
                if (goods == null){
                    // 可能被合并入之前的堆, 可能为null
                    continue;
                }
                int maxCount = goods.getData().getMaxCount();

                if (goods.getCount() < maxCount){
                    for (int k = i + 1; k < length; k++){
                        Goods goods1 = agoods[foldablePos.get(k)];
                        if (goods1 != null && goods1.isSameGoods(goods)){
                            int l = goods.getCount() + goods1.getCount();
                            if (l > maxCount){
                                int moveCount = maxCount - goods.getCount();
                                goods1.foldTo(goods, moveCount);
                                continue outer;
                            } else{
                                goods1.foldTo(goods);
                                agoods[foldablePos.get(k)] = null;
                                if (l == maxCount){
                                    continue outer;
                                }
                            }
                        }
                    }
                }
            }
        }
    },
    FAST_SORTER {
        @Override
        void dofold(Goods[] goodsList, int size){

            Goods[] agoods = goodsList;
            int length = size;

            GoodsFolder goodsFolder = GoodsFolder.current();
            goodsFolder.beforeClear();
            try{
                // 先标记各个物品整理之前所在的位置
                // 找到所有可堆叠物品的位置
                for (int i = 0; i < length; i++){
                    Goods g = agoods[i];
                    if (g == null){
                        continue;
                    }

                    g.pos = i;

                    if (!g.notFull()){
                        continue;
                    }

                    Goods sameGoods = goodsFolder.putIfNotSameGoods(g);
                    if (sameGoods == null){
                        continue;
                    }

                    int maxCount = g.getData().getMaxCount();

                    int l = sameGoods.getCount() + g.getCount();
                    if (l > maxCount){
                        int moveCount = maxCount - sameGoods.getCount();
                        g.foldTo(sameGoods, moveCount);
                        goodsFolder.replace(sameGoods, g);
                    } else{
                        g.foldTo(sameGoods);
                        agoods[i] = null;

                        if (l == maxCount){
                            goodsFolder.remove(sameGoods);
                        }
                    }
                }
            } finally{
                goodsFolder.afterClear();
            }
        }
    };

    abstract void dofold(Goods[] goodsList, int size);

    public void sort(GoodsContainer goodsContainer){
        Goods[] goodsList = goodsContainer.goodsList;
        int size = goodsContainer.size();

        sort(goodsList, size);
    }

    public void sort(Goods[] goodsList, int size){
        // 先做堆叠，堆叠完成后排序一次(物品类型，物品id，绑定在前，过期时间早的在前，堆叠数量多的在前)
        dofold(goodsList, size);
        Arrays.sort(goodsList, 0, size, Goods.SORT_OUT_COMP);
    }

}