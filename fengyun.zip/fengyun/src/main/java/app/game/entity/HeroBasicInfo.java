package app.game.entity;

public class HeroBasicInfo{

    public final int id;
    public final byte[] heroName;
    public final int heroLevel;
    public final long heroCreateTime;

    public HeroBasicInfo(int id, byte[] heroName, int heroLevel,
            long heroCreateTime){
        super();
        this.id = id;
        this.heroName = heroName;
        this.heroLevel = heroLevel;
        this.heroCreateTime = heroCreateTime;
    }
}
