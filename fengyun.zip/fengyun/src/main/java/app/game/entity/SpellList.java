package app.game.entity;

import java.util.Collection;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.data.ConfigService;
import app.game.data.goods.Goods;
import app.game.data.goods.GoodsData;
import app.game.data.spell.PassiveSpell;
import app.game.data.spell.SingleEffectSpell;
import app.game.data.spell.SingleEffectSpell.SingleEffectSpellWithUsedTimes;
import app.game.data.spell.Spells;
import app.game.data.weapon7.SuperWeaponData;
import app.protobuf.HeroContent.HeroProto;
import app.protobuf.HeroServerContent.CombineXinfaSpellServerProto;
import app.protobuf.HeroServerContent.HeroServerProto;
import app.utils.VariableConfig;

import com.mokylin.collection.IntHashMap;
import com.mokylin.collection.IntValueLongHashMap;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.annotation.MultiThread;
import com.mokylin.sink.util.annotation.SelfThreadOnly;

public class SpellList{
    private static final Logger logger = LoggerFactory
            .getLogger(SpellList.class);

    /**
     * key 是spellType
     */
    @SelfThreadOnly
    private final IntHashMap<SingleEffectSpellWithUsedTimes> singleEffectSpells;

    @SelfThreadOnly
    private final IntHashMap<PassiveSpell> passiveSpells;

//    @MultiThread
//    private PassiveSpell[] passiveSpells;

    private final int[] shortcuts;
    private int defaultSpellPos;

    public final int rageMaxAMount;

    /**
     * 技能战斗力
     */
    private int spellFightingAmount;

    /**
     * 怒气值
     */
    private int rageAmount;

    public SpellList(int rageMaxAmount){
        this.rageMaxAMount = rageMaxAmount;

        singleEffectSpells = new IntHashMap<>();
        passiveSpells = new IntHashMap<>();
        shortcuts = new int[VariableConfig.SHORTCUT_COUNT];
        defaultSpellPos = -1;
    }

    private SpellList(int rageMaxAmount, int singleEffectSpellsCount,
            int passiveSpellsCount){
        this.rageMaxAMount = rageMaxAmount;

        singleEffectSpells = new IntHashMap<>(singleEffectSpellsCount);
        passiveSpells = new IntHashMap<>(passiveSpellsCount);
        shortcuts = new int[VariableConfig.SHORTCUT_COUNT];
        defaultSpellPos = -1;
    }

    public int getRageAmount(){
        return rageAmount;
    }

    public boolean isRageFull(){
        return rageAmount >= rageMaxAMount;
    }

    public int addRageAmount(int toAdd){
        return rageAmount = Math.min(rageAmount + toAdd, rageMaxAMount);
    }

    public void setRageAmount(int newRage){
        this.rageAmount = Utils.getPointWithRange(0, rageMaxAMount, newRage);
    }

    public void clearRangeAmount(){
        rageAmount = 0;
    }

    public int getFightingAmount(){
        return spellFightingAmount;
    }

    @SelfThreadOnly
    private int updateFightingAmount(){

        int fightingAmount = 0;

        // 主动技能
        for (SingleEffectSpellWithUsedTimes sp : singleEffectSpells.values()){
            fightingAmount += sp.getActualSpell().getFightingAmount();
        }

        // 被动技能
        for (PassiveSpell ps : passiveSpells.values()){
            if (ps != null)
                fightingAmount += ps.getFightingAmount();
        }

        return spellFightingAmount = fightingAmount;
    }

    @SelfThreadOnly
    public SingleEffectSpellWithUsedTimes addSingleEffectSpell(
            SingleEffectSpellWithUsedTimes spell){
        SingleEffectSpellWithUsedTimes old = singleEffectSpells.put(
                spell.getActualSpell().spellType, spell);
        if (old == null){
            spellFightingAmount += spell.getActualSpell().getFightingAmount();
        } else{
            spellFightingAmount += (spell.getActualSpell().getFightingAmount() - old
                    .getActualSpell().getFightingAmount());
        }

        return old;
    }

    public boolean setShortcut(int spellType, int pos, int defaultSpellPos){
        if (pos < 0 || pos >= VariableConfig.SHORTCUT_COUNT){
            return false;
        }
        shortcuts[pos] = spellType;
        this.defaultSpellPos = defaultSpellPos;
        return true;
    }

    @SelfThreadOnly
    public PassiveSpell addPassiveSpell(PassiveSpell spell){
        PassiveSpell old = passiveSpells.put(spell.spellType, spell);
        if (old == null){
            spellFightingAmount += spell.getFightingAmount();
        } else{
            spellFightingAmount += (spell.getFightingAmount() - old
                    .getFightingAmount());
        }

        return old;
    }

    @SelfThreadOnly
    public SingleEffectSpellWithUsedTimes getSingleEffectSpell(int spellType){
        return singleEffectSpells.get(spellType);
    }

    @MultiThread
    public Collection<SingleEffectSpellWithUsedTimes> getSingleEffectSpells(){
        // 多线程环境下面可能不准确
        return singleEffectSpells.values();
    }

    @MultiThread
    public Collection<PassiveSpell> getPassiveSpells(){
        // 多线程环境下面可能不准确
        return passiveSpells.values();
    }

    public PassiveSpell getPassiveSpell(int spellType){
        return passiveSpells.get(spellType);
    }

    // ---------- encode & decode ----------
    public void encode(HeroServerProto.Builder builder){
        builder.setRageAmount(rageAmount);

        for (SingleEffectSpellWithUsedTimes s : singleEffectSpells.values()){
            builder.addCombineXinfaSpells(s.encode());
        }
        for (PassiveSpell ps : passiveSpells.values()){
            builder.addPassiveSpells(ps.id);
        }

        for (int i = 0; i < VariableConfig.SHORTCUT_COUNT; i++){
            if (shortcuts[i] != 0){
                builder.addShortcutSpellType(shortcuts[i]);
                builder.addShortcutSpellPos(i);
            }
        }

        builder.setDefaultSpellPos(defaultSpellPos);
    }

    public static SpellList decode(HeroServerProto proto,
            ConfigService configService, boolean isForOtherView,
            IntValueLongHashMap goodsCountMap){
        int singleSpellCount = proto.getCombineXinfaSpellsCount();
        int passiveSpellCount = proto.getPassiveSpellsCount();

        SpellList result = new SpellList(
                configService.getConfig().RAGE_MAX_AMOUNT, singleSpellCount,
                passiveSpellCount);

        result.rageAmount = proto.getRageAmount();
        Spells spells = configService.getSpells();

        // 主动技能
        for (int i = 0; i < singleSpellCount; i++){
            CombineXinfaSpellServerProto spellProto = proto
                    .getCombineXinfaSpells(i);
            SingleEffectSpell spell = spells.getSingleEffectSpells().get(
                    spellProto.getSpellId());
            if (spell == null){
                logger.error("decode 技能列表时, 有个主动技能找不到了: {}",
                        spellProto.getSpellId());
                continue;
            }

            SingleEffectSpellWithUsedTimes usedTimeSpell = spell
                    .withUsedTimes(spellProto.getUsedTimes());

            if (spellProto.hasXinfa()){
                Goods xinfaGoods = Goods.decode(spellProto.getXinfa(),
                        configService, goodsCountMap);
                usedTimeSpell.setXinfa(xinfaGoods);
            }

            result.addSingleEffectSpell(usedTimeSpell);
        }

        // 被动技能
        for (int i = 0; i < passiveSpellCount; i++){
            int spellID = proto.getPassiveSpells(i);
            PassiveSpell ps = spells.passiveSpells.get(spellID);
            if (ps == null){
                logger.error("decode 技能列表时, 有个被动技能找不到了: {}", spellID);
                continue;
            }
            result.addPassiveSpell(ps);
        }

        if (!isForOtherView){
            // 快捷栏
            int shortcutCount = Math.min(proto.getShortcutSpellTypeCount(),
                    proto.getShortcutSpellPosCount());
            for (int i = 0; i < shortcutCount; i++){
                int pos = proto.getShortcutSpellPos(i);
                if (pos >= VariableConfig.SHORTCUT_COUNT){
                    continue;
                }

                // pos 肯定>=0的
                int shortcut = proto.getShortcutSpellType(i);
                int type = shortcut & 0b111; // 支持0-7
                int realId = shortcut >>> 3;
                switch (type){
                    case 0:{
                        // 英雄技能
                        if (result.singleEffectSpells.containsKey(realId)){
                            // 会这个技能, 才放入快捷栏
                            result.shortcuts[pos] = shortcut;
                        }
                        break;
                    }
                    case 1:{
                        // 物品
                        GoodsData g = configService.getGoods().get(realId);

                        if (g != null && g.getEfficacy() != null){
                            // 这个物品可以使用才放进去
                            result.shortcuts[pos] = shortcut;
                        }
                        break;
                    }
                    case 2:{
                        // 神兵技能
                        SuperWeaponData weapon = configService
                                .getSuperWeapons().get(realId);
                        if (weapon != null){
                            result.shortcuts[pos] = shortcut;
                        }
                        break;
                    }
                    default:{
                        // 无效的类型
                        break;
                    }
                }
            }
            result.defaultSpellPos = proto.getDefaultSpellPos();
        }

        // 更新战斗力
        result.updateFightingAmount();

        return result;
    }

    public void encodeToSelfHeroOnLogin(HeroProto.Builder builder){
        for (SingleEffectSpellWithUsedTimes sp : singleEffectSpells.values()){
            builder.addCombineSpells(sp.encodeToSelfHeroOnLogin());
        }

        for (PassiveSpell sp : passiveSpells.values()){
            builder.addPassiveSpell(sp.getProto());
        }

        for (int i = 0; i < VariableConfig.SHORTCUT_COUNT; i++){
            if (shortcuts[i] != 0){
                builder.addShortcutSpellType(shortcuts[i]);
                builder.addShortcutSpellPos(i);
            }
        }
        builder.setDefaultSpellPos(defaultSpellPos).setRageAmount(rageAmount);
    }
}
