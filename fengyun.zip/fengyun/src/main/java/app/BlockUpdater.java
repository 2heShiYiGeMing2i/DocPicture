package app;

import java.io.File;
import java.io.FileOutputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import app.game.data.FileLoaderModule;
import app.game.data.scene.*;

import com.google.common.collect.Sets;
import com.google.common.io.Resources;
import com.mokylin.sink.util.pack.FileLoader;
import com.mokylin.sink.util.parse.ObjectParser;
import com.mokylin.sink.util.parse.ObjectParsers;

/**
 * @author Liwei
 *
 */
public class BlockUpdater{

    private static final String LOCAL_DIR = "config/data/scene/block/";

    private static final String REMOTE_DIR = "http://168.168.1.18/wind/res/map/";

    private static final String REMOTE_FINENAME = "/data.dat";

    public static void main(String[] args){
        update();
    }

    public static void update(){
        try{
            Executor exec = Executors.newCachedThreadPool();

            Set<String> fileNames = loadBlockFileNames(exec);

            final CountDownLatch latch = new CountDownLatch(fileNames.size());
            for (final String name : fileNames){
                exec.execute(new Runnable(){
                    @Override
                    public void run(){
                        doUpdate(name, latch);
                    }
                });
            }

            try{
                latch.await();
            } catch (InterruptedException e){
                e.printStackTrace();
            }

            System.out.println("block 更新完毕");
        } catch (Exception e){
            e.printStackTrace();
        }

        System.exit(0);
    }

    private static void doUpdate(String fileName, CountDownLatch latch){
        try{
            String localPath = LOCAL_DIR + fileName;

            String remoteURL = REMOTE_DIR + fileName + REMOTE_FINENAME;

            byte[] dataBytes = Resources.toByteArray(new URL(remoteURL));

            File file = new File(localPath);
            file.getParentFile().mkdirs();
            if (!file.exists()){
                file.createNewFile();
            }

            FileOutputStream fos = new FileOutputStream(localPath);
            fos.write(dataBytes);
            fos.flush();

            fos.close();
        } catch (Exception e){
            e.printStackTrace();
        } finally{
            latch.countDown();
        }
    }

    static List<ObjectParser> loadScenes(Executor exec, String... locations){
        FileLoader fileLoader = new FileLoaderModule().doGetFromLocal();
        List<ObjectParser> result = new ArrayList<>();

        for (String location : locations){
            List<ObjectParser> list = ObjectParsers.parseList(location,
                    fileLoader.readFile(location), exec);

            result.addAll(list);
        }

        return result;
    }

    static Set<String> loadBlockFileNames(Executor exec){

        List<ObjectParser> datas = loadScenes(exec, NormalSceneDatas.LOCATION,
                StoryDungeonSceneDatas.LOCATION,
                ChallengeDungeonSceneDatas.LOCATION,
                VipDungeonSceneDatas.LOCATION,
                DefenceDungeonSceneDatas.LOCATION,
                SouShenDungeonSceneDatas.LOCATION,
                LingYunDungeonSceneDatas.LOCATION,
                LongMaiDungeonSceneDatas.LOCATION,
                PortalDungeonSceneDatas.LOCATION,
                HuoLinActivitySceneDatas.LOCATION, JijianSceneDatas.LOCATION);

        Set<String> fileNames = Sets.newHashSetWithExpectedSize(datas.size());

        for (ObjectParser p : datas){
            String name = p.getKey("map_name");
            if (name.isEmpty()){
                continue;
            }

            fileNames.add(name);
        }

        return fileNames;
    }
}
