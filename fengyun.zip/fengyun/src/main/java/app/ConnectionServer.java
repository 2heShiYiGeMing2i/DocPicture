package app;

import java.io.Closeable;

import app.game.ListenPort;
import app.utils.IndividualServerConfig;

import com.google.inject.Inject;
import com.mokylin.sink.server.NettyServer;
import com.mokylin.sink.server.SecurityServer;
import com.mokylin.sink.server.WorkerFactory;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.concurrent.PaddedAtomicReference;

public class ConnectionServer implements Closeable{

    private enum Stage{
        INIT, STARTED, STOPPED;
    }

    private final PaddedAtomicReference<Stage> stage = new PaddedAtomicReference<Stage>(
            Stage.INIT);

    private final SecurityServer securityServer;
    private final NettyServer nettyServer;

    @Inject
    ConnectionServer(@ListenPort int port, WorkerFactory workerFactory,
            IndividualServerConfig serverConfig){
        this.securityServer = new SecurityServer(7890);
        this.nettyServer = new NettyServer(port, workerFactory);
    }

    public void start(){
        if (!stage.compareAndSet(Stage.INIT, Stage.STARTED)){
            throw new IllegalStateException("GameServer illegal stage: "
                    + stage.get());
        }
        securityServer.start();
        nettyServer.start();
    }

    public void close(){
        if (!stage.compareAndSet(Stage.STARTED, Stage.STOPPED)){
            throw new IllegalStateException("GameServer illegal stage: "
                    + stage.get());
        }

        Utils.closeQuietly(securityServer);
        Utils.closeQuietly(nettyServer);
    }

}
