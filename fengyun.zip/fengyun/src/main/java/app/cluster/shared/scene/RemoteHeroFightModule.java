package app.cluster.shared.scene;

import static app.game.module.HeroMiscMessages.*;
import static app.game.module.scene.SceneMessages.*;

import java.lang.ref.WeakReference;

import org.jboss.netty.buffer.ChannelBuffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.cluster.client.logic.team.ClusterClientMessages;
import app.game.data.HeroLevelData;
import app.game.data.HeroLevelDatas;
import app.game.data.SpriteStat;
import app.game.data.goods.Goods;
import app.game.data.goods.SceneAmountGoodsHolder;
import app.game.data.goods.SceneRealGoodsHolder;
import app.game.data.scene.MonsterData;
import app.game.data.scene.NormalSceneData;
import app.game.data.spell.FightState.FightStateInstance;
import app.game.data.spell.SingleEffectSpell;
import app.game.entity.Hero;
import app.game.module.HeroID;
import app.game.module.MiscModule.DisconnectReason;
import app.game.module.Modules;
import app.game.module.guild.RemoteGuild;
import app.game.module.guild.RemoteGuildMember;
import app.game.module.scene.AbstractHeroFightModule;
import app.game.module.scene.FightData;
import app.game.module.scene.FightModule;
import app.game.module.scene.SceneGoods;
import app.game.module.scene.SceneMessages;
import app.game.module.team.TeamMember;
import app.game.service.SelfThreadExecuteService.ExecutorRelatedObject;
import app.game.service.SelfThreadExecuteService.HeroKilledHeroEvent;
import app.message.ISender;
import app.protobuf.LogContent.LogEnum.TransportType;
import app.utils.VariableConfig;

import com.mokylin.sink.server.MessageProcessorInDisruptor;
import com.mokylin.sink.util.BufferUtil;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.annotation.MultiThread;
import com.mokylin.sink.util.concurrent.DisruptorExecutor;

public class RemoteHeroFightModule extends AbstractHeroFightModule implements
        MessageProcessorInDisruptor{
    private static final Logger logger = LoggerFactory
            .getLogger(RemoteHeroFightModule.class);

    private final ISender worker;

    private final ProxySender sender;

    private final AbstractRemoteClusterScene parent;

    private final RemoteGuildMember guildMember;

    private TeamMember teamMember; // TODO 远程服需要发送队伍人数 (计算增加的属性)

    private transient ChannelBuffer singleMediateMessage;
    private transient ChannelBuffer doubleMediateMessage;

    /**
     * 来自帮派的额外属性
     */
    private transient SpriteStat additionalStatFromGuild;

    // 占领信息
    private transient boolean isTerritotyMaster;

    private transient boolean isWsCityMaster;

    private transient boolean isLongCityMaster;

    public RemoteHeroFightModule(Hero hero, ProxySender sender,
            RemoteGuildMember remoteGuildMember,
            AbstractRemoteClusterScene parent, DisruptorExecutor exec,
            ExecutorRelatedObject relatedObject, long ctime, ISender worker){
        super(hero, exec, sender, parent, relatedObject, ctime);

        this.worker = worker;
        this.hasEnteredScene = true;
        this.sender = sender;
        this.parent = parent;

        FightData fightData = hero.getFightData();
        this.lastSyncX = fightData.getX();
        this.lastSyncY = fightData.getY();
        this.lastLife = fightData.getLife();
        this.nextSyncPosLifeTime = ctime + SYNC_INTERVAL;

        HeroID heroID = new HeroID(hero.getID());

        this.guildMember = remoteGuildMember;
        this.teamMember = TeamMember
                .fromHero(heroID, hero, sender,
                        new WeakReference<AbstractHeroFightModule>(this),
                        relatedObject);

        RemoteGuild g = remoteGuildMember.getGuild();
        if (g != null){
            this.additionalStatFromGuild = g.getAdditionalSpriteStat();
            fightData.setChangedStat(additionalStatFromGuild);

            isTerritotyMaster = g.isTerritoryMaster();
            isWsCityMaster = g.isWsCityMaster();
            isLongCityMaster = g.isLongCityMaster();
        }
    }

    public ISender getWorker(){
        return worker;
    }

    protected int getPVipMask(){
        return 0; // TODO 跨服时候没有设置
    }

    @Override
    public boolean isOffline(){
        return false;
    }

    public void setLevel(int oldLevel, int newLevel){
        assert Thread.currentThread() == taskExec.getThread();
        HeroLevelDatas datas = parent.getConfigService().getHeroLevelDatas();

        HeroLevelData oldLevelData = datas.get(oldLevel);
        HeroLevelData newLevelData = datas.get(newLevel);

        if (oldLevelData == null){
            logger.error(
                    "RemoteHeroFightModule.setLevel时, oldLevel的HerolevelData没找到: {}",
                    oldLevel);
            oldLevelData = hero.getLevelData();
        }

        if (newLevelData == null){
            logger.error(
                    "RemoteHeroFightModule.setLevel时, newLevel的HeroLevelData没找到: {}",
                    newLevel);
            return;
        }

        getHero().getFightData().setLevel(newLevel);
        getHero().setLevelData(newLevelData);

        sharedOnLevelChanged(oldLevelData, newLevel, false);
    }

    @Override
    public ProxySender getSender(){
        return sender;
    }

    @Override
    public AbstractRemoteClusterScene getParent(){
        return parent;
    }

    @Override
    public void doLeaveDungeonAndSendDungeonTimeUpMsg(){
        sendMessage(ClusterClientMessages.dungeonTimeUp);
        doLeaveDungeon();
    }

    public void setHasEnteredScene(boolean newValue){
        this.hasEnteredScene = newValue;
    }

    @Override
    public void doLeaveDungeon(){
        logger.debug("主动要求英雄退出副本: {}", this);
        if (!hasEnteredScene){
            return;
        }
        getParent().removeHero(this, false);
        getSender().sendToServer(
                ClusterSceneHeader.onlySendHeadAndAVarInt64Message(
                        ClusterSceneHeader.C2S_HERO_LEAVE,
                        getParent().sceneUUID, getID()));
    }

    @Override
    public void disconnect(DisconnectReason reason){
    }

    public void addFightStateFromLocalScene(FightStateInstance fsi, long ctime){
        SpriteStat oldStat = fightData.getTotalStat();
        SpriteStat oldBaseStat = fightData.getBaseStat();
        SpriteStat oldChangedStat = fightData.getChangedStat();

        nextUpdateStateTime = Math
                .min(nextUpdateStateTime, fsi.nextWorkingTime);

        FightStateInstance[] states = fightData.getStates();
        for (int i = fightData.getStateSize(); --i >= 0;){
            if (states[i] == null){
                continue;
            }

            if (fsi.getActualState().isSameGroup(states[i])){
                fightData.removeState(i);
                break; // 肯定不会再有同一个group存在了, 继续添加下一个状态
            }
        }

        fightData.addState(fsi);
        clearCurrentPathIfStunOrUnmovable();

        SpriteStat newBaseStat = fightData.getBaseStat();
        SpriteStat newChangedStat = fightData.getChangedStat();
        if (oldBaseStat != newBaseStat || newChangedStat != oldChangedStat){
            SpriteStat newStat = fightData.updateTotalStat();
            onStatChanged(oldStat, newStat, ctime);
        }

        // 广播

        selfThreadBroadcastAroundAndSelf(addFightStateMsg(getID(), fsi));
    }

    @Override
    protected boolean isParentReliveLimit(){
        return parent.getSceneData().isReliveLimit;
    }

    @MultiThread
    @Override
    protected void onThisBeenKilled(FightModule attacker, long ctime,
            long realDeadTime){
        if (!killed.compareAndSet(false, true)){
            return;
        }

        mustReliveTime = ctime + VariableConfig.HERO_DEAD_MUST_RELIVE_TIME;

        parent.onHeroDead(this);

        FightModule realAttacker = attacker == null ? null : attacker
                .getRealFightModule();

        // 死人了!!
        sendYouAreDeadMessage(realAttacker);
    }

    @Override
    protected void onKilledBroadcastKillEventToFriendAndEnemy(long killerID,
            byte[] killerNameBytes, long deadID, byte[] deadNameBytes,
            int sceneConfigID){

    }

    @Override
    protected void onBeenKilledAddEnemy(long otherHeroID,
            byte[] otherHeroNameBytes){

    }

    @Override
    protected void onActivityBeenKilled(HeroKilledHeroEvent killEvent){
    }

    @Override
    protected void onKillOtherHero(HeroKilledHeroEvent killEvent){

    }

    @Override
    public TeamMember getTeamMember(){
        return teamMember;
    }

    @Override
    public RemoteGuildMember getGuildMember(){
        return guildMember;
    }

    @Override
    public boolean isTerritoryMaster(){
        return isTerritotyMaster;
    }

    @Override
    public boolean isWsCityMaster(){
        return isWsCityMaster;
    }

    @Override
    public boolean isLongCityMaster(){
        return isLongCityMaster;
    }

    @Override
    protected boolean canBeShootMount(){
        return hero.getModel().hasMount();
    }

    @Override
    protected void onShootMount(long ctime){
        getSender().sendToServer(
                ClusterSceneHeader.onlySendHeadAndAVarInt64Message(
                        ClusterSceneHeader.C2S_SHOOT_MOUNT,
                        getParent().sceneUUID, getID()));
    }

    @Override
    public void handleHeroKilledMonsterEvent(MonsterData monster){
        if (!spellList.isRageFull()){
            // 加怒气值
            spellList.addRageAmount(VariableConfig.ADD_RAGE_PER_TIMES);

            if (spellList.isRageFull()){
                // 怒气满了，发送个消息通知客户端
                sendMessage(RAGE_MAX_MSG);
            } else{
                sendMessage(RAGE_INCREMENT_MSG);
            }
        }

        // 发送消息给本地场景
        sender.sendToServer(ClusterSceneHeader.C2S.killedMonster(
                parent.sceneUUID, getID(), monster.id));
    }

    @Override
    protected void doChangeScene(NormalSceneData target, int line, int x,
            int y, TransportType transportType){
        // 发送消息给游戏服, 然后这里直接把英雄移出场景
        assert Thread.currentThread() == taskExec.getThread(): "RemoteHeroFightModule.doChangeScene不是由英雄自己的线程调用的";

        parent.removeHero(this, false);

        doSyncPosLifeAndJumpShield(getFightData().getJumpShield()); // 先同步一次血量和别的属性
        sender.sendToServer(ClusterSceneHeader.C2S
                .changeToNormalScene(parent.sceneUUID, getID(), target.id,
                        line, x, y, transportType));
    }

    public void onTryReduceToolAndPerfectReliveSuccess(){
        isWaitingToReduceTool = false;

        if (!killed.get()){
            logger.error("RemoteHeroFightModule.onTryReduceToolAndPerfecReliveSuccess时, 物品也已经扣了, 英雄竟然没死... kill.get() == false");
            return;
        }
        processPerfectRelive();
    }

    public void onTryReduceToolAndPerfectReliveFail(){
        isWaitingToReduceTool = false;
    }

    @Override
    protected void tryReduceToolAndPerfectRelive(int suggestedPos){
        // 发送要删除一个复活道具消息给游戏服, 游戏服自己删除后, 再发还一条消息, 这里才真正开始复活
        isWaitingToReduceTool = true;

        sender.sendToServer(ClusterSceneHeader.C2S
                .tryReduceToolAndPerfectRelive(parent.sceneUUID, getID(),
                        suggestedPos));
    }

    public void updatePerMillis(long ctime){
        heroUpdate(ctime);
    }

    public void updatePerSecond(long ctime){
        sharedUpdatePerSecond(ctime);
        trySyncPosLife(ctime);
    }

    @Override
    protected void addExpAndRealAirOnMediate(boolean isDoubleMediate){
        // 发送消息给游戏服
        if (isDoubleMediate){
            sender.sendToServer(doubleMediateMessage != null ? doubleMediateMessage
                    : (doubleMediateMessage = ClusterSceneHeader.C2S
                            .heroMediate(parent.sceneUUID, getID(), true)));
        } else{
            sender.sendToServer(singleMediateMessage != null ? singleMediateMessage
                    : (singleMediateMessage = ClusterSceneHeader.C2S
                            .heroMediate(parent.sceneUUID, getID(), false)));
        }
    }

    @Override
    public void sendSpellReleasedMessage(SingleEffectSpell spell, int spellType){
        sender.sendToServer(CombatHeader.heroReleasedSpell(getID(), spellType));

        if (spell.isRageSpell()){
            // 本地服收到释放怒气技能, 会清掉怒气值
            lastRage = 0;
        }
    }

    @Override
    protected void addJumpShield(int amount){
        int oldJumpShield = getFightData().getJumpShield();
        int newJumpShield = Utils.getPointWithRange(0,
                VariableConfig.HERO_MAX_JUMP_SHIELD, amount + oldJumpShield);

        if (oldJumpShield != newJumpShield){
            fightData.setJumpShield(newJumpShield);

            doSyncPosLifeAndJumpShield(newJumpShield);
            // 广播给周围的玩家, 我的跳闪值变化了
            selfThreadBroadcastAround(SceneMessages.objectJumpShieldChange(
                    getID(), newJumpShield - oldJumpShield, newJumpShield));
        }
    }

    @Override
    @MultiThread
    protected boolean tryJumpShield(){
        if (!isJumping()){
            return false;
        }

        if (VariableConfig.IS_JUMP_SHIELD_COST_JUMP_SHIELD){
            // 如果跳跃需要扣跳闪值
            int oldJumpShield = getFightData().getJumpShield();
            if (oldJumpShield > 0){
                int newJumpShield = oldJumpShield - 1;
                getFightData().setJumpShield(newJumpShield);

                // 发送消息给游戏服, 设置跳闪值, 游戏服设置游戏服上的状态, 再发送给玩家自己
                sender.sendToServer(ClusterSceneHeader.C2S.setJumpShield(
                        parent.sceneUUID, getID(), newJumpShield));

                // 广播给周围的玩家, 我的跳闪值变化了
                concurrentBroadcastAround(SceneMessages.objectJumpShieldChange(
                        getID(), -1, newJumpShield));
                return true;
            }
            return false;
        } else{
            return true;
        }
    }

    @Override
    public void onMessage(ChannelBuffer buffer, int moduleID, int sequenceID){
        switch (moduleID){
            case SceneMessages.MODULE_ID:{
                onSceneMessage(buffer, sequenceID);
                return;
            }

            default:{
                logger.error("RemoteHeroFightModule.onMessage收到未知模块的消息: {}-{}",
                        moduleID, sequenceID);
            }
        }
    }

    private void onSceneMessage(ChannelBuffer buffer, int sequenceID){
        String msgName = Modules.getC2SMsgName(SceneMessages.MODULE_ID,
                sequenceID);
        if (msgName != null){
            logger.debug("收到要处理的英雄上发的场景模块消息: {}", msgName);
        }

        switch (sequenceID){
            case SceneMessages.C2S_SCENE_HERO_MOVE:{
                onHeroMove(buffer);
                return;
            }

            case SceneMessages.C2S_SCENE_CHANGE_DIRECTION:{
                onChangeDirection(buffer);
                return;
            }

            case SceneMessages.C2S_SCENE_HERO_JUMP:{
                onHeroJump(buffer);
                return;
            }

            case SceneMessages.C2S_SCENE_STOP_MOVE:{
                onStopMove(buffer);
                return;
            }

            case SceneMessages.C2S_SCENE_RELEASE_SPELL:{
                onReleaseSpell(buffer);
                return;
            }

            case SceneMessages.C2S_SCENE_CHANGE_VIEW_RANGE:{
                onChangeViewRange(buffer);
                return;
            }

            case SceneMessages.C2S_SCENE_AUTO_COMBAT:{
                onAutoCombat(buffer);
                return;
            }

            case SceneMessages.C2S_SCENE_CANCEL_AUTO_COMBAT:{
                onCancelAutoCombat(buffer);
                return;
            }

            case SceneMessages.C2S_SCENE_SINGLE_HERO_MEDITATE:{
                onSingleMeditate();
                return;
            }

            case SceneMessages.C2S_SCENE_DOUBLE_HERO_MEDITATE:{
                onDoubleMeditate(buffer);
                return;
            }

            case SceneMessages.C2S_SCENE_HERO_CANCEL_MEDITATE:{
                onCancelMeditate();
                return;
            }

            case SceneMessages.C2S_SCENE_REQUEST_RELIVE:{
                onRequestRelive(buffer);
                return;
            }

            case SceneMessages.C2S_SCENE_PICK_UP_GOODS:{
                onPickUpGoods(buffer);
                return;
            }

            default:{
                logger.error(
                        "RemoteHeroFightModule.onMessage收到未处理的消息. bug!: {}",
                        sequenceID);
            }
        }
    }

    private SceneGoods toPickUpGoods;

    public void onPickUpGoodsSuccess(int id){
        if (toPickUpGoods == null){
            logger.error("RemoteHeroFightModule.onPickGoodsSuccess时, toPickUpGoods == null");
            return;
        }

        if (toPickUpGoods.getId() != id){
            logger.error(
                    "RemoteHeroFightModule.onPickGoodsSuccess时, toPickUpGoods的id和要删的id不同: {} -> {}",
                    toPickUpGoods.getId(), id);
            toPickUpGoods = null;
            return;
        }

        toPickUpGoods = null;
    }

    public void onPickUpGoodsFail(int id){
        if (toPickUpGoods == null){
            logger.error("RemoteHeroFightModule.onPickUpGoodsFail时, toPickUpGoods == null");
            return;
        }

        if (toPickUpGoods.getId() != id){
            logger.error(
                    "RemoteHeroFightModule.onPickUpGoodsFail时, toPickUpGoods的id和要删的id不同: {} -> {}",
                    toPickUpGoods.getId(), id);
            toPickUpGoods = null;
            return;
        }

        toPickUpGoods.clearCanSeeMeHeroes(); // 再删一次

        // 加回原场景
        parent.getSceneObjectProcessor().addGoods(toPickUpGoods);
        toPickUpGoods = null;
    }

    private void onPickUpGoods(ChannelBuffer buffer){
        if (toPickUpGoods != null){
            logger.warn("英雄要拾取物品, 但是前一个拾取的结果还没返回给他");
            sendMessage(ERR_PICK_UP_FAIL_NOT_YOURS);
            return;
        }

        if (!isAlive()){
            logger.debug("挂了，不能拾取物品");
            sendMessage(ERR_PICK_UP_FAIL_YOU_ARE_DEAD);
            return;
        }

        if (isJumping()){
            logger.debug("跳跃中不能拾取物品");
            sendMessage(ERR_PICK_UP_FAIL_JUMPING);
            return;
        }

        int id = BufferUtil.readVarInt32(buffer);
        SceneGoods goods = parent.getSceneObjectProcessor().getGoods(id);

        if (goods == null){
            logger.debug("物品不存在，可能已经被拾取");
            sendMessage(ERR_PICK_UP_FAIL_GOODS_NOT_FOUND);
            return;
        }

        if (!Utils.isInEasyRange(getX(), getY(), goods.x, goods.y, 4)){
            logger.debug("物品与英雄距离大于4格");
            sendMessage(ERR_PICK_UP_FAIL_GOODS_TOO_FAR);
            return;
        }
        long ctime = parent.getCurrentTime();

        if (!goods.canPickUp(getID(), ctime)){
            logger.debug("物品拾取时间未到");
            sendMessage(ERR_PICK_UP_FAIL_NOT_YOURS);
            return;
        }

        SceneGoods pickUpGoods = parent.getSceneObjectProcessor().removeGoods(
                id, sender);
        if (pickUpGoods == null){
            logger.debug("物品不存在，已经被别人拾取");
            sendMessage(ERR_PICK_UP_FAIL_GOODS_NOT_FOUND);
            return;
        }

        if (pickUpGoods != goods){
            logger.error("拾取物品时，get的物品与remove的物品不是同一个，怎么回事?");
        }

        pickUpGoods.clearCanSeeMeHeroes();

        if (pickUpGoods.goodsHolder instanceof SceneAmountGoodsHolder){
            // 是数值型物品, 直接通知客户端让加上
            SceneAmountGoodsHolder g = (SceneAmountGoodsHolder) pickUpGoods.goodsHolder;
            sender.sendToServer(ClusterSceneHeader.C2S.addSceneAmountGoods(
                    parent.sceneUUID, getID(), id, g.getGoodsType(),
                    g.getAmount()));
            return;
        }

        if (!(pickUpGoods.goodsHolder instanceof SceneRealGoodsHolder)){
            logger.error("RemoteHeroFightModule.onPickUpGoods时, 有新的SceneGoodsHolder类型没有处理? 新加了?");
            return;
        }

        toPickUpGoods = pickUpGoods;

        // 发消息给游戏服, 尝试加物品
        Goods g = ((SceneRealGoodsHolder) pickUpGoods.goodsHolder).getGoods();

        sender.sendToServer(ClusterSceneHeader.C2S.tryAddPickUpGoods(
                parent.sceneUUID, getID(), id, g));
    }

    private transient int lastSyncX;
    private transient int lastSyncY;
    private transient int lastLife;
    private transient int lastRage;

    private transient long nextSyncPosLifeTime;
    private static final long SYNC_INTERVAL = 3000L;

    private void trySyncPosLife(long ctime){
        if (ctime < nextSyncPosLifeTime){
            return;
        }

        nextSyncPosLifeTime = ctime + SYNC_INTERVAL;

        FightData fightData = getFightData();
        int pos = getTraceTargetPoint();

        int newX = Utils.getHighShort(pos);
        int newY = Utils.getLowShort(pos);
        int newLife = fightData.getLife();

        int newRage = spellList.getRageAmount();

        if (Utils.isInEasyRange(lastSyncX, lastSyncY, newX, newY, 3)
                && Math.abs(((float) (newLife - lastLife))
                        / fightData.getMaxLife()) < 0.1f
                && !needSyncRage(newRage, lastRage)){
            // 如果格子变化不超过3格, 且血量变化不超过10%, 怒气不超过30点, 则不同步给游戏服
            return;
        }

        lastSyncX = newX;
        lastSyncY = newY;
        lastLife = newLife;
        lastRage = newRage;
        sender.sendToServer(ClusterSceneHeader.C2S.syncPosAndLifeRage(
                parent.sceneUUID, getID(), newX, newY, newLife, newRage));
    }

    private boolean needSyncRage(int newRage, int oldRage){
        if (newRage == oldRage){
            return false;
        }

        if (newRage == spellList.rageMaxAMount){
            return true;
        }

        return newRage - oldRage > 30; // 相差30怒气, 就同步
    }

    private void doSyncPosLifeAndJumpShield(int newJumpShield){
        long ctime = parent.getCurrentTime();
        FightData fightData = getFightData();

        int pos = getTraceTargetPoint();

        lastSyncX = Utils.getHighShort(pos);
        lastSyncY = Utils.getLowShort(pos);
        lastLife = fightData.getLife();
        lastRage = spellList.getRageAmount();
        nextSyncPosLifeTime = ctime + SYNC_INTERVAL;

        sender.sendToServer(ClusterSceneHeader.C2S.syncPosLifeJumpShieldRage(
                parent.sceneUUID, getID(), lastSyncX, lastSyncY, lastLife,
                newJumpShield, lastRage));
    }
}
