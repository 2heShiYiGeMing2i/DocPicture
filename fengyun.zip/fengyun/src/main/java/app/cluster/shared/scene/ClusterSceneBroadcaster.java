package app.cluster.shared.scene;

import static com.mokylin.sink.util.BufferUtil.*;

import java.util.Collection;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.module.scene.ISceneBroadcaster;
import app.message.ISender;

import com.google.common.collect.ConcurrentHashMultiset;
import com.google.common.collect.MapMaker;

public class ClusterSceneBroadcaster implements ISceneBroadcaster{

    private static final MapMaker heroWorkerCounterMapMaker = new MapMaker()
            .concurrencyLevel(1).initialCapacity(8);

    private final ConcurrentHashMultiset<ISender> heroWorkerCounter;

    private final int uuid;

    public ClusterSceneBroadcaster(int uuid){
        this.uuid = uuid;
        heroWorkerCounter = ConcurrentHashMultiset
                .create(heroWorkerCounterMapMaker);
    }

    @Override
    public void broadcastDroppableMsg(ChannelBuffer buffer){
        broadcast(buffer);
    }

    @Override
    public void broadcastDroppableMsg(ChannelBuffer buffer, long dontSend){
        broadcast(buffer, dontSend);
    }

    @Override
    public void broadcast(ChannelBuffer buffer){
        int len = buffer.readableBytes() - 2; // 去掉头上的2字节长度

        ChannelBuffer toSend = ClusterSceneHeader.newFixedSizeMessage(
                ClusterSceneHeader.C2S_BROADCAST, uuid, len);
        toSend.writeBytes(buffer, 2, len);
        broadcastToAllLocalScene(toSend);
    }

    @Override
    public void broadcast(ChannelBuffer buffer, long dontSend){
        int len = buffer.readableBytes() - 2; // 去掉头上的2字节长度

        ChannelBuffer toSend = ClusterSceneHeader.newFixedSizeMessage(
                ClusterSceneHeader.C2S_BROADCAST_EXCEPT_ONE, uuid,
                computeVarInt64Size(dontSend) + len);
        writeVarInt64(toSend, dontSend);
        toSend.writeBytes(buffer, 2, len);
        broadcastToAllLocalScene(toSend);
    }

    Collection<ISender> getCombatMasterWorkers(){
        return heroWorkerCounter.elementSet();
    }

    /**
     * 发送消息给每个Combat场景, 不是把消息发给每个英雄. 这边直接发, 不会再转化buffer
     * @param buffer
     */
    public void broadcastToAllLocalScene(ChannelBuffer buffer){
        for (ISender worker : heroWorkerCounter.elementSet()){
            worker.sendMessage(buffer);
        }
    }

    public void add(ISender worker){
        heroWorkerCounter.add(worker, 1);
    }

    public void remove(ISender worker){
        heroWorkerCounter.remove(worker, 1);
    }
}
