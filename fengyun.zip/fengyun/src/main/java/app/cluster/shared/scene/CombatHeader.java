package app.cluster.shared.scene;

import static com.mokylin.sink.util.BufferUtil.*;

import java.io.IOException;

import org.jboss.netty.buffer.BigEndianHeapChannelBuffer;
import org.jboss.netty.buffer.ChannelBuffer;
import org.jboss.netty.buffer.ChannelBuffers;

import app.cluster.protobuf.CombatContent.EnteringHeroProto;

import com.google.protobuf.CodedOutputStream;
import com.google.protobuf.MessageLite;
import com.mokylin.sink.util.BufferUtil;

public enum CombatHeader{

    /**
     * 游戏服刚连上combat时发送, 登录
     * 
     * 附带
     * 
     * 
     */
    S2C_HELLO_COMBAT,

    /**
     * 英雄释放了技能
     * 
     * 游戏服
     * 
     *  发送给玩家
     *  并增加技能熟练度
     *  如果消耗怒气, 则把怒气清掉
     *  
     * 附带
     * 
     * varint64 英雄id
     * varint32 技能spellType
     */
    C2S_HERO_RELEASED_SPELL,

    /**
     * 直接交给场景处理的消息
     * 可以C2S, 也可以S2C
     * 
     * 附带
     * 
     * CombatSceneHeader.ordinal
     * varint32 场景id (uuid)
     * 后面是每个消息所独特的附带方式
     */
    SCENE_MESSAGE,

    /**
     * 英雄新进入场景. 如果场景不存在, 则新建个
     * 
     * 附带
     * 
     * varint64 英雄id
     * varint32 副本uuid
     * varint32 副本id
     * 
     * UTF 英雄名字
     * varint32 视野x
     * varint32 视野y
     * 
     * EnteringHeroProto proto
     */
    S2C_HERO_NEW_ENTER,

    /**
     * 英雄断线重连, 重新进入场景. 如果场景不存在, 则发送英雄离开消息
     * 
     * 附带
     * 
     * 与S2C_HERO_NEW_ENTER相同
     */
    S2C_HERO_OFFLINE_REENTER,

    // --- 观察 ---
    /**
     * 观察个不在我服务器上的人
     * 
     * 如果场景存在, 且找到了这个人, 则直接proxy相应的消息给双方. 被观察者发送附近有人查看你
     * 
     * 如果没找到, 则找到对方的区服, 如果不存在, proxy对方服务器没找到. 如果存在, 转发给对应的服务器
     * 
     * 附带
     * 
     * varint32 请求者所在场景的uuid, 未必是有的
     * varint64 请求者id
     * varint64 要看的人id
     */
    S2C_VIEW_HERO,

    /**
     * 别的服务器有人要观察你这个服务器上的人
     * 
     * 附带
     * 
     * varint64 请求者id
     * varint64 要看的人id
     */
    C2S_OTHER_SERVER_VIEW_YOUR_HERO,

    // --- 通用转发 ---
    /**
     * 游戏服 转发条消息给别的游戏服的玩家
     * combat通过目标玩家的id, 找到他应该所在的服务器
     * 如果目标服务器不存在, 或者玩家不在线, 则收不到
     * 
     * 附带
     * 
     * varint64 接收者id
     * 后面是附带的内容. 没有消息长度
     */
    S2C_PROXY_MSG_TO_HERO_ON_ANOTHER_SERVER,

    /**
     * 转发消息给你这里的玩家
     * 
     * 如果在线就发, 不在线就算
     * 
     * 附带
     * 
     * varint64 接收者的id
     * 后面是附带的内容. 没有消息长度
     */
    C2S_PROXY_MSG

    ;

    // --- 消息构建 ---

    public static ChannelBuffer proxyMsgToHeroOnAnotherServer(long heroID,
            int extraSize){
        ChannelBuffer buffer = newFixedSizeMessage(
                CombatHeader.S2C_PROXY_MSG_TO_HERO_ON_ANOTHER_SERVER,
                computeVarInt64Size(heroID) + extraSize);
        writeVarInt64(buffer, heroID);
        return buffer;
    }

    public static ChannelBuffer proxyMsgFixSize(long heroID, int extraSize){
        ChannelBuffer buffer = newFixedSizeMessage(CombatHeader.C2S_PROXY_MSG,
                computeVarInt64Size(heroID) + extraSize);
        writeVarInt64(buffer, heroID);
        return buffer;
    }

    public static ChannelBuffer otherServerViewYourHero(long askerID,
            long targetID){
        return onlySendHeadAnd2VarInt64Message(C2S_OTHER_SERVER_VIEW_YOUR_HERO,
                askerID, targetID);
    }

    public static ChannelBuffer viewHero(int sceneUUID, long askerID,
            long targetID){
        ChannelBuffer buffer = newFixedSizeMessage(CombatHeader.S2C_VIEW_HERO,
                computeVarInt32Size(sceneUUID) + computeVarInt64Size(askerID)
                        + computeVarInt64Size(targetID));
        writeVarInt32(buffer, sceneUUID);
        writeVarInt64(buffer, askerID);
        writeVarInt64(buffer, targetID);
        return buffer;
    }

    public static ChannelBuffer heroReleasedSpell(long heroID, int spellType){
        ChannelBuffer buffer = newFixedSizeMessage(
                CombatHeader.C2S_HERO_RELEASED_SPELL,
                computeVarInt64Size(heroID) + computeVarInt32Size(spellType));
        writeVarInt64(buffer, heroID);
        writeVarInt32(buffer, spellType);
        return buffer;
    }

    public static ChannelBuffer heroEnter(boolean isEnteringFirstScene,
            int sceneConfigID, int uuid, long heroID, byte[] heroNameBytes,
            int viewRangeX, int viewRangeY, EnteringHeroProto proto){
        int protoSize = proto.getSerializedSize();
        ChannelBuffer buffer = newFixedSizeMessage(
                isEnteringFirstScene ? S2C_HERO_OFFLINE_REENTER
                        : S2C_HERO_NEW_ENTER,
                computeVarInt32Size(sceneConfigID) + computeVarInt32Size(uuid)
                        + computeVarInt64Size(heroID) + 2
                        + heroNameBytes.length
                        + computeVarInt32Size(viewRangeX)
                        + computeVarInt32Size(viewRangeY) + protoSize);
        writeVarInt64(buffer, heroID);
        writeVarInt32(buffer, uuid);
        writeVarInt32(buffer, sceneConfigID);

        writeUTF(buffer, heroNameBytes);

        writeVarInt32(buffer, viewRangeX);
        writeVarInt32(buffer, viewRangeY);

        BufferUtil.writeProto(buffer, proto);
        return buffer;
    }

    // --- 消息构建helper方法 ---
    private static final int HEADER_COUNT = CombatHeader.values().length;

    private static final CombatHeader[] HEADERS = CombatHeader.values();

    public static CombatHeader getHeaderByID(int id){
        if (id >= 0 && id < HEADER_COUNT){
            return HEADERS[id];
        }
        return null;
    }

    public static ChannelBuffer newFixedSizeMessage(CombatHeader msg,
            int sureSizeExcludingSizeAndID){
        ChannelBuffer buffer = new BigEndianHeapChannelBuffer(2
                + sureSizeExcludingSizeAndID
                + computeVarInt32Size(msg.ordinal()));
        buffer.writeShort(0);
        writeVarInt32(buffer, msg.ordinal());

        return buffer;
    }

    public static ChannelBuffer newDynamicMessage(CombatHeader msg){
        return newDynamicMessage(msg, 64);
    }

    /**
     * 返回的ChannelBuffer会按需加大
     * 
     * @param msgId
     * @param approxSize
     * @return
     */
    public static ChannelBuffer newDynamicMessage(CombatHeader msg,
            int approxSizeExcludingSizeAndID){
        ChannelBuffer buffer = ChannelBuffers
                .dynamicBuffer(12 + approxSizeExcludingSizeAndID);
        buffer.writeShort(0);// place holder for buffer size
        writeVarInt32(buffer, msg.ordinal());
        return buffer;
    }

    public static ChannelBuffer onlySendHeaderMessage(CombatHeader msg){
        return newFixedSizeMessage(msg, 0);
    }

    public static ChannelBuffer onlySendHeadAndABoolBytes(CombatHeader msg,
            boolean b){
        ChannelBuffer buffer = newFixedSizeMessage(msg, 1);
        writeBoolean(buffer, b);
        return buffer;
    }

    public static ChannelBuffer onlySendHeadAndAUTFBytes(CombatHeader msg,
            byte[] utf){
        ChannelBuffer buffer = newFixedSizeMessage(msg, utf.length);
        buffer.writeBytes(utf);
        return buffer;
    }

    public static ChannelBuffer onlySendHeadAndAByteMessage(CombatHeader msg,
            int b){
        ChannelBuffer buffer = newFixedSizeMessage(msg, 1);
        buffer.writeByte(b);
        return buffer;
    }

    public static ChannelBuffer onlySendHeadAndAVarInt32Message(
            CombatHeader msg, int b){
        ChannelBuffer buffer = newFixedSizeMessage(msg, computeVarInt32Size(b));
        writeVarInt32(buffer, b);
        return buffer;
    }

    public static ChannelBuffer onlySendHeadAnd2VarInt32Message(
            CombatHeader msg, int b, int c){
        ChannelBuffer buffer = newFixedSizeMessage(msg, computeVarInt32Size(b)
                + computeVarInt32Size(c));
        writeVarInt32(buffer, b);
        writeVarInt32(buffer, c);
        return buffer;
    }

    public static ChannelBuffer onlySendHeadAnd3VarInt32Message(
            CombatHeader msg, int b, int c, int d){
        ChannelBuffer buffer = newFixedSizeMessage(msg, computeVarInt32Size(b)
                + computeVarInt32Size(c) + computeVarInt32Size(d));
        writeVarInt32(buffer, b);
        writeVarInt32(buffer, c);
        writeVarInt32(buffer, d);
        return buffer;
    }

    public static ChannelBuffer onlySendHeadAnd4VarInt32Message(
            CombatHeader msg, int b, int c, int d, int e){
        ChannelBuffer buffer = newFixedSizeMessage(msg, computeVarInt32Size(b)
                + computeVarInt32Size(c) + computeVarInt32Size(d)
                + computeVarInt32Size(e));
        writeVarInt32(buffer, b);
        writeVarInt32(buffer, c);
        writeVarInt32(buffer, d);
        writeVarInt32(buffer, e);
        return buffer;
    }

    public static ChannelBuffer onlySendHeadAndAVarInt64Message(
            CombatHeader msg, long b){
        ChannelBuffer buffer = newFixedSizeMessage(msg, computeVarInt64Size(b));
        writeVarInt64(buffer, b);
        return buffer;
    }

    public static ChannelBuffer onlySendHeadAnd2VarInt64Message(
            CombatHeader msg, long b, long c){
        ChannelBuffer buffer = newFixedSizeMessage(msg, computeVarInt64Size(b)
                + computeVarInt64Size(c));
        writeVarInt64(buffer, b);
        writeVarInt64(buffer, c);
        return buffer;
    }

    public static ChannelBuffer onlySendHeaderAndVarIntsMessage(
            CombatHeader msg, int... value){
        int size = 0;
        for (int i : value){
            size += computeVarInt32Size(i);
        }
        ChannelBuffer result = newFixedSizeMessage(msg, size);
        for (int i : value){
            writeVarInt32(result, i);
        }
        return result;
    }

    public static ChannelBuffer onlySendHeadAndBytesMessage(CombatHeader msg,
            byte[] data){
        ChannelBuffer buffer = newFixedSizeMessage(msg, data.length);
        buffer.writeBytes(data);
        return buffer;
    }

    public static ChannelBuffer newProtobufMessage(CombatHeader header,
            MessageLite msg){
        int size = msg.getSerializedSize();
        byte[] buf = new byte[2 + size + computeVarInt32Size(header.ordinal())];

        int index = writeVarInt32(buf, 2, header.ordinal());

        CodedOutputStream out = CodedOutputStream.newInstance(buf, index, size);
        try{
            msg.writeTo(out);
        } catch (IOException e){
            throw new RuntimeException(
                    "Serializing to a byte array threw an IOException "
                            + "(should never happen).", e);
        }
        return new BigEndianHeapChannelBuffer(buf);
    }

    public static ChannelBuffer getCompressedMessage(CombatHeader msg,
            ChannelBuffer buffer){
        ChannelBuffer result = newFixedSizeMessage(msg,
                getMaxCompressedSize(buffer.writerIndex()));
        compressBuffer(buffer, result);
        return result;
    }

    public static ChannelBuffer getCompressedMessage(CombatHeader msg,
            byte[] data, boolean bestCompression){
        ChannelBuffer result = newFixedSizeMessage(msg,
                getMaxCompressedSize(data.length));
        compressBuffer(data, result, bestCompression);
        return result;
    }

}
