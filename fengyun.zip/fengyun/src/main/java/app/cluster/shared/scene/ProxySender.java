package app.cluster.shared.scene;

import org.jboss.netty.buffer.ChannelBuffer;

import app.message.ISender;

import com.mokylin.sink.util.BufferUtil;

/**
 * 可以当做玩家会收到sendMessage中附带的消息
 * 实际上会创建个新的proxy消息, 发送给游戏服, 让游戏服转发给玩家
 * @author Timmy
 *
 */
public class ProxySender implements ISender{

    private final ISender sender;

    private final long heroID;

    private final int uuid;

    public ProxySender(ISender sender, long heroID, int uuid){
        this.sender = sender;
        this.heroID = heroID;
        this.uuid = uuid;
    }

    /**
     * 这条消息将会被转化成proxy消息, 发送给游戏服, 并由游戏服proxy给英雄
     * 
     * 不会改变buffer的readerIndex和writerIndex
     */
    @Override
    public boolean sendMessage(ChannelBuffer buffer){
        int len = buffer.writerIndex() - 2;
        ChannelBuffer toSend = ClusterSceneHeader.newFixedSizeMessage(
                ClusterSceneHeader.C2S_PROXY_MSG, uuid,
                BufferUtil.computeVarInt64Size(heroID) + len); // 加上英雄id, 去掉buffer头2位的消息长度short

        BufferUtil.writeVarInt64(toSend, heroID);
        toSend.writeBytes(buffer, 2, len);
        return sender.sendMessage(toSend);
    }

    /**
     * 直接发送这条消息给游戏服
     * @param buffer
     * @return
     */
    public boolean sendToServer(ChannelBuffer buffer){
        return sender.sendMessage(buffer);
    }
}
