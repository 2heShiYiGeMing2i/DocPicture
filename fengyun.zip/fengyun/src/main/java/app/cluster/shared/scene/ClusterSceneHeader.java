package app.cluster.shared.scene;

import static com.mokylin.sink.util.BufferUtil.*;

import java.io.IOException;

import org.jboss.netty.buffer.BigEndianHeapChannelBuffer;
import org.jboss.netty.buffer.ChannelBuffer;
import org.jboss.netty.buffer.ChannelBuffers;

import app.game.data.SpriteStat;
import app.game.data.goods.Goods;
import app.protobuf.GoodsServerContent.GoodsServerProto;
import app.protobuf.GoodsServerContent.GoodsType;
import app.protobuf.LogContent.LogEnum.TransportType;
import app.protobuf.SpriteStatContent.SpriteStatProto;

import com.google.protobuf.CodedOutputStream;
import com.google.protobuf.MessageLite;

public enum ClusterSceneHeader{

    /**
     * 英雄正在加载, 准备进入你的场景. 如果场景存在, markAboutEnter. 不要让场景过期
     * 
     * 附带
     * 
     * varint64 英雄id
     */
    S2C_HERO_ABOUT_TO_COME,

    /**
     * 英雄离开, 不会再回来了
     * 
     * 附带
     * 
     * varint64 英雄id
     */
    S2C_HERO_LEAVE,

    /**
     * 英雄断线, 可能还会回来
     * 
     * 附带
     * 
     * varint64 英雄id
     */
    S2C_HERO_OFFLINE,

    /**
     * 英雄还在加载时, 下线了
     * 
     * 附带
     * 
     * varint64 英雄id
     */
    S2C_HERO_OFFLINE_WHEN_LOADING,

    /**
     * 把英雄发送的场景消息转发给Combat服处理. 
     * 移动/转向/跳跃/停止移动/技能/改变视野范围/拾取物品/自动战斗/取消自动战斗/打坐/双修/取消双修
     * 
     * 附带
     * 
     * varint64 英雄id
     * varint32 消息号
     * 后面全是英雄发送的数据
     */
    S2C_PROXY_SCENE_MODULE_MSG,

    /**
     * 广播消息给来自别的服的英雄, 不需要广播给这个服了
     * 
     * 后面全是附带的消息
     */
    S2C_BROADCAST,

    /**
     * 广播消息给来自别的服的英雄, 不需要广播这个服了
     * 
     * 附带
     * 
     * varint64 不要发送的英雄id
     * 后面全是附带的消息
     */
    S2C_BROADCAST_DONT_SEND,

    /**
     * 英雄被击下马
     * 
     * 附带
     * 
     * varint64 英雄id
     */
    C2S_SHOOT_MOUNT,

    /**
     * Combat服告诉Server英雄离开了场景了, 在Combat服这里已经让英雄离开了, 游戏服remove英雄时不要再通知Combat服了
     * 
     * 附带
     * 
     * varint64 英雄id
     */
    C2S_HERO_LEAVE,

    /**
     * 场景在Combat服过期, 如果此场景在本地服里面没人了, 则删除
     * 
     * 没有附带信息
     */
    C2S_SCENE_EXPIRED,

    /**
     * 广播消息给所有已经进入场景的英雄
     * 
     * 附带
     * 
     * 后面就是需要发送给玩家的消息. 游戏服只需要在最前面加上个short的长度就可以广播
     */
    C2S_BROADCAST,

    /**
     * 同上, 但消息不要发送给id为xx的玩家
     * 
     * 附带
     * 
     * varint64 不要发的玩家id
     * 后面是需要发送的消息
     */
    C2S_BROADCAST_EXCEPT_ONE,

    /**
     * 副本全部通关了, 本地场景负责给每个在场景中的英雄发副本完成奖励和消息之类的
     * 
     * 附带
     * 
     * varint32 总死亡次数
     * varint32 总消耗时间 (秒)
     */
    C2S_DUNGEON_FINISHED,

    /**
     * 英雄把怪杀了. 本地游戏服负责加经验以及处理任务进度等
     * 
     * varint64 英雄id
     * varint32 monsterData id
     */
    C2S_HERO_KILLED_MONSTER,

    /**
     * 游戏服通知Combat服英雄的等级更新
     * 
     * Combat服自己计算属性变化, 和自动学会的技能, 并广播给周围的英雄
     * 
     * varint64 英雄id
     * varint32 之前的等级
     * varint32 最新的等级
     * 
     */
    S2C_HERO_CHANGE_LEVEL,

    /**
     * 英雄获得打坐经验
     * 
     * 附带
     * 
     * varint64 英雄id
     * bool 是否是双修
     */
    C2S_HERO_MEDIATE,

    /**
     * 设置英雄的最新跳闪值
     * 
     * 附带
     * 
     * varint64 英雄id
     * varint32 最新的跳闪值
     */
    C2S_HERO_SET_JUMP_SHIELD,

    /**
     * 让英雄去个普通场景. Combat服上已经把英雄从场景中移除了
     * 
     * 附带
     * 
     * varint64 英雄id
     * varint32 要去的普通场景id
     * varint32 线数 从1开始. 0表示随机
     * varint32 在新场景中的x坐标
     * varint32 在新场景中的y坐标
     */
    C2S_HERO_TRANSPORT_TO_NORMAL_SCENE,

    /**
     * Combat服给游戏服同步血量和位置
     * 
     * 附带
     * 
     * varint64 英雄id
     * varint32 x
     * varint32 y
     * varint32 life
     */
    C2S_HERO_SYNC_POS_AND_LIFE_RAGE,

    /**
     * Combat服给游戏服同步血量和位置
     * 
     * 附带
     * 
     * varint64 英雄id
     * varint32 x
     * varint32 y
     * varint32 life
     * varint32 最新的跳闪值
     */
    C2S_HERO_SYNC_POS_LIFE_AND_JUMP_SHIELD_RAGE,

    /**
     * 要求Combat服添加个单次生效的状态
     * 
     * 附带
     * 
     * varint64 英雄id
     * varint32 状态id
     * varint32 状态multiple
     */
    S2C_HERO_ADD_SINGLE_EFFECT_FIGHT_STATE,

    /**
     * 要求Combat服添加个状态, 状态的层数和过期时间已经是决定了的
     * 
     * 附带
     * 
     * varint64 英雄id
     * varint32 状态id
     * varint32 状态层数
     * varint64 状态消失时间 
     */
    S2C_HERO_ADD_FIGHT_STATE,

    /**
     * 转发消息给英雄
     *  
     * varint64 英雄id
     * 之后就是附带的信息
     */
    C2S_PROXY_MSG,

    // --- 拾取物品 ---

    /**
     * 拾取了个数值型物品, 直接让游戏服添加. 就算英雄不在也不管, 不用返回
     * 
     * 发送拾取成功消息给英雄
     * 
     * 附带
     * 
     * varint64 英雄id
     * varint32 场景的物品id, 发送拾取成功消息给客户端
     * varint32 GoodsType.number
     * varint32 amount
     */
    C2S_ADD_SCENE_AMOUNT_GOODS,

    /**
     * 尝试添加个物品. 成功失败都发送消息给玩家
     * 
     * 附带
     * 
     * varint64 英雄id
     * varint32 物品在场景中的id (到时候发回来, 检查错误) (发送拾取成功消息)
     * GoodsServerProto 具体的物品
     */
    C2S_TRY_ADD_PICK_UP_GOODS,

    /**
     * 添加成功, Combat服去掉这个物品
     * 
     * 附带
     * 
     * varint64 英雄id
     * varint32 物品在场景中的id
     */
    S2C_ADD_PICK_UP_GOODS_SUCCESS,

    /**
     * 添加失败, 背包已满, Combat服把物品加回场景中
     * 
     * 附带
     * 
     * varint64 英雄id
     * varint32 物品在场景中的id
     */
    S2C_ADD_PICK_UP_GOODS_FAIL,

    // --- 完美复活 ---

    /**
     * 英雄尝试完美复活. 游戏服删除掉个完美复活道具, 再发结果返回给Combat服
     * 
     * 附带
     * 
     * varint64 英雄id
     * varint32 建议扣物品的位置
     */
    C2S_TRY_REDUCE_TOOL_AND_PERFECT_RELIVE,

    /**
     * 删除道具失败. 游戏服会直接发送扣道具失败消息给玩家
     * 
     * 附带
     * 
     * varint64 英雄id
     * 
     */
    S2C_PERFECT_RELIVE_FAIL,

    /**
     * 删除道具成功, combat服让玩家复活, 游戏服不会发送任何消息给玩家
     * 
     * 附带
     * 
     * varint64 英雄id
     */
    S2C_PERFECT_RELIVE_SUCCESS,

    // --- 搜神宫 ---

    /**
     * 某个搜神宫boss挂了, 本地场景负责给每个在场景中的英雄发奖励和消息之类的
     * 
     * 附带
     * 
     * varint64 死掉的boss在场景中的id
     */
    C2S_SOU_SHEN_BOSS_DEAD,

    // --- PORTAL ---

    /**
     * 英雄尝试踩传送门, Combat服直接把结果proxy给玩家
     * 
     * 附带
     * 
     * varint64 英雄id
     * varint32 要踩的门id
     */
    S2C_PORTAL_TRY_PORTAL,

    /**
     * 英雄完成了副本. 本地场景负责给奖励和发消息
     * 
     * 附带
     * 
     * varint64 英雄id
     * varint32 总死亡次数
     * varint32 总消耗时间 (秒)
     */
    C2S_PORTAL_HERO_FINISHED,

    // --- 火麟洞 ---

    /**
     * 每隔几秒会广播一次, 让local场景给所有在场景中的英雄加经验和真气
     * 
     * 没有附带信息
     */
    C2S_HUO_LIN_ADD_EXP_AND_REAL_AIR,

    // --- 改基础属性 ---

    /**
     * 改变基础属性
     * 
     * 附带
     * 
     * SpriteStatProto
     */
    S2C_CHANGE_BASE_STAT,

    /**
     * 换装
     * 
     * 附带
     * 
     * varint32 新的换装
     */
    S2C_CHANGE_EQUIPMENT_RESOURCE,

    /**
     * Vip变化
     * 
     * 附带
     * 
     * varint32 新的Vip等级
     */
    S2C_CHANGE_VIP,

    // --- 改变技能 ---

    /**
     * 切换神兵
     * 
     * varint32 神兵ID，0表示卸载神兵
     */
    S2C_CHANGE_SUPER_WEAPON,

//    神兵心法升级，影响神兵技能抵抗
//    S2C_CHANGE_SUPER_WEAPON_XINFA, 

    /**
     * 弓箭进阶，影响弓箭技能触发
     * 
     * varint32 新的弓箭阶数
     */
    S2C_BOW_UPGRADE,

//    英雄技能升级
//    S2C_HERO_SPELL_UPGRADE,

    /**
     * 替换英雄被动触发技能
     * 
     * varint32 removeSpellID
     * varint32 addSpellID
     */
    S2C_REPLACE_HERO_SPELL,

    /**
     * 添加英雄被动触发技能
     * 
     * while(buffer.readable())
     *     varint32 spellID
     */
    S2C_ADD_HERO_SPELL,

    /**
     * 添加英雄被动触发技能
     * 
     * while(buffer.readable())
     *     varint32 spellID
     */
    S2C_REMOVE_HERO_SPELL,

    // 宠物

    /**
     * 宠物变化
     * 
     * varint64 宠物过期时间
     * varint32 天劫ID
     * varint32 天罪ID
     * 
     */
    S2C_CHANGE_PET,

    /**
     * 宠物技能变化
     * 
     * varint32 技能位置
     * varint32 技能ID
     * 
     */
    S2C_CHANGE_PET_SPELL,

    /**
     * 更新pk模式，远程服只改pk模式即可
     * 
     * varint32 pkMode
     */
    S2C_CHANGE_PK_MODE,

    ;

    // --- 消息构建 ---

    public static class S2C{

        public static ChannelBuffer changePetMsg(int sceneID, long heroID,
                int pkMode){
            ChannelBuffer buffer = newFixedSizeMessage(
                    ClusterSceneHeader.S2C_CHANGE_PK_MODE, sceneID,
                    computeVarInt64Size(heroID) + computeVarInt32Size(pkMode));
            writeVarInt64(buffer, heroID);
            writeVarInt32(buffer, pkMode);
            return buffer;
        }

        public static ChannelBuffer changePetMsg(int sceneID, long heroID,
                long expireTime, int tianjieID, int tianzuiID){
            ChannelBuffer buffer = newFixedSizeMessage(
                    ClusterSceneHeader.S2C_CHANGE_PET, sceneID,
                    computeVarInt64Size(heroID)
                            + computeVarInt64Size(expireTime)
                            + computeVarInt32Size(tianjieID)
                            + computeVarInt32Size(tianzuiID));
            writeVarInt64(buffer, heroID);
            writeVarInt64(buffer, expireTime);
            writeVarInt32(buffer, tianjieID);
            writeVarInt32(buffer, tianzuiID);
            return buffer;
        }

        public static ChannelBuffer changePetSpellMsg(int sceneID, long heroID,
                int pos, int spellID){
            ChannelBuffer buffer = newFixedSizeMessage(
                    ClusterSceneHeader.S2C_CHANGE_PET_SPELL, sceneID,
                    computeVarInt64Size(heroID) + computeVarInt32Size(pos)
                            + computeVarInt32Size(spellID));
            writeVarInt64(buffer, heroID);
            writeVarInt32(buffer, pos);
            writeVarInt32(buffer, spellID);
            return buffer;
        }

        public static ChannelBuffer getAddPassiveSpellBuffer(int sceneID,
                long heroID, int spellCount){
            ChannelBuffer buffer = newDynamicMessage(
                    ClusterSceneHeader.S2C_ADD_HERO_SPELL, sceneID,
                    computeVarInt64Size(heroID) + 2 * spellCount);
            writeVarInt64(buffer, heroID);
            return buffer;
        }

        public static ChannelBuffer addPassiveSpellMsg(int sceneID,
                long heroID, int addSpellID){
            ChannelBuffer buffer = newFixedSizeMessage(
                    ClusterSceneHeader.S2C_ADD_HERO_SPELL, sceneID,
                    computeVarInt64Size(heroID)
                            + computeVarInt32Size(addSpellID));
            writeVarInt64(buffer, heroID);
            writeVarInt32(buffer, addSpellID);
            return buffer;
        }

        public static ChannelBuffer getRemovePassiveSpellBuffer(int sceneID,
                long heroID, int spellCount){
            ChannelBuffer buffer = newDynamicMessage(
                    ClusterSceneHeader.S2C_REMOVE_HERO_SPELL, sceneID,
                    computeVarInt64Size(heroID) + 2 * spellCount);
            writeVarInt64(buffer, heroID);
            return buffer;
        }

        public static ChannelBuffer replacePassiveSpell(int sceneID,
                long heroID, int removeSpellID, int addSpellID){
            ChannelBuffer buffer = newFixedSizeMessage(
                    ClusterSceneHeader.S2C_REPLACE_HERO_SPELL, sceneID,
                    computeVarInt64Size(heroID)
                            + computeVarInt32Size(removeSpellID)
                            + computeVarInt32Size(addSpellID));
            writeVarInt64(buffer, heroID);
            writeVarInt32(buffer, removeSpellID);
            writeVarInt32(buffer, addSpellID);
            return buffer;
        }

        public static ChannelBuffer bowUpgrade(int sceneID, long heroID,
                int newBow){
            ChannelBuffer buffer = newFixedSizeMessage(
                    ClusterSceneHeader.S2C_BOW_UPGRADE, sceneID,
                    computeVarInt64Size(heroID) + computeVarInt32Size(newBow));
            writeVarInt64(buffer, heroID);
            writeVarInt32(buffer, newBow);
            return buffer;
        }

        public static ChannelBuffer changeSuperWeapon(int sceneID, long heroID,
                int newWeapon){
            ChannelBuffer buffer = newFixedSizeMessage(
                    ClusterSceneHeader.S2C_CHANGE_SUPER_WEAPON, sceneID,
                    computeVarInt64Size(heroID)
                            + computeVarInt32Size(newWeapon));
            writeVarInt64(buffer, heroID);
            writeVarInt32(buffer, newWeapon);
            return buffer;
        }

        public static ChannelBuffer changeVip(int sceneID, long heroID,
                int newVip){
            ChannelBuffer buffer = newFixedSizeMessage(
                    ClusterSceneHeader.S2C_CHANGE_VIP, sceneID,
                    computeVarInt64Size(heroID) + computeVarInt32Size(newVip));
            writeVarInt64(buffer, heroID);
            writeVarInt32(buffer, newVip);
            return buffer;
        }

        public static ChannelBuffer changeEquipmentResource(int sceneID,
                long heroID, int newEquipmentResource){
            ChannelBuffer buffer = newFixedSizeMessage(
                    ClusterSceneHeader.S2C_CHANGE_EQUIPMENT_RESOURCE, sceneID,
                    computeVarInt64Size(heroID)
                            + computeVarInt32Size(newEquipmentResource));
            writeVarInt64(buffer, heroID);
            writeVarInt32(buffer, newEquipmentResource);
            return buffer;
        }

        public static ChannelBuffer changeBaseStat(int sceneID, long heroID,
                SpriteStat newBaseStat){
            SpriteStatProto proto = newBaseStat.encode();
            ChannelBuffer buffer = newFixedSizeMessage(
                    ClusterSceneHeader.S2C_CHANGE_BASE_STAT, sceneID,
                    computeVarInt64Size(heroID) + proto.getSerializedSize());
            writeVarInt64(buffer, heroID);
            writeProto(buffer, proto);
            return buffer;
        }

        public static ChannelBuffer addFightState(int sceneID, long heroID,
                int stateID, int stackCount, long disappearTime){
            ChannelBuffer buffer = newFixedSizeMessage(
                    ClusterSceneHeader.S2C_HERO_ADD_FIGHT_STATE, sceneID,
                    computeVarInt64Size(heroID) + computeVarInt32Size(stateID)
                            + computeVarInt32Size(stackCount)
                            + computeVarInt64Size(disappearTime));
            writeVarInt64(buffer, heroID);
            writeVarInt32(buffer, stateID);
            writeVarInt32(buffer, stackCount);
            writeVarInt64(buffer, disappearTime);
            return buffer;
        }

        public static ChannelBuffer addSingleEffectFightState(int sceneID,
                long heroID, int stateID, int multiple){
            ChannelBuffer buffer = newFixedSizeMessage(
                    ClusterSceneHeader.S2C_HERO_ADD_SINGLE_EFFECT_FIGHT_STATE,
                    sceneID, computeVarInt64Size(heroID)
                            + computeVarInt32Size(stateID)
                            + computeVarInt32Size(multiple));
            writeVarInt64(buffer, heroID);
            writeVarInt32(buffer, stateID);
            writeVarInt32(buffer, multiple);
            return buffer;
        }

        public static ChannelBuffer addPickUpGoodsFail(int sceneID,
                long heroID, int sceneGoodsID){
            ChannelBuffer buffer = newFixedSizeMessage(
                    ClusterSceneHeader.S2C_ADD_PICK_UP_GOODS_FAIL, sceneID,
                    computeVarInt64Size(heroID)
                            + computeVarInt32Size(sceneGoodsID));
            writeVarInt64(buffer, heroID);
            writeVarInt32(buffer, sceneGoodsID);
            return buffer;
        }

        public static ChannelBuffer addPickUpGoodsSuccess(int sceneID,
                long heroID, int sceneGoodsID){
            ChannelBuffer buffer = newFixedSizeMessage(
                    ClusterSceneHeader.S2C_ADD_PICK_UP_GOODS_SUCCESS, sceneID,
                    computeVarInt64Size(heroID)
                            + computeVarInt32Size(sceneGoodsID));
            writeVarInt64(buffer, heroID);
            writeVarInt32(buffer, sceneGoodsID);
            return buffer;
        }

        public static ChannelBuffer perfectReliveSuccess(int sceneID,
                long heroID){
            return onlySendHeadAndAVarInt64Message(
                    ClusterSceneHeader.S2C_PERFECT_RELIVE_SUCCESS, sceneID,
                    heroID);
        }

        public static ChannelBuffer perfectReliveFail(int sceneID, long heroID){
            return onlySendHeadAndAVarInt64Message(
                    ClusterSceneHeader.S2C_PERFECT_RELIVE_FAIL, sceneID, heroID);
        }

        public static ChannelBuffer changeLevel(int sceneID, long heroID,
                int oldLevel, int newLevel){
            ChannelBuffer buffer = ClusterSceneHeader.newFixedSizeMessage(
                    ClusterSceneHeader.S2C_HERO_CHANGE_LEVEL, sceneID,
                    computeVarInt64Size(heroID) + computeVarInt32Size(oldLevel)
                            + computeVarInt32Size(newLevel));
            writeVarInt64(buffer, heroID);
            writeVarInt32(buffer, oldLevel);
            writeVarInt32(buffer, newLevel);
            return buffer;
        }

        public static ChannelBuffer portalTryPortal(int sceneID, long heroID,
                int portalIndex){
            ChannelBuffer buffer = ClusterSceneHeader.newFixedSizeMessage(
                    ClusterSceneHeader.S2C_PORTAL_TRY_PORTAL, sceneID,
                    computeVarInt64Size(heroID)
                            + computeVarInt32Size(portalIndex));
            writeVarInt64(buffer, heroID);
            writeVarInt32(buffer, portalIndex);
            return buffer;
        }

        public static ChannelBuffer proxySceneModuleMsg(int sceneID,
                long heroID, int sequenceID, ChannelBuffer msg){
            ChannelBuffer buffer = ClusterSceneHeader.newFixedSizeMessage(
                    ClusterSceneHeader.S2C_PROXY_SCENE_MODULE_MSG,
                    sceneID,
                    computeVarInt64Size(heroID)
                            + computeVarInt32Size(sequenceID)
                            + msg.readableBytes());

            writeVarInt64(buffer, heroID);
            writeVarInt32(buffer, sequenceID);
            buffer.writeBytes(msg);
            return buffer;
        }

    }

    // -------------

    public static class C2S{

        public static ChannelBuffer proxyMsgDynamic(int sceneID, long heroID,
                int moduleID, int sequenceID, int appSize){
            ChannelBuffer buffer = newDynamicMessage(
                    ClusterSceneHeader.C2S_PROXY_MSG, sceneID, 12 + appSize);
            writeVarInt64(buffer, heroID);
            writeVarInt32(buffer, moduleID);
            writeVarInt32(buffer, sequenceID);
            return buffer;
        }

        public static ChannelBuffer proxyMsg(int sceneID, long heroID,
                int moduleID, int sequenceID, int sureSizeExcludingHeader){
            ChannelBuffer buffer = newFixedSizeMessage(
                    ClusterSceneHeader.C2S_PROXY_MSG, sceneID,
                    computeVarInt32Size(moduleID)
                            + computeVarInt32Size(sequenceID)
                            + computeVarInt64Size(heroID)
                            + sureSizeExcludingHeader);
            writeVarInt64(buffer, heroID);
            writeVarInt32(buffer, moduleID);
            writeVarInt32(buffer, sequenceID);
            return buffer;
        }

        public static ChannelBuffer proxyMsgOnlyHeader(int sceneID,
                long heroID, int moduleID, int sequenceID){
            return proxyMsg(sceneID, heroID, moduleID, sequenceID, 0);
        }

        public static ChannelBuffer proxyMsgOnlyHeaderAnd1Varint32(int sceneID,
                long heroID, int moduleID, int sequenceID, int load){
            ChannelBuffer buffer = proxyMsg(sceneID, heroID, moduleID,
                    sequenceID, computeVarInt32Size(load));
            writeVarInt32(buffer, load);
            return buffer;
        }

        public static ChannelBuffer proxyMsgOnlyHeaderAnd1Varint64(int sceneID,
                long heroID, int moduleID, int sequenceID, long load){
            ChannelBuffer buffer = proxyMsg(sceneID, heroID, moduleID,
                    sequenceID, computeVarInt64Size(load));
            writeVarInt64(buffer, load);
            return buffer;
        }

        public static ChannelBuffer syncPosLifeJumpShieldRage(int sceneID,
                long heroID, int x, int y, int life, int jumpShield, int rage){
            ChannelBuffer buffer = newFixedSizeMessage(
                    ClusterSceneHeader.C2S_HERO_SYNC_POS_LIFE_AND_JUMP_SHIELD_RAGE,
                    sceneID, computeVarInt64Size(heroID)
                            + computeVarInt32Size(x) + computeVarInt32Size(y)
                            + computeVarInt32Size(life)
                            + computeVarInt32Size(jumpShield)
                            + computeVarInt32Size(rage));
            writeVarInt64(buffer, heroID);
            writeVarInt32(buffer, x);
            writeVarInt32(buffer, y);
            writeVarInt32(buffer, life);
            writeVarInt32(buffer, jumpShield);
            writeVarInt32(buffer, rage);
            return buffer;
        }

        public static ChannelBuffer syncPosAndLifeRage(int sceneID,
                long heroID, int x, int y, int life, int rage){
            ChannelBuffer buffer = newFixedSizeMessage(
                    ClusterSceneHeader.C2S_HERO_SYNC_POS_AND_LIFE_RAGE,
                    sceneID, computeVarInt64Size(heroID)
                            + computeVarInt32Size(x) + computeVarInt32Size(y)
                            + computeVarInt32Size(life)
                            + computeVarInt32Size(rage));
            writeVarInt64(buffer, heroID);
            writeVarInt32(buffer, x);
            writeVarInt32(buffer, y);
            writeVarInt32(buffer, life);
            writeVarInt32(buffer, rage);
            return buffer;
        }

        public static ChannelBuffer tryAddPickUpGoods(int sceneID, long heroID,
                int sceneGoodsID, Goods g){
            GoodsServerProto proto = g.encode();
            int size = proto.getSerializedSize();

            ChannelBuffer buffer = newFixedSizeMessage(
                    ClusterSceneHeader.C2S_TRY_ADD_PICK_UP_GOODS, sceneID,
                    computeVarInt64Size(heroID)
                            + computeVarInt32Size(sceneGoodsID) + size);
            writeVarInt64(buffer, heroID);
            writeVarInt32(buffer, sceneGoodsID);
            writeProto(buffer, proto);
            return buffer;
        }

        public static ChannelBuffer addSceneAmountGoods(int sceneID,
                long heroID, int sceneGoodsID, GoodsType type, int amount){
            int typeNumber = type.getNumber();

            ChannelBuffer buffer = newFixedSizeMessage(
                    ClusterSceneHeader.C2S_ADD_SCENE_AMOUNT_GOODS, sceneID,
                    computeVarInt64Size(heroID)
                            + computeVarInt32Size(sceneGoodsID)
                            + computeVarInt32Size(typeNumber)
                            + computeVarInt32Size(amount));
            writeVarInt64(buffer, heroID);
            writeVarInt32(buffer, sceneGoodsID);
            writeVarInt32(buffer, typeNumber);
            writeVarInt32(buffer, amount);
            return buffer;
        }

        public static ChannelBuffer changeToNormalScene(int sceneID,
                long heroID, int normalSceneDataID, int line, int x, int y,
                TransportType transportType){
            int transportTypeNumber = transportType == null ? 0 : transportType
                    .getNumber();

            ChannelBuffer buffer = newFixedSizeMessage(
                    ClusterSceneHeader.C2S_HERO_TRANSPORT_TO_NORMAL_SCENE,
                    sceneID, computeVarInt64Size(heroID)
                            + computeVarInt32Size(normalSceneDataID)
                            + computeVarInt32Size(line)
                            + computeVarInt32Size(x) + computeVarInt32Size(y)
                            + computeVarInt32Size(transportTypeNumber));

            writeVarInt64(buffer, heroID);
            writeVarInt32(buffer, normalSceneDataID);
            writeVarInt32(buffer, line);
            writeVarInt32(buffer, x);
            writeVarInt32(buffer, y);
            writeVarInt32(buffer, transportTypeNumber);
            return buffer;
        }

        public static ChannelBuffer setJumpShield(int sceneID, long heroID,
                int newJumpShield){
            ChannelBuffer buffer = newFixedSizeMessage(
                    ClusterSceneHeader.C2S_HERO_SET_JUMP_SHIELD, sceneID,
                    computeVarInt64Size(heroID)
                            + computeVarInt32Size(newJumpShield));
            writeVarInt64(buffer, heroID);
            writeVarInt32(buffer, newJumpShield);
            return buffer;
        }

        public static ChannelBuffer tryReduceToolAndPerfectRelive(int sceneID,
                long heroID, int suggestedPos){
            ChannelBuffer buffer = newFixedSizeMessage(
                    ClusterSceneHeader.C2S_TRY_REDUCE_TOOL_AND_PERFECT_RELIVE,
                    sceneID, computeVarInt64Size(heroID)
                            + computeVarInt32Size(suggestedPos));
            writeVarInt64(buffer, heroID);
            writeVarInt32(buffer, suggestedPos);
            return buffer;
        }

        public static ChannelBuffer heroMediate(int sceneID, long heroID,
                boolean isDoubleMediate){
            ChannelBuffer buffer = newFixedSizeMessage(
                    ClusterSceneHeader.C2S_HERO_MEDIATE, sceneID,
                    computeVarInt64Size(heroID) + 1);
            writeVarInt64(buffer, heroID);
            writeBoolean(buffer, isDoubleMediate);
            return buffer;
        }

        public static ChannelBuffer killedMonster(int sceneID, long heroID,
                int monsterDataID){
            ChannelBuffer buffer = newFixedSizeMessage(
                    ClusterSceneHeader.C2S_HERO_KILLED_MONSTER, sceneID,
                    computeVarInt64Size(heroID)
                            + computeVarInt32Size(monsterDataID));
            writeVarInt64(buffer, heroID);
            writeVarInt32(buffer, monsterDataID);
            return buffer;
        }

        public static ChannelBuffer portalHeroFinished(int sceneID,
                long heroID, int deadCount, int duration){
            ChannelBuffer buffer = ClusterSceneHeader.newFixedSizeMessage(
                    ClusterSceneHeader.C2S_PORTAL_HERO_FINISHED, sceneID,
                    computeVarInt64Size(heroID)
                            + computeVarInt32Size(deadCount)
                            + computeVarInt32Size(duration));
            writeVarInt64(buffer, heroID);
            writeVarInt32(buffer, deadCount);
            writeVarInt32(buffer, duration);
            return buffer;
        }

        public static ChannelBuffer souShenBossDead(int sceneID,
                long bossSceneID){
            return ClusterSceneHeader.onlySendHeadAndAVarInt64Message(
                    ClusterSceneHeader.C2S_SOU_SHEN_BOSS_DEAD, sceneID,
                    bossSceneID);
        }

        public static ChannelBuffer dungeonFinished(int sceneID, int deadCount,
                int totalTimeInSeconds){
            return ClusterSceneHeader.onlySendHeadAnd2VarInt32Message(
                    ClusterSceneHeader.C2S_DUNGEON_FINISHED, sceneID,
                    deadCount, totalTimeInSeconds);
        }

    }

    // --- 消息构建helper方法 ---
    private static final int HEADER_COUNT = ClusterSceneHeader.values().length;

    private static final ClusterSceneHeader[] HEADERS = ClusterSceneHeader
            .values();

    public static ClusterSceneHeader getHeaderByID(int id){
        if (id >= 0 && id < HEADER_COUNT){
            return HEADERS[id];
        }
        return null;
    }

    private static final int SCENE_MESSAGE_ORDINAL_SIZE = computeVarInt32Size(CombatHeader.SCENE_MESSAGE
            .ordinal());
    private static final int SCENE_MESSAGE_ORDINAL = CombatHeader.SCENE_MESSAGE
            .ordinal();

    public static ChannelBuffer newFixedSizeMessage(ClusterSceneHeader msg,
            int sceneID, int sureSizeExcludingSizeAndID){
        ChannelBuffer buffer = new BigEndianHeapChannelBuffer(2
                + SCENE_MESSAGE_ORDINAL_SIZE
                + computeVarInt32Size(msg.ordinal())
                + computeVarInt32Size(sceneID) + sureSizeExcludingSizeAndID
                + SCENE_MESSAGE_ORDINAL_SIZE);
        buffer.writeShort(0);
        writeVarInt32(buffer, SCENE_MESSAGE_ORDINAL);
        writeVarInt32(buffer, msg.ordinal());
        writeVarInt32(buffer, sceneID);

        return buffer;
    }

    public static ChannelBuffer newDynamicMessage(ClusterSceneHeader msg,
            int sceneID){
        return newDynamicMessage(msg, sceneID, 64);
    }

    /**
     * 返回的ChannelBuffer会按需加大
     * 
     * @param msgId
     * @param approxSize
     * @return
     */
    public static ChannelBuffer newDynamicMessage(ClusterSceneHeader msg,
            int sceneID, int approxSizeExcludingSizeAndID){
        ChannelBuffer buffer = ChannelBuffers
                .dynamicBuffer(20 + approxSizeExcludingSizeAndID);
        buffer.writeShort(0);// place holder for buffer size
        writeVarInt32(buffer, SCENE_MESSAGE_ORDINAL);
        writeVarInt32(buffer, msg.ordinal());
        writeVarInt32(buffer, sceneID);
        return buffer;
    }

    public static ChannelBuffer onlySendHeaderMessage(ClusterSceneHeader msg,
            int sceneID){
        return newFixedSizeMessage(msg, sceneID, 0);
    }

    public static ChannelBuffer onlySendHeadAndABoolBytes(
            ClusterSceneHeader msg, int sceneID, boolean b){
        ChannelBuffer buffer = newFixedSizeMessage(msg, sceneID, 1);
        writeBoolean(buffer, b);
        return buffer;
    }

    public static ChannelBuffer onlySendHeadAndAUTFBytes(
            ClusterSceneHeader msg, int sceneID, byte[] utf){
        ChannelBuffer buffer = newFixedSizeMessage(msg, sceneID, utf.length);
        buffer.writeBytes(utf);
        return buffer;
    }

    public static ChannelBuffer onlySendHeadAndAByteMessage(
            ClusterSceneHeader msg, int sceneID, int b){
        ChannelBuffer buffer = newFixedSizeMessage(msg, sceneID, 1);
        buffer.writeByte(b);
        return buffer;
    }

    public static ChannelBuffer onlySendHeadAndAVarInt32Message(
            ClusterSceneHeader msg, int sceneID, int b){
        ChannelBuffer buffer = newFixedSizeMessage(msg, sceneID,
                computeVarInt32Size(b));
        writeVarInt32(buffer, b);
        return buffer;
    }

    public static ChannelBuffer onlySendHeadAnd2VarInt32Message(
            ClusterSceneHeader msg, int sceneID, int b, int c){
        ChannelBuffer buffer = newFixedSizeMessage(msg, sceneID,
                computeVarInt32Size(b) + computeVarInt32Size(c));
        writeVarInt32(buffer, b);
        writeVarInt32(buffer, c);
        return buffer;
    }

    public static ChannelBuffer onlySendHeadAnd3VarInt32Message(
            ClusterSceneHeader msg, int sceneID, int b, int c, int d){
        ChannelBuffer buffer = newFixedSizeMessage(msg, sceneID,
                computeVarInt32Size(b) + computeVarInt32Size(c)
                        + computeVarInt32Size(d));
        writeVarInt32(buffer, b);
        writeVarInt32(buffer, c);
        writeVarInt32(buffer, d);
        return buffer;
    }

    public static ChannelBuffer onlySendHeadAnd4VarInt32Message(
            ClusterSceneHeader msg, int sceneID, int b, int c, int d, int e){
        ChannelBuffer buffer = newFixedSizeMessage(msg, sceneID,
                computeVarInt32Size(b) + computeVarInt32Size(c)
                        + computeVarInt32Size(d) + computeVarInt32Size(e));
        writeVarInt32(buffer, b);
        writeVarInt32(buffer, c);
        writeVarInt32(buffer, d);
        writeVarInt32(buffer, e);
        return buffer;
    }

    public static ChannelBuffer onlySendHeadAndAVarInt64Message(
            ClusterSceneHeader msg, int sceneID, long b){
        ChannelBuffer buffer = newFixedSizeMessage(msg, sceneID,
                computeVarInt64Size(b));
        writeVarInt64(buffer, b);
        return buffer;
    }

    public static ChannelBuffer onlySendHeadAnd2VarInt64Message(
            ClusterSceneHeader msg, int sceneID, long b, long c){
        ChannelBuffer buffer = newFixedSizeMessage(msg, sceneID,
                computeVarInt64Size(b) + computeVarInt64Size(c));
        writeVarInt64(buffer, b);
        writeVarInt64(buffer, c);
        return buffer;
    }

    public static ChannelBuffer onlySendHeaderAndVarIntsMessage(
            ClusterSceneHeader msg, int sceneID, int... value){
        int size = 0;
        for (int i : value){
            size += computeVarInt32Size(i);
        }
        ChannelBuffer result = newFixedSizeMessage(msg, sceneID, size);
        for (int i : value){
            writeVarInt32(result, i);
        }
        return result;
    }

    public static ChannelBuffer onlySendHeadAndBytesMessage(
            ClusterSceneHeader msg, int sceneID, byte[] data){
        ChannelBuffer buffer = newFixedSizeMessage(msg, sceneID, data.length);
        buffer.writeBytes(data);
        return buffer;
    }

    public static ChannelBuffer newProtobufMessage(ClusterSceneHeader header,
            int sceneID, MessageLite msg){
        int size = msg.getSerializedSize();
        ChannelBuffer buffer = newFixedSizeMessage(header, sceneID, size);

        CodedOutputStream out = CodedOutputStream.newInstance(buffer.array(),
                buffer.writerIndex(), size);
        try{
            msg.writeTo(out);
        } catch (IOException e){
            throw new RuntimeException(
                    "Serializing to a byte array threw an IOException "
                            + "(should never happen).", e);
        }

        buffer.writerIndex(buffer.writerIndex() + size);
        return buffer;
    }

}
