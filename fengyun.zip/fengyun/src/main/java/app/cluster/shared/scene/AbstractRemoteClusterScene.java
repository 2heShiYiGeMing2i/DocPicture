package app.cluster.shared.scene;

import static app.game.module.MiscModule.DisconnectReason.INTERNAL_ERROR_ADD_POSITION_MODULE_FAIL;
import static com.mokylin.sink.util.BufferUtil.*;

import java.util.Collection;

import org.jboss.netty.buffer.ChannelBuffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.data.ConfigService;
import app.game.data.SpriteStat;
import app.game.data.Vip;
import app.game.data.bow.BowData;
import app.game.data.bow.HeroBow;
import app.game.data.pet.HeroPet;
import app.game.data.pet.HeroTianJie;
import app.game.data.pet.HeroTianZui;
import app.game.data.pet.TianJieData;
import app.game.data.pet.TianZuiData;
import app.game.data.scene.SceneData;
import app.game.data.spell.FightState;
import app.game.data.spell.FightState.FightStateInstance;
import app.game.data.spell.PassiveSpell;
import app.game.data.weapon7.SuperWeaponData;
import app.game.module.EquipmentMessages;
import app.game.module.VipMessages;
import app.game.module.scene.*;
import app.game.module.scene.AbstractHeroFightModule.PkMode;
import app.game.service.IThreadService;
import app.game.service.TimeService;
import app.game.service.WorldData;
import app.message.ISender;
import app.protobuf.SpriteStatContent.SpriteStatProto;
import app.utils.IDUtils;
import app.utils.VariableConfig;

import com.mokylin.sink.util.concurrent.DisruptorExecutor;

/**
 * 在远程服上的真正处理逻辑的场景
 * @author Timmy
 *
 */
public abstract class AbstractRemoteClusterScene implements IScene{
    private static final Logger logger = LoggerFactory
            .getLogger(AbstractRemoteClusterScene.class);

    protected final IScenePositionModule positionModule;

    protected final int sceneUUID;

    protected final IThreadService threadService;

    protected final TimeService timeService;

    protected final FightProcessor fightProcessor;

    protected final SceneObjectProcessor sceneGoodsProcessor;

    private final Object positionModuleSharedSync = new Object();

    protected final IDungeonService dungeonService;

    private final ClusterSceneBroadcaster sceneBroadcaster;

    protected AbstractRemoteClusterScene(SceneData sceneData, int uuid,
            IDungeonService dungeonService){
        logger.debug("新建场景: {}. uuid: {}", sceneData, uuid);
        this.sceneUUID = uuid;
        this.dungeonService = dungeonService;
        this.timeService = dungeonService.getTimeService();
        this.threadService = dungeonService.getThreadService();

        sceneBroadcaster = new ClusterSceneBroadcaster(uuid);

        ConcurrentPositionModule pm = new ConcurrentPositionModule(
                sceneData.getEndX(), sceneData.getEndY(), timeService,
                sceneData.isSeeAllInScene());
        this.positionModule = pm;

        this.sceneGoodsProcessor = new SceneObjectProcessor(
                sceneData.blockInfo, positionModule,
                dungeonService.getDelayedEventService());

        this.fightProcessor = new FightProcessor(positionModule,
                sceneBroadcaster, dungeonService.getDelayedEventService(),
                timeService, sceneData.blockInfo,
                sceneData.newReliveMonsterFightModules(this),
                sceneData.newSingleLifeMonsterFightModules(this),
                sceneData.newSingleLifeMonsterWithTime(timeService, this),
                sceneData.isSeeAllInScene());
    }

    @Override
    public void addHero(AbstractHeroFightModule heroFightModule, long ctime,
            boolean isEnteringFirstScene){
        assert heroFightModule.isInScene(this);
        logger.debug("英雄进入场景: {} -> {}", heroFightModule, this);

        RemoteHeroFightModule rhfm = (RemoteHeroFightModule) heroFightModule;
        sceneBroadcaster.add(rhfm.getWorker());

        // 进入场景前, 不需要随机一个点, 应该由游戏服已经随机好了, 这里就直接让玩家站在发来的点上就好了
        // 游戏服已经发送了进入场景消息, 这里不需要再发
        PkMode fixPkMode = getSceneData().getFixedPkMode();
        if (fixPkMode != null){
            // 设置固定PK模式
            heroFightModule.getHero().setPkMode(fixPkMode);
        }

        // 先发消息让客户端进入场景, 再发hero加入positionModule. 不然另一个线程可能已经开始把别的英雄发给客户端了
        if (!positionModule.add(heroFightModule)){
            logger.error("positionModule 添加英雄失败.... 断开");

            heroFightModule.disconnect(INTERNAL_ERROR_ADD_POSITION_MODULE_FAIL);
        }
    }

    @Override
    public void removeHero(AbstractHeroFightModule heroFightModule,
            boolean isOffline){
        logger.debug("英雄离开场景: {} -> {}", heroFightModule, this);
        RemoteHeroFightModule rhfm = (RemoteHeroFightModule) heroFightModule;
        sceneBroadcaster.remove(rhfm.getWorker());

        rhfm.setHasEnteredScene(false);
        positionModule.remove(heroFightModule);
    }

    private void onHeroLeave(long heroID, boolean isOffline){
        FightModule fm = getTarget(heroID);
        if (fm instanceof AbstractHeroFightModule){
            removeHero((AbstractHeroFightModule) fm, isOffline);
        } else{
            logger.warn(
                    "AbstractRemoveClusterScene收到onHeroLeave时, 没有找到英雄: {}-{}",
                    heroID, fm);
        }
    }

    /**
     * 处理来自游戏服, 让这个场景处理的消息
     * @param header
     * @param buffer
     * @param worker
     */
    // @NettyThread
    public void onSceneMessage(ClusterSceneHeader header,
            final ChannelBuffer buffer, final ISender worker){
        try{
            switch (header){
                case S2C_HERO_ADD_SINGLE_EFFECT_FIGHT_STATE:{
                    final long heroID = readVarInt64(buffer);
                    int stateID = readVarInt32(buffer);
                    final int multiple = readVarInt32(buffer);

                    final FightState fs = getConfigService().getFightStates()
                            .get(stateID);
                    if (fs == null){
                        logger.error(
                                "AbstractRemoteClusterScene.S2C_HERO_ADD_SINGLE_EFFECT_FIGHT_STATE时, 状态没找到. id: {}",
                                stateID);
                        return;
                    }

                    threadService.getExecutor(IDUtils.getUserID(heroID))
                            .execute(new Runnable(){
                                @Override
                                public void run(){
                                    RemoteHeroFightModule hfm = getHero(heroID);
                                    if (hfm == null){
                                        logger.warn("AbstractRemoteClusterScene.S2C_HERO_ADD_SINGLE_EFFECT_FIGHT_STATE时, 英雄不在场景了");
                                        return;
                                    }

                                    hfm.selfThreadProcessStateEffect(fs,
                                            getCurrentTime(), multiple);
                                }
                            });
                    return;
                }

                case S2C_HERO_ADD_FIGHT_STATE:{
                    final long heroID = readVarInt64(buffer);
                    int stateID = readVarInt32(buffer);
                    int stackCount = readVarInt32(buffer);
                    long disappearTime = readVarInt64(buffer);

                    FightState fs = getConfigService().getFightStates().get(
                            stateID);
                    if (fs == null){
                        logger.error(
                                "AbstractRemoteClusterScene.S2C_HERO_ADD_FIGHT_STATE时, 状态没找到. id: {}",
                                stateID);
                        return;
                    }

                    final long ctime = getCurrentTime();
                    final FightStateInstance fsi = fs.decode(stackCount,
                            disappearTime, ctime);

                    threadService.getExecutor(IDUtils.getUserID(heroID))
                            .execute(new Runnable(){
                                @Override
                                public void run(){
                                    RemoteHeroFightModule hfm = getHero(heroID);
                                    if (hfm == null){
                                        logger.error("AbstractRemoteClusterScene.S2C_HERO_ADD_FIGHT_STATE时, 英雄不在场景了");
                                        return;
                                    }

                                    hfm.addFightStateFromLocalScene(fsi, ctime);
                                }
                            });
                    return;
                }

                case S2C_ADD_PICK_UP_GOODS_SUCCESS:{
                    final long heroID = readVarInt64(buffer);
                    final int sceneGoodsID = readVarInt32(buffer);
                    threadService.getExecutor(IDUtils.getUserID(heroID))
                            .execute(new Runnable(){
                                @Override
                                public void run(){
                                    RemoteHeroFightModule hfm = getHero(heroID);
                                    if (hfm == null){
                                        logger.error("AbstractRemoteClusterScene.S2C_ADD_PICK_UP_GOODS_SUCCESS时, 英雄不在场景了");
                                        return;
                                    }

                                    hfm.onPickUpGoodsSuccess(sceneGoodsID);
                                }
                            });
                    return;
                }

                case S2C_ADD_PICK_UP_GOODS_FAIL:{
                    final long heroID = readVarInt64(buffer);
                    final int sceneGoodsID = readVarInt32(buffer);
                    threadService.getExecutor(IDUtils.getUserID(heroID))
                            .execute(new Runnable(){
                                @Override
                                public void run(){
                                    RemoteHeroFightModule hfm = getHero(heroID);
                                    if (hfm == null){
                                        logger.error("AbstractRemoteClusterScene.S2C_ADD_PICK_UP_GOODS_FAIL时, 英雄不在场景了");
                                        return;
                                    }

                                    hfm.onPickUpGoodsFail(sceneGoodsID);
                                }
                            });
                    return;
                }

                case S2C_PERFECT_RELIVE_SUCCESS:{
                    final long heroID = readVarInt64(buffer);
                    threadService.getExecutor(IDUtils.getUserID(heroID))
                            .execute(new Runnable(){
                                @Override
                                public void run(){
                                    RemoteHeroFightModule hfm = getHero(heroID);
                                    if (hfm == null){
                                        logger.error("AbstractRemoteClusterScene.S2C_PERFECT_RELIVE_SUCCESS时, 英雄不在场景了");
                                        return;
                                    }

                                    hfm.onTryReduceToolAndPerfectReliveSuccess();
                                }
                            });
                    return;
                }

                case S2C_PERFECT_RELIVE_FAIL:{
                    final long heroID = readVarInt64(buffer);
                    threadService.getExecutor(IDUtils.getUserID(heroID))
                            .execute(new Runnable(){
                                @Override
                                public void run(){
                                    RemoteHeroFightModule hfm = getHero(heroID);
                                    if (hfm == null){
                                        logger.error("AbstractRemoteClusterScene.S2C_PERFECT_RELIVE_FAIL时, 英雄不在场景了");
                                        return;
                                    }

                                    hfm.onTryReduceToolAndPerfectReliveFail();
                                }
                            });
                    return;
                }

                case S2C_BROADCAST:{
                    // 要求广播, 不需要广播给这个服
                    int len = buffer.readableBytes();
                    ChannelBuffer toSend = ClusterSceneHeader
                            .newFixedSizeMessage(
                                    ClusterSceneHeader.C2S_BROADCAST,
                                    sceneUUID, len);
                    toSend.writeBytes(buffer, len);
                    for (ISender w : sceneBroadcaster.getCombatMasterWorkers()){
                        if (w != worker){
                            w.sendMessage(toSend);
                        }
                    }
                    return;
                }

                case S2C_BROADCAST_DONT_SEND:{
                    long dontSend = readVarInt64(buffer);

                    // 要求广播, 不需要广播给这个服
                    int len = buffer.readableBytes();
                    ChannelBuffer toSend = ClusterSceneHeader
                            .newFixedSizeMessage(
                                    ClusterSceneHeader.C2S_BROADCAST_EXCEPT_ONE,
                                    sceneUUID, computeVarInt64Size(dontSend)
                                            + len);
                    writeVarInt64(toSend, dontSend);
                    toSend.writeBytes(buffer, len);
                    for (ISender w : sceneBroadcaster.getCombatMasterWorkers()){
                        if (w != worker){
                            w.sendMessage(toSend);
                        }
                    }
                    return;
                }

                case S2C_HERO_CHANGE_LEVEL:{
                    final long heroID = readVarInt64(buffer);
                    final int oldLevel = readVarInt32(buffer);
                    final int newLevel = readVarInt32(buffer);
                    threadService.getExecutor(IDUtils.getUserID(heroID))
                            .execute(new Runnable(){
                                @Override
                                public void run(){
                                    RemoteHeroFightModule heroFightModule = getHero(heroID);
                                    if (heroFightModule == null){
                                        logger.warn("AbstractRemoteClusterScene收到S2C_HERO_CHANGE_LEVEL时, 场景中没有找到英雄");
                                        return;
                                    }

                                    heroFightModule
                                            .setLevel(oldLevel, newLevel);
                                }
                            });
                    return;
                }

                case S2C_HERO_LEAVE:{
                    final long heroID = readVarInt64(buffer);
                    threadService.getExecutor(IDUtils.getUserID(heroID))
                            .execute(new Runnable(){
                                @Override
                                public void run(){
                                    onHeroLeave(heroID, false);
                                }
                            });
                    return;
                }

                case S2C_HERO_OFFLINE:{
                    final long heroID = readVarInt64(buffer);
                    threadService.getExecutor(IDUtils.getUserID(heroID))
                            .execute(new Runnable(){
                                @Override
                                public void run(){
                                    onHeroLeave(heroID, true);
                                }
                            });
                    return;
                }

                case S2C_CHANGE_BASE_STAT:{
                    final long heroID = readVarInt64(buffer);
                    SpriteStatProto spriteStatProto = readProto(
                            SpriteStatProto.getDefaultInstance(), buffer, null);
                    final SpriteStat newBaseStat = SpriteStat
                            .decode(spriteStatProto);
                    threadService.getExecutor(IDUtils.getUserID(heroID))
                            .execute(new Runnable(){
                                @Override
                                public void run(){
                                    RemoteHeroFightModule hfm = getHero(heroID);
                                    if (hfm == null){
                                        logger.warn("AbstractRemoteClusterScene收到S2C_CHANGE_BASE_STAT时, 场景中没有找到英雄");
                                        return;
                                    }

                                    hfm.changeBaseStat(hfm.getFightData()
                                            .getBaseStat(), newBaseStat,
                                            getCurrentTime());
                                }
                            });
                    return;
                }

                case S2C_CHANGE_EQUIPMENT_RESOURCE:{
                    final long heroID = readVarInt64(buffer);
                    final int newEquipmentResource = readVarInt32(buffer);
                    threadService.getExecutor(IDUtils.getUserID(heroID))
                            .execute(new Runnable(){
                                @Override
                                public void run(){
                                    RemoteHeroFightModule hfm = getHero(heroID);
                                    if (hfm == null){
                                        logger.warn("AbstractRemoteClusterScene收到S2C_CHANGE_EQUIPMENT_RESOURCE时, 场景中没有找到英雄");
                                        return;
                                    }

                                    hfm.getHero()
                                            .getModel()
                                            .setCurrentResourceOnly(
                                                    newEquipmentResource);
                                    hfm.selfThreadBroadcastAround(EquipmentMessages
                                            .getEquipmentResourcesChanged(
                                                    heroID,
                                                    newEquipmentResource));
                                }
                            });
                    return;
                }

                case S2C_CHANGE_VIP:{
                    final long heroID = readVarInt64(buffer);
                    final int newVip = readVarInt32(buffer);
                    threadService.getExecutor(IDUtils.getUserID(heroID))
                            .execute(new Runnable(){
                                @Override
                                public void run(){
                                    RemoteHeroFightModule hfm = getHero(heroID);
                                    if (hfm == null){
                                        logger.warn("AbstractRemoteClusterScene收到S2C_CHANGE_VIP时, 场景中没有找到英雄");
                                        return;
                                    }

                                    if (hfm.getHero().isVip()){
                                        // 如果英雄已经是Vip，则不处理
                                        logger.warn("AbstractRemoteClusterScene收到S2C_CHANGE_VIP时, 英雄已经是Vip了");
                                        return;
                                    }

                                    Vip vip = getConfigService().getVips().get(
                                            newVip);

                                    if (vip == null){
                                        logger.warn(
                                                "AbstractRemoteClusterScene收到S2C_CHANGE_VIP时, Vip等级不存在: {}",
                                                newVip);
                                        return;
                                    }

                                    hfm.getHero().setVip(vip);
                                    hfm.selfThreadBroadcastAround(VipMessages
                                            .sceneBecomeVipBroadcast(hfm
                                                    .getID()));
                                }
                            });
                    return;
                }

                case S2C_CHANGE_SUPER_WEAPON:{
                    final long heroID = readVarInt64(buffer);
                    final int newWeapon = readVarInt32(buffer);
                    threadService.getExecutor(IDUtils.getUserID(heroID))
                            .execute(new Runnable(){
                                @Override
                                public void run(){
                                    RemoteHeroFightModule hfm = getHero(heroID);
                                    if (hfm == null){
                                        logger.warn("AbstractRemoteClusterScene收到S2C_CHANGE_SUPER_WEAPON时, 场景中没有找到英雄");
                                        return;
                                    }

                                    if (newWeapon == 0){
                                        hfm.getHero().setUsingWeapon(null);
                                        return;
                                    }

                                    SuperWeaponData data = getConfigService()
                                            .getSuperWeapons().get(newWeapon);
                                    if (data == null){
                                        logger.warn(
                                                "AbstractRemoteClusterScene收到S2C_CHANGE_SUPER_WEAPON时, 神兵id不存在: {}",
                                                newWeapon);
                                        return;
                                    }

                                    hfm.getHero().setUsingWeapon(data);
                                }
                            });
                    return;
                }

                case S2C_BOW_UPGRADE:{
                    final long heroID = readVarInt64(buffer);
                    final int newBow = readVarInt32(buffer);
                    threadService.getExecutor(IDUtils.getUserID(heroID))
                            .execute(new Runnable(){
                                @Override
                                public void run(){
                                    RemoteHeroFightModule hfm = getHero(heroID);
                                    if (hfm == null){
                                        logger.warn("AbstractRemoteClusterScene收到S2C_BOW_UPGRADE时, 场景中没有找到英雄");
                                        return;
                                    }

                                    if (newBow <= 0){
                                        logger.warn(
                                                "AbstractRemoteClusterScene收到S2C_BOW_UPGRADE时, newBow<=0, {}",
                                                newBow);
                                        return;
                                    }

                                    BowData data = getConfigService().getBows()
                                            .getBow(newBow);
                                    if (data == null){
                                        logger.warn(
                                                "AbstractRemoteClusterScene收到S2C_BOW_UPGRADE时, 弓箭id不存在: {}",
                                                newBow);
                                        return;
                                    }

                                    HeroBow heroBow = hfm.getHero().getBow();
                                    if (heroBow == null){
                                        hfm.getHero().setBow(data.newBow());
                                    } else{
                                        heroBow.setBowData(data);
                                    }

                                }
                            });
                    return;
                }

                case S2C_ADD_HERO_SPELL:{
                    final long heroID = readVarInt64(buffer);
                    threadService.getExecutor(IDUtils.getUserID(heroID))
                            .execute(new Runnable(){
                                @Override
                                public void run(){
                                    RemoteHeroFightModule hfm = getHero(heroID);
                                    if (hfm == null){
                                        logger.warn("AbstractRemoteClusterScene收到S2C_ADD_HERO_SPELL时, 场景中没有找到英雄");
                                        return;
                                    }

                                    boolean hasSpell = false;
                                    while (buffer.readable()){
                                        int spellID = readVarInt32(buffer);

                                        PassiveSpell spell = getConfigService()
                                                .getSpells().getPassiveSpells()
                                                .get(spellID);
                                        if (spell == null){
                                            logger.warn(
                                                    "AbstractRemoteClusterScene收到S2C_ADD_HERO_SPELL时, 技能id不存在: {}",
                                                    spellID);
                                            continue;
                                        }

                                        hfm.getPassiveSpellList().add(spell);
                                        hasSpell = true;
                                    }

                                    if (hasSpell){
                                        hfm.getPassiveSpellList()
                                                .onSpellChanged();
                                    }
                                }
                            });
                    return;
                }

                case S2C_REMOVE_HERO_SPELL:{
                    final long heroID = readVarInt64(buffer);
                    threadService.getExecutor(IDUtils.getUserID(heroID))
                            .execute(new Runnable(){
                                @Override
                                public void run(){
                                    RemoteHeroFightModule hfm = getHero(heroID);
                                    if (hfm == null){
                                        logger.warn("AbstractRemoteClusterScene收到S2C_REMOVE_HERO_SPELL时, 场景中没有找到英雄");
                                        return;
                                    }

                                    boolean hasSpell = false;
                                    while (buffer.readable()){
                                        int spellID = readVarInt32(buffer);

                                        PassiveSpell spell = getConfigService()
                                                .getSpells().getPassiveSpells()
                                                .get(spellID);
                                        if (spell == null){
                                            logger.warn(
                                                    "AbstractRemoteClusterScene收到S2C_REMOVE_HERO_SPELL时, 技能id不存在: {}",
                                                    spellID);
                                            continue;
                                        }

                                        hfm.getPassiveSpellList().remove(spell);
                                        hasSpell = true;
                                    }

                                    if (hasSpell){
                                        hfm.getPassiveSpellList()
                                                .onSpellChanged();
                                    }
                                }
                            });
                    return;
                }

                case S2C_REPLACE_HERO_SPELL:{
                    final long heroID = readVarInt64(buffer);
                    final int toRemove = readVarInt32(buffer);
                    final int toAdd = readVarInt32(buffer);
                    threadService.getExecutor(IDUtils.getUserID(heroID))
                            .execute(new Runnable(){
                                @Override
                                public void run(){
                                    RemoteHeroFightModule hfm = getHero(heroID);
                                    if (hfm == null){
                                        logger.warn("AbstractRemoteClusterScene收到S2C_REPLACE_HERO_SPELL时, 场景中没有找到英雄");
                                        return;
                                    }

                                    PassiveSpell toRemoveSpell = getConfigService()
                                            .getSpells().getPassiveSpells()
                                            .get(toRemove);
                                    if (toRemoveSpell == null){
                                        logger.warn(
                                                "AbstractRemoteClusterScene收到S2C_REPLACE_HERO_SPELL时, toRemove技能id不存在: {}",
                                                toRemove);
                                        return;
                                    }

                                    PassiveSpell toAddSpell = getConfigService()
                                            .getSpells().getPassiveSpells()
                                            .get(toAdd);
                                    if (toAddSpell == null){
                                        logger.warn(
                                                "AbstractRemoteClusterScene收到S2C_REPLACE_HERO_SPELL时, toAdd技能id不存在: {}",
                                                toAdd);
                                        return;
                                    }

                                    hfm.getPassiveSpellList().remove(
                                            toRemoveSpell);
                                    hfm.getPassiveSpellList().add(toAddSpell);

                                    hfm.getPassiveSpellList().onSpellChanged();
                                }
                            });
                    return;
                }

                case S2C_CHANGE_PET:{
                    final long heroID = readVarInt64(buffer);
                    final long expireTime = readVarInt64(buffer);
                    final int tianjieID = readVarInt32(buffer);
                    final int tianzuiID = readVarInt32(buffer);
                    threadService.getExecutor(IDUtils.getUserID(heroID))
                            .execute(new Runnable(){
                                @Override
                                public void run(){
                                    RemoteHeroFightModule hfm = getHero(heroID);
                                    if (hfm == null){
                                        logger.warn("AbstractRemoteClusterScene收到S2C_CHANGE_PET时, 场景中没有找到英雄");
                                        return;
                                    }

                                    // 天劫数据
                                    if (tianjieID > 0){

                                        HeroTianJie tianjie = hfm.getHero()
                                                .getTianJie();

                                        if (tianjie == null){
                                            TianJieData data = getConfigService()
                                                    .getPet().getTianJie(
                                                            tianjieID);
                                            tianjie = data.newTianJie();
                                            hfm.getHero().setTianJie(tianjie);
                                        } else if (tianjie.getId() != tianjieID){
                                            TianJieData data = getConfigService()
                                                    .getPet().getTianJie(
                                                            tianjieID);

                                            tianjie.setData(data);
                                        }
                                    }

                                    // 天罪数据
                                    if (tianjieID > 0){

                                        HeroTianZui tianzui = hfm.getHero()
                                                .getTianZui();

                                        if (tianzui == null){
                                            TianZuiData data = getConfigService()
                                                    .getPet().getTianZui(
                                                            tianzuiID);
                                            tianzui = data.newTianZui();
                                            hfm.getHero().setTianZui(tianzui);
                                        } else if (tianzui.getId() != tianzuiID){
                                            TianZuiData data = getConfigService()
                                                    .getPet().getTianZui(
                                                            tianzuiID);

                                            tianzui.setData(data);
                                        }
                                    }

                                    HeroPet pet = hfm.getHero().getPet();
                                    if (pet == null){
                                        pet = new HeroPet(getConfigService()
                                                .getPet().getLevelDatas(), hfm
                                                .getHero().getLevel(),
                                                expireTime);
                                        hfm.getHero().setPet(pet);
                                    } else if (expireTime == 0
                                            && pet.hasExpiredTime()){
                                        pet.removeExpireTime();
                                    }

                                    hfm.onRemovePet();
                                }
                            });
                    return;
                }

                case S2C_CHANGE_PET_SPELL:{
                    final long heroID = readVarInt64(buffer);
                    final int pos = readVarInt32(buffer);
                    final int spellID = readVarInt32(buffer);
                    threadService.getExecutor(IDUtils.getUserID(heroID))
                            .execute(new Runnable(){
                                @Override
                                public void run(){
                                    RemoteHeroFightModule hfm = getHero(heroID);
                                    if (hfm == null){
                                        logger.warn("AbstractRemoteClusterScene收到S2C_CHANGE_PET_SPELL时, 场景中没有找到英雄");
                                        return;
                                    }

                                    HeroPet pet = hfm.getHero().getPet();
                                    if (pet == null){
                                        logger.warn("AbstractRemoteClusterScene收到S2C_CHANGE_PET_SPELL时, 英雄没有宠物");
                                        return;
                                    }

                                    if (pos < 0
                                            || pos >= pet.getSpells().length){
                                        logger.warn(
                                                "AbstractRemoteClusterScene收到S2C_CHANGE_PET_SPELL时, 技能位置无效: {}",
                                                pos);
                                        return;
                                    }

                                    PassiveSpell spell = getConfigService()
                                            .getSpells().getPassiveSpells()
                                            .get(spellID);
                                    if (spell == null){
                                        logger.warn(
                                                "AbstractRemoteClusterScene收到S2C_CHANGE_PET_SPELL时, 技能id不存在: {}",
                                                spellID);
                                        return;
                                    }

                                    pet.replace(pos, spell);
                                }
                            });
                    return;
                }

                case S2C_CHANGE_PK_MODE:{
                    final long heroID = readVarInt64(buffer);
                    int intPkMode = readVarInt32(buffer);
                    final PkMode pkMode = PkMode.valueOf(intPkMode);
                    if (pkMode == null){
                        logger.warn(
                                "AbstractRemoteClusterScene收到S2C_CHANGE_PK_MODE时, 无效的pkmode-{}",
                                intPkMode);
                        return;
                    }

                    threadService.getExecutor(IDUtils.getUserID(heroID))
                            .execute(new Runnable(){
                                @Override
                                public void run(){
                                    RemoteHeroFightModule hfm = getHero(heroID);
                                    if (hfm == null){
                                        logger.warn("AbstractRemoteClusterScene收到S2C_CHANGE_PET_SPELL时, 场景中没有找到英雄");
                                        return;
                                    }

                                    hfm.getHero().setPkMode(pkMode);
                                }
                            });
                    return;
                }

                case S2C_PROXY_SCENE_MODULE_MSG:{
                    long heroID = readVarInt64(buffer);
                    RemoteHeroFightModule remoteHeroFightModule = getHero(heroID);
                    if (remoteHeroFightModule != null){
                        int sequenceID = readVarInt32(buffer);
                        // 交给英雄线程处理
                        remoteHeroFightModule.getTaskExec().processMessage(
                                buffer, SceneMessages.MODULE_ID, sequenceID,
                                remoteHeroFightModule);
                    } else{
                        logger.warn(
                                "AbstractRemoveClusterScene收到S2C_PROXY_SCENE_MODULE_MSG时, 没有找到英雄: {} heroID: {}",
                                getSceneData(), heroID);
                    }
                    return;
                }

                default:{
                    logger.error(
                            "有AbstractRemoveClusterScene.onSceneMessage收到未处理的ClusterSceneHeader: {}-{}",
                            header.ordinal(), header);
                }
            }
        } catch (Throwable ex){
            logger.error(
                    "AbstractRemoteScene.onSceneMessage出错. id: "
                            + header.ordinal() + ", header: " + header, ex);
        }
    }

    @Override
    public FightModule getTarget(long id){
        return positionModule.getObject(id);
    }

    public RemoteHeroFightModule getHero(long id){
        FightModule fm = positionModule.getObject(id);
        if (fm == null){
            return null;
        }

        return (RemoteHeroFightModule) fm;
    }

    @Override
    public SceneObjectProcessor getSceneObjectProcessor(){
        return sceneGoodsProcessor;
    }

    @Override
    public int getSceneID(){
        return sceneUUID;
    }

    @Override
    public int getSceneUUID(){
        return sceneUUID;
    }

    @Override
    public int getSceneConfigDataID(){
        return getSceneData().id;
    }

    @Override
    public FightProcessor getFightProcessor(){
        return fightProcessor;
    }

    @Override
    public long getCurrentTime(){
        return timeService.getCurrentTime();
    }

    @Override
    public void onMonsterDead(MonsterFightModule dead, FightModule attacker,
            long ctime, long realDeadTime){
        fightProcessor.onMonsterDead(dead, attacker, realDeadTime);
    }

    @Override
    public void onHeroAddMonsterDeadExp(HeroFightModule heroFightModule,
            int amount){

    }

    @Override
    public void onHeroDead(AbstractHeroFightModule heroFightModule){

    }

    @Override
    public Object getPositionModuleSharedSync(){
        return positionModuleSharedSync;
    }

    @Override
    public float getMeditateMultiple(){
        return 0;
    }

    @Override
    public void onAddMediateAmount(HeroFightModule hfm, int toAddExp,
            int toAddRealAir){
    }

    @Override
    public VariableConfig getVariableConfig(){
        return dungeonService.getVariableConfig();
    }

    @Override
    public WorldData getWorldData(){
        return dungeonService.getWorldData();
    }

    @Override
    public ConfigService getConfigService(){
        return dungeonService.getConfigService();
    }

    public Collection<AbstractHeroFightModule> getAllHeroes(){
        return positionModule.getAllHeroObjects();
    }

    @Override
    public String toString(){
        return "跨服场景-" + getSceneData().id + "-" + getSceneData().name;
    }

    /**
     * 广播给全场景的人
     * @param buffer
     */
    @Override
    public void broadcast(ChannelBuffer buffer){
        sceneBroadcaster.broadcast(buffer);
    }

    @Override
    public void broadcast(ChannelBuffer buffer, long dontSend){
        sceneBroadcaster.broadcast(buffer, dontSend);
    }

    /**
     * 广播给全场景的人
     * @param buffer
     */
    @Override
    public void broadcastDroppableMsg(ChannelBuffer buffer){
        sceneBroadcaster.broadcastDroppableMsg(buffer);
    }

    @Override
    public void broadcastDroppableMsg(ChannelBuffer buffer, long dontSend){
        sceneBroadcaster.broadcastDroppableMsg(buffer, dontSend);
    }

    /**
     * 直接广播给每个有英雄在本场景的CombatMasterWorker
     * @param buffer
     */
    protected void broadcastToAllLocalScene(ChannelBuffer buffer){
        sceneBroadcaster.broadcastToAllLocalScene(buffer);
    }

    public abstract void processServerDisconnected(DisruptorExecutor exec,
            ISender worker);
}
