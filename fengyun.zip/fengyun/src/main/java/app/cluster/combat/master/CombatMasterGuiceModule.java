package app.cluster.combat.master;

import app.cluster.combat.master.logic.CombatMasterDungeonService;
import app.cluster.combat.master.logic.CombatMasterPerHeroUpdateService;
import app.cluster.combat.master.logic.CombatMasterServices;
import app.game.service.*;
import app.game.service.redeploy.IHotRedeployService;
import app.utils.CombatMasterServerType;
import app.utils.ServerType;

import com.google.inject.AbstractModule;
import com.google.inject.Singleton;
import com.mokylin.sink.util.pack.RealFileHorizontalConfigLoader;
import com.mokylin.zk.util.ClusterConnection;
import com.mokylin.zk.util.ClusterSharedConfiguration;

public class CombatMasterGuiceModule extends AbstractModule{

    @Override
    protected void configure(){
        binder().requireExplicitBindings();

        bind(CombatMasterConfiguration.class).in(Singleton.class);
        bind(ClusterConnection.class).in(Singleton.class);
        bind(ClusterSharedConfiguration.class).to(
                CombatMasterConfiguration.class).in(Singleton.class);
        bind(CombatMasterServer.class).in(Singleton.class);
        bind(RealFileHorizontalConfigLoader.class).in(Singleton.class);
        bind(CombatMasterServices.class).in(Singleton.class);
        bind(IThreadService.class).to(ThreadServiceImpl.class).in(
                Singleton.class);
        bind(TimeService.class).to(SyncNtpTimeService.class)
                .in(Singleton.class);
        bind(DelayedEventService.class).in(Singleton.class);
        bind(CombatMasterDungeonService.class).in(Singleton.class);
        bind(WorldData.class).in(Singleton.class);
        bind(IWorldBroadcaster.class).to(CombatMasterServices.class).in(
                Singleton.class);
        bind(SelfThreadExecuteService.class).in(Singleton.class);
        bind(CombatMasterPerHeroUpdateService.class).in(Singleton.class);
        bind(CombatMasterWorkers.class).in(Singleton.class);

        bind(IHotRedeployService.class).to(DumpHotRedeployService.class).in(
                Singleton.class);

        bind(ServerType.class).to(CombatMasterServerType.class).in(
                Singleton.class);
    }

}
