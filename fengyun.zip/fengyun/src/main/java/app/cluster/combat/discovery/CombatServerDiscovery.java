package app.cluster.combat.discovery;

import java.io.Closeable;

import org.apache.curator.framework.imps.CuratorFrameworkState;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.cluster.combat.master.CombatMasterServer;
import app.cluster.combat.master.CombatMasterServerInfo;
import app.game.service.IThreadService;

import com.google.inject.Inject;
import com.mokylin.sink.util.Utils;
import com.mokylin.zk.util.ClusterConnection;
import com.mokylin.zk.util.NodeDiscovery;
import com.mokylin.zk.util.NodeDiscovery.NodeListener;

/**
 * 获取并保持更新CombatMasterServer列表
 * @author Timmy
 *
 */
public class CombatServerDiscovery implements Closeable{
    private static final Logger logger = LoggerFactory
            .getLogger(CombatServerDiscovery.class);

    private final ClusterConnection connection;

    private NodeDiscovery<CombatMasterServerInfo> node;

    private final ICombatServerListener listener;

    private final NodeListener<CombatMasterServerInfo> nodeListener;

    private final IThreadService threadService;

    @Inject
    public CombatServerDiscovery(ClusterConnection connection,
            ICombatServerListener listener, IThreadService threadService){
        this.connection = connection;
        this.listener = listener;
        this.threadService = threadService;
        this.nodeListener = new NodeListener<CombatMasterServerInfo>(){

            @Override
            public void onNodeAdded(String path, CombatMasterServerInfo node){
                CombatServerDiscovery.this.listener.onCombatServerAdded(node);
            }

            @Override
            public void onNodeRemoved(String path, CombatMasterServerInfo node){
                CombatServerDiscovery.this.listener.onCombatServerRemoved(node);
            }

            @Override
            public void onNodeUpdated(String path, CombatMasterServerInfo node){
                CombatServerDiscovery.this.listener.onCombatServerUpdated(node);
            }
        };
    }

    /**
     * 开启. 此时的connection必须是已经start过了的
     */
    public void start(){
        assert connection.getCuratorFramework().getState() == CuratorFrameworkState.STARTED;

        node = new NodeDiscovery<>(connection.getCuratorFramework(),
                CombatMasterServer.PATH, CombatMasterServerInfo.PARSER,
                nodeListener, threadService.getScheduledExecutorService());

        node.start();
    }

    /**
     * 必须在connection close之前调用
     */
    @Override
    public void close(){
        // 不close connection
        Utils.closeQuietly(node);
    }
}
