package app.cluster.combat.master;

import java.util.Comparator;

import org.apache.curator.utils.ZKPaths;

import app.cluster.protobuf.ServerInfoContent.CombatMasterInfoProto;

import com.google.protobuf.InvalidProtocolBufferException;
import com.mokylin.zk.util.NodeDiscovery.NodeDataParser;

public class CombatMasterServerInfo{

    public static final Comparator<CombatMasterServerInfo> LOAD_COMPARATOR = new Comparator<CombatMasterServerInfo>(){

        @Override
        public int compare(CombatMasterServerInfo o1, CombatMasterServerInfo o2){
            return o1.load - o2.load;
        }
    };

    public final long id;
    public final String address;
    public final int port;
    private final int load;

    private CombatMasterServerInfo(String path, byte[] proto)
            throws InvalidProtocolBufferException{
        // 通过路径, 获得id
        String pathWithPrefix = ZKPaths.getNodeFromPath(path);
        String p = pathWithPrefix
                .substring(CombatMasterServer.PATH_PREFIX_LENGTH);

        id = Long.parseLong(p) + 1; // 避免第一个的id是0
        CombatMasterInfoProto info = CombatMasterInfoProto.parseFrom(proto);
        this.address = info.getAddress();
        this.port = info.getPort();
        this.load = info.getLoad();
    }

    public int getLoad(){
        return load;
    }

    @Override
    public String toString(){
        return id + " @ " + address + ":" + port;
    }

    @Override
    public int hashCode(){
        return (int) id;
    }

    @Override
    public boolean equals(Object obj){
        if (obj instanceof CombatMasterServerInfo){
            CombatMasterServerInfo info = (CombatMasterServerInfo) obj;
            return id == info.id;
        }
        return false;
    }

    // ----

    public static final NodeDataParser<CombatMasterServerInfo> PARSER = new NodeDataParser<CombatMasterServerInfo>(){

        @Override
        public CombatMasterServerInfo parse(String path, byte[] nodeData){
            try{
                return new CombatMasterServerInfo(path, nodeData);
            } catch (Throwable e){
                throw new RuntimeException(e);
            }
        }

        @Override
        public boolean isValid(String path, byte[] nodeData){
            return ZKPaths.getNodeFromPath(path).startsWith(
                    CombatMasterServer.PATH_PREFIX);
        }
    };

}
