package app.cluster.combat.master;

import static com.mokylin.sink.util.BufferUtil.*;

import java.util.ArrayList;
import java.util.List;

import org.jboss.netty.buffer.ChannelBuffer;
import org.jboss.netty.channel.Channel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.cluster.combat.master.logic.CombatMasterServices;
import app.cluster.shared.scene.CombatHeader;
import app.message.ISender;
import app.utils.IDUtils;

import com.mokylin.collection.IntArrayList;
import com.mokylin.sink.server.Worker;
import com.mokylin.sink.util.BufferUtil;

/**
 * 来自游戏服的连接
 * @author Timmy
 *
 */
class CombatMasterWorker implements Worker, ISender{

    private static final Logger logger = LoggerFactory
            .getLogger(CombatMasterWorker.class);

    private final CombatMasterServices services;

    private final Channel channel;

    /**
     * 存着这个连接里所有的 运营商id+服务器id
     */
    private IntArrayList operatorAndServerIDs;

    /**
     * 是否已登录
     */
    private boolean authenticated;

    CombatMasterWorker(Channel channel, CombatMasterServices services){
        this.channel = channel;
        this.services = services;
    }

    @Override
    public void onMessage(ChannelBuffer buffer){
        int msgId = BufferUtil.readVarInt32(buffer);
        try{

            CombatHeader header = CombatHeader.getHeaderByID(msgId);
            if (header == null){
                logger.error("CombatMasterWorker收到未知消息: {}", msgId); // 可能手动设置了版本号
                channel.close(); // 应该有BUG了
                return;
            }

            logger.debug("received client msg: {}", header);

            if (!authenticated){
                if (header == CombatHeader.S2C_HELLO_COMBAT){
                    doAuthenticate(buffer);
                    return;
                } else{
                    logger.error(
                            "CombatMasterWorker收到消息: {}, 但之前没有收到S2C_HELLO_COMBAT. 断开",
                            header);
                    channel.close();
                }
                return;
            }

            switch (header){
                case SCENE_MESSAGE:{
                    services.getDungeonService().onSceneMessage(buffer, this);
                    return;
                }

                case S2C_HERO_NEW_ENTER:{
                    services.getDungeonService().onHeroNewEnter(buffer, this);
                    return;
                }

                case S2C_HERO_OFFLINE_REENTER:{
                    services.getDungeonService().onHeroOfflineReenter(buffer,
                            this);
                    return;
                }

                case S2C_VIEW_HERO:{
                    // 要观察英雄
                    services.getDungeonService().onViewHero(buffer, this);
                    return;
                }

                case S2C_PROXY_MSG_TO_HERO_ON_ANOTHER_SERVER:{
                    onProxyMsgToHeroOnAnotherServer(buffer);
                    return;
                }

                default:{
                    logger.error("CombatMasterWorker 收到未处理消息: {}-{}", msgId,
                            header);
                }
            }
        } catch (Throwable ex){
            logger.error("CombatMasterWorker.onMessage出错. msgId: " + msgId, ex);
        }
    }

    private void onProxyMsgToHeroOnAnotherServer(ChannelBuffer buffer){
        long targetID = readVarInt64(buffer);
        CombatMasterWorker targetWorker = services.getCombatMasterWorkers()
                .get(IDUtils.getCombinedServerAndOperatorID(targetID));
        if (targetWorker == null){
            logger.error(
                    "CombatMasterWorker.onProxyMsgToHeroOnAnotherServer 时, 没有找到目标服务器: operatorID: {}, serverID: {}",
                    IDUtils.getOperatorID(targetID),
                    IDUtils.getServerID(targetID));
            return;
        }

        int len = buffer.readableBytes();
        ChannelBuffer msg = CombatHeader.proxyMsgFixSize(targetID, len);
        msg.writeBytes(buffer);
        targetWorker.sendMessage(msg);
    }

    @Override
    public boolean sendMessage(ChannelBuffer buffer){
        channel.write(buffer);
        return true;
    }

    private void doAuthenticate(ChannelBuffer buffer){
        logger.info("游戏服登录成功: {}", channel.getRemoteAddress());

        // 这里需要解析发来的区服信息

        List<String> serverRepresentation = new ArrayList<>(3);
        for (int i = 0; i < 100; i++){            // 防止攻击
            if (!buffer.readable()){
                break;
            }

            String str = readUTF(buffer);
            serverRepresentation.add(str);
        }

        operatorAndServerIDs = parseServerRepresentations(serverRepresentation);

        if (operatorAndServerIDs == null){
            logger.error("CombatMasterWorker.doAuthenticate 时, 不符合要求. 断开");
            channel.close();
            return;
        }

        services.getCombatMasterWorkers().add(operatorAndServerIDs, this);

        authenticated = true;
    }

    private static IntArrayList parseServerRepresentations(List<String> input){
        IntArrayList result = new IntArrayList();

        for (String config : input){
            int opPos = config.indexOf("@");
            if (opPos <= 0){
                logger.error(
                        "CombatMasterWorker.parseServerRepresentations 时, 没有找到@符号: {}",
                        config);
                return null;
            }

            int operatorID = Integer.parseInt(config.substring(0, opPos));
            String[] sids = config.substring(opPos + 1).split("-");
            for (int i = 0; i < sids.length; i++){
                int sid = Integer.parseInt(sids[i]);
                result.add(IDUtils.combineOperatorAndServerID(operatorID, sid));
            }
        }
        return result;
    }

    @Override
    public void onDisconnect(){
        logger.debug("与游戏服的连接断开: {}", channel.getRemoteAddress());

        if (!authenticated){
            return;
        }

        logger.info("已登录的游戏服断开: {}", channel.getRemoteAddress());

        // 把所有来自这个服的玩家踢出场景. 场景没人了就关掉
        services.getDungeonService().processServerDisconnected(this);

        // 删除自己
        services.getCombatMasterWorkers().remove(operatorAndServerIDs, this);
    }

    @Override
    public void onConnected(){
        logger.debug("收到来自游戏服的连接: {}", channel.getRemoteAddress());
    }

    // ---

    @Override
    public int hashCode(){
        return System.identityHashCode(this);
    }

    @Override
    public boolean equals(Object obj){
        return this == obj;
    }

}
