package app.cluster.combat.master.logic;

import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.cluster.shared.scene.AbstractRemoteClusterScene;
import app.cluster.shared.scene.RemoteHeroFightModule;
import app.game.module.scene.AbstractHeroFightModule;
import app.game.service.IThreadService;
import app.game.service.TimeService;
import app.utils.VariableConfig;

import com.google.inject.Inject;
import com.mokylin.sink.util.FuncWithTime;
import com.mokylin.sink.util.concurrent.DisruptorExecutor;

/**
 * 定时更新在Combat服的每个英雄
 * 
 * @author Timmy
 *
 */
public class CombatMasterPerHeroUpdateService{
    private static final Logger logger = LoggerFactory
            .getLogger(CombatMasterPerHeroUpdateService.class);

    private final CombatMasterDungeonService dungeonService;

    private final DisruptorExecutor[] executorsArray;

    private final TimeService timeService;

    @Inject
    CombatMasterPerHeroUpdateService(CombatMasterDungeonService dungeonService,
            IThreadService threadService, TimeService timeService){
        this.dungeonService = dungeonService;
        this.timeService = timeService;

        this.executorsArray = threadService.getExecutorsArrayCopy();

        // 每100毫秒更新
        threadService.getScheduledExecutorService().scheduleAtFixedRate(
                new Runnable(){
                    @Override
                    public void run(){
                        try{
                            applyFunctionToAllHeroUsingHeroThread(heroUpdateFunc);
                        } catch (Throwable ex){
                            logger.error(
                                    "CombatMasterPerHeroUpdateService.applyFunctionToAllHeroUsingHeroThread出错",
                                    ex);
                        }
                    }
                }, 1000, VariableConfig.SCENE_MONSTER_UPDATE_INTERVAL,
                TimeUnit.MILLISECONDS);

        // 每秒更新
        threadService.getScheduledExecutorService().scheduleAtFixedRate(
                new Runnable(){
                    @Override
                    public void run(){
                        try{
                            applyFunctionToAllHeroUsingHeroThread(heroUpdatePerSecondFunc);
                        } catch (Throwable ex){
                            logger.error(
                                    "CombatMasterPerHeroPerSecondUpdateService.applyFunctionToAllHeroUsingHeroThread出错",
                                    ex);
                        }
                    }
                }, 1, 1, TimeUnit.SECONDS);

    }

    /**
     * 每秒更新一次英雄
     */
    private final FuncWithTime<RemoteHeroFightModule> heroUpdatePerSecondFunc = new FuncWithTime<RemoteHeroFightModule>(){

        @Override
        public void apply(RemoteHeroFightModule t, long ctime){
            t.updatePerSecond(ctime);
        }

    };

    /**
     * 几百毫秒更新一次英雄
     */
    private final FuncWithTime<RemoteHeroFightModule> heroUpdateFunc = new FuncWithTime<RemoteHeroFightModule>(){

        @Override
        public void apply(RemoteHeroFightModule t, long ctime){
            t.updatePerMillis(ctime);
        }

    };

    /**
     * 使用英雄线程, 调用func
     * @param func
     */
    public void applyFunctionToAllHeroUsingHeroThread(
            final FuncWithTime<RemoteHeroFightModule> func){
        for (final DisruptorExecutor exec : executorsArray){
            exec.execute(new Runnable(){
                public void run(){
                    long ctime = timeService.getCurrentTime();
                    for (AbstractRemoteClusterScene dungeon : dungeonService
                            .getAllDungeons()){
                        for (AbstractHeroFightModule hfm : dungeon
                                .getAllHeroes()){
                            if (hfm.isSameExec(exec)){
                                try{
                                    func.apply((RemoteHeroFightModule) hfm,
                                            ctime);
                                } catch (Throwable ex){
                                    logger.error(
                                            "CombatMasterPerHeroUpdateService.applyFunc出错",
                                            ex);
                                }
                            }
                        }
                    }
                }
            });
        }
    }
}
