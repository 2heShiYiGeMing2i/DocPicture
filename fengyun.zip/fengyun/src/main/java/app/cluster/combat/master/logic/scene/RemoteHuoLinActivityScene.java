package app.cluster.combat.master.logic.scene;

import static app.cluster.client.combat.scene.HuoLinActivityMessages.*;
import static com.mokylin.sink.util.BufferUtil.*;

import org.jboss.netty.buffer.ChannelBuffer;

import app.cluster.shared.scene.ClusterSceneHeader;
import app.game.data.scene.HuoLinActivitySceneData;
import app.game.data.scene.MonsterGroupWithTimeData;
import app.game.data.scene.SceneMonsterData;
import app.game.module.scene.AbstractHeroFightModule;
import app.game.module.scene.FightModule;
import app.game.module.scene.IDungeonService;
import app.game.module.scene.IScheduledThreadUpdateDungeon;
import app.game.module.scene.MonsterFightModule;
import app.message.ISender;
import app.utils.VariableConfig;

import com.mokylin.collection.LongHashMap;
import com.mokylin.sink.util.annotation.SelfThreadOnly;
import com.mokylin.sink.util.holder.LongLongHolder;

public class RemoteHuoLinActivityScene extends RemoteGlobalActivityScene
        implements IScheduledThreadUpdateDungeon{

    private final HuoLinActivitySceneData sceneData;

    private final ChannelBuffer broadcastAddExpRealAirMsg;

    /**
     * 下一次给所有加经验和真气的时间
     */
    private long nextAddExpRealAirTime;

    private final long createTime;

    private final LongHashMap<LongLongHolder> bossKilledTimeMap;

    private final byte[] cacheEnterData;

    public RemoteHuoLinActivityScene(HuoLinActivitySceneData sceneData,
            int uuid, IDungeonService dungeonService, long creator,
            ISender worker){
        super(sceneData, uuid, dungeonService, creator, worker);

        this.sceneData = sceneData;
        this.broadcastAddExpRealAirMsg = ClusterSceneHeader
                .onlySendHeaderMessage(
                        ClusterSceneHeader.C2S_HUO_LIN_ADD_EXP_AND_REAL_AIR,
                        uuid);

        long ctime = dungeonService.getTimeService().getCurrentTime();
        createTime = ctime;

        this.nextAddExpRealAirTime = ctime
                + VariableConfig.HUO_LIN_EACH_ADD_EXP_REAL_AIR_INTERVAL;

        bossKilledTimeMap = new LongHashMap<LongLongHolder>();
        for (MonsterGroupWithTimeData group : sceneData.getMonsterWithTimes()){
            for (SceneMonsterData m : group.getMonsters()){
                bossKilledTimeMap.put(m.getID(), new LongLongHolder(m.getID(),
                        0));
            }
        }

        long timeLimit = getTimeLimit();
        int len = computeVarInt64Size(timeLimit)
                + computeVarInt64Size(createTime)
                + computeVarInt32Size(sceneData.compressBossConfigBytes.length)
                + sceneData.compressBossConfigBytes.length;

        byte[] array = new byte[len];
        int index = 0;

        index = writeVarInt64(array, index, timeLimit);
        index = writeVarInt64(array, index, createTime);
        index = writeVarInt32(array, index,
                sceneData.compressBossConfigBytes.length);
        index = writeBytes(array, index, sceneData.compressBossConfigBytes);

        cacheEnterData = array;
    }

//    private long doCalculateNextSpawnBossTime(long ctime){
//        long nextTime = Long.MAX_VALUE;
//        for (MonsterGroupWithTimeData mon : sceneData.getMonsterWithTimes()){
//            nextTime = Math.min(nextTime, mon.timeData.getNextTime(ctime));
//        }
//        return nextTime;
//    }

    @Override
    @SelfThreadOnly
    public void addHero(AbstractHeroFightModule heroFightModule, long ctime,
            boolean isEnteringFirstScene){
        super.addHero(heroFightModule, ctime, isEnteringFirstScene);

        // 如果已经过期了, 传送出去
        if (ctime >= getTimeLimit()){
            heroFightModule.doLeaveDungeon();
            return;
        }

        // 发送副本剩余时间和下次刷新boss时间
        heroFightModule.sendMessage(setEndTimeAndNextBossTime(cacheEnterData,
                bossKilledTimeMap.values()));
    }

    @Override
    public void onMonsterDead(MonsterFightModule dead, FightModule attacker,
            long ctime, long realDeadTime){
        super.onMonsterDead(dead, attacker, ctime, realDeadTime);

        if (dead.isBoss()){
            LongLongHolder holder = bossKilledTimeMap.get(dead.getID());
            if (holder != null){
                holder.setValue(ctime);

                broadcast(bossBeenKilled(dead.getID(), ctime));
            }
        }
    }

    @Override
    public HuoLinActivitySceneData getSceneData(){
        return sceneData;
    }

    @Override
    public void scheduledThreadUpdate(long ctime){
        super.scheduledThreadUpdate(ctime);

        if (ctime >= nextAddExpRealAirTime){
            nextAddExpRealAirTime = ctime
                    + VariableConfig.HUO_LIN_EACH_ADD_EXP_REAL_AIR_INTERVAL;
            broadcastToAllLocalScene(broadcastAddExpRealAirMsg);
        }

//        if (ctime >= nextSpawnBossTime){
//            nextSpawnBossTime = doCalculateNextSpawnBossTime(ctime);
//            broadcast(setNextBossTime(nextSpawnBossTime >= getTimeLimit() ? 0
//                    : nextSpawnBossTime)); // 下次刷新超出活动结束时间, 就发送0
//        }
    }
}
