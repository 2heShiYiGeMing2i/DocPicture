package app.cluster.combat.master.logic.scene;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.cluster.shared.scene.ClusterSceneHeader;
import app.game.data.scene.SouShenDungeonSceneData;
import app.game.module.scene.AbstractHeroFightModule;
import app.game.module.scene.FightModule;
import app.game.module.scene.IDungeonService;
import app.game.module.scene.MonsterFightModule;
import app.message.ISender;

import com.mokylin.sink.util.annotation.SelfThreadOnly;
import com.mokylin.sink.util.concurrent.PaddedAtomicBoolean;
import com.mokylin.sink.util.concurrent.PaddedAtomicInteger;
import com.mokylin.sink.util.delay.DelayedEvent;

public class RemoteSouShenDungeonScene extends RemoteGroupDungeonScene{
    private static final Logger logger = LoggerFactory
            .getLogger(RemoteSouShenDungeonScene.class);

    private final SouShenDungeonSceneData sceneData;

    private final PaddedAtomicInteger bossLeft;

    private final PaddedAtomicBoolean allBossDead;

    public RemoteSouShenDungeonScene(SouShenDungeonSceneData sceneData,
            int uuid, IDungeonService dungeonService, long creator,
            ISender worker){
        super(sceneData, uuid, dungeonService, creator, worker);

        this.sceneData = sceneData;
        this.bossLeft = new PaddedAtomicInteger(
                sceneData.getHasPrizeBossCount());
        this.allBossDead = new PaddedAtomicBoolean(false);
    }

    @Override
    public SouShenDungeonSceneData getSceneData(){
        return sceneData;
    }

    @Override
    @SelfThreadOnly
    public void addHero(AbstractHeroFightModule heroFightModule, long ctime,
            boolean isEnteringFirstScene){
        super.addHero(heroFightModule, ctime, isEnteringFirstScene);

        // 副本过期, 传出
        if (ctime >= getTimeLimit()){
            heroFightModule.doLeaveDungeonAndSendDungeonTimeUpMsg();
            return;
        }

    }

    @Override
    public void onMonsterDead(MonsterFightModule dead, FightModule attacker,
            long ctime, long realDeadTime){
        super.onMonsterDead(dead, attacker, ctime, realDeadTime);

        final long deadID = dead.getID();

        // 可领boss奖励
        if (sceneData.getBossPrize(deadID) != null){

            logger.debug("搜神宫boss挂了, 可领取奖励: {}", deadID);

            final long eventTime = realDeadTime + 500; // 使用真正的死亡时间, 再加500毫秒, 作为处理的时间

            dungeonService.getDelayedEventService().addDelayedEvent(
                    new DelayedEvent(){

                        @Override
                        public void handle(long ctime){
                            // 通知所有游戏服, 所有在场景内的英雄都加入可领取这个boss奖励的列表, 并发送消息给每个英雄
                            broadcastToAllLocalScene(ClusterSceneHeader.C2S
                                    .souShenBossDead(sceneUUID, deadID));

                            if (bossLeft.decrementAndGet() == 0){
                                // 所有boss都死了, 通关

                                onAllBossDead();
                            }
                        }

                        @Override
                        public long getEventTime(){
                            return eventTime;
                        }
                    });
        }
    }

    private void onAllBossDead(){
        if (!allBossDead.compareAndSet(false, true)){
            logger.error("SouShenDungeonScene.onAllBossDead被调用了2次?");
            return;
        }

        logger.debug("搜神宫完成, 可领取奖励");
        broadcastDungeonFinishedMsgToLocalScenes();
    }
}
