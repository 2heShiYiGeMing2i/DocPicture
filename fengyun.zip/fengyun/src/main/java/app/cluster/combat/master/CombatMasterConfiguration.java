package app.cluster.combat.master;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.inject.Inject;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.pack.RealFileHorizontalConfigLoader;
import com.mokylin.sink.util.parse.ObjectParser;
import com.mokylin.zk.util.ClusterSharedConfiguration;

public class CombatMasterConfiguration implements ClusterSharedConfiguration{
    private static final Logger logger = LoggerFactory
            .getLogger(CombatMasterConfiguration.class);

    private final String ZK_CONNECT_STRING;

    public final String SELF_ADDRESS;

    public final int LISTEN_PORT;

    public final String NTP_SERVER;

    @Inject
    CombatMasterConfiguration(RealFileHorizontalConfigLoader loader){
        final ObjectParser parser = loader.loadFile(LOCATION);

        this.ZK_CONNECT_STRING = parser.getKey("zk_connect_string",
                "168.168.1.18:2181");

        this.NTP_SERVER = parser.getKey("ntp_server", "");

        this.LISTEN_PORT = parser.getIntKey("combat_listen_port", 0);
        String selfAddressConfig = parser.getKey("self_address", "auto");
        if ("auto".equals(selfAddressConfig)){
            // 自动获取本机ip
            try{
                this.SELF_ADDRESS = Utils.getSelfIP();
                logger.info("自动获取本机ip: {}", SELF_ADDRESS);
            } catch (Throwable ex){
                logger.error("无法自动获得本机ip地址. 尝试在" + LOCATION
                        + " 中, 加一条 self_address=xxx.xxx.xxx.xxx 配置");
                throw new RuntimeException(ex);
            }
        } else{
            this.SELF_ADDRESS = selfAddressConfig;
        }
    }

    @Override
    public String getZKConnectString(){
        return ZK_CONNECT_STRING;
    }

    @Override
    public String getNtpServer(){
        return NTP_SERVER;
    }

}
