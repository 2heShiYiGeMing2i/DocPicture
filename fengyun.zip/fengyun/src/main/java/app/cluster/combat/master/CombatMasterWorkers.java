package app.cluster.combat.master;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.utils.IDUtils;

import com.google.inject.Inject;
import com.mokylin.collection.IntArrayList;
import com.mokylin.collection.IntSynchronizedHashMap;

public class CombatMasterWorkers{
    private static final Logger logger = LoggerFactory
            .getLogger(CombatMasterWorkers.class);

    /**
     * key是 运营商+区服id
     * value 是worker
     */
    private final IntSynchronizedHashMap<CombatMasterWorker> workers;

    @Inject
    CombatMasterWorkers(){
        this.workers = new IntSynchronizedHashMap<>();
    }

    void add(IntArrayList list, CombatMasterWorker worker){
        for (int i = 0; i < list.size(); i++){
            CombatMasterWorker oldWorler = workers.put(list.get(i), worker);
            if (oldWorler != null){
                int id = list.get(i);
                logger.error(
                        "CombatMasterWorkers.add时, worker之前已经存在... {}-{}",
                        IDUtils.getOperatorIDFromCombineOperatorAndServerID(id),
                        IDUtils.getServerIDFromCombineOperatorAndServerID(id));

            }
        }
    }

    void remove(IntArrayList list, CombatMasterWorker worker){
        for (int i = 0; i < list.size(); i++){
            workers.remove(list.get(i));
        }
    }

    public CombatMasterWorker get(int combinedOperatorAndServerID){
        return workers.get(combinedOperatorAndServerID);
    }

}
