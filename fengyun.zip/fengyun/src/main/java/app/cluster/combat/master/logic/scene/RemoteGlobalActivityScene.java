package app.cluster.combat.master.logic.scene;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.data.scene.GlobalActivitySceneData;
import app.game.module.scene.AbstractHeroFightModule;
import app.game.module.scene.IDungeonService;
import app.game.module.scene.IScheduledThreadUpdateDungeon;
import app.message.ISender;

/**
 * 跨服的活动场景
 * @author Timmy
 *
 */
public abstract class RemoteGlobalActivityScene extends AbstractRemoteDungeon
        implements IScheduledThreadUpdateDungeon{
    private static final Logger logger = LoggerFactory
            .getLogger(RemoteGlobalActivityScene.class);

    private final GlobalActivitySceneData sceneData;

    private final long timeLimit;

    public RemoteGlobalActivityScene(GlobalActivitySceneData sceneData,
            int uuid, IDungeonService dungeonService, long creator,
            ISender worker){
        super(sceneData, uuid, dungeonService, creator, worker);

        this.sceneData = sceneData;

        // 算出本次活动的开始时间
        long ctime = dungeonService.getTimeService().getCurrentTime();
        long startTime = sceneData.activityTime.getNextTime(ctime
                - sceneData.activityDurationMillis - 10000); // 放宽10秒钟. 可能时间上差一点点

        if (startTime < ctime){
            // 当前确实已经开始了
            this.timeLimit = startTime + sceneData.activityDurationMillis;
        } else{
            // 当前不在活动时间
            this.timeLimit = ctime;
        }
    }

    protected long getTimeLimit(){
        return timeLimit;
    }

    @Override
    public boolean isLocalClusterScene(){
        return false;
    }

    @Override
    public GlobalActivitySceneData getSceneData(){
        return sceneData;
    }

    private long nextKickHeroesTime;

    @Override
    public void scheduledThreadUpdate(long ctime){
        if (ctime >= timeLimit){
            // 每隔几秒再踢一次
            if (ctime < nextKickHeroesTime){
                return;
            }
            nextKickHeroesTime = ctime + 5000;
            logger.debug("活动时间到: {}", sceneUUID);
            for (final AbstractHeroFightModule hfm : getAllHeroes()){
                hfm.getTaskExec().execute(new Runnable(){
                    @Override
                    public void run(){
                        hfm.doLeaveDungeon();
                    }
                });
            }
        }
    }

}
