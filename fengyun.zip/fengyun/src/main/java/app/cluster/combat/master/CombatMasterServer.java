package app.cluster.combat.master;

import java.io.Closeable;
import java.lang.management.ManagementFactory;
import java.lang.management.OperatingSystemMXBean;
import java.util.concurrent.TimeUnit;

import org.apache.curator.framework.recipes.nodes.PersistentEphemeralNode;
import org.apache.curator.framework.recipes.nodes.PersistentEphemeralNode.Mode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.cluster.combat.master.logic.CombatMasterServices;
import app.cluster.protobuf.ServerInfoContent.CombatMasterInfoProto;
import app.game.service.IThreadService;
import app.utils.VariableConfig;

import com.google.common.annotations.VisibleForTesting;
import com.google.inject.Inject;
import com.mokylin.sink.server.NettyServer;
import com.mokylin.sink.util.Utils;
import com.mokylin.zk.util.ClusterConnection;

/**
 * 负责战斗的场景
 * @author Timmy
 *
 */
public class CombatMasterServer implements Closeable{
    private static final Logger logger = LoggerFactory
            .getLogger(CombatMasterServer.class);

    /**
     * 游戏服发过来的消息最大尺寸
     */
    private static final int MSG_SIZE_LIMIT = 65000;

    public static final String PATH = "/combat";

    static final String PATH_PREFIX = VariableConfig.CLUSTER_VERSION + ",";

    static final int PATH_PREFIX_LENGTH = PATH_PREFIX.length();

    private final ClusterConnection connection;

    private final IThreadService threadService;

    private final String selfAddress;

    private final CombatMasterInfoProto.Builder infoBuilder;

    /**
     * 接收来自各个游戏服的连接
     */
    private final NettyServer nettyServer;

    private final OperatingSystemMXBean mxBean;

    /**
     * zookeeper中我的load
     */
    private int lastSentLoad;

    /**
     * 在zookeeper中通知master和游戏服自己的存在. 每一个combatMasterServer就会有一个node
     */
    @VisibleForTesting
    PersistentEphemeralNode node;

    @Inject
    CombatMasterServer(ClusterConnection connection,
            CombatMasterServices services, IThreadService threadService,
            CombatMasterConfiguration config){
        this(connection, services, threadService, config.SELF_ADDRESS,
                config.LISTEN_PORT);
    }

    public CombatMasterServer(ClusterConnection connection,
            CombatMasterServices services, IThreadService threadService,
            String selfAddress, int listenPort){
        this.connection = connection;
        this.threadService = threadService;

        this.selfAddress = selfAddress;

        this.mxBean = ManagementFactory.getOperatingSystemMXBean();
        this.infoBuilder = CombatMasterInfoProto.newBuilder()
                .setAddress(selfAddress).setPort(listenPort);

        this.nettyServer = new NettyServer(listenPort, MSG_SIZE_LIMIT,
                new CombatMasterWorkerFactory(services));
    }

    public void start() throws InterruptedException{
        // start netty
        int actualPort = nettyServer.start(selfAddress);
        infoBuilder.setPort(actualPort);

        // start cluster connection
        connection.start();

        // put zookeeper node

        this.lastSentLoad = getLoad();
        this.infoBuilder.setLoad(lastSentLoad);
        logger.debug("初始汇报的load: {}", lastSentLoad);
        byte[] selfInfo = infoBuilder.build().toByteArray();

        logger.debug("创建znode");
        node = new PersistentEphemeralNode(connection.getCuratorFramework(),
                Mode.EPHEMERAL_SEQUENTIAL, PATH + "/" + PATH_PREFIX, selfInfo);

        node.start();

        logger.debug("等待CombatMaster znode创建完");
        node.waitForInitialCreate(1, TimeUnit.DAYS);
        logger.debug("CombatMaster znode创建完");

        // schedule, 如果当前的load和master所知的我的load差很多,则刷新

        threadService.getScheduledExecutorService().scheduleAtFixedRate(
                new Runnable(){
                    @Override
                    public void run(){
                        try{
                            int newLoad = getLoad();
                            if (Math.abs(newLoad - lastSentLoad) > 100){
                                logger.debug("load 从 {} 变为 {}, 通知zookeeper",
                                        lastSentLoad, newLoad);
                                // 通知zookeeper
                                infoBuilder.setLoad(newLoad);

                                byte[] selfInfo = infoBuilder.build()
                                        .toByteArray();

                                node.setData(selfInfo);
                                lastSentLoad = newLoad;
                            }
                        } catch (Throwable ex){
                            logger.error("汇报load出错", ex);
                        }
                    }
                }, 10, 10, TimeUnit.SECONDS);
    }

    private int getLoad(){
        return (int) (mxBean.getSystemLoadAverage() * 100);
    }

    @Override
    public void close(){
        logger.debug("closing CombatMasterServer");
        Utils.closeQuietly(node);
        Utils.closeQuietly(connection);
        Utils.closeQuietly(threadService);
        Utils.closeQuietly(nettyServer);
    }
}
