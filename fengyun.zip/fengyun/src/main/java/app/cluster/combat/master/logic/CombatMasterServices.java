package app.cluster.combat.master.logic;

import org.jboss.netty.buffer.ChannelBuffer;

import app.cluster.combat.master.CombatMasterWorkers;
import app.game.data.ConfigService;
import app.game.service.IThreadService;
import app.game.service.IWorldBroadcaster;
import app.game.service.SelfThreadExecuteService;
import app.game.service.TimeService;

import com.google.inject.Inject;

public class CombatMasterServices implements IWorldBroadcaster{

    private final CombatMasterDungeonService dungeonService;

    private final ConfigService configService;

    private final IThreadService threadService;

    private final TimeService timeService;

    private final SelfThreadExecuteService selfThreadExecuteService;

    private final CombatMasterWorkers combatMasterWorkers;

    private final CombatMasterPerHeroUpdateService perHeroUpdateService;

    @Inject
    CombatMasterServices(CombatMasterDungeonService dungeonService,
            ConfigService configService, IThreadService threadService,
            TimeService timeService,
            SelfThreadExecuteService selfThreadExecuteService,
            CombatMasterPerHeroUpdateService perHeroUpdateService,
            CombatMasterWorkers combatMasterWorkers){
        this.dungeonService = dungeonService;
        this.configService = configService;
        this.threadService = threadService;
        this.timeService = timeService;
        this.selfThreadExecuteService = selfThreadExecuteService;
        this.perHeroUpdateService = perHeroUpdateService;
        this.combatMasterWorkers = combatMasterWorkers;
    }

    public CombatMasterWorkers getCombatMasterWorkers(){
        return combatMasterWorkers;
    }

    public CombatMasterDungeonService getDungeonService(){
        return dungeonService;
    }

    public IThreadService getThreadService(){
        return threadService;
    }

    public TimeService getTimeService(){
        return timeService;
    }

    public ConfigService getConfigService(){
        return configService;
    }

    @Override
    public void broadcast(ChannelBuffer buffer){
    }
}
