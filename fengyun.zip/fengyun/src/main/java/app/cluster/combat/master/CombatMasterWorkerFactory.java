package app.cluster.combat.master;

import org.jboss.netty.channel.Channel;

import app.cluster.combat.master.logic.CombatMasterServices;

import com.mokylin.sink.server.Worker;
import com.mokylin.sink.server.WorkerFactory;

/**
 * 接受来自游戏服的连接
 * @author Timmy
 *
 */
public class CombatMasterWorkerFactory implements WorkerFactory{

    private final CombatMasterServices services;

    CombatMasterWorkerFactory(CombatMasterServices services){
        this.services = services;
    }

    @Override
    public Worker newWorker(Channel channel){
        return new CombatMasterWorker(channel, services);
    }

}
