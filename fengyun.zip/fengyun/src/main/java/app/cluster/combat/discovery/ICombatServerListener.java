package app.cluster.combat.discovery;

import app.cluster.combat.master.CombatMasterServerInfo;

/**
 * 监听CombatServer的增加/删除/更改 (更改不会改地址和端口), 每个方法都需要快速返回. 别处加着锁呢
 * @author Timmy
 *
 */
public interface ICombatServerListener{

    /**
     * 新增了CombatServer. 必须快速返回
     * @param server
     */
    void onCombatServerAdded(CombatMasterServerInfo server);

    /**
     * 删除了CombatServer. 必须快速返回
     * @param server
     */
    void onCombatServerRemoved(CombatMasterServerInfo server);

    /**
     * CombatServer信息更新了, 不会更新address和port. 必须快速返回
     * @param server
     */
    void onCombatServerUpdated(CombatMasterServerInfo server);
}
