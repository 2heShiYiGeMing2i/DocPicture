package app.cluster.combat.master.logic.scene;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.cluster.client.logic.team.ClusterClientMessages;
import app.cluster.shared.scene.ClusterSceneHeader;
import app.game.data.scene.DamageRecorder;
import app.game.data.scene.DamageRecorder.HeroInfo;
import app.game.data.scene.GroupDungeonSceneData;
import app.game.module.scene.AbstractHeroFightModule;
import app.game.module.scene.IDungeonService;
import app.game.module.scene.IHeroDamageListener;
import app.game.module.scene.IScheduledThreadUpdateDungeon;
import app.message.ISender;

import com.mokylin.sink.util.annotation.MultiThread;
import com.mokylin.sink.util.annotation.SelfThreadOnly;
import com.mokylin.sink.util.concurrent.PaddedAtomicInteger;

/**
 * 在Combat服上的远程组队副本
 * @author Timmy
 *
 */
public abstract class RemoteGroupDungeonScene extends AbstractRemoteDungeon
        implements IHeroDamageListener, IScheduledThreadUpdateDungeon{
    private static final Logger logger = LoggerFactory
            .getLogger(RemoteGroupDungeonScene.class);

    /*
     * 英雄获得的经验在每个服本地的LocalClusterScene里保存
     *
     * 已完成副本的人也在每个服保存
     */

    private final GroupDungeonSceneData sceneData;

    /**
     * 副本时间限制. 到了这个时间还没完成就离开副本
     */
    protected final long timeLimit;

    /**
     * 副本开始时间
     */
    protected final long dungeonStartTime;

    /**
     * 如果统计伤害量, 不为null
     * 不统计, 为null
     */
    private final DamageRecorder damageRecorder;

    /**
     * 英雄总死亡次数
     */
    private final PaddedAtomicInteger totalDeadCounter;

    public RemoteGroupDungeonScene(GroupDungeonSceneData sceneData, int uuid,
            IDungeonService dungeonService, long creator, ISender worker){
        super(sceneData, uuid, dungeonService, creator, worker);

        this.sceneData = sceneData;
        this.totalDeadCounter = new PaddedAtomicInteger();

        this.dungeonStartTime = timeService.getCurrentTime();
        this.timeLimit = sceneData.timeLimit > 0 ? dungeonStartTime
                + sceneData.timeLimit : Long.MAX_VALUE;

        if (sceneData.isRecordDamage){
            this.damageRecorder = new DamageRecorder();
            this.fightProcessor.registerHeroDamageListener(this);
        } else{
            this.damageRecorder = null;
        }
    }

    @Override
    @SelfThreadOnly
    public void addHero(AbstractHeroFightModule heroFightModule, long ctime,
            boolean isEnteringFirstScene){
        super.addHero(heroFightModule, ctime, isEnteringFirstScene);

        if (timeLimit != Long.MAX_VALUE){
            heroFightModule.sendMessage(ClusterClientMessages
                    .setDungeonEndTime(timeLimit));
        }

        if (damageRecorder != null){
            // 加入dps统计处理
            boolean isNew = damageRecorder.add(heroFightModule.getID(),
                    heroFightModule.getHero().getNameByteString());
            if (isNew){
                // 新来的, 广播给别人有新人进场景了
                broadcast(
                        ClusterClientMessages.dpsOtherAdded(
                                heroFightModule.getID(),
                                heroFightModule.getNameBytes()),
                        heroFightModule.getID());
            } else{
                broadcast(ClusterClientMessages.dpsOtherOnline(heroFightModule
                        .getID()), heroFightModule.getID());
            }
            // 发送给自己, 当前场景中已有的人和他们的dps

            heroFightModule.sendMessage(ClusterClientMessages
                    .dpsInit(damageRecorder.encode()));
        }
    }

    @Override
    @MultiThread
    protected void heroLeave(long heroID, boolean isOfflineAndNeedKeep){
        super.heroLeave(heroID, isOfflineAndNeedKeep);

        if (damageRecorder != null){
            // 加入dps统计处理
            if (isOfflineAndNeedKeep){
                // 还会再回来, 设为下线, 广播
                damageRecorder.setOffline(heroID);
                broadcast(ClusterClientMessages.dpsOtherOffline(heroID));
            } else{
                // 不回来了, 删除, 广播
                damageRecorder.remove(heroID);
                broadcast(ClusterClientMessages.dpsOtherLeave(heroID));
            }
        }
    }

    @Override
    public GroupDungeonSceneData getSceneData(){
        return sceneData;
    }

    protected long getDungeonStartTime(){
        return dungeonStartTime;
    }

    protected long getTimeLimit(){
        return timeLimit;
    }

    @Override
    public void onHeroDead(AbstractHeroFightModule heroFightModule){
        super.onHeroDead(heroFightModule);
        if (totalDeadCounter != null){
            totalDeadCounter.incrementAndGet();
        }
    }

    @Override
    public void onHeroMadeDamage(long heroID, int amount, long ctime){
        assert damageRecorder != null;

        if (damageRecorder != null){ // 防御
            if (amount > 0){
                damageRecorder.increment(heroID, amount, ctime);
            }
        }
    }

    protected void broadcastDungeonFinishedMsgToLocalScenes(){
        broadcastToAllLocalScene(ClusterSceneHeader.C2S.dungeonFinished(
                sceneUUID, getTotalDeadCount(), getDuration())); // 时间单位是秒
    }

    protected int getTotalDeadCount(){
        return totalDeadCounter.get();
    }

    protected int getDuration(){
        return (int) ((timeService.getCurrentTime() - dungeonStartTime) / 1000);
    }

    private long nextKickHeroesTime;

    @Override
    public void scheduledThreadUpdate(long ctime){
        if (damageRecorder != null){
            for (HeroInfo info : damageRecorder.getAll()){
                if (info.needBroadcast(ctime)){
                    broadcast(ClusterClientMessages.dpsUpdateDamage(
                            info.getID(), info.getDamage() / 1000));
                }
            }
        }

        if (ctime >= timeLimit){
            // 每隔几秒再踢一次
            if (ctime < nextKickHeroesTime){
                return;
            }
            nextKickHeroesTime = ctime + 5000;
            logger.debug("副本通关时间到: {}", sceneUUID);
            for (final AbstractHeroFightModule hfm : getAllHeroes()){
                hfm.getTaskExec().execute(new Runnable(){
                    @Override
                    public void run(){
                        hfm.doLeaveDungeonAndSendDungeonTimeUpMsg();
                    }
                });
            }
        }
    }

    @Override
    public boolean isLocalClusterScene(){
        return false;
    }
}
