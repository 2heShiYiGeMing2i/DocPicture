package app.cluster.combat.master.logic.scene;

import static app.cluster.client.combat.scene.PortalDungeonMessages.*;
import static com.mokylin.sink.util.BufferUtil.*;

import org.jboss.netty.buffer.ChannelBuffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.cluster.client.combat.scene.PortalDungeonMessages;
import app.cluster.shared.scene.ClusterSceneHeader;
import app.cluster.shared.scene.RemoteHeroFightModule;
import app.game.data.scene.PortalDungeonPortal;
import app.game.data.scene.PortalDungeonPortal.PortalType;
import app.game.data.scene.PortalDungeonSceneData;
import app.game.module.scene.AbstractHeroFightModule;
import app.game.module.scene.FightModule;
import app.game.module.scene.IDungeonService;
import app.game.module.scene.MonsterFightModule;
import app.message.ISender;
import app.utils.IDUtils;

import com.mokylin.collection.IntValueLongConcurrentHashMap;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.annotation.SelfThreadOnly;
import com.mokylin.sink.util.concurrent.PaddedAtomicBoolean;
import com.mokylin.sink.util.delay.DelayedEvent;

public class RemotePortalDungeonScene extends RemoteGroupDungeonScene{
    private static final Logger logger = LoggerFactory
            .getLogger(RemotePortalDungeonScene.class);

    private final PortalDungeonSceneData sceneData;

    private final PaddedAtomicBoolean finished;

    /**
     * 每个在副本内的英雄所在的层数. 供完成时, 把到第8层的设为完成. 层数从1开始
     *
     * 英雄切换层数后, 看下finished是否为true, 是则尝试给奖励. 给过不给
     * finished设为true后, 看下所有英雄所在的层数, 给所有在第8层的奖励
     * 不会有因为多线程而没给奖励的
     *
     * 英雄离线后不会删掉. 断线回来后, 如果副本完成了, 直接退出. 没完成, 那在原来的坐标, 也在原来的层数
     */
    private final IntValueLongConcurrentHashMap heroLevelMap;

    /**
     * 每一层生门所在的index
     */
    private final int[] portalRightPos;

    /**
     * 把每一层生门所在位置拼成一个int. 每一层有8种可能0-7, 3个bit. 共7层, 21bit
     */
    private final int doorIndexCombinedInt;

    /**
     * 使用过的传送门
     */
    private final boolean[] usedPortalArray;

    /**
     * 已完成副本的人id
     */
    private final IntValueLongConcurrentHashMap finishedHeroIDSet;

    public RemotePortalDungeonScene(PortalDungeonSceneData sceneData, int uuid,
            IDungeonService dungeonService, long creator, ISender worker){
        super(sceneData, uuid, dungeonService, creator, worker);

        this.sceneData = sceneData;
        this.finished = new PaddedAtomicBoolean(false);
        this.heroLevelMap = new IntValueLongConcurrentHashMap(8);
        this.finishedHeroIDSet = new IntValueLongConcurrentHashMap(8);

        this.usedPortalArray = new boolean[sceneData.getTotalPortalCount()];

        // 随机每个传送门的类型
        this.portalRightPos = sceneData.newRandomPortalPos();
        this.doorIndexCombinedInt = getDoorIndexCombinedInt(portalRightPos);
    }

    private static int getDoorIndexCombinedInt(int[] portalRightPos){
        int result = portalRightPos[0];
        for (int i = 1; i < portalRightPos.length; i++){
            result |= (portalRightPos[i] << (3 * i));
        }
        return result;
    }

    @Override
    @SelfThreadOnly
    public void addHero(AbstractHeroFightModule heroFightModule, long ctime,
            boolean isEnteringFirstScene){
        super.addHero(heroFightModule, ctime, isEnteringFirstScene);

        // 如果副本已经完成, 传出
        if (finished.get()){
            heroFightModule.doLeaveDungeon();
            return;
        }

        // 如果副本已经过期, 传出
        if (ctime >= getTimeLimit()){
            heroFightModule.doLeaveDungeonAndSendDungeonTimeUpMsg();
            return;
        }

        // 如果没有记录过其所在的level, 则设为第1层
        int heroLevel = heroLevelMap.get(heroFightModule.getID());
        if (heroLevel == -1){
            heroLevelMap.put(heroFightModule.getID(), 1);
            heroLevel = 1;
        }

        // 发送每个传送门的类型, 以及是否被踩过的状态
        heroFightModule.sendMessage(PortalDungeonMessages
                .init(doorIndexCombinedInt, getUsedDoor1(), getUsedDoor2(),
                        heroLevel));
    }

    @Override
    public PortalDungeonSceneData getSceneData(){
        return sceneData;
    }

    PortalType getPortalType(PortalDungeonPortal portal){
        return portal.getPortalType(portalRightPos[portal.level - 1]);
    }

    int getHeroLevel(long heroID){
        return heroLevelMap.get(heroID);
    }

    void setDoorUsed(int index){
        usedPortalArray[index] = true;
    }

    @Override
    public void onMonsterDead(MonsterFightModule dead, FightModule attacker,
            long ctime, long realDeadTime){
        final long eventTime = realDeadTime + 500; // 使用真正的死亡时间, 再加500毫秒, 作为处理的时间

        dungeonService.getDelayedEventService().addDelayedEvent(
                new DelayedEvent(){

                    @Override
                    public void handle(long ctime){
                        if (!finished.compareAndSet(false, true)){
                            logger.error("PortalDungeonScene已经完成, 但是又调用了onMonsterDead. 什么情况?");
                            return;
                        }

                        // 把当时在第8层中的英雄都设为已完成. 只有成功标记为完成的, 才把英雄的完成状态设为完成
                        for (AbstractHeroFightModule heroFightModule : positionModule
                                .getAllHeroObjects()){
                            if (heroLevelMap.get(heroFightModule.getID()) == PortalDungeonSceneData.LEVEL_COUNT){
                                tryFinishIfNotFinished(heroFightModule, ctime);
                            }
                        }
                    }

                    @Override
                    public long getEventTime(){
                        return eventTime;
                    }
                });
    }

    private void tryFinishIfNotFinished(
            AbstractHeroFightModule heroFightModule, long ctime){
        boolean added = finishedHeroIDSet.putIfAbsent(heroFightModule.getID(),
                1) == -1;
        if (added){
            ((RemoteHeroFightModule) heroFightModule).getWorker().sendMessage(
                    ClusterSceneHeader.C2S.portalHeroFinished(sceneUUID,
                            heroFightModule.getID(), getTotalDeadCount(),
                            getDuration()));
        }
    }

    void onHeroAtLevel(AbstractHeroFightModule heroFightModule, int currentLevel){
        heroLevelMap.put(heroFightModule.getID(), currentLevel);

        if (currentLevel == PortalDungeonSceneData.LEVEL_COUNT
                && finished.get()){
            // 如果已经完成了, 设为完成
            tryFinishIfNotFinished(heroFightModule,
                    timeService.getCurrentTime());
        }
    }

    private int getUsedDoor1(){
        int result = 0;
        for (int i = 0; i <= 27; i++){
            if (usedPortalArray[i]){
                result |= (1 << i);
            }
        }
        return result;
    }

    private int getUsedDoor2(){
        int result = 0;
        for (int i = 28; i <= 55; i++){
            if (usedPortalArray[i]){
                result |= (1 << (i - 28));
            }
        }
        return result;
    }

    /**
     * 处理来自游戏服, 让这个场景处理的消息
     * @param header
     * @param buffer
     * @param worker
     */
    // @NettyThread
    @Override
    public void onSceneMessage(ClusterSceneHeader header, ChannelBuffer buffer,
            final ISender worker){
        switch (header){
            case S2C_PORTAL_TRY_PORTAL:{
                onTryPortal(buffer);
                return;
            }

            default:{
                super.onSceneMessage(header, buffer, worker);
            }
        }
    }

    private static boolean canUsePortal(PortalDungeonPortal portal, int x, int y){
        return Utils.isInEasyRange(portal.sourceX, portal.sourceY, x, y, 2);
    }

    private void onTryPortal(ChannelBuffer buffer){
        final long heroID = readVarInt64(buffer);
        final int portalIndex = readVarInt32(buffer);

        dungeonService.getThreadService()
                .getExecutor(IDUtils.getUserID(heroID)).execute(new Runnable(){
                    @Override
                    public void run(){
                        AbstractHeroFightModule heroFightModule = positionModule
                                .getHero(heroID);
                        if (heroFightModule == null){
                            logger.warn("RemotePortalDungeonScene.onTryPortal时, 英雄不在场景中了");
                            return;
                        }

                        if (!heroFightModule.isAlive()){
                            heroFightModule
                                    .sendMessage(ERROR_TRANSPORT_DOOR_DEAD);
                            return;
                        }

                        if (heroFightModule.getFightData().isStunOrUnmovable()){
                            heroFightModule
                                    .sendMessage(ERROR_TRANSPORT_DOOR_STUN);
                            return;
                        }

                        if (heroFightModule.isJumping()){
                            heroFightModule
                                    .sendMessage(ERROR_TRANSPORT_DOOR_JUMPING);
                            return;
                        }

                        PortalDungeonPortal portal = sceneData
                                .getPortal(portalIndex);
                        if (portal == null){
                            logger.error("RemotePortalDungeonScene.onTryPortal时, 门的id没找到... 本地的场景已经检查了呀. 版本不对?");
                            heroFightModule
                                    .sendMessage(ERROR_TRANSPORT_ILLEGAL_ID);
                            return;
                        }

                        int x = heroFightModule.getX();
                        int y = heroFightModule.getY();
                        if (!canUsePortal(portal, x, y)){
                            heroFightModule
                                    .sendMessage(ERROR_TRANSPORT_TOO_FAR);
                            return;
                        }

                        int heroLevel = getHeroLevel(heroID);

                        if (heroLevel <= 0){
                            logger.error(
                                    "RemotePortalDungeonScene.onTryTransport时, 英雄所在的层数<=0: {}",
                                    heroLevel);
                            heroLevel = 1;
                        }

                        PortalType portalType = getPortalType(portal);
                        int newLevel = heroLevel + portalType.getLevelChange();
                        if (newLevel <= 0){
                            newLevel = 1;
                        }

                        setDoorUsed(portalIndex);
                        int targetPos = sceneData.getEnterPosByLevel(newLevel);

                        int newX = Utils.getHighShort(targetPos);
                        int newY = Utils.getLowShort(targetPos);

                        heroFightModule
                                .transportHeroAtSameSceneButDontSendAnyMsg(
                                        newX, newY);
                        onHeroAtLevel(heroFightModule, newLevel);

                        heroFightModule.sendMessage(transportSuccess);

                        broadcast(transportSuccessBroadcast(heroID,
                                heroFightModule.getNameBytes(), portalIndex,
                                newLevel, newX, newY));
                    }
                });
    }
}
