package app.cluster.combat.master.logic.scene;

import static com.mokylin.sink.util.BufferUtil.readVarInt64;

import java.util.Set;

import org.jboss.netty.buffer.ChannelBuffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.cluster.shared.scene.AbstractRemoteClusterScene;
import app.cluster.shared.scene.ClusterSceneHeader;
import app.game.data.scene.DungeonSceneData;
import app.game.module.scene.AbstractHeroFightModule;
import app.game.module.scene.IDungeonService;
import app.message.ISender;
import app.utils.IDUtils;
import app.utils.VariableConfig;

import com.mokylin.collection.LongArrayList;
import com.mokylin.sink.util.annotation.MultiThread;
import com.mokylin.sink.util.concurrent.DisruptorExecutor;

/**
 * 在远程服上真正处理逻辑的副本
 * @author Timmy
 *
 */
public class AbstractRemoteDungeon extends AbstractRemoteClusterScene{
    private static final Logger logger = LoggerFactory
            .getLogger(AbstractRemoteDungeon.class);

    private final DungeonSceneData sceneData;

    // --- 检测副本是否还存活 全都需要加锁才能访问 ---

    private boolean isAlive;

    /**
     * 没有英雄的过期时间
     */
    private volatile long noHeroKeepEndTime;

    /**
     * 能进入这个副本的人id. 包括在副本中下线的
     * 
     * 读写都必须先同步整个副本对象
     * 
     * 中间一定包括了所有在inDungeonCounter中的人
     */
    private final CombatCanEnterCounter canEnterCounter;

    /**
     * 从英雄开始markAboutEnter, 正在加载时, 就加入. 在离开时才删除. 这样不需要通过positionModule才能知道副本里还有多少人
     */
    private final CombatCanEnterCounter inDungeonCounter;

    protected AbstractRemoteDungeon(DungeonSceneData sceneData, int uuid,
            IDungeonService dungeonService, long creator, ISender worker){
        super(sceneData, uuid, dungeonService);

        this.sceneData = sceneData;

        this.canEnterCounter = new CombatCanEnterCounter();
        this.canEnterCounter.add(creator, worker);

        this.inDungeonCounter = new CombatCanEnterCounter();
        this.inDungeonCounter.add(creator, worker);

        this.isAlive = true;
        this.noHeroKeepEndTime = Long.MAX_VALUE;
    }

    @Override
    public int getCurrentLineNumber(){
        return 1;
    }

    @Override
    public boolean isLocalClusterScene(){
        return false;
    }

    @Override
    public DungeonSceneData getSceneData(){
        return sceneData;
    }

    @Override
    public void removeHero(AbstractHeroFightModule heroFightModule,
            boolean isOffline){
        super.removeHero(heroFightModule, isOffline);

        heroLeave(heroFightModule.getID(), isOffline);
    }

    @Override
    public void processServerDisconnected(DisruptorExecutor exec, ISender worker){
        LongArrayList heroIDsFromWorker;
        synchronized (this){
            if (!isAlive){
                return;
            }

            heroIDsFromWorker = canEnterCounter.getKeysSnapshot(worker);
        }

        // 如果有英雄来自这个worker的要加入, 一定是在断线event之前加入到exec的, 所以这个array中就是所有的了. 后面不会再有了
        for (int i = 0; i < heroIDsFromWorker.size(); i++){
            long id = heroIDsFromWorker.get(i);
            if (threadService.getExecutor(IDUtils.getUserID(id)) != exec){
                continue; // 这人不是这个exec负责的
            }

            // 是, 看下英雄是否在
            AbstractHeroFightModule hfm = positionModule.getHero(id);
            if (hfm != null){
                removeHero(hfm, false);
            } else{
                // 英雄不在场景中. 要么在加载, 要么是已经离线的
                synchronized (this){
                    canEnterCounter.remove(id);
                    inDungeonCounter.remove(id);

                    if (!canEnterCounter.hasCanEnter()){
                        // 全部删光了
                        isAlive = false; // 跳到同步块外面删除副本
                    } else{
                        if (!inDungeonCounter.hasCanEnter()){
                            // 能进的都是不在线的了, 如果没有设置副本结束时间, 则设置
                            if (noHeroKeepEndTime != Long.MAX_VALUE){
                                noHeroKeepEndTime = timeService
                                        .getCurrentTime()
                                        + VariableConfig.DUNGEON_OFFLINE_KEEP_TIME;
                            }
                        }

                        continue;
                    }
                }

                // 只有设置了isAlive=false才会跳到这里
                dungeonService.removeDungeon(sceneUUID);
                return;
            }
        }
    }

    /**
     * 处理来自游戏服, 让这个场景处理的消息
     * @param header
     * @param buffer
     * @param worker
     */
    // @NettyThread
    @Override
    public void onSceneMessage(ClusterSceneHeader header, ChannelBuffer buffer,
            final ISender worker){
        try{
            switch (header){
                case S2C_HERO_ABOUT_TO_COME:{
                    final long heroID = readVarInt64(buffer);
                    threadService.getExecutor(IDUtils.getUserID(heroID))
                            .execute(new Runnable(){
                                @Override
                                public void run(){
                                    markAboutEnter(heroID, worker);
                                }
                            });
                    return;
                }

                case S2C_HERO_OFFLINE_WHEN_LOADING:{
                    final long heroID = readVarInt64(buffer);
                    threadService.getExecutor(IDUtils.getUserID(heroID))
                            .execute(new Runnable(){
                                @Override
                                public void run(){
                                    markOfflineWhenLoading(heroID);
                                }
                            });
                    return;
                }

                default:{
                    super.onSceneMessage(header, buffer, worker);
                }
            }
        } catch (Throwable ex){
            logger.error("AbstractRemoteClusterDungeon.onSceneMessage出错. id: "
                    + header.ordinal() + ", header: " + header, ex);
        }
    }

    // --- 副本生命周期 ---
    /**
     * 返回是否还能进入这个副本. 可能正好过期. 如果返回true, 则不会再过期
     * @param heroID
     * @return
     */
    @MultiThread
    public boolean markAboutEnter(long heroID, ISender worker){
        synchronized (this){
            if (!isAlive){
                return false;
            }

            canEnterCounter.add(heroID, worker);
            inDungeonCounter.add(heroID, worker);

            if (noHeroKeepEndTime != Long.MAX_VALUE){
                noHeroKeepEndTime = Long.MAX_VALUE;
            }
            return true;
        }
    }

    @MultiThread
    public void markOfflineWhenLoading(long heroID){
        synchronized (this){
            assert isAlive;
            assert canEnterCounter.canHeroEnter(heroID);
            assert noHeroKeepEndTime == Long.MAX_VALUE;

            inDungeonCounter.remove(heroID);
            if (!inDungeonCounter.hasCanEnter()){
                // 副本里没人了

                noHeroKeepEndTime = timeService.getCurrentTime()
                        + VariableConfig.DUNGEON_OFFLINE_KEEP_TIME;
            }
        }
    }

    /**
     * 被调用前, 需要把英雄从positionModule中删除
     * @param heroID
     * @param isOfflineAndNeedKeep
     */
    @MultiThread
    protected void heroLeave(long heroID, boolean isOfflineAndNeedKeep){
        assert positionModule.getHero(heroID) == null;
        synchronized (this){
            if (!isAlive){
                // 为毛? 又不会过期
                logger.error("AbstractDungeonModule.heroLeave时, 副本已经!isAlive.");
                return;
            }

            assert canEnterCounter.canHeroEnter(heroID);

            inDungeonCounter.remove(heroID);
            if (isOfflineAndNeedKeep){
                // 下线
                if (!inDungeonCounter.hasCanEnter()){
                    // 没有在场景里的英雄了, 也没人正在加载
                    noHeroKeepEndTime = timeService.getCurrentTime()
                            + VariableConfig.DUNGEON_OFFLINE_KEEP_TIME;
                }
                return;
            }

            // 离开场景

            canEnterCounter.remove(heroID);
            if (!canEnterCounter.hasCanEnter()){
                // 场景已经再见了
                isAlive = false;
                // 跳到最后同步块外面删除场景
            } else{
                if (!inDungeonCounter.hasCanEnter()){
                    // 我是最后一个在场景的, 剩下的都已经离线了, 也没人正在加载要进入
                    noHeroKeepEndTime = timeService.getCurrentTime()
                            + VariableConfig.DUNGEON_OFFLINE_KEEP_TIME;
                }
                return;
            }
        }

        // 这里是需要从dungeonService中删除副本的
        dungeonService.removeDungeon(sceneUUID);
    }

    public void checkExpiration(long ctime){
        if (ctime >= noHeroKeepEndTime){
            doDestroyOnExpired();
            return;
        }
    }

    private void doDestroyOnExpired(){
        Set<ISender> workers;
        synchronized (this){
            if (!isAlive){
                // 为毛? 又不会因为有人离开副本被摧毁.
                // 同步块外面检测过期, 进入同步块前, 有人上线/离开副本, 导致被调用destroyOnEmpty? 开玩笑?
                logger.error("AbstractDungeonModule.destroyOnExpired时, 副本已经!isAlive.");
                return;
            }

            if (inDungeonCounter.hasCanEnter()){
                // 正好又有人进入了
                return;
            }
            isAlive = false;

            assert canEnterCounter.hasCanEnter(): "副本expire了, 但是canEnterCounter里竟然是空的, 为什么空的那一刻没有把副本销毁呢";

            // 发送消息给canEnterCounter中的每个服务器, 副本已经销毁了
            workers = canEnterCounter.getValueSetSnapshot();
            // 同步块外面发送也没有关系, isAlive已经是false了, 不会再有新的被添加到counter中
        }
        dungeonService.removeDungeon(sceneUUID);

        ChannelBuffer msg = ClusterSceneHeader.onlySendHeaderMessage(
                ClusterSceneHeader.C2S_SCENE_EXPIRED, sceneUUID);
        for (ISender w : workers){
            w.sendMessage(msg);
        }
    }

}
