package app.cluster.combat.master.logic.scene;

import java.util.HashSet;
import java.util.Set;

import app.message.ISender;

import com.mokylin.collection.LongArrayList;
import com.mokylin.collection.LongHashMap;
import com.mokylin.collection.LongHashMap.Entry;

public class CombatCanEnterCounter{

    private final LongHashMap<ISender> canEnterMap;

    CombatCanEnterCounter(){
        this.canEnterMap = new LongHashMap<>();
    }

    public void add(long heroID, ISender worker){
        canEnterMap.put(heroID, worker);
    }

    public void remove(long heroID){
        canEnterMap.remove(heroID);
    }

    public boolean hasCanEnter(){
        return canEnterMap.size() != 0;
    }

    public boolean canHeroEnter(long heroID){
        return canEnterMap.containsKey(heroID);
    }

    /**
     * 获取当前的values的快照. 之后两边毫不沾边, 两边的变化对另一边都没有影响
     * @return
     */
    public Set<ISender> getValueSetSnapshot(){
        Set<ISender> result = new HashSet<>(canEnterMap.values());
        return result;
    }

    /**
     * 获取当前的keys的快照. 之后两边毫不沾边, 两边的变化对另一边都没有影响
     * @return
     */
    public LongArrayList getKeysSnapshot(){
        LongArrayList result = new LongArrayList(canEnterMap.size());
        for (Entry<ISender> entry : canEnterMap.entrySet()){
            result.add(entry.getKey());
        }
        return result;
    }

    /**
     * 获取当前的所有value是这个worker的keys的快照. 之后两边毫不沾边, 两边的变化对另一边都没有影响
     * @return
     */
    public LongArrayList getKeysSnapshot(ISender worker){
        LongArrayList result = new LongArrayList();
        for (Entry<ISender> entry : canEnterMap.entrySet()){
            if (entry.getValue() == worker){
                result.add(entry.getKey());
            }
        }
        return result;
    }
}
