package app.cluster.combat.master.logic.scene;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.cluster.client.combat.scene.LingYunDungeonMessages;
import app.game.data.scene.LingYunDungeonSceneData;
import app.game.module.scene.AbstractHeroFightModule;
import app.game.module.scene.FightModule;
import app.game.module.scene.IDungeonService;
import app.game.module.scene.MonsterFightModule;
import app.message.ISender;
import app.utils.ClusterDungeonIDUtils;

import com.mokylin.sink.util.annotation.SelfThreadOnly;
import com.mokylin.sink.util.concurrent.PaddedAtomicBoolean;
import com.mokylin.sink.util.delay.DelayedEvent;

public class RemoteLingYunDungeonScene extends RemoteGroupDungeonScene{
    private static final Logger logger = LoggerFactory
            .getLogger(RemoteLingYunDungeonScene.class);

    private final LingYunDungeonSceneData sceneData;

    private final PaddedAtomicBoolean finished;

    private final int bossLevel;

    public RemoteLingYunDungeonScene(LingYunDungeonSceneData sceneData,
            int uuid, IDungeonService dungeonService, long creator,
            ISender worker){
        super(sceneData, uuid, dungeonService, creator, worker);

        this.sceneData = sceneData;
        this.finished = new PaddedAtomicBoolean(false);
        this.bossLevel = ClusterDungeonIDUtils.getDungeonAverageLevel(uuid); // uuid中encode进了队伍的平均等级
    }

    @Override
    public LingYunDungeonSceneData getSceneData(){
        return sceneData;
    }

    @Override
    @SelfThreadOnly
    public void addHero(AbstractHeroFightModule heroFightModule, long ctime,
            boolean isEnteringFirstScene){
        super.addHero(heroFightModule, ctime, isEnteringFirstScene);

        // 如果副本已经完成, 传出
        if (finished.get()){
            heroFightModule.doLeaveDungeon();
            return;
        }

        // 如果副本已经过期, 传出
        if (ctime >= getTimeLimit()){
            heroFightModule.doLeaveDungeonAndSendDungeonTimeUpMsg();
            return;
        }

        // 发送boss等级
        heroFightModule.sendMessage(LingYunDungeonMessages.setBossLevel(
                sceneData.bossSceneID, bossLevel));
    }

    public int getBossLevel(){
        // 怪物初始化的时候这里bossLevel还没有设置, 必须要这么计算获得
        return ClusterDungeonIDUtils.getDungeonAverageLevel(sceneUUID);
    }

    @Override
    public void onMonsterDead(MonsterFightModule dead, FightModule attacker,
            long ctime, long realDeadTime){
        super.onMonsterDead(dead, attacker, ctime, realDeadTime);

        // 看下死的是不是boss, 是的话副本完成
        if (!dead.isBoss()){
            return;
        }

        final long eventTime = realDeadTime + 500; // 使用真正的死亡时间, 再加500毫秒, 作为处理的时间

        dungeonService.getDelayedEventService().addDelayedEvent(
                new DelayedEvent(){

                    @Override
                    public void handle(long ctime){
                        if (!finished.compareAndSet(false, true)){
                            logger.error("凌云窟为什么onMonsterDead里boss死了2次?");
                            return;
                        }

                        broadcastDungeonFinishedMsgToLocalScenes();
                    }

                    @Override
                    public long getEventTime(){
                        return eventTime;
                    }
                });
    }
}
