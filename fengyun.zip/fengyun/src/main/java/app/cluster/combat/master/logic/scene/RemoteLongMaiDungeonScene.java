package app.cluster.combat.master.logic.scene;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.cluster.client.combat.scene.LongMaiDungeonMessages;
import app.game.data.scene.LongMaiBatchInfo;
import app.game.data.scene.LongMaiBatchInfo.LongMaiMonsterPosAndID;
import app.game.data.scene.LongMaiDungeonSceneData;
import app.game.module.scene.AbstractHeroFightModule;
import app.game.module.scene.AbstractMonsterFightModule;
import app.game.module.scene.IDungeonService;
import app.game.module.scene.IScheduledThreadUpdateDungeon;
import app.game.module.scene.LongMaiLongMaiFightModule;
import app.game.module.scene.LongMaiMonsterFightModule;
import app.message.ISender;
import app.utils.VariableConfig;

import com.mokylin.sink.util.annotation.SelfThreadOnly;
import com.mokylin.sink.util.concurrent.PaddedAtomicInteger;
import com.mokylin.sink.util.concurrent.PaddedAtomicReference;

public class RemoteLongMaiDungeonScene extends RemoteGroupDungeonScene
        implements IScheduledThreadUpdateDungeon{
    private static final Logger logger = LoggerFactory
            .getLogger(RemoteLongMaiDungeonScene.class);

    private final LongMaiDungeonSceneData sceneData;

    private final PaddedAtomicReference<LongMaiSceneStage> sceneStage;

    /**
     * 当前波
     */
    private LongMaiBatchInfo currentBatch;

    /**
     * 当前在这一波中的批次数
     */
    private int currentSpawn;

    /**
     * 下一波或者下一批次的怪物刷新时间
     */
    private long nextSpawnTime;

    /**
     * 开始刷第一波的时间, 用来给英雄进场景时, 发消息的
     */
    private final long startFirstSpawnTime;

    /**
     * 这一波是否都刷完了, 是的话, 就一直坐等monsterCounter到0
     */
    private boolean batchAllSpawned;

    /**
     * 场景中还存活着的怪物
     */
    private final PaddedAtomicInteger monsterCounter;

    public final LongMaiLongMaiFightModule longMai;

    public RemoteLongMaiDungeonScene(LongMaiDungeonSceneData sceneData,
            int uuid, IDungeonService dungeonService, long creator,
            ISender worker){
        super(sceneData, uuid, dungeonService, creator, worker);

        this.sceneData = sceneData;
        this.sceneStage = new PaddedAtomicReference<>(LongMaiSceneStage.INIT);
        this.monsterCounter = new PaddedAtomicInteger();

        this.currentBatch = sceneData.getBatch(0);
        long ctime = timeService.getCurrentTime();

        this.startFirstSpawnTime = ctime + VariableConfig.LONG_MAI_START_DELAY;
        logger.debug("守护龙脉副本即将开始, 倒数中");

        this.longMai = sceneData.newLongMai(this);
    }

    @Override
    public LongMaiDungeonSceneData getSceneData(){
        return sceneData;
    }

    @Override
    @SelfThreadOnly
    public void addHero(AbstractHeroFightModule heroFightModule, long ctime,
            boolean isEnteringFirstScene){
        super.addHero(heroFightModule, ctime, isEnteringFirstScene);

        // 如果已经结束, 传出
        if (ctime >= getTimeLimit()){
            heroFightModule.doLeaveDungeonAndSendDungeonTimeUpMsg();
            return;
        }

        // 根据当前副本状态
        LongMaiSceneStage stage = sceneStage.get();
        switch (stage){
            case INIT:{
                // 还没开始
                // 这里 startFirstSpawnTime一定已经设置好了
                heroFightModule.sendMessage(LongMaiDungeonMessages
                        .notifyStartTime(startFirstSpawnTime));
                // 发送第一波的信息
                heroFightModule.sendMessage(currentBatch.batchInfoMsg);

                longMai.doSendMeToHero(heroFightModule.getSender());
                return;
            }

            case NORMAL:{
                // 开始了, 发送当前波数的信息
                heroFightModule.sendMessage(currentBatch.batchInfoMsg);

                longMai.doSendMeToHero(heroFightModule.getSender());
                return;
            }

            case SUCCESS:
            case FAIL:
                // 已经结束了, 传出去
                heroFightModule.doLeaveDungeon();
                return;

            default:{
                logger.error("LongMaiSceneStage又加了?");
                return;
            }
        }
    }

    private static enum LongMaiSceneStage{
        /**
         * 刚初始化, 等人进来, 有人进来后, 设置时间, 等着update线程改成normal, 开始刷怪
         */
        INIT,
        /**
         * 正常刷怪阶段
         */
        NORMAL,
        /**
         * 失败, 龙脉挂了
         */
        FAIL,
        /**
         * 成功, 刷完了怪, 龙脉还在
         */
        SUCCESS;
    }

    @Override
    public void scheduledThreadUpdate(long ctime){
        // 由scheduledService统一更新逻辑
        super.scheduledThreadUpdate(ctime);

        LongMaiSceneStage stage = sceneStage.get();

        switch (stage){
            case INIT:{
                updateInit(ctime);
                return;
            }

            case NORMAL:{
                updateNormal(ctime);
                return;
            }
            default:{
                // 另外两个不需要update了
            }
        }
    }

    private void updateInit(long ctime){
        if (ctime >= startFirstSpawnTime){
            if (sceneStage.compareAndSet(LongMaiSceneStage.INIT,
                    LongMaiSceneStage.NORMAL)){
                logger.debug("守护龙脉副本开始");
            } else{
                logger.error(
                        "LongMaiDungeonScene.updateInit时, 竟然从init cas 到normal失败了. 当前: {}",
                        sceneStage.get());
            }
        }
    }

    private void updateNormal(long ctime){
        if (batchAllSpawned){
            // 如果刷完了这波
            if (monsterCounter.get() <= 0){
                // 怪都死完了
                if (currentBatch.nextBatch == null){
                    // 全部打完了
                    onDungeonFinished(ctime);
                    return;
                }

                nextSpawnTime = ctime
                        + VariableConfig.LONG_MAI_EACH_BATCH_DELAY;
                currentBatch = currentBatch.nextBatch;
                batchAllSpawned = false;
                currentSpawn = 0;
                broadcast(currentBatch.batchInfoMsg);
                logger.debug("守护龙脉开始刷怪. 第{}波", currentBatch.batch);
            }
            return;
        }

        if (ctime >= nextSpawnTime){
            // 要刷怪了
            LongMaiMonsterPosAndID[] mons = currentBatch.monsters[currentSpawn];
            ++currentSpawn;
            if (currentSpawn >= currentBatch.monsters.length){
                batchAllSpawned = true;
            } else{
                nextSpawnTime = ctime
                        + VariableConfig.LONG_MAI_EACH_SPAWN_DELAY;
            }

            // 刷怪
            monsterCounter.addAndGet(mons.length); // 先加数量
            for (LongMaiMonsterPosAndID mon : mons){
                AbstractMonsterFightModule m = mon.newMonster(this);
                fightProcessor.addNonRelivableMonster(m, ctime);
            }
            return;
        }
    }

    private void onDungeonFinished(long ctime){
        if (!sceneStage.compareAndSet(LongMaiSceneStage.NORMAL,
                LongMaiSceneStage.SUCCESS)){
            logger.error(
                    "LongMaiDungeonScene.onDungeonFinished调用 cas normal 到 success 失败, 当前stage: {}",
                    sceneStage.get());
            return;
        }

        logger.debug("守护龙脉副本完成");
        broadcastDungeonFinishedMsgToLocalScenes();
    }

    public void onLongMaiMonsterDead(LongMaiMonsterFightModule mon, long ctime){
        positionModule.remove(mon);

        monsterCounter.decrementAndGet(); // 到0不在这里处理, 在updateNormal里检测
    }

    public void onLongMaiDead(long ctime){
        logger.debug("守护龙脉副本, 龙脉挂了");
        if (!sceneStage.compareAndSet(LongMaiSceneStage.NORMAL,
                LongMaiSceneStage.FAIL)){
            logger.error("守护龙脉要从 normal cas 到fail失败. 当前状态: {}",
                    sceneStage.get());
            return;
        }

        // 失败了. 这里有可能调到失败的同时, 刷新线程还在往场景里加怪
        broadcast(LongMaiDungeonMessages.dungeonFail);
    }

    public boolean inNormalStage(){
        return sceneStage.get() == LongMaiSceneStage.NORMAL;
    }

}
