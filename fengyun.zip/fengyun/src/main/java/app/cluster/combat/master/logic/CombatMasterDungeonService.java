package app.cluster.combat.master.logic;

import static com.mokylin.sink.util.BufferUtil.*;

import java.util.Collection;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;

import org.jboss.netty.buffer.ChannelBuffer;
import org.joda.time.DateTimeConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.cluster.combat.master.CombatMasterWorkers;
import app.cluster.combat.master.logic.scene.AbstractRemoteDungeon;
import app.cluster.protobuf.CombatContent.EnteringHeroProto;
import app.cluster.shared.scene.AbstractRemoteClusterScene;
import app.cluster.shared.scene.ClusterSceneHeader;
import app.cluster.shared.scene.CombatHeader;
import app.cluster.shared.scene.ProxySender;
import app.cluster.shared.scene.RemoteHeroFightModule;
import app.game.data.ConfigService;
import app.game.data.Race;
import app.game.data.scene.ClusterDungeonSceneData;
import app.game.data.scene.SceneData;
import app.game.entity.Hero;
import app.game.entity.User;
import app.game.module.ViewOtherHeroMessages;
import app.game.module.guild.RemoteGuild;
import app.game.module.guild.RemoteGuildMember;
import app.game.module.scene.IDungeonService;
import app.game.module.scene.IScheduledThreadUpdateDungeon;
import app.game.module.scene.OneThreadJob;
import app.game.service.DelayedEventService;
import app.game.service.IThreadService;
import app.game.service.SelfThreadExecuteService;
import app.game.service.TimeService;
import app.game.service.WorldData;
import app.message.ISender;
import app.protobuf.HeroServerContent.HeroServerProto;
import app.protobuf.HeroServerContent.RaceId;
import app.utils.IDUtils;
import app.utils.VariableConfig;

import com.google.inject.Inject;
import com.mokylin.collection.IntHashMap;
import com.mokylin.collection.IntSynchronizedHashMap;
import com.mokylin.collection.ReusableIterator;
import com.mokylin.sink.util.BufferUtil;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.concurrent.DisruptorExecutor;

/**
 * 负责管理所有开着的副本
 * @author Timmy
 *
 */
public class CombatMasterDungeonService implements IDungeonService{
    private static final Logger logger = LoggerFactory
            .getLogger(CombatMasterDungeonService.class);

    private final IThreadService threadService;

    private final TimeService timeService;

    private final DelayedEventService delayedEventService;

    private final ConfigService configService;

    private final WorldData worldData;

    private final VariableConfig variableConfig;

    private final SelfThreadExecuteService selfThreadExecuteService;

    private final IntSynchronizedHashMap<AbstractRemoteDungeon> dungeonUUIDMap;

    private final IntHashMap<ClusterDungeonSceneData> clusterSceneDatas;

    private final DisruptorExecutor[] taskExecArray;

    private final CombatMasterWorkers combatMasterWorkers;

    @Inject
    CombatMasterDungeonService(IThreadService threadSerivce,
            TimeService timeService, DelayedEventService delayedEventService,
            ConfigService configService, WorldData worldData,
            VariableConfig variableConfig,
            SelfThreadExecuteService selfThreadExecuteService,
            CombatMasterWorkers combatMasterWorkers){
        this.threadService = threadSerivce;
        this.taskExecArray = threadSerivce.getExecutorsArrayCopy();
        this.timeService = timeService;
        this.delayedEventService = delayedEventService;
        this.configService = configService;
        this.worldData = worldData;
        this.variableConfig = variableConfig;
        this.selfThreadExecuteService = selfThreadExecuteService;
        this.combatMasterWorkers = combatMasterWorkers;

        this.dungeonUUIDMap = new IntSynchronizedHashMap<>();
        this.clusterSceneDatas = new IntHashMap<>();

        for (SceneData sceneData : configService.getScenes().getAll()){
            if (sceneData instanceof ClusterDungeonSceneData){
                clusterSceneDatas.put(sceneData.id,
                        (ClusterDungeonSceneData) sceneData);
            }
        }

        setUpdate();
    }

    private void setUpdate(){
        // 更新worldData里的时间
        threadService.getScheduledExecutorService().scheduleAtFixedRate(
                new Runnable(){
                    @Override
                    public void run(){
                        try{
                            worldData.updateDailyStatisticsTime();
                        } catch (Throwable ex){
                            logger.error("每天凌晨更新worldData里的时间出错...", ex);
                        }
                    }
                },
                Utils.calculateMillisToMidnight(timeService.getCurrentTime()),
                DateTimeConstants.MILLIS_PER_DAY, TimeUnit.MILLISECONDS);

        // 检测副本过期
        threadService.getScheduledExecutorService().scheduleAtFixedRate(
                new Runnable(){

                    private final ReusableIterator<AbstractRemoteDungeon> ite = dungeonUUIDMap.reusableValueIterator();

                    @Override
                    public void run(){
                        try{
                            long ctime = timeService.getCurrentTime();
                            AbstractRemoteDungeon scene;
                            for (ite.rewind(); ite.hasNext();){
                                scene = ite.next();

                                scene.checkExpiration(ctime);
                            }
                            ite.cleanUp();
                        } catch (Throwable ex){
                            logger.error(
                                    "CombatMasterDungeonService 检测副本是否过期出错", ex);
                        }
                    }
                }, 5, 5, TimeUnit.SECONDS);

        // 刷新视野
        threadService.getScheduledExecutorService().scheduleAtFixedRate(
                new Runnable(){
                    private final ReusableIterator<AbstractRemoteDungeon> ite = dungeonUUIDMap.reusableValueIterator();

                    private final Executor dbExec = threadService
                            .getDbExecutor();

                    @Override
                    public void run(){
                        try{
                            AbstractRemoteDungeon scene;
                            for (ite.rewind(); ite.hasNext();){
                                scene = ite.next();

                                tryExecuteOneThreadJob(dbExec, scene
                                        .getFightProcessor()
                                        .getRefreshViewJob());
                            }
                        } catch (Throwable ex){
                            logger.error("CombatMasterDungeonService 刷新场景出错",
                                    ex);
                        }
                    }
                }, 1000, 600, TimeUnit.MILLISECONDS);

        // 刷新怪物
        threadService.getScheduledExecutorService().scheduleAtFixedRate(
                new Runnable(){
                    private final Executor dbExec = threadService
                            .getDbExecutor();

                    private final ReusableIterator<AbstractRemoteDungeon> ite = dungeonUUIDMap
                            .reusableValueIterator();

                    @Override
                    public void run(){
                        try{
                            long ctime = timeService.getCurrentTime();
                            AbstractRemoteDungeon scene;
                            for (ite.rewind(); ite.hasNext();){
                                scene = ite.next();

                                tryExecuteOneThreadJob(dbExec, scene
                                        .getFightProcessor()
                                        .getRefreshSceneAndMonsterJob());

                                if (scene instanceof IScheduledThreadUpdateDungeon){
                                    try{
                                        ((IScheduledThreadUpdateDungeon) scene)
                                                .scheduledThreadUpdate(ctime);
                                    } catch (Throwable ex){
                                        logger.error(
                                                "CombatMasterDungeonService.scheduleThreadUpdate副本时出错",
                                                ex);
                                    }
                                }
                            }
                            ite.cleanUp();
                        } catch (Throwable ex){
                            logger.error("CombatMasterDungoenService 刷新怪物出错",
                                    ex);
                        }
                    }
                }, 100, VariableConfig.SCENE_MONSTER_UPDATE_INTERVAL,
                TimeUnit.MILLISECONDS);
    }

    private static void tryExecuteOneThreadJob(Executor exec, OneThreadJob job){
        if (job.tryCAS()){
            exec.execute(job);
        }
    }

    public Collection<AbstractRemoteDungeon> getAllDungeons(){
        return dungeonUUIDMap.values();
    }

    @Override
    public VariableConfig getVariableConfig(){
        return variableConfig;
    }

    @Override
    public WorldData getWorldData(){
        return worldData;
    }

    @Override
    public IThreadService getThreadService(){
        return threadService;
    }

    @Override
    public TimeService getTimeService(){
        return timeService;
    }

    @Override
    public DelayedEventService getDelayedEventService(){
        return delayedEventService;
    }

    @Override
    public ConfigService getConfigService(){
        return configService;
    }

    @Override
    public void removeDungeon(int uuid){
        logger.debug("删除副本 {}", uuid);
        boolean removed = dungeonUUIDMap.remove(uuid) != null;
        if (!removed){
            logger.error(
                    "CombatMasterDungeonService.removeDungeon时, 并没有删除掉副本: {}",
                    uuid);
        }
    }

    public void processServerDisconnected(final ISender worker){
        for (final DisruptorExecutor exec : taskExecArray){
            exec.execute(new Runnable(){
                @Override
                public void run(){
                    for (AbstractRemoteClusterScene scene : dungeonUUIDMap
                            .values()){
                        scene.processServerDisconnected(exec, worker);
                    }
                }
            });
        }
    }

    // --- 处理来自游戏服的消息 ---

    public void onSceneMessage(ChannelBuffer buffer, ISender worker){
        int msgId = BufferUtil.readVarInt32(buffer);
        ClusterSceneHeader header = ClusterSceneHeader.getHeaderByID(msgId);
        if (header == null){
            logger.error("收到未知的ClusterSceneHeader: {}", msgId);
            return;
        }

        int sceneID = BufferUtil.readVarInt32(buffer);
        AbstractRemoteClusterScene scene = dungeonUUIDMap.get(sceneID);
        if (scene == null){
            logger.debug("收到SceneMessage: {}-{}, 但场景不存在: {}", msgId, header,
                    sceneID);
            return;
        }

        logger.debug("收到ClusterSceneHeader消息: {}", header);

        scene.onSceneMessage(header, buffer, worker);
    }

    /**
     * 英雄要进入场景
     * @param buffer
     * @param combatMasterWorker
     */
    public void onHeroNewEnter(ChannelBuffer buffer, ISender worker){
        final long heroID = readVarInt64(buffer);
        final int uuid = readVarInt32(buffer);
        final int dungeonID = readVarInt32(buffer);

        final ClusterDungeonSceneData sceneData = clusterSceneDatas
                .get(dungeonID);
        if (sceneData == null){
            logger.error(
                    "CombatMasterDungeonService.onHeroNewEnter时, 收到的副本id不存在: {}. 版本不对? 发错了id? heroid: {}",
                    dungeonID, heroID);
            worker.sendMessage(ClusterSceneHeader
                    .onlySendHeadAndAVarInt64Message(
                            ClusterSceneHeader.C2S_HERO_LEAVE, uuid, heroID));
            return;
        }

        final AbstractRemoteDungeon dungeon = getOrCreateSceneAndMarkedAboutEnter(
                uuid, sceneData, heroID, worker);
        assert dungeon != null;

        heroDoEnter(buffer, heroID, worker, dungeon, false);
    }

    public void onHeroOfflineReenter(ChannelBuffer buffer, ISender worker){
        final long heroID = readVarInt64(buffer);
        final int uuid = readVarInt32(buffer);
        readVarInt32(buffer); // skip dungeon ID

        AbstractRemoteDungeon dungeon = dungeonUUIDMap.get(uuid);
        if (dungeon == null || !dungeon.markAboutEnter(heroID, worker)){
            logger.warn(
                    "CombatMasterDungeonService.onHeroOfflineReenter时, 场景已经不存在. uuid: {} heroid: {}",
                    uuid, heroID);
            worker.sendMessage(ClusterSceneHeader
                    .onlySendHeadAndAVarInt64Message(
                            ClusterSceneHeader.C2S_HERO_LEAVE, uuid, heroID));
            return;
        }

        heroDoEnter(buffer, heroID, worker, dungeon, true);
    }

    private void heroDoEnter(ChannelBuffer buffer, long heroID, ISender worker,
            final AbstractRemoteClusterScene dungeon,
            final boolean isEnteringFirstScene){
        byte[] heroNameBytes = readUTFBytes(buffer);
        int viewRangeX = readVarInt32(buffer);
        int viewRangeY = readVarInt32(buffer);
        try{
            EnteringHeroProto proto = readProto(
                    EnteringHeroProto.getDefaultInstance(), buffer,
                    User.extensionRegistry);

            HeroServerProto heroProto = proto.getHero();
            final long ctime = timeService.getCurrentTime();
            Hero hero = Hero.decodeWithoutMinorData(heroID, heroNameBytes,
                    heroProto, ctime, configService);
            DisruptorExecutor exec = threadService.getExecutor(IDUtils
                    .getUserID(heroID));

            RemoteGuild guild = proto.hasGuild() ? new RemoteGuild(heroID,
                    proto.getGuild(), configService) : null;
            RemoteGuildMember guildMember = new RemoteGuildMember(heroID, guild);

            final RemoteHeroFightModule heroFightModule = new RemoteHeroFightModule(
                    hero, new ProxySender(worker, heroID,
                            dungeon.getSceneUUID()), guildMember, dungeon,
                    exec, selfThreadExecuteService.getRelatedObject(exec),
                    ctime, worker);
            heroFightModule.setViewRange(viewRangeX, viewRangeY);
            heroFightModule.setParentRange(dungeon.getSceneData());

            exec.execute(new Runnable(){
                @Override
                public void run(){
                    try{
                        dungeon.addHero(heroFightModule, ctime,
                                isEnteringFirstScene);
                    } catch (Throwable ex){
                        logger.error(
                                "CombatMasterDungeonService.heroDoEnter dungeon.addHero出错",
                                ex);
                    }
                }
            });
        } catch (Throwable ex){
            logger.error("CombatMasterDungeonService.heroDoEnter解析英雄时出错", ex);
        }
    }

    /**
     * 获得以前的场景, 或者新建个场景. 返回的一定不为null, 且已经markAboutEnter了, 不会过期
     * @param uuid
     * @param sceneData
     * @param heroID
     * @param worker
     * @return
     */
    private AbstractRemoteDungeon getOrCreateSceneAndMarkedAboutEnter(int uuid,
            ClusterDungeonSceneData sceneData, long heroID, ISender worker){
        AbstractRemoteDungeon scene = dungeonUUIDMap.get(uuid);
        if (scene == null){
            AbstractRemoteDungeon newScene = sceneData.newRemoteClusterScene(
                    uuid, this, heroID, worker);
            scene = dungeonUUIDMap.putIfAbsent(uuid, newScene);
            if (scene == null){
                // 新创建的, 已经在canEnterCounter里了
                return newScene;
            } else{
                logger.error("CombatMasterDungeonService.getOrCreateSceneAndMarkedAboutEnter时, 创建副本时putIfAbsent失败了, 这么巧同时创建了?");
            }
        }
        assert scene != null;

        if (!scene.markAboutEnter(heroID, worker)){
            logger.error("CombatMasterDungeonService.getOrCreateSceneAndMarkedAboutEnter时, 获得的场景markAboutEnter失败... 这么巧? 如果一直看到, 就是dungeonMap里有个isAlive=false的副本一直没有被删除. 这里已经死循环了");
            return getOrCreateSceneAndMarkedAboutEnter(uuid, sceneData, heroID,
                    worker);
        }

        return scene;
    }

    public void onViewHero(ChannelBuffer buffer, ISender worker){
        int sceneUUID = readVarInt32(buffer);
        long askerID = readVarInt64(buffer);
        long targetID = readVarInt64(buffer);

        // 所有的观察都交给真正的游戏服
        AbstractRemoteDungeon scene = dungeonUUIDMap.get(sceneUUID);
        if (scene != null){
            // 这里只是提示下被观察的人, 有人在观察他
            RemoteHeroFightModule hfm = scene.getHero(targetID);
            if (hfm != null){
                // 看下提问者是男是女
                RemoteHeroFightModule asker = scene.getHero(askerID);
                if (asker != null){
                    Race race = asker.getHero().getRace();
                    final boolean isMale = race.getRaceId() == RaceId.BU_JING_YUN
                            || race.getRaceId() == RaceId.NIE_FENG; // 是不是男人

                    if (isMale){
                        hfm.sendMessage(ViewOtherHeroMessages.beenViewedByMale);
                    } else{
                        hfm.sendMessage(ViewOtherHeroMessages.beenViewedByFemale);
                    }
                }
            }
        }

        // 这里要么场景没找到, 要么英雄不在场景里
        // 找到这个id应该所在的CombatMasterWorker, 如果没找到, proxy给提问者, 要找的人服务器维护中
        ISender targetServer = combatMasterWorkers.get(IDUtils
                .getCombinedServerAndOperatorID(targetID));
        if (targetServer == null){
            logger.warn(
                    "收到观察请求, 但是请求的人所在的服务器并没有在这台combat上. 运营商id: {}, 服务器id: {}",
                    IDUtils.getOperatorID(targetID),
                    IDUtils.getServerID(targetID));
            // 没找到, 转发给提问者
            int moduleID = ViewOtherHeroMessages.MODULE_ID;
            int sequenceID = ViewOtherHeroMessages.S2C_VIEW_OTHER_HERO_FAIL;
            int errID = 3; // 表示对方服务器维护中

            int len = computeVarInt32Size(moduleID)
                    + computeVarInt32Size(sequenceID)
                    + computeVarInt32Size(errID);

            ChannelBuffer msg = CombatHeader.proxyMsgFixSize(askerID, len);
            writeVarInt32(msg, moduleID);
            writeVarInt32(msg, sequenceID);
            writeVarInt32(msg, errID);
            worker.sendMessage(msg);
            return;
        }

        logger.debug("收到观察请求, 把请求转发给目标所在的服务器");
        // 找到了, 把请求发给target所在的服务器
        targetServer.sendMessage(CombatHeader.otherServerViewYourHero(askerID,
                targetID));
    }
}
