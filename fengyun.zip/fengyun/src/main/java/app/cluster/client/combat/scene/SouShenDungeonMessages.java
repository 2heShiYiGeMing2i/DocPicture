package app.cluster.client.combat.scene;

import java.util.Collection;

import org.jboss.netty.buffer.ChannelBuffer;
import static com.mokylin.sink.util.BufferUtil.*;

import app.game.entity.GoodsBoughtEntry;
import app.game.module.Modules;

public class SouShenDungeonMessages{

    public static final int MODULE_ID = Modules.SOU_SHEN_DUNGEON_MODULE_ID;

    // --- 搜神值改变 ---

    /**
     * 改变搜神值, 将英雄有的搜神值设为消息中附带的值
     * 
     * 附带
     * 
     * varint32 最新的搜神值 (不是改变量)
     */
    static final int S2C_SET_SOU_SHEN_POINT = 1;

    // --- 可领取boss奖励 ---

    /**
     * boss死了一个, 开始随机这个boss的奖励. 找到config.proto中这个boss每种奖励可能随出来的数值
     * 随个3秒, 发送领取奖励C2S_COLLECT_BOSS_PRIZE消息, 之后会回复S2C_COLLECT_BOSS_PRIZE_SUCCESS真正随机奖励
     * 收到S2C_COLLECT_BOSS_PRIZE_SUCCESS后, 将随机的奖励停在消息中附带的数值上
     * 
     * 右侧boss追踪处, 把boss设为已死
     * 
     * 附带
     * 
     * varint64 死掉的boss的场景id
     */
    static final int S2C_START_RANDOM_BOSS_PRIZE = 2;

    /**
     * 要求领取boss奖励, 必须等待服务器返回
     * 
     * 附带
     * 
     * varint64 要领取奖励的boss场景id
     */
    static final int C2S_COLLECT_BOSS_PRIZE = 1;

    /**
     * 领取失败, 附带varint32 错误码. 收到后, 如果正在随机奖励, 则不显示随机面板
     * 
     * 1. 你不能领这个奖励. 要么领过了, 要么这个boss死的时候你不在副本中
     * 2. 你不在搜神宫副本中
     */
    static final int S2C_COLLECT_BOSS_PRIZE_FAIL = 3;
    static final ChannelBuffer ERROR_COLLECT_BOSS_PRIZE_NOT_COLLECTABLE = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_COLLECT_BOSS_PRIZE_FAIL, 1);
    static final ChannelBuffer ERROR_COLLECT_BOSS_PRIZE_NOT_IN_SUO_SHEN_DUNGEON = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_COLLECT_BOSS_PRIZE_FAIL, 2);

    /**
     * 领取成功, 附带每个奖励随机到的数值. 具体加奖励会另外发送消息. 这条消息只供停止随机用
     * 
     * 附带
     * 
     * varint32 随到的经验
     * varint32 真气
     * varint32 银两
     * varint32 搜神值
     */
    static final int S2C_COLLECT_BOSS_PRIZE_SUCCESS = 4;

    // --- 领取副本通关奖励 ---

    /**
     * 副本通关. 什么都不做, 马上发送C2S_COLLECT_DUNGEON_PRIZE
     * 
     * 没有附带信息
     */
    static final int S2C_DUNGEON_FINISHED = 5;
    static final ChannelBuffer dungeonFinished = onlySendHeaderMessage(
            MODULE_ID, S2C_DUNGEON_FINISHED);

    /**
     * 尝试领取首通奖励, 如果有的话. 
     * 紧接着会收到S2C_COLLECT_DUNGEON_PRIZE_SUCCESS
     * 不用加锁
     * 
     * 没有附带信息
     */
    static final int C2S_COLLECT_DUNGEON_PRIZE = 2;

    /**
     * 收到后, 展示 挑战成功. 并根据消息中附带的奖励类型, 展示本次通关获得的奖励
     * 如果没有奖励则只显示挑战成功.
     * 真正加物品消息会单独发送
     * 
     * 附带
     * 
     * byte 奖励类型 0: 无奖励, 1: 获得了每日首通奖励 (将英雄今日设为已通), 2: 获得了角色首次通关奖励 (将英雄设为已通, 且今日也已通) (具体的奖励在config.proto中, 根据当前所在的副本)
     */
    static final int S2C_COLLECT_DUNGEON_PRIZE_SUCCESS = 6;
    static final ChannelBuffer collectDailyFirstPassPrizeNoPrize = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_COLLECT_DUNGEON_PRIZE_SUCCESS, 0);
    static final ChannelBuffer collectDailyFirstPassPrizeDailyFirstPrize = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_COLLECT_DUNGEON_PRIZE_SUCCESS, 1);
    static final ChannelBuffer collectDailyFirstPassPrizeLifeFirstPrize = onlySendHeadAndAByteMessage(
            MODULE_ID, S2C_COLLECT_DUNGEON_PRIZE_SUCCESS, 2);

    // --- 获取兑换数据 ---

    /**
     * 英雄本次登录第一次打开搜神宫商店时, 请求今天已购买的物品数量和已兑换了的搜神宫点数
     * 每次登录只能请求一次, 请求完后保存在客户端
     * 
     * 必须等待服务器返回
     * 
     * 没有附带信息
     */
    static final int C2S_GET_SHOP_INFO = 3;

    /**
     * 请求失败, 附带varint32 错误码
     * 
     * 1. 已经请求过了, 客户端bug
     */
    static final int S2C_GET_SHOP_INFO_FAIL = 8;
    static final ChannelBuffer ERROR_GET_SHOP_INFO_ALREADY_REQUESTED = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_GET_SHOP_INFO_FAIL, 1);

    /**
     * 返回搜神宫商店有关数据
     * 
     * 附带
     * 
     * varint32 今日已兑换的搜神宫点数
     * varint32 每日最多可使用的搜神宫点数
     * while (byteArray.available){
     *   // 下面是今天已兑换过的物品, 里面没有提到的物品, 今日兑换量=0
     *  varint32 物品在商店中的id (不是物品id)
     *  varint32 今日这件物品已兑换的数量
     * }
     */
    static final int S2C_GET_SHOP_INFO_SUCCESS = 9;

    // --- 兑换物品 ---

    /**
     * 兑换搜神宫商店里的物品. 客户端需要检查搜神宫点数是否足够, 今日兑换数量有否超出, 今日已使用的点数有否超支
     * 
     * 必须等待服务器返回
     * 
     * 附带
     * 
     * varint32 物品在搜神宫中的id(不是物品id)
     */
    static final int C2S_BUY_GOODS = 4;

    /**
     * 购买失败, 附带varint32 错误码
     * 
     * 1. 你要买的物品id没找到, 客户端bug
     * 2. 搜神宫点数不够
     * 3. 今日已使用点数超支
     * 4. 背包不够
     * 5. 今日已兑换数量到上限
     */
    static final int S2C_BUY_GOODS_FAIL = 10;
    static final ChannelBuffer ERROR_BUY_GOODS_ID_NOT_FOUND = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_BUY_GOODS_FAIL, 1);
    static final ChannelBuffer ERROR_BUY_GOODS_CANNOT_AFFORD = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_BUY_GOODS_FAIL, 2);
    static final ChannelBuffer ERROR_BUY_GOODS_TODAY_SOU_SHEN_POINT_LIMIT_REACHED = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_BUY_GOODS_FAIL, 3);
    static final ChannelBuffer ERROR_BUY_GOODS_DEPOT_FULL = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_BUY_GOODS_FAIL, 4);
    static final ChannelBuffer ERROR_BUY_GOODS_TODAY_GOODS_BUY_LIMIT_REACHED = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_BUY_GOODS_FAIL, 5);

    /**
     * 物品购买成功, 飞动画. 另外会发送添加物品消息
     * 将这件物品今日已兑换个数+1
     * 
     * 附带
     * 
     * varint32 最新今日已使用的搜神点数
     */
    static final int S2C_BUY_GOODS_SUCCESS = 11;

    // --- 具体消息构建 ---

    static ChannelBuffer buyGoodsSuccess(int newUsedPoint){
        return onlySendHeadAndAVarInt32Message(MODULE_ID,
                S2C_BUY_GOODS_SUCCESS, newUsedPoint);
    }

    static ChannelBuffer getShopInfoSuccess(int todayUsedPoint,
            int dailyMaxPoint, Collection<GoodsBoughtEntry> entries){
        ChannelBuffer buffer = newDynamicMessage(MODULE_ID,
                S2C_GET_SHOP_INFO_SUCCESS);
        writeVarInt32(buffer, todayUsedPoint);
        writeVarInt32(buffer, dailyMaxPoint);
        for (GoodsBoughtEntry entry : entries){
            writeVarInt32(buffer, entry.id);
            writeVarInt32(buffer, entry.count);
        }
        return buffer;
    }

    static ChannelBuffer collectBossPrizeSuccess(int exp, int realAir,
            int money, int souShenPoint){
        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID,
                S2C_COLLECT_BOSS_PRIZE_SUCCESS, computeVarInt32Size(exp)
                        + computeVarInt32Size(realAir)
                        + computeVarInt32Size(money)
                        + computeVarInt32Size(souShenPoint));
        writeVarInt32(buffer, exp);
        writeVarInt32(buffer, realAir);
        writeVarInt32(buffer, money);
        writeVarInt32(buffer, souShenPoint);
        return buffer;
    }

    static ChannelBuffer startRandomBossPrize(long bossSceneID){
        return onlySendHeadAndAVarInt64Message(MODULE_ID,
                S2C_START_RANDOM_BOSS_PRIZE, bossSceneID);
    }

    public static ChannelBuffer setSouShenPoint(int newPoint){
        return onlySendHeadAndAVarInt32Message(MODULE_ID,
                S2C_SET_SOU_SHEN_POINT, newPoint);
    }
}
