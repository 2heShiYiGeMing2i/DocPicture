package app.cluster.client.combat.scene;

import java.util.Collection;

import org.jboss.netty.buffer.ChannelBuffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.cluster.client.combat.ClusterClientCombatServerContainer;
import app.cluster.shared.scene.ClusterSceneHeader;
import app.game.data.ConfigService;
import app.game.data.scene.ClusterDungeonSceneData;
import app.game.module.GoodsContainerModule;
import app.game.module.MailModule;
import app.game.module.scene.IClusterLocalDungeonService;
import app.game.service.DelayedEventService;
import app.game.service.IThreadService;
import app.game.service.TimeService;
import app.game.service.WorldData;
import app.game.service.WorldService;
import app.message.ISender;
import app.utils.VariableConfig;

import com.google.inject.Inject;
import com.mokylin.collection.IntSynchronizedHashMap;
import com.mokylin.sink.util.BufferUtil;

/**
 * 放着所有跨服场景
 * @author Timmy
 *
 */
public class ClusterDungeonService implements IClusterLocalDungeonService{
    private static final Logger logger = LoggerFactory
            .getLogger(ClusterDungeonService.class);

    private final IntSynchronizedHashMap<LocalDungeonScene> dungeonUUIDMap;

    private final ConfigService configService;

    private final VariableConfig variableConfig;

    private final WorldData worldData;

    private final IThreadService threadService;

    private final TimeService timeService;

    private final DelayedEventService delayedEventService;

    private final WorldService worldService;

    private final MailModule mailModule;

    private final GoodsContainerModule goodsContainerModule;

    private final ClusterClientCombatServerContainer combatClientContainer;

    @Inject
    ClusterDungeonService(ConfigService configService,
            VariableConfig variableConfig, WorldData worldData,
            IThreadService threadService, TimeService timeService,
            DelayedEventService delayedEventService, WorldService worldService,
            MailModule mailModule, GoodsContainerModule goodsContainerModule,
            ClusterClientCombatServerContainer combatClientContainer){
        this.dungeonUUIDMap = new IntSynchronizedHashMap<>();

        this.goodsContainerModule = goodsContainerModule;
        this.mailModule = mailModule;
        this.configService = configService;
        this.variableConfig = variableConfig;
        this.worldData = worldData;
        this.threadService = threadService;
        this.timeService = timeService;
        this.worldService = worldService;
        this.delayedEventService = delayedEventService;
        this.combatClientContainer = combatClientContainer;
    }

    public int getDungeonCount(){
        return dungeonUUIDMap.size();
    }

    public Collection<LocalDungeonScene> getAll(){
        return dungeonUUIDMap.values();
    }

    public ISender getCombatClient(long combatServerID){
        return combatClientContainer.getCombatServer(combatServerID);
    }

    @Override
    public GoodsContainerModule getGoodsContainerModule(){
        return goodsContainerModule;
    }

    @Override
    public MailModule getMailModule(){
        return mailModule;
    }

    @Override
    public WorldService getWorldService(){
        return worldService;
    }

    @Override
    public ConfigService getConfigService(){
        return configService;
    }

    @Override
    public VariableConfig getVariableConfig(){
        return variableConfig;
    }

    @Override
    public WorldData getWorldData(){
        return worldData;
    }

    @Override
    public IThreadService getThreadService(){
        return threadService;
    }

    @Override
    public TimeService getTimeService(){
        return timeService;
    }

    @Override
    public DelayedEventService getDelayedEventService(){
        return delayedEventService;
    }

    @Override
    public void removeDungeon(int uuid){
        logger.debug("删除跨服副本: {}", uuid);
        boolean removed = dungeonUUIDMap.remove(uuid) != null;
        if (!removed){
            logger.error(
                    "ClusterDungeonService.removeDungeon时, 要移除的副本不存在. 这下出大事了, map中多了个要删除的副本, 可能导致别人无法markAboutEnter, 最后死循环. id: ",
                    uuid);
        }
    }

    public LocalDungeonScene getExisting(int uuid){
        return dungeonUUIDMap.get(uuid);
    }

    /**
     * 这里直接就会调用markAboutEnter. 所以外部有任何意外, 都需要调用对应的离开方法
     * @param clusterSceneData
     * @param uuid
     * @param heroID
     * @return
     */
    public LocalDungeonScene getOrCreateNew(
            ClusterDungeonSceneData clusterSceneData, int uuid, long heroID,
            ISender combatClient){
        LocalDungeonScene existing = dungeonUUIDMap.get(uuid);
        if (existing != null){
            if (existing.markAboutEnter(heroID)){
                return existing;
            } else{
                logger.warn("ClusterDungeonService.getOrCreateNew时, map里得到以前就有的副本, 但是markAboutEnter失败了, 这么巧?");
            }
        }

        LocalDungeonScene result = clusterSceneData.newLocalClusterScene(uuid,
                this, combatClient, heroID);

        existing = dungeonUUIDMap.putIfAbsent(uuid, result);

        if (existing != null){
            logger.warn("ClusterDungeonService.getOrCreateNew时, putIfAbsent失败, 这么巧? 递归重新获取, 如果重复出现这句log, 就是map中有isAlive=false的dungeon没有删除");
            return getOrCreateNew(clusterSceneData, uuid, heroID, combatClient); // 递归, 重新来次 (如果map中有isAlive = false的, 就死循环了)
        } else{
            // 新建成功, 且也放到map中了, 发送消息, 并返回
            result.sendHeroEnteringOnDungeonCreated(heroID);
            return result;
        }
    }

    public void onSceneMessage(ChannelBuffer buffer){
        int msgId = BufferUtil.readVarInt32(buffer);
        ClusterSceneHeader header = ClusterSceneHeader.getHeaderByID(msgId);
        if (header == null){
            logger.error("收到未知的ClusterSceneHeader: {}", msgId);
            return;
        }

        int sceneID = BufferUtil.readVarInt32(buffer);
        LocalDungeonScene scene = dungeonUUIDMap.get(sceneID);
        if (scene == null){
            logger.debug(
                    "ClusterDungeonService收到SceneMessage: {}-{}, 但场景已经不存在了: {}",
                    msgId, header, sceneID);
            return;
        }

        logger.debug("ClusterDungeonService收到ClusterSceneHeader消息: {}", header);

        scene.onSceneMessage(header, buffer);
    }
}
