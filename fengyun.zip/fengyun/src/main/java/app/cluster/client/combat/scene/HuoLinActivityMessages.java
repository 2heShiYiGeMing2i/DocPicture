package app.cluster.client.combat.scene;

import static com.mokylin.sink.util.BufferUtil.*;

import java.util.Collection;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.module.Modules;

import com.mokylin.sink.util.holder.LongLongHolder;

public class HuoLinActivityMessages{

    public static final int MODULE_ID = Modules.HUO_LIN_ACTIVITY_MODULE_ID;

    // --- 请求进入活动 ---

    /**
     * 请求进入火麟洞活动
     * 
     * 客户端需要检查:
     * 
     *  只有在活动时间内才能发送
     *  当前必须在普通场景内, 不能在切场景, 不能在副本
     *  等级必须足够
     * 
     * 必须等待服务器返回
     *  
     * 没有附带信息
     */
    static final int C2S_REQUEST_ENTRY = 1;

    /**
     * 进入失败, 附带varint32 错误码
     * 
     * 1. 等级不够
     * 2. 不在活动时间
     * 3. 你不在普通场景
     * 4. 与活动服务器断开连接, 稍后再试
     * 5. 暂时无法进入, 稍后再试
     * 6. 请求太频繁
     * 7. 已经花钱完成了
     */
    static final int S2C_REQUEST_ENTRY_FAIL = 1;
    static final ChannelBuffer ERROR_REQUEST_ENTRY_NOT_ENOUGH_LEVEL = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_REQUEST_ENTRY_FAIL, 1);
    static final ChannelBuffer ERROR_REQUEST_ENTRY_NOT_RIGHT_TIME = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_REQUEST_ENTRY_FAIL, 2);
    static final ChannelBuffer ERROR_REQUEST_ENTRY_NOT_IN_NORMAL = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_REQUEST_ENTRY_FAIL, 3);
    static final ChannelBuffer ERROR_REQUEST_ENTRY_MASTER_DISCONNECTED = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_REQUEST_ENTRY_FAIL, 4);
    static final ChannelBuffer ERROR_REQUEST_ENTRY_NO_COMBAT_SERVER_OR_COMBAT_SERVER_NOT_FOUND = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_REQUEST_ENTRY_FAIL, 5);
    static final ChannelBuffer ERROR_REQUEST_ENTRY_TOO_FREQUENT = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_REQUEST_ENTRY_FAIL, 6);
    static final ChannelBuffer ERROR_REQUEST_ENTRY_PAYBACK = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_REQUEST_ENTRY_FAIL, 7);

    /**
     * 进入成功, 解锁
     * 
     * 紧接着会收到切场景消息.
     * 
     * 附带
     * 
     * varint32 即将进入的火麟洞场景的线数. (断线不会重新自动重进火麟洞, 线数在这里告知客户端, 客户端自己保存)
     */
    static final int S2C_REQUEST_ENTRY_SUCCESS = 2;

    // --- 当次活动累计获得的经验和真气 ---

    /**
     * 服务器推送当次活动累计获得的经验和真气
     * 
     * 可能刚进入场景就收到. 有变化时会推送
     * 在刚进场景, 还没收到时, 累计获得的都显示为0
     * 
     * 附带
     * 
     * varint32 累计获得的经验
     * varint32 累计获得的真气
     */
    static final int S2C_SET_ACCUMULATED_EXP_AND_REAL_AIR = 3;

    // --- 副本剩余时间 & 下个boss刷新时间 ---

    /**
     * 英雄刚进入场景时发送, 让客户端显示副本结束时间和下次刷新boss时间
     * 
     * 附带
     * 
     * varint64 副本结束时间点. (时间到了服务器会主动让玩家退出场景)
     * varint64 副本创建时间
     * varint32 Boss数据长度
     * bytes Boss数据（拿到这个数据要先解压，解析后面有说明）
     * while(byteArray.available)
     *     varint64 BossID（在场景中的那个）
     *     varint64 Boss死亡时间
     *     
     * 客户端根据Boss死亡时间，自己计算出Boss数据
     */
    static final int S2C_SET_END_TIME_AND_NEXT_BOSS_TIME = 4;

//    /**
//     * 设置下一个boss的刷新时间
//     * 
//     * 附带
//     * 
//     * varint64 下一个boss的刷新时间点 (0表示本次活动不会再刷boss了) (倒数到0就不要再数了)
//     */
//    static final int S2C_SET_NEXT_BOSS_TIME = 5;

    /**
     * Boss被击杀
     * 
     * 附带
     * 
     * varint64 BossID（在场景中的那个）
     * varint64 Boss死亡时间
     * 
     * 客户端更新Boss的状态
     */
    static final int S2C_BOSS_BEEN_KILLED = 6;

    // --- 具体消息构建 ---

    public static ChannelBuffer bossBeenKilled(long monsterID, long bossDeadTime){
        return onlySendHeadAnd2VarInt64Message(MODULE_ID, S2C_BOSS_BEEN_KILLED,
                monsterID, bossDeadTime);
    }

//    public static ChannelBuffer setNextBossTime(long bossTime){
//        return onlySendHeadAndAVarInt64Message(MODULE_ID,
//                S2C_SET_NEXT_BOSS_TIME, bossTime);
//    }

    public static ChannelBuffer setEndTimeAndNextBossTime(byte[] cacheData,
            Collection<LongLongHolder> bossKilledTimes){
        ChannelBuffer buffer = newDynamicMessage(MODULE_ID,
                S2C_SET_END_TIME_AND_NEXT_BOSS_TIME, cacheData.length + 40);
        buffer.writeBytes(cacheData);

        for (LongLongHolder holder : bossKilledTimes){
            long v = holder.getValue();
            if (v > 0){
                writeVarInt64(buffer, holder.getKey());
                writeVarInt64(buffer, v);
            }
        }

        return buffer;
    }

//    public static ChannelBuffer setEndTimeAndNextBossTime(long endTime,
//            long nextBossTime){
//        return onlySendHeadAnd2VarInt64Message(MODULE_ID,
//                S2C_SET_END_TIME_AND_NEXT_BOSS_TIME, endTime, nextBossTime);
//    }

    static ChannelBuffer setAccumulatedExpAndRealAir(int exp, int realAir){
        return onlySendHeadAnd2VarInt32Message(MODULE_ID,
                S2C_SET_ACCUMULATED_EXP_AND_REAL_AIR, exp, realAir);
    }

    static ChannelBuffer requestEntrySuccess(int line){
        return onlySendHeadAndAVarInt32Message(MODULE_ID,
                S2C_REQUEST_ENTRY_SUCCESS, line);
    }
}
