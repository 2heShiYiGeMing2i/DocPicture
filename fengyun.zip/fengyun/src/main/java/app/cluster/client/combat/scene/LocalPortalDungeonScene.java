package app.cluster.client.combat.scene;

import static com.mokylin.sink.util.BufferUtil.*;

import org.jboss.netty.buffer.ChannelBuffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mokylin.sink.util.annotation.SelfThreadOnly;

import app.cluster.shared.scene.ClusterSceneHeader;
import app.game.data.scene.PortalDungeonSceneData;
import app.game.module.scene.AbstractHeroFightModule;
import app.game.module.scene.HeroFightModule;
import app.game.module.scene.IClusterLocalDungeonService;
import app.message.ISender;
import app.protobuf.ConfigContent.ShengWangType;

public class LocalPortalDungeonScene extends LocalGroupDungeonScene{
    private static final Logger logger = LoggerFactory
            .getLogger(LocalPortalDungeonScene.class);

    private final PortalDungeonSceneData sceneData;

    public LocalPortalDungeonScene(PortalDungeonSceneData sceneData, int uuid,
            IClusterLocalDungeonService dungeonService, ISender combatClient,
            long heroID){
        super(sceneData, uuid, dungeonService, combatClient, heroID);

        this.sceneData = sceneData;
    }

    @Override
    public PortalDungeonSceneData getSceneData(){
        return sceneData;
    }

    @Override
    @SelfThreadOnly
    public void addHero(AbstractHeroFightModule heroFightModule, long ctime,
            boolean isEnteringFirstScene){
        super.addHero(heroFightModule, ctime, isEnteringFirstScene);

        if (hasDisconnected){
            // 上层已经把他传出副本了
            return;
        }

        if (heroFightModule instanceof HeroFightModule){
            ((HeroFightModule) heroFightModule).getHeroMiscModule()
                    .tryCompleteShengWangTask(ShengWangType.SW_WU_JUE, true, 1);
        } else{
            logger.error("无绝神阵副本本地场景中的居然不是 HeroFightModule");
        }
    }

    @Override
    protected void onFinished(int deadCount, int totalDuration){
        throw new UnsupportedOperationException();
    }

    // --- 处理Combat服过来的消息 ---

    /**
     * 处理来自Combat服发送给这个场景, 让这个场景处理的消息
     * @param header
     * @param buffer
     * @param client
     */
    @Override
    public void onSceneMessage(ClusterSceneHeader header, ChannelBuffer buffer){
        switch (header){
            case C2S_PORTAL_HERO_FINISHED:{
                onPortalHeroFinished(buffer);
                return;
            }

            default:{
                super.onSceneMessage(header, buffer);
            }
        }
    }

    private void onPortalHeroFinished(ChannelBuffer buffer){
        final long heroID = readVarInt64(buffer);
        final int deadCount = readVarInt32(buffer);
        final int duration = readVarInt32(buffer);

        final HeroFightModule hfm = getHero(heroID);
        if (hfm == null){
            logger.warn("LocalPortalDungeonScene.onPortalHeroFinished时, 没有找到完成了副本的英雄. 正好退出了?");
            return;
        }

        hfm.getTaskExec().execute(new Runnable(){
            @Override
            public void run(){
                if (!hfm.isInScene(LocalPortalDungeonScene.this)){
                    // 离开场景了
                    logger.warn("LocalPortalDungeonScene.onPortHeroFinished时, 在英雄线程中时, 英雄已经不在场景了");
                    return;
                }

                boolean added = onDungeonFinishStartGiveDungeonPrize(hfm,
                        getCurrentTime(), deadCount, duration);
                if (added){
                    int newTimes = hfm.getHero().addWuJueTodayEnteredTimes();
                    hfm.sendMessage(PortalDungeonMessages
                            .setEnteredTimes(newTimes));
                } else{
                    logger.error("LocalPortalDungeonScene.onPortalHeroFinished时, 英雄已经完成过这个副本了...");
                }
            }
        });
    }
}
