package app.cluster.client.combat.scene;

import static app.cluster.client.combat.scene.PortalDungeonMessages.*;

import org.jboss.netty.buffer.ChannelBuffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.cluster.shared.scene.ClusterSceneHeader;
import app.game.data.scene.PortalDungeonPortal;
import app.game.data.scene.PortalDungeonSceneData;
import app.game.data.scene.PortalDungeonSceneDatas;
import app.game.module.HeroController;
import app.game.module.scene.HeroFightModule;
import app.game.module.scene.IScene;

import com.google.inject.Inject;
import com.mokylin.sink.util.BufferUtil;

public class PortalDungeonModule{
    private static final Logger logger = LoggerFactory
            .getLogger(PortalDungeonModule.class);

    private final PortalDungeonSceneData sceneData;

    @Inject
    PortalDungeonModule(PortalDungeonSceneDatas sceneDatas){
        this.sceneData = sceneDatas.getSceneData();
    }

    public void onMessage(int sequenceID, ChannelBuffer buffer,
            HeroController hc, HeroFightModule heroFightModule){
        switch (sequenceID){
            case C2S_TRY_TRANSPORT:{
                onTryTransport(buffer, hc, heroFightModule);
                return;
            }

            default:{
                logger.warn("PortalDungeonModule收到位置的消息id: {}", sequenceID);
            }
        }
    }

    private void onTryTransport(ChannelBuffer buffer, HeroController hc,
            HeroFightModule heroFightModule){
        if (!heroFightModule.isAlive()){
            hc.sendMessage(ERROR_TRANSPORT_DOOR_DEAD);
            return;
        }

        if (heroFightModule.getFightData().isStunOrUnmovable()){
            hc.sendMessage(ERROR_TRANSPORT_DOOR_STUN);
            return;
        }

        if (heroFightModule.isJumping()){
            hc.sendMessage(ERROR_TRANSPORT_DOOR_JUMPING);
            return;
        }

        if (!heroFightModule.isInAndEnteredDungeon()){
            hc.sendMessage(ERROR_TRANSPORT_DOOR_NOT_IN_PORTAL);
            return;
        }

        IScene parent = heroFightModule.getParent();
        if (!(parent instanceof LocalPortalDungeonScene)){
            hc.sendMessage(ERROR_TRANSPORT_DOOR_NOT_IN_PORTAL);
            return;
        }

        LocalPortalDungeonScene portalParent = (LocalPortalDungeonScene) parent;

        int doorIndex = BufferUtil.readVarInt32(buffer);
        PortalDungeonPortal portal = sceneData.getPortal(doorIndex);
        if (portal == null){
            hc.sendMessage(ERROR_TRANSPORT_ILLEGAL_ID);
            return;
        }

        // 发送消息给远程场景, 成功失败都由Combat服proxy给玩家
        portalParent.sendToRemoteScene(ClusterSceneHeader.S2C.portalTryPortal(
                portalParent.getUUID(), heroFightModule.getID(), doorIndex));
    }

}
