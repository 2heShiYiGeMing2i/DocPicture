package app.cluster.client;

import com.mokylin.sink.server.Worker;

/**
 * 监听来自GroupMaster的消息
 * @author Timmy
 *
 */
public interface IGroupClientListener extends Worker{

}
