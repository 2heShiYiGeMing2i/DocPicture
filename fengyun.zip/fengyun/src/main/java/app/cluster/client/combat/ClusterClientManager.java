package app.cluster.client.combat;

import static com.google.common.base.Preconditions.checkNotNull;
import static com.mokylin.sink.util.BufferUtil.*;

import java.io.Closeable;
import java.util.ArrayList;
import java.util.List;

import org.jboss.netty.buffer.BigEndianHeapChannelBuffer;
import org.jboss.netty.buffer.ChannelBuffer;
import org.jboss.netty.channel.Channel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.cluster.client.GroupClient;
import app.cluster.client.IGroupClientListener;
import app.cluster.client.combat.scene.HuoLinActivityModule;
import app.cluster.client.combat.scene.IGlobalActivityModule;
import app.cluster.client.logic.team.ClusterClientTeamModule;
import app.cluster.combat.discovery.ICombatServerListener;
import app.cluster.combat.master.CombatMasterServerInfo;
import app.cluster.group.codec.GroupHeader;
import app.cluster.shared.scene.CombatHeader;
import app.game.data.ServerData;
import app.game.data.scene.HuoLinActivitySceneData;
import app.game.data.scene.HuoLinActivitySceneDatas;
import app.game.module.ConnectedUser;
import app.game.module.Modules;
import app.utils.IndividualServerConfig;
import app.utils.Operators;

import com.google.inject.Inject;
import com.mokylin.collection.IntHashMap;
import com.mokylin.collection.LongConcurrentSynchronizedHashMap;
import com.mokylin.sink.client.ReconnectNettyClient;
import com.mokylin.sink.client.ReconnectNettyClientSharedResources;
import com.mokylin.sink.util.StringEncoder;
import com.mokylin.sink.util.Utils;

/**
 * 各种服的信息. master信息, 连接. Combat服, 连接
 * @author Timmy
 *
 */
public class ClusterClientManager implements ICombatServerListener, Closeable,
        IGroupClientListener{
    private static final Logger logger = LoggerFactory
            .getLogger(ClusterClientManager.class);

    /**
     * 到master的消息管道
     */
    private final GroupClient groupMasterClient;

    private final ReconnectNettyClientSharedResources nettyRes;

    private final ClusterService clusterService;

    private final ClusterClientTeamModule clusterClientTeamModule;

    private final ClusterClientCombatServerContainer combatServerContainer;

    /**
     * 用来向每个combat服注册的消息 S2C_HELLO_COMBAT, 里面附带自己的区服信息
     */
    private final ChannelBuffer registerCombatMsg;

    /**
     * 仅供这个类的onCombatServerAdded和onCombatServerRemoved使用
     *
     * CombatContainer中仅保存已经connected的combat服. 有可能发现combat服从zookeeper中删除时,
     * 还未connect, 或者之前connect了, 但disconnect了, onCombatServerRemoved时, container中并没有, 无法关闭
     */
    private final LongConcurrentSynchronizedHashMap<CombatClient> combatServers;

    /**
     * 全区服活动的处理模块
     */
    private final IntHashMap<IGlobalActivityModule> globalActivityModuleBySceneDataID;

    private final boolean IS_DEBUG;

    /**
     * 自己的运营商
     *
     * 正常一个服应该只有一个运营商. 如果是测试服, 则所有的都认为是同一个运营商. 反正连的也是独立的zookeeper
     */
    private final Operators selfOperator;

    @Inject
    ClusterClientManager(GroupClient groupMasterClient,
            ReconnectNettyClientSharedResources nettyRes,
            ClusterService clusterService,
            ClusterClientTeamModule clusterClientTeamService,
            ClusterClientCombatServerContainer combatServerContainer,
            IndividualServerConfig individualServerConfig,
            HuoLinActivitySceneDatas huoLinSceneDatas,
            HuoLinActivityModule huoLinActivityModule){
        this.groupMasterClient = groupMasterClient;
        this.nettyRes = nettyRes;
        this.clusterService = clusterService;
        this.clusterClientTeamModule = clusterClientTeamService;
        this.combatServerContainer = combatServerContainer;

        this.combatServers = new LongConcurrentSynchronizedHashMap<>();
        this.globalActivityModuleBySceneDataID = new IntHashMap<>();

        // 火麟洞的id
        for (HuoLinActivitySceneData sceneData : huoLinSceneDatas.getAll()){
            globalActivityModuleBySceneDataID.putUnique(sceneData.id,
                    huoLinActivityModule);
        }

        this.selfOperator = Operators.valueOf(individualServerConfig
                .getDefaultOperatorID());
        checkNotNull(selfOperator, "找不到本服所属的运营商: {}",
                individualServerConfig.getDefaultOperatorID());

        this.IS_DEBUG = individualServerConfig.isDebug();

        // 初始化注册消息
        List<byte[]> serverStringRepresentation = new ArrayList<>();

        for (ServerData serverData : individualServerConfig.getServerDatas()){
            serverStringRepresentation.add(StringEncoder
                    .encode(serverData.stringRepresentation));
        }

        int len = 0;
        for (byte[] b : serverStringRepresentation){
            len += 2;
            len += b.length;
        }
        registerCombatMsg = CombatHeader.newFixedSizeMessage(
                CombatHeader.S2C_HELLO_COMBAT, len);
        for (byte[] b : serverStringRepresentation){
            writeUTF(registerCombatMsg, b);
        }
    }

    @Override
    public void close(){
        // 先关CombatServerDiscovery, 再调用这个close, 不然关了到CombatServer的连接, 那边可能同时又发现了新的CombatServer
        // 这里不关master, master由ClusterClient关
        // 只关到CombatServer的连接
        Utils.closeQuietly(combatServerContainer);
    }

    // --- CombatServer ---
    @Override
    public void onCombatServerAdded(CombatMasterServerInfo server){
        logger.info("发现新的Combat服务器: {}", server);
        CombatClient client = new CombatClient(server, nettyRes,
                clusterService, combatServerContainer, registerCombatMsg,
                IS_DEBUG);
        client.start(); // 这里只启动, 连上时会加入到container中

        CombatClient oldClient = combatServers.put(server.id, client);
        if (oldClient != null){
            logger.error(
                    "ClusterClientManager.onCombatServerAdded时, Combat服务器竟然已经存在. 关闭: {}",
                    server);
            oldClient.close();
        }
    }

    @Override
    public void onCombatServerRemoved(CombatMasterServerInfo server){
        // 把所有人踢出场景, 在CombatClient.onDisconnect处理
        logger.info("发现Combat服务器移除了: {}", server);
        CombatClient client = combatServers.remove(server.id);
        if (client != null){
            Utils.closeQuietly(client);
        } else{
            logger.error(
                    "ClusterClient.onCombatServerRemoved时, 没有找到这个id的CombatServer: {}",
                    server);
        }
    }

    @Override
    public void onCombatServerUpdated(CombatMasterServerInfo server){
        // 无视
    }

    // --- group master handler ---

    /**
     * 发消息给master
     * @param buffer
     * @return 是否发送成功. 就算返回true, 也有可能会失败. 返回false, 一定发送失败
     */
    public boolean sendToMaster(ChannelBuffer buffer){
        return groupMasterClient.sendMessage(buffer);
    }

    /**
     * 与master连接建立
     */
    @Override
    public void onConnected(){
        logger.info("与master连接已建立");
        sendToMaster(GroupHeader.onlySendHeadAndAVarInt32Message(
                GroupHeader.S2M_HELLO_MASTER, selfOperator.operatorID));
    }

    /**
     * 与master的连接断开
     */
    @Override
    public void onDisconnect(){
        logger.error("与master的连接断开");
        clusterClientTeamModule.processMasterDisconnected();
    }

    /**
     * 收到master发来的消息
     */
    @Override
    public void onMessage(ChannelBuffer buffer){
        int msgId = readVarInt32(buffer);

        GroupHeader header = GroupHeader.getHeaderByID(msgId);
        if (header == null){
            logger.error("ClusterClientManager收到来自master的未知消息: {}", msgId);
            // 有bug，断掉连接
            ReconnectNettyClient c = groupMasterClient.getNettyClient();
            if (c != null){
                Channel ch = c.getChannel();
                if (ch != null){
                    ch.close();
                }
            }
            return;
        }

        logger.debug("收到来自master的消息: {}. 消息长度: {} bytes", header,
                buffer.readableBytes());

        switch (header){
            case M2S_BROADCAST_SCENE_TEAM_LIST:{
                clusterClientTeamModule
                        .processMasterBroadcastSceneTeamList(buffer);
                return;
            }

            case M2S_PROXY_MSG:{
                onProxyMsg(buffer);
                return;
            }

            case M2S_JOIN_GROUP_FAIL:{
                clusterClientTeamModule.processJoinGroupFail(buffer);
                return;
            }

            case M2S_AUTO_JOIN_FAIL:{
                clusterClientTeamModule.processAutoJoinGroupFail(buffer);
                return;
            }

            case M2S_BEEN_KICKED:{
                clusterClientTeamModule.processBeenKick(buffer);
                return;
            }

            case M2S_START_BROADCAST:{
                clusterClientTeamModule.processStartBroadcast(buffer);
                return;
            }

            case M2S_GET_GLOBAL_ACTIVITY_DESTINATION_FAIL_NO_COMBAT_SERVER:{
                int sceneDataID = readVarInt32(buffer);
                IGlobalActivityModule module = globalActivityModuleBySceneDataID
                        .get(sceneDataID);
                if (module == null){
                    logger.error(
                            "ClusterClientManager.M2S_GET_GLOBAL_ACTIVITY_DESTINATION_FAIL_NO_COMBAT_SERVER时, 没有找到sceneDataID的处理模块. 没有放入处理map?: {}",
                            sceneDataID);
                    return;
                }
                long heroID = readVarInt64(buffer);
                module.processGetGlobalActivityDestinationFailNoCombatServer(
                        sceneDataID, heroID);
                return;
            }

            case M2S_REPLY_GLOBAL_ACTIVITY_DESTINATION:{
                int sceneDataID = readVarInt32(buffer);

                IGlobalActivityModule module = globalActivityModuleBySceneDataID
                        .get(sceneDataID);
                if (module == null){
                    logger.error(
                            "ClusterClientManager.M2S_REPLY_GLOBAL_ACTIVITY_DESTINATION时, 没有找到sceneDataID的处理模块. 没有放入处理map?: {}",
                            sceneDataID);
                    return;
                }

                long heroID = readVarInt64(buffer);
                int uuid = readVarInt32(buffer);
                int line = readVarInt32(buffer);
                long combatServerID = readVarInt64(buffer);
                module.processReplyGlobalActivityDestination(sceneDataID,
                        heroID, uuid, line, combatServerID);
                return;
            }

            case M2S_REPLY_YOUR_GROUP:{
                long heroID = readVarInt64(buffer);
                int dungeonID = readVarInt32(buffer);
                int teamID = readVarInt32(buffer);
                int requiredFightAmount = readVarInt32(buffer);

                clusterClientTeamModule.processReplyDisplayTeamInvite(heroID,
                        dungeonID, teamID, requiredFightAmount);
                return;
            }

            case M2S_REPLY_YOUR_GROUP_FAIL:{
                long heroID = readVarInt64(buffer);
                int errCode = readVarInt32(buffer);

                clusterClientTeamModule.processReplyDisplayTeamInviteFail(
                        heroID, errCode);
                return;
            }

            default:{
                logger.error(
                        "ClusterClientManager收到来自master的消息: {}-{}, 但没有处理逻辑",
                        msgId, header);
            }
        }
    }

    /**
     * 转发master发来的消息给玩家
     * @param buffer
     */
    private void onProxyMsg(ChannelBuffer buffer){
        long heroID = readVarInt64(buffer);
        ConnectedUser cu = clusterService.getWorldService().getUser(heroID);
        if (cu == null){
            // 英雄已经下线了
            logger.debug("ClusterClientManager.onProxyMsg时, 要转发的英雄不在线: {}",
                    heroID);
            return;
        }

        if (IS_DEBUG){
            buffer.markReaderIndex();
            int moduleID = readVarInt32(buffer);
            int sequenceID = readVarInt32(buffer);
            buffer.resetReaderIndex();

            String msgName = Modules.getS2CMsgName(moduleID, sequenceID);
            if (msgName != null){
                logger.debug("master服要proxy消息给玩家: {}", msgName); // TODO
                                                                 // Modules.getModuleName
                                                                 // 需要读取hashmap,
                                                                 // 有点点消耗
            }
        }
        ChannelBuffer newMsg = new BigEndianHeapChannelBuffer(
                buffer.readableBytes() + 2);
        newMsg.writeShort(0);
        newMsg.writeBytes(buffer);
        cu.getSender().sendMessage(newMsg);
    }
}
