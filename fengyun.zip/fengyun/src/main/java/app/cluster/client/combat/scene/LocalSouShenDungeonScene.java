package app.cluster.client.combat.scene;

import static com.mokylin.sink.util.BufferUtil.readVarInt64;

import org.jboss.netty.buffer.ChannelBuffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.cluster.shared.scene.ClusterSceneHeader;
import app.game.data.scene.SouShenDungeonSceneData;
import app.game.module.scene.AbstractHeroFightModule;
import app.game.module.scene.HeroFightModule;
import app.game.module.scene.IClusterLocalDungeonService;
import app.message.ISender;
import app.protobuf.ConfigContent.ShengWangType;

import com.mokylin.collection.LongConcurrentSynchronizedHashMap;
import com.mokylin.sink.util.Empty;

public class LocalSouShenDungeonScene extends LocalGroupDungeonScene{
    private static final Logger logger = LoggerFactory
            .getLogger(LocalSouShenDungeonScene.class);

    /**
     * 当做是可以领取通关奖励的bossID
     */
    private static final long ALL_PASS_BOSS_SCENE_ID = 999999L;

    private final SouShenDungeonSceneData sceneData;

    /**
     * 可领取boss奖励的英雄id. key是boss的场景id
     */
    private final LongConcurrentSynchronizedHashMap<LongConcurrentSynchronizedHashMap<Object>> canCollectBossPrizeHeroID;

    public LocalSouShenDungeonScene(SouShenDungeonSceneData sceneData,
            int uuid, IClusterLocalDungeonService dungeonService,
            ISender combatClient, long heroID){
        super(sceneData, uuid, dungeonService, combatClient, heroID);

        this.sceneData = sceneData;
        this.canCollectBossPrizeHeroID = new LongConcurrentSynchronizedHashMap<>();
    }

    @Override
    public SouShenDungeonSceneData getSceneData(){
        return sceneData;
    }

    @Override
    public void addHero(AbstractHeroFightModule heroFightModule, long ctime,
            boolean isEnteringFirstScene){
        super.addHero(heroFightModule, ctime, isEnteringFirstScene);

        if (hasDisconnected)
            return;

        if (heroFightModule instanceof HeroFightModule){
            ((HeroFightModule) heroFightModule).getHeroMiscModule()
                    .tryCompleteShengWangTask(ShengWangType.SW_SOU_SHEN, true,
                            1);
        } else{
            logger.error("搜神宫副本本地场景中的居然不是 HeroFightModule");
        }
    }

    /**
     * 如果英雄可领取boss奖励, 则返回true, 且把英雄设为不可领取这个奖励
     * @param bossID
     * @param heroID
     * @return
     */
    public boolean removeCollectableBossPrize(long bossID, long heroID){
        LongConcurrentSynchronizedHashMap<Object> bossPrizes = canCollectBossPrizeHeroID
                .get(bossID);
        if (bossPrizes == null){
            return false;
        }

        return bossPrizes.remove(heroID) != null;
    }

    /**
     * 如果英雄可领取通关奖励, 返回true, 且把英雄设为不可领取通关奖励
     * @param heroID
     * @return
     */
    public boolean removeCollectableFinishPrize(long heroID){
        return removeCollectableBossPrize(ALL_PASS_BOSS_SCENE_ID, heroID);
    }

    // --- 处理Combat服过来的消息 ---

    /**
     * 处理来自Combat服发送给这个场景, 让这个场景处理的消息
     * @param header
     * @param buffer
     * @param client
     */
    @Override
    public void onSceneMessage(ClusterSceneHeader header, ChannelBuffer buffer){
        switch (header){
            case C2S_SOU_SHEN_BOSS_DEAD:{
                onBossDead(buffer);
                return;
            }

            default:{
                super.onSceneMessage(header, buffer);
            }
        }
    }

    private void onBossDead(ChannelBuffer buffer){
        long bossSceneID = readVarInt64(buffer);
        logger.debug(
                "LocalSouShenDungeonScene.onBossDead收到了boss死亡消息, 要发奖励: {}",
                bossSceneID);

        if (sceneData.getBossPrize(bossSceneID) != null){
            ChannelBuffer msg = SouShenDungeonMessages
                    .startRandomBossPrize(bossSceneID);
            LongConcurrentSynchronizedHashMap<Object> map = new LongConcurrentSynchronizedHashMap<>();
            boolean unique = canCollectBossPrizeHeroID.putIfAbsent(bossSceneID,
                    map) == null;
            if (!unique){
                logger.error("LocalSouShenDungeonScene.onBossDead 收到了要发boss奖励消息, 但是此boss已经发过奖励了. 重复发了?");
                return;
            }
            for (AbstractHeroFightModule hfm : getAllHeroes()){
                map.put(hfm.getID(), Empty.DUMB_OBJECT);
                hfm.sendMessage(msg);
            }
        } else{
            logger.error(
                    "LocalSouShenDungeonScene.onBossDead收到了boss死亡消息, 但是boss在配置中没有奖励. 版本不同? {}",
                    bossSceneID);
        }
    }

    @Override
    protected void onFinished(int deadCount, int duration){
        LongConcurrentSynchronizedHashMap<Object> map = new LongConcurrentSynchronizedHashMap<>();
        boolean unique = canCollectBossPrizeHeroID.putIfAbsent(
                ALL_PASS_BOSS_SCENE_ID, map) == null;
        if (!unique){
            logger.error("LocalSouShenDungeonScene.onFinished时, 已经发过通关奖励了. 重复发送了?");
            return;
        }
        for (AbstractHeroFightModule hfm : getAllHeroes()){
            map.put(hfm.getID(), Empty.DUMB_OBJECT);
            hfm.sendMessage(SouShenDungeonMessages.dungeonFinished);
        }
    }
}
