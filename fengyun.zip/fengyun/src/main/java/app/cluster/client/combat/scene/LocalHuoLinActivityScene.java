package app.cluster.client.combat.scene;

import static app.cluster.client.combat.scene.HuoLinActivityMessages.setAccumulatedExpAndRealAir;

import org.jboss.netty.buffer.ChannelBuffer;

import app.cluster.shared.scene.ClusterSceneHeader;
import app.game.data.scene.HuoLinActivitySceneData;
import app.game.module.scene.AbstractHeroFightModule;
import app.game.module.scene.HeroFightModule;
import app.game.module.scene.IClusterLocalDungeonService;
import app.message.ISender;

public class LocalHuoLinActivityScene extends LocalGlobalActivityScene{

    private final HuoLinActivitySceneData sceneData;

    public LocalHuoLinActivityScene(HuoLinActivitySceneData sceneData,
            int uuid, IClusterLocalDungeonService dungeonService,
            ISender combatClient, long heroID){
        super(sceneData, uuid, dungeonService, combatClient, heroID);

        this.sceneData = sceneData;
    }

    @Override
    public HuoLinActivitySceneData getSceneData(){
        return sceneData;
    }

    @Override
    public void addHero(AbstractHeroFightModule heroFightModule, long ctime,
            boolean isEnteringFirstScene){
        super.addHero(heroFightModule, ctime, isEnteringFirstScene);

        if (hasDisconnected){
            // 上层已经把他传出副本了
            return;
        }

        // 如果已经有累计的经验和真气, 发送
        int accumulatedExp = heroFightModule.getHero()
                .getHuoLinAccumulatedExp();
        int accumulatedRealAir = heroFightModule.getHero()
                .getHuoLinAccumulatedRealAir();

        if (accumulatedExp != 0 || accumulatedRealAir != 0){
            heroFightModule.sendMessage(setAccumulatedExpAndRealAir(
                    accumulatedExp, accumulatedRealAir));
        }
    }

    @Override
    public void removeHero(AbstractHeroFightModule heroFightModule,
            boolean isOffline){
        super.removeHero(heroFightModule, false); // 不管是不是下线, 都直接离开. 防止断线重连进入火麟洞.
        // 如果将来火麟洞改成断线重连后, 也进入之前的场景. 则需要换个地方发送场景的线数. 现在在请求进入成功消息里
    }

    // --- 处理Combat服过来的消息 ---

    /**
     * 处理来自Combat服发送给这个场景, 让这个场景处理的消息
     * @param header
     * @param buffer
     * @param client
     */
    @Override
    public void onSceneMessage(ClusterSceneHeader header, ChannelBuffer buffer){
        switch (header){
            case C2S_HUO_LIN_ADD_EXP_AND_REAL_AIR:{
                onAddExpAndRealAir(buffer);
                return;
            }

            default:{
                super.onSceneMessage(header, buffer);
            }
        }
    }

    /**
     * 打坐获得的真气和经验, 加入统计
     */
    @Override
    public void onAddMediateAmount(HeroFightModule hfm, int toAddExp,
            int toAddRealAir){
        super.onAddMediateAmount(hfm, toAddExp, toAddRealAir);

        // 已经是英雄线程了
        if (toAddExp != 0 || toAddRealAir != 0){
            int accumulatedExp = hfm.getHero()
                    .addHuoLinAccumulatedExp(toAddExp);
            int accumulatedRealAir = hfm.getHero().addHuoLinAccumulatedRealAir(
                    toAddRealAir);
            hfm.sendMessage(setAccumulatedExpAndRealAir(accumulatedExp,
                    accumulatedRealAir));
        }
    }

    @Override
    public float getMeditateMultiple(){
        return sceneData.getMeditateMultiple();
    }

    /**
     * 杀怪获得的经验, 加入统计
     */
    @Override
    public void onHeroAddMonsterDeadExp(HeroFightModule heroFightModule,
            int amount){
        super.onHeroAddMonsterDeadExp(heroFightModule, amount);

        if (amount > 0){
            int accumulatedExp = heroFightModule.getHero()
                    .addHuoLinAccumulatedExp(amount);
            int accumulatedRealAir = heroFightModule.getHero()
                    .getHuoLinAccumulatedRealAir();
            heroFightModule.sendMessage(setAccumulatedExpAndRealAir(
                    accumulatedExp, accumulatedRealAir));
        }
    }

    /**
     * 处理定时加经验/真气
     * @param buffer
     */
    private void onAddExpAndRealAir(ChannelBuffer buffer){
        for (final AbstractHeroFightModule hfm : getAllHeroes()){
            hfm.getTaskExec().execute(new Runnable(){
                @Override
                public void run(){
                    ((HeroFightModule) hfm).addHuoLinPeriodicExpAndRealAir(
                            sceneData.eachAddExpAmount,
                            sceneData.eachAddRealAirAmount);

                    hfm.sendMessage(setAccumulatedExpAndRealAir(hfm.getHero()
                            .getHuoLinAccumulatedExp(), hfm.getHero()
                            .getHuoLinAccumulatedRealAir()));
                }
            });
        }
    }
}
