package app.cluster.client.combat;

import static app.game.module.ViewOtherHeroMessages.viewOtherHeroOnline;
import static com.mokylin.sink.util.BufferUtil.*;

import java.io.Closeable;

import org.jboss.netty.buffer.BigEndianHeapChannelBuffer;
import org.jboss.netty.buffer.ChannelBuffer;
import org.jboss.netty.channel.Channel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.cluster.client.combat.scene.AbstractLocalScene;
import app.cluster.combat.master.CombatMasterServerInfo;
import app.cluster.shared.scene.CombatHeader;
import app.game.data.spell.SingleEffectSpell;
import app.game.data.spell.SingleEffectSpell.SingleEffectSpellWithUsedTimes;
import app.game.entity.Hero;
import app.game.entity.SpellList;
import app.game.module.ConnectedUser;
import app.game.module.HeroController;
import app.game.module.Modules;
import app.game.module.ViewOtherHeroMessages;
import app.message.ISender;
import app.protobuf.HeroContent.OtherHeroProto;

import com.mokylin.sink.client.ReconnectNettyClient;
import com.mokylin.sink.client.ReconnectNettyClientSharedResources;
import com.mokylin.sink.server.Worker;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.concurrent.DisruptorExecutor;

class CombatClient implements Closeable, ISender, Worker{
    private static final Logger logger = LoggerFactory
            .getLogger(CombatClient.class);

    public final long id;

    private final ReconnectNettyClient nettyClient;

    private final ClusterService clusterService;

    private final CombatMasterServerInfo serverInfo;

    private final ClusterClientCombatServerContainer combatServerContainer;

    private final ChannelBuffer registerCombatMsg;

    private final boolean IS_DEBUG;

    public CombatClient(CombatMasterServerInfo serverInfo,
            ReconnectNettyClientSharedResources res,
            ClusterService clusterService,
            ClusterClientCombatServerContainer combatServerContainer,
            ChannelBuffer registerCombatMsg, boolean IS_DEBUG){
        this.serverInfo = serverInfo;
        this.id = serverInfo.id;
        this.clusterService = clusterService;
        this.combatServerContainer = combatServerContainer;
        this.registerCombatMsg = registerCombatMsg;
        this.IS_DEBUG = IS_DEBUG;

        this.nettyClient = new ReconnectNettyClient(serverInfo.address,
                serverInfo.port, this, res);
    }

    public void start(){
        nettyClient.start();
    }

    @Override
    public void close(){
        Utils.closeQuietly(nettyClient);
    }

    @Override
    public boolean sendMessage(ChannelBuffer buffer){
        return nettyClient.sendMessage(buffer);
    }

    /**
     * 收到CombatServer消息
     */
    @Override
    public void onMessage(ChannelBuffer buffer){
        int msgId = readVarInt32(buffer);

        CombatHeader header = CombatHeader.getHeaderByID(msgId);
        if (header == null){
            logger.error("CombatClient收到来自Combat服的未知消息: {}", msgId);
            Channel ch = nettyClient.getChannel();
            if (ch != null){
                ch.close(); // 有BUG了
            }
            return;
        }

        logger.debug("收到来自combat服的消息: {}. 消息长度: {} bytes", header,
                buffer.readableBytes());

        try{
            switch (header){
                case SCENE_MESSAGE:{
                    clusterService.getClusterSceneService().onSceneMessage(
                            buffer);
                    return;
                }

                case C2S_HERO_RELEASED_SPELL:{
                    onHeroReleasedSpell(buffer);
                    return;
                }

                case C2S_OTHER_SERVER_VIEW_YOUR_HERO:{
                    onOtherServerViewYourHero(buffer);
                    return;
                }

                case C2S_PROXY_MSG:{
                    onProxyMsg(buffer);
                    return;
                }

                default:{
                    logger.error("CombatClient收到来自Combat服的未处理消息 {}-{}", msgId,
                            header);
                }
            }
        } catch (Throwable ex){
            logger.error("CombatClient.onMessage处理来自Combat服的消息出错 id: " + msgId
                    + ", header: " + header, ex);
        }
    }

    private void onProxyMsg(ChannelBuffer buffer){
        long targetID = readVarInt64(buffer);
        ConnectedUser cu = clusterService.getWorldService().getUser(targetID);
        if (cu == null){
            return;
        }

        if (IS_DEBUG){
            buffer.markReaderIndex();

            int moduleID = readVarInt32(buffer);
            int sequenceID = readVarInt32(buffer);

            logger.debug("Combat要我转发消息给用户: {}",
                    Modules.getS2CMsgName(moduleID, sequenceID));
            buffer.resetReaderIndex();
        }
        ChannelBuffer newMsg = new BigEndianHeapChannelBuffer(
                buffer.readableBytes() + 2);
        newMsg.writeShort(0);
        newMsg.writeBytes(buffer);
        cu.getSender().sendMessage(newMsg);
    }

    private void onOtherServerViewYourHero(ChannelBuffer buffer){
        final long askerID = readVarInt64(buffer);
        final long targetID = readVarInt64(buffer);

        logger.debug("别的服的英雄要观察我这个服务器上的英雄");
        clusterService.getThreadService().getDbExecutor()
                .execute(new Runnable(){
                    @Override
                    public void run(){
                        ChannelBuffer result = getViewResult(targetID);
                        int len = result.writerIndex() - 2;
                        ChannelBuffer toSend = CombatHeader
                                .proxyMsgToHeroOnAnotherServer(askerID, len);
                        toSend.writeBytes(result, 2, len);
                        sendMessage(toSend);
                    }
                });
    }

    private ChannelBuffer getViewResult(long targetID){
        ConnectedUser cu = clusterService.getWorldService().getUser(targetID);
        if (cu != null){
            HeroController hc = cu.getHeroController();
            if (hc != null){
                Hero hero = hc.getHero();
                long ctime = clusterService.getTimeService().getCurrentTime();
                if (ctime < hero.nextViewOtherHeroMsgCacheExpireTime){
                    ChannelBuffer cache = hero.msgAsViewOtherHero;
                    if (cache != null){
                        return cache;
                    }
                }

                // 没有缓存, 或缓存过期
                OtherHeroProto proto = hero.encodeToOtherHeroOnBeingViewed();
                ChannelBuffer msg = viewOtherHeroOnline(proto.toByteArray());

                hero.msgAsViewOtherHero = msg;
                hero.nextViewOtherHeroMsgCacheExpireTime = ctime
                        + ViewOtherHeroMessages.MSG_CACHE_TIME;
                return msg;
            } else{
                // 没英雄
                return ViewOtherHeroMessages.ERR_VIEW_OTHER_HERO_HERO_NOT_EXIST;
            }
        }

        // 不在线
        ChannelBuffer result = clusterService.getViewOtherHeroCache().get(
                targetID);
        if (result == ViewOtherHeroMessages.HERO_NOT_EXIST_BUFFER){
            // 不存在
            return ViewOtherHeroMessages.ERR_VIEW_OTHER_HERO_HERO_NOT_EXIST;
        }

        return result;
    }

    private void onHeroReleasedSpell(ChannelBuffer buffer){
        final long heroID = readVarInt64(buffer);
        final HeroController hc = clusterService.getWorldService()
                .getHeroController(heroID);
        if (hc == null){
            logger.debug("CombatClient.onHeroReleasedSpell时, 英雄不在线: {}", heroID);
            return;
        }

        final int spellType = readVarInt32(buffer);
        hc.getExecutor().execute(new Runnable(){
            @Override
            public void run(){
                if (hc.getIsOffline().get()){
                    logger.debug("CombatClient.onHeroReleasedSpell时, 在exec中英雄下线了, 这么巧?");
                    return;
                }

                SpellList spellList = hc.getHero().getSpellList();
                SingleEffectSpellWithUsedTimes spellWithUsedTime = spellList
                        .getSingleEffectSpell(spellType);
                if (spellWithUsedTime == null){
                    logger.error(
                            "CombatClient.onHeroReleasedSpell时, 没有找到英雄释放出来的技能, 版本不对? spellType: {}",
                            spellType);
                    return;
                }

                spellWithUsedTime.addUsedTime();

                SingleEffectSpell spell = spellWithUsedTime.getActualSpell();
                hc.sendMessage(spell.getReleasedMessage());

                // 怒气值清0
                if (spell.isRageSpell()){
                    spellList.clearRangeAmount();
                }
            }
        });
    }

    /**
     * 与CombatServer的连接断开
     */
    @Override
    public void onDisconnect(){
        logger.info("与Combat服的连接断开: {}", serverInfo);
        CombatClient sd = combatServerContainer.removeCombatServer(id);
        if (sd != this){
            logger.error(
                    "CombatClient.onDisconnect时, 从container中移除的竟然不是自己: 自己 {}, 移除的 {}",
                    this, sd);
        }

        // 和server断开了, 需要把所有正连到这server的人都踢到原场景
        for (final DisruptorExecutor exec : clusterService.getTaskExecArray()){
            exec.execute(new Runnable(){
                @Override
                public void run(){
                    for (AbstractLocalScene scene : clusterService
                            .getClusterSceneService().getAll()){
                        if (scene.isSameCombatClient(CombatClient.this)){
                            scene.processServerDisconnected(exec);
                        }
                    }
                }
            });
        }
    }

    /**
     * 与CombatServer连接建立
     */
    @Override
    public void onConnected(){
        logger.info("与Combat服的连接已建立: {}", serverInfo);
        sendMessage(registerCombatMsg);

        boolean unique = combatServerContainer.addCombatServer(this);

        if (!unique){
            // 竟然之前已经有个相同id的存在了, 搞毛
            logger.error(
                    "CombatClient.onCombatServerAdded时, 相同id的CombatServer竟然已经存在了: {}",
                    serverInfo);
            Utils.closeQuietly(this);
        }
    }

}
