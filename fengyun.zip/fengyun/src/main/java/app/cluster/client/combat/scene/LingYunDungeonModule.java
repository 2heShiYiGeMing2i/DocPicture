package app.cluster.client.combat.scene;

import org.jboss.netty.buffer.ChannelBuffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.module.HeroController;
import app.game.module.scene.HeroFightModule;

import com.google.inject.Inject;

public class LingYunDungeonModule{
    private static final Logger logger = LoggerFactory
            .getLogger(LingYunDungeonModule.class);

    @Inject
    LingYunDungeonModule(){
    }

    public void onMessage(int sequenceID, ChannelBuffer buffer,
            HeroController hc, HeroFightModule heroFightModule){
        switch (sequenceID){

            default:{
                logger.warn("LingYunDungeonModule收到未知的消息id: {}", sequenceID);
            }
        }
    }
}
