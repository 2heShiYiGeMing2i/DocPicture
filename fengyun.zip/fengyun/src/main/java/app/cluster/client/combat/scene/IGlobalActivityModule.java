package app.cluster.client.combat.scene;

/**
 * 全区服跨服活动的模块, 处理master返回的消息
 * @author Timmy
 *
 */
public interface IGlobalActivityModule{

    void processReplyGlobalActivityDestination(int sceneID, long heroID,
            int uuid, int line, long combatServerID);

    void processGetGlobalActivityDestinationFailNoCombatServer(int sceneID,
            long heroID);
}
