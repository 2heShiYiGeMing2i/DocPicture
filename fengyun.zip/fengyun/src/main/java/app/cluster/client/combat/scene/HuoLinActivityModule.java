package app.cluster.client.combat.scene;

import static app.cluster.client.combat.scene.HuoLinActivityMessages.*;

import java.util.concurrent.TimeUnit;

import org.jboss.netty.buffer.ChannelBuffer;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.cluster.client.GroupClient;
import app.cluster.client.combat.ClusterClientCombatServerContainer;
import app.cluster.group.codec.GroupHeader;
import app.game.data.scene.HuoLinActivitySceneData;
import app.game.data.scene.HuoLinActivitySceneDatas;
import app.game.entity.Hero;
import app.game.module.ConnectedUser;
import app.game.module.HeroController;
import app.game.module.WelfareMessages;
import app.game.module.scene.HeroFightModule;
import app.game.service.IThreadService;
import app.game.service.TimeService;
import app.game.service.WorldService;
import app.message.ISender;
import app.protobuf.ConfigContent.DailyActivityType;
import app.protobuf.LogContent.LogEnum.TransportType;
import app.utils.VariableConfig;

import com.google.inject.Inject;

/**
 * 火麟洞模块
 * @author Timmy
 *
 */
public class HuoLinActivityModule implements IGlobalActivityModule{
    private static final Logger logger = LoggerFactory
            .getLogger(HuoLinActivityModule.class);

    /**
     * 到master的连接
     */
    private final GroupClient groupClient;

    private final HuoLinActivitySceneDatas huoLinSceneDatas;

    private final ClusterDungeonService clusterDungeonService;

    private final ClusterClientCombatServerContainer combatServerContainer;

    private final TimeService timeService;

    private final IThreadService threadService;

    private final WorldService worldService;

    /**
     * 当前如果在活动期间, 则不为null, value = 活动结束时间
     * 当前如果不在活动期间, 则为null
     */
    private volatile Long activityEndTime;

    @Inject
    HuoLinActivityModule(GroupClient groupClient,
            HuoLinActivitySceneDatas huoLinSceneDatas,
            ClusterDungeonService clusterDungeonService,
            TimeService timeService, IThreadService threadService,
            WorldService worldService,
            ClusterClientCombatServerContainer combatServerContainer){
        this.groupClient = groupClient;
        this.huoLinSceneDatas = huoLinSceneDatas;
        this.clusterDungeonService = clusterDungeonService;
        this.timeService = timeService;
        this.threadService = threadService;
        this.worldService = worldService;
        this.combatServerContainer = combatServerContainer;

        long ctime = timeService.getCurrentTime();
        // 判断当前是否在活动期间
        // 把时间倒退个活动duration, 看下次活动时间, 是否在ctime之前, 是的话, 当前就是在活动期间

        long nextStartTime = huoLinSceneDatas.activityTimeData
                .getNextTime(ctime - huoLinSceneDatas.activityDuration);

        if (nextStartTime < ctime){
            // 当前是开启状态
            long endTime = nextStartTime + huoLinSceneDatas.activityDuration;
            this.activityEndTime = Long.valueOf(endTime);
            // schedule到时间设置为活动结束
            threadService.getScheduledExecutorService().schedule(
                    setNullRunnable, endTime - ctime, TimeUnit.MILLISECONDS);
            logger.debug("开服时出于火麟洞活动期间, 火麟洞开启");
        } else{
            // 当前不是开启状态
            // schedule 到时间设置为活动开始
            threadService.getScheduledExecutorService().schedule(
                    setStartRunnable, nextStartTime - ctime,
                    TimeUnit.MILLISECONDS);
        }
    }

    /**
     * 活动结束时, 设置下次开始时间
     */
    private final Runnable setStartRunnable = new Runnable(){
        @Override
        public void run(){
            if (activityEndTime != null){
                logger.error("HuoLinActivityModule.setStartRunnable运行时, activityEndTime != null");
            }

            long ctime = timeService.getCurrentTime();

            long actualStartTime = huoLinSceneDatas.activityTimeData
                    .getNextTime(ctime - huoLinSceneDatas.activityDuration);
            if (actualStartTime <= ctime){
                logger.debug("火麟洞开启");
                long endTime = actualStartTime
                        + huoLinSceneDatas.activityDuration;
                activityEndTime = Long.valueOf(endTime);
                threadService.getScheduledExecutorService()
                        .schedule(setNullRunnable, endTime - ctime,
                                TimeUnit.MILLISECONDS);
            } else{
                // 开启时间还没到, 重新schedule
                threadService.getScheduledExecutorService().schedule(
                        setStartRunnable, actualStartTime - ctime,
                        TimeUnit.MILLISECONDS);
            }
        }
    };

    /**
     * 把当前活动设为关闭, 并schedule下次活动开始时间
     */
    private final Runnable setNullRunnable = new Runnable(){
        @Override
        public void run(){
            if (activityEndTime == null){
                logger.error("HuoLinActivityModule.setNullRunnable运行时, activityEndTime == null");
            }
            logger.debug("火麟洞关闭");
            activityEndTime = null;

            long ctime = timeService.getCurrentTime();
            long nextStartTime = huoLinSceneDatas.activityTimeData
                    .getNextTime(ctime);
            threadService.getScheduledExecutorService().schedule(
                    setStartRunnable, nextStartTime - ctime,
                    TimeUnit.MILLISECONDS);
        }
    };

    public void onMessage(int sequenceID, ChannelBuffer buffer,
            HeroController hc, HeroFightModule heroFightModule){
        switch (sequenceID){
            case C2S_REQUEST_ENTRY:{
                onRequestEntry(buffer, hc, heroFightModule);
                return;
            }

            default:{
                logger.warn("HuoLinActivityModule收到未知消息: {}", sequenceID);
            }
        }
    }

    private void onRequestEntry(ChannelBuffer buffer, HeroController hc,
            HeroFightModule heroFightModule){
        Hero hero = hc.getHero();
        if (hero.getLevel() < huoLinSceneDatas.lowestLevel){
            logger.warn("火麟洞, 客户端要求进入, 等级不够");
            hc.sendMessage(ERROR_REQUEST_ENTRY_NOT_ENOUGH_LEVEL);
            return;
        }

        if (!heroFightModule.isInAndEnteredNormalScene()){
            hc.sendMessage(ERROR_REQUEST_ENTRY_NOT_IN_NORMAL);
            return;
        }

        Long endTimeLong = activityEndTime;
        if (endTimeLong == null){
            hc.sendMessage(ERROR_REQUEST_ENTRY_NOT_RIGHT_TIME);
            return;
        }

        long endTime = endTimeLong.longValue();
        long startTime = endTime - huoLinSceneDatas.activityDuration;

        DateTime time = new DateTime(startTime);
        int key = ((DailyActivityType.DA_HUO_LIN_VALUE << 12) | (time
                .getHourOfDay() * 100 + time.getMinuteOfHour()));

        int result = hc.getHero().setDailyActivity(key, 0);
        if (result > 0){
            logger.warn("HuoLinActivityModule.onRequestEntry时, 已经花钱参与过了");
            hc.sendMessage(ERROR_REQUEST_ENTRY_PAYBACK);
            return;
        } else if (result < 0){
            heroFightModule.sendMessage(WelfareMessages
                    .dailyActivityJoinedMsg(key));
        }

        long heroActivityEndTime = hero.getHuoLinActivityEndTime();
        if (heroActivityEndTime >= startTime){
            // 英雄本次活动已经去过火麟洞了
            HuoLinActivitySceneData oldSceneData = huoLinSceneDatas.get(hero
                    .getHuoLinSceneDataID());
            if (oldSceneData != null){
                // 找到了之前的火麟洞场景
                // 看下当前等级该去的火麟洞是不是新的
                HuoLinActivitySceneData newSceneData = huoLinSceneDatas
                        .getByHeroLevel(hero.getLevel());
                if (newSceneData == oldSceneData){
                    // 看下combat服是否存在
                    ISender combatServer = combatServerContainer
                            .getCombatServer(hero.getHuoLinCombatServerID());
                    if (combatServer != null){
                        // 也存在, 进

                        hc.sendMessage(requestEntrySuccess(hero.getHuoLinLine()));

                        AbstractLocalScene scene = clusterDungeonService
                                .getOrCreateNew(oldSceneData,
                                        hero.getHuoLinSceneUUID(),
                                        hc.combinedID, combatServer);
                        heroFightModule.doChangeScene(scene,
                                oldSceneData.getDefaultX(),
                                oldSceneData.getDefaultY(),
                                TransportType.ENTER_DUNGEON);
                        return;
                    }
                }
            }
        } else{
            hero.clearHuoLinAccumulatedStat(); // 清掉上次活动的累计数据
        }

        long ctime = timeService.getCurrentTime();
        if (ctime < hc.nextCanRequestHuoLinActivityTime){
            hc.sendMessage(ERROR_REQUEST_ENTRY_TOO_FREQUENT);
            return;
        }

        // 到这里的, 都是要重新去master请求个场景的
        HuoLinActivitySceneData sceneData = huoLinSceneDatas
                .getByHeroLevel(hero.getLevel());
        assert sceneData != null;

        boolean msgSent = groupClient.sendMessage(GroupHeader
                .getGlobalActivityDestination(sceneData.id, hc.combinedID));

        if (!msgSent){
            hc.sendMessage(ERROR_REQUEST_ENTRY_MASTER_DISCONNECTED);
            return;
        }

        hc.nextCanRequestHuoLinActivityTime = ctime
                + VariableConfig.HUO_LIN_REQUEST_JOIN_INTERVAL;

        // 成功消息等master返回再发
    }

    @Override
    public void processReplyGlobalActivityDestination(final int sceneID,
            long heroID, final int uuid, final int line,
            final long combatServerID){
        final HeroController hc = worldService.getHeroController(heroID);
        if (hc == null){
            return;
        }

        hc.getExecutor().execute(new Runnable(){
            @Override
            public void run(){
                if (hc.getIsOffline().get()){
                    // 之前的那个已经下线了, 不管
                    return;
                }

                HeroFightModule hfm = hc.getHeroFightModule();
                if (!hfm.isInAndEnteredNormalScene()){
                    hc.sendMessage(ERROR_REQUEST_ENTRY_NOT_IN_NORMAL);
                    // 返回前切场景或者进副本了, 发错误消息让客户端解锁
                    return;
                }

                // 可以进
                Long endTime = activityEndTime;
                if (endTime == null){
                    // 返回处理的时候已经不在活动时间了...
                    hc.sendMessage(ERROR_REQUEST_ENTRY_NOT_RIGHT_TIME);
                    return;
                }

                HuoLinActivitySceneData sceneData = huoLinSceneDatas
                        .get(sceneID);
                if (sceneData == null){
                    logger.error(
                            "HuoLinActivityModule.processReplyGlobalActivityDestination时, 竟然没有找到要去的场景. sceneDataID: {}",
                            sceneID);
                    hc.sendMessage(ERROR_REQUEST_ENTRY_NOT_ENOUGH_LEVEL);
                    return;
                }

                ISender combatClient = combatServerContainer
                        .getCombatServer(combatServerID);
                if (combatClient == null){
                    logger.error(
                            "HuoLinActivityModule.processReplyGlobalActivityDestination时, 没有找到combat server. 可能master已经发现了, 客户端还没发现: {}",
                            combatServerID);
                    hc.sendMessage(ERROR_REQUEST_ENTRY_NO_COMBAT_SERVER_OR_COMBAT_SERVER_NOT_FOUND);
                    return;
                }

                hfm.getHero().setHuoLinScene(combatServerID, sceneID, uuid,
                        line, endTime);

                hc.sendMessage(requestEntrySuccess(line));

                AbstractLocalScene scene = clusterDungeonService
                        .getOrCreateNew(sceneData, uuid, hc.combinedID,
                                combatClient);
                assert scene != null;
                hfm.doChangeScene(scene, sceneData.getDefaultX(),
                        sceneData.getDefaultY(), TransportType.ENTER_DUNGEON);
            }
        });
    }

    @Override
    public void processGetGlobalActivityDestinationFailNoCombatServer(
            int sceneID, long heroID){
        ConnectedUser cu = worldService.getUser(heroID);
        if (cu != null){
            cu.getSender()
                    .sendMessage(
                            ERROR_REQUEST_ENTRY_NO_COMBAT_SERVER_OR_COMBAT_SERVER_NOT_FOUND);
        }
    }
}
