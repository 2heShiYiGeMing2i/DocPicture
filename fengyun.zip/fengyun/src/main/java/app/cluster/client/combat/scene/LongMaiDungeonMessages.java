package app.cluster.client.combat.scene;

import org.jboss.netty.buffer.ChannelBuffer;
import static com.mokylin.sink.util.BufferUtil.*;

import app.game.module.Modules;

public class LongMaiDungeonMessages{

    public static final int MODULE_ID = Modules.LONG_MAI_DUNGEON_MODULE_ID;

    // --- 刚进场景时, 展示还需要多久开始刷怪 ---

    /**
     * 发送个开始刷怪的时间点, 客户端自己算出还剩几秒, 开始倒数, 在屏幕上方展示
     * 入侵者即将抵达, 请做好防御准备
     * 
     * 附带
     * 
     * varint64 刷怪的时间点 (具体的时间点)
     */
    static final int S2C_NOTIFY_START_TIME = 1;

    // --- 发送当前波数的信息 ---

    /**
     * 发送当前的波数信息, 刚进入场景时会发送, 以后波数更新时也会发送
     * 
     * 附带
     * 
     * varint32 当前波数 (从1开始, 不需要+1) 总波数在config.proto中
     * while (byteArray.available){
     *  读这一波中会出现的所有怪物
     *  varint32 怪物id  // 通过这个id获得怪物的信息, 以及是精英还是boss之类
     * }
     */
    static final int S2C_SET_BATCH_INFO = 2;

    // --- 守护失败 ---

    /**
     * 龙脉挂了, 展示 龙脉被夺, 通关失败. 并倒计时5秒发送离开副本消息. 服务器不会自动传送出去
     * 
     * 将视野里的怪物都删除. 且本场景内就算再收到添加怪物的消息, 也无视. (注意不要把将来的宠物也误伤了)
     * 
     * 没有附带消息
     */
    static final int S2C_DUNGEON_FAIL = 3;
    public static final ChannelBuffer dungeonFail = onlySendHeaderMessage(
            MODULE_ID, S2C_DUNGEON_FAIL);

    // --- 添加龙脉 ---

    /**
     * 添加龙脉到场景中. 龙脉的场景中的id固定为1. 龙脉可以选中, 不能作为施法目标
     * 
     * 附带
     * 
     * varint32 怪物类型id
     * varint32 血量
     * varint32 最大血量
     * varint32 x坐标
     * varint32 y坐标
     */
    static final int S2C_ADD_LONG_MAI = 4;

    // --- 龙脉设为首通 ---

    /**
     * 将守护龙脉设为今日已首通
     * 
     * 没有附带信息
     */
    static final int S2C_SET_TODAY_FIRST_PASSED = 5;
    static final ChannelBuffer setTodayFirstPassed = onlySendHeaderMessage(
            MODULE_ID, S2C_SET_TODAY_FIRST_PASSED);

    // --- 通关, 今日已首通, 可领取非首通奖励 ---

    /**
     * 副本完成, 但英雄今日已经首通过, 这次领取非首通的奖励
     * 不会再发送 组队模块中的通用领奖励消息
     * 客户端根据config.proto中配置的非首通奖励, 展示领取面板
     * 
     * 没有附带消息
     */
    static final int S2C_DUNGEON_FINISHED_AND_COLLECT_NOT_FIRST_PASS_PRIZE = 6;
    static final ChannelBuffer dungeonFinishedAndCollectNotFirstPassPrize = onlySendHeaderMessage(
            MODULE_ID, S2C_DUNGEON_FINISHED_AND_COLLECT_NOT_FIRST_PASS_PRIZE);

    // --- 领取非首通奖励 ---

    /**
     * 客户端领取非首通奖励
     * 
     * 需要等服务器返回
     * 
     * 没有附带信息
     */
    static final int C2S_COLLECT_NOT_FIRST_PASS_PRIZE = 1;

    /**
     * 领取失败, 附带varint32 错误码
     * 
     * 1. 当前不在守护龙脉副本中
     * 2. 当前不能领取非首通奖励. 没通/已领/应该走统一的奖励流程
     * 3. 背包已满. 服务器会自动把物品发到邮件中, 数值加到身上. 面板关掉, 提示
     */
    static final int S2C_COLLECT_NOT_FIRST_PASS_PRIZE_FAIL = 7;
    static final ChannelBuffer ERROR_COLLECT_NOT_FIRST_PRIZE_NOT_IN_LONG_MAI = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_COLLECT_NOT_FIRST_PASS_PRIZE_FAIL, 1);
    static final ChannelBuffer ERROR_COLLECT_NOT_FIRST_PRIZE_NOT_COLLECTABLE = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_COLLECT_NOT_FIRST_PASS_PRIZE_FAIL, 2);
    static final ChannelBuffer ERROR_COLLECT_NOT_FIRST_PRIZE_BAG_FULL = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_COLLECT_NOT_FIRST_PASS_PRIZE_FAIL, 3);

    /**
     * 领取成功. 会另外发送加物品/加数值消息. 飞动画就行
     * 
     * 没有附带信息
     */
    static final int S2C_COLLECT_NOT_FIRST_PASS_PRIZE_SUCCESS = 8;
    static final ChannelBuffer collectNotFirstPassPrizeSuccess = onlySendHeaderMessage(
            MODULE_ID, S2C_COLLECT_NOT_FIRST_PASS_PRIZE_SUCCESS);

    // --- 具体的消息构建 ---

    public static ChannelBuffer addLongMai(int monsterID, int life,
            int maxLife, int x, int y){
        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID, S2C_ADD_LONG_MAI,
                computeVarInt32Size(monsterID) + computeVarInt32Size(life)
                        + computeVarInt32Size(maxLife) + computeVarInt32Size(x)
                        + computeVarInt32Size(y));

        writeVarInt32(buffer, monsterID);
        writeVarInt32(buffer, life);
        writeVarInt32(buffer, maxLife);
        writeVarInt32(buffer, x);
        writeVarInt32(buffer, y);
        return buffer;
    }

    public static ChannelBuffer setBatchInfo(int[] info){
        return onlySendHeaderAndVarIntsMessage(MODULE_ID, S2C_SET_BATCH_INFO,
                info);
    }

    public static ChannelBuffer notifyStartTime(long time){
        return onlySendHeadAndAVarInt64Message(MODULE_ID,
                S2C_NOTIFY_START_TIME, time);
    }
}
