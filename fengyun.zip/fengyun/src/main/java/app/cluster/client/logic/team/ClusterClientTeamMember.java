package app.cluster.client.logic.team;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.cluster.client.GroupClient;
import app.cluster.client.combat.scene.ClusterDungeonService;
import app.cluster.client.combat.scene.LocalDungeonScene;
import app.cluster.group.codec.GroupHeader;
import app.game.data.scene.GroupDungeonSceneData;
import app.message.ISender;

public class ClusterClientTeamMember{
    private static final Logger logger = LoggerFactory
            .getLogger(ClusterClientTeamMember.class);

    private final GroupDungeonSceneData dungeonSceneData;
    private final long heroID;
    private final GroupClient groupClient;

    /**
     * 所要连的Combat服的id
     */
    private long combatServerID;

    /**
     * 用作区分副本的副本uuid
     */
    private int combatDungeonUUID;

    /**
     * 进入副本的时间
     */
    private long enterDungeonTime;

    ClusterClientTeamMember(GroupDungeonSceneData dungeonSceneData,
            long heroID, GroupClient groupClient){
        this.dungeonSceneData = dungeonSceneData;
        this.heroID = heroID;
        this.groupClient = groupClient;
        this.enterDungeonTime = Long.MAX_VALUE;
    }

    int getSceneConfigID(){
        return dungeonSceneData.id;
    }

    public void leaveTeam(){
        // 发送离队消息给master
        groupClient.sendMessage(GroupHeader.leaveGroup(heroID,
                getSceneConfigID()));
    }

    public void setStartInfo(long combatServerID, int combatDungeonUUID,
            long enterDungeonTime){
        this.combatServerID = combatServerID;
        this.combatDungeonUUID = combatDungeonUUID;
        this.enterDungeonTime = enterDungeonTime;
    }

    public boolean hasStarted(){
        return enterDungeonTime != Long.MAX_VALUE; // 有进入副本时间, 就是已经开始了
    }

    public boolean canEnterDungeon(long ctime){
        return ctime >= enterDungeonTime;
    }

    public LocalDungeonScene getDungeonToEnter(
            ClusterDungeonService clusterDungeonService, long heroID){
        ISender combatClient = clusterDungeonService
                .getCombatClient(combatServerID);
        if (combatClient == null){
            logger.error(
                    "要获取英雄要进入的Combat服务器时, 没有找到服务器. 正好断线了? 或者master发现了, 但这台机器还没发现. server id: {}",
                    combatServerID);
            return null;
        }

        return clusterDungeonService.getOrCreateNew(dungeonSceneData,
                combatDungeonUUID, heroID, combatClient);
    }
}
