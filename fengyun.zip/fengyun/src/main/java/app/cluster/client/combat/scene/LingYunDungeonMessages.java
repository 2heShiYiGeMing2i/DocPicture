package app.cluster.client.combat.scene;

import static com.mokylin.sink.util.BufferUtil.*;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.module.Modules;

public class LingYunDungeonMessages{

    public static final int MODULE_ID = Modules.LING_YUN_DUNGEON_MODULE_ID;

    // --- 发送怪物的等级 ---

    /**
     * 进入副本时, 推送给客户端当前副本中的boss的等级.
     * 客户端把小地图及boss在场景中的等级, 改成消息中附带的等级
     * 收到此消息时, boss可能还未发送给客户端, 将来收到时, 需要改等级
     *
     * 改怪物类型是boss的, 凌云窟只会有一个类型是boss的怪物
     *
     * 附带
     *
     * varint32 boss的怪物场景id
     * varint32 等级
     */
    static final int S2C_SET_BOSS_LEVEL = 1;

    // --- 增加通关次数 ---

    /**
     * 设置今日进入的次数
     *
     * 附带
     *
     * varint32 进入次数
     */
    static final int S2C_SET_ENTERED_TIMES = 9;

    // --- 设置今日通关/参与标签信息 ---

    /**
     * 设置今日已通关/今日已参与
     *
     * 附带
     *
     * varint32 类型  1. 今日已参与. 2. 今日已通关
     *
     */
    static final int S2C_SET_TODAY_STATE = 10;

    static final ChannelBuffer setTodayStateJoined = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_SET_TODAY_STATE, 1);
    static final ChannelBuffer setTodayStatePassed = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_SET_TODAY_STATE, 2);

    // --- 具体消息构建 ---

    public static ChannelBuffer setBossLevel(int bossSceneID, int level){
        return onlySendHeadAnd2VarInt32Message(MODULE_ID, S2C_SET_BOSS_LEVEL,
                bossSceneID, level);
    }

    static ChannelBuffer setEnteredTimes(int times){
        return onlySendHeadAndAVarInt32Message(MODULE_ID,
                S2C_SET_ENTERED_TIMES, times);
    }

}
