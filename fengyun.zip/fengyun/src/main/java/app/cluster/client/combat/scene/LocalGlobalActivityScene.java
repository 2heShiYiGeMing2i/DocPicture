package app.cluster.client.combat.scene;

import app.game.data.scene.GlobalActivitySceneData;
import app.game.module.scene.IClusterLocalDungeonService;
import app.message.ISender;

public abstract class LocalGlobalActivityScene extends LocalDungeonScene{

    private final GlobalActivitySceneData sceneData;

    public LocalGlobalActivityScene(GlobalActivitySceneData sceneData,
            int uuid, IClusterLocalDungeonService dungeonService,
            ISender combatClient, long heroID){
        super(sceneData, uuid, dungeonService, combatClient, heroID);

        this.sceneData = sceneData;
    }

    @Override
    public GlobalActivitySceneData getSceneData(){
        return sceneData;
    }
}
