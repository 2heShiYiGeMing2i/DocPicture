package app.cluster.client.combat.scene;

import static app.game.module.scene.SceneMessages.*;
import static com.mokylin.sink.util.BufferUtil.readVarInt64;

import org.jboss.netty.buffer.ChannelBuffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.cluster.client.logic.team.ClusterClientMessages;
import app.cluster.shared.scene.ClusterSceneHeader;
import app.game.data.scene.DungeonSceneData;
import app.game.module.HeroController;
import app.game.module.scene.AbstractHeroFightModule;
import app.game.module.scene.HeroFightModule;
import app.game.module.scene.ICanEnterCounter;
import app.game.module.scene.IClusterLocalDungeonService;
import app.game.module.scene.IDungeon;
import app.game.module.scene.MultiCanEnterCounter;
import app.game.module.scene.SceneMessages;
import app.message.ISender;

import com.mokylin.sink.util.annotation.MultiThread;
import com.mokylin.sink.util.concurrent.DisruptorExecutor;

public abstract class LocalDungeonScene extends AbstractLocalScene implements
        IDungeon{
    private static final Logger logger = LoggerFactory
            .getLogger(LocalDungeonScene.class);

    // --- 副本生命周期 ---
    private boolean isAlive;

    private final ICanEnterCounter canEnterCounter;

    private final ICanEnterCounter inDungeonCounter;

    public LocalDungeonScene(DungeonSceneData sceneData, int uuid,
            IClusterLocalDungeonService dungeonService, ISender combatClient,
            long heroID){
        super(sceneData, sceneData.newDungeonID(), uuid, dungeonService,
                combatClient);
        this.canEnterCounter = new MultiCanEnterCounter();
        this.canEnterCounter.add(heroID);
        this.inDungeonCounter = new MultiCanEnterCounter();
        this.inDungeonCounter.add(heroID);

        this.isAlive = true;
    }

    @Override
    public void addHero(AbstractHeroFightModule heroFightModule, long ctime,
            boolean isEnteringFirstScene){
        super.addHero(heroFightModule, ctime, isEnteringFirstScene);

        if (hasDisconnected){
            // 与Combat服连接已经断开
            heroFightModule
                    .sendMessage(ClusterClientMessages.dungeonDisconnected);
            heroFightModule.doLeaveDungeon();
            logger.warn(
                    "LocalDungeonScene.addHero时, 场景已经hasDisconnected: {} heroID: {}",
                    getSceneData(), heroFightModule.getID());
            return;
        }

        if (heroFightModule instanceof HeroFightModule){
            HeroFightModule hfm = (HeroFightModule) heroFightModule;
            hfm.getServices()
                    .getModules()
                    .getTaskCallbackModule()
                    .tryCompleteTaskOnEnterScene(getSceneData(), hfm.getHero(),
                            hfm.getSender(), hfm.getHeroMiscModule());
        }
    }

    @Override
    public int getCurrentLineNumber(){
        return 1;
    }

    @Override
    public abstract DungeonSceneData getSceneData();

    @Override
    public void processHeroSceneMessage(HeroFightModule heroFightModule,
            ChannelBuffer buffer, int sequenceID){
        switch (sequenceID){
        // 副本不给查周围的队伍和玩家
            case SceneMessages.C2S_GET_SURROUNDING_TEAM:{
                heroFightModule
                        .sendMessage(ERROR_GET_SURROUNDING_TEAM_NOT_IN_NORMAL_SCENE);
                return;
            }

            case SceneMessages.C2S_GET_SURROUNDING_HERO:{
                heroFightModule
                        .sendMessage(ERROR_GET_SURROUNDING_HERO_NOT_IN_NORMAL_SCENE);
                return;
            }

            case SceneMessages.C2S_SCENE_GET_LINE_INFO:{
                // 请求线信息, 无视
                return;
            }

            case SceneMessages.C2S_SCENE_REQUEST_TRANSPORT:{
                heroFightModule
                        .sendMessage(SceneMessages.ERR_HERO_TRANSPORT_FAIL_NOT_FOUND);
                return;
            }

            // npc传送
            case SceneMessages.C2S_SCENE_REQUEST_NPC_TRANSPORT:{
                heroFightModule
                        .sendMessage(SceneMessages.ERR_TP_NPC_ID_INVALID);
                return;
            }

            // 切线
            case SceneMessages.C2S_SCENE_CHANGE_LINE:{
                heroFightModule
                        .sendMessage(SceneMessages.ERR_CHANGE_LINE_NOT_IN_NORMAL);
                return;
            }

            // 地图传送
            case SceneMessages.C2S_SCENE_MAP_TRANSPORT:{
                heroFightModule
                        .sendMessage(ERR_MAP_TRANSPORT_FAIL_NOT_IN_NORMAL_SCENE);
                return;
            }

            // 援助传送
            case SceneMessages.C2S_SCENE_ASSIST_TRANSPORT:{
                logger.warn("援助传送，英雄不在普通场景");
                heroFightModule
                        .sendMessage(ERR_SCENE_ASSIST_TP_FAIL_NOT_IN_NORMAL_SCENE);
                return;
            }

            default:{
                super.processHeroSceneMessage(heroFightModule, buffer,
                        sequenceID);
            }
        }
    }

    /**
     * 删除所有用这个exec的英雄. 只有还在加载中的不删除, 等加载完成后删除
     * @param exec
     */
    @Override
    public void processServerDisconnected(DisruptorExecutor exec){
        hasDisconnected = true; // 每个线程都会设置一次, 也不需要volatile了

        // 把所有是这个线程的英雄都移出场景
        for (AbstractHeroFightModule hfm : getAllHeroes()){
            if (hfm.isSameExec(exec)){
                hfm.sendMessage(ClusterClientMessages.dungeonDisconnected);
                hfm.doLeaveDungeon();
            }
        }

        // 可能副本里本来就只有离线的人
        synchronized (this){
            if (!isAlive){
                // 删除英雄的时候已经导致副本dead了
                return;
            }

            // 还有人
            if (inDungeonCounter.hasCanEnter()){
                return;
            }

            isAlive = false;
        }

        dungeonService.removeDungeon(uuid);
    }

    @Override
    public void removeHero(AbstractHeroFightModule heroFightModule,
            boolean isOffline){
        super.removeHero(heroFightModule, isOffline);
        heroLeave(heroFightModule.getID(), isOffline); // 离开时, 发送了消息给combat服了
    }

    // --- 生命周期 ---

    /**
     * 下线重登, 是否还能再进入这个副本. 如果canEnterCounter里没有这个英雄了, 则不能进.
     *
     * 如果此副本已经断线了, 会把英雄从canEnterCounter里去掉
     * @param heroID
     * @return
     */
    @Override
    public boolean markAboutEnterOnOnline(long heroID){
        synchronized (this){
            if (!isAlive){
                return false;
            }

            if (hasDisconnected){
                return false;
            }

            if (!canEnterCounter.canHeroEnter(heroID)){
                // 防止火麟洞下线重登时还能再进
                return false;
            }

            canEnterCounter.add(heroID);
            inDungeonCounter.add(heroID);

            // 发消息告诉Combat服
            combatClient.sendMessage(ClusterSceneHeader
                    .onlySendHeadAndAVarInt64Message(
                            ClusterSceneHeader.S2C_HERO_ABOUT_TO_COME, uuid,
                            heroID));
            return true;
        }
    }

    /**
     * 返回是否还能进入这个副本.
     * @param heroID
     * @return
     */
    @MultiThread
    public boolean markAboutEnter(long heroID){
        synchronized (this){
            if (!isAlive){
                return false;
            }

            canEnterCounter.add(heroID);
            inDungeonCounter.add(heroID);

            // 发消息告诉Combat服
            combatClient.sendMessage(ClusterSceneHeader
                    .onlySendHeadAndAVarInt64Message(
                            ClusterSceneHeader.S2C_HERO_ABOUT_TO_COME, uuid,
                            heroID));
            return true;
        }
    }

    @Override
    @MultiThread
    public void markOfflineWhenLoading(long heroID){
        synchronized (this){
            assert isAlive;
            assert canEnterCounter.canHeroEnter(heroID);

            inDungeonCounter.remove(heroID);

            if (hasDisconnected){
                // 如果已经断线了, 加载中离线也已不让再进了
                canEnterCounter.remove(heroID);

                if (!inDungeonCounter.hasCanEnter()){
                    // 场景已经再见了
                    isAlive = false;
                    // 跳到最后同步块外面删除场景
                } else{
                    return;
                }
            } else{
                // 发消息告诉Combat服
                combatClient
                        .sendMessage(ClusterSceneHeader
                                .onlySendHeadAndAVarInt64Message(
                                        ClusterSceneHeader.S2C_HERO_OFFLINE_WHEN_LOADING,
                                        uuid, heroID));
                return;
            }
        }

        // 这里是需要从dungeonService中删除副本的, 只有场景已断线, 且这是最后一个英雄了, 才会到这里
        dungeonService.removeDungeon(uuid);
    }

    /**
     * 被调用前, 需要把英雄从positionModule中删除
     * @param heroID
     * @param isOfflineAndNeedKeep
     */
    @MultiThread
    private void heroLeave(long heroID, boolean isOfflineAndNeedKeep){
        assert localHeroes.get(heroID) == null;
        synchronized (this){
            if (!isAlive){
                // 为毛? 又不会过期
                logger.error("LocalDungeonScene.heroLeave时, 副本已经!isAlive.");
                return;
            }

            assert canEnterCounter.canHeroEnter(heroID);

            inDungeonCounter.remove(heroID);

            if (isOfflineAndNeedKeep && !hasDisconnected){
                // 下线
                // 发消息告诉Combat服
                combatClient.sendMessage(ClusterSceneHeader
                        .onlySendHeadAndAVarInt64Message(
                                ClusterSceneHeader.S2C_HERO_OFFLINE, uuid,
                                heroID));
                return;
            }

            // 离开场景
            canEnterCounter.remove(heroID);

            if (!hasDisconnected){
                // 发消息告诉Combat服
                combatClient
                        .sendMessage(ClusterSceneHeader
                                .onlySendHeadAndAVarInt64Message(
                                        ClusterSceneHeader.S2C_HERO_LEAVE,
                                        uuid, heroID));
            }

            if (!canEnterCounter.hasCanEnter()){
                // 场景已经再见了
                isAlive = false;
                // 跳到最后同步块外面删除场景
            } else{
                return;
            }
        }

        // 这里是需要从dungeonService中删除副本的
        dungeonService.removeDungeon(uuid);
    }

    /**
     * Combat服让英雄离开场景
     *
     * @param buffer
     */
    private void onHeroLeave(ChannelBuffer buffer){
        long heroID = readVarInt64(buffer);

        final HeroController hc = dungeonService.getWorldService()
                .getHeroController(heroID);
        if (hc == null){
            logger.warn(
                    "LocalDungeonScene.onHeroLeave时, 没有找到Combat服让离开场景的英雄. 正好下线了? id: {}",
                    heroID);
            return;
        }

        hc.getExecutor().execute(new Runnable(){
            @Override
            public void run(){
                if (hc.getIsOffline().get()){
                    // 运行到的时候已经下线了, 不处理
                    return;
                }

                HeroFightModule hfm = hc.getHeroFightModule();
                if (!hfm.isInScene(LocalDungeonScene.this)){
                    // 英雄已经不在这场景了
                    logger.warn("LocalDungeonScene.onHeroLeave时, 英雄已经不在这场景了... 正好切场景了?");
                    return;
                }

                hfm.doLeaveDungeon();
            }
        });
    }

    /**
     * 处理来自Combat服的过期消息, synchronized内, 如果inDungeonCounter为空, 则销毁副本
     */
    public void onDungeonExpiredOnCombatServer(){
        synchronized (this){
            if (!isAlive){
                // 可能正好所有人都出去了
                return;
            }

            if (inDungeonCounter.hasCanEnter()){
                logger.warn("副本在Combat服过期, 在游戏服内还有人在, 这么巧正好有人进, Combat服还没有收到这个人进入的消息?");
                return;
            }

            logger.debug("副本在Combat服过期, 销毁副本: {}", this);
            isAlive = false;
        }
        dungeonService.removeDungeon(uuid);
    }

    // --- 处理Combat服过来的消息 ---

    /**
     * 处理来自Combat服发送给这个场景, 让这个场景处理的消息
     * @param header
     * @param buffer
     * @param client
     */
    @Override
    public void onSceneMessage(ClusterSceneHeader header, ChannelBuffer buffer){
        switch (header){
            case C2S_SCENE_EXPIRED:{
                onDungeonExpiredOnCombatServer();
                return;
            }

            case C2S_HERO_LEAVE:{
                onHeroLeave(buffer);
                return;
            }

            default:{
                super.onSceneMessage(header, buffer);
            }
        }
    }

}
