package app.cluster.client.logic.team;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.data.scene.GroupDungeonSceneData;
import app.message.ISender;
import app.utils.VariableConfig;

import com.mokylin.collection.LongConcurrentSynchronizedHashMap;

/**
 * 某个场景的组队信息. 接收master的组队广播, 并转发给监听着的玩家.
 * 有人注册则马上发送上一次收到的广播
 *
 * @author Timmy
 *
 */
public class ClusterClientTeamMatcher{

    private final LongConcurrentSynchronizedHashMap<ISender> listeners;

    final GroupDungeonSceneData sceneData;

    /**
     * 当前的队伍列表消息
     */
    private ChannelBuffer msgToBroadcast;

    /**
     * 总共存在的队伍数. 在各个服务器本地判断是否可注册, 队伍数不是个硬性的非常强的约束
     */
    volatile int totalTeamCount;

    ClusterClientTeamMatcher(GroupDungeonSceneData sceneData){
        this.sceneData = sceneData;
        this.listeners = new LongConcurrentSynchronizedHashMap<>();
    }

    void register(long heroID, ISender sender){
        // 先发送成功消息, 和上次的广播信息, 再放入map中
        sender.sendMessage(ClusterClientMessages.registerSuccess);
        if (msgToBroadcast != null){
            sender.sendMessage(msgToBroadcast);
        }
        listeners.put(heroID, sender);
    }

    /**
     * 帮玩家注册, 但不要发送注册成功以及初始的队伍列表
     * @param heroID
     * @param sender
     */
    void registerWithoutSentAnyMsg(long heroID, ISender sender){
        listeners.put(heroID, sender);
    }

    public void unregister(long heroID){
        listeners.remove(heroID);
    }

    boolean canCreateMoreTeam(){
        return totalTeamCount < VariableConfig.GROUP_DUNGEON_CLUSTER_TEAM_LIMIT;
    }

    void updateTeamList(int totalTeamCount, ChannelBuffer buffer){
        this.msgToBroadcast = ClusterClientMessages.refreshTeamList(buffer);
        this.totalTeamCount = totalTeamCount;

        for (ISender s : listeners.values()){
            s.sendMessage(msgToBroadcast);
        }
    }

    void onMasterDisconnected(){
        this.msgToBroadcast = null;
        this.totalTeamCount = Integer.MAX_VALUE;

        for (ISender s : listeners.values()){
            s.sendMessage(ClusterClientMessages.clearTeamListMsg);
        }
    }
}
