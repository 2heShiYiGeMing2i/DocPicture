package app.cluster.client.combat.scene;

import static com.mokylin.sink.util.BufferUtil.readVarInt32;

import org.jboss.netty.buffer.ChannelBuffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.cluster.client.logic.team.ClusterClientMessages;
import app.cluster.shared.scene.ClusterSceneHeader;
import app.game.data.scene.GroupDungeonPrizeConfig;
import app.game.data.scene.GroupDungeonSceneData;
import app.game.module.scene.AbstractHeroFightModule;
import app.game.module.scene.HeroFightModule;
import app.game.module.scene.IClusterLocalDungeonService;
import app.message.ISender;
import app.protobuf.DungeonContent.GroupDungeonCollectablePrizeProto;

import com.mokylin.collection.IntValueLongConcurrentHashMap;
import com.mokylin.collection.LongConcurrentSynchronizedHashMap;
import com.mokylin.sink.util.concurrent.PaddedAtomicBoolean;

/**
 * 在游戏服上的组队副本
 * 保存英雄获得的杀怪经验, 是否已完成, 是否可领取奖励之类的信息
 * @author Timmy
 *
 */
public abstract class LocalGroupDungeonScene extends LocalDungeonScene{
    private static final Logger logger = LoggerFactory
            .getLogger(LocalGroupDungeonScene.class);

    private final GroupDungeonSceneData sceneData;

    private final IntValueLongConcurrentHashMap perHeroExpCounter;

    /**
     * 可领取副本完成奖励的人
     */
    private final LongConcurrentSynchronizedHashMap<GroupDungeonPrizeStage> prizeStages;

    private final PaddedAtomicBoolean finished;

    public LocalGroupDungeonScene(GroupDungeonSceneData sceneData, int uuid,
            IClusterLocalDungeonService dungeonService, ISender combatClient,
            long heroID){
        super(sceneData, uuid, dungeonService, combatClient, heroID);

        this.sceneData = sceneData;
        this.finished = new PaddedAtomicBoolean(false);

        if (sceneData.getPrizeConfig() != null){
            this.prizeStages = new LongConcurrentSynchronizedHashMap<>(8);
            this.perHeroExpCounter = new IntValueLongConcurrentHashMap();
        } else{
            this.prizeStages = null;
            this.perHeroExpCounter = null;
        }
    }

    @Override
    public GroupDungeonSceneData getSceneData(){
        return sceneData;
    }

    @Override
    public void removeHero(AbstractHeroFightModule heroFightModule,
            boolean isOffline){
        super.removeHero(heroFightModule, isOffline);

        // 如果有奖励可领, 加入到临时奖励里
        if (hasDungeonPrizeStage()){
            GroupDungeonPrizeStage prizeStage = getDungeonPrizeStage(heroFightModule
                    .getID());
            if (prizeStage != null){
                if (!prizeStage.isPrizeCollected){
                    prizeStage.isPrizeCollected = true;
                    // 还没有领取, 放到临时背包
                    GroupDungeonCollectablePrizeProto collectablePrizeProto = prizeStage
                            .getAsTempPrize(getCurrentTime());

                    heroFightModule.getHero().addGroupDungeonCollectablePrize(
                            collectablePrizeProto);
                    if (!isOffline){
                        heroFightModule.sendMessage(ClusterClientMessages
                                .addCollectablePrize(collectablePrizeProto));
                    }
                }
            }
        }
    }

    @Override
    public void onHeroAddMonsterDeadExp(HeroFightModule heroFightModule,
            int amount){
        super.onHeroAddMonsterDeadExp(heroFightModule, amount);

        if (perHeroExpCounter != null && amount > 0){
            perHeroExpCounter.increment(heroFightModule.getID(), amount);
        }
    }

    // --- 统一副本奖励 ---    
    /**
    * 是否有统一的完成奖励
    * @return
    */
    public boolean hasDungeonPrizeStage(){
        return prizeStages != null;
    }

    public GroupDungeonPrizeStage getDungeonPrizeStage(long heroID){
        return prizeStages.get(heroID);
    }

    /**
     * 开始英雄的统一给奖励流程.
     * @param heroFightModule
     * @param ctime
     * @return true 之前英雄并没有设为完成. false 英雄之前已经完成了, 调用了没有效果
     */
    protected boolean onDungeonFinishStartGiveDungeonPrize(
            AbstractHeroFightModule heroFightModule, long ctime, int deadCount,
            int duration){
        assert hasDungeonPrizeStage(): "组队副本没有完成奖励, 但还是调用了onDungeonFinishStartGiveDungeonPrize(HeroFightModule, long)";

        if (prizeStages.containsKey(heroFightModule.getID())){
            return false;
        }

        GroupDungeonPrizeConfig prizeConfig = getSceneData().getPrizeConfig();
        int score = prizeConfig.calculateScore(duration, deadCount);

        int exp = perHeroExpCounter.get(heroFightModule.getID());
        if (exp < 0){
            exp = 0;
        }

        GroupDungeonPrizeStage prizeStage = new GroupDungeonPrizeStage(
                prizeConfig, score, duration, deadCount, exp);

        boolean added = prizeStages.putIfAbsent(heroFightModule.getID(),
                prizeStage) == null;
        if (added){
            heroFightModule
                    .sendMessage(ClusterClientMessages.dungeonCompleteWithPrize);
            return true;
        } else{
            return false;
        }

    }

    // --- 处理Combat服过来的消息 ---

    protected abstract void onFinished(int deadCount, int totalDuration);

    /**
     * 处理来自Combat服发送给这个场景, 让这个场景处理的消息
     * @param header
     * @param buffer
     * @param client
     */
    @Override
    public void onSceneMessage(ClusterSceneHeader header, ChannelBuffer buffer){
        switch (header){
            case C2S_DUNGEON_FINISHED:{
                if (!finished.compareAndSet(false, true)){
                    logger.error("LocalGroupDungeonScene.收到C2S_DUNGEON_FINISHED, 但是副本已经是完成状态了. 重复发送了?");
                    return;
                }

                int deadCount = readVarInt32(buffer);
                int duration = readVarInt32(buffer);

                if (duration <= 0){
                    duration = 300; // 有bug就当300秒
                    logger.error(
                            "LocalGroupDungeonScene收到的副本完成耗时<=0: {} -> {}",
                            sceneData, duration);
                }
                onFinished(deadCount, duration);
                return;
            }

            default:{
                super.onSceneMessage(header, buffer);
            }
        }
    }
}
