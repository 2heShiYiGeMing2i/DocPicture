package app.cluster.client.logic.team;

import static app.cluster.client.logic.team.ClusterClientMessages.*;
import static app.protobuf.LogContent.LogEnum.OperateObject.DUNGEON;
import static app.protobuf.LogContent.LogEnum.OperateType.*;
import static com.mokylin.sink.util.BufferUtil.*;

import java.util.ArrayList;
import java.util.List;

import org.jboss.netty.buffer.ChannelBuffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.cluster.client.GroupClient;
import app.cluster.client.combat.scene.GroupDungeonPrizeStage;
import app.cluster.client.combat.scene.LocalGroupDungeonScene;
import app.cluster.group.codec.GroupHeader;
import app.game.data.ConfigService;
import app.game.data.Prize;
import app.game.data.Vip;
import app.game.data.goods.GoodsAddHelper;
import app.game.data.goods.GoodsTryAddResult;
import app.game.data.goods.GoodsWrapper;
import app.game.data.scene.GroupDungeonPrizeConfig;
import app.game.data.scene.GroupDungeonSceneData;
import app.game.data.scene.GroupDungeonsWithPrizeConfig;
import app.game.data.scene.SceneData;
import app.game.data.scene.SceneDatas;
import app.game.entity.Hero;
import app.game.entity.User;
import app.game.module.ConnectedUser;
import app.game.module.GoodsContainerModule;
import app.game.module.HeroController;
import app.game.module.HeroMiscModule;
import app.game.module.scene.HeroFightModule;
import app.game.module.scene.IScene;
import app.game.service.ExecutorRelatedService;
import app.game.service.TimeService;
import app.game.service.WorldService;
import app.game.service.log.LogService;
import app.protobuf.DungeonContent.GroupDungeonCollectablePrizeProto;
import app.protobuf.DungeonContent.GroupDungeonFinishStatProto;
import app.protobuf.HeroServerContent.GoodsWrapperServerProto;
import app.utils.VariableConfig;

import com.google.inject.Inject;
import com.google.protobuf.ByteString;
import com.mokylin.collection.IntHashMap;
import com.mokylin.sink.util.BufferUtil;
import com.mokylin.sink.util.Func;

/**
 * 负责跨服组队的模块
 * @author Timmy
 *
 */
public class ClusterClientTeamModule{
    private static final Logger logger = LoggerFactory
            .getLogger(ClusterClientTeamModule.class);

    private final IntHashMap<ClusterClientTeamMatcher> matchers;

    private final GroupClient groupClient;

    private final WorldService worldService;

    private final ExecutorRelatedService executorRelatedService;

    private final LogService logService;

    private final TimeService timeService;

    private final ConfigService configService;

    private final GoodsContainerModule goodsContainerModule;

    /**
     * 有完成奖励的
     */
    private final GroupDungeonsWithPrizeConfig prizeConfigBySceneID;

    @Inject
    ClusterClientTeamModule(GroupClient groupClient, SceneDatas sceneDatas,
            LogService logService, TimeService timeService,
            WorldService worldService,
            ExecutorRelatedService executorRelatedService,
            ConfigService configService,
            GoodsContainerModule goodsContainerModule,
            GroupDungeonsWithPrizeConfig prizeConfigs){
        this.groupClient = groupClient;
        this.logService = logService;
        this.timeService = timeService;
        this.worldService = worldService;
        this.executorRelatedService = executorRelatedService;

        this.configService = configService;
        this.goodsContainerModule = goodsContainerModule;
        this.prizeConfigBySceneID = prizeConfigs;

        this.matchers = new IntHashMap<>();

        for (SceneData sceneData : sceneDatas.getAll()){
            if (sceneData instanceof GroupDungeonSceneData){
                GroupDungeonSceneData groupSceneData = (GroupDungeonSceneData) sceneData;
                ClusterClientTeamMatcher matcher = new ClusterClientTeamMatcher(
                        groupSceneData);
                matchers.put(groupSceneData.id, matcher);
            }
        }
    }

    public void onMessage(int sequenceID, ChannelBuffer buffer,
            HeroController hc, HeroFightModule heroFightModule){
        switch (sequenceID){
            case C2S_REGISTER:{
                onRegister(buffer, hc, heroFightModule);
                return;
            }

            case C2S_UNREGISTER:{
                onUnregister(buffer, hc, heroFightModule);
                return;
            }

            case C2S_CREATE_GROUP:{
                onCreateGroup(buffer, hc, heroFightModule);
                return;
            }

            case C2S_LEAVE:{
                onLeaveGroup(buffer, hc, heroFightModule);
                return;
            }

            case C2S_JOIN_GROUP:{
                onJoinGroup(buffer, hc, heroFightModule);
                return;
            }

            case C2S_READY:{
                onReady(buffer, hc, heroFightModule);
                return;
            }

            case C2S_CANCEL_READY:{
                onCancelReady(buffer, hc, heroFightModule);
                return;
            }

            case C2S_KICK:{
                onKick(buffer, hc, heroFightModule);
                return;
            }

            case C2S_START:{
                onStart(buffer, hc, heroFightModule);
                return;
            }

            case C2S_AUTO_ENTER_GROUP:{
                onAutoEnterGroup(buffer, hc, heroFightModule);
                return;
            }

            case C2S_GET_PRIZE_STAT:{
                onGetPrizeStat(buffer, hc, heroFightModule);
                return;
            }

            case C2S_COLLECT_DUNGEON_PRIZE:{
                onCollectDungeonPrize(buffer, hc, heroFightModule);
                return;
            }

            case C2S_COLLECT_TEMP_PRIZE:{
                onCollectTempPrize(buffer, hc, heroFightModule);
                return;
            }

            case C2S_DISPLAY_TEAM_INVITE:{
                onDisplayTeamInvite(buffer, hc, heroFightModule);
                return;
            }
            default:{
                logger.warn("ClusterClientTeamModule收到未知的消息: {}", sequenceID);
            }
        }
    }

    // --- 处理来自客户端的消息 ---

    private void onDisplayTeamInvite(ChannelBuffer buffer, HeroController hc,
            HeroFightModule heroFightModule){
        ClusterClientTeamMember member = heroFightModule
                .getGroupDungeonMember();
        if (member == null){
            hc.sendMessage(ERROR_DISPLAY_TEAM_INVITE_NO_TEAM);
            return;
        }

        if (member.hasStarted()){
            hc.sendMessage(ERROR_DISPLAY_TEAM_INVITE_STARTED);
            return;
        }

        long ctime = timeService.getCurrentTime();
        if (ctime < hc.nextCanDisplayTeamTime){
            hc.sendMessage(ERROR_DISPLAY_TEAM_INVITE_TOO_FREQUENT);
            return;
        }

        // 发给master去问队伍的具体信息
        boolean msgSent = groupClient.sendMessage(GroupHeader.displayMyGroup(
                member.getSceneConfigID(), hc.combinedID));
        if (!msgSent){
            hc.sendMessage(ERROR_DISPLAY_TEAM_INVITE_NO_TEAM); // 没有master, 马上会退出队伍的
            return;
        }

        hc.nextCanDisplayTeamTime = ctime
                + VariableConfig.GROUP_DUNGEON_CLUSTER_DISPLAY_CD;

        // 等master返回
    }

    public void processReplyDisplayTeamInviteFail(long heroID, int errCode){
        HeroController hc = worldService.getHeroController(heroID);
        if (hc == null){
            // 下线了, 不管了
            return;
        }

        hc.nextCanDisplayTeamTime = timeService.getCurrentTime() + 1000; // 让他再来吧

        switch (errCode){
            case GroupHeader.ERROR_REPLY_YOUR_GROUP_NO_TEAM:{
                hc.sendMessage(ERROR_DISPLAY_TEAM_INVITE_NO_TEAM);
                return;
            }

            case GroupHeader.ERROR_REPLY_YOUR_GROUP_TEAM_FULL:{
                hc.sendMessage(ERROR_DISPLAY_TEAM_INVITE_TEAM_FULL);
                return;
            }

            default:{
                logger.error(
                        "ClusterClientTeamModule.processReplyDisplayTeamInviteFail 收到了没有处理的errorCode: {}",
                        errCode);
                hc.sendMessage(ERROR_DISPLAY_TEAM_INVITE_NO_TEAM);
                return;
            }
        }
    }

    public void processReplyDisplayTeamInvite(long heroID, int dungeonID,
            int teamID, int requiredFightAmount){
        HeroController hc = worldService.getHeroController(heroID);
        if (hc == null){
            // 下线了, 不管了
            return;
        }

        hc.sendMessage(displayTeamInviteSuccess);

        worldService.broadcastToEnteredFirstSceneHero(
                displayTeamInvite(heroID, hc.getHero().getNameBytes(),
                        dungeonID, teamID, requiredFightAmount), 0);
    }

    private void onAutoEnterGroup(ChannelBuffer buffer, HeroController hc,
            HeroFightModule heroFightModule){
        if (!heroFightModule.isParentNormalScene()){
            hc.sendMessage(ERROR_AUTO_ENTER_GROUP_IN_DUNGEON);
            return;
        }

        if (heroFightModule.getGroupDungeonMember() != null){
            hc.sendMessage(ERROR_AUTO_ENTER_GROUP_IN_GROUP);
            return;
        }

        final int dungeonID = readVarInt32(buffer);

        ClusterClientTeamMatcher matcher = matchers.get(dungeonID);
        if (matcher == null){
            hc.sendMessage(ERROR_AUTO_ENTER_GROUP_ID_NOT_FOUND);
            return;
        }

        Hero hero = hc.getHero();
        if (hero.getLevel() < matcher.sceneData.requiredLevel){
            hc.sendMessage(ERROR_AUTO_ENTER_GROUP_NOT_ENOUGH_LEVEL);
            return;
        }

        if (!matcher.sceneData.canHeroEnterToday(hero)){
            hc.sendMessage(ERROR_AUTO_ENTER_GROUP_TODAY_ENTER_LIMIT_REACHED);
            return;
        }

        // 看下频率
        long ctime = timeService.getCurrentTime();
        if (ctime < hc.nextCanAutoJoinGroupTime){
            hc.sendMessage(ERROR_AUTO_ENTER_GROUP_TOO_FREQUENT);
            return;
        }

        // 发送请求到master
        boolean msgSent = groupClient.sendMessage(GroupHeader.autoJoinGroup(
                dungeonID, hero));
        if (!msgSent){
            hc.sendMessage(ERROR_JOIN_GROUP_MASTER_DISCONNECTED);
            return;
        }

        hc.nextCanAutoJoinGroupTime = ctime
                + VariableConfig.GROUP_DUNGEON_CLUSTER_AUTO_JOIN_CD;

        // 发送成功, 这里先不发送给玩家入队结果

        // 先解除注册监听的副本, 如果入队失败, 则再自动帮玩家注册
        ClusterClientTeamMatcher listeningMatcher = heroFightModule
                .getListeningGroupDungeonMatcher();
        if (listeningMatcher != null){
            listeningMatcher.unregister(hc.combinedID);
            heroFightModule.setListeningGroupDungeonMatcher(null);
        }

        // 把队伍先设置了
        heroFightModule.setGroupDungeonMember(new ClusterClientTeamMember(
                matcher.sceneData, hc.combinedID, groupClient));
    }

    private void onCollectTempPrize(ChannelBuffer buffer, HeroController hc,
            HeroFightModule heroFightModule){
        int pos = BufferUtil.readVarInt32(buffer);
        Hero hero = hc.getHero();
        if (pos < 0 || pos >= hero.getGroupDungeonCollectablePrizeSize()){
            logger.warn(
                    "GroupDungeonModule.onCollectTempPrize时, 发来的pos非法. 共{}个, 要领第{}个",
                    hero.getGroupDungeonCollectablePrizeSize(), pos);
            hc.sendMessage(ERROR_COLLECT_TEMP_PRIZE_ILLEGAL_POS);
            return;
        }

        GroupDungeonCollectablePrizeProto prizeProto = hero
                .getGroupDungeonCollectablePrize(pos);

        GroupDungeonPrizeConfig prizeConfig = prizeConfigBySceneID
                .get(prizeProto.getDungeonId());
        if (prizeConfig == null){
            logger.error("GroupDungeonModule.onCollectTempPrize时, 竟然有奖励里的dungeonID是没有组队奖励的. 英雄decode时应该检查了. 给他发领取成功并删除, 希望玩家没发现");
            hero.removeGroupDungeonCollectablePrize(pos);
            hc.sendMessage(collectTempPrizeSuccess);
            return;
        }

        long ctime = timeService.getCurrentTime();
        List<GoodsAddHelper> goods = newPrizeGoods(prizeConfig, prizeProto,
                hero.getVip(), ctime);

        // 检查能否放下
        GoodsTryAddResult result = hero.getDepot().canAddGoods(goods);
        if (!result.isSuccess()){
            hc.sendMessage(ERROR_COLLECT_TEMP_PRIZE_BAG_FULL);
            return;
        }

        // 能放下

        hero.removeGroupDungeonCollectablePrize(pos);

        // TODO
        String iEventId = logService.newTodoEventId();

        HeroMiscModule heroMiscModule = hc.getHeroMiscModule();
        goodsContainerModule.addBatchGoodsList(goods, result, hero,
                hc.getSender(), heroMiscModule, COLLECT_DUNGEON_TEMP_PRIZE,
                prizeConfig.sceneData.id, ctime);

        prizeConfig.getFixedPrize().giveIgnoreGoods(heroMiscModule, hero,
                false, COLLECT_DUNGEON_TEMP_PRIZE, iEventId);
        hc.sendMessage(collectTempPrizeSuccess);

        logService.todo();
//        logService.writeOperateLog(COLLECT_DUNGEON_TEMP_PRIZE, DUNGEON,
//                prizeConfig.sceneData.id, prizeConfig.sceneData.getIntType(),
//                0, 0, 0, hc.getHero());
    }

    private List<GoodsAddHelper> newPrizeGoods(
            GroupDungeonPrizeConfig prizeConfig,
            GroupDungeonCollectablePrizeProto proto, Vip vip, long ctime){
        Prize fixedPrize = prizeConfig.getFixedPrize();
        GoodsWrapper[] fixedPrizeGoodsWrapper = fixedPrize.getGoodsWrappers();
        List<GoodsAddHelper> result = new ArrayList<>(
                fixedPrizeGoodsWrapper.length + 2);

        for (GoodsWrapper w : fixedPrizeGoodsWrapper){
            result.add(w.newHelper(ctime));
        }

        if (vip != null && vip.hasStoryExtraPrize()){
            if (!proto.hasRandomedVipPrize()){
                result.add(prizeConfig.getRandomPrizeV5().newHelper(ctime));
            } else{
                GoodsWrapper gw = decodeGoodsWrapper(proto
                        .getRandomedVipPrize());
                if (gw != null){
                    result.add(gw.newHelper(ctime));
                } else{
                    result.add(prizeConfig.getRandomPrizeV5().newHelper(ctime));
                }
            }
        }

        if (!proto.hasNoScoreSPrize()){
            if (!proto.hasRandomedSPrize()){
                result.add(prizeConfig.getRandomPrizeS().newHelper(ctime));
            } else{
                GoodsWrapper gw = decodeGoodsWrapper(proto.getRandomedSPrize());
                if (gw != null){
                    result.add(gw.newHelper(ctime));
                } else{
                    result.add(prizeConfig.getRandomPrizeS().newHelper(ctime));
                }
            }
        }

        return result;
    }

    private GoodsWrapper decodeGoodsWrapper(ByteString bs){
        try{
            GoodsWrapperServerProto proto = GoodsWrapperServerProto.parseFrom(
                    bs, User.extensionRegistry);
            return GoodsWrapper.decode(proto, configService);
        } catch (Throwable ex){
            logger.error("LingYunDungeonModule.decodeGoodsWrapper报错", ex);
            return null;
        }
    }

    private void onCollectDungeonPrize(ChannelBuffer buffer, HeroController hc,
            HeroFightModule heroFightModule){
        if (!heroFightModule.isInAndEnteredDungeon()){
            logger.warn("ClusterClientTeamModule.onCollectDungeonPrize时, 英雄当前不在副本中. 要么还在加载, 要么parent不是副本");
            hc.sendMessage(ERROR_COLLECT_DUNGEON_PRIZE_NOT_IN_GROUP_DUNGEON);
            return;
        }

        IScene parent = heroFightModule.getParent();
        if (!(parent instanceof LocalGroupDungeonScene)){
            logger.warn(
                    "ClusterClientTeamModule.onCollectDungeonPrize时, 英雄的parent不是个组队副本: {}",
                    parent);
            hc.sendMessage(ERROR_COLLECT_DUNGEON_PRIZE_NOT_IN_GROUP_DUNGEON);
            return;
        }

        LocalGroupDungeonScene groupScene = (LocalGroupDungeonScene) parent;
        if (!groupScene.hasDungeonPrizeStage()){
            logger.warn(
                    "ClusterClientTeamModule.onCollectDungeonPrize时, 英雄的parent不是个有统一完成奖励的组队副本: {}",
                    parent);
            hc.sendMessage(ERROR_COLLECT_DUNGEON_PRIZE_NOT_IN_GROUP_DUNGEON);
            return;
        }

        GroupDungeonPrizeStage prizeStage = groupScene
                .getDungeonPrizeStage(hc.combinedID);
        if (prizeStage == null){
            hc.sendMessage(ERROR_COLLECT_DUNGEON_PRIZE_NOT_COLLECTABLE);
            return;
        }

        if (prizeStage.isPrizeCollected){
            logger.warn("ClusterClientTeamModule.onCollectDungoenPrize时, 奖励已经领过了. 客户端没加锁?");
            hc.sendMessage(ERROR_COLLECT_DUNGEON_PRIZE_NOT_COLLECTABLE);
            return;
        }

        if (!prizeStage.repliedStat){
            logger.warn("ClusterClientTeamModule.onCollectDungeonPrize时, 客户端还未请求过副本的奖励数据");
            prizeStage.randomPrize(hc.getHero().getVip());
        }

        prizeStage.isPrizeCollected = true;
        long ctime = timeService.getCurrentTime();
        List<GoodsAddHelper> prizeGoods = prizeStage.getPrizeGoods(ctime);

        // 检查物品是否能全放入
        GoodsTryAddResult result = hc.getDepot().canAddGoods(prizeGoods);
        if (!result.isSuccess()){
            hc.sendMessage(ERROR_COLLECT_DUNGEON_PRIZE_BAG_FULL);
            heroFightModule.doLeaveDungeon();
            // 背包不够, 再离开副本时, 加入到临时副本背包
            return;
        }

        String iEventId = logService.newTodoEventId();

        HeroMiscModule heroMiscModule = hc.getHeroMiscModule();

        goodsContainerModule.addBatchGoodsList(prizeGoods, result,
                hc.getHero(), hc.getSender(), heroMiscModule,
                COLLECT_DUNGEON_PRIZE, parent.getSceneConfigDataID(), ctime);

        prizeStage
                .getPrizeConfig()
                .getFixedPrize()
                .giveIgnoreGoods(heroMiscModule, heroFightModule.getHero(),
                        false, COLLECT_DUNGEON_PRIZE, iEventId);

        hc.sendMessage(collectDungeonPrizeSuccess);

        logService.todo();
//        logService.writeOperateLog(COLLECT_DUNGEON_PRIZE, DUNGEON, parent
//                .getSceneConfigDataID(), parent.getSceneData().getIntType(), 0,
//                0, 0, hc.getHero());
    }

    private void onGetPrizeStat(ChannelBuffer buffer, HeroController hc,
            HeroFightModule heroFightModule){
        if (!heroFightModule.isInAndEnteredDungeon()){
            logger.warn("ClusterClientTeamModule.onGetPrizeStat时, 英雄当前不在副本中. 要么还在加载, 要么parent不是副本");
            hc.sendMessage(ERROR_GET_PRIZE_STAT_NOT_IN_GROUP_DUNGEON);
            return;
        }

        IScene parent = heroFightModule.getParent();
        if (!(parent instanceof LocalGroupDungeonScene)){
            logger.warn(
                    "ClusterClientTeamModule.onGetDungeonStat时, 英雄的parent不是个组队副本: {}",
                    parent);
            hc.sendMessage(ERROR_GET_PRIZE_STAT_NOT_IN_GROUP_DUNGEON);
            return;
        }

        LocalGroupDungeonScene groupDungeonScene = (LocalGroupDungeonScene) parent;
        if (!groupDungeonScene.hasDungeonPrizeStage()){
            logger.warn(
                    "ClusterClientTeamModule.onGetDungeonStat时, 这个组队副本并没有完成奖励: {}",
                    parent);
            hc.sendMessage(ERROR_GET_PRIZE_STAT_NOT_IN_GROUP_DUNGEON);
            return;
        }

        GroupDungeonPrizeStage prizeStage = groupDungeonScene
                .getDungeonPrizeStage(hc.combinedID);
        if (prizeStage == null){
            hc.sendMessage(ERROR_GET_PRIZE_STAT_WRONG_STAGE);
            return;
        }

        if (prizeStage.repliedStat){
            hc.sendMessage(ERROR_GET_PRIZE_STAT_WRONG_STAGE);
            return;
        }

        GroupDungeonFinishStatProto proto = prizeStage
                .randomPrizeAndGetProto(hc.getHero().getVip());
        hc.sendMessage(getDungeonStatSuccess(proto));
    }

    private void onStart(ChannelBuffer buffer, HeroController hc,
            HeroFightModule heroFightModule){
        ClusterClientTeamMember member = heroFightModule
                .getGroupDungeonMember();
        if (member == null){
            hc.sendMessage(ERROR_START_NO_TEAM);
            return;
        }

        long ctime = timeService.getCurrentTime();
        if (ctime < hc.nextCanClusterGroupStartTime){
            hc.sendMessage(ERROR_START_TOO_FREQUENT);
            return;
        }

        boolean msgSent = groupClient.sendMessage(GroupHeader.start(
                member.getSceneConfigID(), hc.combinedID));
        if (!msgSent){
            hc.sendMessage(ERROR_START_MASTER_DISCONNECTED);
            return;
        }

        hc.nextCanClusterGroupStartTime = ctime
                + VariableConfig.GROUP_DUNGEON_CLUSTER_START_CD;

        // 成功失败都由master proxy消息
    }

    private void onKick(ChannelBuffer buffer, HeroController hc,
            HeroFightModule heroFightModule){
        ClusterClientTeamMember member = heroFightModule
                .getGroupDungeonMember();
        if (member == null){
            hc.sendMessage(ERROR_KICK_NO_TEAM);
            return;
        }

        long toKickID = readVarInt64(buffer);
        if (toKickID == hc.combinedID){
            hc.sendMessage(ERROR_KICK_CANNOT_KICK_SELF);
            return;
        }

        long ctime = timeService.getCurrentTime();

        if (ctime < hc.nextCanClusterGroupKickTime){
            hc.sendMessage(ERROR_KICK_TOO_FREQUENT);
            return;
        }

        // 发送给master
        boolean msgSent = groupClient.sendMessage(GroupHeader.kick(
                member.getSceneConfigID(), hc.combinedID, toKickID));
        if (!msgSent){
            hc.sendMessage(ERROR_KICK_MASTER_DISCONNECTED);
            return;
        }

        hc.nextCanClusterGroupKickTime = ctime
                + VariableConfig.GROUP_DUNGEON_CLUSTER_KICK_CD;

        // 成功失败都由master proxy给玩家
    }

    private void onCancelReady(ChannelBuffer buffer, HeroController hc,
            HeroFightModule heroFightModule){
        ClusterClientTeamMember member = heroFightModule
                .getGroupDungeonMember();
        if (member == null){
            hc.sendMessage(ERROR_CANCEL_READY_NO_TEAM);
            return;
        }

        long ctime = timeService.getCurrentTime();
        if (ctime < hc.nextCanClusterGroupCancelReadyTime){
            hc.sendMessage(ERROR_CANCEL_READY_TOO_FREQUENT);
            return;
        }

        // 发送给master
        boolean msgSent = groupClient.sendMessage(GroupHeader.groupCancelReady(
                member.getSceneConfigID(), hc.combinedID));
        if (!msgSent){
            hc.sendMessage(ERROR_CANCEL_READY_MASTER_DISCONNECTED);
            return;
        }

        hc.nextCanClusterGroupCancelReadyTime = ctime
                + VariableConfig.GROUP_DUNGEON_CLUSTER_READY_CD;

        // 成功失败都由master proxy消息给玩家
    }

    private void onReady(ChannelBuffer buffer, HeroController hc,
            HeroFightModule heroFightModule){
        ClusterClientTeamMember member = heroFightModule
                .getGroupDungeonMember();
        if (member == null){
            hc.sendMessage(ERROR_READY_NO_TEAM);
            return;
        }

        long ctime = timeService.getCurrentTime();
        if (ctime < hc.nextCanCluterGroupReadyTime){
            hc.sendMessage(ERROR_READY_TOO_FREQUENT);
            return;
        }

        // 发送给master
        boolean msgSent = groupClient.sendMessage(GroupHeader.groupReady(
                member.getSceneConfigID(), hc.combinedID));
        if (!msgSent){
            hc.sendMessage(ERROR_READY_MASTER_DISCONNECTED);
            return;
        }

        hc.nextCanCluterGroupReadyTime = ctime
                + VariableConfig.GROUP_DUNGEON_CLUSTER_READY_CD;

        // 成功或者失败都由master proxy给玩家
    }

    private void onJoinGroup(ChannelBuffer buffer, HeroController hc,
            HeroFightModule heroFightModule){
        if (!heroFightModule.isParentNormalScene()){
            hc.sendMessage(ERROR_JOIN_GROUP_IN_DUNGEON);
            return;
        }

        if (heroFightModule.getGroupDungeonMember() != null){
            hc.sendMessage(ERROR_JOIN_GROUP_IN_GROUP);
            return;
        }

        final int dungeonID = readVarInt32(buffer);
        final int groupID = readVarInt32(buffer);

        ClusterClientTeamMatcher matcher = matchers.get(dungeonID);
        if (matcher == null){
            hc.sendMessage(ERROR_JOIN_GROUP_DUNGEON_ID_NOT_FOUND);
            return;
        }

        Hero hero = hc.getHero();
        if (hero.getLevel() < matcher.sceneData.requiredLevel){
            hc.sendMessage(ERROR_JOIN_GROUP_NOT_ENOUGH_LEVEL);
            return;
        }

        if (!matcher.sceneData.canHeroEnterToday(hero)){
            hc.sendMessage(ERROR_JOIN_GROUP_TODAY_ENTERED_TOO_MUCH);
            return;
        }

        long ctime = timeService.getCurrentTime();
        if (ctime < hc.nextCanJoinClusterGroupTime){
            hc.sendMessage(ERROR_JOIN_GROUP_TOO_FREQUENT);
            return;
        }

        // 发送请求到master
        boolean msgSent = groupClient.sendMessage(GroupHeader.joinGroup(
                dungeonID, groupID, hero));
        if (!msgSent){
            hc.sendMessage(ERROR_JOIN_GROUP_MASTER_DISCONNECTED);
            return;
        }

        hc.nextCanJoinClusterGroupTime = ctime
                + VariableConfig.GROUP_DUNGEON_CLUSTER_JOIN_CD;

        // 发送成功, 这里先不发送给玩家入队结果

        // 先解除注册监听的副本, 如果入队失败, 则再自动帮玩家注册
        ClusterClientTeamMatcher listeningMatcher = heroFightModule
                .getListeningGroupDungeonMatcher();
        if (listeningMatcher != null){
            listeningMatcher.unregister(hc.combinedID);
            heroFightModule.setListeningGroupDungeonMatcher(null);
        }

        // 把队伍先设置了
        heroFightModule.setGroupDungeonMember(new ClusterClientTeamMember(
                matcher.sceneData, hc.combinedID, groupClient));
    }

    private void onLeaveGroup(ChannelBuffer buffer, HeroController hc,
            HeroFightModule heroFightModule){
        ClusterClientTeamMember member = heroFightModule
                .getGroupDungeonMember();
        if (member == null){
            hc.sendMessage(ERROR_LEAVE_NO_TEAM);
            return;
        }

        heroFightModule.setGroupDungeonMember(null);
        hc.sendMessage(leaveSuccess);
        // 直接就当做没有队伍了, 通知下master
        member.leaveTeam();
    }

    private void onCreateGroup(ChannelBuffer buffer, HeroController hc,
            HeroFightModule heroFightModule){
        if (!heroFightModule.isParentNormalScene()){
            hc.sendMessage(ERROR_CREATE_GROUP_IN_DUNGEON);
            return;
        }

        if (heroFightModule.getGroupDungeonMember() != null){
            hc.sendMessage(ERROR_CREATE_GROUP_ALREADY_HAVE_GROUP);
            return;
        }

        final int dungeonID = readVarInt32(buffer);
        final int requiredFightAmount = readVarInt32(buffer);
        final boolean isAutoStart = readBoolean(buffer);

        ClusterClientTeamMatcher matcher = matchers.get(dungeonID);
        if (matcher == null){
            hc.sendMessage(ERROR_CREATE_GROUP_ID_NOT_FOUND);
            return;
        }

        Hero hero = hc.getHero();
        // 检查等级
        if (hero.getLevel() < matcher.sceneData.requiredLevel){
            hc.sendMessage(ERROR_CREATE_GROUP_NOT_ENOUGH_LEVEL);
            return;
        }

        if (requiredFightAmount < 0
                || requiredFightAmount > hero.getFightingAmount()){
            hc.sendMessage(ERROR_CREATE_GROUP_ILLEGAL_FIGHT_AMOUNT);
            return;
        }

        if (!matcher.sceneData.canHeroEnterToday(hero)){
            hc.sendMessage(ERROR_CREATE_GROUP_TODAY_ENTERED_TOO_MUCH);
            return;
        }

        if (!matcher.canCreateMoreTeam()){
            hc.sendMessage(ERROR_CREATE_GROUP_ALREADY_TOO_MANY_TEAMS);
            return;
        }

        long ctime = timeService.getCurrentTime();
        if (ctime < hc.nextCanCreateClusterGroupTime){
            hc.sendMessage(ERROR_CREATE_GROUP_TOO_FREQUENT);
            return;
        }

        boolean msgSent = groupClient.sendMessage(GroupHeader.createGroup(
                dungeonID, requiredFightAmount, isAutoStart, hero));

        if (!msgSent){
            hc.sendMessage(ERROR_CREATE_GROUP_MASTER_DISCONNECTED);
            return;
        }

        // 可以创建
        hc.nextCanCreateClusterGroupTime = ctime
                + VariableConfig.GROUP_DUNGEON_CLUSTER_CREATE_CD;

        // 如果有监听, 取消监听
        ClusterClientTeamMatcher listeningMatcher = heroFightModule
                .getListeningGroupDungeonMatcher();
        if (listeningMatcher != null){
            listeningMatcher.unregister(hc.combinedID);
            heroFightModule.setListeningGroupDungeonMatcher(null);
        }

        ClusterClientTeamMember member = new ClusterClientTeamMember(
                matcher.sceneData, hc.combinedID, groupClient);
        heroFightModule.setGroupDungeonMember(member);

        // 通知英雄创建成功
        hc.sendMessage(createGroupSuccess);
    }

    private void onUnregister(ChannelBuffer buffer, HeroController hc,
            HeroFightModule heroFightModule){
        ClusterClientTeamMatcher listeningMatcher = heroFightModule
                .getListeningGroupDungeonMatcher();
        if (listeningMatcher == null){
            logger.warn("GroupDungeonModule.onUnregister时, 用户并没有监听任何副本的队伍");
            return;
        }

        listeningMatcher.unregister(hc.combinedID);
        heroFightModule.setListeningGroupDungeonMatcher(null);
    }

    private void onRegister(ChannelBuffer buffer, HeroController hc,
            HeroFightModule heroFightModule){
        if (!heroFightModule.isParentNormalScene()){
            hc.sendMessage(ERROR_REGISTER_IN_DUNGEON);
            logger.warn("注册组队副本时, 不在普通场景");
            return;
        }

        if (heroFightModule.getGroupDungeonMember() != null){
            logger.warn("注册组队副本时, 已经在个队伍里了");
            hc.sendMessage(ERROR_REGISTER_IN_GROUP);
            return;
        }

        int dungeonID = readVarInt32(buffer);
        ClusterClientTeamMatcher matcher = matchers.get(dungeonID);
        if (matcher == null){
            logger.warn("注册组队副本时, 没有找到要注册的副本id: {}", dungeonID);
            hc.sendMessage(ERROR_REGISTER_ID_NOT_FOUND);
            return;
        }

        ClusterClientTeamMatcher oldListeningMatcher = heroFightModule
                .getListeningGroupDungeonMatcher();
        if (oldListeningMatcher == matcher){
            logger.warn("注册组队副本时, 注册了个本来就已经注册了的副本");
            hc.sendMessage(ERROR_REGISTER_REGISTERED);
            return;
        }

        if (oldListeningMatcher != null){
            oldListeningMatcher.unregister(hc.combinedID);
        }

        heroFightModule.setListeningGroupDungeonMatcher(matcher);
        matcher.register(hc.combinedID, hc.getSender()); // 里面发送了注册成功和队伍列表消息
        logger.debug("注册组队副本成功: {}", dungeonID);
    }

    // --- 处理别的逻辑 ---

    public void processMasterDisconnected(){
        // 踢出所有在组队中的人, 并且去掉每个副本的队伍信息缓存(广播空队伍列表). 队伍数设成最大, 防止创建队伍
        for (ClusterClientTeamMatcher matcher : matchers.values()){
            matcher.onMasterDisconnected();
        }

        executorRelatedService
                .applyFunctionToAllHeroFightModuleUsingUserThread(new Func<HeroFightModule>(){
                    @Override
                    public void apply(HeroFightModule heroFightModule){
                        ClusterClientTeamMember member = heroFightModule
                                .getGroupDungeonMember();
                        if (member == null){
                            return;
                        }

                        heroFightModule.setGroupDungeonMember(null);
                        heroFightModule
                                .sendMessage(leaveGroupMasterDisconnected);
                    }
                });
    }

    public void processMasterBroadcastSceneTeamList(ChannelBuffer buffer){
        int sceneID = BufferUtil.readVarInt32(buffer);
        int teamCount = BufferUtil.readVarInt32(buffer);
        ClusterClientTeamMatcher matcher = matchers.get(sceneID);
        if (matcher == null){
            logger.error(
                    "ClusterClientTeamModule收到master广播的队伍列表时, 竟然有个场景没找到: {}. 难道是版本不同?",
                    sceneID);
            return;
        }

        matcher.updateTeamList(teamCount, buffer);
    }

    public void processAutoJoinGroupFail(ChannelBuffer buffer){
        final long heroID = readVarInt64(buffer);
        final ConnectedUser cu = worldService.getUser(heroID);
        if (cu == null){
            // 英雄已经下线了
            return;
        }
        cu.getExecutor().execute(new Runnable(){
            @Override
            public void run(){
                // 不要再去worldService重新再取一次英雄, 如果在execute前已经下线换了新英雄了, 那不需要告诉他之前入队失败了
                if (cu.getIsOffline().get()){
                    // execute前下线了
                    return;
                }

                HeroController hc = cu.getHeroController();
                if (hc == null){
                    logger.error("ClusterClientTeamModule.processAutoJoinGroupFail收到的英雄id, 有user, 但没有hc...");
                    return;
                }

                hc.sendMessage(ERROR_AUTO_ENTER_GROUP_NO_MATCH_GROUP_FOUND);

                // 重新注册这个副本
                HeroFightModule heroFightModule = hc.getHeroFightModule();

                ClusterClientTeamMember member = heroFightModule
                        .getGroupDungeonMember();
                if (member == null){
                    // 可能英雄进入了副本, 导致已经不在队伍了. 还是发送入队失败, 但不注册回副本了
                } else{
                    heroFightModule.setGroupDungeonMember(null);
                    ClusterClientTeamMatcher matcher = matchers.get(member
                            .getSceneConfigID());
                    if (matcher == null){
                        logger.error(
                                "ClusterClientTeamModule.processJoinGroupFail时, 英雄的ClusterClientTeamMember的sceneID没有对应的matcher: {}",
                                member.getSceneConfigID());
                        return;
                    }
                    matcher.registerWithoutSentAnyMsg(heroID, hc.getSender());
                    heroFightModule.setListeningGroupDungeonMatcher(matcher);
                }

            }
        });
    }

    public void processJoinGroupFail(ChannelBuffer buffer){
        final long heroID = readVarInt64(buffer);
        final ConnectedUser cu = worldService.getUser(heroID);
        if (cu == null){
            // 英雄已经下线了
            return;
        }

        final int errorCode = readVarInt32(buffer);
        cu.getExecutor().execute(new Runnable(){
            @Override
            public void run(){
                // 不要再去worldService重新再取一次英雄, 如果在execute前已经下线换了新英雄了, 那不需要告诉他之前入队失败了
                if (cu.getIsOffline().get()){
                    // execute前下线了
                    return;
                }

                HeroController hc = cu.getHeroController();
                if (hc == null){
                    logger.error("ClusterClientTeamModule.processJoinGroupFail收到的英雄id, 有user, 但没有hc...");
                    return;
                }

                // 不管怎么样, 发送入队失败
                switch (errorCode){
                    case 1:{
                        hc.sendMessage(ERROR_JOIN_GROUP_GROUP_ID_NOT_FOUND);
                        break;
                    }

                    case 2:{
                        hc.sendMessage(ERROR_JOIN_GROUP_GROUP_FULL);
                        break;
                    }

                    case 3:{
                        hc.sendMessage(ERROR_JOIN_GROUP_NOT_ENOUGH_FIGHT_AMOUNT);
                        break;
                    }

                    default:{
                        logger.error(
                                "ClusterClientTeamModule.processJoinGroupFail收到未知的错误码, 加了码没有处理?: {}",
                                errorCode);
                        hc.sendMessage(ERROR_JOIN_GROUP_DUNGEON_ID_NOT_FOUND);
                        break;
                    }
                }

                HeroFightModule heroFightModule = hc.getHeroFightModule();

                ClusterClientTeamMember member = heroFightModule
                        .getGroupDungeonMember();
                if (member == null){
                    // 可能英雄进入了副本, 导致已经不在队伍了. 还是发送入队失败, 但不注册回副本了
                } else{
                    heroFightModule.setGroupDungeonMember(null);
                    ClusterClientTeamMatcher matcher = matchers.get(member
                            .getSceneConfigID());
                    if (matcher == null){
                        logger.error(
                                "ClusterClientTeamModule.processJoinGroupFail时, 英雄的ClusterClientTeamMember的sceneID没有对应的matcher: {}",
                                member.getSceneConfigID());
                        return;
                    }
                    matcher.registerWithoutSentAnyMsg(heroID, hc.getSender());
                    heroFightModule.setListeningGroupDungeonMatcher(matcher);
                }
            }
        });
    }

    public void processBeenKick(ChannelBuffer buffer){
        final long heroID = readVarInt64(buffer);
        final ConnectedUser cu = worldService.getUser(heroID);
        if (cu == null){
            // 英雄已经下线了
            return;
        }

        cu.getExecutor().execute(new Runnable(){
            @Override
            public void run(){
                // 不要再去worldService重新再取一次英雄, 如果在execute前已经下线换了新英雄了, 那不需要告诉他之前入队失败了
                if (cu.getIsOffline().get()){
                    // execute前下线了
                    return;
                }

                HeroController hc = cu.getHeroController();
                if (hc == null){
                    logger.error("ClusterClientTeamModule.processBeenKick收到的英雄id, 有user, 但没有hc...");
                    return;
                }

                HeroFightModule heroFightModule = hc.getHeroFightModule();
                ClusterClientTeamMember member = heroFightModule
                        .getGroupDungeonMember();
                if (member == null){
                    // 可能英雄进入了副本, 不管了
                    return;
                }

                heroFightModule.setGroupDungeonMember(null);
                hc.sendMessage(beenKicked);
            }
        });
    }

    public void processStartBroadcast(ChannelBuffer buffer){
        final long heroID = readVarInt64(buffer);
        final long combatServerID = readVarInt64(buffer);

        final int dungeonID = readVarInt32(buffer); // 副本配置id
        final int uuid = readVarInt32(buffer);

        final ConnectedUser cu = worldService.getUser(heroID);
        if (cu == null){
            // 英雄已经下线了
            return;
        }

        cu.getExecutor().execute(new Runnable(){
            @Override
            public void run(){
                // 不要再去取了
                if (cu.getIsOffline().get()){
                    // execute前下线了
                    return;
                }

                HeroController hc = cu.getHeroController();
                if (hc == null){
                    logger.error("ClusterClientTeamModule.processStartBroadcast收到的英雄id, 有user, 但没有hc");
                    return;
                }

                HeroFightModule heroFightModule = hc.getHeroFightModule();
                ClusterClientTeamMember member = heroFightModule
                        .getGroupDungeonMember();
                if (member == null || member.getSceneConfigID() != dungeonID){
                    // 可能英雄进入了别的副本, 不管了
                    return;
                }

                // 设置进入时间和别的数据 
                long enterDungeonTime = timeService.getCurrentTime()
                        + VariableConfig.GROUP_DUNGEON_START_AND_WAIT_TIME;

                member.setStartInfo(combatServerID, uuid, enterDungeonTime);
                hc.sendMessage(startedBroadcast);
            }
        });
    }
}
