package app.cluster.client.combat.scene;

import static app.cluster.client.combat.scene.LongMaiDungeonMessages.*;
import static app.protobuf.LogContent.LogEnum.OperateType.COLLECT_DUNGEON_PRIZE;

import org.jboss.netty.buffer.ChannelBuffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.data.Prize;
import app.game.data.goods.GoodsAddHelper;
import app.game.data.goods.GoodsTryAddResult;
import app.game.module.GoodsContainerModule;
import app.game.module.HeroController;
import app.game.module.MailModule;
import app.game.module.scene.HeroFightModule;
import app.game.module.scene.IScene;
import app.game.service.TimeService;
import app.protobuf.LogContent.LogEnum.OperateType;

import com.google.inject.Inject;

public class LongMaiDungeonModule{
    private static final Logger logger = LoggerFactory
            .getLogger(LongMaiDungeonModule.class);

    private final TimeService timeService;
    private final MailModule mailModule;
    private final GoodsContainerModule goodsContainerModule;

    @Inject
    LongMaiDungeonModule(TimeService timeService, MailModule mailModule,
            GoodsContainerModule goodsContainerModule){
        this.timeService = timeService;
        this.mailModule = mailModule;
        this.goodsContainerModule = goodsContainerModule;
    }

    public void onMessage(int sequenceID, ChannelBuffer buffer,
            HeroController hc, HeroFightModule heroFightModule){
        switch (sequenceID){
            case C2S_COLLECT_NOT_FIRST_PASS_PRIZE:{
                onCollectNotFirstPassPrize(buffer, hc, heroFightModule);
                return;
            }

            default:{
                logger.warn("LongMaiDungeonModule收到位置的消息id: {}", sequenceID);
            }
        }
    }

    private void onCollectNotFirstPassPrize(ChannelBuffer buffer,
            HeroController hc, HeroFightModule heroFightModule){
        if (!heroFightModule.isInAndEnteredDungeon()){
            hc.sendMessage(ERROR_COLLECT_NOT_FIRST_PRIZE_NOT_IN_LONG_MAI);
            return;
        }

        IScene parent = heroFightModule.getParent();
        if (!(parent instanceof LocalLongMaiDungeonScene)){
            hc.sendMessage(ERROR_COLLECT_NOT_FIRST_PRIZE_NOT_IN_LONG_MAI);
            return;
        }

        LocalLongMaiDungeonScene longMaiParent = (LocalLongMaiDungeonScene) parent;

        boolean canCollect = longMaiParent
                .canHeroCollectNotFirstPassPrizeAndRemove(hc.combinedID);
        if (!canCollect){
            hc.sendMessage(ERROR_COLLECT_NOT_FIRST_PRIZE_NOT_COLLECTABLE);
            return;
        }

        Prize prize = longMaiParent.getSceneData().getNotFirstPassPrize();
        long ctime = timeService.getCurrentTime();

        // LongMaiDungeonScene#removeHero处, 也需要发邮件

        // 不管怎么样, 数值型的都加
        prize.giveIgnoreGoods(hc.getHeroMiscModule(), hc.getHero(), false,
                COLLECT_DUNGEON_PRIZE, null);

        GoodsAddHelper[] gah = prize.newGoodsAddHelpers(ctime);

        GoodsTryAddResult result = hc.getHero().getDepot().canAddGoods(gah);
        if (!result.isSuccess()){
            // 失败, 发邮件
            hc.sendMessage(ERROR_COLLECT_NOT_FIRST_PRIZE_BAG_FULL);
            mailModule.newMailOnDepotEmptyPosNotEnough(hc.getHero(),
                    prize.newGoodsAddHelpers(ctime));
        } else{
            // 成功, 放到背包
            hc.sendMessage(collectNotFirstPassPrizeSuccess);
            goodsContainerModule.addBatchGoodsArray(gah, result, hc.getHero(),
                    hc.getSender(), hc.getHeroMiscModule(),
                    OperateType.COLLECT_DUNGEON_PRIZE, 0, ctime);
        }
    }
}
