package app.cluster.client.combat.scene;

import java.util.ArrayList;
import java.util.List;

import app.game.data.Prize;
import app.game.data.Vip;
import app.game.data.goods.GoodsAddHelper;
import app.game.data.goods.GoodsWrapper;
import app.game.data.scene.GroupDungeonPrizeConfig;
import app.protobuf.DungeonContent.GroupDungeonCollectablePrizeProto;
import app.protobuf.DungeonContent.GroupDungeonFinishStatProto;
import app.utils.VariableConfig;

public class GroupDungeonPrizeStage{

    private final GroupDungeonPrizeConfig prizeConfig;

    private final int score;

    private final int duration;

    private final int deadCount;

    private final int exp;

    public boolean repliedStat;

    public boolean isPrizeCollected;

    public GoodsWrapper randomedPrizeS;

    public GoodsWrapper randomedPrizeV5;

    public GroupDungeonPrizeStage(GroupDungeonPrizeConfig prizeConfig,
            int score, int duration, int deadCount, int exp){
        super();
        this.prizeConfig = prizeConfig;
        this.score = score;
        this.duration = duration;
        this.deadCount = deadCount;
        this.exp = exp;
    }

    public GroupDungeonPrizeConfig getPrizeConfig(){
        return prizeConfig;
    }

    public GroupDungeonCollectablePrizeProto getAsTempPrize(long ctime){
        GroupDungeonCollectablePrizeProto.Builder builder = GroupDungeonCollectablePrizeProto
                .newBuilder().setDungeonId(prizeConfig.sceneID);

        if (score > GroupDungeonPrizeConfig.SCORE_S){
            builder.setNoScoreSPrize(true);

            if (randomedPrizeS == null){
                randomedPrizeS = prizeConfig.getRandomPrizeS();
            }

            builder.setRandomedSPrize(randomedPrizeS.encode().toByteString());
        }

        if (randomedPrizeV5 == null){
            randomedPrizeV5 = prizeConfig.getRandomPrizeV5();
        }

        builder.setRandomedVipPrize(randomedPrizeV5.encode().toByteString());

        builder.setExpireTime(ctime
                + VariableConfig.STORY_DUNGEON_COLLECTABLE_PRIZE_KEEP_TIME);

        return builder.build();
    }

    public GroupDungeonFinishStatProto randomPrizeAndGetProto(Vip clientVip){
        assert !repliedStat;
        repliedStat = true;
        GroupDungeonFinishStatProto.Builder builder = GroupDungeonFinishStatProto
                .newBuilder();
        builder.setTotalTime(duration).setDeadCount(deadCount).setScore(score)
                .setMonsterExp(exp);

        // s评分奖励
        if (score <= GroupDungeonPrizeConfig.SCORE_S){
            GoodsWrapper[] prize = prizeConfig.getRandomPrizeSAnd3More();
            for (GoodsWrapper w : prize){
                builder.addScoreSPrize(w.encode4Client());
            }
            randomedPrizeS = prize[0];
        }

        // v5奖励
        if (clientVip != null && clientVip.hasStoryExtraPrize()){
            GoodsWrapper[] prize = prizeConfig.getRandomPrizeV5And3More();
            for (GoodsWrapper w : prize){
                builder.addVipPrize(w.encode4Client());
            }
            randomedPrizeV5 = prize[0];
        }

        return builder.build();
    }

    public void randomPrize(Vip clientVip){
        assert !repliedStat;

        repliedStat = true;

        if (score <= GroupDungeonPrizeConfig.SCORE_S){
            randomedPrizeS = prizeConfig.getRandomPrizeS();
        }

        if (clientVip != null && clientVip.hasStoryExtraPrize()){
            randomedPrizeV5 = prizeConfig.getRandomPrizeV5();
        }
    }

    public List<GoodsAddHelper> getPrizeGoods(long ctime){
        Prize fixedPrize = prizeConfig.getFixedPrize();
        GoodsWrapper[] fixedPrizeGoodsWrappers = fixedPrize.getGoodsWrappers();
        List<GoodsAddHelper> result = new ArrayList<>(
                fixedPrizeGoodsWrappers.length + 2);

        for (GoodsWrapper w : fixedPrizeGoodsWrappers){
            result.add(w.newHelper(ctime));
        }

        if (randomedPrizeS != null){
            result.add(randomedPrizeS.newHelper(ctime));
        }

        if (randomedPrizeV5 != null){
            result.add(randomedPrizeV5.newHelper(ctime));
        }

        return result;
    }

}
