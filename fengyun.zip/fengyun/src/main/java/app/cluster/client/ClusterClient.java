package app.cluster.client;

import java.io.Closeable;

import app.cluster.client.combat.ClusterClientManager;
import app.cluster.combat.discovery.CombatServerDiscovery;

import com.google.inject.Inject;
import com.mokylin.sink.util.Utils;
import com.mokylin.zk.util.ClusterConnection;

/**
 * 每一个服, 在集群中
 * @author Timmy
 *
 */
public class ClusterClient implements Closeable{

    private final ClusterConnection clusterConnection;

    private final GroupClient groupClient;

    private final CombatServerDiscovery combatServerDiscovery;

    private final ClusterClientManager manager;

    @Inject
    ClusterClient(ClusterConnection connection, GroupClient groupClient,
            ClusterClientManager manager,
            CombatServerDiscovery combatServerDiscovery){
        this.clusterConnection = connection;
        this.groupClient = groupClient;
        this.manager = manager;
        this.combatServerDiscovery = combatServerDiscovery;
    }

    public void start() throws Exception{
        clusterConnection.start();

        groupClient.start();

        combatServerDiscovery.start();
    }

    @Override
    public void close(){
        Utils.closeQuietly(groupClient);
        Utils.closeQuietly(combatServerDiscovery);
        Utils.closeQuietly(manager);
        Utils.closeQuietly(clusterConnection);
    }
}
