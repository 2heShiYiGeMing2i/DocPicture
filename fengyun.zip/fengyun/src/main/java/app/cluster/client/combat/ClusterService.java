package app.cluster.client.combat;

import app.cluster.client.combat.scene.ClusterDungeonService;
import app.game.module.ViewOtherHeroCache;
import app.game.service.ExecutorRelatedService;
import app.game.service.IThreadService;
import app.game.service.TimeService;
import app.game.service.WorldService;

import com.google.inject.Inject;
import com.mokylin.sink.util.concurrent.DisruptorExecutor;

/**
 * 跨服所需要使用到的Service, 供处理cluster的消息等逻辑
 * @author Timmy
 *
 */
public class ClusterService{

    private final WorldService worldService;

    private final IThreadService threadService;

    private final TimeService timeService;

    private final ClusterDungeonService clusterSceneService;

    private final ExecutorRelatedService executorRelatedService;

    private final DisruptorExecutor[] taskExecArray;

    private final ViewOtherHeroCache viewOtherHeroCache;

    @Inject
    ClusterService(WorldService worldService, IThreadService threadService,
            TimeService timeService, ClusterDungeonService clusterSceneService,
            ExecutorRelatedService executorRelatedService,
            ViewOtherHeroCache viewOtherHeroCache){
        this.worldService = worldService;
        this.threadService = threadService;
        this.taskExecArray = threadService.getExecutorsArrayCopy();

        this.timeService = timeService;
        this.clusterSceneService = clusterSceneService;
        this.executorRelatedService = executorRelatedService;
        this.viewOtherHeroCache = viewOtherHeroCache;
    }

    public ViewOtherHeroCache getViewOtherHeroCache(){
        return viewOtherHeroCache;
    }

    public DisruptorExecutor[] getTaskExecArray(){
        return taskExecArray;
    }

    public ClusterDungeonService getClusterSceneService(){
        return clusterSceneService;
    }

    public ExecutorRelatedService getExecutorRelatedService(){
        return executorRelatedService;
    }

    public TimeService getTimeService(){
        return timeService;
    }

    public WorldService getWorldService(){
        return worldService;
    }

    public IThreadService getThreadService(){
        return threadService;
    }
}
