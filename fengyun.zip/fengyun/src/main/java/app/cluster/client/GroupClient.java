package app.cluster.client;

import java.io.Closeable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.curator.framework.imps.CuratorFrameworkState;
import org.apache.curator.framework.recipes.cache.ChildData;
import org.apache.curator.framework.recipes.cache.NodeCache;
import org.apache.curator.framework.recipes.cache.NodeCacheListener;
import org.jboss.netty.buffer.ChannelBuffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.cluster.group.master.GroupMasterServer;
import app.cluster.group.master.GroupMasterServerInfo;
import app.cluster.group.master.GroupMasterZKPathUtil;
import app.message.ISender;
import app.utils.IndividualServerConfig;
import app.utils.Operators;

import com.google.common.base.Objects;
import com.google.inject.Inject;
import com.mokylin.sink.client.ReconnectNettyClient;
import com.mokylin.sink.client.ReconnectNettyClient.ClosedNotifier;
import com.mokylin.sink.client.ReconnectNettyClientSharedResources;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.concurrent.NamedThreadFactory;
import com.mokylin.zk.util.ClusterConnection;

/**
 * 获取GroupMaster信息, 并连接到master, 断线也重连
 * @author Timmy
 *
 */
public class GroupClient implements Closeable, NodeCacheListener, ISender,
        ClosedNotifier{
    private static final Logger logger = LoggerFactory
            .getLogger(GroupClient.class);

    private final ClusterConnection connection;

    private final IGroupClientListener listener;

    private final ReconnectNettyClientSharedResources nettyClientSharedResources;

    private NodeCache nodeCache;

    private GroupMasterServerInfo currentMasterInfo;

    private final ExecutorService masterChangeExec;

    private final Operators operator;

    /**
     * tcp连接到当前的master进行通讯
     */
    private volatile ReconnectNettyClient nettyClient;

    @Inject
    public GroupClient(ClusterConnection connection,
            IGroupClientListener listener,
            ReconnectNettyClientSharedResources nettyClientResources,
            IndividualServerConfig serverConfig){
        this.connection = connection;
        this.listener = listener;
        this.masterChangeExec = Executors
                .newSingleThreadExecutor(new NamedThreadFactory(
                        "GROUP_MASTER_CHANGE_EXEC", false));
        this.nettyClientSharedResources = nettyClientResources;
        this.operator = Operators.valueOf(serverConfig.getDefaultOperatorID());
    }

    /**
     * ClusterConnection必须是已经started的
     * @throws Exception
     */
    public void start() throws Exception{
        assert connection.getCuratorFramework().getState() == CuratorFrameworkState.STARTED;

        nodeCache = new NodeCache(connection.getCuratorFramework(),
                GroupMasterZKPathUtil.getListenPath(operator), false);

        nodeCache.getListenable().addListener(this, masterChangeExec);

        nodeCache.start(false);
    }

    @Override
    public void close(){
        // 这不关ClusterConnection. 谁开的谁关
        Utils.closeQuietly(nodeCache);

        currentMasterInfo = null;
        if (nettyClient != null){
            Utils.closeQuietly(nettyClient);
        }
    }

    public ReconnectNettyClient getNettyClient(){
        return nettyClient;
    }

    /**
     * 发送消息给GroupMaster. 返回是否发送成功
     *
     * 注. 返回的只是当前是否还和GroupMaster有连接. 可能返回true但实际发送失败. 调用者需要有机制处理
     * 返回false是一定发送失败
     *
     * @param buffer
     * @return
     */
    @Override
    public boolean sendMessage(ChannelBuffer buffer){
        ReconnectNettyClient c = nettyClient;
        if (c != null){
            return c.sendMessage(buffer);
        }
        return false;
    }

    @Override
    public void nodeChanged() throws Exception{
        ChildData data = nodeCache.getCurrentData();

        GroupMasterServerInfo info = data == null ? null
                : GroupMasterServerInfo.parse(data.getData());

        // 比较现有数据
        if (Objects.equal(info, currentMasterInfo)){
            return;
        }
        // 有改变
        logger.debug("发现Master信息改变: {}", info);
        currentMasterInfo = info;

        ReconnectNettyClient client = nettyClient;
        if (client != null){
            // 关闭以前的连接
            Utils.closeQuietly(client);
            // 这里不设为null, 不然再来个nodeChanged, 就直接连上了, 没有等前一个调用onClosed
        } else{
            if (info == null){
                return;
            }
            nettyClient = new ReconnectNettyClient(info.address, info.port,
                    listener, this, nettyClientSharedResources).start();
        }
    }

    @Override
    public void onClosed(){
        masterChangeExec.execute(new Runnable(){
            @Override
            public void run(){
                GroupMasterServerInfo info = currentMasterInfo;
                if (info != null){
                    nettyClient = new ReconnectNettyClient(info.address,
                            info.port, listener, GroupClient.this,
                            nettyClientSharedResources).start();
                } else{
                    nettyClient = null;
                }
            }
        });
    }
}
