package app.cluster.client;

import app.cluster.client.combat.ClusterClientCombatServerContainer;
import app.cluster.client.combat.ClusterClientManager;
import app.cluster.client.combat.ClusterService;
import app.cluster.client.combat.scene.ClusterDungeonService;
import app.cluster.client.combat.scene.HuoLinActivityModule;
import app.cluster.client.logic.team.ClusterClientTeamModule;
import app.cluster.combat.discovery.CombatServerDiscovery;
import app.cluster.combat.discovery.ICombatServerListener;
import app.utils.IndividualServerConfig;

import com.google.inject.AbstractModule;
import com.google.inject.Singleton;
import com.mokylin.sink.client.ReconnectNettyClientSharedResources;
import com.mokylin.zk.util.ClusterConnection;
import com.mokylin.zk.util.ClusterSharedConfiguration;

public class ClusterClientGuiceModule extends AbstractModule{

    @Override
    protected void configure(){
        binder().requireExplicitBindings();

        bind(ClusterConnection.class).in(Singleton.class);
        bind(ClusterClient.class).in(Singleton.class);
        bind(ClusterSharedConfiguration.class).to(IndividualServerConfig.class)
                .in(Singleton.class);
        bind(GroupClient.class).in(Singleton.class);
        bind(ReconnectNettyClientSharedResources.class).in(Singleton.class);
        bind(ClusterService.class).in(Singleton.class);
        bind(ClusterDungeonService.class).in(Singleton.class);
        bind(IGroupClientListener.class).to(ClusterClientManager.class).in(
                Singleton.class);
        bind(ClusterClientManager.class).in(Singleton.class);
        bind(ICombatServerListener.class).to(ClusterClientManager.class).in(
                Singleton.class);
        bind(CombatServerDiscovery.class).in(Singleton.class);
        bind(ClusterClientTeamModule.class).in(Singleton.class);
        bind(ClusterClientCombatServerContainer.class).in(Singleton.class);

        bind(HuoLinActivityModule.class).in(Singleton.class);
    }
}
