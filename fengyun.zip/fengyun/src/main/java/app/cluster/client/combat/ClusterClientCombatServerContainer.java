package app.cluster.client.combat;

import java.io.Closeable;
import java.util.Iterator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.inject.Inject;
import com.mokylin.collection.LongConcurrentSynchronizedHashMap;
import com.mokylin.sink.util.Utils;

public class ClusterClientCombatServerContainer implements Closeable{
    private static final Logger logger = LoggerFactory
            .getLogger(ClusterClientCombatServerContainer.class);

    /**
     * 到各个CombatServer的消息管道
     */
    private final LongConcurrentSynchronizedHashMap<CombatClient> combatClients;

    @Inject
    ClusterClientCombatServerContainer(){
        this.combatClients = new LongConcurrentSynchronizedHashMap<>();
    }

    @Override
    public void close(){
        for (Iterator<CombatClient> ite = combatClients.newValueIterator(); ite
                .hasNext();){
            Utils.closeQuietly(ite.next());
        }
    }

    public boolean addCombatServer(CombatClient client){
        return combatClients.putIfAbsent(client.id, client) == null;
    }

    public CombatClient removeCombatServer(long id){
        return combatClients.remove(id);
    }

    /**
     * 获得CombatServer的通信管道
     * @param id
     * @return
     */
    public CombatClient getCombatServer(long id){
        return combatClients.get(id);
    }

    /**
     * 随机获得一个CombatClient
     * @return
     */
    public CombatClient getRandomCombatServer(){
        Iterator<CombatClient> ite = combatClients.newValueIterator();
        if (ite.hasNext()){
            return ite.next();
        }
        return null;
    }
}
