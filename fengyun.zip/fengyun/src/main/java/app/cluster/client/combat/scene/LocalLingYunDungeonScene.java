package app.cluster.client.combat.scene;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.data.scene.LingYunDungeonSceneData;
import app.game.module.scene.AbstractHeroFightModule;
import app.game.module.scene.HeroFightModule;
import app.game.module.scene.IClusterLocalDungeonService;
import app.message.ISender;
import app.protobuf.ConfigContent.ShengWangType;

import com.mokylin.sink.util.annotation.SelfThreadOnly;

public class LocalLingYunDungeonScene extends LocalGroupDungeonScene{
    private static final Logger logger = LoggerFactory
            .getLogger(LocalLingYunDungeonScene.class);

    private final LingYunDungeonSceneData sceneData;

    public LocalLingYunDungeonScene(LingYunDungeonSceneData sceneData,
            int uuid, IClusterLocalDungeonService dungeonService,
            ISender combatClient, long heroID){
        super(sceneData, uuid, dungeonService, combatClient, heroID);

        this.sceneData = sceneData;
    }

    @Override
    public LingYunDungeonSceneData getSceneData(){
        return sceneData;
    }

    @Override
    @SelfThreadOnly
    public void addHero(AbstractHeroFightModule heroFightModule, long ctime,
            boolean isEnteringFirstScene){
        super.addHero(heroFightModule, ctime, isEnteringFirstScene);

        if (hasDisconnected){
            // 上层已经把他传出副本了
            return;
        }

        if (heroFightModule instanceof HeroFightModule){
            ((HeroFightModule) heroFightModule).getHeroMiscModule()
                    .tryCompleteShengWangTask(ShengWangType.SW_LIN_YUN_KU,
                            true, 1);
        } else{
            logger.error("凌云窟副本本地场景中的居然不是 HeroFightModule");
        }
    }

    @Override
    protected void onFinished(final int deadCount, final int totalDuration){
        final long ctime = getCurrentTime();
        for (final AbstractHeroFightModule heroFightModule : getAllHeroes()){

            heroFightModule.getTaskExec().execute(new Runnable(){
                @Override
                public void run(){
                    if (!heroFightModule
                            .isInScene(LocalLingYunDungeonScene.this)){
                        // 已经离开场景了
                        return;
                    }

                    // 今日已通关
                    int finishedTimes = heroFightModule.getHero()
                            .addLingYunTodayFinishedTimes();
                    heroFightModule.sendMessage(LingYunDungeonMessages
                            .setEnteredTimes(finishedTimes)); // 客户端还是按进入次数算吧
                    heroFightModule
                            .sendMessage(LingYunDungeonMessages.setTodayStatePassed);
                    onDungeonFinishStartGiveDungeonPrize(heroFightModule,
                            ctime, deadCount, totalDuration);
                }
            });
        }
    }

}
