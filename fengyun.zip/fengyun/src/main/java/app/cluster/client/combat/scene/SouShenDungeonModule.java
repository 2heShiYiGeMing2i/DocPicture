package app.cluster.client.combat.scene;

import static app.cluster.client.combat.scene.SouShenDungeonMessages.*;
import static app.protobuf.LogContent.LogEnum.OperateObject.DUNGEON;
import static app.protobuf.LogContent.LogEnum.OperateType.*;
import static com.mokylin.sink.util.BufferUtil.*;

import org.jboss.netty.buffer.ChannelBuffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.data.goods.GoodsAddHelper;
import app.game.data.goods.GoodsTryAddResult;
import app.game.data.scene.SouShenDungeonSceneData.SouShenBossPrize;
import app.game.data.scene.SouShenShop;
import app.game.data.scene.SouShenShop.SouShenShopGoods;
import app.game.entity.Hero;
import app.game.module.GoodsContainerModule;
import app.game.module.HeroController;
import app.game.module.MailModule;
import app.game.module.scene.HeroFightModule;
import app.game.module.scene.IScene;
import app.game.service.TimeService;
import app.game.service.log.LogService;
import app.utils.VariableConfig;

import com.google.inject.Inject;

public class SouShenDungeonModule{
    private static final Logger logger = LoggerFactory
            .getLogger(SouShenDungeonModule.class);

    private final GoodsContainerModule goodsContainerModule;

    private final MailModule mailModule;

    private final TimeService timeService;

    private final VariableConfig variableConfig;

    private final SouShenShop souShenShop;

    private final LogService logService;

    @Inject
    SouShenDungeonModule(GoodsContainerModule goodsContainerModule,
            MailModule mailModule, TimeService timeService,
            VariableConfig variableConfig, SouShenShop souShenShop,
            LogService logService){
        this.goodsContainerModule = goodsContainerModule;
        this.mailModule = mailModule;
        this.timeService = timeService;
        this.variableConfig = variableConfig;
        this.souShenShop = souShenShop;
        this.logService = logService;
    }

    public void onMessage(int sequenceID, ChannelBuffer buffer,
            HeroController hc, HeroFightModule heroFightModule){
        switch (sequenceID){
            case C2S_COLLECT_BOSS_PRIZE:{
                onCollectBossPrize(buffer, hc, heroFightModule);
                return;
            }

            case C2S_COLLECT_DUNGEON_PRIZE:{
                onCollectDungeonPrize(buffer, hc, heroFightModule);
                return;
            }

            case C2S_GET_SHOP_INFO:{
                onGetShopInfo(buffer, hc, heroFightModule);
                return;
            }

            case C2S_BUY_GOODS:{
                onBuyGoods(buffer, hc, heroFightModule);
                return;
            }

            default:{
                logger.warn("SouShenDungeonModule收到位置的消息id: {}", sequenceID);
            }
        }
    }

    private void onBuyGoods(ChannelBuffer buffer, HeroController hc,
            HeroFightModule heroFightModule){
        int toBuyID = readVarInt32(buffer);

        SouShenShopGoods shopGoods = souShenShop.getGoods(toBuyID);
        if (shopGoods == null){
            hc.sendMessage(ERROR_BUY_GOODS_ID_NOT_FOUND);
            return;
        }

        Hero hero = hc.getHero();

        // 搜神值是否足够
        if (hero.getSouShenPoint() < shopGoods.souShenPointCost){
            hc.sendMessage(ERROR_BUY_GOODS_CANNOT_AFFORD);
            return;
        }

        // 每日使用搜神值
        int newUsedAmount = hero.getSouShenPointTodayUsedAmount()
                + shopGoods.souShenPointCost;
        if (newUsedAmount <= 0
                || newUsedAmount > variableConfig.SOU_SHEN_DAILY_USED_POINT_LIMIT){
            hc.sendMessage(ERROR_BUY_GOODS_TODAY_SOU_SHEN_POINT_LIMIT_REACHED);
            return;
        }

        // 每日兑换数量
        if (shopGoods.dailyLimit > 0){
            int todayBoughtGoodsCount = hero
                    .getSouShenGoodsBoughtCount(toBuyID);
            if (todayBoughtGoodsCount >= shopGoods.dailyLimit){
                hc.sendMessage(ERROR_BUY_GOODS_TODAY_GOODS_BUY_LIMIT_REACHED);
                return;
            }
        }

        // 背包是否放得下
        long ctime = timeService.getCurrentTime();
        GoodsAddHelper gah = shopGoods.goodsWrapper.newHelper(ctime);
        GoodsTryAddResult result = hero.getDepot().canAddGoods(gah);
        if (!result.isSuccess()){
            hc.sendMessage(ERROR_BUY_GOODS_DEPOT_FULL);
            return;
        }

        // 能放下
        if (shopGoods.dailyLimit > 0){
            hero.addNewSouShenGoodsBoughtCount(toBuyID);
        }
        hero.setSouShenPointTodayUsedAmount(newUsedAmount);

        // TODO 日志
        String iEventId = logService.newTodoEventId();

        hc.getHeroMiscModule().reduceSouShenPoint(shopGoods.souShenPointCost,
                SOU_SHEN_BUY, iEventId);

        goodsContainerModule.addBatchGoods(gah, result, hero, hc.getSender(),
                hc.getHeroMiscModule(), SOU_SHEN_BUY, 0, ctime);
        hc.sendMessage(buyGoodsSuccess(newUsedAmount));
    }

    private void onGetShopInfo(ChannelBuffer buffer, HeroController hc,
            HeroFightModule heroFightModule){
        if (hc.hasRequestedSouShenShopInfo){
            hc.sendMessage(ERROR_GET_SHOP_INFO_ALREADY_REQUESTED);
            return;
        }

        hc.hasRequestedSouShenShopInfo = true;
        Hero hero = hc.getHero();
        hc.sendMessage(getShopInfoSuccess(
                hero.getSouShenPointTodayUsedAmount(),
                variableConfig.SOU_SHEN_DAILY_USED_POINT_LIMIT,
                hero.getSouShenGoodsBoughtEntries()));
    }

    private void onCollectDungeonPrize(ChannelBuffer buffer, HeroController hc,
            HeroFightModule heroFightModule){
        IScene parent = heroFightModule.getParent();
        if (!(parent instanceof LocalSouShenDungeonScene)){
            return;
        }

        LocalSouShenDungeonScene souShenParent = (LocalSouShenDungeonScene) parent;

        boolean canCollect = souShenParent
                .removeCollectableFinishPrize(hc.combinedID);
        if (!canCollect){
            logger.warn("搜神宫收到英雄要领取完成奖励, 但是英雄不能领取这个奖励. 不在可领取列表中. 要么领过了");
            return;
        }

        // 看下今天是否有完成过, 有的话, 表示生涯一定已经完成过了
        Hero hero = hc.getHero();
        int sceneConfigID = souShenParent.getSceneConfigDataID();
        if (hero.hasTodayFinishedSouShen(sceneConfigID)){
            hc.sendMessage(collectDailyFirstPassPrizeNoPrize);
            return;
        }

        // TODO 日志
        String iEventId = logService.newTodoEventId();
        logService.todo();
//        logService.writeOperateLog(COLLECT_DUNGEON_PRIZE, DUNGEON,
//                souShenParent.getSceneConfigDataID(), souShenParent
//                        .getSceneData().getIntType(), 0, 0, 0, hc.getHero());

        hero.addTodayFinishedSouShen(sceneConfigID);
        // 今天没有完成过, 看下生涯有没有完成过
        boolean hasLifePassed = hero.hasLifeFinishedSouShen(sceneConfigID);
        if (hasLifePassed){
            // 以前有通过, 发搜神值奖励
            hc.sendMessage(collectDailyFirstPassPrizeDailyFirstPrize);
            hc.getHeroMiscModule().addSouShenPoint(
                    souShenParent.getSceneData()
                            .getDailyFirstPassSouShenPoint(),
                    COLLECT_DUNGEON_PRIZE, iEventId);
            return;
        }

        // 以前也没有通过, 发首通物品
        hc.sendMessage(collectDailyFirstPassPrizeLifeFirstPrize);
        hero.addLifeFinishedSouShen(sceneConfigID);
        long ctime = timeService.getCurrentTime();
        GoodsAddHelper gah = souShenParent.getSceneData()
                .getLifeFirstPassGoodsWrapper().newHelper(ctime);

        GoodsTryAddResult result = hero.getDepot().canAddGoods(gah);
        if (!result.isSuccess()){
            // 放不下, 邮件
            mailModule.newMailOnDepotEmptyPosNotEnough(hc.getHero(), gah);
            return;
        }

        goodsContainerModule.addBatchGoods(gah, result, hero, hc.getSender(),
                hc.getHeroMiscModule(), COLLECT_FIRST_PASS_PRIZE,
                souShenParent.getSceneConfigDataID(), ctime);
    }

    private void onCollectBossPrize(ChannelBuffer buffer, HeroController hc,
            HeroFightModule heroFightModule){
        IScene parent = heroFightModule.getParent();
        if (!(parent instanceof LocalSouShenDungeonScene)){
            hc.sendMessage(ERROR_COLLECT_BOSS_PRIZE_NOT_IN_SUO_SHEN_DUNGEON);
            return;
        }

        long bossSceneID = readVarInt64(buffer);

        LocalSouShenDungeonScene souShenParent = (LocalSouShenDungeonScene) parent;

        boolean canCollect = souShenParent.removeCollectableBossPrize(
                bossSceneID, hc.combinedID);
        if (!canCollect){
            hc.sendMessage(ERROR_COLLECT_BOSS_PRIZE_NOT_COLLECTABLE);
            return;
        }

        // 可领取
        SouShenBossPrize bossPrize = souShenParent.getSceneData().getBossPrize(
                bossSceneID);
        if (bossPrize == null){
            logger.error(
                    "SouShenDungeonModule.onCollectBossPrize时, 英雄在可领取boss的列表中, 但是sceneData中又没有这个boss的奖励... bossSceneID: {}",
                    bossSceneID);
            hc.sendMessage(ERROR_COLLECT_BOSS_PRIZE_NOT_COLLECTABLE);
            return;
        }

        int exp = bossPrize.randomExp();
        int realAir = bossPrize.randomRealAir();
        int money = bossPrize.randomRealAir();
        int souShenPoint = bossPrize.randomSouShenPoint();

        assert exp > 0 && realAir > 0 && money > 0 && souShenPoint > 0;

        // TODO 日志
        String iEventId = logService.newTodoEventId();
        logService.todo();
//        logService.writeOperateLog(COLLECT_BOSS_PRIZE, DUNGEON, souShenParent
//                .getSceneConfigDataID(), souShenParent.getSceneData()
//                .getIntType(), 0, 0, 0, hc.getHero());

        // 真正加
        hc.getHeroMiscModule().addExperience(exp, COLLECT_BOSS_PRIZE, iEventId);
        hc.getHeroMiscModule()
                .addRealAir(realAir, COLLECT_BOSS_PRIZE, iEventId);
        hc.getHeroMiscModule().addMoney(money, COLLECT_BOSS_PRIZE, iEventId);
        hc.getHeroMiscModule().addSouShenPoint(souShenPoint,
                COLLECT_BOSS_PRIZE, iEventId);

        // 发送消息停止随机
        hc.sendMessage(collectBossPrizeSuccess(exp, realAir, money,
                souShenPoint));
    }

}
