package app.cluster.client.logic.team;

import static com.mokylin.sink.util.BufferUtil.*;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.module.Modules;
import app.protobuf.DungeonContent.DamageRecordProto;
import app.protobuf.DungeonContent.GroupDungeonCollectablePrizeProto;
import app.protobuf.DungeonContent.GroupDungeonFinishStatProto;

public class ClusterClientMessages{

    public static final int MODULE_ID = Modules.GROUP_DUNGEON_MODULE_ID; // 共用组队模块id

    // --- 注册某副本的队伍列表变化 ---
    /**
     * 获取并监听某个组队副本的队伍情况. 如果之前已经监听着别的组队副本, 则会自动取消监听前一个组队副本
     * 
     * 必须等待服务器返回
     * 
     * 附带
     * 
     * varint32 组队副本的id
     */
    static final int C2S_REGISTER = 1;

    /**
     * 获取及监听失败, 附带varint32 错误码
     * 
     * 1. 你当前在副本中
     * 2. 你当前已经在某个组队副本的队伍中 (未开始, 只是在里面等待开始) 客户端bug
     * 3. 你当前已经监听了这个组队副本 客户端bug
     * 4. 要监听的组队副本id没找到. 要么不存在这个id, 要么这个id不是组队副本
     */
    static final int S2C_REGISTER_FAIL = 1;
    static final ChannelBuffer ERROR_REGISTER_IN_DUNGEON = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_REGISTER_FAIL, 1);
    static final ChannelBuffer ERROR_REGISTER_IN_GROUP = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_REGISTER_FAIL, 2);
    static final ChannelBuffer ERROR_REGISTER_REGISTERED = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_REGISTER_FAIL, 3);
    static final ChannelBuffer ERROR_REGISTER_ID_NOT_FOUND = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_REGISTER_FAIL, 4);

    /**
     * 监听成功. 紧接着会收到详细的队伍信息消息
     * 
     * 没有附带信息
     */
    static final int S2C_REGISTER_SUCCESS = 2;
    static final ChannelBuffer registerSuccess = onlySendHeaderMessage(
            MODULE_ID, S2C_REGISTER_SUCCESS);

    // --- 解除注册 ---

    /**
     * 解除当前监听着的副本. 不需要发送副本id, 服务器也没有返回
     * 
     * 关闭面板时, 发送
     * 
     * 如果进入了副本队伍(不是普通的组队), 进入了副本, 服务器自动会解除监听
     */
    static final int C2S_UNREGISTER = 2;

    // --- 详细队伍信息推送 ---

    /**
     * 服务器会定时给所有注册着副本队伍的玩家推送这条消息
     * 
     * 每次都会附带当前所有的队伍的最新信息, 删掉之前有的所有队伍, 更新成当前消息中的队伍. 
     * 客户端需要根据队伍id排序
     * 
     * 先解压整条消息
     * 
     * 附带
     * 
     * SceneTeamProto, 里面有很多个 TeamInfoProto
     * 
     *  message TeamInfoProto{
     *      optional int32 team_id = 1; // 队伍id
     *      optional int32 hero_count = 2; // 当前英雄人数
     *      optional int32 leader_server_id = 3; // 队长的服务器id. 不管当前是否合服, 都显示
     *      optional string leader_name = 4; // 队长名字
     *      optional int32 fight_amount_threshold = 5; // 进入的战斗力限制. 0表示不限
     *  }
     * 
     */
    static final int S2C_REFRESH_TEAM_LIST = 50;
    public static final ChannelBuffer clearTeamListMsg = onlySendHeaderMessage(
            MODULE_ID, S2C_REFRESH_TEAM_LIST);

    // --- 与组队服务器断开连接导致退出队伍 ---

    /**
     * 退出当前的队伍, 并提示与组队服务器连接断开. 重新注册队伍列表
     * 
     * 就算当前在进入副本倒计时, 也停掉倒计时
     * 
     * 所有这个模块内正在等待服务器返回的, 全都不要再等了, 不会有返回了
     * 比如创建队伍/加入/离队/准备/取消准备/离队/踢人 等等
     * 
     * 没有附带信息
     */
    static final int S2C_LEAVE_GROUP_MASTER_DISCONNECTED = 49;
    static final ChannelBuffer leaveGroupMasterDisconnected = onlySendHeaderMessage(
            MODULE_ID, S2C_LEAVE_GROUP_MASTER_DISCONNECTED);

    // --- 创建队伍 ---

    /**
     * 创建个队伍, 当前必须没有队伍, 正常应该正注册着要创建的副本
     * 
     * 必须等待服务器返回
     * 
     * 附带
     * 
     * varint32 要创建的副本id
     * varint32 战力要求 0表示没有要求
     * bool 是否满员自动开始
     */
    static final int C2S_CREATE_GROUP = 3;

    /**
     * 创建队伍失败, 附带varint32 错误码
     * 
     * 1. 你已经有队伍了
     * 2. 你当前在副本里
     * 3. 等级不够
     * 4. 要创建的副本id非法. 要么不存在, 要么不是个组队副本
     * 5. 战力要求非法 (负的, 或者超过了你自己的战力)
     * 6. 副本次数已经用完
     * 7. 已经有太多的队伍存在了
     * 8. 创建太频繁, 稍候再试
     * 9. 与组队服务器失去连接, 稍后再试
     */
    static final int S2C_CREATE_GROUP_FAIL = 3;
    static final ChannelBuffer ERROR_CREATE_GROUP_ALREADY_HAVE_GROUP = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_CREATE_GROUP_FAIL, 1);
    static final ChannelBuffer ERROR_CREATE_GROUP_IN_DUNGEON = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_CREATE_GROUP_FAIL, 2);
    static final ChannelBuffer ERROR_CREATE_GROUP_NOT_ENOUGH_LEVEL = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_CREATE_GROUP_FAIL, 3);
    static final ChannelBuffer ERROR_CREATE_GROUP_ID_NOT_FOUND = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_CREATE_GROUP_FAIL, 4);
    static final ChannelBuffer ERROR_CREATE_GROUP_ILLEGAL_FIGHT_AMOUNT = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_CREATE_GROUP_FAIL, 5);
    static final ChannelBuffer ERROR_CREATE_GROUP_TODAY_ENTERED_TOO_MUCH = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_CREATE_GROUP_FAIL, 6);
    static final ChannelBuffer ERROR_CREATE_GROUP_ALREADY_TOO_MANY_TEAMS = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_CREATE_GROUP_FAIL, 7);
    static final ChannelBuffer ERROR_CREATE_GROUP_TOO_FREQUENT = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_CREATE_GROUP_FAIL, 8);
    static final ChannelBuffer ERROR_CREATE_GROUP_MASTER_DISCONNECTED = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_CREATE_GROUP_FAIL, 9);

    /**
     * 创建队伍成功. 自己把界面换成队伍界面, 副本/战力要求/是否满员自动开始, 都根据之前的请求来.
     * 
     * 如果当时有注册着副本信息, 服务器会自动解除注册 (正常情况应该正注册着自己创建的这个副本)
     * 
     * 没有附带信息
     */
    static final int S2C_CREATE_GROUP_SUCCESS = 4;
    static final ChannelBuffer createGroupSuccess = onlySendHeaderMessage(
            MODULE_ID, S2C_CREATE_GROUP_SUCCESS);

    // --- 加入队伍 ---

    /**
     * 请求加入一个队伍. 当前必须不在副本, 等级足够, 不在组队副本队伍(不是普通的队伍)
     * 
     * 必须等待服务器返回
     * 
     * 附带
     * 
     * varint32 副本id
     * varint32 队伍id
     */
    static final int C2S_JOIN_GROUP = 4;

    /**
     * 请求加入队伍失败, 附带varint32 错误码
     * 
     * 1. 在副本中
     * 2. 已经在个队伍中了
     * 3. 副本id不存在
     * 4. 队伍id不存在
     * 5. 等级不够
     * 6. 战力不够别人的要求
     * 7. 队伍已经开始了
     * 8. 队伍已经满了
     * 9. 今日无法再进入
     * 10. 请求太频繁了, 稍后再试
     * 11. 与组队服务器失去连接, 稍后再试
     */
    static final int S2C_JOIN_GROUP_FAIL = 6;
    static final ChannelBuffer ERROR_JOIN_GROUP_IN_DUNGEON = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_JOIN_GROUP_FAIL, 1);
    static final ChannelBuffer ERROR_JOIN_GROUP_IN_GROUP = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_JOIN_GROUP_FAIL, 2);
    static final ChannelBuffer ERROR_JOIN_GROUP_DUNGEON_ID_NOT_FOUND = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_JOIN_GROUP_FAIL, 3);
    static final ChannelBuffer ERROR_JOIN_GROUP_GROUP_ID_NOT_FOUND = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_JOIN_GROUP_FAIL, 4);
    static final ChannelBuffer ERROR_JOIN_GROUP_NOT_ENOUGH_LEVEL = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_JOIN_GROUP_FAIL, 5);
    static final ChannelBuffer ERROR_JOIN_GROUP_NOT_ENOUGH_FIGHT_AMOUNT = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_JOIN_GROUP_FAIL, 6);
    static final ChannelBuffer ERROR_JOIN_GROUP_GROUP_NOT_WAITING = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_JOIN_GROUP_FAIL, 7);
    static final ChannelBuffer ERROR_JOIN_GROUP_GROUP_FULL = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_JOIN_GROUP_FAIL, 8);
    static final ChannelBuffer ERROR_JOIN_GROUP_TODAY_ENTERED_TOO_MUCH = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_JOIN_GROUP_FAIL, 9);
    static final ChannelBuffer ERROR_JOIN_GROUP_TOO_FREQUENT = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_JOIN_GROUP_FAIL, 10);
    static final ChannelBuffer ERROR_JOIN_GROUP_MASTER_DISCONNECTED = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_JOIN_GROUP_FAIL, 11);

    /**
     * 请求加入队伍成功. 如果之前有监听着副本, 服务器会自动取消监听
     * 
     * 附带队伍信息. 队伍id/副本id/战力需求 不再发送, 请求加入队伍前客户端已经知道了
     *
     * bool 是否自动开始
     * while(byteArray.available){
     *   读取每一个队员, 不包括自己, 客户端自己把自己加在最后, 第一个发送的是队长
     * 
     *   varint64 英雄id
     *   UTF 英雄名
     *   varint32 战力
     *   varint32 职业和是否已准备   n >>> 1 职业id, n & 1 == 1 是否已准备 
     *   varint32 等级
     * }
     * 
     */
    public static final int S2C_JOIN_GROUP_SUCCESS = 7;

    /**
     * 有人加入了队伍. 发送给之前就在队伍里的人, 不会发给进队伍的那个人
     * 默认未准备
     * 
     * 附带
     * 
     * varint64 英雄id
     * varint32 战力
     * varint32 职业
     * varint32 等级
     * UTFBytes 名字
     */
    public static final int S2C_OTHER_JOIN_GROUP = 8;

    // --- 准备开始 ---

    /**
     * 将自己的队伍状态设为准备. 当前必须在个队伍里, 且没有准备, 且不能是队长(队长不能准备, 只能开始)
     * 
     * 需要等待服务器返回
     * 
     * 没有附带信息
     */
    static final int C2S_READY = 5;

    /**
     * 准备失败, 附带varint32 错误码
     * 
     * 1. 你没有队伍
     * 2. 你已经准备好了
     * 3. 你是队长
     * 4. 和组队服务器断开连接
     * 5. 准备太频繁, 稍后再试
     */
    public static final int S2C_READY_FAIL = 9;
    static final ChannelBuffer ERROR_READY_NO_TEAM = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_READY_FAIL, 1);
    static final ChannelBuffer ERROR_READY_MASTER_DISCONNECTED = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_READY_FAIL, 4);
    static final ChannelBuffer ERROR_READY_TOO_FREQUENT = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_READY_FAIL, 5);

    /**
     * 准备成功, 把自己的状态设为准备
     * 
     * 没有附带信息
     */
    public static final int S2C_READY_SUCCESS = 10;

    /**
     * 准备成功后, 广播给队伍的其他人, 自己不会收到
     * 
     * 附带
     * 
     * varint64 已准备的人id
     */
    public static final int S2C_OTHER_READY = 11;

    // --- 队长开始 ---

    /**
     * 队伍里成员全部准备, 且人数>=副本最小需要人数时, 队长可以发送
     * 
     * 必须等待服务器返回
     * 
     * 没有附带信息
     */
    static final int C2S_START = 6;

    /**
     * 开始失败, 附带varint32 错误码
     * 
     * 1. 你没有队伍
     * 2. 你不是队长
     * 3. 队伍里有人没准备
     * 4. 人数不够副本最小人数
     * 5. 已经开始了, 不要再开始了
     * 6. 与组队服务器连接断开
     * 7. 操作太频繁, 稍后再试 
     */
    public static final int S2C_START_FAIL = 12;
    static final ChannelBuffer ERROR_START_NO_TEAM = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_START_FAIL, 1);
    static final ChannelBuffer ERROR_START_NOT_LEADER = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_START_FAIL, 2);
    static final ChannelBuffer ERROR_START_SOMEONE_NOT_READY = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_START_FAIL, 3);
    static final ChannelBuffer ERROR_START_TOO_FEW_PEOPLE = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_START_FAIL, 4);
    static final ChannelBuffer ERROR_START_ALREADY_STARTED = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_START_FAIL, 5);
    static final ChannelBuffer ERROR_START_MASTER_DISCONNECTED = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_START_FAIL, 6);
    static final ChannelBuffer ERROR_START_TOO_FREQUENT = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_START_FAIL, 7);

    /**
     * 启动成功, 解锁. 紧接着会收到S2C_STARTED_BROADCAST开始副本的广播
     * 把启动按钮禁用
     * 
     * 注: 队长有可能自己没有按开始, 也会收到S2C_STARTED_BROADCAST. 创建时如果选了自动开始
     * 
     * 没有附带信息
     */
    public static final int S2C_START_SUCCESS = 13;
    static final ChannelBuffer startSuccess = onlySendHeaderMessage(MODULE_ID,
            S2C_START_SUCCESS);

    /**
     * 队长成功启动后, 所有队伍中的人会收到. 禁用离开和启动按钮 (如果是队长, 这里也要禁用启动)
     * 出现5秒倒计时, 5秒后, 服务器会主动发送切场景进入副本消息.
     * 注: 5秒后自动去掉倒计时框, 不管服务器有没有发送切场景消息
     * 
     * 没有附带信息
     */
    public static final int S2C_STARTED_BROADCAST = 14;
    static final ChannelBuffer startedBroadcast = onlySendHeaderMessage(
            MODULE_ID, S2C_STARTED_BROADCAST);

    // --- 取消准备 ---

    /**
     * 将自己的队伍状态设为未准备. 当前必须在个队伍里, 且已经准备, 且没有在开始倒计时, 且不能是队长
     * 
     * 需要等待服务器返回
     * 
     * 没有附带信息
     */
    static final int C2S_CANCEL_READY = 13;

    /**
     * 取消准备失败, 附带varint32 错误码
     * 
     * 1. 你没有队伍
     * 2. 你没有准备
     * 3. 已经开始倒计时准备进副本
     * 4. 和组队服务器断开连接
     * 5. 取消太频繁, 稍后再试
     */
    public static final int S2C_CANCEL_READY_FAIL = 51;
    static final ChannelBuffer ERROR_CANCEL_READY_NO_TEAM = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_CANCEL_READY_FAIL, 1);
    static final ChannelBuffer ERROR_CANCEL_READY_NOT_READY = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_CANCEL_READY_FAIL, 2);
    static final ChannelBuffer ERROR_CANCEL_READY_COUNTING_DOWN = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_CANCEL_READY_FAIL, 3);
    static final ChannelBuffer ERROR_CANCEL_READY_MASTER_DISCONNECTED = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_CANCEL_READY_FAIL, 4);
    static final ChannelBuffer ERROR_CANCEL_READY_TOO_FREQUENT = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_CANCEL_READY_FAIL, 5);

    /**
     * 取消准备成功, 把自己的状态设为为准备
     * 
     * 没有附带信息
     */
    public static final int S2C_CANCEL_READY_SUCCESS = 52;

    /**
     * 取消准备成功后, 广播给队伍的其他人, 自己不会收到
     * 
     * 附带
     * 
     * varint64 取消准备的人id
     */
    public static final int S2C_OTHER_CANCEL_READY = 53;

    // --- 有人离队广播 ---

    /**
     * 要求离开队伍, 当前必须在个队伍中
     * 
     * 必须等待服务器返回
     * 
     * 没有附带信息
     */
    static final int C2S_LEAVE = 7;

    /**
     * 离开队伍失败, 附带varint32 错误码
     * 
     * 1. 你没有队伍
     */
    static final int S2C_LEAVE_FAIL = 15;
    static final ChannelBuffer ERROR_LEAVE_NO_TEAM = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_LEAVE_FAIL, 1);

    /**
     * 离队成功. 并不会自动帮用户注册之前的副本, 如果需要的话, 客户端收到后自动再注册
     * 
     * 没有附带消息
     */
    static final int S2C_LEAVE_SUCCESS = 16;
    static final ChannelBuffer leaveSuccess = onlySendHeaderMessage(MODULE_ID,
            S2C_LEAVE_SUCCESS);

    /**
     * 广播给队伍中其他人, 队伍里有人离队了. 如果离队的是队长, 则排第二的成为队长, 将新队长的是否准备设为false
     * 
     * 附带
     * 
     * varint64 离队的人的id
     */
    public static final int S2C_LEAVED_BROADCAST = 17;

    // --- 踢出队伍 ---

    /**
     * 踢人. 必须是队长, 且不能踢自己. 开始后倒计时期间也不能踢
     * 
     * 必须等服务器返回
     * 
     * 附带
     * 
     * varint64 要踢的人的id
     */
    static final int C2S_KICK = 8;

    /**
     * 踢人失败, 附带varint32 错误码
     * 
     * 1. 你没有队伍
     * 2. 你不是队长
     * 3. 不能踢自己
     * 4. 要踢的人没找到
     * 5. 已经开始了
     * 6. 与组队服务器断开连接
     * 7. 操作太频繁, 稍后再试
     */
    public static final int S2C_KICK_FAIL = 19;
    static final ChannelBuffer ERROR_KICK_NO_TEAM = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_KICK_FAIL, 1);
    static final ChannelBuffer ERROR_KICK_NOT_LEADER = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_KICK_FAIL, 2);
    static final ChannelBuffer ERROR_KICK_CANNOT_KICK_SELF = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_KICK_FAIL, 3);
    static final ChannelBuffer ERROR_KICK_ID_NOT_FOUND = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_KICK_FAIL, 4);
    static final ChannelBuffer ERROR_KICK_NOT_WAITING = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_KICK_FAIL, 5);
    static final ChannelBuffer ERROR_KICK_MASTER_DISCONNECTED = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_KICK_FAIL, 6);
    static final ChannelBuffer ERROR_KICK_TOO_FREQUENT = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_KICK_FAIL, 7);

    /**
     * 踢人成功, 解锁. 紧接着全队会收到S2C_LEAVED_BROADCAST广播
     * 队长收到的这条消息不需要做处理
     * 
     * 没有附带信息
     */
    public static final int S2C_KICK_SUCCESS = 20;

    /**
     * 被踢的人会收到. 把自己的队伍去掉, 并不会自动帮用户注册之前的副本, 如果需要的话, 客户端收到后自动再注册
     * 
     * 没有附带信息
     */
    static final int S2C_BEEN_KICKED = 21;
    public static final ChannelBuffer beenKicked = onlySendHeaderMessage(
            MODULE_ID, S2C_BEEN_KICKED);

    // ---
    /**
     * 你干了某些事情, 导致你自动离开了队伍, 把队伍清掉. 不要自动注册副本了
     * 
     * 比如你进入了副本
     * 
     * 没有附带信息
     */
    static final int S2C_YOU_AUTO_LEFT = 22;
    public static final ChannelBuffer youAutoLeft = onlySendHeaderMessage(
            MODULE_ID, S2C_YOU_AUTO_LEFT);

    // --- 进入场景时, 设置副本剩余时间 ---

    /**
     * 副本有时间限制, 在进入场景之后会收到推送. 
     * 如果没有收到这条消息则不要显示副本结束时间, 即副本是否有时限全根据这条消息驱动
     * 
     * 注: 剩余时间最多减到0秒, 不要搞到负的了
     * 
     * 附带
     * 
     * varint64 结束的时间点 (是个绝对时间, 和当前时间无关的时间)
     */
    public static final int S2C_SET_DUNGEON_END_TIME = 23;

    // --- 副本超时 ---

    /**
     * 副本时间到, 紧接着会收到切场景消息, 等进入场景后, 在界面上展示
     * 
     *  副本时间已用完, 通关失败 (3秒后消息)
     *  
     *  并不一定只是组队副本才会发, 别的会超时的副本都统一用这条
     *  
     *  没有附带信息
     */
    public static final int S2C_DUNGEON_TIME_UP = 34;
    public static final ChannelBuffer dungeonTimeUp = onlySendHeaderMessage(
            MODULE_ID, S2C_DUNGEON_TIME_UP);

    // --- 与组队服断线 ---

    /**
     * 与副本服务器断开连接, 紧接着会收到切场景消息. 
     * 
     * 等进入场景后, 提示玩家与副本服务器连接断开, 稍后再试
     * 
     * 并不一定只是组队副本才会发, 别的跨服场景都统一用这条
     * 
     * 没有附带信息
     */
    public static final int S2C_DUNGEON_DISCONNECTED = 35;
    public static final ChannelBuffer dungeonDisconnected = onlySendHeaderMessage(
            MODULE_ID, S2C_DUNGEON_DISCONNECTED);

    // --- 自动入队 ---

    /**
     * 快速加入, 随便进入个我能进入的队伍
     * 
     * 当前不能在副本, 等级足够, 不能已经在队伍中 
     * 
     * 必须等待服务器返回
     * 
     * 附带
     * 
     * varint32 副本id
     */
    static final int C2S_AUTO_ENTER_GROUP = 9;

    /**
     * 快速加入失败, 附带varint32 错误码
     * 
     * 1. 在副本中
     * 2. 已经在个队伍中了
     * 3. 副本id不存在
     * 4. 等级不够
     * 5. 今日无法再进入
     * 6. 没有你能进的队伍
     * 7. 与组队服务器断开连接
     * 8. 操作太频繁, 稍后再试
     */
    static final int S2C_AUTO_ENTER_GROUP_FAIL = 24;
    static final ChannelBuffer ERROR_AUTO_ENTER_GROUP_IN_DUNGEON = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_AUTO_ENTER_GROUP_FAIL, 1);
    static final ChannelBuffer ERROR_AUTO_ENTER_GROUP_IN_GROUP = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_AUTO_ENTER_GROUP_FAIL, 2);
    static final ChannelBuffer ERROR_AUTO_ENTER_GROUP_ID_NOT_FOUND = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_AUTO_ENTER_GROUP_FAIL, 3);
    static final ChannelBuffer ERROR_AUTO_ENTER_GROUP_NOT_ENOUGH_LEVEL = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_AUTO_ENTER_GROUP_FAIL, 4);
    static final ChannelBuffer ERROR_AUTO_ENTER_GROUP_TODAY_ENTER_LIMIT_REACHED = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_AUTO_ENTER_GROUP_FAIL, 5);
    static final ChannelBuffer ERROR_AUTO_ENTER_GROUP_NO_MATCH_GROUP_FOUND = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_AUTO_ENTER_GROUP_FAIL, 6);
    static final ChannelBuffer ERROR_AUTO_ENTER_GROUP_MASTER_DISCONNECTED = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_AUTO_ENTER_GROUP_FAIL, 7);
    static final ChannelBuffer ERROR_AUTO_ENTER_GROUP_TOO_FREQUENT = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_AUTO_ENTER_GROUP_FAIL, 8);

    /**
     * 进入队伍成功, 进入的副本id一定是之前请求中附带的
     * 
     * 附带
     * varint32 战力需求
     * bool 是否自动开始
     * while(byteArray.available){
     *   读取每一个队员, 不包括自己, 客户端自己把自己加在最后, 第一个发送的是队长
     * 
     *   varint64 英雄id
     *   UTF 英雄名
     *   varint32 战力
     *   varint32 职业和是否已准备   n >>> 1 职业id, n & 1 == 1 是否已准备 
     *   varint32 等级
     * }
     */
    public static final int S2C_AUTO_ENTER_GROUP_SUCCESS = 25;

    /*
     * 以下是副本奖励相关
     */

    /**
     * 副本完成, 客户端在英雄头上倒计时10秒后, 发送C2S_GET_PRIZE_STAT请求评分/时间/获得经验/死亡次数/随机的物品奖励
     * 
     * 所在副本的config.proto中一定有GroupDungeonPrizeProto, 到时候显示也是根据这个显示
     * 
     * 没有附带信息
     */
    static final int S2C_DUNGEON_COMPLETE_WITH_PRIZE = 26;
    public static final ChannelBuffer dungeonCompleteWithPrize = onlySendHeaderMessage(
            MODULE_ID, S2C_DUNGEON_COMPLETE_WITH_PRIZE);

    /**
     * 请求通关具体信息, 每收到一个S2C_DUNGEON_COMPLETE_WITH_PRIZE只能请求一次, 且如果切换了场景就取消
     * 
     * 没有附带信息
     */
    static final int C2S_GET_PRIZE_STAT = 10;

    /**
     * 获取通关信息失败, 附带varint32 错误码
     * 
     * 1. 你当前不在个有完成奖励的组队副本中. 客户端bug? 不要再重试, 再发也没用
     * 2. 没有发给你完成, 或者已经成功获得过一次通关信息了. 客户端bug
     */
    static final int S2C_GET_PRIZE_STAT_FAIL = 27;
    static final ChannelBuffer ERROR_GET_PRIZE_STAT_NOT_IN_GROUP_DUNGEON = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_GET_PRIZE_STAT_FAIL, 1);
    static final ChannelBuffer ERROR_GET_PRIZE_STAT_WRONG_STAGE = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_GET_PRIZE_STAT_FAIL, 2);

    /**
     * 返回通关信息, 收到后展示通关界面
     * 
     * 固定经验/固定奖励根据副本配置展示. s级奖励和v5奖励根据评分和vip等级自己展示
     * 
     * 附带
     * 
     * GroupDungeonFinishStatProto 这个proto
     */
    static final int S2C_GET_PRIZE_STAT_SUCCESS = 28;

    // --- 领取副本奖励 ---

    /**
     * 让客户端选择了箱子后, 请求领取副本奖励
     * 必须等待服务器返回
     * 
     * 没有附带信息
     */
    static final int C2S_COLLECT_DUNGEON_PRIZE = 11;

    /**
     * 领取奖励失败, 附带varint32 错误码
     * 
     * 1. 你当前不在组队副本中
     * 2. 你不能领取. 要么没收到过完成消息, 要么已经领取了. 客户端bug
     * 3. 背包不够. 紧接着会发送离开副本的消息, 并将奖励加到临时仓库
     */
    static final int S2C_COLLECT_DUNGEON_PRIZE_FAIL = 29;
    static final ChannelBuffer ERROR_COLLECT_DUNGEON_PRIZE_NOT_IN_GROUP_DUNGEON = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_COLLECT_DUNGEON_PRIZE_FAIL, 1);
    static final ChannelBuffer ERROR_COLLECT_DUNGEON_PRIZE_NOT_COLLECTABLE = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_COLLECT_DUNGEON_PRIZE_FAIL, 2);
    static final ChannelBuffer ERROR_COLLECT_DUNGEON_PRIZE_BAG_FULL = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_COLLECT_DUNGEON_PRIZE_FAIL, 3);

    /**
     * 领取奖励成功, 客户端只需要播放飞物品和奖励的动画.  真实增加会另外发消息
     * 
     * 没有附带信息
     */
    static final int S2C_COLLECT_DUNGEON_PRIZE_SUCCESS = 30;
    static final ChannelBuffer collectDungeonPrizeSuccess = onlySendHeaderMessage(
            MODULE_ID, S2C_COLLECT_DUNGEON_PRIZE_SUCCESS);

    // --- 临时副本奖励仓库增加可领取副本奖励 ---

    /**
     * 完成个副本但背包不够, 奖励会存在临时区, 会收到这条消息
     * 
     *  附带
     *  
     *  LingYunDungeonCollectablePrizeProto 这个proto. 内有副本id和是否有s级奖励. 客户端自己根据配置/自己vip等级, 展示这个副本的奖励
     */
    static final int S2C_ADD_COLLECTABLE_PRIZE = 31;

    // --- 领取临时仓库内的奖励 ---

    /**
     * 领取临时奖励列表里单个奖励
     * 
     * 必须等待服务器返回
     * 
     * 附带
     * 
     * varint32 序号. 不是副本id, 从0开始
     */
    static final int C2S_COLLECT_TEMP_PRIZE = 12;

    /**
     * 领取失败, 附带varint32 错误码
     * 
     * 1. 序号无效
     * 2. 背包放不下
     */
    static final int S2C_COLLECT_TEMP_PRIZE_FAIL = 32;
    static final ChannelBuffer ERROR_COLLECT_TEMP_PRIZE_ILLEGAL_POS = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_COLLECT_TEMP_PRIZE_FAIL, 1);
    static final ChannelBuffer ERROR_COLLECT_TEMP_PRIZE_BAG_FULL = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_COLLECT_TEMP_PRIZE_FAIL, 2);

    /**
     * 领取成功, 添加物品消息会单独发, 播放个飞物品/奖励的动画. 删除之前请求的那条奖励
     * 
     * 没有附带信息
     */
    static final int S2C_COLLECT_TEMP_PRIZE_SUCCESS = 33;
    static final ChannelBuffer collectTempPrizeSuccess = onlySendHeaderMessage(
            MODULE_ID, S2C_COLLECT_TEMP_PRIZE_SUCCESS);

    // --- 发布自己的组队信息 ---

    /**
     * 发布寻求组队链接
     * 
     * 客户端需判断
     * 
     * 当前必须在个队伍副本的队伍中, 当前不能在倒数状态, 人数不能已满
     *  
     * 距离上一次成功发布链接必须超过10秒. 退出队伍也不重置cd
     * 
     * 没有附带信息
     */
    static final int C2S_DISPLAY_TEAM_INVITE = 15;

    /**
     * 发布失败, 附带varint32 错误码
     * 
     * 1. 你没有队伍
     * 2. 发布太频繁
     * 3. 人数已满
     * 4. 队伍已经开始
     */
    static final int S2C_DISPLAY_TEAM_INVITE_FAIL = 37;
    static final ChannelBuffer ERROR_DISPLAY_TEAM_INVITE_NO_TEAM = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_DISPLAY_TEAM_INVITE_FAIL, 1);
    static final ChannelBuffer ERROR_DISPLAY_TEAM_INVITE_TOO_FREQUENT = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_DISPLAY_TEAM_INVITE_FAIL, 2);
    static final ChannelBuffer ERROR_DISPLAY_TEAM_INVITE_TEAM_FULL = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_DISPLAY_TEAM_INVITE_FAIL, 3);
    static final ChannelBuffer ERROR_DISPLAY_TEAM_INVITE_STARTED = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_DISPLAY_TEAM_INVITE_FAIL, 4);

    /**
     * 发布成功. 设置自己的发布cd, 是收到这条消息之后的10秒. 不能再发送寻求组队链接消息
     * 就算换了个队伍, cd还是在
     * 
     * 紧接着会收到S2C_DISPLAY_TEAM_INVITE_BROADCAST广播, 展示在聊天框的逻辑在那里做, 这里不做
     * 
     * 没有附带信息
     */
    static final int S2C_DISPLAY_TEAM_INVITE_SUCCESS = 38;
    static final ChannelBuffer displayTeamInviteSuccess = onlySendHeaderMessage(
            MODULE_ID, S2C_DISPLAY_TEAM_INVITE_SUCCESS);

    /**
     * 别人发布了一条寻求组队信息, 展示在该展示的地方
     * 
     * 附带
     * 
     * varint64 那人的id
     * varint32 副本的id (找到是哪个副本, 展示名字)
     * varint32 队伍的id  (点击的时候, 发送C2S_JOIN_GROUP来, 附带上面的副本id和队伍id. 需要判断自己够不够等级/是否已通关等等的加入队伍逻辑)
     * varint32 需求的战力, 没有就是0 (点击的时候需要判断自己是不是狗)
     * UTFBytes 那人的名字
     */
    static final int S2C_DISPLAY_TEAM_INVITE_BROADCAST = 39;

    /*
     * 以下是统计伤害量相关的消息, 全部是服务器推送, 从100开始
     */

    // --- 刚进入场景, 初始化场景中有的人 ---

    /**
     * 刚进入个需要统计伤害量的场景, 发送已经在场景中的人(包括自己), 以及他们的伤害量
     * 伤害量是已经除过1000的
     * 
     * 附带
     * 
     * DamageRecordProto 这个proto
     * 具体proto内容:
     *  // 都是repeated的字段, 同一个pos对应的是一个英雄, 你懂的吧?
     *  message DamageRecordProto{
     *      repeated int64 hero_id = 1;
     *      repeated bytes hero_name = 2;
     *      repeated int64 damage_divided_by_1000 = 3; // 已经除过1000的伤害量
     *      repeated bool is_offline = 4; // 是否离线
     *  }
     */
    public static final int S2C_DPS_INIT = 100;

    // --- 有人下线了 ---

    /**
     * dps统计列表中有人下线了, 在他名字后面加个下线的标签, 不修改他的伤害量
     * 
     * 附带
     * 
     * varint64 下线的人的id
     */
    public static final int S2C_DPS_OTHER_OFFLINE = 101;

    // --- 有人退出了 ---

    /**
     * dps统计列表中有人离开副本了, 把他的信息从列表中删除
     * 
     * 附带
     * 
     * varint64 退出的人的id
     */
    public static final int S2C_DPS_OTHER_LEAVE = 102;

    // --- 有人进入了场景 ---

    /**
     * dps列表中, 有人新进入了场景. 加入到列表中, 状态在线, 伤害量0
     * 
     * 附带
     * 
     * varint64 英雄id
     * UTFBytes 英雄的名字
     */
    public static final int S2C_DPS_OTHER_ADDED = 103;

    // --- 之前下线的人上线了 ---

    /**
     * dps列表中, 有之前不在线的上线了. 把状态设为在线, 不改变之前的伤害量
     * 
     * 附带
     * 
     * varint64 英雄id
     */
    public static final int S2C_DPS_OTHER_ONLINE = 104;

    // --- 更新别人的dps ---

    /**
     * 有人的伤害量变化了, 广播(自己也会收到)
     * 
     * 附带
     * 
     * varint64 英雄id
     * varint64 最新的伤害量 (除过1000的) (不是增加的量, 是最新的量)
     */
    public static final int S2C_DPS_UPDATE_DAMAGE = 105;

    // --- 具体消息构建 ---

    static ChannelBuffer displayTeamInvite(long heroID, byte[] heroNameBytes,
            int dungeonID, int teamID, int requiredFightAmount){
        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID,
                S2C_DISPLAY_TEAM_INVITE_BROADCAST, computeVarInt64Size(heroID)
                        + heroNameBytes.length + computeVarInt32Size(dungeonID)
                        + computeVarInt32Size(teamID)
                        + computeVarInt32Size(requiredFightAmount));
        writeVarInt64(buffer, heroID);
        writeVarInt32(buffer, dungeonID);
        writeVarInt32(buffer, teamID);
        writeVarInt32(buffer, requiredFightAmount);
        buffer.writeBytes(heroNameBytes);
        return buffer;
    }

    public static ChannelBuffer setDungeonEndTime(long time){
        return onlySendHeadAndAVarInt64Message(MODULE_ID,
                S2C_SET_DUNGEON_END_TIME, time);
    }

    public static ChannelBuffer addCollectablePrize(
            GroupDungeonCollectablePrizeProto proto){
        return newProtobufMessage(MODULE_ID, S2C_ADD_COLLECTABLE_PRIZE, proto);
    }

    public static ChannelBuffer getDungeonStatSuccess(
            GroupDungeonFinishStatProto proto){
        return newProtobufMessage(MODULE_ID, S2C_GET_PRIZE_STAT_SUCCESS, proto);
    }

    public static ChannelBuffer dpsUpdateDamage(long id, long newAmount){
        return onlySendHeadAnd2VarInt64Message(MODULE_ID,
                S2C_DPS_UPDATE_DAMAGE, id, newAmount);
    }

    public static ChannelBuffer dpsOtherOnline(long id){
        return onlySendHeadAndAVarInt64Message(MODULE_ID, S2C_DPS_OTHER_ONLINE,
                id);
    }

    public static ChannelBuffer dpsOtherAdded(long id, byte[] name){
        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID,
                S2C_DPS_OTHER_ADDED, computeVarInt64Size(id) + name.length);
        writeVarInt64(buffer, id);
        buffer.writeBytes(name);
        return buffer;
    }

    public static ChannelBuffer dpsOtherLeave(long id){
        return onlySendHeadAndAVarInt64Message(MODULE_ID, S2C_DPS_OTHER_LEAVE,
                id);
    }

    public static ChannelBuffer dpsOtherOffline(long id){
        return onlySendHeadAndAVarInt64Message(MODULE_ID,
                S2C_DPS_OTHER_OFFLINE, id);
    }

    public static ChannelBuffer dpsInit(DamageRecordProto proto){
        return newProtobufMessage(MODULE_ID, S2C_DPS_INIT, proto);
    }

    static ChannelBuffer refreshTeamList(ChannelBuffer source){
        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID,
                S2C_REFRESH_TEAM_LIST, source.readableBytes());
        buffer.writeBytes(source);
        return buffer;
    }
}
