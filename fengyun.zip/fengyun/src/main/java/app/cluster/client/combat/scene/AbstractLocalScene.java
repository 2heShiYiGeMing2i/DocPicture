package app.cluster.client.combat.scene;

import static app.protobuf.LogContent.LogEnum.OperateType.*;
import static com.mokylin.sink.util.BufferUtil.*;

import java.io.IOException;
import java.util.Collection;

import org.jboss.netty.buffer.BigEndianHeapChannelBuffer;
import org.jboss.netty.buffer.ChannelBuffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.cluster.protobuf.CombatContent.EnteringHeroProto;
import app.cluster.shared.scene.ClusterSceneHeader;
import app.cluster.shared.scene.CombatHeader;
import app.game.data.ConfigService;
import app.game.data.goods.Goods;
import app.game.data.goods.GoodsData;
import app.game.data.goods.SceneAmountGoodsHolder;
import app.game.data.mount.HeroMount;
import app.game.data.scene.MonsterData;
import app.game.data.scene.NormalSceneData;
import app.game.data.scene.SceneData;
import app.game.data.scene.SceneDatas;
import app.game.entity.Hero;
import app.game.entity.User;
import app.game.module.GoodsContainerMessages.ReduceCooldownGoodsResult;
import app.game.module.GoodsContainerModule;
import app.game.module.Modules;
import app.game.module.guild.Guild;
import app.game.module.scene.*;
import app.game.module.scene.AbstractHeroFightModule.PkMode;
import app.game.service.WorldData;
import app.message.ISender;
import app.protobuf.GoodsServerContent.GoodsServerProto;
import app.protobuf.GoodsServerContent.GoodsType;
import app.protobuf.HeroServerContent.HeroServerProto;
import app.protobuf.LogContent.LogEnum.TransportType;
import app.utils.VariableConfig;

import com.google.common.base.Objects;
import com.mokylin.collection.LongConcurrentSynchronizedHashMap;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.concurrent.DisruptorExecutor;

/**
 * 在本地部分的跨服场景, 和f远程服务器上的场景通信. 可能是combat服, 可能是联服master
 * @author Timmy
 *
 */
public abstract class AbstractLocalScene implements IScene, ILocalClusterScene{
    private static final Logger logger = LoggerFactory
            .getLogger(AbstractLocalScene.class);

    protected final ISender combatClient;

    /**
     * 还是搞个id, 别的地方可能需要这个获得英雄当前所在的场景
     */
    private final int sceneID;

    protected final int uuid;

    protected final SceneData sceneData;

    protected final IClusterLocalDungeonService dungeonService;

    private final Object sharedSync = new Object();

    /**
     * 已经进入了场景的英雄. 不包括正在加载的
     */
    protected final LongConcurrentSynchronizedHashMap<AbstractHeroFightModule> localHeroes;

    /**
     * 是否已经经历过一次CombatClient断线
     *
     * volatile 因为LocalNormalScene设置断线只会有一个线程设置一次
     */
    protected volatile boolean hasDisconnected;

    protected AbstractLocalScene(SceneData sceneData, int sceneID, int uuid,
            IClusterLocalDungeonService dungeonService, ISender combatClient){
        /*
         * 这里直接把英雄id加入到各种counter中, 防止副本被销毁
         * 但不发送消息给combat服, 因为创建时是putIfAbsent的, 未必会进入这个对象
         */
        this.combatClient = combatClient;
        this.uuid = uuid;
        this.sceneData = sceneData;
        this.sceneID = sceneID;
        this.dungeonService = dungeonService;

        this.localHeroes = new LongConcurrentSynchronizedHashMap<>();
    }

    public abstract void processServerDisconnected(DisruptorExecutor exec);

    /**
     * 是否是来自同一个Combat服的
     * @param client
     * @return
     */
    public boolean isSameCombatClient(ISender client){
        return client == combatClient;
    }

    protected Collection<AbstractHeroFightModule> getAllHeroes(){
        return localHeroes.values();
    }

    protected HeroFightModule getHero(long heroID){
        AbstractHeroFightModule hfm = localHeroes.get(heroID);
        if (hfm == null){
            return null;
        }
        return (HeroFightModule) hfm;
    }

    @Override
    public void broadcastDroppableMsg(ChannelBuffer buffer){
        broadcast(buffer);
    }

    @Override
    public void broadcastDroppableMsg(ChannelBuffer buffer, long dontSend){
        broadcast(buffer, dontSend);
    }

    @Override
    public void broadcast(ChannelBuffer buffer){
        int len = buffer.readableBytes() - 2;
        for (AbstractHeroFightModule hfm : getAllHeroes()){
            hfm.sendMessage(buffer);
        }

        ChannelBuffer toSend = ClusterSceneHeader.newFixedSizeMessage(
                ClusterSceneHeader.S2C_BROADCAST, uuid, len);
        toSend.writeBytes(buffer, 2, len);
        combatClient.sendMessage(toSend);
    }

    @Override
    public void broadcast(ChannelBuffer buffer, long dontSend){
        int len = buffer.readableBytes() - 2;
        boolean foundYou = false;
        for (AbstractHeroFightModule hfm : getAllHeroes()){
            if (hfm.getID() != dontSend){
                hfm.sendMessage(buffer);
            } else{
                foundYou = true;
            }
        }

        if (foundYou){
            // 不要发的人id已经找到了
            ChannelBuffer toSend = ClusterSceneHeader.newFixedSizeMessage(
                    ClusterSceneHeader.S2C_BROADCAST, uuid, len);
            toSend.writeBytes(buffer, 2, len);
            combatClient.sendMessage(toSend);
        } else{
            ChannelBuffer toSend = ClusterSceneHeader.newFixedSizeMessage(
                    ClusterSceneHeader.S2C_BROADCAST_DONT_SEND, uuid,
                    computeVarInt64Size(dontSend) + len);
            writeVarInt64(toSend, dontSend);
            toSend.writeBytes(buffer, 2, len);
            combatClient.sendMessage(toSend);
        }
    }

    /**
     * 创建成功, 放到dungeonMap中后, 才发送消息告诉combat服
     * @param heroID
     */
    public void sendHeroEnteringOnDungeonCreated(long heroID){
        // 发消息告诉Combat服
        combatClient
                .sendMessage(ClusterSceneHeader
                        .onlySendHeadAndAVarInt64Message(
                                ClusterSceneHeader.S2C_HERO_ABOUT_TO_COME,
                                uuid, heroID));
    }

    @Override
    public void addHero(AbstractHeroFightModule heroFightModule, long ctime,
            boolean isEnteringFirstScene){
        logger.debug("英雄请求进入跨服场景: {}. uuid: {}", sceneData, uuid);
        PkMode fixPkMode = getSceneData().getFixedPkMode();
        Hero hero = heroFightModule.getHero();
        if (fixPkMode != null){
            // 设置固定PK模式
            hero.setPkMode(fixPkMode);
        }

        // 直接发送进入成功消息, 不等Combat服返回

        // send confirm entered scene message with new
        // x/y/states/life/mana/parent line
        heroFightModule.sendMessage(SceneMessages.sceneEnter(
                hero.getFightData(), getCurrentLineNumber(),
                hero.getIntPkMode()));

        boolean unique = localHeroes.put(heroFightModule.getID(),
                heroFightModule) == null;

        if (!unique){
            logger.error("AbstractLocalScene.addHero时, 英雄已经在场景内了");
        }

        if (hasDisconnected){
            logger.warn(
                    "AbstractLocalScene.addHero时, 场景已经hasDisconnected: {} heroID: {}",
                    getSceneData(), heroFightModule.getID());
            return;
        }
        // 发送消息给Combat服, 包括英雄的最新属性和坐标. 这方法里可能会改变
        // Combat服需要区分英雄是第一次进入场景还是断线重连

        HeroServerProto heroServerProto = hero.encodeHeroServerProto(ctime);

        EnteringHeroProto.Builder proto = EnteringHeroProto.newBuilder()
                .setHero(heroServerProto);

        HeroFightModule hfm = (HeroFightModule) heroFightModule;
        Guild g = hfm.getGuildMember().getGuild();
        if (g != null){
            proto.setGuild(g.encodeForRemote());
        }

        combatClient.sendMessage(CombatHeader.heroEnter(isEnteringFirstScene,
                getSceneConfigDataID(), uuid, hero.getID(),
                hero.getNameBytes(), heroFightModule.getViewRangeX(),
                heroFightModule.getViewRangeY(), proto.build()));
    }

    @Override
    public void removeHero(AbstractHeroFightModule heroFightModule,
            boolean isOffline){
        localHeroes.remove(heroFightModule.getID());
    }

    public void processHeroSceneMessage(HeroFightModule heroFightModule,
            ChannelBuffer buffer, int sequenceID){
        switch (sequenceID){
            case SceneMessages.C2S_SCENE_HERO_MOVE:
            case SceneMessages.C2S_SCENE_CHANGE_DIRECTION:
            case SceneMessages.C2S_SCENE_HERO_JUMP:
            case SceneMessages.C2S_SCENE_STOP_MOVE:
            case SceneMessages.C2S_SCENE_RELEASE_SPELL:
            case SceneMessages.C2S_SCENE_CHANGE_VIEW_RANGE: // 不需要本地处理, 每次切场景, 都会发当前视野大小
            case SceneMessages.C2S_SCENE_PICK_UP_GOODS:
            case SceneMessages.C2S_SCENE_AUTO_COMBAT:
            case SceneMessages.C2S_SCENE_CANCEL_AUTO_COMBAT:
            case SceneMessages.C2S_SCENE_SINGLE_HERO_MEDITATE:
            case SceneMessages.C2S_SCENE_DOUBLE_HERO_MEDITATE:
            case SceneMessages.C2S_SCENE_HERO_CANCEL_MEDITATE:
            case SceneMessages.C2S_SCENE_REQUEST_RELIVE:
                proxyHeroMsgToCombat(heroFightModule.getID(), sequenceID,
                        buffer);
                return;

            default:{
                if (sequenceID == SceneMessages.C2S_SCENE_LOADED){
                    logger.warn("英雄的stage是ENTERED, 但是收到了C2S_SCENE_LOADED");
                    return;
                }
                logger.warn("AbstractLocalScene 有未处理场景消息: {}", sequenceID);
            }
        }
    }

    protected void proxyHeroMsgToCombat(long heroID, int sequenceID,
            ChannelBuffer buffer){
        combatClient.sendMessage(ClusterSceneHeader.S2C.proxySceneModuleMsg(
                uuid, heroID, sequenceID, buffer));
    }

    @Override
    public void sendToRemoteScene(ChannelBuffer buffer){
        combatClient.sendMessage(buffer);
    }

    public int getUUID(){
        return uuid;
    }

    @Override
    public SceneData getSceneData(){
        return sceneData;
    }

    @Override
    public FightModule getTarget(long id){
        throw new UnsupportedOperationException();
    }

    @Override
    public SceneObjectProcessor getSceneObjectProcessor(){
        throw new UnsupportedOperationException();
    }

    @Override
    public FightProcessor getFightProcessor(){
        throw new UnsupportedOperationException();
    }

    @Override
    public int getSceneID(){
        return sceneID;
    }

    @Override
    public int getSceneUUID(){
        return uuid;
    }

    @Override
    public boolean isLocalClusterScene(){
        return true;
    }

    @Override
    public int getSceneConfigDataID(){
        return sceneData.id;
    }

    @Override
    public long getCurrentTime(){
        return dungeonService.getTimeService().getCurrentTime();
    }

    @Override
    public void onMonsterDead(MonsterFightModule dead, FightModule attacker,
            long ctime, long realDeadTime){
        throw new UnsupportedOperationException();
    }

    @Override
    public void onHeroAddMonsterDeadExp(HeroFightModule heroFightModule,
            int amount){
    }

    @Override
    public void onHeroDead(AbstractHeroFightModule heroFightModule){
        throw new UnsupportedOperationException();
    }

    @Override
    public Object getPositionModuleSharedSync(){
        return sharedSync;
    }

    @Override
    public float getMeditateMultiple(){
        return 0;
    }

    @Override
    public void onAddMediateAmount(HeroFightModule hfm, int toAddExp,
            int toAddRealAir){
    }

    @Override
    public VariableConfig getVariableConfig(){
        return dungeonService.getVariableConfig();
    }

    @Override
    public WorldData getWorldData(){
        return dungeonService.getWorldData();
    }

    @Override
    public ConfigService getConfigService(){
        return dungeonService.getConfigService();
    }

    @Override
    public String toString(){
        return Objects.toStringHelper("AbstractLocalScene")
                .add("sceneData", sceneData).add("uuid", uuid).toString();
    }

    // --- 处理Combat服过来的消息 ---

    /**
     * 处理来自Combat服发送给这个场景, 让这个场景处理的消息
     * @param header
     * @param buffer
     * @param client
     */
    public void onSceneMessage(ClusterSceneHeader header, ChannelBuffer buffer){
        switch (header){
            case C2S_PROXY_MSG:{
                onProxyMsg(buffer);
                return;
            }

            case C2S_BROADCAST:{
                onBroadcast(buffer, 0);
                return;
            }

            case C2S_BROADCAST_EXCEPT_ONE:{
                onBroadcast(buffer, readVarInt64(buffer));
                return;
            }

            case C2S_HERO_KILLED_MONSTER:{
                onKilledMonster(buffer);
                return;
            }

            case C2S_HERO_MEDIATE:{
                onHeroMediate(buffer);
                return;
            }

            case C2S_TRY_REDUCE_TOOL_AND_PERFECT_RELIVE:{
                onTryReduceToolAndPerfectRelive(buffer);
                return;
            }

            case C2S_HERO_SET_JUMP_SHIELD:{
                onHeroSetJumpShield(buffer);
                return;
            }

            case C2S_HERO_TRANSPORT_TO_NORMAL_SCENE:{
                onHeroTransportToNormalScene(buffer);
                return;
            }

            case C2S_ADD_SCENE_AMOUNT_GOODS:{
                onAddSceneAmountGoods(buffer);
                return;
            }

            case C2S_TRY_ADD_PICK_UP_GOODS:{
                onTryAddPickUpGoods(buffer);
                return;
            }

            case C2S_HERO_SYNC_POS_AND_LIFE_RAGE:{
                onSyncPosAndLife(buffer);
                return;
            }

            case C2S_HERO_SYNC_POS_LIFE_AND_JUMP_SHIELD_RAGE:{
                onSyncPosLifeJumpShield(buffer);
                return;
            }

            case C2S_SHOOT_MOUNT:{
                onHeroShootMount(buffer);
                return;
            }
            default:{
                logger.error(
                        "有AbstractLocalScene.onSceneMessage收到未处理的ClusterSceneHeader: {}-{}",
                        header.ordinal(), header);
            }
        }
    }

    private void onHeroShootMount(ChannelBuffer buffer){
        final long heroID = readVarInt64(buffer);

        final HeroFightModule hfm = getHero(heroID);
        if (hfm == null){
            logger.debug("AbstractLocalScene.onHeroShootMount时, 英雄已经不在场景中");
            return;
        }

        final HeroMount mount = hfm.getHero().getMount();
        if (mount == null || !mount.isRiding()){
            // 不在马上
            return;
        }

        hfm.getTaskExec().execute(new Runnable(){
            @Override
            public void run(){
                if (!hfm.isInScene(AbstractLocalScene.this)){
                    logger.warn("AbstractLocalScene.onHeroShootMount时, 到exec里处理时, 英雄已经不在之前的场景了, 这么巧?");
                    return;
                }

                if (!mount.isRiding()){
                    // 不在马上
                    return;
                }

                hfm.getServices().getModules().getMountModule()
                        .heroDownFromMount(hfm, getCurrentTime());
            }
        });
    }

    private void onProxyMsg(ChannelBuffer buffer){
        long heroID = readVarInt64(buffer);

        HeroFightModule hfm = getHero(heroID);

        if (hfm == null){
            // 英雄已经下线了
            int moduleID = readVarInt32(buffer);
            int sequenceID = readVarInt32(buffer);

            String msg = Modules.getS2CMsgName(moduleID, sequenceID);
            logger.debug(
                    "AbstractLocalScene.onProxyMsg要转发Combat服的消息给英雄时, 英雄不在场景中了: {} -> {}",
                    heroID, msg);
            return;
        }

        ChannelBuffer newMsg = new BigEndianHeapChannelBuffer(
                buffer.readableBytes() + 2);
        newMsg.writeShort(0);
        newMsg.writeBytes(buffer);
        hfm.sendMessage(newMsg);
    }

    private void onSyncPosLifeJumpShield(ChannelBuffer buffer){
        final long heroID = readVarInt64(buffer);

        final HeroFightModule hfm = getHero(heroID);
        if (hfm == null){
            logger.debug("AbstractLocalScene.onSyncPosLifeJumpShield时, 英雄已经不在场景中");
            return;
        }

        final int x = readVarInt32(buffer);
        final int y = readVarInt32(buffer);
        final int life = readVarInt32(buffer);
        final int jumpShield = readVarInt32(buffer);
        final int rage = readVarInt32(buffer);

        hfm.getTaskExec().execute(new Runnable(){
            @Override
            public void run(){
                if (!hfm.isInScene(AbstractLocalScene.this)){
                    logger.warn("AbstractLocalScene.onSyncPosLifeJumpShield时, 到exec里处理时, 英雄已经不在之前的场景了, 这么巧?");
                    return;
                }

                hfm.setJumpShieldAndSendToSelf(jumpShield);

                FightData fightData = hfm.getFightData();
                fightData.setPosition(x, y);
                fightData.setLife(Utils.getPointWithRange(0,
                        fightData.getMaxLife(), life));

                hfm.getHero().getSpellList().setRageAmount(rage);
            }
        });
    }

    private void onSyncPosAndLife(ChannelBuffer buffer){
        final long heroID = readVarInt64(buffer);

        final HeroFightModule hfm = getHero(heroID);
        if (hfm == null){
            logger.debug("AbstractLocalScene.onSyncPosAndLife时, 英雄已经不在场景中");
            return;
        }

        final int x = readVarInt32(buffer);
        final int y = readVarInt32(buffer);
        final int life = readVarInt32(buffer);
        final int rage = readVarInt32(buffer);

        hfm.getTaskExec().execute(new Runnable(){
            @Override
            public void run(){
                if (!hfm.isInScene(AbstractLocalScene.this)){
                    logger.warn("AbstractLocalScene.onSyncPosAndLife时, 到exec里处理时, 英雄已经不在之前的场景了, 这么巧?");
                    return;
                }

                FightData fightData = hfm.getFightData();
                fightData.setPosition(x, y);

                int oldLife = fightData.getLife();
                int newLife = Utils.getPointWithRange(0,
                        fightData.getMaxLife(), life);
                fightData.setLife(newLife);

                if (oldLife <= 0 && newLife > 0){
                    hfm.setKilled(false);
                } else if (oldLife > 0 && newLife <= 0){
                    hfm.setKilled(true);
                }

                hfm.getHero().getSpellList().setRageAmount(rage);
            }
        });
    }

    private void onTryAddPickUpGoods(ChannelBuffer buffer){
        final long heroID = readVarInt64(buffer);
        final HeroFightModule hfm = getHero(heroID);
        if (hfm == null){
            logger.debug("AbstractLocalScene.onTryAddPickUpGoods时, 英雄已经不在场景中");
            return;
        }

        final int sceneGoodsID = readVarInt32(buffer);
        final Goods g;
        try{
            GoodsServerProto proto = readProto(
                    GoodsServerProto.getDefaultInstance(), buffer,
                    User.extensionRegistry);
            g = Goods.decode(proto, getConfigService(), null);

            if (g == null){
                logger.error("AbstractLocalScene.onTryAddPickUpGoods时, decode出来的goods为null");
                hfm.sendMessage(SceneMessages.ERR_PICK_UP_FAIL_GOODS_NOT_FOUND);
                combatClient.sendMessage(ClusterSceneHeader.S2C
                        .addPickUpGoodsFail(uuid, heroID, sceneGoodsID));
                return;
            }
        } catch (IOException e){
            logger.error(
                    "AbstractLocalScene.onTryAddPickUpGoods时, decode goods出错",
                    e);
            hfm.sendMessage(SceneMessages.ERR_PICK_UP_FAIL_NOT_YOURS);
            combatClient.sendMessage(ClusterSceneHeader.S2C.addPickUpGoodsFail(
                    uuid, heroID, sceneGoodsID));
            return;
        }

        hfm.getTaskExec().execute(new Runnable(){
            @Override
            public void run(){
                if (!hfm.isInScene(AbstractLocalScene.this)){
                    logger.warn("AbstractLocalScene.onTryAddPickUpGoods时, 到exec里处理时, 英雄已经不在之前的场景了, 这么巧?");
                    return;
                }

                Hero hero = hfm.getHero();
                if (!hero.getDepot().hasEnoughEmptyCount(1)){
                    logger.debug("背包已满，不能拾取物品");
                    hfm.sendMessage(SceneMessages.ERR_PICK_UP_FAIL_DEPOT_FULL);
                    combatClient.sendMessage(ClusterSceneHeader.S2C
                            .addPickUpGoodsFail(uuid, heroID, sceneGoodsID));
                    return;
                }

                GoodsContainerModule goodsContainerModule = dungeonService
                        .getGoodsContainerModule();
                goodsContainerModule.addGoods(hfm.getHero(), g,
                        hfm.getSender(), hfm.getHeroMiscModule(),
                        SCENE_GOODS_PICK_UP, 0, getCurrentTime());

                hfm.sendMessage(SceneMessages.pickUpGoodsMsg(sceneGoodsID)); // 通知英雄删除场景中的物品
                combatClient.sendMessage(ClusterSceneHeader.S2C
                        .addPickUpGoodsSuccess(uuid, heroID, sceneGoodsID)); // 通知Combat场景拾取成功
            }
        });
    }

    private void onAddSceneAmountGoods(ChannelBuffer buffer){
        final long heroID = readVarInt64(buffer);

        final HeroFightModule hfm = getHero(heroID);
        if (hfm == null){
            logger.debug("AbstractLocalScene.onAddSceneAmountGoods时, 英雄已经不在场景中");
            return;
        }

        final int sceneGoodsID = readVarInt32(buffer);

        int goodsType = readVarInt32(buffer);

        GoodsType t = GoodsType.valueOf(goodsType);
        if (t == null){
            logger.error(
                    "AbstractLocalScene.onAddSceneAmountGoods时, goodsType没找到. number: {}",
                    goodsType);
            return;
        }

        int amount = readVarInt32(buffer);
        if (amount <= 0){
            logger.error(
                    "AbstractLocalScene.onAddSceneAmountGoods时, 要加的amount<=0: type: {}-{}, amount: {}",
                    goodsType, t, amount);
            return;
        }

        final SceneAmountGoodsHolder goodsHolder = SceneAmountGoodsHolder
                .decode(t, amount);
        if (goodsHolder == null){
            logger.error(
                    "AbstractLocalScene.onAddSceneAmountGoods时, SceneAmountGoodsHolder无法decode出物品: type: {}-{}",
                    goodsType, t);
            return;
        }

        hfm.getTaskExec().execute(new Runnable(){
            @Override
            public void run(){
                if (!hfm.isInScene(AbstractLocalScene.this)){
                    logger.warn("AbstractLocalScene.onAddSceneAmountGoods时, 到exec里处理时, 英雄已经不在之前的场景了, 这么巧?");
                    return;
                }

                hfm.sendMessage(SceneMessages.pickUpGoodsMsg(sceneGoodsID));
                goodsHolder.give(hfm);
            }
        });
    }

    private void onHeroTransportToNormalScene(ChannelBuffer buffer){
        final long heroID = readVarInt64(buffer);

        final HeroFightModule hfm = getHero(heroID);
        if (hfm == null){
            logger.debug("AbstractLocalScene.onHeroTransportToNormalScene时, 英雄已经不在场景中");
            return;
        }

        int inputNormalSceneDataID = readVarInt32(buffer);
        final int line = readVarInt32(buffer);
        int inputX = readVarInt32(buffer);
        int inputY = readVarInt32(buffer);
        int inputTransportTypeNumber = readVarInt32(buffer);

        SceneDatas sceneDatas = getConfigService().getScenes();
        NormalSceneData normalSceneData = sceneDatas
                .getNormal(inputNormalSceneDataID);
        final NormalSceneData sceneData;
        final int x;
        final int y;
        if (normalSceneData == null){
            logger.error(
                    "AbstractLocalScene.onHeroTransportToNormalScene时, 收到的目标场景id没找到. 版本不对? 传了个副本来? sceneID: {}",
                    inputNormalSceneDataID);
            sceneData = sceneDatas.getHeroFirstSceneData();
            x = sceneDatas.getHeroFirstSceneX();
            y = sceneDatas.getHeroFirstSceneY();
        } else{
            sceneData = normalSceneData;
            x = inputX;
            y = inputY;
        }

        final TransportType transportType;
        TransportType t = TransportType.valueOf(inputTransportTypeNumber);
        if (t == null){
            logger.error(
                    "AbstractLocalScene.onHeroTransportToNormalScene时, 收到的TransportType没找到. 版本不对? 当做ASSIST类. type: {}",
                    inputTransportTypeNumber);
            transportType = TransportType.ASSIST;
        } else{
            transportType = t;
        }

        hfm.getTaskExec().execute(new Runnable(){
            @Override
            public void run(){
                if (!hfm.isInScene(AbstractLocalScene.this)){
                    logger.warn("AbstractLocalScene.onHeroTransportToNormalScene时, 到exec里处理时, 英雄已经不在之前的场景了, 这么巧?");
                    return;
                }

                hfm.doChangeScene(sceneData, line, x, y, transportType);
            }
        });
    }

    private void onHeroSetJumpShield(ChannelBuffer buffer){
        final long heroID = readVarInt64(buffer);

        final HeroFightModule hfm = getHero(heroID);
        if (hfm == null){
            logger.debug("AbstractLocalScene.onHeroSetJumpShield时, 英雄已经不在场景中");
            return;
        }

        final int newAmount = readVarInt32(buffer);

        hfm.getTaskExec().execute(new Runnable(){
            @Override
            public void run(){
                if (!hfm.isInScene(AbstractLocalScene.this)){
                    logger.warn("AbstractLocalScene.onHeroSetJumpShield时, 到exec里处理时, 英雄已经不在之前的场景了, 这么巧?");
                    return;
                }

                hfm.setJumpShieldAndSendToSelf(newAmount);
            }
        });
    }

    private void onTryReduceToolAndPerfectRelive(ChannelBuffer buffer){
        final long heroID = readVarInt64(buffer);
        final HeroFightModule hfm = getHero(heroID);
        if (hfm == null){
            logger.debug("AbstractLocalScene.onTryReduceToolAndPerfectRelive时, 英雄已经不在场景中");
            return;
        }

        final int suggestedPos = readVarInt32(buffer);
        hfm.getTaskExec().execute(new Runnable(){
            @Override
            public void run(){
                if (!hfm.isInScene(AbstractLocalScene.this)){
                    logger.warn("AbstractLocalScene.onTryReduceToolAndPerfectRelive时, 到exec里处理时, 英雄已经不在之前的场景了, 这么巧?");
                    return;
                }

                // 检查物品
                GoodsContainerModule goodsModule = dungeonService
                        .getGoodsContainerModule();

                GoodsData perfectReliveGoods = getConfigService().getGoods()
                        .getPerfectReliveGoods();

                long ctime = getCurrentTime();
                ReduceCooldownGoodsResult result = goodsModule
                        .tryReduceCooldownGoods(hfm.getHero(), suggestedPos,
                                perfectReliveGoods, hfm.getSender(), RELIVE, 0,
                                ctime);
                if (result == ReduceCooldownGoodsResult.SUCCESS){
                    combatClient.sendMessage(ClusterSceneHeader.S2C
                            .perfectReliveSuccess(uuid, hfm.getID()));
                    return;
                } else if (result == ReduceCooldownGoodsResult.COOL_DOWN){
                    logger.debug("完美复活，物品正在冷却中");
                    combatClient.sendMessage(ClusterSceneHeader.S2C
                            .perfectReliveFail(uuid, hfm.getID()));
                    hfm.sendMessage(SceneMessages.ERR_RELIVE_FAIL_TOOL_IN_CD);
                    return;
                } else{
                    logger.debug("完美复活，没有找到复活物品");
                    combatClient.sendMessage(ClusterSceneHeader.S2C
                            .perfectReliveFail(uuid, hfm.getID()));
                    hfm.sendMessage(SceneMessages.ERR_RELIVE_FAIL_NO_TOOL_IN_BAG);
                }
            }
        });
    }

    private void onHeroMediate(ChannelBuffer buffer){
        final long heroID = readVarInt64(buffer);
        final HeroFightModule hfm = getHero(heroID);
        if (hfm == null){
            logger.debug("AbstractLocalScene.onHeroMediate时, 英雄已经不在场景中");
            return;
        }

        final boolean isDoubleMediate = readBoolean(buffer);
        hfm.getTaskExec().execute(new Runnable(){
            @Override
            public void run(){
                if (!hfm.isInScene(AbstractLocalScene.this)){
                    logger.warn("AbstractLocalScene.onHeroMediate时, 到exec里处理时, 英雄已经不在之前的场景了, 这么巧?");
                    return;
                }

                hfm.addExpAndRealAirOnMediate(isDoubleMediate);
            }
        });
    }

    private void onKilledMonster(ChannelBuffer buffer){
        final long heroID = readVarInt64(buffer);
        final HeroFightModule hfm = getHero(heroID);
        if (hfm == null){
            logger.debug("AbstractLocalScene.onKilledMonster时, 英雄已经不在场景中");
            return;
        }

        final int monsterDataID = readVarInt32(buffer);

        final MonsterData monsterData = dungeonService.getConfigService()
                .getMonsterDatas().get(monsterDataID);
        if (monsterData == null){
            logger.error(
                    "AbstractLocalScene.onKilledMonster时, 没有找到被杀掉的怪物类型id: {}",
                    monsterDataID);
            return;
        }
        hfm.getTaskExec().execute(new Runnable(){
            @Override
            public void run(){
                if (!hfm.isInScene(AbstractLocalScene.this)){
                    logger.warn("AbstractLocalScene.onKilledMonster时, 到exec里处理时, 英雄已经不在之前的场景了, 这么巧?");
                    return;
                }

                hfm.handleHeroKilledMonsterEvent(monsterData);
            }
        });
    }

    /**
     * 广播消息给每个在场景中的英雄 (正在加载的不发)
     * @param buffer
     * @param dontSend
     */
    private void onBroadcast(ChannelBuffer buffer, long dontSend){
        buffer.markReaderIndex();

        int moduleID = readVarInt32(buffer);
        int sequenceID = readVarInt32(buffer);

        buffer.resetReaderIndex();

        logger.debug("AbstractLocalScene收到Combat服要转发给每个在副本中的玩家消息: {}",
                Modules.getS2CMsgName(moduleID, sequenceID));

        ChannelBuffer toSend = new BigEndianHeapChannelBuffer(
                2 + buffer.readableBytes());
        toSend.writeShort(0);
        toSend.writeBytes(buffer);

        if (dontSend != 0){
            for (AbstractHeroFightModule hfm : localHeroes.values()){
                if (hfm.getID() != dontSend){
                    hfm.sendMessage(toSend);
                }
            }
        } else{
            for (AbstractHeroFightModule hfm : localHeroes.values()){
                hfm.sendMessage(toSend);
            }
        }
    }

}
