package app.cluster.client.combat.scene;

import static app.cluster.client.combat.scene.LongMaiDungeonMessages.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.data.Prize;
import app.game.data.goods.GoodsAddHelper;
import app.game.data.goods.GoodsTryAddResult;
import app.game.data.scene.LongMaiDungeonSceneData;
import app.game.entity.Hero;
import app.game.module.scene.AbstractHeroFightModule;
import app.game.module.scene.HeroFightModule;
import app.game.module.scene.IClusterLocalDungeonService;
import app.message.ISender;
import app.protobuf.ConfigContent.ShengWangType;
import app.protobuf.LogContent.LogEnum.OperateType;

import com.mokylin.collection.IntValueLongConcurrentHashMap;

public class LocalLongMaiDungeonScene extends LocalGroupDungeonScene{
    private static final Logger logger = LoggerFactory
            .getLogger(LocalLongMaiDungeonScene.class);

    private final LongMaiDungeonSceneData sceneData;

    /**
     * 可领取非首通奖励的英雄id
     */
    private final IntValueLongConcurrentHashMap canCollectNotFirstPassPrizeHeroID;

    public LocalLongMaiDungeonScene(LongMaiDungeonSceneData sceneData,
            int uuid, IClusterLocalDungeonService dungeonService,
            ISender combatClient, long heroID){
        super(sceneData, uuid, dungeonService, combatClient, heroID);

        this.sceneData = sceneData;
        this.canCollectNotFirstPassPrizeHeroID = new IntValueLongConcurrentHashMap(
                8);
    }

    @Override
    public LongMaiDungeonSceneData getSceneData(){
        return sceneData;
    }

    @Override
    public void addHero(AbstractHeroFightModule heroFightModule, long ctime,
            boolean isEnteringFirstScene){
        super.addHero(heroFightModule, ctime, isEnteringFirstScene);

        if (hasDisconnected)
            return;

        if (heroFightModule instanceof HeroFightModule){
            ((HeroFightModule) heroFightModule).getHeroMiscModule()
                    .tryCompleteShengWangTask(ShengWangType.SW_LONG_MAI, true,
                            1);
        } else{
            logger.error("守护龙脉副本本地场景中的居然不是 HeroFightModule");
        }
    }

    @Override
    public void removeHero(AbstractHeroFightModule hfm, boolean isOffline){
        super.removeHero(hfm, isOffline);

        if (canHeroCollectNotFirstPassPrizeAndRemove(hfm.getID())){
            // 如果可领取非首通奖励, 则物品发邮件, 数值直接加
            HeroFightModule heroFightModule = (HeroFightModule) hfm;
            Prize prize = sceneData.getNotFirstPassPrize();

            Hero hero = heroFightModule.getHero();

            prize.giveIgnoreGoods(heroFightModule.getHeroMiscModule(), hero,
                    false, OperateType.COLLECT_DUNGEON_PRIZE, null);

            long ctime = getCurrentTime();

            if (prize.hasGoods()){
                GoodsAddHelper[] gah = prize.newGoodsAddHelpers(ctime);

                GoodsTryAddResult result = hero.getDepot().canAddGoods(gah);
                if (!result.isSuccess()){
                    // 失败, 发邮件
                    dungeonService.getMailModule()
                            .newMailOnDepotEmptyPosNotEnough(hero,
                                    prize.newGoodsAddHelpers(ctime));
                } else{
                    // 成功, 放到背包
                    dungeonService.getGoodsContainerModule()
                            .addBatchGoodsArray(gah, result, hero,
                                    heroFightModule.getSender(),
                                    heroFightModule.getHeroMiscModule(),
                                    OperateType.COLLECT_DUNGEON_PRIZE,
                                    getSceneConfigDataID(), ctime);
                }
            }
        }
    }

    boolean canHeroCollectNotFirstPassPrizeAndRemove(long heroID){
        return canCollectNotFirstPassPrizeHeroID.remove(heroID);
    }

    @Override
    protected void onFinished(final int deadCount, final int totalDuration){
        for (final AbstractHeroFightModule heroFightModule : getAllHeroes()){
            heroFightModule.getTaskExec().execute(new Runnable(){
                @Override
                public void run(){
                    if (!heroFightModule
                            .isInScene(LocalLongMaiDungeonScene.this)){
                        // 已经离开场景了, 算了
                        return;
                    }

                    // 当前一定在线
                    boolean hasTodayFirstPassed = heroFightModule.getHero()
                            .hasLongMaiTodayFirstPassed();
                    if (!hasTodayFirstPassed){
                        // 今日没有首通过
                        // 走通用的完成流程
                        heroFightModule.getHero().setLongMaiTodayFirstPassed();
                        heroFightModule.sendMessage(setTodayFirstPassed);
                        onDungeonFinishStartGiveDungeonPrize(heroFightModule,
                                getCurrentTime(), deadCount, totalDuration);
                    } else{
                        // 今日首通过
                        // 走特殊的完成流程
                        if (canCollectNotFirstPassPrizeHeroID.put(
                                heroFightModule.getID(), 1) != -1){
                            logger.error("LongMaiDungeonScene.onHeroFinishedDungeon, 把英雄加入到可领取非首通奖励列表中时, 英雄id已经在列表中了");
                        } else{
                            heroFightModule
                                    .sendMessage(dungeonFinishedAndCollectNotFirstPassPrize);
                        }
                    }
                }
            });
        }
    }
}
