package app.cluster.client.combat.scene;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.module.scene.IScene;

public interface ILocalClusterScene extends IScene{

    /**
     * 直接就把消息发送了, 方法里不会修改buffer
     * @param buffer
     */
    void sendToRemoteScene(ChannelBuffer buffer);
}
