package app.cluster.client.combat.scene;

import static com.mokylin.sink.util.BufferUtil.*;

import org.jboss.netty.buffer.ChannelBuffer;

import app.game.module.Modules;

public class PortalDungeonMessages{

    public static final int MODULE_ID = Modules.PORTAL_DUNGEON_MODULE_ID;

    // --- 设置副本进入次数 ---
    /**
     * 设置无绝神阵进入已进入次数. 只有这一条消息能改变次数. 外加每日空数据消息, 客户端自己清掉
     *
     * 附带
     *
     * varint32 已进入次数 (最新值, 不是增加的量)
     */
    static final int S2C_SET_ENTERED_TIMES = 1;

    // --- 刚进入时, 发送每个传送门的类型 ---

    /**
     * 英雄刚进入时, 服务器会发送每个传送门的类型, 以及他们是否被使用过
     *
     * 相当于客户端一进副本就知道副本内所有传送门的类型, 只是如果没有被使用过, 就不在门上显示字
     * 发类型时, 只发每一层的生门所在的位置(文档按休门), 知道生门位置后, 别的门类型也就知道了
     *
     * 每一层北边的门, index为0, 顺时针+1.
     *
     * 附带
     *
     * varint32 门的类型 n
     * 每一层的生门index 读法. 层数由0开始
     *
     * function getRightDoorIndex(int n, int level):int{
     *      return (n >>> (level * 3)) & 7; // 每个括号都很重要
     * }
     *
     * 由方法可知道从1-7层每层的生门的index (第8层没有门)
     * ---------
     *
     * 以下是每个门是否已使用过, 使用过, 则在门上显示门的类型
     * 总共7层有门, 每层8个门. 共56个门. 每个门的总index = 所在的level(从0开始) * 8 + 自己在这一层中的index (北门是0, 顺时针+1)
     *
     * varint32 0-27号门的使用状况 n1
     * varint32 28-55号门的使用状况 n2
     *
     * 获取每个门是否使用过
     *
     * function isDoorUsed(int n1, int n2, int doorIndex):boolean{
     *  var n:int = doorIndex <= 27 ? n1 : n2;
     *  var index:int = doorIndex <= 27 ? doorIndex : doorIndex - 28;
     *
     *  return ((n >>> index) & 1) == 1;
     * }
     *
     * ---
     *
     * varint32 你当前所在的层数
     *
     */
    static final int S2C_INIT = 2;

    // --- 请求走传送门 ---

    /**
     * 玩家点击传送门后发送
     *
     * 必须等待服务器返回
     *
     * 附带
     *
     * varint32 门的id (0-55)
     */
    static final int C2S_TRY_TRANSPORT = 1;

    /**
     * 传送失败, 附带varint32 错误码
     *
     * 1. 门id非法 客户端bug
     * 2. 离门太远了 2格之内才能. 客户端继续往门这里走两步
     * 3. 此门不通 只有第一层时才会收到
     * 4. 你当前不在无绝神阵副本中
     * 5. 跳跃中
     * 6. 你挂了 (虽然不太可能)
     * 7. 晕眩中 (虽然不太可能)
     */
    static final int S2C_TRY_TRANSPORT_FAIL = 3;
    public static final ChannelBuffer ERROR_TRANSPORT_ILLEGAL_ID = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_TRY_TRANSPORT_FAIL, 1);
    public static final ChannelBuffer ERROR_TRANSPORT_TOO_FAR = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_TRY_TRANSPORT_FAIL, 2);
    public static final ChannelBuffer ERROR_TRANSPORT_DOOR_NOT_USABLE = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_TRY_TRANSPORT_FAIL, 3);
    static final ChannelBuffer ERROR_TRANSPORT_DOOR_NOT_IN_PORTAL = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_TRY_TRANSPORT_FAIL, 4);
    public static final ChannelBuffer ERROR_TRANSPORT_DOOR_JUMPING = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_TRY_TRANSPORT_FAIL, 5);
    public static final ChannelBuffer ERROR_TRANSPORT_DOOR_DEAD = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_TRY_TRANSPORT_FAIL, 6);
    public static final ChannelBuffer ERROR_TRANSPORT_DOOR_STUN = onlySendHeadAndAVarInt32Message(
            MODULE_ID, S2C_TRY_TRANSPORT_FAIL, 7);

    /**
     * 传送成功
     *
     * 解锁, 逻辑都做在下面这条广播的消息里
     */
    static final int S2C_TRANSPORT_SUCCESS = 4;
    public static final ChannelBuffer transportSuccess = onlySendHeaderMessage(
            MODULE_ID, S2C_TRANSPORT_SUCCESS);

    /**
     * 有人传送成功了. 这条消息需要显示对应的提示, 展示对应的门上的字. 并把英雄传送到相应的坐标
     *
     * 如果id是自己, 使用的门的层数 == 目标层数, 则提示 此门不通
     *
     * 如果使用的是生门, 而且此门之前是没用过的, 没显示门类型的, 则根据层数, 多展示个对应的提示
     * 　恭喜【XX玩家名称】成功找到生门，前进至第X层
     * 　恭喜【XX玩家名称】成功找到生门，前进至最顶层，击败绝无神即可破阵
     *
     * 附带
     *
     * varint64 英雄id
     * varint32 使用的门id  (客户端可以知道英雄之前的层数, 以及使用的门类型)
     * varint32 目标层数 (可能和之前所在的层数相同)
     * varint32 英雄最新坐标x
     * varint32 英雄最新坐标y
     * bytes 英雄名字
     */
    static final int S2C_TRANSPORT_SUCCESS_BROADCAST = 5;

    // --- 具体消息构建 ---

    public static ChannelBuffer transportSuccessBroadcast(long id,
            byte[] nameBytes, int doorIndex, int targetLevel, int newX, int newY){
        ChannelBuffer buffer = newFixedSizeMessage(MODULE_ID,
                S2C_TRANSPORT_SUCCESS_BROADCAST, computeVarInt64Size(id)
                        + computeVarInt32Size(doorIndex)
                        + computeVarInt32Size(targetLevel)
                        + computeVarInt32Size(newX) + computeVarInt32Size(newY)
                        + nameBytes.length);
        writeVarInt64(buffer, id);
        writeVarInt32(buffer, doorIndex);
        writeVarInt32(buffer, targetLevel);
        writeVarInt32(buffer, newX);
        writeVarInt32(buffer, newY);
        buffer.writeBytes(nameBytes);
        return buffer;
    }

    public static ChannelBuffer init(int doorIndexCombinedInt, int usedDoor1,
            int usedDoor2, int yourLevel){
        return onlySendHeadAnd4VarInt32Message(MODULE_ID, S2C_INIT,
                doorIndexCombinedInt, usedDoor1, usedDoor2, yourLevel);
    }

    public static ChannelBuffer setEnteredTimes(int times){
        return onlySendHeadAndAVarInt32Message(times, S2C_SET_ENTERED_TIMES,
                times);
    }
}
