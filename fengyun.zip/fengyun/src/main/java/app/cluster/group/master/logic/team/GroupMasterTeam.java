package app.cluster.group.master.logic.team;

import static com.mokylin.sink.util.BufferUtil.*;

import org.jboss.netty.buffer.ChannelBuffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.cluster.client.logic.team.ClusterClientMessages;
import app.cluster.combat.master.CombatMasterServerInfo;
import app.cluster.group.codec.GroupHeader;
import app.cluster.group.master.GroupMasterWorker;
import app.cluster.protobuf.TeamContent.TeamInfoProto;
import app.utils.ClusterDungeonIDUtils;
import app.utils.VariableConfig;

import com.google.common.base.Objects;

/**
 * 已创建的队伍. 必须由GroupMasterTeamMatcher线程才能访问
 * @author Timmy
 *
 */
public class GroupMasterTeam{
    private static final Logger logger = LoggerFactory
            .getLogger(GroupMasterTeam.class);

    private final GroupMasterTeamMatcher matcher;

    final int id;

    private final GroupMasterHero[] heroes;

    private final int fightAmountThreshold;

    private final boolean fullAutoStart;

    /**
     * 这个时间前还没开始, 就解散队伍
     */
    private final long dismissIfNotStartTime;

    /**
     * 当前已有的人数
     */
    private int heroCount;

    /**
     * 队伍是否已销毁. 开始了或者解散了
     */
    private boolean destroyed;

    GroupMasterTeam(GroupMasterTeamMatcher matcher, int id,
            GroupMasterHero leader, int fightAmountThreshold,
            boolean fullAutoStart, long ctime){
        this.matcher = matcher;
        this.id = id;
        this.heroes = new GroupMasterHero[matcher.sceneData.maxHeroCount];
        heroes[0] = leader;
        this.fightAmountThreshold = fightAmountThreshold;
        this.fullAutoStart = fullAutoStart;
        this.heroCount = 1;
        this.dismissIfNotStartTime = ctime
                + VariableConfig.GROUP_DUNGEON_CLUSTER_TEAM_DISMISS_TIME_IF_NOT_START;
    }

    /**
     * 如果很久没开始, 就解散
     *
     * @param ctime
     * @return
     */
    boolean needDismiss(long ctime){
        return ctime >= dismissIfNotStartTime;
    }

    void doDismiss(){
        destroyed = true;
        GroupMasterHero hero;
        for (int i = 0; i < heroCount; i++){
            hero = heroes[i];
            if (hero == null){
                logger.error("GroupMasterTeam.clearOnDismiss时, 0-heroCount中有null");
                continue;
            } else{
                matcher.removeHeroTeam(hero.heroID);
                hero.sendMessage(GroupHeader.beenKicked(hero.heroID));
                heroes[i] = null;
            }
        }
    }

    boolean isLeader(long heroID){
        return heroes[0] != null && heroes[0].heroID == heroID;
    }

    int getFightAmountThreshold(){
        return fightAmountThreshold;
    }

    boolean isAlive(){
        return !destroyed;
    }

    /**
     * 删除来自这个服务器的玩家. 如果所有的玩家都是这个服务器的, 则删除队伍
     * @param worker
     */
    void removeHeroFromServer(GroupMasterWorker worker){
        GroupMasterHero hero;
        for (int i = heroCount; --i >= 0;){
            hero = heroes[i];
            if (hero == null){
                logger.error("GroupMasterTeam.removeHeroFromServer时, 0-heroCount中有null");
                continue;
            } else{
                if (!hero.sender.isAlive()){ // 用isAlive来判断, 这样就算有之前已经断线的漏网之鱼, 也能删掉
                    logger.debug("移除来自断线游戏服的玩家: {}", hero);
                    doRemoveHeroByIndex(i);

                    matcher.removeHeroTeam(hero.heroID);
                }
            }
        }

        // 全都是来自这个服务器的
        if (heroCount == 0){
            logger.debug("游戏服断线, 这个队伍里所有玩家都被移除了, 队伍删除: {}", this);
            destroyed = true;
            matcher.removeTeam(id);
        }
    }

    /**
     * 尝试开始. 返回是否开始了
     * @return
     */
    void tryStart(){
        // 开始的一定是队长

        GroupMasterHero leader = heroes[0];

        if (heroCount < matcher.sceneData.minHeroCount){
            leader.sendMessage(GroupHeader.proxyMsgOnlyHeaderAnd1Varint32(
                    leader.heroID, ClusterClientMessages.MODULE_ID,
                    ClusterClientMessages.S2C_START_FAIL, 4)); // 不够最小人数
            return;
        }

        GroupMasterHero hero;
        for (int i = 1; i < heroCount; i++){
            hero = heroes[i];
            if (hero != null){
                if (!hero.isReady){
                    leader.sendMessage(GroupHeader
                            .proxyMsgOnlyHeaderAnd1Varint32(leader.heroID,
                                    ClusterClientMessages.MODULE_ID,
                                    ClusterClientMessages.S2C_START_FAIL, 3)); // 有人没准备
                    return;
                }
            } else{
                logger.error("GroupMasterTeam.tryStart时, 0-heroCount之间有null的英雄");
            }
        }

        // 都准备了

        // 给队长发给开始成功消息
        leader.sendMessage(GroupHeader.proxyMsgOnlyHeader(leader.heroID,
                ClusterClientMessages.MODULE_ID,
                ClusterClientMessages.S2C_START_SUCCESS));

        doStart();
    }

    private void doStart(){
        // 决定要去哪个combat服, 决定场景的uuid, 删除heroes里所有英雄, destroy设为true, 把所有英雄从heroTeam中删除, 把队伍从teams里删除, 给每个人发消息
        CombatMasterServerInfo combatServer = matcher
                .getLowestLowCombatServer();
        if (combatServer == null){
            logger.error("GroupMasterTeam.doStart时, 没有combatServer可用...");
            return; // 不管, 也不发消息, 也不解散队伍
        }
        destroyed = true;

        // 进入场景的时候由游戏服决定, 收到提示的时间+5秒, 这样就算有延迟, 也是在玩家消息后5秒
        int dungeonUUID = newDungeonUUID();
        GroupMasterHero hero;
        for (int i = 0; i < heroCount; i++){
            hero = heroes[i];
            if (hero == null){
                logger.error("GroupMasterTeam.doStart时, 0-heroCount中有null英雄");
            } else{
                heroes[i] = null;
                matcher.removeHeroTeam(hero.heroID);
                hero.sendMessage(GroupHeader.startBroadcast(hero.heroID,
                        combatServer.id, matcher.sceneID, dungeonUUID));
            }
        }

        matcher.removeTeam(id);
    }

    private int newDungeonUUID(){
        return ClusterDungeonIDUtils.newDungeonUUID(getAverageLevel()); // 把队伍平均等级作为最右边的部分encode进id
    }

    private int getAverageLevel(){
        if (heroCount <= 0){
            logger.error("GroupMasterTeam.getAverageLevel时, heroCount<=0: {}",
                    this);
            return 0;
        }
        int total = 0;
        GroupMasterHero hero;
        for (int i = 0; i < heroCount; i++){
            hero = heroes[i];
            if (hero == null){
                logger.error("GroupMasterTeam.getAverageLevel时, 0-heroCount中间有null");
            } else{
                total += hero.level;
            }
        }
        return total / heroCount;
    }

    /**
     * 尝试踢人. 返回是否踢成功了.
     * @param targetID
     * @return
     */
    boolean tryKick(long targetID){
        // 踢人的一定是队长

        int index = getMemberIndex(targetID);
        if (index <= 0){ // 没找到或者要踢自己
            heroes[0].sendMessage(GroupHeader.proxyMsgOnlyHeaderAnd1Varint32(
                    heroes[0].heroID, ClusterClientMessages.MODULE_ID,
                    ClusterClientMessages.S2C_KICK_FAIL, 4));
            return false;
        }

        GroupMasterHero beenKicked = heroes[index];
        beenKicked.sendMessage(GroupHeader.beenKicked(targetID));

        heroes[0].sendMessage(GroupHeader.proxyMsgOnlyHeader(heroes[0].heroID,
                ClusterClientMessages.MODULE_ID,
                ClusterClientMessages.S2C_KICK_SUCCESS));

        doRemoveHeroByIndex(index);

        return true;
    }

    private void doRemoveHeroByIndex(int index){
        GroupMasterHero removedHero = heroes[index];
        removeMember(index);

        if (heroCount == 0){
            return;
        }

        if (index == 0){
            // 把新队长设为未准备
            heroes[0].isReady = false;
        }

        // 广播给所有还在队中的人, 此人走了
        GroupMasterHero hero;
        for (int i = 0; i < heroCount; i++){
            hero = heroes[i];
            if (hero != null){
                ChannelBuffer buffer = GroupHeader
                        .proxyMsgOnlyHeaderAnd1Varint64(hero.heroID,
                                ClusterClientMessages.MODULE_ID,
                                ClusterClientMessages.S2C_LEAVED_BROADCAST,
                                removedHero.heroID);
                hero.sendMessage(buffer);
            } else{
                logger.error("GroupMasterTeam.doRemoveHeroByIndex时, 0-heroCount之间有null的英雄");
            }
        }
    }

    /**
     * 删除英雄, 返回当前队伍是否还存活
     * @param heroID
     * @return true 队伍还存活, false 队伍已经没了
     */
    boolean removeHero(long heroID){
        int index = getMemberIndex(heroID);
        if (index == -1){
            return !destroyed; // 直接返回是否存活
        }

        doRemoveHeroByIndex(index);

        // 没人了, 销毁
        if (heroCount == 0){
            destroyed = true;
            return false;
        }

        return true;
    }

    private void removeMember(int index){
        int numMoved = heroCount - index - 1;
        if (numMoved > 0){
            System.arraycopy(heroes, index + 1, heroes, index, numMoved);
        }

        heroes[--heroCount] = null;
    }

    private int getMemberIndex(long heroID){
        GroupMasterHero hero;
        for (int i = 0; i < heroCount; i++){
            hero = heroes[i];
            if (hero != null && hero.heroID == heroID){
                return i;
            }
        }
        return -1;
    }

    int getMaxHeroCount(){
        return matcher.sceneData.maxHeroCount;
    }

    boolean canAddMoreHero(){
        return heroCount < getMaxHeroCount();
    }

    /**
     * 哥这水平能进你的队伍不
     * @param fightAmount
     * @return
     */
    boolean canFightAmountEnter(int fightAmount){
        return fightAmountThreshold == 0 || fightAmount >= fightAmountThreshold;
    }

    void doAutoJoin(GroupMasterHero toAdd){
        assert heroCount < getMaxHeroCount();

        // 发送自动加入成功消息给hero
        ChannelBuffer autoJoinSuccess = GroupHeader.proxyMsgDynamic(
                toAdd.heroID, ClusterClientMessages.MODULE_ID,
                ClusterClientMessages.S2C_AUTO_ENTER_GROUP_SUCCESS,
                20 * heroCount);
        writeVarInt32(autoJoinSuccess, fightAmountThreshold);
        writeBoolean(autoJoinSuccess, fullAutoStart);

        GroupMasterHero hero;

        for (int i = 0; i < heroCount; i++){
            hero = heroes[i];
            if (hero == null){
                logger.error("GroupMasterTeam.doAddHero时, 0-heroCount之间有null的英雄");
                continue;
            }

            hero.writeToInList(autoJoinSuccess);
            // 发送此英雄入队的消息
            ChannelBuffer otherJoinMsg = GroupHeader.proxyMsgDynamic(
                    hero.heroID, ClusterClientMessages.MODULE_ID,
                    ClusterClientMessages.S2C_OTHER_JOIN_GROUP, 20);
            toAdd.writeToInSingle(otherJoinMsg);
            hero.sendMessage(otherJoinMsg);
        }

        toAdd.sendMessage(autoJoinSuccess);

        heroes[heroCount++] = toAdd;
    }

    void doAddHero(GroupMasterHero toAdd){
        assert heroCount < getMaxHeroCount();

        // 发送当前队伍的信息给hero
        ChannelBuffer joinSuccess = GroupHeader.proxyMsgDynamic(toAdd.heroID,
                ClusterClientMessages.MODULE_ID,
                ClusterClientMessages.S2C_JOIN_GROUP_SUCCESS, 20 * heroCount);
        writeBoolean(joinSuccess, fullAutoStart);
        GroupMasterHero hero;
        for (int i = 0; i < heroCount; i++){
            hero = heroes[i];
            if (hero == null){
                logger.error("GroupMasterTeam.doAddHero时, 0-heroCount之间有null的英雄");
                continue;
            }

            hero.writeToInList(joinSuccess);
            // 发送此英雄入队的消息
            ChannelBuffer otherJoinMsg = GroupHeader.proxyMsgDynamic(
                    hero.heroID, ClusterClientMessages.MODULE_ID,
                    ClusterClientMessages.S2C_OTHER_JOIN_GROUP, 20);
            toAdd.writeToInSingle(otherJoinMsg);
            hero.sendMessage(otherJoinMsg);
        }

        toAdd.sendMessage(joinSuccess);

        heroes[heroCount++] = toAdd;
    }

    void doCancelReady(long heroID){
        if (destroyed){
            logger.error("GroupMasterTeam.doCancelReady时, 竟然已经destroy了...");
            return;
        }

        int index = getMemberIndex(heroID);
        if (index == -1){
            logger.error("GroupMasterTeam.doCancelReady时, 已经没有找到要cancelReady的英雄id");
            return;
        }

        GroupMasterHero hero = heroes[index];
        // 不需要判断队长
        if (!hero.isReady){
            // 没有准备
            hero.sendMessage(GroupHeader.proxyMsgOnlyHeaderAnd1Varint32(heroID,
                    ClusterClientMessages.MODULE_ID,
                    ClusterClientMessages.S2C_CANCEL_READY_FAIL, 2));
            return;
        }

        hero.isReady = false;

        // 通知英雄自己
        hero.sendMessage(GroupHeader.proxyMsgOnlyHeader(heroID,
                ClusterClientMessages.MODULE_ID,
                ClusterClientMessages.S2C_CANCEL_READY_SUCCESS));

        // 通知队伍中的其他人, 这个人取消准备了
        for (int i = 0; i < heroCount; i++){
            if (i == index){
                continue;
            }

            hero = heroes[i];
            if (hero != null){
                hero.sendMessage(GroupHeader.proxyMsgOnlyHeaderAnd1Varint64(
                        hero.heroID, ClusterClientMessages.MODULE_ID,
                        ClusterClientMessages.S2C_OTHER_CANCEL_READY, heroID));
            }
        }
    }

    void doReady(long heroID){
        if (destroyed){
            logger.error("GroupMasterTeam.doReady时, 竟然已经destroy了...");
            return;
        }

        int index = getMemberIndex(heroID);
        if (index == -1){
            logger.error("GroupMasterTeam.doReady时, 竟然没有找到ready的英雄id");
            return;
        }

        GroupMasterHero hero = heroes[index];
        if (index == 0){
            // 是队长
            hero.sendMessage(GroupHeader.proxyMsgOnlyHeaderAnd1Varint32(heroID,
                    ClusterClientMessages.MODULE_ID,
                    ClusterClientMessages.S2C_READY_FAIL, 3));
            return;
        }

        if (hero.isReady){
            // 已经ready了
            hero.sendMessage(GroupHeader.proxyMsgOnlyHeaderAnd1Varint32(heroID,
                    ClusterClientMessages.MODULE_ID,
                    ClusterClientMessages.S2C_READY_FAIL, 2));
            return;
        }

        hero.isReady = true;

        // 通知英雄自己
        hero.sendMessage(GroupHeader.proxyMsgOnlyHeader(heroID,
                ClusterClientMessages.MODULE_ID,
                ClusterClientMessages.S2C_READY_SUCCESS));

        // 通知队伍中的其他人, 这个人已经ready了
        for (int i = 0; i < heroCount; i++){
            if (i == index){
                continue;
            }

            hero = heroes[i];
            if (hero != null){
                hero.sendMessage(GroupHeader.proxyMsgOnlyHeaderAnd1Varint64(
                        hero.heroID, ClusterClientMessages.MODULE_ID,
                        ClusterClientMessages.S2C_OTHER_READY, heroID));
            } else{
                logger.error("GroupMasterTeam.doReady时, 0-heroCount之间有null的英雄");
            }
        }

        // 如果是自动开始的, 且如果所有的都已经准备, (除了队长) 则开始

        if (fullAutoStart && heroCount == getMaxHeroCount()){
            for (int i = 1; i < heroCount; i++){
                hero = heroes[i];
                if (hero != null){
                    if (!hero.isReady){
                        // 有人没准备
                        return;
                    }
                } else{
                    logger.error("GroupMasterTeam.doReady时, 0-heroCount之间有null的英雄");
                    return;
                }
            }

            // 所有人都准备了
            doStart();
        }
    }

    /**
     * 返回null表示队伍已销毁
     * @return
     */
    TeamInfoProto encode(){
        if (destroyed){
            return null;
        }
        TeamInfoProto.Builder builder = TeamInfoProto.newBuilder();
        builder.setTeamId(id);
        if (fightAmountThreshold != 0){
            builder.setFightAmountThreshold(fightAmountThreshold);
        }

        builder.setHeroCount(heroCount);
        GroupMasterHero leader = heroes[0];
        builder.setLeaderNameBytes(leader.nameBytesString).setLeaderId(
                leader.heroID);
        return builder.build();
    }

    @Override
    public String toString(){
        return Objects.toStringHelper("GroupMasterTeam").add("队伍id", id)
                .add("战力需求", fightAmountThreshold)
                .add("最大队伍人数", getMaxHeroCount()).add("是否自动开始", fullAutoStart)
                .toString();
    }
}
