package app.cluster.group.master;

import app.utils.Operators;
import app.utils.VariableConfig;

public class GroupMasterZKPathUtil{

    /**
     * 获得此运营商该监听的路径
     * @param operator
     * @return
     */
    public static String getListenPath(Operators operator){
        return "/master/" + VariableConfig.CLUSTER_VERSION + ","
                + operator.operatorID;
    }
}
