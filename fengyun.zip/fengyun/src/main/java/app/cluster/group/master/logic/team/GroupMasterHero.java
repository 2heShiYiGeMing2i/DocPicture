package app.cluster.group.master.logic.team;

import org.jboss.netty.buffer.ChannelBuffer;

import app.cluster.group.master.GroupMasterWorker;

import com.google.common.base.Objects;
import com.google.protobuf.ByteString;
import com.mokylin.sink.util.BufferUtil;
import com.mokylin.sink.util.StringEncoder;

/**
 * 在队伍中的英雄
 * @author Timmy
 *
 */
public class GroupMasterHero{

    final long heroID;

    final ByteString nameBytesString;

    final byte[] nameBytes;

    final int raceID;

    final int level;

    final int fightAmount;

    final GroupMasterWorker sender;

    boolean isReady;

    GroupMasterHero(long heroID, byte[] nameBytes, int raceID, int level,
            int fightAmount, GroupMasterWorker sender){
        this.heroID = heroID;
        this.nameBytes = nameBytes;
        this.nameBytesString = ByteString.copyFrom(nameBytes);
        this.raceID = raceID;
        this.level = level;
        this.fightAmount = fightAmount;
        this.sender = sender;
    }

    void sendMessage(ChannelBuffer buffer){
        sender.sendMessage(buffer);
    }

    void writeToInList(ChannelBuffer buffer){
        BufferUtil.writeVarInt64(buffer, heroID);
        BufferUtil.writeUTF(buffer, nameBytes);
        BufferUtil.writeVarInt32(buffer, fightAmount);
        BufferUtil.writeVarInt32(buffer, (raceID << 1) | (isReady ? 1 : 0)); // 是否准备 + 职业
        BufferUtil.writeVarInt32(buffer, level);
    }

    void writeToInSingle(ChannelBuffer buffer){
        BufferUtil.writeVarInt64(buffer, heroID);
        BufferUtil.writeVarInt32(buffer, fightAmount);
        BufferUtil.writeVarInt32(buffer, raceID);
        BufferUtil.writeVarInt32(buffer, level);
        buffer.writeBytes(nameBytes);
    }

    @Override
    public String toString(){
        return Objects.toStringHelper("GroupMasterHero").add("英雄id", heroID)
                .add("英雄名", StringEncoder.encode(nameBytes)).add("等级", level)
                .add("战力", fightAmount).toString();
    }
}
