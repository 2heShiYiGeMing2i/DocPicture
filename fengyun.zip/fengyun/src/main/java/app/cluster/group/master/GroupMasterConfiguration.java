package app.cluster.group.master;

import static com.google.common.base.Preconditions.*;

import java.util.EnumSet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.utils.Operators;

import com.google.inject.Inject;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.pack.RealFileHorizontalConfigLoader;
import com.mokylin.sink.util.parse.ObjectParser;
import com.mokylin.zk.util.ClusterSharedConfiguration;

public class GroupMasterConfiguration implements ClusterSharedConfiguration{
    private static final Logger logger = LoggerFactory
            .getLogger(GroupMasterConfiguration.class);

    private final String ZK_CONNECT_STRING;

    public final String SELF_ADDRESS;

    public final int LISTEN_PORT;

    public final String NTP_SERVER;

    /**
     * 本程序, 所服务的运营商
     */
    public final EnumSet<Operators> operators;

    @Inject
    GroupMasterConfiguration(RealFileHorizontalConfigLoader loader){
        final ObjectParser parser = loader.loadFile(LOCATION);

        this.ZK_CONNECT_STRING = parser.getKey("zk_connect_string",
                "168.168.1.18:2181");

        this.NTP_SERVER = parser.getKey("ntp_server", "");

        this.LISTEN_PORT = parser.getIntKey("master_listen_port", 0);

        String selfAddressConfig = parser.getKey("self_address", "auto");
        if ("auto".equals(selfAddressConfig)){
            // 自动获取本机ip
            try{
                this.SELF_ADDRESS = Utils.getSelfIP();
                logger.info("自动获取本机ip: {}", SELF_ADDRESS);
            } catch (Throwable ex){
                logger.error("无法自动获得本机ip地址. 尝试在" + LOCATION
                        + " 中, 加一条 self_address=xxx.xxx.xxx.xxx 配置");
                throw new RuntimeException(ex);
            }
        } else{
            this.SELF_ADDRESS = selfAddressConfig;
        }

        // 获得自己所服务的运营商id. 不填默认为所有的运营商

        String[] ops = parser.getStringArray("master_operator", null);
        if (ops == null){
            operators = EnumSet.allOf(Operators.class);
            logger.info("服务所有的运营商");
        } else{
            // 自己只服务几个
            operators = EnumSet.noneOf(Operators.class);
            logger.info("只服务选定的运营商");
            for (String op : ops){
                int operatorID = Integer.parseInt(op);
                Operators operator = Operators.valueOf(operatorID);
                checkNotNull(operator, "所需要服务的运营商不存在: {}", operatorID);
                operators.add(operator);
                logger.info("  {}-{}", operatorID, operator);
            }
        }

        // 排除需要服务的运营商. 有的运营商人很多, 防止被全吃的master抢到. 全交给单独的master服务
        String[] ignoreOperator = parser.getStringArray(
                "master_ignore_operator", null);
        if (ignoreOperator != null){
            if (ops != null){
                logger.error("又单独选定运营商, 又排除几个, 这是想闹哪样");
            }
            // 有需要排除的
            for (String op : ignoreOperator){
                int operatorID = Integer.parseInt(op);
                Operators operator = Operators.valueOf(operatorID);
                checkNotNull(operator, "所需要排除的运营商不存在: {}", operatorID);

                operators.remove(operator);
            }
        }

        checkArgument(operators.size() > 0, "没有要服务的运营商了!!");
    }

    public EnumSet<Operators> getSelfOperators(){
        return operators;
    }

    @Override
    public String getZKConnectString(){
        return ZK_CONNECT_STRING;
    }

    @Override
    public String getNtpServer(){
        return NTP_SERVER;
    }

}
