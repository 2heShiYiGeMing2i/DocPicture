package app.cluster.group.master;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.game.data.ConfigGuiceModule;
import app.game.data.FileLoaderModule;
import app.game.data.goods.GoodsGuiceModule;
import app.game.data.scene.SceneConfigGuiceModule;
import app.game.data.spell.SpellsGuiceModule;
import app.utils.VariableConfig;

import com.google.inject.Guice;
import com.google.inject.Injector;
import com.google.inject.Stage;
import com.mokylin.sink.util.pack.RealTimeFileLoaderModule;

/**
 * 启动个组队master服务器
 * @author Timmy
 *
 */
public class GroupMasterMain{
    private static final Logger logger = LoggerFactory
            .getLogger(GroupMasterMain.class);

    public static void main(String[] args) throws InterruptedException{
        start();
    }

    public static void start() throws InterruptedException{
        Injector injector = createInjector();
        final GroupMasterServer server = injector
                .getInstance(GroupMasterServer.class);

        try{
            server.start();
            Runtime.getRuntime().addShutdownHook(new Thread(){
                @Override
                public void run(){
                    System.out.println("Running shutdown hook");
                    server.close();
                    System.out.println("Shutdown hook over");
                }
            });
            logger.info("master服务器已启动. 版本: {}", VariableConfig.CLUSTER_VERSION);
        } catch (Throwable ex){
            logger.error("启动失败", ex);
            System.exit(-1);
        }
    }

    static Injector createInjector(){
        return Guice.createInjector(Stage.PRODUCTION,
                new GroupMasterGuiceModule(), new RealTimeFileLoaderModule(),
                new ConfigGuiceModule(), new FileLoaderModule(),
                new SpellsGuiceModule(), new GoodsGuiceModule(),
                new SceneConfigGuiceModule());
    }
}
