package app.cluster.group.master;

import java.io.Closeable;
import java.util.EnumSet;
import java.util.concurrent.TimeUnit;

import org.apache.curator.framework.recipes.nodes.PersistentEphemeralNode;
import org.apache.curator.framework.recipes.nodes.PersistentEphemeralNode.Mode;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.cluster.combat.discovery.CombatServerDiscovery;
import app.cluster.group.master.logic.GroupMasterServices;
import app.cluster.protobuf.ServerInfoContent.GroupMasterInfoProto;
import app.game.service.IThreadService;
import app.utils.Operators;

import com.google.common.annotations.VisibleForTesting;
import com.google.inject.Inject;
import com.mokylin.sink.server.NettyServer;
import com.mokylin.sink.util.Utils;
import com.mokylin.zk.util.ClusterConnection;

/**
 * 组队master服务器. 通过zookeeper竞争master, 并监听客户端连接
 * @author Timmy
 *
 */
public class GroupMasterServer implements Closeable{
    private static final Logger logger = LoggerFactory
            .getLogger(GroupMasterServer.class);

    private final ClusterConnection connection;

    private final IThreadService threadService;

    private final GroupMasterServices services;

    private final String selfAddress;

    private final NettyServer nettyServer;

    private byte[] selfInfo;

    private final CombatServerDiscovery combatServerDiscovery;

    /**
     * 在zookeeper中竞争master的node. 每个自己服务的运营商一个node
     */
    private final PersistentEphemeralNode[] nodes;

    private final EnumSet<Operators> operators;

    @Inject
    GroupMasterServer(ClusterConnection connection,
            GroupMasterServices services, IThreadService threadService,
            GroupMasterConfiguration config){
        this(connection, services, threadService, config.SELF_ADDRESS,
                config.LISTEN_PORT, config.getSelfOperators());
    }

    @VisibleForTesting
    public GroupMasterServer(ClusterConnection connection,
            GroupMasterServices services, IThreadService threadService,
            String selfAddress, int listenPort, EnumSet<Operators> operators){
        this.connection = connection;
        this.threadService = threadService;
        this.services = services;

        this.selfAddress = selfAddress;

        this.operators = operators;
        this.nodes = new PersistentEphemeralNode[operators.size()];

        this.nettyServer = new NettyServer(listenPort,
                new GroupMasterWorkerFactory(services));

        this.combatServerDiscovery = new CombatServerDiscovery(connection,
                services, threadService);
    }

    public void start() throws InterruptedException{
        // start netty
        int actualPort = nettyServer.start(selfAddress);

        // start cluster connection
        connection.start();

        this.selfInfo = GroupMasterInfoProto.newBuilder()
                .setAddress(selfAddress).setPort(actualPort).build()
                .toByteArray();

        // put zookeeper node
        logger.debug("创建master znode");

        int index = 0;
        for (Operators operator : operators){
            String path = GroupMasterZKPathUtil.getListenPath(operator);
            PersistentEphemeralNode node = new PersistentEphemeralNode(
                    connection.getCuratorFramework(), Mode.EPHEMERAL, path,
                    selfInfo);
            node.start();
            logger.debug("等待GroupMaster znode创建完: {}", path);
            node.waitForInitialCreate(1, TimeUnit.DAYS);
            logger.debug("GroupMaster znode创建成功: {}", path);

            nodes[index++] = node;
        }

        logger.debug("开始监听Combat服务器变化");
        this.combatServerDiscovery.start();
    }

    @Override
    public void close(){
        logger.debug("closing GroupMasterServer");
        // 先关netty, 别的服还会尝试重连. 先把zookeeper中自己的master node删除, 让别人连新的master, 再关netty
        for (PersistentEphemeralNode node : nodes){
            Utils.closeQuietly(node);
        }
        Utils.closeQuietly(combatServerDiscovery);
        Utils.closeQuietly(connection);
        Utils.closeQuietly(threadService);
        Utils.closeQuietly(nettyServer);
        logger.info("GroupMasterServer closed");
    }
}
