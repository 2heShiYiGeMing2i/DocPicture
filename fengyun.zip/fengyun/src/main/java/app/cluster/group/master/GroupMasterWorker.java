package app.cluster.group.master;

import static com.mokylin.sink.util.BufferUtil.readVarInt32;

import org.jboss.netty.buffer.ChannelBuffer;
import org.jboss.netty.channel.Channel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.cluster.group.codec.GroupHeader;
import app.cluster.group.master.logic.GroupMasterActivityService;
import app.cluster.group.master.logic.GroupMasterServices;
import app.cluster.group.master.logic.GroupMasterTeamService;
import app.message.ISender;
import app.utils.Operators;

import com.mokylin.sink.server.Worker;
import com.mokylin.sink.util.BufferUtil;

/**
 * 代表每一个连接过来的服务器
 * @author Timmy
 *
 */
public class GroupMasterWorker implements Worker, ISender{
    private static final Logger logger = LoggerFactory
            .getLogger(GroupMasterWorker.class);

    private final GroupMasterServices services;

    private final GroupMasterTeamService teamService;

    private final GroupMasterActivityService activityService;

    private final Channel channel;

    /**
     * 本连接所属的运营商
     */
    private Operators operator;

    /**
     * 是否还连接着
     */
    private boolean isAlive;

    /**
     * 是否是自己人. 收到S2M_HELLO_MASTER的才算是自己人
     * 以后不排除要在hello_master后加上payload
     */
    private boolean authenticated;

    GroupMasterWorker(Channel channel, GroupMasterServices services){
        this.channel = channel;
        this.services = services;
        this.teamService = services.getGroupMasterTeamService();
        this.activityService = services.getGroupMasterActivityService();
        this.isAlive = true;
    }

    @Override
    public int hashCode(){
        return System.identityHashCode(this);
    }

    @Override
    public boolean equals(Object obj){
        return this == obj;
    }

    @Override
    public void onMessage(ChannelBuffer buffer){
        int msgId = BufferUtil.readVarInt32(buffer);

        try{
            GroupHeader header = GroupHeader.getHeaderByID(msgId);

            if (header == null){
                logger.error("GroupMasterWorker收到未知消息: {}", msgId); // 可能手动设置了版本号
                channel.close(); // 可能有BUG了
                return;
            }

            logger.debug("received client msg: {}", header);

            if (!isAuthenticated()){
                if (header == GroupHeader.S2M_HELLO_MASTER){
                    doAuthenticate(buffer);
                } else{
                    logger.error(
                            "GroupMasterWorker收到消息: {}, 但之前没有收到S2M_HELLO_MASTER. 断开",
                            header);
                    channel.close();
                }
                return;
            }

            switch (header){
                case S2M_CREATE_GROUP:{
                    teamService.onCreateGroup(buffer, this);
                    return;
                }

                case S2M_LEAVE_GROUP:{
                    teamService.onLeaveGroup(buffer, this);
                    return;
                }

                case S2M_JOIN_GROUP:{
                    teamService.onJoinGroup(buffer, this);
                    return;
                }

                case S2M_AUTO_JOIN_GROUP:{
                    teamService.onAutoJoinGroup(buffer, this);
                    return;
                }

                case S2M_GROUP_READY:{
                    teamService.onReady(buffer, this);
                    return;
                }

                case S2M_GROUP_CANCEL_READY:{
                    teamService.onCancelReady(buffer, this);
                    return;
                }

                case S2M_KICK:{
                    teamService.onKick(buffer, this);
                    return;
                }

                case S2M_START:{
                    teamService.onStart(buffer, this);
                    return;
                }

                case S2M_DISPLAY_MY_GROUP:{
                    teamService.onDisplay(buffer, this);
                    return;
                }

                case S2M_GET_GLOBAL_ACTIVITY_DESTINATION:{
                    activityService.onGetActivityDestination(buffer, this);
                    return;
                }

                case S2M_HELLO_MASTER:{
                    logger.error("已经authenticated过的连接, 又发了S2M_HELLO_MASTER. 无视");
                    return;
                }

                default:{
                    logger.error("GroupMasterWorker 收到未处理消息: {}-{}", msgId,
                            header);
                }
            }
        } catch (Throwable ex){
            logger.error("GroupMasterWorker.onMessage出错. msgID: " + msgId, ex);
        }
    }

    /**
     * 只有自己已经authenticated, 别人才会看到这个连接. 所以operator一定不为null
     * @return
     */
    public Operators getOperator(){
        return operator;
    }

    private void doAuthenticate(ChannelBuffer buffer){
        logger.info("游戏服登录成功. {}", channel.getRemoteAddress());
        int operatorType = readVarInt32(buffer);

        operator = Operators.valueOf(operatorType);
        if (operator == null){
            logger.error("master收到个不存在的运营商注册: {}", operatorType);
            channel.close();
            return;
        }

        if (!teamService.containsOperator(operator)){
            logger.error("master收到个本机器不服务的运营商: {}", operatorType);
            channel.close();
            return;
        }

        authenticated = true;
        teamService.onServerInit(this); // 发送每个队伍的初始信息
    }

    @Override
    public boolean sendMessage(ChannelBuffer buffer){
        channel.write(buffer);
        return true;
    }

    private boolean isAuthenticated(){
        return authenticated;
    }

    public boolean isAlive(){
        return isAlive;
    }

    @Override
    public void onDisconnect(){
        logger.debug("与游戏服的连接断开. {}. 游戏服是否已登录: {}", channel.getRemoteAddress(),
                isAuthenticated());
        isAlive = false;
        if (!isAuthenticated()){
            // 没有登录的
            return;
        }

        logger.info("已登录的游戏服断开: {}", channel.getRemoteAddress());
        // 将所有来自这个连接的, 还在组队中的人删除
        teamService.onServerDisconnected(this);
    }

    @Override
    public void onConnected(){
        logger.debug("收到来自游戏服的连接. {}", channel.getRemoteAddress());
        // 不要在这里推送各种消息. 说不定不是自己人. 收到S2M_HELLO_MASTER才算是自己人
    }

}
