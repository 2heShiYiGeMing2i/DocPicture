package app.cluster.group.master;

import org.jboss.netty.channel.Channel;

import app.cluster.group.master.logic.GroupMasterServices;

import com.mokylin.sink.server.Worker;
import com.mokylin.sink.server.WorkerFactory;

public class GroupMasterWorkerFactory implements WorkerFactory{

    private final GroupMasterServices services;

    GroupMasterWorkerFactory(GroupMasterServices services){
        this.services = services;
    }

    @Override
    public Worker newWorker(Channel channel){
        return new GroupMasterWorker(channel, services);
    }

}
