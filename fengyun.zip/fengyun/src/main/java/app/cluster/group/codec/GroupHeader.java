package app.cluster.group.codec;

import static com.mokylin.sink.util.BufferUtil.*;

import java.io.IOException;

import org.jboss.netty.buffer.BigEndianHeapChannelBuffer;
import org.jboss.netty.buffer.ChannelBuffer;
import org.jboss.netty.buffer.ChannelBuffers;

import app.game.entity.Hero;

import com.google.protobuf.CodedOutputStream;
import com.google.protobuf.MessageLite;

public enum GroupHeader{

    /**
     * 游戏服刚连上master时发送, 登录, 并要求master发送初始信息给游戏服
     * 
     * 没有附带信息
     */
    S2M_HELLO_MASTER,

    /**
     * Master定时向Server广播当前每个场景的队伍信息
     * 
     * 附带
     * 
     *  varint32 scene_id
     *  varint32 team_count
     *  剩余的都是data  
     */
    M2S_BROADCAST_SCENE_TEAM_LIST,

    /**
     * 请求创建队伍. 应该是一定成功的, master不用返回
     * 
     * 附带
     * 
     * varint32 副本id
     * varint32 战力要求
     * bool 是否满员自动开
     * varint64 英雄id
     * varint32 英雄等级
     * varint32 英雄职业
     * varint32 英雄战力
     * UTFBytes 英雄名字
     */
    S2M_CREATE_GROUP,

    /**
     * 请求加入队伍
     * 
     * 如果成功, 不用返回. 失败则返回英雄id及错误码
     * 
     * 附带
     * 
     * varint32 副本id
     * varint32 队伍id
     * varint64 英雄id
     * varint32 英雄等级
     * varint32 英雄职业
     * varint32 英雄战力
     * UTFBytes 英雄名字
     */
    S2M_JOIN_GROUP,

    /**
     * 请求加入队伍失败
     * 
     * 附带
     * 
     * varint64 英雄id
     * varint32 错误码
     * 1. 队伍id不存在
     * 2. 队伍已满
     * 3. 战力不够
     */
    M2S_JOIN_GROUP_FAIL,

    /**
     * 请求自动加入个队伍
     * 
     * 如果成功, 直接proxy成功消息给玩家. 失败, 发送M2S_AUTO_JOIN_FAIL, 附带英雄id
     * 
     * 附带
     * 
     * varint32 副本id
     * varint64 英雄id
     * varint32 英雄等级
     * varint32 英雄职业
     * varint32 英雄战力
     * UTFBytes 英雄名字
     * 
     */
    S2M_AUTO_JOIN_GROUP,

    /**
     * 自动加入队伍失败
     * 
     * 附带
     * 
     * varint64 英雄id
     */
    M2S_AUTO_JOIN_FAIL,

    /**
     * 单方面通知master, 此人离开了队伍. 
     * 可能是因为下线, 可能是主动离队, 可能是收到请求加入队伍成功消息时, 已经不在能加入队伍的状态
     * 反正此时游戏服上, 此人在队伍中. 
     * 
     * master只要把此人退出队伍就行, 成功失败都不需要发送返回消息
     * 
     * 附带
     * 
     * varint32 英雄所在队伍的副本id
     * varint64 英雄id
     */
    S2M_LEAVE_GROUP,

    /**
     * master要求游戏服转发消息给玩家. 游戏服不需要关心消息内容
     * 
     * 附带
     * 
     * varint64 英雄id
     * 接下来就是要发送的内容. 游戏服只需要在最前面加上长度就好
     */
    M2S_PROXY_MSG,

    /**
     * 英雄在副本队伍中准备. 如果有任何错误, 直接proxy给玩家就行
     * 
     * 附带
     * 
     * varint32 副本场景id
     * varint64 英雄id
     */
    S2M_GROUP_READY,

    /**
     * 英雄在副本队伍中取消准备. 如果有任何错误, 直接proxy给玩家就行
     * 
     * 附带
     * 
     * varint32 副本场景id
     * varint64 英雄id
     */
    S2M_GROUP_CANCEL_READY,

    /**
     * 踢人. 只需要在成功时, 发给被踢的人所在的服务器, 由服务器再发送被踢消息给玩家同时把玩家的队伍设为null
     * 
     * 附带
     * 
     * varint32 副本场景id
     * varint64 踢人的人id
     * varint64 要踢的人id
     */
    S2M_KICK,

    /**
     * 被踢. 由服务器再发送被踢消息给玩家同时把玩家的队伍设为null
     * 
     * 附带
     * 
     * varint64 被踢的人id
     */
    M2S_BEEN_KICKED,

    /**
     * 请求开始副本. 开始或失败都直接proxy给玩家. 
     * 开始成功后, 发送M2S_START_BROADCAST给游戏服, 附带开始时间和combatServer id和场景id. 
     * 场景服转发START_BROADCAST
     * 
     * 附带
     * 
     * varint32 副本场景id
     * varint64 英雄id
     */
    S2M_START,

    /**
     * 开始成功后, 告诉游戏服, 附带开始时间和combatServer id和场景id. 
     * 场景服转发START_BROADCAST
     * 游戏服在时间到后, 自动让玩家切场景, 并连到对应的combat服
     * 
     * 附带
     *  
     * varint64 英雄id
     * varint64 combat服id
     * varint32 副本配置id
     * varint32 副本uuid
     */
    M2S_START_BROADCAST,

    // --- 英雄获取跨服活动的目的地 ---

    /**
     * 英雄要进入跨服活动场景, 获取要连的combat服, uuid, 线数
     * 直接回复给询问的这个连接
     * 
     * 附带
     * 
     * varint32 场景id
     * varint64 英雄id
     */
    S2M_GET_GLOBAL_ACTIVITY_DESTINATION,

    /**
     * 没有连接着的Combat服, 获取失败
     * 
     * 附带
     * 
     * varint32 场景id
     * varint64 英雄id
     */
    M2S_GET_GLOBAL_ACTIVITY_DESTINATION_FAIL_NO_COMBAT_SERVER,

    /**
     * 回复英雄的跨服活动目的地
     * 
     * 附带
     * 
     * varint32 场景id
     * varint64 英雄id
     * varint32 场景uuid
     * varint32 线数
     * varint64 combat服id
     */
    M2S_REPLY_GLOBAL_ACTIVITY_DESTINATION,

    // --- 要求广播自己的队伍 ---

    /**
     * 获取这个英雄的队伍, 并返回队伍信息给英雄所在的服务器
     * 
     * 附带
     * 
     * varint32 场景id
     * varint64 英雄id
     */
    S2M_DISPLAY_MY_GROUP,

    /**
     * 回复你的队伍
     * 
     * 附带
     * 
     * varint64 英雄id
     * varint32 副本id
     * varint32 队伍id
     * varint32 队伍的战力需求
     */
    M2S_REPLY_YOUR_GROUP,

    /**
     * 获取你的队伍失败 
     * 
     * 附带
     * 
     * varint64 英雄id
     * varint32 错误码 1. 没有队伍, 2. 队伍满了
     */
    M2S_REPLY_YOUR_GROUP_FAIL;

    // --- 消息构建 ---

    public static final int ERROR_REPLY_YOUR_GROUP_NO_TEAM = 1;
    public static final int ERROR_REPLY_YOUR_GROUP_TEAM_FULL = 2;

    public static ChannelBuffer replyYourGroupFail(long heroID, int errCode){
        ChannelBuffer buffer = newFixedSizeMessage(
                GroupHeader.M2S_REPLY_YOUR_GROUP_FAIL,
                computeVarInt64Size(heroID) + computeVarInt32Size(errCode));
        writeVarInt64(buffer, heroID);
        writeVarInt32(buffer, errCode);
        return buffer;
    }

    public static ChannelBuffer replyYourGroup(long heroID, int dungeonID,
            int groupID, int requiredFightAmount){
        ChannelBuffer buffer = newFixedSizeMessage(
                GroupHeader.M2S_REPLY_YOUR_GROUP, computeVarInt64Size(heroID)
                        + computeVarInt32Size(dungeonID)
                        + computeVarInt32Size(groupID)
                        + computeVarInt32Size(requiredFightAmount));
        writeVarInt64(buffer, heroID);
        writeVarInt32(buffer, dungeonID);
        writeVarInt32(buffer, groupID);
        writeVarInt32(buffer, requiredFightAmount);
        return buffer;
    }

    public static ChannelBuffer displayMyGroup(int sceneID, long heroID){
        ChannelBuffer buffer = newFixedSizeMessage(
                GroupHeader.S2M_DISPLAY_MY_GROUP, computeVarInt32Size(sceneID)
                        + computeVarInt64Size(heroID));
        writeVarInt32(buffer, sceneID);
        writeVarInt64(buffer, heroID);
        return buffer;
    }

    public static ChannelBuffer getGlobalActivityDestinationFailNoCombatServer(
            int sceneID, long heroID){
        ChannelBuffer buffer = newFixedSizeMessage(
                GroupHeader.M2S_GET_GLOBAL_ACTIVITY_DESTINATION_FAIL_NO_COMBAT_SERVER,
                computeVarInt32Size(sceneID) + computeVarInt64Size(heroID));
        writeVarInt32(buffer, sceneID);
        writeVarInt64(buffer, heroID);
        return buffer;
    }

    public static ChannelBuffer replyGlobalActitivyDestination(int sceneID,
            long heroID, int uuid, int line, long combatServerID){
        ChannelBuffer buffer = newFixedSizeMessage(
                GroupHeader.M2S_REPLY_GLOBAL_ACTIVITY_DESTINATION,
                computeVarInt32Size(sceneID) + computeVarInt64Size(heroID)
                        + computeVarInt32Size(uuid) + computeVarInt32Size(line)
                        + computeVarInt64Size(combatServerID));
        writeVarInt32(buffer, sceneID);
        writeVarInt64(buffer, heroID);
        writeVarInt32(buffer, uuid);
        writeVarInt32(buffer, line);
        writeVarInt64(buffer, combatServerID);
        return buffer;
    }

    public static ChannelBuffer getGlobalActivityDestination(int sceneID,
            long heroID){
        ChannelBuffer buffer = newFixedSizeMessage(
                GroupHeader.S2M_GET_GLOBAL_ACTIVITY_DESTINATION,
                computeVarInt32Size(sceneID) + computeVarInt64Size(heroID));
        writeVarInt32(buffer, sceneID);
        writeVarInt64(buffer, heroID);
        return buffer;
    }

    public static ChannelBuffer startBroadcast(long heroID,
            long combatServerID, int sceneID, int dungeonUUID){
        ChannelBuffer buffer = newFixedSizeMessage(
                GroupHeader.M2S_START_BROADCAST, computeVarInt64Size(heroID)
                        + computeVarInt64Size(combatServerID)
                        + computeVarInt32Size(sceneID)
                        + computeVarInt32Size(dungeonUUID));
        writeVarInt64(buffer, heroID);
        writeVarInt64(buffer, combatServerID);
        writeVarInt32(buffer, sceneID);
        writeVarInt32(buffer, dungeonUUID);
        return buffer;
    }

    public static ChannelBuffer start(int sceneID, long heroID){
        ChannelBuffer buffer = newFixedSizeMessage(GroupHeader.S2M_START,
                computeVarInt32Size(sceneID) + computeVarInt64Size(heroID));
        writeVarInt32(buffer, sceneID);
        writeVarInt64(buffer, heroID);
        return buffer;
    }

    public static ChannelBuffer beenKicked(long heroID){
        return onlySendHeadAndAVarInt64Message(GroupHeader.M2S_BEEN_KICKED,
                heroID);
    }

    public static ChannelBuffer kick(int sceneID, long kickerID, long targetID){
        ChannelBuffer buffer = newFixedSizeMessage(GroupHeader.S2M_KICK,
                computeVarInt32Size(sceneID) + computeVarInt64Size(kickerID)
                        + computeVarInt64Size(targetID));
        writeVarInt32(buffer, sceneID);
        writeVarInt64(buffer, kickerID);
        writeVarInt64(buffer, targetID);
        return buffer;
    }

    public static ChannelBuffer groupCancelReady(int sceneID, long heroID){
        ChannelBuffer buffer = newFixedSizeMessage(
                GroupHeader.S2M_GROUP_CANCEL_READY,
                computeVarInt32Size(sceneID) + computeVarInt64Size(heroID));
        writeVarInt32(buffer, sceneID);
        writeVarInt64(buffer, heroID);
        return buffer;
    }

    public static ChannelBuffer groupReady(int sceneID, long heroID){
        ChannelBuffer buffer = newFixedSizeMessage(GroupHeader.S2M_GROUP_READY,
                computeVarInt32Size(sceneID) + computeVarInt64Size(heroID));
        writeVarInt32(buffer, sceneID);
        writeVarInt64(buffer, heroID);
        return buffer;
    }

    public static ChannelBuffer joinGroupFail(long heroID, int errorCode){
        ChannelBuffer buffer = newFixedSizeMessage(
                GroupHeader.M2S_JOIN_GROUP_FAIL, computeVarInt64Size(heroID)
                        + computeVarInt32Size(errorCode));
        writeVarInt64(buffer, heroID);
        writeVarInt32(buffer, errorCode);
        return buffer;
    }

    public static ChannelBuffer autoJoinFail(long heroID){
        ChannelBuffer buffer = newFixedSizeMessage(
                GroupHeader.M2S_AUTO_JOIN_FAIL, computeVarInt64Size(heroID));
        writeVarInt64(buffer, heroID);
        return buffer;
    }

    public static ChannelBuffer autoJoinGroup(int sceneID, Hero hero){
        long heroID = hero.getID();
        int heroLevel = hero.getLevel();
        int raceID = hero.getRaceId();
        int fightAmount = hero.getFightingAmount();
        byte[] nameBytes = hero.getNameBytes();

        ChannelBuffer buffer = newFixedSizeMessage(
                GroupHeader.S2M_AUTO_JOIN_GROUP, computeVarInt32Size(sceneID)
                        + computeVarInt64Size(heroID)
                        + computeVarInt32Size(heroLevel)
                        + computeVarInt32Size(raceID)
                        + computeVarInt32Size(fightAmount) + nameBytes.length);

        writeVarInt32(buffer, sceneID);

        writeVarInt64(buffer, heroID);
        writeVarInt32(buffer, heroLevel);
        writeVarInt32(buffer, raceID);
        writeVarInt32(buffer, fightAmount);
        buffer.writeBytes(nameBytes);

        return buffer;
    }

    public static final int ERROR_JOIN_GROUP_ID_NOT_EXISTS = 1;
    public static final int ERROR_JOIN_GROUP_TEAM_FULL = 2;
    public static final int ERROR_JOIN_GROUP_NOT_ENOUGH_FIGHT_AMOUNT = 3;

    public static ChannelBuffer joinGroup(int sceneID, int groupID, Hero hero){
        long heroID = hero.getID();
        int heroLevel = hero.getLevel();
        int raceID = hero.getRaceId();
        int fightAmount = hero.getFightingAmount();
        byte[] nameBytes = hero.getNameBytes();

        ChannelBuffer buffer = newFixedSizeMessage(GroupHeader.S2M_JOIN_GROUP,
                computeVarInt32Size(sceneID) + computeVarInt32Size(groupID)
                        + computeVarInt64Size(heroID)
                        + computeVarInt32Size(heroLevel)
                        + computeVarInt32Size(raceID)
                        + computeVarInt32Size(fightAmount) + nameBytes.length);

        writeVarInt32(buffer, sceneID);
        writeVarInt32(buffer, groupID);

        writeVarInt64(buffer, heroID);
        writeVarInt32(buffer, heroLevel);
        writeVarInt32(buffer, raceID);
        writeVarInt32(buffer, fightAmount);
        buffer.writeBytes(nameBytes);

        return buffer;
    }

    public static ChannelBuffer proxyMsgDynamic(long heroID, int moduleID,
            int sequenceID, int appSize){
        ChannelBuffer buffer = newDynamicMessage(GroupHeader.M2S_PROXY_MSG,
                12 + appSize);
        writeVarInt64(buffer, heroID);
        writeVarInt32(buffer, moduleID);
        writeVarInt32(buffer, sequenceID);
        return buffer;
    }

    public static ChannelBuffer proxyMsg(long heroID, int moduleID,
            int sequenceID, int sureSizeExcludingHeader){
        ChannelBuffer buffer = newFixedSizeMessage(GroupHeader.M2S_PROXY_MSG,
                computeVarInt32Size(moduleID) + computeVarInt32Size(sequenceID)
                        + computeVarInt64Size(heroID) + sureSizeExcludingHeader);
        writeVarInt64(buffer, heroID);
        writeVarInt32(buffer, moduleID);
        writeVarInt32(buffer, sequenceID);
        return buffer;
    }

    public static ChannelBuffer proxyMsgOnlyHeader(long heroID, int moduleID,
            int sequenceID){
        return proxyMsg(heroID, moduleID, sequenceID, 0);
    }

    public static ChannelBuffer proxyMsgOnlyHeaderAnd1Varint32(long heroID,
            int moduleID, int sequenceID, int load){
        ChannelBuffer buffer = proxyMsg(heroID, moduleID, sequenceID,
                computeVarInt32Size(load));
        writeVarInt32(buffer, load);
        return buffer;
    }

    public static ChannelBuffer proxyMsgOnlyHeaderAnd1Varint64(long heroID,
            int moduleID, int sequenceID, long load){
        ChannelBuffer buffer = proxyMsg(heroID, moduleID, sequenceID,
                computeVarInt64Size(load));
        writeVarInt64(buffer, load);
        return buffer;
    }

    public static ChannelBuffer leaveGroup(long heroID, int sceneID){
        ChannelBuffer buffer = newFixedSizeMessage(GroupHeader.S2M_LEAVE_GROUP,
                computeVarInt64Size(heroID) + computeVarInt32Size(sceneID));
        writeVarInt32(buffer, sceneID);
        writeVarInt64(buffer, heroID);
        return buffer;
    }

    public static ChannelBuffer createGroup(int sceneID,
            int fightAmountThreshold, boolean fullAutoStart, Hero hero){
        long heroID = hero.getID();
        int heroLevel = hero.getLevel();
        int raceID = hero.getRaceId();
        int fightAmount = hero.getFightingAmount();
        byte[] nameBytes = hero.getNameBytes();

        ChannelBuffer buffer = newFixedSizeMessage(
                GroupHeader.S2M_CREATE_GROUP, computeVarInt32Size(sceneID)
                        + computeVarInt32Size(fightAmountThreshold) + 1
                        + computeVarInt64Size(heroID)
                        + computeVarInt32Size(heroLevel)
                        + computeVarInt32Size(raceID)
                        + computeVarInt32Size(fightAmount) + nameBytes.length);

        writeVarInt32(buffer, sceneID);
        writeVarInt32(buffer, fightAmountThreshold);
        writeBoolean(buffer, fullAutoStart);
        writeVarInt64(buffer, heroID);
        writeVarInt32(buffer, heroLevel);
        writeVarInt32(buffer, raceID);
        writeVarInt32(buffer, fightAmount);
        buffer.writeBytes(nameBytes);

        return buffer;
    }

    // --- 消息构建helper方法 ---

    private static final int HEADER_COUNT = GroupHeader.values().length;

    private static final GroupHeader[] HEADERS = GroupHeader.values();

    public static GroupHeader getHeaderByID(int id){
        if (id >= 0 && id < HEADER_COUNT){
            return HEADERS[id];
        }
        return null;
    }

    public static ChannelBuffer newFixedSizeMessage(GroupHeader msg,
            int sureSizeExcludingSizeAndID){
        ChannelBuffer buffer = new BigEndianHeapChannelBuffer(2
                + sureSizeExcludingSizeAndID
                + computeVarInt32Size(msg.ordinal()));
        buffer.writeShort(0);
        writeVarInt32(buffer, msg.ordinal());

        return buffer;
    }

    public static ChannelBuffer newDynamicMessage(GroupHeader msg){
        return newDynamicMessage(msg, 64);
    }

    /**
     * 返回的ChannelBuffer会按需加大
     * 
     * @param msgId
     * @param approxSize
     * @return
     */
    public static ChannelBuffer newDynamicMessage(GroupHeader msg,
            int approxSizeExcludingSizeAndID){
        ChannelBuffer buffer = ChannelBuffers
                .dynamicBuffer(12 + approxSizeExcludingSizeAndID);
        buffer.writeShort(0);// place holder for buffer size
        writeVarInt32(buffer, msg.ordinal());
        return buffer;
    }

    public static ChannelBuffer onlySendHeaderMessage(GroupHeader msg){
        return newFixedSizeMessage(msg, 0);
    }

    public static ChannelBuffer onlySendHeadAndABoolBytes(GroupHeader msg,
            boolean b){
        ChannelBuffer buffer = newFixedSizeMessage(msg, 1);
        writeBoolean(buffer, b);
        return buffer;
    }

    public static ChannelBuffer onlySendHeadAndAUTFBytes(GroupHeader msg,
            byte[] utf){
        ChannelBuffer buffer = newFixedSizeMessage(msg, utf.length);
        buffer.writeBytes(utf);
        return buffer;
    }

    public static ChannelBuffer onlySendHeadAndAByteMessage(GroupHeader msg,
            int b){
        ChannelBuffer buffer = newFixedSizeMessage(msg, 1);
        buffer.writeByte(b);
        return buffer;
    }

    public static ChannelBuffer onlySendHeadAndAVarInt32Message(
            GroupHeader msg, int b){
        ChannelBuffer buffer = newFixedSizeMessage(msg, computeVarInt32Size(b));
        writeVarInt32(buffer, b);
        return buffer;
    }

    public static ChannelBuffer onlySendHeadAnd2VarInt32Message(
            GroupHeader msg, int b, int c){
        ChannelBuffer buffer = newFixedSizeMessage(msg, computeVarInt32Size(b)
                + computeVarInt32Size(c));
        writeVarInt32(buffer, b);
        writeVarInt32(buffer, c);
        return buffer;
    }

    public static ChannelBuffer onlySendHeadAnd3VarInt32Message(
            GroupHeader msg, int b, int c, int d){
        ChannelBuffer buffer = newFixedSizeMessage(msg, computeVarInt32Size(b)
                + computeVarInt32Size(c) + computeVarInt32Size(d));
        writeVarInt32(buffer, b);
        writeVarInt32(buffer, c);
        writeVarInt32(buffer, d);
        return buffer;
    }

    public static ChannelBuffer onlySendHeadAnd4VarInt32Message(
            GroupHeader msg, int b, int c, int d, int e){
        ChannelBuffer buffer = newFixedSizeMessage(msg, computeVarInt32Size(b)
                + computeVarInt32Size(c) + computeVarInt32Size(d)
                + computeVarInt32Size(e));
        writeVarInt32(buffer, b);
        writeVarInt32(buffer, c);
        writeVarInt32(buffer, d);
        writeVarInt32(buffer, e);
        return buffer;
    }

    public static ChannelBuffer onlySendHeadAndAVarInt64Message(
            GroupHeader msg, long b){
        ChannelBuffer buffer = newFixedSizeMessage(msg, computeVarInt64Size(b));
        writeVarInt64(buffer, b);
        return buffer;
    }

    public static ChannelBuffer onlySendHeadAnd2VarInt64Message(
            GroupHeader msg, long b, long c){
        ChannelBuffer buffer = newFixedSizeMessage(msg, computeVarInt64Size(b)
                + computeVarInt64Size(c));
        writeVarInt64(buffer, b);
        writeVarInt64(buffer, c);
        return buffer;
    }

    public static ChannelBuffer onlySendHeaderAndVarIntsMessage(
            GroupHeader msg, int... value){
        int size = 0;
        for (int i : value){
            size += computeVarInt32Size(i);
        }
        ChannelBuffer result = newFixedSizeMessage(msg, size);
        for (int i : value){
            writeVarInt32(result, i);
        }
        return result;
    }

    public static ChannelBuffer onlySendHeadAndBytesMessage(GroupHeader msg,
            byte[] data){
        ChannelBuffer buffer = newFixedSizeMessage(msg, data.length);
        buffer.writeBytes(data);
        return buffer;
    }

    public static ChannelBuffer newProtobufMessage(GroupHeader header,
            MessageLite msg){
        int size = msg.getSerializedSize();
        byte[] buf = new byte[2 + size + computeVarInt32Size(header.ordinal())];

        int index = writeVarInt32(buf, 2, header.ordinal());

        CodedOutputStream out = CodedOutputStream.newInstance(buf, index, size);
        try{
            msg.writeTo(out);
        } catch (IOException e){
            throw new RuntimeException(
                    "Serializing to a byte array threw an IOException "
                            + "(should never happen).", e);
        }
        return new BigEndianHeapChannelBuffer(buf);
    }

    public static ChannelBuffer getCompressedMessage(GroupHeader msg,
            ChannelBuffer buffer){
        ChannelBuffer result = newFixedSizeMessage(msg,
                getMaxCompressedSize(buffer.writerIndex()));
        compressBuffer(buffer, result);
        return result;
    }

    public static ChannelBuffer getCompressedMessage(GroupHeader msg,
            byte[] data, boolean bestCompression){
        ChannelBuffer result = newFixedSizeMessage(msg,
                getMaxCompressedSize(data.length));
        compressBuffer(data, result, bestCompression);
        return result;
    }
}
