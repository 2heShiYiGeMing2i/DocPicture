package app.cluster.group.master.logic.activity;

import com.mokylin.sink.util.concurrent.PaddedAtomicInteger;

/**
 * 单个活动场景的人数
 * @author Timmy
 *
 */
public class GroupMasterActivityCounter{

    final long combatServerID;
    final int line;
    final int uuid;

    private final PaddedAtomicInteger heroCounter;

    GroupMasterActivityCounter(long combatServerID, int line, int uuid){
        this.combatServerID = combatServerID;
        this.line = line;
        this.uuid = uuid;
        this.heroCounter = new PaddedAtomicInteger(1);
    }

    int incrementCounter(){
        return heroCounter.incrementAndGet();
    }

}
