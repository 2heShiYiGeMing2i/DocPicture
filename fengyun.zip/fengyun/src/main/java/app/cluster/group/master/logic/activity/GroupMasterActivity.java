package app.cluster.group.master.logic.activity;

import java.util.concurrent.TimeUnit;

import org.joda.time.DateTimeConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.cluster.combat.master.CombatMasterServerInfo;
import app.cluster.group.codec.GroupHeader;
import app.cluster.group.master.GroupMasterWorker;
import app.cluster.group.master.logic.GroupMasterCombatServerContainer;
import app.game.data.scene.GlobalActivitySceneData;
import app.game.service.IThreadService;
import app.game.service.TimeService;

import com.mokylin.sink.util.RandomNumber;
import com.mokylin.sink.util.concurrent.PaddedAtomicReference;

/**
 * 每个场景的
 * @author Timmy
 *
 */
public class GroupMasterActivity{
    private static final Logger logger = LoggerFactory
            .getLogger(GroupMasterActivity.class);

    private final GlobalActivitySceneData sceneData;

    private final GroupMasterCombatServerContainer combatServerContainer;

    private final PaddedAtomicReference<GroupMasterActivityCounter> counter;

    private final TimeService timeService;

    private final IThreadService threadService;

    private long nextActivityTime;

    public GroupMasterActivity(GlobalActivitySceneData sceneData,
            GroupMasterCombatServerContainer combatServerContainer,
            TimeService timeService, IThreadService threadService){
        this.timeService = timeService;
        this.threadService = threadService;
        this.sceneData = sceneData;
        this.combatServerContainer = combatServerContainer;
        this.counter = new PaddedAtomicReference<GroupMasterActivityCounter>(
                null);

        // 定时, 每次活动开始前1分钟, 清掉counter

        long ctime = timeService.getCurrentTime();
        nextActivityTime = sceneData.activityTime.getNextTime(ctime);
        long nextClearActivityCounterTime = nextActivityTime
                - DateTimeConstants.MILLIS_PER_MINUTE;
        threadService.getScheduledExecutorService().schedule(
                clearCounterRunnable, nextClearActivityCounterTime - ctime,
                TimeUnit.MILLISECONDS);
    }

    private final Runnable clearCounterRunnable = new Runnable(){
        @Override
        public void run(){
            counter.set(null);

            nextActivityTime = sceneData.activityTime
                    .getNextTime(nextActivityTime + 1); // 理论上这个类应该返回的时间一定是大于input的, 但还是...
            long clearCounterTime = nextActivityTime
                    - DateTimeConstants.MILLIS_PER_MINUTE;

            long ctime = timeService.getCurrentTime();
            threadService.getScheduledExecutorService().schedule(
                    clearCounterRunnable, clearCounterTime - ctime,
                    TimeUnit.MILLISECONDS);
        }
    };

    /**
     * 清掉counter, 清掉line数
     * @param heroID
     * @param worker
     */
    public void onGetActivityDestination(long heroID, GroupMasterWorker worker){
        GroupMasterActivityCounter c = counter.get();
        if (c == null){
            CombatMasterServerInfo serverInfo = combatServerContainer
                    .getLowestLoadCombatServer();
            if (serverInfo == null){
                // 没有combat服
                logger.error("GroupMasterActivity, 游戏服请求跨服活动的目的地时, 没有连接着的combat服");
                worker.sendMessage(GroupHeader
                        .getGlobalActivityDestinationFailNoCombatServer(
                                sceneData.id, heroID));
                return;
            }
            c = new GroupMasterActivityCounter(serverInfo.id, 1, newUUID());
            boolean success = counter.compareAndSet(null, c);
            if (!success){
                onGetActivityDestination(heroID, worker); // cas 失败, 递归重新获取次 
                return;
            }
        }

        assert c != null;

        int heroCount = c.incrementCounter();
        if (heroCount >= sceneData.perSceneHeroLimit){
            // 超出了场景人数上限了, 新建个. 不成功也无所谓
            CombatMasterServerInfo serverInfo = combatServerContainer
                    .getLowestLoadCombatServer();
            if (serverInfo != null){
                counter.compareAndSet(c, new GroupMasterActivityCounter(
                        serverInfo.id, c.line + 1, newUUID()));
            }
        }

        worker.sendMessage(GroupHeader.replyGlobalActitivyDestination(
                sceneData.id, heroID, c.uuid, c.line, c.combatServerID));
    }

    private int newUUID(){
        return Math.abs(RandomNumber.randomInt());
    }

    public void onCombatServerDisconnected(CombatMasterServerInfo info){
        // 在这之前, 断线的combat服已经从combatServerContainer里删除了
        // 如果当前的combat服是这个, 则换一个新的

        GroupMasterActivityCounter c = counter.get();
        if (c == null || c.combatServerID == info.id){
            // 不是这个服, 不管
            return;
        }

        CombatMasterServerInfo newServer = combatServerContainer
                .getLowestLoadCombatServer();
        if (newServer == null){
            // 不可能会有新的服务器在, 添加删除服务器都在这个线程
            logger.error("GroupMasterActivity, 最后一个combat服也断线了");
            counter.set(null);
            return;
        }

        counter.compareAndSet(c, new GroupMasterActivityCounter(newServer.id,
                c.line + 1, newUUID()));
    }
}
