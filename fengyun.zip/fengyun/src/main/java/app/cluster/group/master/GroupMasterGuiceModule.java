package app.cluster.group.master;

import app.cluster.group.master.logic.GroupMasterActivityService;
import app.cluster.group.master.logic.GroupMasterCombatServerContainer;
import app.cluster.group.master.logic.GroupMasterServices;
import app.cluster.group.master.logic.GroupMasterTeamService;
import app.game.service.DumpHotRedeployService;
import app.game.service.IThreadService;
import app.game.service.SyncNtpTimeService;
import app.game.service.ThreadServiceImpl;
import app.game.service.TimeService;
import app.game.service.redeploy.IHotRedeployService;
import app.utils.GroupMasterServerType;
import app.utils.ServerType;

import com.google.inject.AbstractModule;
import com.google.inject.Singleton;
import com.mokylin.sink.util.pack.RealFileHorizontalConfigLoader;
import com.mokylin.zk.util.ClusterConnection;
import com.mokylin.zk.util.ClusterSharedConfiguration;

public class GroupMasterGuiceModule extends AbstractModule{

    @Override
    protected void configure(){
        binder().requireExplicitBindings();

        bind(GroupMasterConfiguration.class).in(Singleton.class);
        bind(ClusterConnection.class).in(Singleton.class);
        bind(GroupMasterServer.class).in(Singleton.class);
        bind(GroupMasterServices.class).in(Singleton.class);
        bind(RealFileHorizontalConfigLoader.class).in(Singleton.class);
        bind(ClusterSharedConfiguration.class).to(
                GroupMasterConfiguration.class).in(Singleton.class);
        bind(IThreadService.class).to(ThreadServiceImpl.class).in(
                Singleton.class);
        bind(TimeService.class).to(SyncNtpTimeService.class)
                .in(Singleton.class);
        bind(GroupMasterTeamService.class).in(Singleton.class);
        bind(GroupMasterCombatServerContainer.class).in(Singleton.class);
        bind(GroupMasterActivityService.class).in(Singleton.class);

        bind(IHotRedeployService.class).to(DumpHotRedeployService.class).in(
                Singleton.class);

        bind(ServerType.class).to(GroupMasterServerType.class).in(
                Singleton.class);
    }
}
