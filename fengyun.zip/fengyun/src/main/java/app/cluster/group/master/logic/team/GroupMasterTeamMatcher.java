package app.cluster.group.master.logic.team;

import static app.cluster.group.codec.GroupHeader.*;
import static com.mokylin.sink.util.BufferUtil.*;

import java.util.ArrayList;
import java.util.List;

import org.jboss.netty.buffer.ChannelBuffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.cluster.client.logic.team.ClusterClientMessages;
import app.cluster.combat.master.CombatMasterServerInfo;
import app.cluster.group.codec.GroupHeader;
import app.cluster.group.master.GroupMasterWorker;
import app.cluster.group.master.logic.GroupMasterCombatServerContainer;
import app.cluster.protobuf.TeamContent.SceneTeamProto;
import app.cluster.protobuf.TeamContent.TeamInfoProto;
import app.game.data.scene.GroupDungeonSceneData;
import app.game.service.IThreadService;
import app.game.service.TimeService;
import app.utils.VariableConfig;

import com.mokylin.collection.IntHashMap;
import com.mokylin.collection.LongHashMap;
import com.mokylin.collection.ReusableIterator;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.concurrent.DisruptorExecutor;

/**
 * 单个副本的所有队伍
 * @author Timmy
 *
 */
public class GroupMasterTeamMatcher{
    /*
     * 所有操作都交给exec线程处理
     */
    private static final Logger logger = LoggerFactory
            .getLogger(GroupMasterTeamMatcher.class);

    private static final int ID_MASK = (1 << 14) - 1;

    final int sceneID;

    final GroupDungeonSceneData sceneData;

    /**
     * 处理这个matcher事件的线程
     */
    private final DisruptorExecutor exec;

    /**
     * 所有的Combat服
     */
    private final GroupMasterCombatServerContainer combatServerContainer;

    private final IntHashMap<GroupMasterTeam> teams;

    private final ReusableIterator<GroupMasterTeam> teamsIte;

    /**
     * 每个英雄在哪个队伍里
     */
    private final LongHashMap<GroupMasterTeam> heroTeam;

    private final List<GroupMasterWorker> workers;

    private final TimeService timeService;

    private int idCounter;

    /**
     * 队伍列表信息是否有改变
     *
     * 队伍中有人准备或者没有准备, 不需要改变这个值
     */
    private boolean teamListChanged;

    public GroupMasterTeamMatcher(GroupDungeonSceneData sceneData,
            IThreadService threadService,
            GroupMasterCombatServerContainer combatServerContainer,
            TimeService timeService){
        this.sceneData = sceneData;
        this.sceneID = sceneData.id;
        this.exec = threadService.getExecutor(sceneID);
        this.workers = new ArrayList<>();
        this.combatServerContainer = combatServerContainer;
        this.timeService = timeService;

        this.teams = new IntHashMap<>();
        this.teamsIte = teams.newValueIterator();
        this.heroTeam = new LongHashMap<>();
    }

    /**
     *  encode, 并广播给每个服务器
     */
    public void encodeAndBroadcast(){
        exec.execute(encodeAndBroadcastRunnable);
    }

    public void onServerInit(final GroupMasterWorker worker){
        exec.execute(new Runnable(){
            @Override
            public void run(){
                workers.add(worker);

                worker.sendMessage(doEncode());
            }
        });
    }

    public void onServerDisconnected(final GroupMasterWorker worker){
        exec.execute(new Runnable(){
            @Override
            public void run(){
                workers.remove(worker);

                for (GroupMasterTeam team : teams.values()){
                    team.removeHeroFromServer(worker);
                }
            }
        });
    }

    public void onCreateGroup(ChannelBuffer buffer, GroupMasterWorker worker){
        final int fightAmountThreshold = readVarInt32(buffer);
        final boolean fullAutoStart = readBoolean(buffer);
        final long heroID = readVarInt64(buffer);
        final int heroLevel = readVarInt32(buffer);
        final int heroRaceID = readVarInt32(buffer);
        final int heroFightAmount = readVarInt32(buffer);
        final byte[] heroNameBytes = new byte[buffer.readableBytes()];
        buffer.readBytes(heroNameBytes);

        final GroupMasterHero hero = new GroupMasterHero(heroID, heroNameBytes,
                heroRaceID, heroLevel, heroFightAmount, worker);

        exec.execute(new Runnable(){
            @Override
            public void run(){
                teamListChanged = true;

                // 直到找到个不冲突的id
                GroupMasterTeam team;
                int id;
                do{
                    id = newID();
                    team = new GroupMasterTeam(GroupMasterTeamMatcher.this, id,
                            hero, fightAmountThreshold, fullAutoStart,
                            timeService.getCurrentTime());
                } while (teams.putIfAbsent(id, team) != null);

                GroupMasterTeam oldTeam = heroTeam.put(heroID, team);
                if (oldTeam != null){
                    logger.error("英雄创建了队伍, 但英雄本来就已经在个队伍中了... 从原来的队伍中删除他");
                    doRemoveHeroFromTeam(oldTeam, heroID);
                }

                logger.debug("副本 {} 创建了新的队伍: {}, 队长: {}", sceneID, team, hero);
            }
        });
    }

    private void doRemoveHeroFromTeam(GroupMasterTeam team, long heroID){
        assert Thread.currentThread() == exec.getThread(): "GroupMasterTeamMatcher.doRemoveHeroFromTeam不是在exec调用的";
        boolean isAlive = team.removeHero(heroID);
        if (!isAlive){
            // 队伍没了
            GroupMasterTeam removedTeam = teams.remove(team.id);
            if (removedTeam == null){
                logger.error(
                        "GroupMasterTeamMatcher.doRemoveHeroFromTeam时, 英雄从队伍中移除后, 队伍dead, 但是总的队伍map中没有这个队伍: {}",
                        Utils.getStackTrace());
            }
        }
    }

    public void onLeaveGroup(ChannelBuffer buffer, GroupMasterWorker worker){
        final long heroID = readVarInt64(buffer);

        exec.execute(new Runnable(){
            @Override
            public void run(){
                GroupMasterTeam team = heroTeam.remove(heroID);
                if (team != null){
                    teamListChanged = true;
                    doRemoveHeroFromTeam(team, heroID);
                } else{
                    logger.warn("GroupMasterTeamMatcher.onLeaveGroup时, 没有找到英雄的队伍");
                }
            }
        });
    }

    public void onAutoJoinGroup(ChannelBuffer buffer,
            final GroupMasterWorker worker){

        final long heroID = readVarInt64(buffer);
        final int heroLevel = readVarInt32(buffer);
        final int heroRaceID = readVarInt32(buffer);
        final int heroFightAmount = readVarInt32(buffer);
        final byte[] heroNameBytes = new byte[buffer.readableBytes()];
        buffer.readBytes(heroNameBytes);

        final GroupMasterHero hero = new GroupMasterHero(heroID, heroNameBytes,
                heroRaceID, heroLevel, heroFightAmount, worker);

        exec.execute(new Runnable(){

            @Override
            public void run(){
                for (GroupMasterTeam t : teams.values()){
                    if (t.canAddMoreHero()
                            && t.canFightAmountEnter(heroFightAmount)){
                        // 可加入

                        teamListChanged = true;

                        GroupMasterTeam oldTeam = heroTeam.put(heroID, t);
                        if (oldTeam != null){
                            logger.error("GroupMasterTeamMatcher.onAutoJoinGroup时, 英雄以前已经有队伍... 从以前的队伍中退出");
                            doRemoveHeroFromTeam(oldTeam, heroID); // 就算要进的就是以前的队伍, 也先退出, 再进, 这样玩家可以收到进入成功消息
                        }
                        t.doAutoJoin(hero);
                        return;
                    }
                }

                // 发送加入失败
                worker.sendMessage(GroupHeader.autoJoinFail(heroID));
            }
        });
    }

    public void onJoinGroup(ChannelBuffer buffer, final GroupMasterWorker worker){
        final int groupID = readVarInt32(buffer);
        final long heroID = readVarInt64(buffer);
        final int heroLevel = readVarInt32(buffer);
        final int heroRaceID = readVarInt32(buffer);
        final int heroFightAmount = readVarInt32(buffer);
        final byte[] heroNameBytes = new byte[buffer.readableBytes()];
        buffer.readBytes(heroNameBytes);

        final GroupMasterHero hero = new GroupMasterHero(heroID, heroNameBytes,
                heroRaceID, heroLevel, heroFightAmount, worker);

        exec.execute(new Runnable(){

            @Override
            public void run(){
                GroupMasterTeam team = teams.get(groupID);
                if (team == null){
                    logger.warn("GroupMasterTeamMatcher.onJoinGroup时, 没有找到英雄的队伍");
                    worker.sendMessage(joinGroupFail(heroID,
                            ERROR_JOIN_GROUP_ID_NOT_EXISTS));
                    return;
                }

                if (!team.isAlive()){
                    logger.error("GroupMasterTeamMatcher.onJoinGroup时, 发现teams里竟然还有!isAlive的队伍. 哪个操作没有把没用的队伍删掉");
                    worker.sendMessage(joinGroupFail(heroID,
                            ERROR_JOIN_GROUP_ID_NOT_EXISTS));
                    return;
                }

                if (!team.canFightAmountEnter(hero.fightAmount)){
                    worker.sendMessage(joinGroupFail(heroID,
                            ERROR_JOIN_GROUP_NOT_ENOUGH_FIGHT_AMOUNT));
                    return;
                }

                if (!team.canAddMoreHero()){
                    worker.sendMessage(joinGroupFail(heroID,
                            ERROR_JOIN_GROUP_TEAM_FULL));
                    return;
                }

                // 能进

                teamListChanged = true;

                GroupMasterTeam oldTeam = heroTeam.put(heroID, team);
                if (oldTeam != null){
                    logger.error("GroupMasterTeamMatcher.onJoinGroup时, 英雄以前已经有队伍... 从以前的队伍中退出");
                    doRemoveHeroFromTeam(oldTeam, heroID); // 就算要进的就是以前的队伍, 也先退出, 再进, 这样玩家可以收到进入成功消息
                }
                team.doAddHero(hero);
            }
        });
    }

    public void onReady(ChannelBuffer buffer, final GroupMasterWorker worker){
        final long heroID = readVarInt64(buffer);
        exec.execute(new Runnable(){
            @Override
            public void run(){
                GroupMasterTeam team = heroTeam.get(heroID);
                if (team == null){
                    logger.warn("GroupMasterTeamMatcher.onReady时, 没有找到英雄的队伍");
                    worker.sendMessage(GroupHeader
                            .proxyMsgOnlyHeaderAnd1Varint32(heroID,
                                    ClusterClientMessages.MODULE_ID,
                                    ClusterClientMessages.S2C_READY_FAIL, 1)); // 发送没有队伍的错误码
                    return;
                }

                team.doReady(heroID);
            }
        });
    }

    public void onCancelReady(ChannelBuffer buffer,
            final GroupMasterWorker worker){
        final long heroID = readVarInt64(buffer);

        exec.execute(new Runnable(){
            @Override
            public void run(){
                GroupMasterTeam team = heroTeam.get(heroID);
                if (team == null){
                    logger.warn("GroupMasterTeamMatcher.onCancelReady时, 没有找到英雄的队伍");
                    worker.sendMessage(GroupHeader
                            .proxyMsgOnlyHeaderAnd1Varint32(
                                    heroID,
                                    ClusterClientMessages.MODULE_ID,
                                    ClusterClientMessages.S2C_CANCEL_READY_FAIL,
                                    1));// 发送没有队伍的错误码
                    return;
                }

                team.doCancelReady(heroID);
            }
        });
    }

    public void onKick(ChannelBuffer buffer, final GroupMasterWorker worker){
        final long kickerID = readVarInt64(buffer);
        final long targetID = readVarInt64(buffer);

        exec.execute(new Runnable(){

            @Override
            public void run(){
                GroupMasterTeam kickerTeam = heroTeam.get(kickerID);
                if (kickerTeam == null){
                    logger.warn("GroupMasterTeamMatcher.onKick时, 没有找到英雄的队伍");
                    worker.sendMessage(GroupHeader
                            .proxyMsgOnlyHeaderAnd1Varint32(kickerID,
                                    ClusterClientMessages.MODULE_ID,
                                    ClusterClientMessages.S2C_KICK_FAIL, 1)); // 发送没有队伍的错误码
                    return;
                }

                if (!kickerTeam.isLeader(kickerID)){
                    worker.sendMessage(GroupHeader
                            .proxyMsgOnlyHeaderAnd1Varint32(kickerID,
                                    ClusterClientMessages.MODULE_ID,
                                    ClusterClientMessages.S2C_KICK_FAIL, 2)); // 发送不是队长的错误码
                    return;
                }

                boolean kicked = kickerTeam.tryKick(targetID); // 发给对应人的消息都在里面发送了

                if (kicked){
                    teamListChanged = true;
                    GroupMasterTeam beenKickedTeam = heroTeam.remove(targetID);
                    if (beenKickedTeam != kickerTeam){
                        logger.error("出大事了. GroupMasterTeamMatcher.onKick时, 踢成功, 但是在heroTeam列表里, 被踢人的队伍和踢人的人的队伍不同");
                        if (beenKickedTeam != null){
                            doRemoveHeroFromTeam(beenKickedTeam, targetID);
                        }
                    }
                }
            }
        });
    }

    public void onStart(ChannelBuffer buffer, final GroupMasterWorker worker){
        final long heroID = readVarInt64(buffer);

        exec.execute(new Runnable(){

            @Override
            public void run(){
                GroupMasterTeam team = heroTeam.get(heroID);
                if (team == null){
                    logger.warn("GroupMasterTeamMatcher.onStart时, 没有找到英雄的队伍");
                    worker.sendMessage(GroupHeader
                            .proxyMsgOnlyHeaderAnd1Varint32(heroID,
                                    ClusterClientMessages.MODULE_ID,
                                    ClusterClientMessages.S2C_START_FAIL, 1));// 发送没有队伍的错误码
                    return;
                }

                if (!team.isLeader(heroID)){
                    worker.sendMessage(GroupHeader
                            .proxyMsgOnlyHeaderAnd1Varint32(heroID,
                                    ClusterClientMessages.MODULE_ID,
                                    ClusterClientMessages.S2C_START_FAIL, 2));// 发送不是队长的错误码
                    return;
                }

                team.tryStart();
            }
        });
    }

    public void onDisplay(ChannelBuffer buffer, final GroupMasterWorker worker){
        final long heroID = readVarInt64(buffer);

        exec.execute(new Runnable(){
            @Override
            public void run(){
                GroupMasterTeam team = heroTeam.get(heroID);
                if (team == null){
                    worker.sendMessage(GroupHeader.replyYourGroupFail(heroID,
                            GroupHeader.ERROR_REPLY_YOUR_GROUP_NO_TEAM));
                    return;
                }

                if (!team.canAddMoreHero()){
                    worker.sendMessage(GroupHeader.replyYourGroupFail(heroID,
                            GroupHeader.ERROR_REPLY_YOUR_GROUP_TEAM_FULL));
                    return;
                }

                worker.sendMessage(GroupHeader.replyYourGroup(heroID, sceneID,
                        team.id, team.getFightAmountThreshold()));
            }
        });
    }

    // -----

    CombatMasterServerInfo getLowestLowCombatServer(){
        return combatServerContainer.getLowestLoadCombatServer();
    }

    void removeHeroTeam(long heroID){
        boolean removed = heroTeam.remove(heroID) != null;
        if (!removed){
            logger.error("GroupMasterTeamMatcher.removeHeroTeamOnStart时, heroTeam里没有要删除的英雄");
        }
    }

    void removeTeam(int teamID){
        boolean removed = teams.remove(teamID) != null;
        if (!removed){
            logger.error("GroupMasterTeamMatcher.removeTeamOnStart时, teams里没有要删除的队伍");
        } else{
            teamListChanged = true;
        }
    }

    private int newID(){
        return (idCounter++ & ID_MASK) + 1; // +1为了让结果不为0
    }

    private ChannelBuffer doEncode(){
        SceneTeamProto.Builder builder = SceneTeamProto.newBuilder();

        int totalTeamCount = teams.size();
        int skipFullTeam = totalTeamCount > VariableConfig.GROUP_DUNGEON_CLUSTER_TEAM_BROADCAST ? totalTeamCount
                - VariableConfig.GROUP_DUNGEON_CLUSTER_TEAM_BROADCAST
                : 0; // 最多跳过n个已经满的队伍

        int sentCount = 0;
        GroupMasterTeam team;
        for (teamsIte.rewind(); teamsIte.hasNext();){
            team = teamsIte.next();

            if (!team.canAddMoreHero()){
                // 满了
                if (skipFullTeam > 0){
                    // 还有需要跳过的满人队伍

                    --skipFullTeam;
                    continue; // 不写进去了
                }
            }

            TeamInfoProto proto = team.encode();
            if (proto != null){
                // 可能队伍正好解散了
                builder.addTeams(proto);
                if (++sentCount >= VariableConfig.GROUP_DUNGEON_CLUSTER_TEAM_BROADCAST){
                    // 超出了广播的队伍个数
                    break;
                }
            }
        }
        teamsIte.cleanUp();

        byte[] data = Utils.zlibCompress(builder.build().toByteArray());

        ChannelBuffer buffer = GroupHeader.newFixedSizeMessage(
                GroupHeader.M2S_BROADCAST_SCENE_TEAM_LIST,
                computeVarInt32Size(sceneID)
                        + computeVarInt32Size(totalTeamCount) + data.length);
        writeVarInt32(buffer, sceneID);
        writeVarInt32(buffer, totalTeamCount);
        buffer.writeBytes(data);
        return buffer;
    }

    private void dismissExpiredTeam(){
        long ctime = timeService.getCurrentTime();

        GroupMasterTeam team;
        for (teamsIte.rewind(); teamsIte.hasNext();){
            team = teamsIte.next();

            if (team.needDismiss(ctime)){
                team.doDismiss();
                teamsIte.remove();
                teamListChanged = true;
            }
        }
        teamsIte.cleanUp();
    }

    /**
     * 交给matcher线程, 去真正encode并广播
     */
    private final Runnable encodeAndBroadcastRunnable = new Runnable(){
        @Override
        public void run(){
            dismissExpiredTeam();

            if (!teamListChanged){
                return;
            }

            teamListChanged = false;
            logger.debug("广播 {} 副本的最新队伍信息", sceneID);

            ChannelBuffer msg = doEncode();
            for (GroupMasterWorker worker : workers){
                worker.sendMessage(msg);
            }
        }
    };
}
