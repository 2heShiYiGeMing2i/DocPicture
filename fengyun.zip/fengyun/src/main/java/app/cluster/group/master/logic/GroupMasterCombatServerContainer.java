package app.cluster.group.master.logic;

import java.util.Arrays;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.cluster.combat.master.CombatMasterServerInfo;
import app.game.service.IThreadService;

import com.google.inject.Inject;
import com.mokylin.collection.LongConcurrentSynchronizedHashMap;
import com.mokylin.collection.ReusableIterator;
import com.mokylin.sink.util.RandomNumber;

public class GroupMasterCombatServerContainer{
    private static final Logger logger = LoggerFactory
            .getLogger(GroupMasterCombatServerContainer.class);

    private final LongConcurrentSynchronizedHashMap<CombatMasterServerInfo> combatServers;

    private final ReusableIterator<CombatMasterServerInfo> combatServerIte;

    private final IThreadService threadService;

    /**
     * 当前load最低的Combat服
     */
    private volatile CombatMasterServerInfo lowestLoadServer;

    @Inject
    GroupMasterCombatServerContainer(IThreadService threadService){
        this.threadService = threadService;
        this.combatServers = new LongConcurrentSynchronizedHashMap<>();
        this.combatServerIte = combatServers.newValueIterator();
        setUpdate();
    }

    private boolean noCombatServer;

    private void setUpdate(){
        threadService.getScheduledExecutorService().scheduleWithFixedDelay(
                new Runnable(){
                    @Override
                    public void run(){
                        try{
                            doGetLowestLoadCombatServer();

                            if (lowestLoadServer == null){
                                if (!noCombatServer){
                                    noCombatServer = true;
                                    logger.error(
                                            "没有Combat服务器啊!! server count: {}",
                                            combatServers.size());
                                }
                            } else{
                                if (noCombatServer){
                                    noCombatServer = false;
                                    logger.info(
                                            "有Combat服务器了. server count: {}",
                                            combatServers.size());
                                }
                            }
                        } catch (Throwable ex){
                            logger.error(
                                    "GroupMasterCombatServerContainer出大问题了, 自己去看",
                                    ex);
                        }
                    }
                }, 1, 1, TimeUnit.SECONDS);
    }

    // --- 排序 ---
    private static final int SORT_SIZE = 64;
    /**
     * 用来存load最低的服
     */
    private final CombatMasterServerInfo[] tempList = new CombatMasterServerInfo[SORT_SIZE];

    private int tempListIndex;

    private int lastTempListIndex;

    private void doGetLowestLoadCombatServer(){
        try{
            tempListIndex = 0;
            for (combatServerIte.rewind(); combatServerIte.hasNext();){
                tempList[tempListIndex++] = combatServerIte.next();

                if (tempListIndex == SORT_SIZE){
                    break;
                }
            }
            combatServerIte.cleanUp();

            // 把上次有, 这次没有的位置, 设为null. lastTempIndex一定 <= SORT_SIZE
            for (int i = tempListIndex; i < lastTempListIndex; i++){
                tempList[i] = null;
            }

            lastTempListIndex = tempListIndex;

            if (tempListIndex == 0){
                this.lowestLoadServer = null;
                return;
            }

            Arrays.sort(tempList, 0, tempListIndex,
                    CombatMasterServerInfo.LOAD_COMPARATOR);

            int lowestLoad = tempList[0].getLoad();

            int maxLoadThreshold = Math.max(lowestLoad, // 防止lowest为负
                    ((int) Math.ceil(lowestLoad * 1.2f)) + 1); // 只要load比最低的高20%以内, 都可以. +1防0%

            if (maxLoadThreshold < 1000){
                maxLoadThreshold = 1000; // 10都是可以接受的 (汇报的load是*100的)
            }

            int maxIndex = 1;

            for (; maxIndex < tempListIndex; maxIndex++){
                if (tempList[maxIndex].getLoad() > maxLoadThreshold){
                    break;
                }
            }

            logger.debug("在 {} 个combat服间随机", maxIndex);
            this.lowestLoadServer = tempList[RandomNumber.getRate(maxIndex)];
        } catch (Throwable ex){
            logger.error(
                    "GroupMasterCombatServerContainer.setLowestLoadServer出错",
                    ex);
            this.lowestLoadServer = combatServers.size() == 0 ? null
                    : combatServers.newValueIterator().next();
        }
    }

    // ---

    void addCombatServer(CombatMasterServerInfo server){
        combatServers.put(server.id, server);
    }

    void removeCombatServer(CombatMasterServerInfo server){
        combatServers.remove(server.id);
    }

    void updateCombatServer(CombatMasterServerInfo server){
        combatServers.put(server.id, server);
    }

    public CombatMasterServerInfo getLowestLoadCombatServer(){
        return lowestLoadServer;
    }
}
