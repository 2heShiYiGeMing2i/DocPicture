package app.cluster.group.master;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.cluster.protobuf.ServerInfoContent.GroupMasterInfoProto;

import com.google.protobuf.InvalidProtocolBufferException;

public class GroupMasterServerInfo{
    private static final Logger logger = LoggerFactory
            .getLogger(GroupMasterServerInfo.class);

    public final String address;

    public final int port;

    private final int hashCode;

    private GroupMasterServerInfo(byte[] info)
            throws InvalidProtocolBufferException{
        GroupMasterInfoProto proto = GroupMasterInfoProto.parseFrom(info);
        this.address = proto.getAddress();
        this.port = proto.getPort();
        this.hashCode = address.hashCode() * 31 + port;
    }

    @Override
    public String toString(){
        return "master @ " + address + ":" + port;
    }

    @Override
    public int hashCode(){
        return hashCode;
    }

    @Override
    public boolean equals(Object obj){
        if (obj instanceof GroupMasterServerInfo){
            GroupMasterServerInfo info = (GroupMasterServerInfo) obj;
            return address.equals(info.address) && port == info.port;
        }
        return false;
    }

    public static GroupMasterServerInfo parse(byte[] info){
        try{
            return new GroupMasterServerInfo(info);
        } catch (Throwable ex){
            logger.error("GroupMasterInfo.parse出错", ex);
            return null;
        }
    }
}
