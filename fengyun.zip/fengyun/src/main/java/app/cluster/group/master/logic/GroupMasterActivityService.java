package app.cluster.group.master.logic;

import static com.mokylin.sink.util.BufferUtil.*;

import java.util.EnumMap;

import org.jboss.netty.buffer.ChannelBuffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.cluster.combat.master.CombatMasterServerInfo;
import app.cluster.group.master.GroupMasterConfiguration;
import app.cluster.group.master.GroupMasterWorker;
import app.cluster.group.master.logic.activity.GroupMasterActivity;
import app.game.data.scene.GlobalActivitySceneData;
import app.game.data.scene.SceneData;
import app.game.data.scene.SceneDatas;
import app.game.service.IThreadService;
import app.game.service.TimeService;
import app.utils.Operators;

import com.google.inject.Inject;
import com.mokylin.collection.IntHashMap;

/**
 * 负责每一些人就新开一个场景
 * @author Timmy
 *
 */
public class GroupMasterActivityService{
    private static final Logger logger = LoggerFactory
            .getLogger(GroupMasterActivityService.class);

    private final EnumMap<Operators, IntHashMap<GroupMasterActivity>> activities;

    @Inject
    GroupMasterActivityService(SceneDatas sceneDatas,
            GroupMasterCombatServerContainer combatServerContainer,
            TimeService timeService, IThreadService threadService,
            GroupMasterConfiguration config){
        this.activities = new EnumMap<>(Operators.class);

        for (Operators operator : config.getSelfOperators()){
            IntHashMap<GroupMasterActivity> map = new IntHashMap<>();
            this.activities.put(operator, map);
            for (SceneData sceneData : sceneDatas.getAll()){
                if (sceneData instanceof GlobalActivitySceneData){
                    GroupMasterActivity activity = new GroupMasterActivity(
                            (GlobalActivitySceneData) sceneData,
                            combatServerContainer, timeService, threadService);

                    map.put(sceneData.id, activity);
                }
            }
        }
    }

    public void onCombatServerDisconnected(CombatMasterServerInfo server){
        for (IntHashMap<GroupMasterActivity> map : activities.values()){
            for (GroupMasterActivity activity : map.values()){
                activity.onCombatServerDisconnected(server);
            }
        }
    }

    public void onGetActivityDestination(ChannelBuffer buffer,
            GroupMasterWorker worker){
        int sceneID = readVarInt32(buffer);

        GroupMasterActivity activity = activities.get(worker.getOperator())
                .get(sceneID); // 到这里, worker的operator一定是存在且合法的
        if (activity == null){
            logger.error(
                    "GroupMasterActivityService.onGetActivityDestination时, 场景id没找到. 要么不存在, 要么不是个跨服的活动场景: {}",
                    sceneID);
            return;
        }

        long heroID = readVarInt64(buffer);
        activity.onGetActivityDestination(heroID, worker);
    }

}
