package app.cluster.group.master.logic;

import static com.mokylin.sink.util.BufferUtil.readVarInt32;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.jboss.netty.buffer.ChannelBuffer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.cluster.group.master.GroupMasterConfiguration;
import app.cluster.group.master.GroupMasterWorker;
import app.cluster.group.master.logic.team.GroupMasterTeamMatcher;
import app.game.data.scene.GroupDungeonSceneData;
import app.game.data.scene.SceneData;
import app.game.data.scene.SceneDatas;
import app.game.service.IThreadService;
import app.game.service.TimeService;
import app.utils.Operators;

import com.google.inject.Inject;
import com.mokylin.collection.IntHashMap;

public class GroupMasterTeamService{
    private static final Logger logger = LoggerFactory
            .getLogger(GroupMasterTeamService.class);

    private final IThreadService threadService;

    /**
     * 第一个key是场景id
     * 后面的key是生成的队伍id
     */
    private final EnumMap<Operators, IntHashMap<GroupMasterTeamMatcher>> matchers;

    private final GroupMasterTeamMatcher[] matcherArray;

    @Inject
    GroupMasterTeamService(IThreadService threadService,
            TimeService timeService,
            GroupMasterCombatServerContainer combatServerContainer,
            GroupMasterConfiguration config, SceneDatas sceneDatas){
        this.threadService = threadService;

        this.matchers = new EnumMap<>(Operators.class);

        List<GroupMasterTeamMatcher> matcherList = new ArrayList<>();

        for (Operators operator : config.getSelfOperators()){
            IntHashMap<GroupMasterTeamMatcher> map = new IntHashMap<>();
            matchers.put(operator, map);

            for (SceneData sceneData : sceneDatas.getAll()){
                if (sceneData instanceof GroupDungeonSceneData){
                    GroupDungeonSceneData groupSceneData = (GroupDungeonSceneData) sceneData;
                    GroupMasterTeamMatcher matcher = new GroupMasterTeamMatcher(
                            groupSceneData, threadService,
                            combatServerContainer, timeService);
                    map.put(groupSceneData.id, matcher);
                    matcherList.add(matcher);
                }
            }
        }

        this.matcherArray = matcherList.toArray(new GroupMasterTeamMatcher[0]);

        setUpdate();
    }

    /**
     * 是否服务此运营商
     * @param operator
     * @return
     */
    public boolean containsOperator(Operators operator){
        return matchers.containsKey(operator);
    }

    /**
     * 每隔一段时间, 把所有的队伍信息拼成一条消息, 广播给所有的服务器
     */
    private void setUpdate(){
        logger.debug("GroupMasterTeamService开始定期广播组队信息");
        threadService.getScheduledExecutorService().scheduleWithFixedDelay(
                new Runnable(){
                    @Override
                    public void run(){
                        try{
                            generateTeamInfoAndBroadcast();
                        } catch (Throwable ex){
                            logger.error(
                                    "GroupMasterTeamService.generateTeamInfoAndBroadcast出错",
                                    ex);
                        }
                    }
                }, 3, 2, TimeUnit.SECONDS);
    }

    /**
     * 生成每个副本的队伍信息, 并广播给每个游戏服, 由游戏服缓存, 并发送给注册了的玩家
     */
    private void generateTeamInfoAndBroadcast(){
        for (GroupMasterTeamMatcher matcher : matcherArray){
            matcher.encodeAndBroadcast();
        }
    }

    public void onServerInit(GroupMasterWorker worker){
        // 每个worker调用此方法前, 已经检查过, 这个worker的operator是存在的
        for (GroupMasterTeamMatcher matcher : matchers
                .get(worker.getOperator()).values()){
            matcher.onServerInit(worker);
        }
    }

    public void onServerDisconnected(GroupMasterWorker worker){
        for (GroupMasterTeamMatcher matcher : matchers
                .get(worker.getOperator()).values()){
            matcher.onServerDisconnected(worker);
        }
    }

    public void onCreateGroup(ChannelBuffer buffer, GroupMasterWorker worker){
        int dungeonID = readVarInt32(buffer);
        GroupMasterTeamMatcher matcher = matchers.get(worker.getOperator())
                .get(dungeonID);
        if (matcher == null){
            logger.error(
                    "GroupMasterTeamService.onCreateGroup时, 没有找到matcher: {}",
                    dungeonID);
            return;
        }

        assert matcher != null;

        matcher.onCreateGroup(buffer, worker);
    }

    public void onLeaveGroup(ChannelBuffer buffer, GroupMasterWorker worker){
        int dungeonID = readVarInt32(buffer);
        GroupMasterTeamMatcher matcher = matchers.get(worker.getOperator())
                .get(dungeonID);
        if (matcher == null){
            logger.error(
                    "GroupMasterTeamService.onLeaveGroup时, 没有找到matcher: {}",
                    dungeonID);
            return;
        }

        matcher.onLeaveGroup(buffer, worker);
    }

    public void onJoinGroup(ChannelBuffer buffer, GroupMasterWorker worker){
        int dungeonID = readVarInt32(buffer);
        GroupMasterTeamMatcher matcher = matchers.get(worker.getOperator())
                .get(dungeonID);
        if (matcher == null){
            logger.error(
                    "GroupMasterTeamService.onJoinGroup时, 没有找到matcher: {}",
                    dungeonID);
            return;
        }

        matcher.onJoinGroup(buffer, worker);
    }

    public void onAutoJoinGroup(ChannelBuffer buffer, GroupMasterWorker worker){
        int dungeonID = readVarInt32(buffer);
        GroupMasterTeamMatcher matcher = matchers.get(worker.getOperator())
                .get(dungeonID);
        if (matcher == null){
            logger.error(
                    "GroupMasterTeamService.onAutoJoinGroup时, 没有找到matcher: {}",
                    dungeonID);
            return;
        }

        matcher.onAutoJoinGroup(buffer, worker);
    }

    public void onReady(ChannelBuffer buffer, GroupMasterWorker worker){
        int dungeonID = readVarInt32(buffer);
        GroupMasterTeamMatcher matcher = matchers.get(worker.getOperator())
                .get(dungeonID);
        if (matcher == null){
            logger.error("GroupMasterTeamService.onReady时, 没有找到matcher: {}",
                    dungeonID);
            return;
        }

        matcher.onReady(buffer, worker);
    }

    public void onCancelReady(ChannelBuffer buffer, GroupMasterWorker worker){
        int dungeonID = readVarInt32(buffer);
        GroupMasterTeamMatcher matcher = matchers.get(worker.getOperator())
                .get(dungeonID);
        if (matcher == null){
            logger.error(
                    "GroupMasterTeamService.onCancelReady时, 没有找到matcher: {}",
                    dungeonID);
            return;
        }

        matcher.onCancelReady(buffer, worker);
    }

    public void onKick(ChannelBuffer buffer, GroupMasterWorker worker){
        int dungeonID = readVarInt32(buffer);
        GroupMasterTeamMatcher matcher = matchers.get(worker.getOperator())
                .get(dungeonID);
        if (matcher == null){
            logger.error("GroupMasterTeamService.onKick时, 没有找到matcher: {}",
                    dungeonID);
            return;
        }

        matcher.onKick(buffer, worker);
    }

    public void onStart(ChannelBuffer buffer, GroupMasterWorker worker){
        int dungeonID = readVarInt32(buffer);
        GroupMasterTeamMatcher matcher = matchers.get(worker.getOperator())
                .get(dungeonID);
        if (matcher == null){
            logger.error("GroupMasterTeamService.onStart时, 没有找到matcher: {}",
                    dungeonID);
            return;
        }

        matcher.onStart(buffer, worker);
    }

    public void onDisplay(ChannelBuffer buffer, GroupMasterWorker worker){
        int dungeonID = readVarInt32(buffer);
        GroupMasterTeamMatcher matcher = matchers.get(worker.getOperator())
                .get(dungeonID);
        if (matcher == null){
            logger.error("GroupMasterTeamService.onDisplay时, 没有找到matcher: {}",
                    dungeonID);
            return;
        }

        matcher.onDisplay(buffer, worker);
    }
}
