package app.cluster.group.master.logic;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import app.cluster.combat.discovery.ICombatServerListener;
import app.cluster.combat.master.CombatMasterServerInfo;
import app.game.service.IThreadService;
import app.game.service.TimeService;

import com.google.inject.Inject;

public class GroupMasterServices implements ICombatServerListener{
    private static final Logger logger = LoggerFactory
            .getLogger(GroupMasterServices.class);

    private final TimeService timeService;

    private final IThreadService threadService;

    /**
     * 负责组队
     */
    private final GroupMasterTeamService groupMasterTeamService;

    /**
     * 负责活动
     */
    private final GroupMasterActivityService groupMasterActivityService;

    /**
     * 保存所有已发现的的Combat服务器
     */
    private final GroupMasterCombatServerContainer combatServerContainer;

    @Inject
    GroupMasterServices(TimeService timeService, IThreadService threadService,
            GroupMasterTeamService groupMasterTeamService,
            GroupMasterActivityService groupMasterActivityService,
            GroupMasterCombatServerContainer combatServerContainer){
        this.timeService = timeService;
        this.threadService = threadService;
        this.groupMasterTeamService = groupMasterTeamService;
        this.groupMasterActivityService = groupMasterActivityService;
        this.combatServerContainer = combatServerContainer;
    }

    public IThreadService getThreadService(){
        return threadService;
    }

    public TimeService getTimeService(){
        return timeService;
    }

    public GroupMasterActivityService getGroupMasterActivityService(){
        return groupMasterActivityService;
    }

    public GroupMasterTeamService getGroupMasterTeamService(){
        return groupMasterTeamService;
    }

    // --- CombatServer ---
    @Override
    public void onCombatServerAdded(CombatMasterServerInfo server){
        logger.info("发现新的Combat服务器: {}", server);
        combatServerContainer.addCombatServer(server);
    }

    @Override
    public void onCombatServerRemoved(CombatMasterServerInfo server){
        logger.info("发现Combat服务器关闭: {}", server);
        combatServerContainer.removeCombatServer(server);
        groupMasterActivityService.onCombatServerDisconnected(server);
    }

    @Override
    public void onCombatServerUpdated(CombatMasterServerInfo server){
        logger.debug("发现Combat服务器信息改变: {}", server);
        combatServerContainer.updateCombatServer(server);
    }

}
