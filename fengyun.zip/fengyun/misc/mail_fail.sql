/*
Navicat MySQL Data Transfer

Source Server         : local
Source Server Version : 50611
Source Host           : localhost:3306
Source Database       : testdb

Target Server Type    : MYSQL
Target Server Version : 50611
File Encoding         : 65001

Date: 2013-08-06 20:57:20
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `mail_fail`
-- ----------------------------
DROP TABLE IF EXISTS `mail_fail`;
CREATE TABLE `mail_fail` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `combine_id` bigint(20) NOT NULL,
  `content` mediumblob,
  `data` mediumblob,
  `create_time` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_combine_id` (`combine_id`) USING HASH,
  KEY `idx_create_time` (`create_time`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=806 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of mail_fail
-- ----------------------------
