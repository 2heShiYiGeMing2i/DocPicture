package com.mokylin.sink.util.parse;

import static org.junit.Assert.assertEquals;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.junit.AfterClass;
import org.junit.Test;

public class TestObjectParsers{

    static ExecutorService exec = Executors.newCachedThreadPool();

    @AfterClass
    public static void tearDown(){
        exec.shutdown();
    }

    @Test
    public void testSimple(){
        String content = "\r\nheader1\theader2\theader3\r\nv1\tv2\tv3\r\nv4\tv5\tv6\r\n\r\n";

        List<ObjectParser> result = ObjectParsers.parseList("name", content,
                exec);

        assertEquals(2, result.size());

        ObjectParser ps1 = result.get(0);
        assertEquals("v1", ps1.getKey("header1"));
        assertEquals("v2", ps1.getKey("header2"));
        assertEquals("v3", ps1.getKey("header3"));

        ObjectParser ps2 = result.get(1);
        assertEquals("v4", ps2.getKey("header1"));
        assertEquals("v5", ps2.getKey("header2"));
        assertEquals("v6", ps2.getKey("header3"));
    }

    @Test
    public void testEmptyField(){
        String content = "\r\nh1\th2\th3\r\n\tn\t";
        List<ObjectParser> result = ObjectParsers.parseList("name", content,
                exec);

        assertEquals(1, result.size());
        ObjectParser p = result.get(0);
        assertEquals("", p.getKey("h1"));
        assertEquals("n", p.getKey("h2"));
        assertEquals("", p.getKey("h3"));
    }

    @Test
    public void testTrailingHeaderTab(){
        String content = "\r\nh1\t\r\n1\t2";
        List<ObjectParser> result = ObjectParsers.parseList("name", content,
                exec);
        assertEquals(1, result.size());
        ObjectParser p = result.get(0);
        assertEquals(1, p.getIntKey("h1"));
        assertEquals(2, p.getIntKey(""));
    }

    @Test
    public void testBasicBuilder(){
        ObjectParser p = ObjectParser.newBuilder().addField("h1", "1").build();
        assertEquals(1, p.getIntKey("h1"));
    }

    @Test
    public void testDuplicateHeader(){
        ObjectParser p = ObjectParser.newBuilder().addField("h1", "1")
                .addField("h1", "2").build();

        assertEquals(1, p.map.keySet().size());
        assertEquals(2, p.map.size());

        List<String> list = p.getKeyList("h1");
        assertEquals(2, list.size());
        assertEquals("1", list.get(0));
        assertEquals("2", list.get(1));
    }

    @Test(expected = IllegalStateException.class)
    public void testEmptyBuilder(){
        ObjectParser.newBuilder().build();
    }
}
