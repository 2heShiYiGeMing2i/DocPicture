package com.mokylin.sink.util;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class TestUtils{

    @Test
    public void testMultiplyMoney(){
        int price = 1000;
        int quantity = 1000;

        assertEquals(price * quantity, Utils.multiplyMoney(price, quantity));
    }

    @Test(expected = IllegalArgumentException.class)
    public void testMultiplyMoneyPrice0(){
        Utils.multiplyMoney(0, 100);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testMultiplyMoneyQuantity0(){
        Utils.multiplyMoney(100, 0);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testMultiplyOverflow(){
        int price = 10_0000_0000;
        int quantity = 10_0000_0000;

        System.out.println(price * quantity);
        Utils.multiplyMoney(price, quantity);
    }
}
