package com.mokylin.sink.util.pack;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestServerConfigLoader{

    @Test
    public void testLoadConfig(){
        final String config = "a = 1\r\nb=2\r\nc=3\r\nd=4\r\ne=5\r\nf=6\r\n";
        
        TestServerConfig testConfig = new TestServerConfig();
        ServerConfigLoaders.readConfigFile(testConfig, new ServerConfigLoader(){
            
            @Override
            public String loadConfig(){
                return config;
            }
        });
        
        assertEquals(1, testConfig.initCalledCount);
        assertEquals(1, testConfig.a);
        assertEquals("2", testConfig.b);
        assertTrue(testConfig.c == 3d);
        assertEquals(4L, testConfig.d);
        assertTrue(testConfig.e == 5f);
        
        assertEquals(6, TestServerConfig.f); // static field also set
    }

    @Test(expected=IllegalArgumentException.class)
    public void testLoadNotExistsField(){
        final String config = "h = 1";
        
        TestServerConfig testConfig = new TestServerConfig();
        ServerConfigLoaders.readConfigFile(testConfig, new ServerConfigLoader(){
            
            @Override
            public String loadConfig(){
                return config;
            }
        });
    }
    
    private static class TestServerConfig implements ServerConfig{
        
        int initCalledCount;
        public void init(){
            initCalledCount++;
        }
        
        public int a = 100;
        public String b = "120";
        public double c = 140d;
        public long d = 160L;
        public float e = 180f;
        public static int f = 200;
    }
}
