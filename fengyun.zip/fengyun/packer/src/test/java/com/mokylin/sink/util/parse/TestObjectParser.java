package com.mokylin.sink.util.parse;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.BeforeClass;
import org.junit.Test;
public class TestObjectParser{
    static String[] header = new String[]{"header1", "header2", "header3", "header2", "header3"};

    static String[] value = new String[]{"value1", "value2", "value3", "value4", "value5"};
    
    static ObjectParser op;
    
    @BeforeClass
    public static void init(){
        op = new ObjectParser(header, value);
    }
    
    @Test(expected=IllegalArgumentException.class)
    public void testDiffLenValue(){
        String[] values = new String[]{"v1", "v2", "v3", "v4"};
        new ObjectParser(header, values);
    }

    @Test(expected=IllegalArgumentException.class)
    public void testDiffLenValue1(){
        String[] values = new String[]{"v1", "v2", "v3", "v4", "v5", "v6"};
        new ObjectParser(header, values);
    }
    
    @Test(expected=NullPointerException.class)
    public void testNullValues(){
        String[] values = new String[]{"v1", "v2", "v3", "v4",null};
        new ObjectParser(header, values);
    }
    
    @Test
    public void testGetKey(){
        assertEquals("value1", op.getKey("header1"));
    }
    
    @Test
    public void testGetMultiKey(){
        List<String> result = op.getKeyList("header1");
        assertEquals(1, result.size());
        assertEquals("value1", result.get(0));
        assertEquals(result, op.getKeyList("header1"));
    }
    
    @Test
    public void testGetMultiKeyList(){
        List<String> result = op.getKeyList("header2");
        assertEquals(2, result.size());
        assertEquals("value2", result.get(0));
        assertEquals("value4", result.get(1));
    }
    
    @Test(expected=NullPointerException.class)
    public void testGetNullKey(){
        op.getKey(null);
    }
    
    @Test(expected=NullPointerException.class)
    public void testGetNullKeyList(){
        op.getKeyList(null);
    }
    
    @Test(expected=RuntimeException.class)
    public void testNotExistsKey(){
        op.getKey("noexisted");
    }
    
    @Test(expected=RuntimeException.class)
    public void testNotExistKeyList(){
        op.getKeyList("notexisted");
    }
    
    @Test(expected=RuntimeException.class)
    public void testGetMultiValueKey(){
        op.getKey("header2");
    }
    
    
}
