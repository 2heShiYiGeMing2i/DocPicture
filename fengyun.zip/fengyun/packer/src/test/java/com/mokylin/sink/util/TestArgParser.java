package com.mokylin.sink.util;

import static org.junit.Assert.*;

import java.util.Arrays;

import org.junit.Test;

import com.mokylin.sink.util.parse.ObjectParser;

public class TestArgParser{

    @Test
    public void testBasic(){
        ObjectParser p = ArgParser.parse(new String[]{"a=b", "aa = bb",
                "aa= cc"});
        assertEquals("b", p.getKey("a"));

        String[] array = p.getStringArray("aa");
        Arrays.sort(array);
        assertEquals("bb", array[0]);
        assertEquals("cc", array[1]);
    }

    @Test
    public void testEmptyArray(){
        ObjectParser p = ArgParser.parse(new String[0]);
        assertNotNull(p);
    }
}
