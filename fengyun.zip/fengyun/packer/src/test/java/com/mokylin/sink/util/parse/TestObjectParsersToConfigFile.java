package com.mokylin.sink.util.parse;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.junit.AfterClass;
import org.junit.Test;

public class TestObjectParsersToConfigFile{

    private static final ExecutorService exec = Executors.newCachedThreadPool();

    @AfterClass
    public static void tearDown(){
        exec.shutdown();
    }

    @Test
    public void testBasic(){
        ObjectParser p = ObjectParser.newBuilder().addField("h1", "1")
                .addField("h2", "2").build();
        ObjectParser p1 = ObjectParser.newBuilder().addField("h1", "1")
                .addField("h2", "2").build();
        String s = ObjectParsers.toConfigFile(p, p1);

        List<ObjectParser> list = ObjectParsers.parseList("name", s, exec);
        assertEquals(2, list.size());
        assertEquals(p, list.get(0));
        assertEquals(p1, list.get(1));
    }

    @Test
    public void testOneHaveMoreField(){
        ObjectParser p = ObjectParser.newBuilder().addField("h1", "1").build();
        ObjectParser p1 = ObjectParser.newBuilder().addField("h1", "2")
                .addField("h2", "3").build();
        String s = ObjectParsers.toConfigFile(p, p1);

        List<ObjectParser> list = ObjectParsers.parseList("name", s, exec);

        assertEquals(0, list.get(0).getIntKey("h2")); // contains this key
        assertEquals(p1, list.get(1));
    }

    @Test
    public void testOneHaveDifferentLength(){
        ObjectParser p = ObjectParser.newBuilder().addField("h1", "1").build();
        ObjectParser p1 = ObjectParser.newBuilder().addField("h1", "1")
                .addField("h1", "2").build();
        ObjectParser p2 = ObjectParser.newBuilder().addField("h1", "1")
                .addField("h1", "2").addField("h1", "3").build();

        String s = ObjectParsers.toConfigFile(p, p1, p2);

        List<ObjectParser> list = ObjectParsers.parseList("name", s, exec);
        assertEquals(Arrays.asList("1", "", ""), list.get(0).getKeyList("h1"));
        assertEquals(Arrays.asList("1", "2", ""), list.get(1).getKeyList("h1"));
        assertEquals(Arrays.asList("1", "2", "3"), list.get(2).getKeyList("h1"));
    }

}
