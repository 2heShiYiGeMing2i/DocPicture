package com.mokylin.sink.util.pack;

public interface ServerConfigLoader{
    public String loadConfig();
}
