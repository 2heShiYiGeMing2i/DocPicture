package com.mokylin.sink.util.pack;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mokylin.collection.Pair;

public class ConfigPackFileLoader implements FileLoader{
    private static final Logger logger = LoggerFactory
            .getLogger(ConfigPackFileLoader.class);

    private final Map<String, byte[]> config;

    public ConfigPackFileLoader(Map<String, byte[]> configs){
        if (configs == null){
            throw new NullPointerException();
        }

        this.config = configs;
    }

    @Override
    public String readFile(String path){
        byte[] result = config.get(path);
        if (result == null){
            logger.debug("File not found: {}", path);
            return null;
        }

        return CharSetConvertor.convertBytes(result, path);
    }

    @Override
    public byte[] readByteFile(String path){
        return config.get(path);
    }

    @Override
    public Collection<Pair<String, String>> loadFilesInFolder(String path){
        List<Pair<String, String>> result = new LinkedList<Pair<String, String>>();
        for (Entry<String, byte[]> entry : config.entrySet()){
            int indexOf = entry.getKey().indexOf(path);

            if (indexOf == 0){
                String fileName = entry.getKey().substring(path.length());
                if (fileName.startsWith("/")){
                    fileName = fileName.substring(1);
                }

                if (fileName.indexOf("/") == -1){
                    result.add(new Pair<String, String>(fileName,
                            CharSetConvertor.convertBytes(entry.getValue(),
                                    entry.getKey())));
                }
            }
        }
        return result;
    }

    @Override
    public Collection<Pair<String, byte[]>> loadByteFilesInFolder(String path){
        List<Pair<String, byte[]>> result = new LinkedList<Pair<String, byte[]>>();
        for (Entry<String, byte[]> entry : config.entrySet()){
            int indexOf = entry.getKey().indexOf(path);

            if (indexOf == 0){
                String fileName = entry.getKey().substring(path.length());
                if (fileName.startsWith("/")){
                    fileName = fileName.substring(1);
                }

                if (fileName.indexOf("/") == -1){
                    result.add(new Pair<String, byte[]>(fileName, entry
                            .getValue()));
                }
            }
        }
        return result;
    }

    @Override
    public Map<String, byte[]> loadAllFiles(){
        return config;
    }

}
