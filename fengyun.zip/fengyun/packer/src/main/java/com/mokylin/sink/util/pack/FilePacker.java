package com.mokylin.sink.util.pack;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.zip.GZIPOutputStream;

import com.google.protobuf.ByteString;
import com.google.protobuf.InvalidProtocolBufferException;
import com.mokylin.sink.util.StringEncoder;
import com.mokylin.sink.util.Utils;
import com.mokylin.sink.util.pack.ConfigContent.ConfigFile;
import com.mokylin.sink.util.pack.ConfigContent.ConfigFilePack;

public class FilePacker{

    /**
     * 
     * @param fromDir
     * @return 是否成功
     */
    public static boolean packAndGenerate(String fromDir, String toDir){
        if (fromDir == null || fromDir.isEmpty() || toDir == null
                || toDir.isEmpty()){
            throw new IllegalArgumentException();
        }

        try{
            System.out.println("开始压缩: " + fromDir);
            byte[] p = pack(new File(fromDir));

            String fileName = "secret";
            File file = new File(toDir + fileName + ".hyc");
            System.out.println("生成中: " + file.getAbsolutePath());
            if (!file.createNewFile()){
                System.err.println("文件已存在,强制删除: " + file.getAbsolutePath());
                if (!file.delete()){
                    System.err.println("文件已存在,强制删除失败: "
                            + file.getAbsolutePath());
                    return false;
                }

                if (!file.createNewFile()){
                    System.err.println("删除后,重新创建还是失败: "
                            + file.getAbsolutePath());
                    return false;
                }
                System.err.println("重新创建成功: " + file.getAbsolutePath());
            }

            GZIPOutputStream fos = new GZIPOutputStream(new FileOutputStream(
                    file));
            try{
                fos.write(p);
                fos.flush();
            } finally{
                fos.close();
            }
            System.out.println("生成完成:" + file.getAbsolutePath());
            return true;

        } catch (Throwable e){
            System.err.println("生成出错！");
            return false;
        }

    }

    public static byte[] pack(File folder) throws IOException{
        if (folder == null){
            throw new NullPointerException();
        }

        if (!folder.exists() || folder.isFile()){
            throw new IllegalArgumentException("folder 不存在");
        }

        ConfigFilePack.Builder builder = ConfigFilePack.newBuilder();

        String basePath = folder.getAbsolutePath();
        // 去除最后的路径
        int indexOf = basePath.lastIndexOf(File.separator);
        if (indexOf >= 0){
            basePath = basePath.substring(0, indexOf + 1);
        }
        addFile(folder, builder, basePath);

        return builder.build().toByteArray();
    }

    public static Map<String, byte[]> unpack(byte[] content)
            throws InvalidProtocolBufferException{
        ConfigFilePack filePack = ConfigFilePack.parseFrom(content);
        Map<String, byte[]> result = new HashMap<String, byte[]>();
        for (int i = filePack.getConfigFilesCount(); --i >= 0;){
            ConfigFile file = filePack.getConfigFiles(i);

            String fileName = file.getFileName().toStringUtf8();
            byte[] fileContent = file.getFileContent().toByteArray();
            result.put(fileName, fileContent);
        }
        return result;
    }

    /**
     * 将版本中的secret.hyc还原到config文件夹
     */
    public static void dump2ConfigFolder(){
        dump("config");
    }

    /**
     * 将版本中的secret.hyc还原到指定路径,如果指定路径存在,报错
     * @param toPath
     */
    public static void dump(String toPath){
        assert toPath != null;
        File toFolder = new File(toPath);
        if (toFolder.exists()){
            throw new IllegalArgumentException("目标路径已经存在");
        }
        if (!toFolder.mkdirs()){
            throw new IllegalStateException("创建目标文件夹失败");
        }

        Map<String, byte[]> configFiles = null;
        try (InputStream is = Utils.getInputStreamFromClassPath("secret.hyc")){
            if (is == null){
                throw new IllegalStateException("没有找到secret.hyc文件");
            }

            byte[] content = Utils.readGzipFile(is);
            configFiles = unpack(content);
        } catch (Throwable ex){
            throw new RuntimeException(ex);
        }

        for (Entry<String, byte[]> entry : configFiles.entrySet()){
            String fileName = entry.getKey();
            String folderName = fileName.substring(0,
                    fileName.lastIndexOf("/") + 1);

            File folder = new File(toFolder, folderName);
            if (!folder.exists() && !folder.mkdirs()){
                throw new IllegalStateException("创建子文件夹失败");
            }

            File toFile = new File(toFolder, entry.getKey());
            try (FileOutputStream fos = new FileOutputStream(toFile);){
                toFile.createNewFile();
                fos.write(entry.getValue());
                fos.flush();
            } catch (Throwable ex){
                System.err.println("还原" + entry.getKey() + " 出错");
                ex.printStackTrace();
                throw new RuntimeException(ex);
            }
        }
    }

    private static void addFile(File file, ConfigFilePack.Builder builder,
            String basePath) throws IOException{
        if (file.isDirectory()){
            if (file.getName().equalsIgnoreCase(".svn")){
                System.out.println("跳过 " + file.getAbsolutePath() + "文件夹");
                return;
            }
            for (File f : file.listFiles()){
                addFile(f, builder, basePath);
            }
        } else{
            // 真正处理
            byte[] content = Utils.readFile(file);

            String fileName = file.getAbsolutePath();
            int indexOf = fileName.indexOf(basePath);
            if (indexOf < 0){
                System.err.println("无法打包文件: " + fileName);
                throw new RuntimeException();
            }

            fileName = fileName.substring(indexOf + basePath.length());

            String[] names = Utils.split(fileName, File.separator);

            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < names.length; i++){
                sb.append(names[i]);
                if (i < names.length - 1){
                    sb.append("/");
                }
            }

            fileName = sb.toString();

            System.out.println("打包 " + fileName);

            builder.addConfigFiles(ConfigFile
                    .newBuilder()
                    .setFileName(
                            ByteString.copyFrom(StringEncoder.encode(fileName)))
                    .setFileContent(ByteString.copyFrom(content)));
//            builder
        }
    }
}
