package com.mokylin.sink.util.pack;

import java.util.Collection;
import java.util.Map;

import com.mokylin.collection.Pair;

public interface FileLoader{

    /**
     * 读取文件, 智能转换字符集, 如果文件不存在, 返回null.
     * 文件路径以 / 符号分割
     * @param path
     * @return
     */
    public String readFile(String path);

    /**
     * 读取文件的raw二进制内容, 如果文件不存在, 返回null
     * 文件路径以 / 符号分割
     * @param path
     * @return
     */
    public byte[] readByteFile(String path);

    /**
     * 返回文件夹下所有的文件, 智能转换字符集，不递归处理该目录中文件夹内的文件
     * @param path
     * @return
     */
    public Collection<Pair<String, String>> loadFilesInFolder(String path);

    /**
     * 返回文件夹下所有文件的raw二进制内容，不递归处理该目录中文件夹内的文件
     * @param path
     * @return
     */
    public Collection<Pair<String, byte[]>> loadByteFilesInFolder(String path);

    /**
     * 返回所有的文件
     * @return
     */
    public Map<String, byte[]> loadAllFiles();
}
