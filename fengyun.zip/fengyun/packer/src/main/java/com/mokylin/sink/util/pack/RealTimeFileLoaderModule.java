package com.mokylin.sink.util.pack;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.inject.AbstractModule;
import com.google.inject.Provides;
import com.google.inject.Singleton;

public class RealTimeFileLoaderModule extends AbstractModule{
    private static final Logger logger = LoggerFactory
            .getLogger(RealTimeFileLoaderModule.class);

    @Override
    protected void configure(){
        binder().requireExplicitBindings();
    }

    @Provides
    @Singleton
    public RealTimeFileLoader get(){
        return new RealTimeFileLoader();
    }

}
