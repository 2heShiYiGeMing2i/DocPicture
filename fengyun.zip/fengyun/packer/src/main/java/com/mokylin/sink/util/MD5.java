package com.mokylin.sink.util;

/**
 * @author Liwei
 *
 */
public class MD5 extends com.twmacinta.util.MD5{

    public MD5(){
    }

    @Override
    public void Update(String s){
        Update(StringEncoder.encode(s));
    }
}
