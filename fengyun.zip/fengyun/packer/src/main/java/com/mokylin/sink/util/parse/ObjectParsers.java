package com.mokylin.sink.util.parse;

import static com.google.common.base.Preconditions.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.Executor;
import java.util.concurrent.Future;
import java.util.concurrent.FutureTask;

import com.google.common.collect.LinkedHashMultiset;
import com.google.common.collect.Multiset.Entry;
import com.mokylin.sink.util.Empty;
import com.mokylin.sink.util.Utils;

public class ObjectParsers{

    private ObjectParsers(){
    }

    private static final int CORE_NUM = Runtime.getRuntime()
            .availableProcessors();

    public static List<ObjectParser> parseList(String fileName,
            String fileContent, Executor exec){
        try{
            if (fileContent == null){
                return Collections.emptyList();
            }
            String[] as = fileContent.split("\r\n");
            if (as.length <= 1){
                throw new IllegalArgumentException(fileName + " 用wps另存为制表格式");
            }

            String[] header = Utils.split(as[1], "\t");

            for (int i = 0; i < header.length; i++){
                header[i] = header[i].trim();
                int headerLength = header[i].length();
                if (headerLength > 2){
                    if (header[i].charAt(0) == '"'
                            && header[i].charAt(headerLength - 1) == '"'){
                        header[i] = header[i].substring(1, headerLength - 1);
                    }
                }
            }
            int objectCount = as.length - 2;

            int sliceNum = objectCount / (CORE_NUM);

            if (sliceNum <= 50){
                sliceNum = objectCount;
            }

            List<Future<List<ObjectParser>>> list = new LinkedList<>();

            for (int i = 2; i < as.length; i += sliceNum){
                list.add(submitCallable(
                        new ConfigLoader(i, Math.min(i + sliceNum, as.length),
                                header, as), exec));
            }

            List<ObjectParser> result = new ArrayList<>(objectCount);

            for (Future<List<ObjectParser>> future : list){
                for (ObjectParser parse : future.get()){
                    result.add(parse);
                }
            }
            return result;
        } catch (Throwable ex){
            System.err.println("读取错误: " + fileName);
            ex.printStackTrace();
            throw new RuntimeException(ex);
        }
    }

    private static <T> Future<T> submitCallable(Callable<T> callable,
            Executor exec){
        FutureTask<T> future = new FutureTask<T>(callable);
        exec.execute(future);
        return future;
    }

    private static class ConfigLoader implements Callable<List<ObjectParser>>{
        private int offset;
        private int endIndex;
        private String[] header;
        private String[] lines;

        public ConfigLoader(int offset, int endIndex, String[] header,
                String[] lines){
            super();
            this.offset = offset;
            this.endIndex = endIndex;
            this.header = header;
            this.lines = lines;
        }

        @Override
        public List<ObjectParser> call(){
            List<ObjectParser> result = new ArrayList<>(endIndex - offset);

            for (int i = offset; i < endIndex; i++){
                String line = lines[i].trim();
                int len = line.length();
                if (len == 0){
                    continue; // empty line
                }

                String[] values = Utils.split(lines[i], "\t"); // 用原来的来split,
                                                               // 不然最后的\t会被去掉
                for (int k = values.length; --k >= 0;){
                    String s = values[k].trim();

                    if (s.length() >= 2){
                        if (s.charAt(0) == '"'
                                && s.charAt(s.length() - 1) == '"'){
                            s = s.substring(1, s.length() - 1);
                        }
                    }
                    values[k] = s;
                }

                result.add(new ObjectParser(header, values));
            }
            return result;
        }
    }

    public static String toConfigFile(ObjectParser... parsers){
        checkNotNull(parsers);
        checkArgument(parsers.length > 0);

        // header
        LinkedHashMultiset<String> headers = LinkedHashMultiset.create();
        for (ObjectParser p : parsers){
            checkArgument(p.map.size() > 0);
            for (Entry<String> entry : p.map.keys().entrySet()){
                int count = entry.getCount();
                int currentCount = headers.count(entry.getElement());
                if (currentCount == 0){
                    headers.add(entry.getElement(), count);
                } else{
                    headers.setCount(entry.getElement(), count);
                }
            }
        }

        checkArgument(headers.size() > 0); // must have at least one header

        StringBuilder sb = new StringBuilder();
        sb.append("\r\n");
        for (Entry<String> headerEntry : headers.entrySet()){
            for (int i = headerEntry.getCount(); --i >= 0;){
                sb.append(headerEntry.getElement());
                sb.append('\t');
            }
        }

        sb.deleteCharAt(sb.length() - 1); // remove last trailing tab
        sb.append("\r\n");

        // add each object
        for (ObjectParser p : parsers){
            for (Entry<String> headerEntry : headers.entrySet()){
                List<String> field = p.map.get(headerEntry.getElement());
                for (String f : field){
                    sb.append(f);
                    sb.append("\t");
                }

                for (int i = headerEntry.getCount() - field.size(); --i >= 0;){
                    sb.append("\t");
                }
            }
            // remove trailing tab
            sb.deleteCharAt(sb.length() - 1);
            sb.append("\r\n");
        }

        return sb.toString();
    }

    public static ObjectParser emptyParser(){
        return EMPTY_PARSER1111;
    }

    public static final EmptyObjectParser EMPTY_PARSER1111 = new EmptyObjectParser();

    private static class EmptyObjectParser extends ObjectParser{

        EmptyObjectParser(){
            super(Empty.STRING_ARRAY, Empty.STRING_ARRAY);
        }

        @Override
        public String getKey(String key){
            return "";
        }

        @Override
        public int getIntKey(String key){
            return 0;
        }
    }

    public static final ObjectParser EMPTY_PARSER = new ObjectParser(
            Empty.STRING_ARRAY, Empty.STRING_ARRAY);
}
