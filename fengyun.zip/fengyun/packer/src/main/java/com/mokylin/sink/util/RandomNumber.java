package com.mokylin.sink.util;

public class RandomNumber{

    public static int getRate(){
        return ThreadLocalRandom.current().nextInt(100);
        // return rand.nextInt(100);
    }

    public static float getFraction(){
        return ThreadLocalRandom.current().nextFloat();
        // return rand.nextFloat();
    }

    public static int getRate(int num){
        return num != 0 ? ThreadLocalRandom.current().nextInt(Math.abs(num))
                : 0;
    }

    public static int randomInt(){
        return ThreadLocalRandom.current().nextInt();
    }

    public static long randomLong(){
        return ThreadLocalRandom.current().nextLong();
    }

    /**
     * 不检查参数的合法性
     * 
     * @param num
     * @param holder
     *            只是为了和别的方法区分
     * @return
     */
    public static int getRate(int num, boolean holder){
        return ThreadLocalRandom.current().nextInt(num);
    }
}
