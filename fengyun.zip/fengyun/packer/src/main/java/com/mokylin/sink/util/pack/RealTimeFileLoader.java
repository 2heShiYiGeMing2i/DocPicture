package com.mokylin.sink.util.pack;

import java.io.File;
import java.io.IOException;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.io.Files;
import com.mokylin.collection.Pair;
import com.mokylin.sink.util.Utils;

public class RealTimeFileLoader implements FileLoader{
    private static final Logger logger = LoggerFactory
            .getLogger(RealTimeFileLoader.class);

    @Override
    public String readFile(String path){
        String result = CharSetConvertor.readFile(path);
        return result;
    }

    @Override
    public Map<String, byte[]> loadAllFiles(){
        Map<String, byte[]> result = new HashMap<>();
        File folder = new File("config");
        try{
            doLoadFileInFolder(folder, "config/", result);
        } catch (IOException e){
            throw new RuntimeException(e);
        }
        return result;
    }

    private void doLoadFileInFolder(File folder, String dir,
            Map<String, byte[]> map) throws IOException{
        for (File file : folder.listFiles()){
            String name = file.getName();
            if (file.isFile()){
                if (".DS_Store".equals(name)){
                    continue; // 跳过mac中会自动生成的文件
                }
                String fullPath = dir + name;
                byte[] content = Files.toByteArray(file);
                map.put(fullPath, content);
                logger.debug("RealTimeFileLoader加载到文件: {}", fullPath);
            } else{
                if (".svn".equals(name)){
                    continue; // 跳过svn
                }
                String fullPath = dir + name + "/";
                doLoadFileInFolder(file, fullPath, map);
            }
        }
    }

    @Override
    public Collection<Pair<String, String>> loadFilesInFolder(String path){
        File folder = new File(path);
        if (folder.exists() && folder.isDirectory()){

            List<Pair<String, String>> result = new LinkedList<Pair<String, String>>();

            for (File s : folder.listFiles()){
                if (s.isFile()){
                    String ss = CharSetConvertor.readFile(s);
                    result.add(new Pair<String, String>(s.getName(), ss));
                }
            }
            return result;

        } else{
            return Collections.emptyList();
        }
    }

    @Override
    public byte[] readByteFile(String path){
        try{
            return Utils.readFile(path);
        } catch (IOException e){
            // TODO Auto-generated catch block
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public Collection<Pair<String, byte[]>> loadByteFilesInFolder(String path){
        File folder = new File(path);
        if (folder.exists() && folder.isDirectory()){

            List<Pair<String, byte[]>> result = new LinkedList<Pair<String, byte[]>>();

            for (File s : folder.listFiles()){
                if (s.isFile()){
                    try{
                        byte[] ss = Utils.readFile(s);
                        result.add(new Pair<String, byte[]>(s.getName(), ss));
                    } catch (IOException e){
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }
            }
            return result;

        } else{
            return Collections.emptyList();
        }
    }

}
