package com.mokylin.sink.util.pack;

import java.io.CharArrayReader;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.Map.Entry;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ServerConfigLoaders{
    private static final Logger logger = LoggerFactory
            .getLogger(ServerConfigLoaders.class);

    private ServerConfigLoaders(){
    }

    /**
     * 读取config/configuration.property中的内容
     */
    public static void readConfigFile(ServerConfig cls,
            ServerConfigLoader loader){
        logger.debug("Trying to load property file");
        Properties prop = new Properties();
        try{
            String input = loader.loadConfig();
            if (input == null){

                return;
            }
            prop.load(new CharArrayReader(input.toCharArray()));

            for (Entry<Object, Object> entry : prop.entrySet()){
                try{
                    String key = (String) entry.getKey();

                    key = key.trim();

                    if (key.startsWith("#")){ // skip
                                              // comment
                        continue;
                    }
                    final Field f;
                    try{
                        f = cls.getClass().getDeclaredField(key);
                    } catch (NoSuchFieldException ex){
                        throw new IllegalArgumentException(
                                "property not found: " + key + ", class: "
                                        + cls.getClass());
                    }

                    String value = ((String) entry.getValue()).trim();

                    int commentPos = value.indexOf("//");
                    if (commentPos >= 0)
                        value = value.substring(0, commentPos).trim();
                    if (value == null){
                        logger.info("null value for property: {}", key);
                        continue;
                    }
                    if (f.getType() == int.class){
                        int intValue = Integer.parseInt(value);
                        f.set(cls, intValue);
                    } else if (f.getType() == long.class){
                        f.set(cls, Long.parseLong(value));
                    } else if (f.getType() == boolean.class){
                        f.set(cls, Boolean.parseBoolean(value));
                    } else if (f.getType() == float.class){
                        f.set(cls, Float.parseFloat(value));
                    } else if (f.getType() == double.class){
                        f.set(cls, Double.parseDouble(value));
                    } else{
                        f.set(cls, value);
                    }

                    logger.info("set {} -> {}", key, value);
                } catch (Throwable e){
                    throw new IllegalArgumentException(e);
                }
            }

            cls.init();
        } catch (IOException ex){
            throw new IllegalArgumentException(ex);
        }
    }
}
