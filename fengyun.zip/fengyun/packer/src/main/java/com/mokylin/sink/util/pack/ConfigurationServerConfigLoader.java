package com.mokylin.sink.util.pack;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ConfigurationServerConfigLoader implements ServerConfigLoader{
    private static final Logger logger = LoggerFactory
            .getLogger(ConfigurationServerConfigLoader.class);
    
    private static String SERVER_CONFIG_FILE = "configuration.property";
    
    public String loadConfig(){
        // �����static�ķ���, ����mock
        return CharSetConvertor.readFile(SERVER_CONFIG_FILE);
    }
}
