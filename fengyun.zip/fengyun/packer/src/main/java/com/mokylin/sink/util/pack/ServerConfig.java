package com.mokylin.sink.util.pack;

public interface ServerConfig{
    void init();
}
