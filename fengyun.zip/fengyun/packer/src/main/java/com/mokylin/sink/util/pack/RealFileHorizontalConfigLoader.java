package com.mokylin.sink.util.pack;

import static com.google.common.base.Preconditions.checkArgument;

import java.util.List;

import com.google.common.collect.Lists;
import com.google.inject.Inject;
import com.mokylin.sink.util.Empty;
import com.mokylin.sink.util.parse.ObjectParser;
import com.mokylin.sink.util.parse.ObjectParsers;

public class RealFileHorizontalConfigLoader{

    private final RealTimeFileLoader fileLoader;

    @Inject
    public RealFileHorizontalConfigLoader(RealTimeFileLoader fileLoader){
        this.fileLoader = fileLoader;
    }

    public ObjectParser loadFile(String location){
        String data = fileLoader.readFile(location);
        if (data == null){
            return ObjectParsers.EMPTY_PARSER;
        }

        String[] as = data.split("\\r?\\n"); // 兼顾\n和\r\n

        List<String> headerList = Lists.newArrayListWithCapacity(as.length);
        List<String> valueList = Lists.newArrayListWithCapacity(as.length);

        for (String rawLine : as){
            try{
                String line = rawLine.trim();
                if (line.length() == 0){
                    continue;
                }

                if (line.startsWith("#")){
                    continue;
                }

                int commentPos = line.indexOf("//");
                if (commentPos >= 0){
                    line = line.substring(0, commentPos);
                }
                line = line.trim();
                if (line.length() == 0){
                    continue;
                }

                int epos = line.indexOf("=");
                checkArgument(epos > 0, "%s 格式错误. 必须是 key = value: %s",
                        location, line);
                String key = line.substring(0, epos).trim();

                String value = line.substring(epos + 1).trim();

                headerList.add(key);
                valueList.add(value);
            } catch (Throwable e){
                throw new IllegalArgumentException(e);
            }
        }

        return new ObjectParser(headerList.toArray(Empty.STRING_ARRAY),
                valueList.toArray(Empty.STRING_ARRAY));

    }
}
