package com.mokylin.sink.util;

import static com.google.common.base.Preconditions.checkArgument;

import com.mokylin.sink.util.parse.ObjectParser;
import com.mokylin.sink.util.parse.ObjectParsers;

public class ArgParser{

    public static ObjectParser parse(String[] args){
        if (args.length == 0){
            return ObjectParsers.EMPTY_PARSER;
        }
        ObjectParser.Builder builder = ObjectParser.newBuilder();

        for (String s : args){
            int eqPos = s.indexOf("=");
            checkArgument(eqPos > 0, "参数格式是 key=value: %s", s);

            String key = s.substring(0, eqPos);
            String value = s.substring(eqPos + 1);
            builder.addField(key.trim(), value.trim());
        }

        return builder.build();
    }
}
